package sf.bankautomationdallas.pages;

import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;
import net.thucydides.core.annotations.DefaultUrl;

//changes made 1
@DefaultUrl("https://techguide.test.statefarm.com")
public class SFTechGuidePage extends PageObject {

	@FindBy(id = "searchInput")
	private WebElementFacade searchField;

	@FindBy(xpath = "//a[contains(@title,'Maven')]")
	private WebElementFacade searchResultLink;

	public WebElementFacade getSearchField() {
		return searchField;
	}

	public WebElementFacade getSearchResult() {
		return searchResultLink;
	}
}
