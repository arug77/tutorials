package sf.bankautomationdallas.it;

import sf.icp.selenium.bdd.serenity.AbstractSerenityTestRunner;

public class BddTestSuite extends AbstractSerenityTestRunner {

	@Override
	public String getStepsPackage() {
		return "sf.bankautomationdallas";
	}
}
