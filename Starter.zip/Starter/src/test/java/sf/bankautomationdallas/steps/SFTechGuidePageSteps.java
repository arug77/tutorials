package sf.bankautomationdallas.steps;

import org.jbehave.core.annotations.Given;
import org.jbehave.core.annotations.Then;
import org.jbehave.core.annotations.When;
import org.junit.Assert;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import sf.bankautomationdallas.pages.SFTechGuidePage;

@Component
public class SFTechGuidePageSteps {
	@Autowired
	Environment env;

	@Autowired
	ApplicationContext ctx;

	SFTechGuidePage sfTechGuidePage;

	@Given("I launch the SF tech guide")
	public void openLoginConfig() {
		sfTechGuidePage.open();
	}

	@Then("the page title is $titleValue")
	public void laneIsVisible(String titleValue) {
		Assert.assertEquals(titleValue, sfTechGuidePage.getTitle());
	}

	@When("I search for $searchValue")
	public void searchTechGuide(String searchValue) {
		sfTechGuidePage.getSearchField().typeAndEnter(searchValue);
	}

	@When("I click on the search result")
	public void selectSearchResult() {
		sfTechGuidePage.getSearchResult().click();
	}

}
