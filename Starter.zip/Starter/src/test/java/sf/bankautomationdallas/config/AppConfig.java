package sf.bankautomationdallas.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.ImportResource;
import org.springframework.context.annotation.PropertySource;

@Configuration
@ImportResource({ "classpath:META-INF/applicationContext-uitests.xml" })
@PropertySource("classpath:config.properties")
public class AppConfig {
	
}
