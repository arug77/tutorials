select credit_request.client_app_id,
verification_services_view.applicant,
verification_services_view.verification_product,
verification_services_view.product_model,
to_char(to_evaluatortime(service_date_time,credit_request.evaluator_id),'MM/DD/YYYY HH12:MI:SS AM') AS formatted_service_date_time,
TRIM(TO_CHAR([datecol],'Month'))||' '||TO_CHAR([datecol],'dd'||','||' yyyy') AS DAILY_TXT,
'Week of '||TRIM(TO_CHAR([datecol],'Month'))||' '||TO_CHAR(TRUNC([datecol],'w'),'dd'||','||' yyyy') AS WEEKLY_TXT,
trim(to_char([datecol],'Month')) || ' ' || to_char([datecol],'yyyy') AS MONTHLY_TXT,
decode(to_char([datecol],'Q'),1,'January - March',2,'April - June',3,'July - September',4,'October - December') || ' ' || to_char([datecol],'yyyy') AS QUARTERLY_TXT,
to_char([datecol],'yyyy') AS YEARLY_TXT
from credit_request,
verification_services_view
where credit_request.appseqno = verification_services_view.appseqno