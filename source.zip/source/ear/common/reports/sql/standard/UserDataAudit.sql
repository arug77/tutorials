select user_aud_view.audit_id,
user_aud_view.user_id,
(users.last_name_txt || CHR(44) || users.first_name_txt) as user_name,
user_aud_view.column_name_txt,
user_aud_view.old_value_txt,
user_aud_view.new_value_txt,
case when evaluator.country_id like '%CAN%' then to_char(user_aud_view.audit_last_updated_dt,'YYYY/MM/DD HH12:MI:SS AM')
else to_char(user_aud_view.audit_last_updated_dt,'MM/DD/YYYY HH12:MI:SS AM') end as audit_last_updated_dt ,
user_aud_view.audit_updated_user_id,
evaluator.evaluator_name_txt,
evaluator.evaluator_id,
TRIM(TO_CHAR([datecol],'Month'))||' '||TO_CHAR([datecol],'dd'||','||' yyyy') AS DAILY_TXT,
trim(to_char([datecol],'Month')) || ' ' || to_char([datecol],'yyyy') AS MONTHLY_TXT,
decode(to_char([datecol],'Q'),1,'January - March',2,'April - June',3,'July - September',4,'October - December') || ' ' || to_char([datecol],'yyyy') AS QUARTERLY_TXT,
to_char([datecol],'yyyy') AS YEARLY_TXT
from user_aud_view,
users,
evaluator
WHERE user_aud_view.evaluator_id = evaluator.evaluator_id
and user_aud_view.user_id = users.user_id
