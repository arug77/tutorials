select evaluator.evaluator_id,
evaluator.evaluator_name_txt,
credit_request.request_id, 
credit_request.client_app_id,
credit_request.application_name_txt,
users.team_id,
users.user_id, 
users.user_id AS assigned_user_id,
decode(users.last_name_txt||users.first_name_txt,'','',users.last_name_txt||CHR(44)||' '||users.first_name_txt) AS name_txt,
config_team.team_name_txt,
concurrency_control.lock_dt,
to_char(to_evaluatortime(concurrency_control.lock_dt,evaluator.evaluator_id),'MM/DD/YYYY HH:MI:SS AM') AS lock_dt_txt
from concurrency_control,
users,
credit_request,
config_team,
evaluator
where concurrency_control.request_id = credit_request.request_id
and concurrency_control.user_id = users.user_id
and users.team_id = config_team.team_id
and users.evaluator_id = config_team.evaluator_id
and users.evaluator_id = evaluator.evaluator_id
and upper(users.user_id) not like 'SYSTEM%'