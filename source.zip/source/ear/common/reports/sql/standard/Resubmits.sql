select credit_request.client_app_id, 
to_char(to_evaluatortime(credit_request.initiation_dt,credit_request.evaluator_id),'MM/DD/YYYY HH12:MI:SS AM') AS initiation_dt,
mstr_app_status.status_code, 
to_char(to_evaluatortime(credit_request_journal.journal_dt,credit_request_journal.evaluator_id),'MM/DD/YYYY HH12:MI AM') AS formatted_journal_dt, 
credit_request_journal.created_user_id, 
credit_request_journal.journal_event_txt 
from credit_request,
mstr_app_status,
credit_request_journal
where credit_request.app_status_id = mstr_app_status.status_id
and credit_request.request_id = credit_request_journal.request_id
and credit_request_journal.journal_event_id = 75