select credit_request.client_app_id,
credit_request.request_id,
credit_request.evaluator_id,
credit_request.application_name_txt,
credit_request.loan_purpose_id,
crd_req_finance_program_view.finance_program_txt,
mstr_app_status.default_status_txt,
credit_request.task_id,
mstr_evaluator_decision.decision_txt,
TRIM(TO_CHAR([datecol],'Month'))||' '||TO_CHAR([datecol],'dd'||','||' yyyy') AS DAILY_TXT,
'Week of '||TRIM(TO_CHAR([datecol],'Month'))||' '||TO_CHAR(TRUNC([datecol],'w'),'dd'||','||' yyyy') AS WEEKLY_TXT,
trim(to_char([datecol],'Month')) || ' ' || to_char([datecol],'yyyy') AS MONTHLY_TXT,
decode(to_char([datecol],'Q'),1,'January - March',2,'April - June',3,'July - September',4,'October - December') || ' ' || to_char([datecol],'yyyy') AS QUARTERLY_TXT,
to_char([datecol],'yyyy') AS YEARLY_TXT
from credit_request,
crd_req_finance_program_view,
mstr_app_status,
credit_req_decisions_evaluator,
mstr_evaluator_decision,
config_loan_purpose
where credit_request.request_id = crd_req_finance_program_view.request_id (+)
and credit_request.app_status_id = mstr_app_status.status_id
and credit_request.latest_dec_ref_id = credit_req_decisions_evaluator.decision_ref_id (+)
and credit_req_decisions_evaluator.decision_id = mstr_evaluator_decision.decision_id (+)
and credit_request.evaluator_id = config_loan_purpose.evaluator_id (+)
and credit_request.product_id = config_loan_purpose.product_id (+)
and credit_request.loan_purpose_id = config_loan_purpose.loan_purpose_id (+)
and config_loan_purpose.hmda_eligible_flg = 1