select xep.profile_id, 
us.user_id, 
get_user_name(us.user_id) as user_name, 
decode(get_user_status(us.user_id),'ACTIVE','Yes','No') as user_status,
evaluator.evaluator_name_txt 
from evaluator, xref_evaluator_profiles xep, users us 
where xep.evaluator_id = evaluator.evaluator_id
and us.evaluator_id = xep.evaluator_id
and us.profile_id = xep.profile_id