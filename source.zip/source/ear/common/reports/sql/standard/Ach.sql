select credit_request.client_app_id,
credit_request.request_id,
credit_request_payoff.payoff_type_id,
evaluator_originator.originator_name_txt,
to_char(to_evaluatortime(credit_request.funding_dt,credit_request.evaluator_id),'MM/DD/YYYY HH12:MI AM') AS funding_dt,
GET_GEN_TIME_USER(credit_request_payoff_mpe.mpe_gen_time_id,credit_request_payoff_mpe.request_id) AS funding_user_id,
mstr_aba_type.aba_txt AS account_type,
credit_request_payoff.payoff_num AS amount_num,
evaluator.evaluator_name_txt,
TRIM(TO_CHAR([datecol],'Month'))||' '||TO_CHAR([datecol],'dd'||','||' yyyy') AS DAILY_TXT,
'Week of '||TRIM(TO_CHAR([datecol],'Month'))||' '||TO_CHAR(TRUNC([datecol],'w'),'dd'||','||' yyyy') AS WEEKLY_TXT,
trim(to_char([datecol],'Month'))||' '||to_char([datecol],'yyyy') AS MONTHLY_TXT,
decode(to_char([datecol],'Q'),1,'January - March',2,'April - June',3,'July - September',4,'October - December') || ' ' || to_char([datecol],'yyyy') AS QUARTERLY_TXT,
to_char([datecol],'yyyy') AS YEARLY_TXT
from credit_request,
credit_request_originator,
evaluator_originator,
credit_request_funding,
credit_request_finance,
mstr_aba_type,
credit_request_payoff_mpe,
credit_request_payoff,
credit_req_decisions_evaluator,
evaluator
where credit_request.request_id = credit_request_originator.request_id (+) 
and credit_request.evaluator_id = credit_request_originator.evaluator_id (+) 
and credit_request_originator.originator_id = evaluator_originator.originator_id (+) 
and credit_request_originator.evaluator_id = evaluator_originator.evaluator_id (+)
and credit_request.request_id = credit_request_funding.request_id
and credit_request.request_id = credit_request_payoff_mpe.request_id
and credit_request.request_id = credit_request_payoff.request_id
and credit_request_payoff_mpe.payoff_id = credit_request_payoff.payoff_id
and credit_request_payoff_mpe.seq_num = get_max_payoff_seq_num(credit_request_payoff_mpe.request_id,credit_request_payoff_mpe.payoff_id)
and credit_request.request_id = credit_request_finance.request_id
and credit_request.evaluator_id = credit_request_finance.evaluator_id
and credit_request_payoff.aba_type_id = mstr_aba_type.aba_id (+)
and credit_request_payoff_mpe.mpe_type_id = 'ACH'
and credit_request_payoff.detail_fund_meth_id = 4
and check_activity_status(credit_request_payoff_mpe.mpe_gen_time_id,credit_request.request_id) > 0
and credit_request.request_id = credit_req_decisions_evaluator.request_id
and credit_request.evaluator_id = evaluator.evaluator_id
and credit_req_decisions_evaluator.decision_ref_id = (select max(decision_ref_id) from credit_req_decisions_evaluator where request_id = credit_request.request_id)
and credit_req_decisions_evaluator.decision_id in (1, 3, 102)
