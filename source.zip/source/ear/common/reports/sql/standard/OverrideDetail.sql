select credit_request.client_app_id,
credit_request.request_id, 
credit_request.evaluator_id, 
credit_request.application_name_txt, 
to_char(to_evaluatortime(credit_request.initiation_dt,credit_request.evaluator_id),'MM/DD/YYYY HH12:MI:SS AM') AS initiation_dt,
evaluator_originator.originator_name_txt, 
mstr_product.product_short_name_txt, 
credit_req_decisions_evaluator.approved_grade_txt, 
credit_req_decisions_evaluator.decisioned_by_user_id, 
mstr_evaluator_decision.decision_txt, 
credit_req_decisions_evaluator.decision_ref_id, 
to_char(to_evaluatortime(credit_req_decisions_evaluator.send_dt,credit_request.evaluator_id),'MM/DD/YYYY') AS decision_dt,
case
    when (credit_req_decisions_evaluator.decision_id in (1,3,102,104) and credit_request.booking_status_id in (2,3)) then nvl(credit_request_funding.tot_fund_amt_num,0)
    when (credit_req_decisions_evaluator.decision_id in (1,3,102,104)) then nvl(credit_req_decisions_evaluator.approved_amount_num,0)
    else calc_requested_amount_num(credit_request.request_id,credit_request.evaluator_id)
end as amount_financed_num, 
TRIM(TO_CHAR([datecol],'Month'))||' '||TO_CHAR([datecol],'dd'||','||' yyyy') AS DAILY_TXT, 
'Week of '||TRIM(TO_CHAR([datecol],'Month'))||' '||TO_CHAR(TRUNC([datecol],'w'),'dd'||','||' yyyy') AS WEEKLY_TXT, 
trim(to_char([datecol],'Month')) || ' ' || to_char([datecol],'yyyy') AS MONTHLY_TXT, 
decode(to_char([datecol],'Q'),1,'January - March',2,'April - June',3,'July - September',4,'October - December') || ' ' || to_char([datecol],'yyyy') AS QUARTERLY_TXT, 
to_char([datecol],'yyyy') AS YEARLY_TXT,
config_override_categories.category_txt 
from credit_request,
credit_request_originator,
evaluator_originator,
mstr_product,
credit_req_decisions_evaluator,
mstr_evaluator_decision,
credit_req_decision_reasons,
credit_request_funding,
config_override_categories,
config_decision_reasons
where credit_request.request_id = credit_request_originator.request_id (+) 
and credit_request.evaluator_id = credit_request_originator.evaluator_id (+) 
and credit_request_originator.originator_id = evaluator_originator.originator_id (+) 
and credit_request_originator.evaluator_id = evaluator_originator.evaluator_id (+) 
and credit_request.product_id = mstr_product.product_id (+)
and credit_request.request_id = credit_request_funding.request_id (+) 
and credit_request.latest_dec_ref_id = credit_req_decisions_evaluator.decision_ref_id (+)
and credit_req_decisions_evaluator.decision_id = mstr_evaluator_decision.decision_id (+) 
and credit_request.latest_dec_ref_id = credit_req_decision_reasons.decision_ref_id
and credit_req_decision_reasons.reason_type_id = 2
and credit_req_decision_reasons.reason_type_id = config_decision_reasons.reason_type_id
and credit_req_decision_reasons.reason_id = config_decision_reasons.reason_id
and config_decision_reasons.evaluator_id = config_override_categories.evaluator_id
and config_override_categories.active_flg = 1
and config_decision_reasons.category_id = config_override_categories.category_id (+)