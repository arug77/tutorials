select distinct(credit_request.client_app_id) as client_app_id, 
credit_request.request_id, 
to_evaluatortime(credit_request.funding_dt,credit_request.evaluator_id) AS funding_dt, 
max_deler_reserve_view.adj_reserve_amt_num, 
CASE
WHEN credit_request.evaluator_id =25 THEN GET_DRAFT_AMOUNT_NUM(credit_request.request_id)
ELSE GET_FUNDING_AMOUNT_NUM(credit_request.request_id,credit_request.task_group_id)
END AS amount_financed_num, 
evaluator_originator.ach_fax_no_txt, 
evaluator.evaluator_name_txt, 
evaluator_address.address1_txt, 
evaluator_address.city_txt, 
evaluator_address.state_id, 
evaluator_address.zipcode_txt, 
evaluator_originator.originator_name_txt, 
evaluator_originator.originator_code_txt, 
evaluator_originator.contact_txt, 
TRIM(TO_CHAR([datecol],'Month'))||' '||TO_CHAR([datecol],'dd'||','||' yyyy') AS DAILY_TXT, 
'Week of '||TRIM(TO_CHAR([datecol],'Month'))||' '||TO_CHAR(TRUNC([datecol],'w'),'dd'||','||' yyyy') AS WEEKLY_TXT, 
trim(to_char([datecol],'Month')) || ' ' || to_char([datecol],'yyyy') AS MONTHLY_TXT, 
decode(to_char([datecol],'Q'),1,'January - March',2,'April - June',3,'July - September',4,'October - December') || ' ' || to_char([datecol],'yyyy') AS QUARTERLY_TXT, 
to_char([datecol],'yyyy') AS YEARLY_TXT 
from credit_request,
evaluator_originator,
credit_request_originator,
config_sales_rep,
credit_req_contr_fin,
credit_request_payoff,
credit_request_funding,
credit_req_decisions_evaluator,
credit_req_contra_fin_fee_sum,
max_deler_reserve_view,
mstr_funding_method,
evaluator_address,
requestor,
evaluator
where credit_request_originator.originator_id = evaluator_originator.originator_id (+) 
and credit_request_originator.evaluator_id = evaluator_originator.evaluator_id (+)
and credit_request.request_id = requestor.request_id (+) 
and credit_request.evaluator_id = requestor.evaluator_id (+)
and credit_request.request_id = credit_request_originator.request_id (+) 
and credit_request.evaluator_id = credit_request_originator.evaluator_id (+)
and evaluator_originator.sales_rep_txt = config_sales_rep.sales_rep_txt (+) 
and evaluator_originator.evaluator_id = config_sales_rep.evaluator_id (+)   
and credit_request.request_id = credit_req_contr_fin.request_id (+)
and credit_request.request_id = credit_request_payoff.request_id (+)
and credit_request.evaluator_id = credit_request_payoff.evaluator_id (+)
and credit_request.request_id = credit_request_funding.request_id (+)
and credit_request.latest_dec_ref_id = credit_req_decisions_evaluator.decision_ref_id (+)
and credit_request.request_id = credit_req_contra_fin_fee_sum.request_id (+)
and credit_request.evaluator_id = credit_req_contra_fin_fee_sum.evaluator_id (+)
and credit_request_payoff.detail_fund_meth_id = mstr_funding_method.fund_meth_id (+)
and credit_request.evaluator_id = evaluator_address.evaluator_id
and credit_request.evaluator_id = evaluator.evaluator_id
and evaluator_address.address_type_id = 0
and credit_req_contra_fin_fee_sum.finance_id (+) = 1
and credit_request_payoff.payoff_id (+) = 1
and credit_request.request_id = max_deler_reserve_view.request_id (+)
and credit_request.funding_dt is not null
and evaluator_originator.ach_fax_no_txt is not null