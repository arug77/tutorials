SELECT credit_request.request_id,
    credit_request.evaluator_id,
    credit_request.client_app_id,
    credit_request.task_id,
    [datecol] as initiation_dt,
	ev.evaluate_client_id_txt
	from credit_request, evaluator ev
where  upper(credit_request.task_id) != 'DONE' AND credit_request.evaluator_id = ev.evaluator_id 

  


