select to_char((to_date('[dateStart]','MM/DD/YYYY')+ rownum -1),'MM/DD/YYYY') as date_unit,
	to_char((to_date('[dateStart]','MM/DD/YYYY')+ rownum),'MM/DD/YYYY') as date_unit_inc
    from all_objects
     where rownum <= 
to_date('[dateEnd]','MM/DD/YYYY')-to_date('[dateStart]','MM/DD/YYYY')