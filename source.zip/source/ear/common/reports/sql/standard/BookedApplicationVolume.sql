select credit_request.client_app_id, 
credit_request.request_id, 
credit_request.evaluator_id,
credit_req_decisions_evaluator.decision_id,
credit_request.booking_status_id,
credit_request.app_status_id,
nvl(credit_req_contr_fin.amount_financed_num,nvl(credit_req_decisions_evaluator.approved_amount_num,nvl(calc_requested_amount_num(credit_request.request_id,credit_request.evaluator_id),0))) AS amount_financed_num,
TRIM(TO_CHAR([datecol],'Month'))||' '||TO_CHAR([datecol],'dd'||','||' yyyy') AS DAILY_TXT,
'Week of '||TRIM(TO_CHAR([datecol],'Month'))||' '||TO_CHAR(TRUNC([datecol],'w'),'dd'||','||' yyyy') AS WEEKLY_TXT,
trim(to_char([datecol],'Month')) || ' ' || to_char([datecol],'yyyy') AS MONTHLY_TXT,
decode(to_char([datecol],'Q'),1,'January - March',2,'April - June',3,'July - September',4,'October - December') || ' ' || to_char([datecol],'yyyy') AS QUARTERLY_TXT,
to_char([datecol],'yyyy') AS YEARLY_TXT
from credit_request,
credit_req_decisions_evaluator,
credit_req_contr_fin
where credit_request.latest_dec_ref_id = credit_req_decisions_evaluator.decision_ref_id (+)
and credit_request.request_id = credit_req_contr_fin.request_id (+)