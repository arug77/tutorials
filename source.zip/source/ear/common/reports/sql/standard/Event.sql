select evaluator.evaluator_id,
evaluator.evaluator_name_txt,
event.event_id,
event.user_id,
event.user_id AS application_name_txt,
event.user_id AS client_app_id,
users.first_name_txt||' '||users.last_name_txt AS name_txt,
to_char(to_evaluatortime(event.event_dt,evaluator.evaluator_id),'MM/DD/YYYY HH:MI:SS AM') AS event_dt_txt,
event.event_dt,
event.event_type_id,
mstr_event.event_type_description_txt,
TRIM(TO_CHAR([datecol],'Month'))||' '||TO_CHAR([datecol],'dd'||','||' yyyy') AS DAILY_TXT,
'Week of '||TRIM(TO_CHAR([datecol],'Month'))||' '||TO_CHAR(TRUNC([datecol],'w'),'dd'||','||' yyyy') AS WEEKLY_TXT,
trim(to_char([datecol],'Month'))||' '||to_char([datecol],'yyyy') AS MONTHLY_TXT,
decode(to_char([datecol],'Q'),1,'January - March',2,'April - June',3,'July - September',4,'October - December')||' '||to_char([datecol],'yyyy') AS QUARTERLY_TXT,
to_char([datecol],'yyyy') AS YEARLY_TXT
from event,
mstr_event,
users,
evaluator
where event.user_id=users.user_id
and evaluator.evaluator_id=event.evaluator_id
and event.event_type_id=mstr_event.event_type_id
and mstr_event.event_type_id not in (12)