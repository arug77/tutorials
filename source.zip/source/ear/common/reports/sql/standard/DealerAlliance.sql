select evaluator_originator.originator_id,
evaluator_originator.originator_code_txt, 
evaluator_originator.originator_name_txt, 
config_region.region_desc_txt, 
config_region.region_code_txt, 
config_region.region_id, 
originator_address.address1_txt, 
originator_address.address2_txt, 
originator_address.city_txt, 
originator_address.state_id, 
originator_address.zipcode_txt, 
originator_address.phone_number_txt, 
xref_eval_orig_comm_type.comm_type_number_txt as fax_number_txt, 
evaluator_originator.contact_txt, 
evaluator_originator.email_address_txt, 
config_sales_rep.last_name_txt, 
config_sales_rep.first_name_txt 
from evaluator_originator,
config_region,
originator_address,
config_sales_rep,
xref_eval_orig_comm_type
where evaluator_originator.evaluator_id = config_region.evaluator_id (+)
and evaluator_originator.region_id = config_region.region_id (+)
and evaluator_originator.originator_id = originator_address.originator_id (+)
and evaluator_originator.evaluator_id = originator_address.evaluator_id (+)
and originator_address.address_type_id (+) = 0
and config_sales_rep.sales_rep_txt (+) = evaluator_originator.sales_rep_txt
and xref_eval_orig_comm_type.evaluator_id (+) = originator_address.evaluator_id
and xref_eval_orig_comm_type.originator_id (+) = originator_address.originator_id
and xref_eval_orig_comm_type.address_type_id (+) = originator_address.address_type_id
and xref_eval_orig_comm_type.comm_type_id (+) = 1    
and xref_eval_orig_comm_type.comm_id (+) = 1