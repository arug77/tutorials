select credit_request.request_id,
credit_request.evaluator_id, 
credit_request.client_app_id,
credit_request.application_name_txt,
credit_request_originator.loan_originator_id,
to_evaluatortime(credit_request.initiation_dt,credit_request.evaluator_id) AS initiation_dt,
evaluator_originator.originator_name_txt,
evaluator_originator.contact_txt,
config_region.region_desc_txt,
config_sources.source_desc_txt,
mstr_product.product_short_name_txt,
nvl(credit_req_contr_fin.amount_financed_num,nvl(credit_req_decisions_evaluator.approved_amount_num,nvl(calc_requested_amount_num(credit_request.request_id,credit_request.evaluator_id),0))) AS amount_financed_num,
credit_request.task_id, 
mstr_app_status.default_status_txt AS app_status,
to_evaluatortime(credit_request.current_status_dt,credit_request.evaluator_id) AS current_status_dt,
credit_req_decisions_evaluator.decisioned_by_user_id AS assigned_user_id,
credit_req_decisions_evaluator.decisioned_by_user_id,
credit_request.booking_status_id,
credit_req_decisions_evaluator.decision_id,
evaluator_originator.market_txt,
u.FIRST_NAME_TXT || ' ' || u.LAST_NAME_TXT as loan_originator_name,
users_view.user_name_txt,
TRIM(TO_CHAR([datecol],'Month'))||' '||TO_CHAR([datecol],'dd'||','||' yyyy') AS DAILY_TXT,
'Week of '||TRIM(TO_CHAR([datecol],'Month'))||' '||TO_CHAR(TRUNC([datecol],'w'),'dd'||','||' yyyy') AS WEEKLY_TXT,
trim(to_char([datecol],'Month')) || ' ' || to_char([datecol],'yyyy') AS MONTHLY_TXT,
decode(to_char([datecol],'Q'),1,'January - March',2,'April - June',3,'July - September',4,'October - December') || ' ' || to_char([datecol],'yyyy') AS QUARTERLY_TXT,
to_char([datecol],'yyyy') AS YEARLY_TXT,
get_model_year(credit_request.request_id) as model_year
from credit_request,
credit_request_originator,
evaluator_originator,
config_region,
config_sources,
mstr_product,
mstr_app_status,
credit_req_decisions_evaluator,
users u,
credit_req_contr_fin,
users_view
where credit_request.request_id = credit_request_originator.request_id (+) 
and credit_request.evaluator_id = credit_request_originator.evaluator_id (+)
and credit_request_originator.originator_id = evaluator_originator.originator_id (+) 
and credit_request_originator.evaluator_id = evaluator_originator.evaluator_id (+)
and evaluator_originator.region_id = config_region.region_id (+) 
and evaluator_originator.evaluator_id = config_region.evaluator_id (+)
and credit_request.source_id = config_sources.source_id (+) 
and credit_request.evaluator_id = config_sources.evaluator_id (+)
and credit_request.product_id = mstr_product.product_id (+)
and credit_request.app_status_id = mstr_app_status.status_id
and credit_request.latest_dec_ref_id = credit_req_decisions_evaluator.decision_ref_id (+)
and credit_request.request_id = credit_req_contr_fin.request_id (+)
and credit_request_originator.loan_originator_id = u.user_id (+)
and u.user_id = users_view.user_id (+)