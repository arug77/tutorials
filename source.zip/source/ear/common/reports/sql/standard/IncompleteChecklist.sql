select distinct(credit_request.client_app_id) as client_app_id, 
credit_request.request_id, 
credit_request.evaluator_id, 
to_char(to_evaluatortime(credit_request.initiation_dt,credit_request.evaluator_id),'MM/DD/YYYY') AS initiation_dt, 
credit_request.application_name_txt, 
evaluator_originator.originator_name_txt, 
config_sales_rep.sales_rep_txt, 
credit_req_decisions_evaluator.decisioned_by_user_id, 
credit_req_decisions_evaluator.approved_grade_txt, 
nvl(credit_req_decisions_evaluator.approved_tier_txt,'-') AS approved_tier_txt, 
TRIM(TO_CHAR([datecol],'Month'))||' '||TO_CHAR([datecol],'dd'||','||' yyyy') AS DAILY_TXT, 
'Week of '||TRIM(TO_CHAR([datecol],'Month'))||' '||TO_CHAR(TRUNC([datecol],'w'),'dd'||','||' yyyy') AS WEEKLY_TXT, 
trim(to_char([datecol],'Month')) || ' ' || to_char([datecol],'yyyy') AS MONTHLY_TXT, 
decode(to_char([datecol],'Q'),1,'January - March',2,'April - June',3,'July - September',4,'October - December') || ' ' || to_char([datecol],'yyyy') AS QUARTERLY_TXT, 
to_char([datecol],'yyyy') AS YEARLY_TXT 
from credit_request,
credit_request_originator,
evaluator_originator,
config_sales_rep,
credit_req_decisions_evaluator,
credit_req_checklist_item
where credit_request.request_id = credit_request_originator.request_id (+) 
and credit_request.evaluator_id = credit_request_originator.evaluator_id (+) 
and credit_request_originator.originator_id = evaluator_originator.originator_id (+) 
and credit_request_originator.evaluator_id = evaluator_originator.evaluator_id (+)
and evaluator_originator.sales_rep_txt = config_sales_rep.sales_rep_txt (+) 
and evaluator_originator.evaluator_id = config_sales_rep.evaluator_id (+)
and credit_request.latest_dec_ref_id = credit_req_decisions_evaluator.decision_ref_id (+)
and credit_request.app_status_id in (17, 22, 23, 26)
and credit_request.task_group_id = 'CONTRACTADMIN'
and credit_request.request_id = credit_req_checklist_item.request_id
and credit_request.evaluator_id = credit_req_checklist_item.evaluator_id 
and credit_req_checklist_item.checklist_item_status_id = 1