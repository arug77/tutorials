select credit_request.client_app_id,
credit_request_app_history.user_id,
get_team_name(credit_request.evaluator_id,credit_request_app_history.team_id) as team_name_txt,
mstr_app_status.default_status_txt,
config_task.task_desc_txt,
to_char(to_evaluatortime(credit_request_app_history.start_dt,credit_request.evaluator_id),'MM/DD/YYYY HH12:MI:SS AM') AS start_dt,
to_char(to_evaluatortime(credit_request_app_history.end_dt,credit_request.evaluator_id),'MM/DD/YYYY HH12:MI:SS AM') AS end_dt,
TRIM(TO_CHAR([datecol],'Month'))||' '||TO_CHAR([datecol],'dd'||','||' yyyy') AS DAILY_TXT,
'Week of '||TRIM(TO_CHAR([datecol],'Month'))||' '||TO_CHAR(TRUNC([datecol],'w'),'dd'||','||' yyyy') AS WEEKLY_TXT,
trim(to_char([datecol],'Month')) || ' ' || to_char([datecol],'yyyy') AS MONTHLY_TXT,
decode(to_char([datecol],'Q'),1,'January - March',2,'April - June',3,'July - September',4,'October - December') || ' ' || to_char([datecol],'yyyy') AS QUARTERLY_TXT,
to_char([datecol],'yyyy') AS YEARLY_TXT
from credit_request,
credit_request_app_history,
mstr_app_status,
config_task,
credit_req_decisions_evaluator,
users,
config_team
where credit_request.request_id = credit_request_app_history.request_id
and credit_request.evaluator_id = credit_request_app_history.evaluator_id
and credit_request_app_history.start_app_status_id = mstr_app_status.status_id
and credit_request_app_history.start_task_id = config_task.task_id
and credit_request.evaluator_id = config_task.evaluator_id
and credit_request_app_history.end_dt is not null
and credit_request.request_id = credit_req_decisions_evaluator.request_id
and credit_request.evaluator_id = credit_req_decisions_evaluator.evaluator_id
and credit_request.latest_dec_ref_id = credit_req_decisions_evaluator.decision_ref_id
and credit_request_app_history.user_id = users.user_id (+)
and users.team_id = config_team.team_id (+)
and users.evaluator_id = config_team.evaluator_id (+)