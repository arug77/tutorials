select 
	MSTR_PRODUCT.product_id,	
	credit_req_decisions_evaluator.requestor_id,
	TO_EVALUATORTIME(credit_request.initiation_dt,credit_request.evaluator_id) as initiation_dt,
	CALC_REQUESTED_AMOUNT_NUM(credit_request.Request_id,CREDIT_REQUEST.Evaluator_id) AS amount_financed_num, 
	TO_EVALUATORTIME(credit_req_decisions_evaluator.SEND_DT,credit_request.evaluator_id) AS SEND_DT,
	TO_EVALUATORTIME(credit_request.AUDIT_LAST_UPDATED_DT,credit_request.evaluator_id) AS AUDIT_LAST_UPDATED_DT,
	credit_request.client_app_id,	
	credit_req_decisions_evaluator.evaluator_id,	
	credit_request.request_id,
	credit_req_decisions_evaluator.decision_id,
	mstr_evaluator_decision.decision_txt,
	credit_req_decisions_evaluator.decision_category_id,	
	credit_request.most_recent_grade_txt as grade_txt,	
	credit_req_decisions_evaluator.decisioned_by_user_id,
	MSTR_PRODUCT.Product_description_txt, 
        MSTR_PRODUCT.Product_short_name_txt, 	
	credit_req_decisions_evaluator.scorecard_score_num,
	credit_request.application_name_txt as last_name,	
	EVALUATOR_ORIGINATOR.ORIGINATOR_NAME_TXT,
	BUYING_CENTER.CENTER_NAME AS BUYING_CENTER_NAME,
	FUNDING_CENTER.CENTER_NAME AS FUNDING_CENTER_NAME,
	SERVICE_BUYING_CENTER.CENTER_NAME AS SERVICE_BUYING_CENTER_NAME,
	SUBSIDIARY_BUYING_CENTER.CENTER_NAME AS SUBSIDIARY_BUYING_CENTER_NAME,
	EVALUATOR.EVALUATOR_NAME_TXT,
	Config_division.DIVISION_NAME_TXT,
	EVALUATOR_ORIGINATOR.MARKET_TXT,
	MEGA_ORIGINATOR.ORIGINATOR_DESC_TXT,
	EVALUATOR_ORIGINATOR.ORIGINATOR_CODE_TXT,	
	CONFIG_REGION.REGION_DESC_TXT,
	credit_request.Assigned_user_id,
	CONFIG_SOURCES.SOURCE_DESC_TXT,
	Originator_address.STATE_ID,
	Originator_address.ZIPCODE_TXT,
	MEGA_ORIGINATOR.MEGA_ORIGINATOR_ID,
	evaluator_originator.region_id,
	EVALUATOR_ORIGINATOR.ORIGINATOR_ID,
	CONFIG_SOURCES.Source_id,  
	TAFEVENT_VIEW.PROVIDER,
	TAFEVENT_VIEW.VENDOR_NAME_TXT,     	
	TAFEVENT_VIEW.ORDER_PRODUCT,     	
	TAFEVENT_VIEW.RESP_RODUCT,   
	TO_CHAR(TO_EVALUATORTIME(TAFEVENT_VIEW.ORDER_DT,credit_request.evaluator_id),'DD-MON-YY') AS ORDER_DT,
	MSTR_TAF_ORDER_STATUS.TAF_ORDER_STATUS_TXT as order_status,     
	TO_CHAR(TO_EVALUATORTIME(TAFEVENT_VIEW.RESPONSE_DT,credit_request.evaluator_id),'DD-MON-YY') AS RESPONSE_DT,
	TAFEVENT_VIEW.RESP_STATUS,  
	TAFEVENT_VIEW.TRANSACTION_ID,  
	MSTR_TAF_TYPE.DESC_TXT,     
	MSTR_TAF_TYPE.TAF_TYPE_TXT,
        to_char(CREDIT_REQUEST_HOME_LOAN.REQUESTED_AMOUNT_NUM) as reqamt,
        to_char(CREDIT_REQ_DECISIONS_EVALUATOR.APPROVED_AMOUNT_NUM) as appamt,
        MSTR_TAF_PROVIDER_RESP_STATUS.RESPONSE_CODE_FULL_TXT as respdesc,
        to_char(MSTR_TAF_PROVIDER_RESP_STATUS.TAF_PROVIDER_ID) as TAF_PROVIDER_ID,        
	TRIM(TO_CHAR([datecol],'Month'))||' '||TO_CHAR([datecol],'dd'||','||' yyyy') AS DAILY_TXT,
	'Week of '||TRIM(TO_CHAR([datecol],'Month'))||' '||TO_CHAR(TRUNC([datecol],'w'),'dd'||','||' yyyy') AS WEEKLY_TXT,
	trim(to_char([datecol],'Month')) || ' ' || to_char([datecol],'yyyy') AS MONTHLY_TXT,
	decode(to_char([datecol],'Q'),1,'January - March',2,'April - June',3,'July - September',4,'October - December') || ' ' || to_char([datecol],'yyyy') AS QUARTERLY_TXT,
        to_char([datecol],'yyyy') AS YEARLY_TXT
FROM
	credit_req_decisions_evaluator,	        
	mstr_evaluator_decision,                              
	mstr_product,
	credit_request,	
	EVALUATOR_ORIGINATOR,
	CREDIT_REQUEST_ORIGINATOR,
	Config_center Buying_center,
	Config_center Funding_center,
	Config_center Service_buying_center,
	Config_center Subsidiary_buying_center,
	EVALUATOR,
	Config_division,
	MEGA_ORIGINATOR,
	CONFIG_REGION,
	CONFIG_SOURCES,	
	Originator_address,
        TAFEVENT_VIEW,
        MSTR_TAF_TYPE,
        CONFIG_VENDOR,
        CREDIT_REQUEST_HOME_LOAN,
        CONFIG_PRODUCT_PROGRAM,
        CREDIT_REQUEST_ACTIVITY,
        CONFIG_TAF_RESPONSE_STATUS,
        MSTR_TAF_ORDER_STATUS,
        MSTR_TAF_PROVIDER_RESP_STATUS
        
where        
	credit_req_decisions_evaluator.decision_id = mstr_evaluator_decision.decision_id		
	AND credit_req_decisions_evaluator.product_id = MSTR_PRODUCT.product_id 
        AND CREDIT_REQUEST.Request_id = CREDIT_REQ_DECISIONS_EVALUATOR.Request_id 
	AND CREDIT_REQUEST.Evaluator_id = CREDIT_REQ_DECISIONS_EVALUATOR.Evaluator_id 
        AND TAFEVENT_VIEW.REQUEST_ID = credit_request.REQUEST_ID  	
	AND TAFEVENT_VIEW.EVALUATOR_ID = credit_request.EVALUATOR_ID 
	AND EVALUATOR_ORIGINATOR.EVALUATOR_ID = credit_request.EVALUATOR_ID  
	and credit_request.REQUEST_ID=CREDIT_REQUEST_ORIGINATOR.REQUEST_ID(+)
	AND credit_request.EVALUATOR_ID=CREDIT_REQUEST_ORIGINATOR.EVALUATOR_ID(+)
	AND CREDIT_REQUEST_ORIGINATOR.ORIGINATOR_ID=EVALUATOR_ORIGINATOR.ORIGINATOR_ID(+)
	AND CREDIT_REQUEST_ORIGINATOR.EVALUATOR_ID=EVALUATOR_ORIGINATOR.EVALUATOR_ID(+)
	AND (credit_req_decisions_evaluator.decision_category_id <> 4 AND credit_req_decisions_evaluator.decision_category_id <> 5)        
	AND Evaluator_originator.BUYING_CENTER_ID = Buying_center.CENTER_ID(+)
	AND Evaluator_originator.FUNDING_CENTER_ID = Funding_center.CENTER_ID(+)
	AND Evaluator_originator.SERVICE_BUYING_CENTER_ID = Service_buying_center.CENTER_ID(+)
	AND Evaluator_originator.SUBSIDIARY_BUYING_CENTER_ID = Subsidiary_buying_center.CENTER_ID(+)
	AND credit_request.EVALUATOR_ID=EVALUATOR.EVALUATOR_ID
	AND Evaluator_originator.EVALUATOR_ID = Evaluator.evaluator_id
	and EVALUATOR_ORIGINATOR.EVALUATOR_ID=CONFIG_DIVISION.EVALUATOR_ID(+)
	AND EVALUATOR_ORIGINATOR.DIVISION_ID=CONFIG_DIVISION.DIVISION_ID(+) 
	AND EVALUATOR_ORIGINATOR.EVALUATOR_ID=MEGA_ORIGINATOR.EVALUATOR_ID(+)
	AND EVALUATOR_ORIGINATOR.MEGA_ORIGINATOR_ID=MEGA_ORIGINATOR.MEGA_ORIGINATOR_ID(+)	
	AND EVALUATOR_ORIGINATOR.EVALUATOR_ID=CONFIG_REGION.EVALUATOR_ID(+)
	AND EVALUATOR_ORIGINATOR.REGION_ID=CONFIG_REGION.REGION_ID(+)        
	AND credit_request.EVALUATOR_ID=CONFIG_SOURCES.EVALUATOR_ID(+)
	AND credit_request.SOURCE_ID=CONFIG_SOURCES.SOURCE_ID(+)
	and CREDIT_REQUEST_ORIGINATOR.EVALUATOR_ID=Originator_address.EVALUATOR_ID(+)
	AND CREDIT_REQUEST_ORIGINATOR.ORIGINATOR_ID=Originator_address.ORIGINATOR_ID(+)  
	AND ORIGINATOR_ADDRESS.ADDRESS_TYPE_ID = 0
        and MSTR_TAF_TYPE.TAF_TYPE_TXT = TAFEVENT_VIEW.TAF_TYPE_TXT
	and CONFIG_VENDOR.VENDOR_ID = TAFEVENT_VIEW.VENDOR_ID
	and CONFIG_VENDOR.EVALUATOR_ID=TAFEVENT_VIEW.EVALUATOR_ID 
        and CONFIG_VENDOR.VENDOR_NAME_TXT = TAFEVENT_VIEW.VENDOR_NAME_TXT
        AND TAFEVENT_VIEW.Request_id = CREDIT_REQUEST_HOME_LOAN.Request_id 
        AND TAFEVENT_VIEW.EVALUATOR_ID = CREDIT_REQUEST_HOME_LOAN.EVALUATOR_ID 
        AND CREDIT_REQUEST_HOME_LOAN.Program_id = CONFIG_PRODUCT_PROGRAM.Program_id (+)
        AND TAFEVENT_VIEW.EVALUATOR_ID = CONFIG_PRODUCT_PROGRAM.EVALUATOR_ID
        AND TAFEVENT_VIEW.Request_id = CREDIT_REQUEST_ACTIVITY.Request_id(+) 
	AND CREDIT_REQ_DECISIONS_EVALUATOR.Decision_ref_id = (SELECT MAX (CREDIT_REQ_DECISIONS_EVALUATOR.Decision_ref_id)
                                FROM Credit_req_decisions_evaluator CREDIT_REQ_DECISIONS_EVALUATOR
                               WHERE Credit_request.Request_id = CREDIT_REQ_DECISIONS_EVALUATOR.Request_id
                                 AND CREDIT_REQ_DECISIONS_EVALUATOR.Decision_category_id IN (1, 2, 3) )
	AND TAFEVENT_VIEW.EVALUATOR_ID = CONFIG_TAF_RESPONSE_STATUS.EVALUATOR_ID(+)
	AND TAFEVENT_VIEW.RESP_STATUS = CONFIG_TAF_RESPONSE_STATUS.RESPONSE_STATUS_CODE_TXT(+)
	and TAFEVENT_VIEW.ORDERSTATUS = MSTR_TAF_ORDER_STATUS.TAF_ORDER_STATUS_ID
	and CONFIG_TAF_RESPONSE_STATUS.TAF_PROVIDER_ID = MSTR_TAF_PROVIDER_RESP_STATUS.TAF_PROVIDER_ID(+)
	and CONFIG_TAF_RESPONSE_STATUS.COMPLETE_FLG = 1
	