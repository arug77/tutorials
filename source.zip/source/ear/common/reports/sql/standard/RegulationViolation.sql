select credit_request.client_app_id,
credit_request.request_id,
credit_request.evaluator_id,
credit_request.application_name_txt,
to_char(to_evaluatortime(credit_request.initiation_dt,credit_request.evaluator_id),'MM/DD/YYYY') AS initiation_dt,
evaluator_originator.originator_name_txt,
mstr_product.product_short_name_txt,
calc_total_financed_num(credit_request.request_id,credit_request.evaluator_id) AS total_financed_num,
credit_request.task_id,
mstr_evaluator_decision.decision_txt,
to_char(to_evaluatortime(credit_req_decisions_evaluator.send_dt,credit_request.evaluator_id),'MM/DD/YYYY') AS decision_dt,
mstr_booking_status.booking_status_txt,
TRIM(TO_CHAR([datecol],'Month'))||' '||TO_CHAR([datecol],'dd'||','||' yyyy') AS DAILY_TXT,
'Week of '||TRIM(TO_CHAR([datecol],'Month'))||' '||TO_CHAR(TRUNC([datecol],'w'),'dd'||','||' yyyy') AS WEEKLY_TXT,
trim(to_char([datecol],'Month')) || ' ' || to_char([datecol],'yyyy') AS MONTHLY_TXT,
decode(to_char([datecol],'Q'),1,'January - March',2,'April - June',3,'July - September',4,'October - December') || ' ' || to_char([datecol],'yyyy') AS QUARTERLY_TXT,
to_char([datecol],'yyyy') AS YEARLY_TXT
from credit_request,
credit_request_originator,
evaluator_originator,
mstr_product,
credit_req_decisions_evaluator,
mstr_evaluator_decision,
mstr_booking_status,
CREDIT_REQ_DOC_HISTORY
where credit_request.request_id = credit_request_originator.request_id (+) 
and credit_request.evaluator_id = credit_request_originator.evaluator_id (+) 
and credit_request_originator.originator_id = evaluator_originator.originator_id (+) 
and credit_request_originator.evaluator_id = evaluator_originator.evaluator_id (+) 
and credit_request.product_id = mstr_product.product_id (+) 
and credit_request.latest_dec_ref_id = credit_req_decisions_evaluator.decision_ref_id (+)
and credit_req_decisions_evaluator.decision_id = mstr_evaluator_decision.decision_id (+) 
and credit_request.booking_status_id = mstr_booking_status.booking_status_id (+)
and credit_request.request_id = credit_req_doc_history.request_id (+)
and credit_req_decisions_evaluator.decision_id in (1,2,103,108)