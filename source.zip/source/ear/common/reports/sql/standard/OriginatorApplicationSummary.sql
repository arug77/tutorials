select evaluator_originator.originator_id, 
evaluator_originator.originator_name_txt,
originator_address.city_txt,
originator_address.state_id,
config_region.region_desc_txt AS region_txt,
evaluator_originator.market_txt
from evaluator_originator,
originator_address,
config_region,
credit_request_originator,
credit_request
where evaluator_originator.originator_id = originator_address.originator_id
and evaluator_originator.evaluator_id = originator_address.evaluator_id
and evaluator_originator.region_id = config_region.region_id (+)
and evaluator_originator.evaluator_id = config_region.evaluator_id (+)
and evaluator_originator.originator_id = credit_request_originator.originator_id (+) 
and evaluator_originator.evaluator_id = credit_request_originator.evaluator_id (+)
and credit_request_originator.request_id = credit_request.request_id (+) 
and credit_request_originator.evaluator_id = credit_request.evaluator_id (+)
and evaluator_originator.active_flg = 1
and originator_address.address_type_id = 1