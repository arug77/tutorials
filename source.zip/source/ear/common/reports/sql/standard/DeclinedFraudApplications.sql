select credit_request_comment.comment_id,
credit_request.application_name_txt,
credit_request_comment.comment_dt,
credit_request.client_app_id, 
credit_request.request_id,  
to_char(get_formatted_date_notime(to_evaluatortime(credit_request.initiation_dt,credit_request.evaluator_id))) as initiation_dt,
nvl(credit_req_contr_requestor.last_name_txt,requestor.last_name_txt) as last_name_txt,
case
  when credit_req_contr_requestor.last_name_txt is not null then credit_req_contr_requestor.first_name_txt
  else requestor.first_name_txt
end as first_name_txt,
credit_request_comment.comment_txt
from 
credit_request,
credit_req_contr_requestor, 
credit_request_comment, 
requestor
where (credit_request.decision_status_id = 2 or credit_request.decision_status_id = 103)
and requestor.fraud_flg = 1
and credit_request.personal_flg = 1 
and credit_request.request_id = requestor.request_id
and credit_request.request_id = credit_req_contr_requestor.request_id (+)
And Credit_Request.Request_Id = Credit_Request_Comment.Request_Id
And Lower(Credit_Request_Comment.Comment_Txt) Like '%fraud%match%'
And Credit_Request_Comment.Comment_Id = (
    Select Max(Comment_Id) 
    From Credit_Request Cr,
    Credit_Request_Comment Crc,
    requestor r
    Where Cr.Request_Id = Credit_Request.Request_Id
    and r.request_id = credit_request.request_id
    and Cr.Request_Id = Crc.Request_Id 
    and r.Fraud_Flg = 1
	and cr.Personal_Flg = 1 
	and Lower(Crc.Comment_Txt) Like '%fraud%match%'
	and cr.request_id = r.request_id
)