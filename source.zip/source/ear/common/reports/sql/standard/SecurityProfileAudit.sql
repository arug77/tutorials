SELECT
secvw.audit_id, secvw.audit_last_updated_dt, secvw.application_name_txt, secvw.client_app_id, GET_FORMATTED_DATE(secvw.audit_id) as audit_updated_dt, 
secvw.audit_updated_user_id,
secvw.audit_user_name,
secvw.event,
secvw.evaluator_id, 
secvw.sec_profile,
secvw.func_id,
function_ancestor.function_description_txt,
evaluator.evaluator_name_txt,
TRIM(TO_CHAR([datecol],'Month'))||' '||TO_CHAR([datecol],'dd'||','||' yyyy') AS DAILY_TXT,
trim(to_char([datecol],'Month')) || ' ' || to_char([datecol],'yyyy') AS MONTHLY_TXT,
decode(to_char([datecol],'Q'),1,'January - March',2,'April - June',3,'July - September',4,'October - December') || ' ' || to_char([datecol],'yyyy') AS QUARTERLY_TXT,
to_char([datecol],'yyyy') AS YEARLY_TXT
FROM
function_ancestor, users, xref_evaluator_profiles, evaluator, sec_prof_aud_view secvw where secvw.event is not null AND secvw.evaluator_id = evaluator.evaluator_id AND secvw.func_id = function_ancestor.function_id
AND upper(secvw.sec_profile) = upper(xref_evaluator_profiles.profile_id) AND secvw.evaluator_id = xref_evaluator_profiles.evaluator_id AND upper(secvw.audit_updated_user_id) = upper(users.user_id(+)) 

