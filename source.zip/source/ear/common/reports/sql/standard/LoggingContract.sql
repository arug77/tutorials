select credit_request.request_id,
credit_request.evaluator_id,
credit_request.client_app_id,
credit_req_decisions_evaluator.decision_id,
mstr_evaluator_decision.decision_txt,
evaluator_originator.originator_name_txt,
mstr_product.product_short_name_txt,
evaluator_originator.sales_rep_txt,
to_char(credit_request_activity.audit_last_updated_dt,'MM/DD/YYYY') as audit_last_updated_dt,
credit_request.application_name_txt,
to_char(credit_request.initiation_dt,'MM/DD/YYYY') as initiation_dt,
credit_req_decisions_evaluator.approved_amount_num,
mstr_app_status.status_code as status_code_txt,
C.center_name as center_name_txt
from
credit_request,
credit_request_activity,
credit_req_decisions_evaluator,
evaluator_originator,
mstr_product,
mstr_evaluator_decision,
credit_request_originator,
mstr_app_status,
config_center C
where credit_request.request_id = credit_request_activity.request_id
and credit_request.evaluator_id = credit_request_originator.evaluator_id
and credit_request.request_id = credit_request_originator.request_id
and credit_request.evaluator_id = evaluator_originator.evaluator_id
and credit_request_originator.originator_id = evaluator_originator.originator_id
and credit_request.request_id = credit_req_decisions_evaluator.request_id
and credit_request.evaluator_id = credit_req_decisions_evaluator.evaluator_id
and credit_request.latest_dec_ref_id = credit_req_decisions_evaluator.decision_ref_id
and credit_req_decisions_evaluator.decision_id = mstr_evaluator_decision.decision_id
and credit_request.product_id = mstr_product.product_id
and credit_request.app_status_id = mstr_app_status.status_id
and credit_req_decisions_evaluator.decision_id in (3,1,102)
and credit_request_activity.activity_id = 10
and credit_request_activity.activity_status_id = 3
and C.center_id(+)=credit_request_originator.buying_center_id
and C.evaluator_id(+)=credit_request_originator.evaluator_id


