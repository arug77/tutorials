select credit_request.client_app_id,
credit_request.request_id,
credit_request.evaluator_id,
credit_request.application_name_txt,
credit_req_decisions_evaluator.approved_grade_txt AS grade,
credit_req_decisions_evaluator.approved_grade_txt,
credit_request_journal.created_user_id,
credit_req_decisions_evaluator.decisioned_by_user_id,
nvl(credit_req_decisions_evaluator.approved_amount_num,calc_requested_amount_num(credit_request.request_id,credit_request.evaluator_id)) AS amount_financed_num,
credit_req_decisions_evaluator.bureau_id,
mstr_evaluator_decision.decision_txt, 
credit_req_decisions_evaluator.decision_ref_id,
to_char(to_evaluatortime(credit_req_decisions_evaluator.send_dt,credit_request.evaluator_id),'MM/DD/YYYY HH12:MI:SS AM') AS decision_dt, 
TRIM(TO_CHAR([datecol],'Month'))||' '||TO_CHAR([datecol],'dd'||','||' yyyy') AS DAILY_TXT,
'Week of '||TRIM(TO_CHAR([datecol],'Month'))||' '||TO_CHAR(TRUNC([datecol],'w'),'dd'||','||' yyyy') AS WEEKLY_TXT,
trim(to_char([datecol],'Month')) || ' ' || to_char([datecol],'yyyy') AS MONTHLY_TXT,
decode(to_char([datecol],'Q'),1,'January - March',2,'April - June',3,'July - September',4,'October - December') || ' ' || to_char([datecol],'yyyy') AS QUARTERLY_TXT,
to_char([datecol],'yyyy') AS YEARLY_TXT
from credit_request,
credit_req_decisions_evaluator, 
credit_request_journal,
mstr_evaluator_decision
where credit_request.latest_dec_ref_id = credit_req_decisions_evaluator.decision_ref_id
and credit_req_decisions_evaluator.decision_id = mstr_evaluator_decision.decision_id (+)
and credit_request.request_id = credit_request_journal.request_id (+)
and credit_request_journal.journal_event_id in (2,74)