select credit_request.request_id,
credit_request.evaluator_id,
com.comment_id,
upper(credit_request.application_name_txt) as application_name_txt,
credit_request.client_app_id, 
get_requestor_id(com.comment_txt) as requestor_id, 
get_requestor_type(com.comment_txt) as requestor_type_txt,
al.alert_id, 
get_rego_name(credit_request.request_id,credit_request.evaluator_id,al.alert_id,REGEXP_REPLACE(GET_TOKEN(com.comment_txt,5,' '),'[0-9]','')) as rego_name, 
get_rego_taxid(credit_request.request_id,credit_request.evaluator_id,al.alert_id,REGEXP_REPLACE(GET_TOKEN(com.comment_txt,5,' '),'[0-9]','')) as rego_taxid, 
al.comment_txt,
rownum as row_id,
TRIM(TO_CHAR([datecol],'Month'))||' '||TO_CHAR([datecol],'dd'||','||' yyyy') AS DAILY_TXT,
'Week of '||TRIM(TO_CHAR([datecol],'Month'))||' '||TO_CHAR(TRUNC([datecol],'w'),'dd'||','||' yyyy') AS WEEKLY_TXT,
trim(to_char([datecol],'Month')) || ' ' || to_char([datecol],'yyyy') AS MONTHLY_TXT,
decode(to_char([datecol],'Q'),1,'January - March',2,'April - June',3,'July - September',4,'October - December') || ' ' || to_char([datecol],'yyyy') AS QUARTERLY_TXT,
to_char([datecol],'yyyy') AS YEARLY_TXT
from credit_request, cred_req_com_view com, alert al
where al.evaluator_id = credit_request.evaluator_id 
and credit_request.request_id = com.request_id 
and credit_request.request_id = com.request_id 
and com.comment_event_id = 51 
and to_number(GET_TOKEN(com.comment_txt,4,' '))= al.alert_id 
and al.evaluator_id = credit_request.evaluator_id 
and al.alert_category_id = 2
