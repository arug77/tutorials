select credit_request.client_app_id, 
credit_request.application_name_txt, 
evaluator_originator.originator_name_txt, 
mstr_product.product_short_name_txt, 
crd_req_finance_program_view.finance_program_txt, 
nvl(credit_req_contract.actual_closing_dt,credit_request_closing.requested_closing_dt) AS requested_closing_dt, 
credit_request_closing.closing_time_txt, 
credit_request_closing.closing_location_txt, 
credit_request_closing.contact_txt, 
credit_request_closing.phone_number_txt,
(to_char(requested_closing_dt,'MM/DD/YYYY')||' '||to_char(to_date(closing_time_txt,'hh:mi AM'),'hh24:mi')) AS closing_dt_time_txt, 
TRIM(TO_CHAR([datecol],'Month'))||' '||TO_CHAR([datecol],'dd'||','||' yyyy') AS DAILY_TXT, 
'Week of '||TRIM(TO_CHAR([datecol],'Month'))||' '||TO_CHAR(TRUNC([datecol],'w'),'dd'||','||' yyyy') AS WEEKLY_TXT, 
trim(to_char([datecol],'Month')) || ' ' || to_char([datecol],'yyyy') AS MONTHLY_TXT, 
decode(to_char([datecol],'Q'),1,'January - March',2,'April - June',3,'July - September',4,'October - December') || ' ' || to_char([datecol],'yyyy') AS QUARTERLY_TXT, 
to_char([datecol],'yyyy') AS YEARLY_TXT 
from credit_request,
credit_request_originator,
evaluator_originator,
mstr_product,
crd_req_finance_program_view,
credit_request_closing,
credit_req_contract
where credit_request.request_id = credit_request_originator.request_id (+) 
and credit_request.evaluator_id = credit_request_originator.evaluator_id (+) 
and credit_request_originator.originator_id = evaluator_originator.originator_id (+) 
and credit_request_originator.evaluator_id = evaluator_originator.evaluator_id (+)
and credit_request.product_id = mstr_product.product_id (+)
and credit_request.request_id = credit_request_closing.request_id (+)
and credit_request.evaluator_id = credit_request_closing.evaluator_id (+)
and credit_request_closing.request_id = crd_req_finance_program_view.request_id (+)
and credit_request_closing.evaluator_id = crd_req_finance_program_view.evaluator_id (+) 
and credit_request_closing.finance_id = crd_req_finance_program_view.finance_id (+)
and credit_request.request_id = credit_req_contract.request_id (+)
and (mstr_product.product_type_id = 2 or mstr_product.product_id = 17)