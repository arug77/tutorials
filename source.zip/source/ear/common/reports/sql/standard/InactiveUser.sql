select users.user_id,
evaluator.evaluator_name_txt, 
get_user_name(users.user_id) as user_name,
GET_FORMATTED_DATE_DT([datecol]) as login_date,
users.active_flg,
GET_FORMATTED_DATE_DT([datesetup]) as user_setup_date,
GET_FORMATTED_DATE_DT([dateinact]) as last_inactivation_date,
GET_USER_STATUS(users.user_id) as user_status
from users,
evaluator
where users.evaluator_id = evaluator.evaluator_id
