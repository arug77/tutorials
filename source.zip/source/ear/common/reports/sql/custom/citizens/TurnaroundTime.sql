select 1 as defaultsort,
credit_request.client_app_id,
credit_request.request_id,
credit_request.evaluator_id,
credit_request.application_name_txt,
credit_request_originator.buying_center_id,
to_char(to_evaluatortime(credit_request.initiation_dt,credit_request.evaluator_id),'MM/DD/YYYY HH12:MI:SS AM') AS initiation_dt,
evaluator_originator.originator_name_txt,
credit_req_decisions_evaluator.decisioned_by_user_id,
config_center.state_id,
credit_request.most_recent_grade_txt,
case when (credit_req_decisions_evaluator.scorecard_score_num is not null) then credit_req_decisions_evaluator.scorecard_score_num else 0 end as scorecard_score_num,
case 
when (credit_req_decisions_evaluator.decision_id = 3 or credit_req_decisions_evaluator.decision_id = 1 or credit_req_decisions_evaluator.decision_id = 102) then credit_req_decisions_evaluator.approved_amount_num
else calc_requested_amount_num(credit_req_decisions_evaluator.request_id,credit_request.evaluator_id) 
end AS loan_amount_num,
mstr_evaluator_decision.decision_txt,
to_char(to_evaluatortime(credit_req_decisions_evaluator.send_dt,credit_request.evaluator_id),'MM/DD/YYYY HH12:MI:SS AM') AS decision_dt
from credit_request,
evaluator_originator,
config_center,
credit_request_originator,
credit_req_decisions_evaluator,
mstr_evaluator_decision
where credit_request.request_id = credit_request_originator.request_id (+) 
and credit_request.evaluator_id = credit_request_originator.evaluator_id (+) 
and credit_request_originator.originator_id = evaluator_originator.originator_id (+) 
and credit_request_originator.evaluator_id = evaluator_originator.evaluator_id (+)
and credit_request.latest_dec_ref_id = credit_req_decisions_evaluator.decision_ref_id (+)
and credit_request_originator.evaluator_id = config_center.evaluator_id (+)
and credit_request_originator.buying_center_id = config_center.center_id (+)
and credit_req_decisions_evaluator.decision_id = mstr_evaluator_decision.decision_id (+)
and credit_req_decisions_evaluator.decision_id in (1,2,3,102,103)