select credit_request.client_app_id,
credit_request.request_id, 
credit_request.evaluator_id, 
credit_request.application_name_txt, 
evaluator_originator.originator_name_txt, 
credit_request.most_recent_grade_txt, 
credit_req_decisions_evaluator.decisioned_by_user_id, 
mstr_evaluator_decision.decision_txt, 
mstr_evaluator_decision.decision_display_txt,
credit_request.product_id,
GET_APP_NUM('[datestart]','[dateend]',[datetype],credit_request.evaluator_id) as apps_count,
GET_OVERRIDE_TYPE(credit_req_decisions_evaluator.decision_ref_id,credit_request.evaluator_id,credit_request.product_id) as override_type,
credit_req_decisions_evaluator.decision_ref_id,
credit_req_decisions_evaluator.scorecard_score_num,
case
    when (credit_req_decisions_evaluator.decision_id in (1,3)) then nvl(credit_req_decisions_evaluator.approved_amount_num,0)
    else calc_requested_amount_num(credit_request.request_id,credit_request.evaluator_id)
end as loan_amount, 
config_region.region_desc_txt 
from credit_request,
config_region,
credit_request_originator,
evaluator_originator,
credit_req_decisions_evaluator,
mstr_evaluator_decision,
credit_req_decision_reasons
where credit_request.request_id = credit_request_originator.request_id (+) 
and credit_request.evaluator_id = credit_request_originator.evaluator_id (+) 
and credit_request_originator.originator_id = evaluator_originator.originator_id (+) 
and credit_request_originator.evaluator_id = evaluator_originator.evaluator_id (+) 
and credit_request.latest_dec_ref_id = credit_req_decisions_evaluator.decision_ref_id (+)
and credit_req_decisions_evaluator.decision_id = mstr_evaluator_decision.decision_id (+) 
and credit_request.latest_dec_ref_id = credit_req_decision_reasons.decision_ref_id
and evaluator_originator.region_id = config_region.region_id (+)
and evaluator_originator.evaluator_id = config_region.evaluator_id (+)
and credit_req_decision_reasons.reason_type_id = 2
and credit_req_decisions_evaluator.decision_id in (1,2,3)