SELECT
credit_request.request_id,
credit_request.evaluator_id,
credit_request.client_app_id,
credit_request.appseqno,
evaluator_originator.originator_name_txt,
evaluator_originator.originator_code_txt,
evaluator.evaluator_name_txt, 
config_region.region_desc_txt,
case when (credit_request.paper_contract_started_flg=0 and credit_request.convert_to_paper_flg=0) then 'Electronic' else 'Paper' end AS contract_type_txt,
nvl(credit_req_contr_fin.lender_gap_num,0) as gap_num,
case when credit_req_contr_fin.vsi_fee_num is null then 0 else credit_req_contr_fin.vsi_fee_num end as vsi_num,
case when credit_req_contr_fin.amount_financed_num is null then 0 else credit_req_contr_fin.amount_financed_num end as amount_financed_num,
case when credit_req_contr_fin.rate_num is null then 0 else credit_req_contr_fin.rate_num end as rate_num,
case when credit_req_contr_fin.misc_fee_num is null then 0 else credit_req_contr_fin.misc_fee_num end as misc_fee_num,
case when credit_req_contr_fin.doc_stamps_fee_num is null then 0 else credit_req_contr_fin.doc_stamps_fee_num end as doc_stamps_fee_num,
case when credit_req_contr_fin.prep_finance_chg_num is null then 0 else credit_req_contr_fin.prep_finance_chg_num end as prep_finance_chg_num,
case when max_deler_reserve_view.adj_reserve_amt_num is null then 0 else max_deler_reserve_view.adj_reserve_amt_num end as adj_reserve_amt_num,
max_deler_reserve_view.adj_reserve_method_txt,
case when credit_request.personal_flg=1 then (nvl(credit_req_contr_requestor.last_name_txt,requestor.last_name_txt)||','||' '||nvl(credit_req_contr_requestor.first_name_txt,requestor.first_name_txt))   else requestor_business.business_name_txt end as applicant_name_txt 
FROM credit_request,
evaluator_originator,
evaluator,
requestor,
config_region,
config_mpe,
credit_req_contr_mpe,
credit_req_contr_fin,
credit_request_originator,
mstr_booking_status,
credit_req_decisions_evaluator,
max_deler_reserve_view,
credit_req_contr_requestor,
requestor_business
WHERE credit_request.request_id = credit_request_originator.request_id (+)
and credit_request.evaluator_id = credit_request_originator.evaluator_id (+)
and credit_request.evaluator_id = evaluator.evaluator_id
and credit_request.latest_final_dec_ref_id = credit_req_decisions_evaluator.decision_ref_id (+)
and credit_request_originator.originator_id = evaluator_originator.originator_id (+)
and credit_request_originator.evaluator_id = evaluator_originator.evaluator_id (+)
and credit_request.request_id = credit_req_contr_requestor.request_id (+)
and credit_request.evaluator_id = credit_req_contr_requestor.evaluator_id (+)
and credit_req_contr_requestor.requestor_type_id (+) = 0
and credit_request.request_id = max_deler_reserve_view.request_id (+)
and credit_request.request_id = credit_req_contr_mpe.request_id (+)
and evaluator_originator.region_id = config_region.region_id (+) 
and evaluator_originator.evaluator_id = config_region.evaluator_id (+) 
and credit_request.request_id = credit_req_contr_fin.request_id (+)
and credit_request.booking_status_id = mstr_booking_status.booking_status_id (+)
and credit_request.request_id = requestor.request_id (+)
and requestor.requestor_type_id (+) = 0
and credit_request.request_id = requestor_business.request_id (+)
and requestor_business.requestor_type_id (+) = 3
and credit_req_contr_mpe.status_txt = 'GENERATED'
and credit_req_contr_mpe.mpe_id = config_mpe.mpe_id (+)
and credit_req_contr_mpe.evaluator_id = config_mpe.evaluator_id (+)
and config_mpe.mpe_file_desc_txt = 'AFACH'
and (credit_request.booking_status_id = '2' OR credit_request.booking_status_id = '3')