select CASE WHEN crde.concurrence_user_id is null THEN crde.decisioned_by_user_id ELSE crde.concurrence_user_id END as analyst, crde.concurrence_user_id, 
crde.decisioned_by_user_id, crde.decision_id, crde.decision_category_id, 
cr.request_id, crde.decision_ref_id, evaluator.evaluator_name_txt 
from credit_req_decisions_evaluator crde, credit_request cr, evaluator 
where cr.latest_dec_ref_id = crde.decision_ref_id (+)
and crde.decision_id in(1,2,3)
and crde.decision_category_id in(2,3) 
and get_credit_limit(CASE WHEN crde.concurrence_user_id is null THEN crde.decisioned_by_user_id ELSE crde.concurrence_user_id END) > 0 
AND cr.evaluator_id = evaluator.evaluator_id