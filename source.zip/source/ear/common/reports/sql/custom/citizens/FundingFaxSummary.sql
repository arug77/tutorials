select distinct(credit_request.client_app_id) as client_app_id,
	credit_request.request_id,
	(credit_req_contr_requestor.first_name_txt||' '||credit_req_contr_requestor.MIDDLE_NAME_TXT||' '||credit_req_contr_requestor.LAST_NAME_TXT||' '||credit_req_contr_requestor.SUFFIX_ID) as application_name_txt,
	max_deler_reserve_view.adj_reserve_amt_num,
	GET_FUNDING_AMOUNT_NUM(credit_request.request_id,credit_request.task_group_id) as amount_financed_num, 
	evaluator_originator.ach_fax_no_txt as fax_num,
	CASE 
	WHEN ORIGINATOR_ADDRESS.PHONE_EXTENSION_TXT IS NULL THEN ORIGINATOR_ADDRESS.PHONE_NUMBER_TXT
	ELSE (ORIGINATOR_ADDRESS.PHONE_NUMBER_TXT||'-'||ORIGINATOR_ADDRESS.PHONE_EXTENSION_TXT) 
	END AS dealer_phone_num,
	ORIGINATOR_ADDRESS.address1_txt, 
	ORIGINATOR_ADDRESS.city_txt, 
	ORIGINATOR_ADDRESS.state_id, 
	ORIGINATOR_ADDRESS.zipcode_txt, 
	credit_request_funding.NET_PROCEEDS_NUM as proceeds_num,
	evaluator_originator.originator_name_txt, 
	evaluator_originator.originator_id, 
	evaluator_originator.originator_code_txt, 
	evaluator_originator.contact_txt, 
	evaluator.evaluator_name_txt,
	credit_request.evaluator_id,
	TRIM(TO_CHAR([datecol],'Month'))||' '||TO_CHAR([datecol],'dd'||','||' yyyy') AS DAILY_TXT, 
	'Week of '||TRIM(TO_CHAR([datecol],'Month'))||' '||TO_CHAR(TRUNC([datecol],'w'),'dd'||','||' yyyy') AS WEEKLY_TXT, 
	trim(to_char([datecol],'Month')) || ' ' || to_char([datecol],'yyyy') AS MONTHLY_TXT, 
	decode(to_char([datecol],'Q'),1,'January - March',2,'April - June',3,'July - September',4,'October - December') || ' ' || to_char([datecol],'yyyy') AS QUARTERLY_TXT, 
	to_char([datecol],'yyyy') AS YEARLY_TXT 
from credit_request,
     credit_req_contr_requestor, 
     max_deler_reserve_view,
     credit_request_originator,
     ORIGINATOR_ADDRESS,
     credit_request_funding,
     evaluator_originator,
	 evaluator,
	 credit_req_contr_mpe,
	 config_mpe
where credit_request.request_id = credit_req_contr_requestor.request_id (+) 
	and credit_request.evaluator_id = credit_req_contr_requestor.evaluator_id (+)
	and credit_request.request_id = credit_req_contr_mpe.request_id (+)
	and credit_request.evaluator_id = evaluator.evaluator_id (+)
	and credit_request.request_id = max_deler_reserve_view.request_id (+)
	and credit_request.request_id = credit_request_funding.request_id (+)
	and credit_request.request_id = credit_request_originator.request_id (+) 
	and credit_request.evaluator_id = credit_request_originator.evaluator_id (+)
	and credit_request_originator.originator_id = evaluator_originator.originator_id (+) 
	and credit_request_originator.evaluator_id = evaluator_originator.evaluator_id (+)
	and credit_request_originator.evaluator_id = ORIGINATOR_ADDRESS.evaluator_id (+)
	and credit_request_originator.ORIGINATOR_ID = ORIGINATOR_ADDRESS.ORIGINATOR_ID (+)
	and ORIGINATOR_ADDRESS.ADDRESS_TYPE_ID (+) = 0
	and credit_req_contr_mpe.status_txt = 'MOVED_TO_MPE_FILE'
	and credit_req_contr_mpe.mpe_id = config_mpe.mpe_id (+)
	and credit_req_contr_mpe.evaluator_id = config_mpe.evaluator_id (+)
	and config_mpe.mpe_file_desc_txt = 'AFACH'
	and (credit_request.booking_status_id = '2' OR credit_request.booking_status_id = '3')