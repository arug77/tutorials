SELECT 
1 as defaultSort,
credit_request.request_id,
credit_request.evaluator_id,
credit_request.client_app_id,
evaluator_originator.originator_id,
evaluator_originator.originator_code_txt,
evaluator_originator.originator_name_txt,
evaluator.evaluator_name_txt, 
case 
when (credit_request.econtract_flg=1) 
then 'Electronic' 
else 'Paper' 
end AS contract_type_txt,
credit_request.application_name_txt,
case 
when (credit_req_contr_fin.amount_financed_num is null) 
then 0 
else credit_req_contr_fin.amount_financed_num 
end AS amount_financed_num,
case 
when (credit_request_funding.net_proceeds_num is null) 
then 0 
else credit_request_funding.net_proceeds_num 
end AS net_proceeds_num,
mstr_booking_status.booking_status_txt,
credit_request.funding_dt
FROM credit_request,
evaluator_originator,
credit_request_originator,
credit_req_contr_mpe,
config_mpe,
evaluator,
credit_request_funding,
credit_req_contr_fin,
mstr_booking_status
WHERE credit_request.evaluator_id = evaluator.evaluator_id
and credit_request.evaluator_id = evaluator_originator.evaluator_id
and credit_request.request_id = credit_request_originator.request_id
and credit_request.evaluator_id = credit_request_originator.evaluator_id
and credit_request_originator.originator_id = evaluator_originator.originator_id
and credit_request.request_id = credit_req_contr_fin.request_id (+)
and credit_request.request_id = credit_request_funding.request_id (+)
and credit_request.booking_status_id = mstr_booking_status.booking_status_id (+)
and (credit_request.booking_status_id = 2 OR credit_request.booking_status_id = 3)
and credit_request.request_id = credit_req_contr_mpe.request_id (+)
and credit_req_contr_mpe.status_txt = 'GENERATED'
and credit_req_contr_mpe.mpe_id = config_mpe.mpe_id
and config_mpe.mpe_file_desc_txt = 'AFACH'
and config_mpe.evaluator_id = credit_request.evaluator_id