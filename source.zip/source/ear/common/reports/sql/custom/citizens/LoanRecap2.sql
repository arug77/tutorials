SELECT 
credit_request.request_id,
credit_request.evaluator_id,
credit_request.client_app_id,
credit_request.application_name_txt,
credit_request.appseqno,
evaluator_originator.originator_name_txt,
evaluator.evaluator_name_txt as evaluator_name_txt,
case 
when (credit_request.paper_contract_started_flg=0 and credit_request.convert_to_paper_flg=0) 
then 'Electronic' 
else 'Paper' 
end AS contract_type_txt,
CASE 
WHEN credit_req_contr_fin.vsi_fee_num is null then 0 
else credit_req_contr_fin.vsi_fee_num
END as vsi_fee_num,
nvl(credit_req_contr_fin.lender_gap_num,0) as gap_num,
max_deler_reserve_view.adj_reserve_amt_num,
CASE 
WHEN credit_req_contr_fin.amount_financed_num is null then 0 
else credit_req_contr_fin.amount_financed_num
END as amount_financed_num,
CASE 
WHEN credit_req_contr_fin.doc_stamps_fee_num is null then 0 
else credit_req_contr_fin.doc_stamps_fee_num
END as doc_stamps_fee_num,
CASE 
WHEN credit_req_contr_fin.prep_finance_chg_num is null then 0 
else credit_req_contr_fin.prep_finance_chg_num
END as prep_finance_charge_num,
config_region.region_desc_txt,
mstr_booking_status.booking_status_txt,
[datecol] AS mpe_data_created_dt,
originator_address.state_id as orig_state_id
FROM credit_request,
evaluator,
evaluator_originator,
originator_address,
credit_request_originator,
max_deler_reserve_view,
config_region,
credit_req_contr_mpe,
config_mpe,
credit_req_contr_fin,
mstr_booking_status
WHERE  credit_request.request_id = credit_request_originator.request_id (+)
and credit_request.evaluator_id = credit_request_originator.evaluator_id (+)
and credit_request.evaluator_id = evaluator.evaluator_id
and credit_request_originator.evaluator_id = evaluator_originator.evaluator_id (+)
and credit_request_originator.originator_id = evaluator_originator.originator_id (+)
and credit_request.request_id = max_deler_reserve_view.request_id (+)
and credit_request.request_id = credit_req_contr_mpe.request_id (+)
and credit_request.request_id = credit_req_contr_fin.request_id (+)
and evaluator_originator.region_id = config_region.region_id (+)
and evaluator_originator.evaluator_id = config_region.evaluator_id (+)
and credit_request.booking_status_id = mstr_booking_status.booking_status_id (+)
and credit_req_contr_mpe.status_txt = 'GENERATED'
and credit_req_contr_mpe.mpe_id = config_mpe.mpe_id (+)
and credit_req_contr_mpe.evaluator_id = config_mpe.evaluator_id (+)
and config_mpe.mpe_file_desc_txt = 'AFACH'
and (credit_request.booking_status_id = '2' OR credit_request.booking_status_id = '3')
and originator_address.evaluator_id (+) = evaluator_originator.evaluator_id
and originator_address.originator_id (+) = evaluator_originator.originator_id
and (originator_address.address_type_id = 0 or originator_address.address_type_id is null)