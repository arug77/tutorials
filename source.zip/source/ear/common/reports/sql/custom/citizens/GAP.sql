SELECT 
credit_request.request_id,
credit_request.evaluator_id,
credit_request.client_app_id,
evaluator_originator.originator_name_txt,
evaluator_originator.originator_code_txt,
credit_req_citizens_setup.loan_acct_num_txt,
evaluator.evaluator_name_txt, 
case 
when (credit_request.econtract_flg=1) 
then 'Electronic' 
else 'Paper' 
end AS contract_type_txt,
CASE 
WHEN credit_req_contr_fin.lender_gap_num is null then 0 
else credit_req_contr_fin.lender_gap_num
END as gap_num,
config_region.region_desc_txt,
mstr_booking_status.booking_status_txt,
to_char(credit_req_contr_mpe.mpe_data_created_dt,'MM/DD/YYYY HH:MI:SS AM') AS created_dt
FROM credit_request,
evaluator_originator,
evaluator,
config_region,
config_mpe,
credit_req_citizens_setup,
credit_req_contr_mpe,
credit_req_contr_fin,
credit_request_originator,
mstr_booking_status,
credit_req_decisions_evaluator
WHERE credit_request.request_id = credit_request_originator.request_id
and credit_request.evaluator_id = credit_request_originator.evaluator_id
and credit_request.evaluator_id = evaluator.evaluator_id
and credit_request.request_id = credit_req_decisions_evaluator.request_id
and credit_request_originator.originator_id = evaluator_originator.originator_id
and credit_request.evaluator_id = evaluator_originator.evaluator_id
and credit_request.request_id = credit_req_contr_mpe.request_id (+)
and evaluator_originator.region_id = config_region.region_id (+) 
and evaluator_originator.evaluator_id = config_region.evaluator_id (+) 
and credit_request.request_id = credit_req_contr_fin.request_id (+)
and credit_request.booking_status_id = mstr_booking_status.booking_status_id (+)
and credit_request.request_id = credit_req_citizens_setup.request_id 
and credit_request.request_id = credit_req_contr_mpe.request_id (+)
and credit_req_contr_mpe.evaluator_id = credit_request.evaluator_id
and credit_req_contr_mpe.status_txt = 'GENERATED'
and credit_req_contr_mpe.mpe_id = config_mpe.mpe_id
and config_mpe.mpe_file_desc_txt = 'AFACH'
and config_mpe.evaluator_id = credit_request.evaluator_id
and credit_request.booking_status_id = mstr_booking_status.booking_status_id (+)
and (mstr_booking_status.booking_status_txt = 'BOOKED' OR mstr_booking_status.booking_status_txt = 'BOOKEX')
    