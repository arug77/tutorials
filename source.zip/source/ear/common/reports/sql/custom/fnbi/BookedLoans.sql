select
credit_request.request_id,
credit_request.client_app_id,
credit_request.appseqno,
to_evaluatortime(credit_request.initiation_dt,credit_request.evaluator_id) as application_date,
credit_req_verify_data.value_txt as miser_loan_num,
CASE
WHEN (credit_request.personal_flg = 1)
THEN (get_appli_lastname(credit_request.request_id,credit_request.evaluator_id,0))
ELSE (get_appli_lastname(credit_request.request_id,credit_request.evaluator_id,3))
END AS applicant_lst_name_txt,
(get_appli_lastname(credit_request.request_id,credit_request.evaluator_id,1)) as co_applicant_last_name_txt,
evaluator_originator.originator_code_txt as dealer_num,
evaluator_originator.originator_name_txt as dealer_name,
originator_address.state_id as dealer_state,
config_region.region_id,
(get_applicant_bureau_score(credit_request.request_id,0)) as applicant_credit_score,
(get_applicant_bureau_score(credit_request.request_id,1)) as co_applicant_credit_score,
to_evaluatortime(contract_logged_activity_tbl.audit_last_updated_dt,credit_request.evaluator_id) as contract_logged_date,
to_evaluatortime(booked_activity_tbl.audit_last_updated_dt,credit_request.evaluator_id) as contract_booked_date,
get_ptidti(credit_request.request_id,'LTV') as ltv_val,
get_ptidti(credit_request.request_id,'DTI') as dti_val,
get_ptidti(credit_request.request_id,'PTI') as pti_val,
max_deler_reserve_view.percent_to_dealer_num,
max_deler_reserve_view.amt_to_dealer_num,
max_deler_reserve_view.dealer_buydown_amt_num,
max_deler_reserve_view.adj_approve_buyrate as approved_buy_rate_num,
credit_req_contr_fin.rate_num as cust_rate,
to_evaluatortime(credit_req_contr_fin.first_payment_dt,credit_request.evaluator_id) as first_payment_date,
credit_req_contr_fin.term_num,
credit_req_contr_fin.finance_charge_num,
credit_req_contr_fin.account_access_type_id as account_type,
nvl(nvl(credit_req_contr_fin.rate_num,0) - nvl(max_deler_reserve_view.adj_approve_buyrate,0),0) as mark_up,
get_auto_info(credit_request.request_id,'new_used_flg') as new_used_flg,
get_auto_info(credit_request.request_id,'model_txt') as vehicle_model,
get_auto_info(credit_request.request_id,'year_num') as vehicle_year,
get_auto_info(credit_request.request_id,'mstr_auto_make.auto_make_description_txt') as vehicle_make, 
config_region.region_desc_txt
from
credit_request,
credit_req_verify_data,
config_verify_fields,
requestor,
credit_request_originator,
evaluator_originator,
originator_address,
config_region,
credit_request_activity contract_logged_activity_tbl,
credit_request_activity booked_activity_tbl,
max_deler_reserve_view,
credit_req_contr_fin
where credit_request.request_id = requestor.request_id (+)
and requestor.requestor_type_id (+) = 0
and credit_request.request_id = credit_req_verify_data.request_id (+)
and credit_request.evaluator_id = credit_req_verify_data.evaluator_id (+)
and credit_req_verify_data.field_id (+) = 31223
and credit_req_verify_data.profile_id  = config_verify_fields.profile_id (+)
and credit_req_verify_data.category_id  = config_verify_fields.category_id (+)
and credit_req_verify_data.field_id = config_verify_fields.field_id (+)
and credit_req_verify_data.evaluator_id  = config_verify_fields.evaluator_id (+)
and credit_request.request_id = credit_request_originator.request_id (+) 
and credit_request.evaluator_id = credit_request_originator.evaluator_id (+)
and credit_request_originator.originator_id = evaluator_originator.originator_id (+) 
and credit_request_originator.evaluator_id = evaluator_originator.evaluator_id (+) 
and credit_request_originator.evaluator_id = originator_address.evaluator_id (+)
and credit_request_originator.originator_id = originator_address.originator_id (+)
and originator_address.address_type_id (+) = 0
and evaluator_originator.region_id = config_region.region_id (+) 
and evaluator_originator.evaluator_id = config_region.evaluator_id (+) 
and credit_request.request_id = contract_logged_activity_tbl.request_id (+)
and contract_logged_activity_tbl.activity_id (+) = 10 
and contract_logged_activity_tbl.task_group_id (+) = upper('contractadmin')
and credit_request.request_id = booked_activity_tbl.request_id (+)
and booked_activity_tbl.activity_id (+) = 23
and booked_activity_tbl.task_group_id (+) = upper('contractadmin')
and credit_request.request_id = max_deler_reserve_view.request_id (+)
and credit_request.request_id = credit_req_contr_fin.request_id (+)
and credit_request.booking_status_id in (2,3)
