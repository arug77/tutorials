select credit_request.client_app_id,
credit_request.request_id,
credit_request.application_name_txt,
GET_REQSTOR_LNAME(credit_request.request_id,credit_request.evaluator_id) as last_name,
evaluator_originator.originator_code_txt,
evaluator_originator.dba_name_txt,
evaluator_originator.sales_rep_txt,
to_date(to_char(to_evaluatortime(credit_request_activity.audit_last_updated_dt,credit_request.evaluator_id),'mm/dd/yyyy'),'mm/dd/yyyy') AS logged_dt,
originator_address.state_id as state_id,
nvl2(evapp_interface.dealer_incentive_num,'Yes','No') AS dealer_incentive
from credit_request,
evaluator_originator,
credit_request_originator,
credit_request_activity,
originator_address, 
evapp_interface 
where credit_request.request_id = credit_request_activity.request_id (+) 
and credit_request_activity.activity_id (+) = 10 
and credit_request_activity.activity_status_id (+) = 3
and credit_request.booking_status_id (+) = 1 
and credit_request.request_id = credit_request_originator.request_id (+) 
and credit_request.evaluator_id = credit_request_originator.evaluator_id (+)		
and credit_request_originator.originator_id = evaluator_originator.originator_id (+) 
and credit_request_originator.evaluator_id = evaluator_originator.evaluator_id (+) 
and evaluator_originator.originator_id = originator_address.originator_id (+) 
and evaluator_originator.evaluator_id = originator_address.evaluator_id (+) 
and credit_request.appseqno = evapp_interface.appseqno (+) 
and originator_address.address_type_id (+) = 0 