select credit_request.request_id, 
credit_request.client_app_id,
to_evaluatortime(credit_request_activity.audit_last_updated_dt,credit_request.evaluator_id) as logged_dt,
CASE
WHEN (credit_request.personal_flg = 1)
THEN (get_appli_lastname(credit_request.request_id,credit_request.evaluator_id,0))
ELSE (get_appli_lastname(credit_request.request_id,credit_request.evaluator_id,3))
END AS customer_last_name,
evaluator_originator.originator_code_txt as dealer_num,
evaluator_originator.originator_name_txt as dealer_name_txt,
evaluator_originator.sales_rep_txt as sales_representative_txt,
originator_address.state_id as state_id,
case when evapp_interface.dealer_incentive_num is not null then 'Yes' when evapp_interface.dealer_incentive_num  is null then 'No' end as dealer_rewards_txt,
get_applicant_bureau_score(credit_request.request_id,0) as fico_score, --Primary Applicant
get_ltv(credit_request.request_id) as ltv_val,
credit_req_contr_fin.amount_financed_num
from credit_request_activity,
credit_request,
credit_request_originator,
evaluator_originator,
config_sales_rep,
originator_address,
evapp_interface,
credit_req_contr_fin
where credit_request_activity.request_id = credit_request.request_id(+)
and credit_request.request_id = credit_request_originator.request_id (+)
and credit_request.evaluator_id = credit_request_originator.evaluator_id (+)
and credit_request_originator.originator_id = evaluator_originator.originator_id (+)
and credit_request_originator.evaluator_id = evaluator_originator.evaluator_id (+)
and evaluator_originator.evaluator_id = config_sales_rep.evaluator_id (+)
and evaluator_originator.sales_rep_txt = config_sales_rep.sales_rep_txt (+)
and credit_request_originator.evaluator_id = originator_address.evaluator_id (+)
and credit_request_originator.originator_id = originator_address.originator_id (+)
and credit_request.appseqno = evapp_interface.appseqno (+)
and evapp_interface.appseqno = credit_req_contr_fin.appseqno (+)
and originator_address.address_type_id = 0 -- Current
and credit_request_activity.activity_id = 10 -- log contract
and credit_request_activity.activity_status_id = 3  -- activity complete
and credit_request_activity.task_group_id = 'CONTRACTADMIN'
