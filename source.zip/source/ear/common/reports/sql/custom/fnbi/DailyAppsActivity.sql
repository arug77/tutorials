select credit_request.request_id,
to_date(to_char(to_evaluatortime(credit_request.initiation_dt,credit_request.evaluator_id),'mm/dd/yyyy'),'mm/dd/yyyy') AS  initiation_dt,
to_char(to_evaluatortime(credit_request.initiation_dt,credit_request.evaluator_id),'Day') AS week_day,
CASE credit_req_decisions_evaluator.decision_id
	WHEN 1 THEN 'CONDITION'
	WHEN 2 THEN 'DECLINE'
	WHEN 3 THEN 'APPROVE'
	WHEN 102 THEN 'APPSCOR'
	WHEN 103 THEN 'DECSCOR'
	ELSE 'OTHER'
END
AS decision_txt,
CHECK_BOOK_ACTIVITY(credit_request.request_id) AS funding_status,
evaluator.evaluator_name_txt
from credit_request,
credit_req_decisions_evaluator,
evaluator
where credit_request.latest_dec_ref_id = credit_req_decisions_evaluator.decision_ref_id (+)
and credit_request.evaluator_id = evaluator.evaluator_id