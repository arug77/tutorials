select credit_request.evaluator_id,
credit_request.request_id,
credit_request.appseqno,
credit_request.client_app_id,
config_product_program.product_id, 
config_product_program.program_id, 
config_product_program.description_txt as finance_program,
credit_request.application_name_txt,
config_sales_rep.first_name_txt||' '||config_sales_rep.last_name_txt AS sales_rep_name_txt,
credit_request_funding.discount_amt_num AS discount_fee,
nvl(credit_req_contr_fin.amount_financed_num,nvl(credit_req_decisions_evaluator.approved_amount_num,nvl(calc_requested_amount_num(credit_request.request_id,credit_request.evaluator_id),0))) AS amount_financed,
to_evaluatortime(credit_request.funding_dt,credit_request.evaluator_id) AS funded_dt,
credit_request_payoff.payoff_num AS tot_fund_amt_num,
credit_request.program_txt as finance_plan,
mstr_booking_status.booking_status_txt,
evaluator_originator.originator_name_txt,
credit_request_loan.other_num,
mega_originator.originator_desc_txt
from credit_request, 
config_product_program, 
credit_request_loan,
credit_request_originator,
evaluator_originator,
credit_request_funding,
credit_request_payoff,
mstr_booking_status,
credit_req_contr_fin,
credit_req_decisions_evaluator,
config_sales_rep,
mega_originator
where credit_request.request_id = credit_request_loan.request_id (+)
and credit_request_loan.program_id = config_product_program.program_id
and credit_request_loan.evaluator_id = config_product_program.evaluator_id
and config_product_program.product_id = credit_request.product_id
and credit_request_originator.request_id = credit_request.request_id
and credit_request_originator.evaluator_id = credit_request.evaluator_id
and credit_request_originator.originator_id = evaluator_originator.originator_id
and credit_request_originator.evaluator_id = evaluator_originator.evaluator_id
and credit_request.evaluator_id = credit_request_payoff.evaluator_id (+)
and credit_request.request_id = credit_request_payoff.request_id (+)
and credit_request.request_id = credit_request_funding.request_id (+)
and credit_request_loan.finance_id (+) = 1
and credit_request_payoff.payoff_id (+) = 1
and credit_request.booking_status_id = mstr_booking_status.booking_status_id (+)
and credit_request.request_id = credit_req_contr_fin.request_id (+)
and credit_request.appseqno = credit_req_contr_fin.appseqno (+)
and credit_request.latest_dec_ref_id = credit_req_decisions_evaluator.decision_ref_id (+)
and evaluator_originator.evaluator_id = config_sales_rep.evaluator_id (+)
and evaluator_originator.sales_rep_txt = config_sales_rep.sales_rep_txt (+)
and evaluator_originator.mega_originator_id = mega_originator.mega_originator_id (+)
and evaluator_originator.evaluator_id = mega_originator.evaluator_id (+)
and credit_request.funding_dt is not null