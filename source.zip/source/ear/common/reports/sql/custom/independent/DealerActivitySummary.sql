select evaluator.evaluator_id,
evaluator.evaluator_name_txt,
evaluator_originator.originator_name_txt,
credit_request.client_app_id,
credit_request.request_id,
credit_request.application_name_txt,
case when credit_req_contr_fin.other2_fee_amt_num > 0 then 1 else 0 end as other2_fee_amt_count,
credit_req_contr_fin.other2_fee_amt_num,
credit_req_contr_fin.rate_num,
credit_req_contr_fin.amount_financed_num,
max_deler_reserve_view.adj_reserve_amt_num/credit_req_contr_fin.amount_financed_num+1.00 as reserve_position_num,
credit_req_decisions_evaluator.approved_buy_rate_num,
credit_req_decisions_evaluator.decision_ref_id,
nvl(credit_request_auto.new_used_flg,0) as new_used_flg,
config_center.center_name as buying_center_name,
crd_req_finance_program_view.finance_program_txt as program_txt,
config_region.region_desc_txt,
config_region.region_desc_txt as region_txt,
credit_request_funding.net_proceeds_num,
max_deler_reserve_view.flat_fee_num,
max_deler_reserve_view.adj_reserve_amt_num,
case when nvl(max_deler_reserve_view.flat_fee_num,0) > 0 then 1 else 0 end as flat_fee_count,
case when nvl(max_deler_reserve_view.amt_to_dealer_num,0) > 0 then 1 else 0 end as adj_reserve_amt_count,
to_number(credit_req_intermediate_value.variable_value_txt) as yield_num
from credit_request,
credit_req_contr_fin,
credit_req_decisions_evaluator,
evaluator,
credit_request_auto,
config_center,
evaluator_originator,
credit_request_originator,
crd_req_finance_program_view,
config_region,
credit_request_funding,
max_deler_reserve_view,
credit_req_intermediate_value
where credit_request.request_id = credit_req_contr_fin.request_id (+)
and credit_request.latest_final_dec_ref_id = credit_req_decisions_evaluator.decision_ref_id (+)
and credit_request.request_id = credit_request_auto.request_id (+)
and credit_request_auto.primary_flg (+) = 1
and credit_request_originator.originator_id = evaluator_originator.originator_id (+) 
and credit_request_originator.evaluator_id = evaluator_originator.evaluator_id (+)
and credit_request.request_id = credit_request_originator.request_id (+) 
and credit_request.evaluator_id = credit_request_originator.evaluator_id (+)
and evaluator_originator.buying_center_id = config_center.center_id (+)
and credit_request.request_id = crd_req_finance_program_view.request_id (+)
and credit_request.evaluator_id = crd_req_finance_program_view.evaluator_id (+)
and crd_req_finance_program_view.finance_id (+) = 1
and evaluator_originator.region_id = config_region.region_id (+)
and evaluator_originator.evaluator_id = config_region.evaluator_id (+)
and credit_request.request_id = credit_request_funding.request_id (+)
and credit_request.request_id = max_deler_reserve_view.request_id (+)
and credit_request.request_id = credit_req_intermediate_value.request_id (+)
and credit_req_intermediate_value.variable_name_txt (+) = 'Inter!YieldDR'
and credit_req_intermediate_value.appentity_txt (+) = 'ALL'
and credit_request.evaluator_id = evaluator.evaluator_id
and credit_request.funding_dt is not null