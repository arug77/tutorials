select credit_request.client_app_id,
credit_request.request_id,
credit_request.evaluator_id,
credit_request.application_name_txt,
credit_request.most_recent_grade_txt AS grade,
credit_req_decisions_evaluator.decisioned_by_user_id,
calc_requested_amount_num(credit_request.request_id,credit_request.evaluator_id) AS amount_financed_num,
credit_req_decisions_evaluator.bureau_id,
mstr_evaluator_decision.decision_txt, 
credit_req_decisions_evaluator.decision_ref_id,
evaluator.evaluator_name_txt,
evaluator_originator.originator_name_txt,
to_char(to_evaluatortime(credit_req_decisions_evaluator.send_dt,credit_request.evaluator_id),'MM/DD/YYYY') AS decision_dt, 
TRIM(TO_CHAR([datecol],'Month'))||' '||TO_CHAR([datecol],'dd'||','||' yyyy') AS DAILY_TXT,
'Week of '||TRIM(TO_CHAR([datecol],'Month'))||' '||TO_CHAR(TRUNC([datecol],'w'),'dd'||','||' yyyy') AS WEEKLY_TXT,
trim(to_char([datecol],'Month'))||' '||to_char([datecol],'yyyy') AS MONTHLY_TXT,
decode(to_char([datecol],'Q'),1,'January - March',2,'April - June',3,'July - September',4,'October - December')||' '||to_char([datecol],'yyyy') AS QUARTERLY_TXT,
to_char([datecol],'yyyy') AS YEARLY_TXT
from credit_request,
credit_req_decisions_evaluator,
mstr_evaluator_decision,
evaluator,
evaluator_originator,
credit_request_originator,
credit_req_decision_reasons
where credit_request.latest_dec_ref_id = credit_req_decisions_evaluator.decision_ref_id
and credit_req_decisions_evaluator.decision_id = mstr_evaluator_decision.decision_id (+)
and credit_req_decisions_evaluator.evaluator_id = evaluator.evaluator_id
and credit_request.request_id = credit_request_originator.request_id
and credit_request_originator.originator_id = evaluator_originator.originator_id
and credit_request_originator.evaluator_id = evaluator_originator.evaluator_id
and credit_request.latest_dec_ref_id = credit_req_decisions_evaluator.decision_ref_id (+) 
and credit_request.latest_dec_ref_id = credit_req_decision_reasons.decision_ref_id
and credit_req_decision_reasons.reason_type_id = 2 