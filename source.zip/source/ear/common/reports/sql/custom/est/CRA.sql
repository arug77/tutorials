select cr.client_app_id,
cr.request_id,
cr.evaluator_id,
cr.personal_flg, 
cr.product_id,
med.decision_txt,
Mbs.Booking_Status_Txt,
get_datetype_txt([datetype]) AS datetype_txt, 
(round((calc_requested_amount_num(cr.request_id,cr.evaluator_id)/10000),1) * 10) AS amount_financed_num,
Evaluator.Evaluator_Name_Txt,
nvl(crcr_applcnt.last_name_txt,applcnt.last_name_txt) as applcnt_last_name_txt,
case
  when crcr_applcnt.last_name_txt is not null then crcr_applcnt.first_name_txt
  Else applcnt.First_Name_Txt
end as applcnt_first_name_txt,
applcnt.age_num as applcnt_age_num,
nvl(crcr_coapplcnt1.last_name_txt,coapplcnt1.last_name_txt) as coapplcnt1_last_name_txt,
case
  when crcr_coapplcnt1.last_name_txt is not null then crcr_coapplcnt1.first_name_txt
  else coapplcnt1.first_name_txt
end as coapplcnt1_first_name_txt,
coapplcnt1.age_num as coapplcnt1_age_num,
nvl(crcr_coapplcnt2.last_name_txt,coapplcnt2.last_name_txt) as coapplcnt2_last_name_txt,
case
  when crcr_coapplcnt2.last_name_txt is not null then crcr_coapplcnt2.first_name_txt
  else coapplcnt2.first_name_txt
end as coapplcnt2_first_name_txt,
coapplcnt2.age_num as coapplcnt2_age_num,
evaluator_originator.originator_code_txt,
credit_req_contr_fin.term_num,
credit_req_contr_fin.buy_rate_num
from 
credit_request cr,
mstr_evaluator_decision med,
mstr_booking_status mbs,
credit_req_decisions_evaluator crde,
evaluator,
requestor applcnt,
requestor coapplcnt1,
requestor coapplcnt2,
credit_req_contr_requestor crcr_applcnt,
credit_req_contr_requestor crcr_coapplcnt1,
credit_req_contr_requestor crcr_coapplcnt2,
credit_request_originator,
evaluator_originator,
credit_req_contr_fin
where med.decision_id = cr.decision_status_id
and cr.evaluator_id = evaluator.evaluator_id
and cr.latest_dec_ref_id = crde.decision_ref_id 
and Mbs.Booking_Status_Id(+) = Cr.Booking_Status_Id 
and Cr.Request_Id = applcnt.Request_Id (+)
and Cr.Evaluator_Id = applcnt.Evaluator_Id  (+)
and applcnt.requestor_type_id (+) = 0
and applcnt.request_id = crcr_applcnt.request_id (+)
and applcnt.Evaluator_Id = crcr_applcnt.Evaluator_Id (+)
and crcr_applcnt.requestor_id (+) = applcnt.requestor_id 
and cr.request_id = coapplcnt1.request_id (+)
and cr.evaluator_id = coapplcnt1.evaluator_id (+)
and coapplcnt1.entity_txt (+) = 'C1'
and coapplcnt1.requestor_type_id (+) = 1
and coapplcnt1.request_id = crcr_coapplcnt1.request_id (+)
and coapplcnt1.evaluator_id = crcr_coapplcnt1.evaluator_id (+)
and crcr_coapplcnt1.requestor_id (+)= coapplcnt1.requestor_id 
and cr.request_id = coapplcnt2.request_id (+)
and cr.evaluator_id = coapplcnt2.evaluator_id (+)
and coapplcnt2.entity_txt (+) = 'C2'
and coapplcnt2.requestor_type_id (+) = 1
and coapplcnt2.request_id = crcr_coapplcnt2.request_id (+)
and coapplcnt2.evaluator_id = crcr_coapplcnt2.evaluator_id (+)
and crcr_coapplcnt2.requestor_id (+)= coapplcnt2.requestor_id 
and cr.request_id = credit_request_originator.request_id (+) 
and cr.evaluator_id = credit_request_originator.evaluator_id (+)
and credit_request_originator.originator_id = evaluator_originator.originator_id (+) 
and credit_request_originator.evaluator_id = evaluator_originator.evaluator_id (+) 
and cr.request_id = credit_req_contr_fin.request_id (+)