select credit_request.client_app_id,
to_char(to_evaluatortime(credit_request.initiation_dt,credit_request.evaluator_id),'MM/DD/YYYY HH12:MI:SS AM') as initiation_dt,
(CASE WHEN (credit_request.booking_status_id = 2 or credit_request.booking_status_id = 3) THEN to_char(to_evaluatortime(credit_request.booking_dt,credit_request.evaluator_id),'MM/DD/YYYY HH12:MI:SS AM') ELSE null END) as approved_dt,
mstr_evaluator_decision.decision_txt,
credit_request_originator.affiliate_id,
credit_request_originator.sub_affiliate_id,
config_affiliates.affiliate_name_txt
from credit_request,
credit_req_contract,
credit_request_originator,
mstr_evaluator_decision,
config_affiliates
where credit_request.decision_status_id=mstr_evaluator_decision.decision_id
and credit_request.request_id=credit_req_contract.request_id(+)
and credit_request.request_id=credit_request_originator.request_id(+)
and credit_request.evaluator_id=credit_request_originator.evaluator_id(+)
and config_affiliates.affiliate_id = credit_request_originator.affiliate_id