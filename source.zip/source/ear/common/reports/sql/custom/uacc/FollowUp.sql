select credit_request.client_app_id, 
credit_request.application_name_txt, 
to_char(to_evaluatortime(credit_request.initiation_dt,credit_request.evaluator_id),'MM/DD/YYYY HH12:MI:SS AM') AS initiation_dt, 
evaluator_originator.originator_name_txt, 
config_region.region_desc_txt, 
mstr_evaluator_decision.decision_txt, 
to_char(to_evaluatortime(credit_req_decisions_evaluator.send_dt,credit_request.evaluator_id),'MM/DD/YYYY HH12:MI:SS AM') AS decision_dt, 
credit_req_decisions_evaluator.decisioned_by_user_id, 
credit_request_auto.year_num AS auto_year, 
mstr_auto_make.auto_make_description_txt AS auto_make, 
credit_request_auto.model_txt AS auto_model, 
TRIM(TO_CHAR([datecol],'Month'))||' '||TO_CHAR([datecol],'dd'||','||' yyyy') AS DAILY_TXT, 
'Week of '||TRIM(TO_CHAR([datecol],'Month'))||' '||TO_CHAR(TRUNC([datecol],'w'),'dd'||','||' yyyy') AS WEEKLY_TXT, 
trim(to_char([datecol],'Month')) || ' ' || to_char([datecol],'yyyy') AS MONTHLY_TXT, 
decode(to_char([datecol],'Q'),1,'January - March',2,'April - June',3,'July - September',4,'October - December') || ' ' || to_char([datecol],'yyyy') AS QUARTERLY_TXT, 
to_char([datecol],'yyyy') AS YEARLY_TXT 
from credit_request, 
credit_request_originator, 
evaluator_originator, 
config_region, 
credit_req_decisions_evaluator, 
mstr_evaluator_decision, 
credit_request_comment, 
credit_request_auto, 
mstr_auto_make 
where credit_request.request_id = credit_request_originator.request_id (+) 
and credit_request.evaluator_id = credit_request_originator.evaluator_id (+) 
and credit_request_originator.originator_id = evaluator_originator.originator_id (+) 
and credit_request_originator.evaluator_id = evaluator_originator.evaluator_id (+) 
and evaluator_originator.evaluator_id = config_region.evaluator_id (+) 
and evaluator_originator.region_id = config_region.region_id (+) 
and credit_request.latest_dec_ref_id = credit_req_decisions_evaluator.decision_ref_id (+) 
and credit_req_decisions_evaluator.decision_id = mstr_evaluator_decision.decision_id (+) 
and credit_request.request_id = credit_request_comment.request_id (+) 
and credit_request.request_id = credit_request_auto.request_id (+) 
and credit_request_auto.auto_make_id = mstr_auto_make.auto_make_id (+) 
and credit_req_decisions_evaluator.decision_id in (1,3,102) 
and credit_request.task_id = 'FOLLOW UP DEALS' 
and credit_request.request_id not in 
                                    (SELECT request_id 
                                       FROM credit_request_comment crc 
                                      WHERE upper(crc.comment_subject_txt) like '%DEAD%DEAL%') 