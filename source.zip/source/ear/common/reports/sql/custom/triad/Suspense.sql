SELECT Credit_request.Evaluator_id,
       Credit_request.Client_app_id,
       Credit_request.Assigned_user_id,
       Credit_request.App_status_id,
       TO_EVALUATORTIME(Credit_request.Initiation_dt,CREDIT_REQUEST.EVALUATOR_ID) AS Initiation_date,
       BUYING_CENTER.CENTER_NAME AS BUYING_CENTER_NAME,
       FUNDING_CENTER.CENTER_NAME AS FUNDING_CENTER_NAME,
       SERVICE_BUYING_CENTER.CENTER_NAME AS SERVICE_BUYING_CENTER_NAME,
       SUBSIDIARY_BUYING_CENTER.CENTER_NAME AS SUBSIDIARY_BUYING_CENTER_NAME,
       Originator_address.STATE_ID,
       Originator_address.ZIPCODE_TXT,
       Credit_request.Application_name_txt,
       Credit_request.PROGRAM_TXT,
       Config_sources.SOURCE_DESC_TXT,
       EVALUATOR_ORIGINATOR.MARKET_TXT,
       Mstr_product.PRODUCT_SHORT_NAME_TXT,
       Mega_originator.ORIGINATOR_DESC_TXT,
       Config_territory.TERRITORY_NAME,
       Config_division.DIVISION_NAME_TXT,
       Config_region.REGION_DESC_TXT,
       Evaluator_originator.Originator_name_txt,
       Evaluator_originator.Assigned_user_id AS Eval_orig_user,
       Evaluator_originator.Sales_rep_txt,
       Evaluator.evaluator_name_txt,
       Eo1.Originator_name_txt AS Linked_orig_name,
       Credit_request_activity.Activity_id,
       Credit_request_activity.Activity_status_id,
       TO_CHAR(TO_EVALUATORTIME(Credit_request_activity.Audit_last_updated_dt,CREDIT_REQUEST.EVALUATOR_ID),'MM/DD/YYYY        HH:MI AM') AS Audit_last_updated_dt,
       Catv1.Activity_id AS Closing_id,
       TO_CHAR(TO_EVALUATORTIME(Catv1.Audit_last_updated_dt,CREDIT_REQUEST.EVALUATOR_ID),'MM/DD/YYYY        HH:MI AM') AS Closing_date,
       Catv1.Activity_status_id AS Closing_status,
       Credit_req_decisions_evaluator.Approved_tier_txt,
       Credit_req_checklist_item.Checklist_item_desc_txt,
       Credit_req_checklist_item.Checklist_item_status_id,
       Requestor_bureau_header.Bureau_of_record_flg,
       TO_EVALUATORTIME(Requestor_bureau_header.Pull_dt,CREDIT_REQUEST.EVALUATOR_ID) AS Pull_dt,
       Config_sales_rep.First_name_txt,
       Config_sales_rep.Last_name_txt,
       Config_center.Center_name,
       Requestor_header.Requestor_type_id,
       Credit_req_doc_ff_comments.Value_txt,
       Credit_req_decisions_evaluator.Decision_id,
       Credit_req_decisions_evaluator.Decisioned_by_user_id,
       Max_ref_id_cat2_view.Decisioned_by_user_id AS Cat2_user_id,
	TRIM(TO_CHAR([datecol],'Month'))||' '||TO_CHAR([datecol],'dd'||','||' yyyy') AS DAILY_TXT,
	'Week of '||TRIM(TO_CHAR([datecol],'Month'))||' '||TO_CHAR(TRUNC([datecol],'w'),'dd'||','||' yyyy') AS WEEKLY_TXT,
	trim(to_char([datecol],'Month')) || ' ' || to_char([datecol],'yyyy') AS MONTHLY_TXT,
	decode(to_char([datecol],'Q'),1,'January - March',2,'April - June',3,'July - September',4,'October - December') || ' ' || to_char([datecol],'yyyy') AS QUARTERLY_TXT,
	to_char([datecol],'yyyy') AS YEARLY_TXT
  FROM Credit_request,
       Credit_request_activity,
       Credit_request_originator,
       Credit_request_activity Catv1,
       Credit_req_checklist_item,
       Requestor_header,
       Credit_req_doc_ff_comments,
       Max_ref_id_cat2_view,
       Evaluator_originator,
       Evaluator_originator Eo1,
       Config_center,
       Config_sales_rep,
       Credit_req_decisions_evaluator,
       Requestor_bureau_header,
       evaluator,
	   Config_region,
	   Config_division,
	   Config_territory,
	   Mega_originator,
	   Mstr_product,
	   Config_sources,
	   Originator_address,
	   Config_center Buying_center,
	   Config_center Funding_center,
       Config_center Service_buying_center,
	   Config_center Subsidiary_buying_center	   
 WHERE Credit_request.Request_id = Credit_request_activity.Request_id
   AND Credit_request.Request_id = Credit_request_originator.Request_id
   AND Credit_request.Request_id = Catv1.Request_id(+)
   AND Credit_request.Request_id = Credit_req_checklist_item.Request_id(+)
   AND Credit_request.Request_id = Requestor_header.Request_id
   AND Credit_request.Request_id = Credit_req_doc_ff_comments.Request_id(+)
   AND Credit_request.Request_id = Max_ref_id_cat2_view.Request_id
   AND CREDIT_REQUEST.PRODUCT_ID = MSTR_PRODUCT.PRODUCT_ID
   AND CREDIT_REQUEST.SOURCE_ID  = CONFIG_SOURCES.SOURCE_ID
   AND CREDIT_REQUEST.EVALUATOR_ID=CONFIG_SOURCES.EVALUATOR_ID
   AND Credit_request_originator.Originator_id = Evaluator_originator.Originator_id
   AND Credit_request_originator.Evaluator_id = Evaluator_originator.Evaluator_id
   AND Evaluator_originator.Linked_originator_code_txt = Eo1.Originator_code_txt
   AND Evaluator_originator.Linked_originator_code_txt is not null
   AND EVALUATOR_ORIGINATOR.EVALUATOR_ID = EO1.EVALUATOR_ID
   AND Evaluator_originator.Evaluator_id = Config_center.Evaluator_id(+)
   AND Evaluator_originator.Buying_center_id = Config_center.Center_id(+)
   and EVALUATOR_ORIGINATOR.EVALUATOR_ID=CONFIG_DIVISION.EVALUATOR_ID(+)
   AND EVALUATOR_ORIGINATOR.DIVISION_ID=CONFIG_DIVISION.DIVISION_ID(+)
   and CREDIT_REQUEST_ORIGINATOR.EVALUATOR_ID=Originator_address.EVALUATOR_ID(+)
   AND CREDIT_REQUEST_ORIGINATOR.ORIGINATOR_ID=Originator_address.ORIGINATOR_ID(+)
   AND Originator_address.ADDRESS_TYPE_ID = 3
   AND Evaluator_originator.REGION_ID = Config_region.REGION_ID(+)
   AND Evaluator_originator.EVALUATOR_ID = Config_region.EVALUATOR_ID(+)
   AND Evaluator_originator.Evaluator_id = Config_sales_rep.Evaluator_id
   AND Evaluator_originator.Sales_rep_txt = Config_sales_rep.Sales_rep_txt
   and EVALUATOR_ORIGINATOR.EVALUATOR_ID=CONFIG_TERRITORY.EVALUATOR_ID(+)
   AND EVALUATOR_ORIGINATOR.TERRITORY_ID=CONFIG_TERRITORY.TERRITORY_ID(+)
   AND Requestor_header.Request_id = Requestor_bureau_header.Request_id
   AND Requestor_header.Requestor_id = Requestor_bureau_header.Requestor_id
   AND EVALUATOR_ORIGINATOR.EVALUATOR_ID=MEGA_ORIGINATOR.EVALUATOR_ID(+)
   AND EVALUATOR_ORIGINATOR.MEGA_ORIGINATOR_ID=MEGA_ORIGINATOR.MEGA_ORIGINATOR_ID(+)
   AND Credit_req_doc_ff_comments.Document_id(+) = 5075
   AND Requestor_header.Requestor_type_id IN (0, 3)
   AND Credit_request.EVALUATOR_ID = 37
   AND Credit_request.App_status_id = 17
   AND Credit_request_activity.Activity_id = 10
   AND Catv1.Activity_id(+) = 28
   AND Requestor_bureau_header.Bureau_of_record_flg = 1
   AND Evaluator_originator.BUYING_CENTER_ID = Buying_center.CENTER_ID(+)
   AND Evaluator_originator.FUNDING_CENTER_ID = Funding_center.CENTER_ID(+)
   AND Evaluator_originator.SERVICE_BUYING_CENTER_ID = Service_buying_center.CENTER_ID(+)
   AND Evaluator_originator.SUBSIDIARY_BUYING_CENTER_ID = Subsidiary_buying_center.CENTER_ID(+)	
   AND Credit_req_decisions_evaluator.Decision_ref_id =
                             (SELECT MAX (crde.Decision_ref_id)
                                FROM Credit_req_decisions_evaluator crde
                               WHERE Credit_request.Request_id = Crde.Request_id
                                 AND crde.Decision_category_id IN (1, 2, 3) )