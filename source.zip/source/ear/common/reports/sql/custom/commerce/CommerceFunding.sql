select credit_request.application_name_txt, 
credit_request.client_app_id, 
to_evaluatortime(credit_request.funding_dt,credit_request.evaluator_id) AS funding_dt,
max_deler_reserve_view.adj_reserve_amt_num, 
credit_request_funding.NET_PROCEEDS_NUM AS amount_financed_num, 
credit_request_funding.tot_fund_amt_num, 
credit_request_funding.misc_ded_num, 
credit_request_funding.misc_ded_txt, 
evaluator_originator.ach_fax_no_txt, 
evaluator.evaluator_name_txt, 
evaluator_address.address1_txt, 
evaluator_address.city_txt, 
evaluator_address.state_id, 
evaluator_address.zipcode_txt, 
evaluator_originator.originator_name_txt, 
evaluator_originator.originator_code_txt, 
evaluator_originator.contact_txt, 
max_deler_reserve_view.ADJ_APPROVE_BUYRATE as approved_buy_rate_num,
TRIM(TO_CHAR([datecol],'Month'))||' '||TO_CHAR([datecol],'dd'||','||' yyyy') AS DAILY_TXT, 
'Week of '||TRIM(TO_CHAR([datecol],'Month'))||' '||TO_CHAR(TRUNC([datecol],'w'),'dd'||','||' yyyy') AS WEEKLY_TXT, 
trim(to_char([datecol],'Month')) || ' ' || to_char([datecol],'yyyy') AS MONTHLY_TXT, 
decode(to_char([datecol],'Q'),1,'January - March',2,'April - June',3,'July - September',4,'October - December') || ' ' || to_char([datecol],'yyyy') AS QUARTERLY_TXT, 
to_char([datecol],'yyyy') AS YEARLY_TXT 
from credit_request,
max_deler_reserve_view,
evaluator_originator,
credit_request_originator,
evaluator,
evaluator_address,
credit_request_funding
where credit_request.request_id = max_deler_reserve_view.request_id (+)
and credit_request.request_id = credit_request_funding.request_id (+)
and credit_request.request_id = credit_request_originator.request_id (+) 
and credit_request.evaluator_id = credit_request_originator.evaluator_id (+) 
and credit_request_originator.originator_id = evaluator_originator.originator_id (+) 
and credit_request_originator.evaluator_id = evaluator_originator.evaluator_id (+) 
and credit_request.evaluator_id = evaluator.evaluator_id
and credit_request.evaluator_id = evaluator_address.evaluator_id
and evaluator_address.address_id = 1
and evaluator_originator.ach_fax_no_txt is not null
and credit_request.app_status_id <> 20
and credit_request.funding_dt is not null 