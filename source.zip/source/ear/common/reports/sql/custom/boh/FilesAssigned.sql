select users.user_id,
(users.first_name_txt || ' ' || users.last_name_txt) AS username,
config_team.team_name_txt
from users,
config_team
where users.evaluator_id = config_team.evaluator_id
and users.team_id = config_team.team_id
and users.active_flg = 1
and config_team.active_flg = 1