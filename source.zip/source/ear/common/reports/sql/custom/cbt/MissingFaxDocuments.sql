select credit_request.request_id, 
credit_request.evaluator_id, 
credit_request.client_app_id, 
credit_request.application_name_txt, 
evaluator.evaluator_name_txt, 
evaluator_originator.ach_fax_no_txt, 
funding_center.street_number_txt || ' ' || funding_center.street_name_txt || ' ' || funding_center.street_type_id AS address1, 
funding_center.apt_suite_box_txt,
funding_center.fax_number_txt,
funding_center.city_txt || '  ' || funding_center.state_id || '  ' || funding_center.zipcode_txt AS address2, 
to_char(to_evaluatortime(sysdate,credit_request.evaluator_id),'MM/DD/YYYY') AS system_date, 
evaluator_originator.originator_name_txt, 
evaluator_originator.contact_txt, 
'XXX-XX-'||substr(requestor.soc_sec_num_txt,6,4) AS soc_sec_num_txt
from credit_request, 
evaluator, 
credit_request_originator, 
evaluator_originator, 
config_center funding_center, 
requestor,
credit_req_checklist_item,
credit_req_checklist_note,
credit_request_activity
where credit_request.booking_status_id = 1 
and credit_request.product_id = 1
and credit_request.task_id = 'MISSING DOCS'
and credit_request.request_id = credit_request_originator.request_id (+) 
and credit_request.evaluator_id = credit_request_originator.evaluator_id (+)
and credit_request.evaluator_id = evaluator.evaluator_id 
and credit_request.request_id = requestor.request_id
and credit_request.evaluator_id = requestor.evaluator_id 
and credit_request.request_id = credit_request_activity.request_id 
and credit_request_activity.task_group_id = 'CONTRACTADMIN'
and credit_request_activity.activity_id = 17
and credit_request_activity.activity_status_id = 1
and credit_request.request_id = credit_req_checklist_item.request_id
and credit_request.evaluator_id = credit_req_checklist_item.evaluator_id
and credit_req_checklist_item.request_id = credit_req_checklist_note.request_id
and credit_req_checklist_item.evaluator_id = credit_req_checklist_note.evaluator_id
and credit_req_checklist_item.checklist_id = credit_req_checklist_note.checklist_id
and credit_request_originator.originator_id = evaluator_originator.originator_id (+) 
and credit_request_originator.evaluator_id = evaluator_originator.evaluator_id (+) 
and evaluator_originator.funding_center_id = funding_center.center_id (+)
and requestor.requestor_type_id = 0
and credit_req_checklist_item.is_document_flg = 1
and credit_req_checklist_item.checklist_item_status_id = 3
and evaluator_originator.ach_fax_no_txt is not null