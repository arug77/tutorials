select credit_request.client_app_id, 
credit_request.application_name_txt, 
nvl(credit_req_contr_fin.amount_financed_num,nvl(credit_req_decisions_evaluator.approved_amount_num,nvl(calc_requested_amount_num(credit_request.request_id,credit_request.evaluator_id),0))) AS amount_financed,
credit_request_payoff.payoff_num AS tot_fund_amt_num, 
credit_request_funding.net_proceeds_num, 
max_deler_reserve_view.adj_approve_buyrate as approved_buy_rate_num, 
credit_req_contr_fin.rate_num AS cust_rate, 
credit_req_decisions_evaluator.approved_discount_amt AS discount_fee, 
credit_req_contra_fin_fee_sum.dealer_fees_num AS total_dealer_fee, 
mstr_funding_method.fund_meth_txt, 
to_evaluatortime(credit_request.funding_dt,credit_request.evaluator_id) AS funded_dt, 
credit_request.funding_user_id, 
credit_request.assigned_user_id, 
credit_req_contr_fin.term_num, 
credit_req_dealer_reserve.adj_dealer_plan_txt, 
credit_req_dealer_reserve.adj_flat_fee_num, 
credit_req_dealer_reserve.amt_to_dealer_num, 
credit_req_dealer_reserve.seq_id, 
evaluator_originator.dealer_reserve_plan_txt, 
TRIM(TO_CHAR([datecol],'Month'))||' '||TO_CHAR([datecol],'dd'||','||' yyyy') AS DAILY_TXT, 
'Week of '||TRIM(TO_CHAR([datecol],'Month'))||' '||TO_CHAR(TRUNC([datecol],'w'),'dd'||','||' yyyy') AS WEEKLY_TXT, 
trim(to_char([datecol],'Month')) || ' ' || to_char([datecol],'yyyy') AS MONTHLY_TXT, 
decode(to_char([datecol],'Q'),1,'January - March',2,'April - June',3,'July - September',4,'October - December') || ' ' || to_char([datecol],'yyyy') AS QUARTERLY_TXT, 
to_char([datecol],'yyyy') AS YEARLY_TXT 
from credit_request, 
credit_req_contr_fin, 
credit_request_payoff, 
credit_request_funding, 
credit_req_decisions_evaluator, 
credit_req_contra_fin_fee_sum, 
max_deler_reserve_view, 
mstr_funding_method, 
credit_req_dealer_reserve, 
evaluator_originator, 
credit_request_originator 
where credit_request.request_id = credit_request_originator.request_id (+) 
and credit_request.evaluator_id = credit_request_originator.evaluator_id (+) 
and credit_request_originator.originator_id = evaluator_originator.originator_id (+) 
and credit_request_originator.evaluator_id = evaluator_originator.evaluator_id (+) 
and credit_request.request_id = credit_req_contr_fin.request_id (+) 
and credit_request.request_id = credit_request_payoff.request_id (+) 
and credit_request.evaluator_id = credit_request_payoff.evaluator_id (+) 
and credit_request.request_id = credit_request_funding.request_id (+) 
and credit_request.latest_dec_ref_id = credit_req_decisions_evaluator.decision_ref_id (+) 
and credit_request.request_id = credit_req_contra_fin_fee_sum.request_id (+) 
and credit_request.evaluator_id = credit_req_contra_fin_fee_sum.evaluator_id (+) 
and credit_request_payoff.detail_fund_meth_id = mstr_funding_method.fund_meth_id (+) 
and credit_request.request_id = max_deler_reserve_view.request_id (+) 
and credit_request.request_id = credit_req_dealer_reserve.request_id (+) 
and credit_req_dealer_reserve.seq_id = 
                                       (SELECT MAX(seq_id) 
                                          FROM credit_req_dealer_reserve crdr 
                                         WHERE credit_request.request_id = crdr.request_id (+)) 
and credit_req_contra_fin_fee_sum.finance_id (+) = 1 
and credit_request_payoff.payoff_id (+) = 1 
and credit_request.funding_dt is not null 