package com.cmsinc.origenate.ae.copyapp;

import java.io.*;
import java.sql.*;
import java.util.*;

import com.cmsinc.origenate.util.LogMsg;
import com.cmsinc.origenate.util.IniFile;


public class TestCopyApp
{

  public static void main( String argv[] ) throws Exception
    {
     TestCopyApp test = new TestCopyApp();

     if (argv.length != 5) {
         System.err.println ("Usage: java TestCopyApp requestID transtype startingTableName deleteFlag ccweb.inipath");
         System.exit (1);
     }

     String requestID=argv[0];
     String transType=argv[1];
     String startingTableName=argv[2];
     String deleteFlag=argv[3];
     String iniFile=argv[4];


     IniFile ini = new IniFile();
     ini.readINIFile(iniFile);
     String s_host = ini.getINIVar("database.host");
     String s_port = ini.getINIVar("database.port");
     String s_sid = ini.getINIVar("database.sid");
     String s_user = ini.getINIVar("database.user");
     String s_password = ini.getINIVar("database.password");
     String s_log_file = ini.getINIVar("logs.copyapp_log_file");
     String sTNSEntry = ini.getINIVar("database.TNSEntry", "");

     System.out.println("Calling CopyApp, parms= "+requestID+" "+transType+" "+startingTableName+" "+deleteFlag);


     CopyApp copyApp = null;

     /* if s_log_file is null then msgs are written to std out */

     /*
     You can either let the CopyApp constructor maitain its own connection
     to the database by passing in the paramters below or

     Or you can pass in your own connection as:

     copyApp = new CopyApp(connection,s_log_file);


     However, if you let CopyApp create its own connection then you MUST

     call copyApp.closeDatabaseConnection();

     to close the connection before you free the copyApp object for the
     garbage collector.

     */

     try {copyApp = new CopyApp(s_host,s_sid,s_user,s_password,s_log_file,s_port,sTNSEntry);}
     catch (Exception e) { 
	    System.out.println("RID="+requestID+" - DEBUG MESSAGE: TestCopyApp.java main Method : FAILED instantiating copyApp for requestID: "+requestID);
	    throw e; 
    }




     CopyAppResponse resp;

     String additionalParms="";  // name=value,name=value...pairs

     try {
       if (deleteFlag.equals("1"))
         resp=copyApp.delete(requestID,transType,startingTableName,additionalParms);
       else
         resp=copyApp.copy(requestID,transType,startingTableName,additionalParms);
      }
     catch (Exception e) { 
	    System.out.println("RID="+requestID+" - DEBUG MESSAGE: TestCopyApp.java main Method : FAILED calling copyApp delete or copy method for requestID: "+requestID);
	    throw e; 
	 }

     copyApp.closeDatabaseConnection(); // because copyapp opened it

     System.out.println("Response assigned ID: "+resp.assignedRequestID);

     writeStringToFile("c:\\development\\libs\\copyapp\\deleteapp.bat",
     "java TestCopyApp "+resp.assignedRequestID+" "+transType+" "+startingTableName+" 1"+" "+iniFile);


     // you can delete the new app the was just created by executing the above file
     // name ( for cleanup)

    } // main

  public TestCopyApp(){}


  public static void writeStringToFile(String fileName,String str) throws Exception {
      PrintWriter out=null;
      FilePermission fp = null;
      try {
      out = new PrintWriter(new FileWriter(fileName));
      // change the permissions on the file so it only has write access while
      // its being written to. This is done to prevent the cdssend monitor
      // from trying to send it while its being written to.
      // After the file is created the permissions will be set to read/write
      fp = new FilePermission(fileName,"write");
      out.print(str);
      out.flush();
      out.close();
      // set the file's permissions so it can be read and the Gateway can recognize
      // it as processable
      fp = new FilePermission(fileName,"read,write");
      }
      catch (Exception e) {
	     System.out.println("DEBUG MESSAGE: TestCopyApp.java writeStringToFile Method : FAILED for fileName: "+fileName+" and str: "+str);
	     throw e;
	  }
  }



} // TestCopyApp


