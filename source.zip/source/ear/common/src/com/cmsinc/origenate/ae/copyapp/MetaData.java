
package com.cmsinc.origenate.ae.copyapp;

import java.sql.*;
import java.util.Vector;
import java.util.Enumeration;
import com.cmsinc.origenate.util.LogMsg;

public class MetaData {

    private Connection conn;
    private Vector rows;
    private int currRow = -1;
    private int numCols=0;
    private String s_colname[];
    private int sqltypes[];


    public MetaData(Connection conn) {
        this.conn=conn;
        // displayDataTypes();
    }// constructor


    public void getMetaData(String schema,String tableName,boolean getPrimaryKeys) throws Exception {
 

           /***************   GET COLUMNS returns the following in a result set

           Each column description has the following columns:

           TABLE_CAT String => table catalog (may be null)
           TABLE_SCHEM String => table schema (may be null)
           TABLE_NAME String => table name
           COLUMN_NAME String => column name
           DATA_TYPE short => SQL type from java.sql.Types
           TYPE_NAME String => Data source dependent type name, for a UDT the type name is fully qualified
           COLUMN_SIZE int => column size. For char or date types this is the maximum number of characters, for numeric or decimal types this is precision.
           BUFFER_LENGTH is not used.
           DECIMAL_DIGITS int => the number of fractional digits
           NUM_PREC_RADIX int => Radix (typically either 10 or 2)
           NULLABLE int => is NULL allowed?
           columnNoNulls - might not allow NULL values
           columnNullable - definitely allows NULL values
           columnNullableUnknown - nullability unknown
           REMARKS String => comment describing column (may be null)
           COLUMN_DEF String => default value (may be null)
           SQL_DATA_TYPE int => unused
           SQL_DATETIME_SUB int => unused
           CHAR_OCTET_LENGTH int => for char types the maximum number of bytes in the column
           ORDINAL_POSITION int => index of column in table (starting at 1)
           IS_NULLABLE String => "NO" means column definitely does not allow NULL values; "YES" means the column might allow NULL values. An empty string means nobody knows.

           *******************/


        DatabaseMetaData dmd;

        rows = new Vector();

        dmd=conn.getMetaData();
        RowData rd=null;
        ResultSet rs=null;
        if (schema!=null) schema=schema.toUpperCase();

        if (getPrimaryKeys)
            rs=dmd.getPrimaryKeys(null,schema,tableName.toUpperCase());
        else
            rs=dmd.getColumns(null,schema,tableName.toUpperCase(),null);

        int ix;
		LogMsg log = new LogMsg();
        try {
            numCols = rs.getMetaData().getColumnCount();
            // get a list of the column names returned for future reference
            s_colname = new String[numCols];
            sqltypes = new int[numCols];
            for (ix=0;ix<s_colname.length;ix++) {
                 s_colname[ix] = rs.getMetaData().getColumnName((ix+1));
                 //System.out.println(s_colname[ix]);
                 sqltypes[ix]=rs.getMetaData().getColumnType(ix+1);
                //System.out.println(s_colname[ix]);
            }

            // now load up the rows found into the rows vector

            while ( rs.next() ) {
                rd = new RowData(rs,numCols);
                rd.setData(rs);
                rows.addElement(rd);
            } // rs.next
        }
        catch (Exception e) {
		    log.FmtAndLogMsg("DEBUG MESSAGE: MetaData.java getMetaData Method : Error getting metadata for  tableName: "+tableName+" and schema: "+schema, e);
            // statement closed in finally block
            throw new Exception("Error getting metadata for "+tableName+" in " +getClass()+":"+e.toString(), e);
        }
        finally {
            rs.close(); // close the result set
        }

        currRow = -1;

    } // getMetaData


    public final int getRowCount() { return(rows.size()); }

    public final int getNumCols() { return(numCols); }

    public final void gotoRow(int row) { currRow=row; } // zero based

    public final int getCurrRowID() { return(currRow); }

    public final void reset() { currRow = -1; } // so next() will get first row

    public final String getColName(int col)  { // 1 based
        return(s_colname[col-1]);
    }
    public final int getColType(int col)  { // 1 based
        return(sqltypes[col-1]);
    }

    public boolean next() {
        currRow++;
        return((currRow>(rows.size()-1)) ? false : true);
    }

    public String getColValue(String colName) throws Exception {
        return(((RowData)rows.elementAt(currRow)).getColValue(getColPosition(colName)));
    }


    public int getColPosition(String colName) throws Exception {
        for (int ix=0;ix<s_colname.length;ix++)
            if (colName.equalsIgnoreCase(s_colname[ix])) return(ix+1);
        return(0);
    }// getColPosition


    public int getDataType(String colName) throws Exception {

        String dataType="";
        int saveRow=currRow;

        int type=Types.NUMERIC;

        reset();
        while(next()) {
            if (getColValue("column_name").equals(colName)){
                dataType=getColValue("data_type");
                //System.out.println(dataType);
                type=Integer.parseInt(dataType);
                break;
            }
        }

        currRow=saveRow;

        //if (colName.equals("BIRTH_DT"))
        //    System.out.println("birth type = "+type);


        return type;

    }  // getDataType

    public void listDataTypes() throws Exception {

        int saveRow=currRow;

        reset();
        while(next()) {
            System.out.println(getColValue("column_name")+"  Type="+getColValue("data_type"));
        }

        currRow=saveRow;

    }  // listDataTypes


    public boolean isNumeric(String colName) throws Exception {
        int type=getDataType(colName);
        switch(type) {
             case    Types.BIGINT            :
             case    Types.BIT               :
             case    Types.DECIMAL           :
             case    Types.DOUBLE            :
             case    Types.FLOAT             :
             case    Types.INTEGER           :
             case    Types.NUMERIC           :
             case    Types.REAL              :
             case    Types.SMALLINT          :
             case    Types.TINYINT           :
                     return(true);
        }
        return(false);

    } // isNumeric

    public boolean supportedDataType(String colName) throws Exception {

        int type=getDataType(colName);


        switch(type) {
              // the following data types are not supported during a
              // copy process
              case  Types.ARRAY             :
              case  Types.BINARY            :
              case  Types.BLOB              :
              case  Types.CLOB              :
              case  Types.JAVA_OBJECT       :
              case  Types.LONGVARBINARY     :
              case  Types.OTHER             :
              case  Types.REF               :
              case  Types.STRUCT            :
              case  Types.VARBINARY         :
                    return(false);
        }
        return(true);

    } // isNumeric



    private void displayDataTypes() {
         System.out.println("ARRAY         "+Types.ARRAY             );
         System.out.println("BIGINT        "+Types.BIGINT            );
         System.out.println("BINARY        "+Types.BINARY            );
         System.out.println("BIT           "+Types.BIT               );
         System.out.println("BLOB          "+Types.BLOB              );
         System.out.println("CHAR          "+Types.CHAR              );
         System.out.println("CLOB          "+Types.CLOB              );
         System.out.println("DATE          "+Types.DATE              );
         System.out.println("DECIMAL       "+Types.DECIMAL           );
         System.out.println("DISTINCT      "+Types.DISTINCT          );
         System.out.println("DOUBLE        "+Types.DOUBLE            );
         System.out.println("FLOAT         "+Types.FLOAT             );
         System.out.println("INTEGER       "+Types.INTEGER           );
         System.out.println("JAVA_OBJECT   "+Types.JAVA_OBJECT       );
         System.out.println("LONGVARBINARY "+Types.LONGVARBINARY     );
         System.out.println("LONGVARCHAR   "+Types.LONGVARCHAR       );
         System.out.println("NULL          "+Types.NULL              );
         System.out.println("NUMERIC       "+Types.NUMERIC           );
         System.out.println("OTHER         "+Types.OTHER             );
         System.out.println("REAL          "+Types.REAL              );
         System.out.println("REF           "+Types.REF               );
         System.out.println("SMALLINT      "+Types.SMALLINT          );
         System.out.println("STRUCT        "+Types.STRUCT            );
         System.out.println("TIME          "+Types.TIME              );
         System.out.println("TIMESTAMP     "+Types.TIMESTAMP         );
         System.out.println("TINYINT       "+Types.TINYINT           );
         System.out.println("VARBINARY     "+Types.VARBINARY         );
         System.out.println("VARCHAR       "+Types.VARCHAR           );
    }

}