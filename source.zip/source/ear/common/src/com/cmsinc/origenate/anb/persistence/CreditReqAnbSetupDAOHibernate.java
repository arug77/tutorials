package com.cmsinc.origenate.anb.persistence;

import java.sql.Date;

import com.cmsinc.origenate.evaluator.persistence.Evaluator;
import com.cmsinc.origenate.util.persistence.BaseHibernateDAO;

/**
 * Dasccess for CreditReqAnbSetup.
 *
 * @spring.bean id="creditReqAnbSetupDAO" singleton="true" autowire="byName"
 *              lazy-init="false" transactional="true"
 */
public class CreditReqAnbSetupDAOHibernate extends BaseHibernateDAO implements CreditReqAnbSetupDAO {

   /** Default serialization ID. */
   private static final long serialVersionUID = 1L;

   public CreditReqAnbSetup get(final Integer id)
   {
      return (CreditReqAnbSetup) find(CreditReqAnbSetup.class, id);
   }

   public CreditReqAnbSetup save(Integer requestId, Evaluator e, Integer appseqno, String branchTxt, String respcodeTxt,
                                 String classcodeTxt, String purpcodeTxt, String portTxt, String prodcodeTxt, String collcodeTxt, 
								 String noteTxt, String paycodeNum, String extacctTxt, String extrouteNum, String chargeacctNum, 
								 String payoridTxt, String promocodeTxt, String dlrachNum)
   {
      CreditReqAnbSetup cr = new CreditReqAnbSetup();

      cr.setId(requestId);
      cr.setEvaluator(e);
      cr.setAppseqno(appseqno);

	  cr.setBranchTxt(branchTxt);
	  cr.setRespcodeTxt(respcodeTxt);
	  cr.setClasscodeTxt(classcodeTxt);
	  cr.setPurpcodeTxt(purpcodeTxt);
	  cr.setPortTxt(portTxt);
	  cr.setProdcodeTxt(prodcodeTxt);
	  cr.setCollcodeTxt(collcodeTxt);
	  cr.setNoteTxt(noteTxt);
	  cr.setPaycodeNum(paycodeNum);
	  cr.setExtacctTxt(extacctTxt);
	  cr.setExtrouteNum(extrouteNum);
	  cr.setChargeacctNum(chargeacctNum);
	  cr.setPayoridTxt(payoridTxt);
	  cr.setPromocodeTxt(promocodeTxt);
	  cr.setDlrachNum(dlrachNum);


      insertOrUpdate(cr);
      if(log.isDebugEnabled())
      {
         log.debug("Added or updated CreditReqAnbSetup row with request_id = " +
            cr.getId());
      }

      return cr;
   }

   public void delete(Integer requestId, Integer evaluatorId)
   {
      CreditReqAnbSetup cr = new CreditReqAnbSetup();
      cr.setId(requestId);
      cr.setEvaluator(new Evaluator(evaluatorId));
      delete(cr);

      if(log.isDebugEnabled())
      {
         log.debug("Successfully removed row with requestId "
                     + requestId + " from CreditReqAnbSetup");
      }
   }
}