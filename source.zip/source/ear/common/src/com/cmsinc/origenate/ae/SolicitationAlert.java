/*
 * SolicitationAlert.java
 *
 * Created on April 16, 2013
 *
 * 
 */

package com.cmsinc.origenate.ae;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import com.cmsinc.origenate.crypto.Crypto;
import com.cmsinc.origenate.crypto.CryptoFactory;
import com.cmsinc.origenate.event.CommentEvents;
import com.cmsinc.origenate.util.COLEncrypt;
import com.cmsinc.origenate.util.ConnectionUtils;
import com.cmsinc.origenate.util.LogMsg;
import com.cmsinc.origenate.util.OrigenateIniFile;
import com.cmsinc.origenate.util.Query;


/**
 *
 * @author saimak
 * @version 1.0
 *
 * request_id - the application to perform the requestor alert check 
 */
public class SolicitationAlert extends Object {
	private Connection conn;
	private LogMsg log = new LogMsg();
	private String s_log_file = "";

	// Default Configuration
	private boolean matchOnAddressFlg = true;
	private boolean matchOnFullNameFlg = true;
	private boolean matchOnSolicitationIDFlg = true;
	private boolean matchOnFirstCharLastNameAndSSNFlg = false;
	private boolean encryptedSSNFlg = false;
	private boolean encryptedIdFlg = false;

	/**
	 * Solicitation Alert Object - used to check application for possible solicitation list matches
	 */

	// SolicitationAlert constructor that creates its own db connection
	public SolicitationAlert(String argHost, String argSid, String argUserName, String argPwd, String argLogName, String argPort,String tnsEntry) throws Exception {
		s_log_file = argLogName;
		if (argLogName!=null && argLogName.length()>0)
			log.openLogFile(argLogName);

		//String conStr = "jdbc:oracle:thin:@" + argHost + ":" + argPort + ":" + argSid;

		// use tns entry if present
		String conStr = "jdbc:oracle:thin:@";
		if (tnsEntry.equals("")) {
			conStr = conStr + argHost + ":" + argPort + ":" + argSid;
		} else {
			conStr = conStr + tnsEntry;
		}
		try {
			// Load Oracle driver
			DriverManager.registerDriver (new oracle.jdbc.OracleDriver());

			// Connect to the Oracle database
			this.conn = DriverManager.getConnection (conStr,argUserName,COLEncrypt.sDecrypt(argPwd));
		}
		catch (SQLException e) {
			if (s_log_file!=null && s_log_file.length()>0)
				log.FmtAndLogMsg("DEBUG MESSAGE: SolicitationAlert.java SolicitationAlert Constructor(7 arguments) : Error problem with db connection in constructor " + getClass(), e);
			throw new Exception("Database connect error:"+e.toString(), e);
		}

	}

	public SolicitationAlert(String argHost, String argSid, String argUserName, String argPwd, String argLogName, String argPort) throws Exception {
		s_log_file = argLogName;
		if (argLogName!=null && argLogName.length()>0)
			log.openLogFile(argLogName);

		String conStr = "jdbc:oracle:thin:@" + argHost + ":" + argPort + ":" + argSid;

		try {
			// Load Oracle driver
			DriverManager.registerDriver (new oracle.jdbc.OracleDriver());

			// Connect to the Oracle database
			this.conn = DriverManager.getConnection (conStr,argUserName,COLEncrypt.sDecrypt(argPwd));
		}
		catch (SQLException e) {
			if (s_log_file!=null && s_log_file.length()>0)
				log.FmtAndLogMsg("DEBUG MESSAGE: SolicitationAlert.java SolicitationAlert Constructor(6 arguments) : Error problem with db connection in constructor " + getClass(), e);
			throw new Exception("Database connect error:"+e.toString(), e);
		}

	}

	// RequestorAlert constructor that allows a db connection to be passed
	public SolicitationAlert(Connection argCon, String argLogName) throws Exception {
		s_log_file = argLogName;
		if (argLogName!=null && argLogName.length()>0)
			log.openLogFile(argLogName);

		this.conn = argCon;
		if (this.conn == null) {
			if (s_log_file!=null && s_log_file.length()>0)
				log.FmtAndLogMsg("Error problem with db connection in constructor " + getClass());
			throw new Exception("Error invalid connection." + getClass());
		}

	}

	public void cleanup() {
		try {conn.close();} catch (Exception ec) {}
		if (s_log_file.length()>0) try {log.closeLogFile(); } catch (Exception e3) {}
	}

	// solicitationAlert method checks application for potential solicitation list matches and returns whether one was found or not
	public void solicitationAlert(int request_id, int evaluator_id) throws Exception {

		initConfig(conn, request_id);
		initEncryption(conn, request_id);

		ResultSet rs = null;
		ResultSet alert_rs = null;
		PreparedStatement stmt = null;
		PreparedStatement update_stmt = null;
		PreparedStatement select_stmt = null;
		PreparedStatement alert_stmt = null;
		PreparedStatement init_stmt = null;
		ResultSet init_rs = null;
		String alertComment = "";


		// make sure db connection is available
		if (conn != null){
			try {
				String s_init = "select initiation_dt from credit_request where request_id = ?";

				init_stmt = conn.prepareStatement(s_init);
				init_stmt.setInt(1,request_id);
				init_rs = init_stmt.executeQuery();
				init_rs.next(); 

				// Grab all Requestor info to cross reference against solicitation records (use case insensitive matches)
				String s_sql =  " SELECT mrt.requestor_type_description_txt,                          " +
						"   r.requestor_id,                                                   " +
						"   LOWER(r.first_name_txt) AS first_name_txt,                        " +
						"   SUBSTR(LOWER(r.middle_name_txt),   1,   1) AS middle_initial_txt, " +
						"   LOWER(r.last_name_txt) AS last_name_txt,                          " +
						"   r.suffix_id,                                                      " +
						"   ra.street_number_txt,                                             " +
						"   LOWER(ra.street_name_txt) AS street_name_txt,                     " +
						"   ra.street_type_id,                                                " +
						"   LOWER(ra.apt_suite_box_txt) AS street_extra_txt,                  " +
						"   ra.zipcode_txt,                                                   " +
						"   r.solicitation_txt AS solicitation_txt,                           " +
						"   r.solicitation_txt2 AS solicitation_txt2,                         " +
						"   r.solicitation_txt3 AS solicitation_txt3,                         " +
						"   r.solicitation_txt4 AS solicitation_txt4,                         " +
						"   soc_sec_num_txt,                                                  " +
						"   soc_sec_num_txt_enc                                               " +
						" FROM mstr_requestor_type mrt,                                       " +
						"   requestor r,                                                      " +
						"   requestor_address ra                                              " +
						" WHERE mrt.requestor_type_id = r.requestor_type_id                   " +
						"  AND r.request_id = ?                                               " +
						"  AND ra.request_id(+) = r.request_id                                " +
						"  AND ra.requestor_id(+) = r.requestor_id                            " +
						"  AND ra.address_type_id(+) = 0                                      " +
						"  AND ra.address_precedence_num(+) = 1                               ";
				stmt = conn.prepareStatement(s_sql);
				stmt.setInt(1, request_id);
				rs = stmt.executeQuery(); 
				boolean recordsExist = false;
				while(rs.next()) {
					recordsExist = true;
					HashMap<String, String> matches = new HashMap<String,String>();
					Date initiation_dt = init_rs.getDate("initiation_dt");
					String requestor_type_description_txt = rs.getString("requestor_type_description_txt"); 

					// Run Solicitation Matching based on CONFIG_SOLICITATION_MATCHES
					if (matchOnAddressFlg) {
						String street_number_txt = rs.getString("street_number_txt"); 
						String street_name_txt = rs.getString("street_name_txt"); 
						String zipcode_txt = rs.getString("zipcode_txt"); 
						String street_type_id = rs.getString("street_type_id"); 
						String street_extra_txt = rs.getString("street_extra_txt"); 
						matches = matchOnAddress(matches, evaluator_id, initiation_dt, street_number_txt, street_name_txt, zipcode_txt, street_type_id, street_extra_txt);
					}
					if (matchOnFullNameFlg) {
						String first_name_txt = rs.getString("first_name_txt"); 
						String last_name_txt = rs.getString("last_name_txt"); 
						String middle_initial_txt = rs.getString("middle_initial_txt"); 
						String suffix_id = rs.getString("suffix_id"); 
						matches = matchOnFullName(matches, evaluator_id, initiation_dt, first_name_txt, last_name_txt, middle_initial_txt, suffix_id);
					}
					if (matchOnSolicitationIDFlg) {
						String solicitation_txt = rs.getString("solicitation_txt"); 
						String solicitation_txt2 = rs.getString("solicitation_txt2"); 
						String solicitation_txt3 = rs.getString("solicitation_txt3"); 
						String solicitation_txt4 = rs.getString("solicitation_txt4"); 
						matches = matchOnSolicitationID(matches, evaluator_id, initiation_dt, solicitation_txt, solicitation_txt2, solicitation_txt3, solicitation_txt4);
					}
					if (matchOnFirstCharLastNameAndSSNFlg) {
						String last_name_txt = rs.getString("last_name_txt"); 
						String soc_sec_num_txt = rs.getString("soc_sec_num_txt"); 
						System.out.println("ssn encryption flg: "+encryptedSSNFlg+", id flg: "+encryptedIdFlg);
						// If Encryption is enabled for the SSN, grab the encrypted SSN, and attempt to decrypt
                                                OrigenateIniFile ini = new OrigenateIniFile(conn);
                                                ini.readINIFile();
                                                String client_name = ini.getINIVar("database.user", "").toLowerCase();
                                                Crypto crypto = CryptoFactory.getCrypto();
						if (encryptedSSNFlg && rs.getString("SOC_SEC_NUM_TXT_ENC") != null) {
							soc_sec_num_txt = crypto.decryptString("origenate_" + client_name, "ssn", rs.getString("SOC_SEC_NUM_TXT_ENC"));
                                                        // gl. 337819 we now have the decrypted ssn from the requestor table
                                                        // convert to hash value so we can search on it,no need for the id_key because it was used to create the hash in the config_solicitations_list table
                                                        // ALSO, ONLY CONVERT TO A HASH VALUE IF THE ID_FLG IS ON IN CONFIG_ENCRYPTION
                                                        if (encryptedIdFlg)
							    soc_sec_num_txt = crypto.generateMAC("origenate_" + client_name,  soc_sec_num_txt.substring(1));
							//soc_sec_num_txt = crypto.encryptString("origenate_" + client_name, "ssn", soc_sec_num_txt.substring(1));
						}
						else if (soc_sec_num_txt!=null)  {
                                                   // gl. 337819 -  If the config_solicitation_id table is encrypted then we want to search on the hash value
                                                   if (encryptedIdFlg)
                                                        soc_sec_num_txt = crypto.generateMAC("origenate_" + client_name,  soc_sec_num_txt.substring(1));
                                                   else
							soc_sec_num_txt = soc_sec_num_txt.substring(1);
						}

						// If the SSN is not null or empty, try to match on it.
						if (soc_sec_num_txt != null && !soc_sec_num_txt.equals("")) {              
							matches = matchOnFirstCharLastNameAndSSN(matches, evaluator_id, initiation_dt, last_name_txt, soc_sec_num_txt);
						}
					}

					//Automatically load the solicitation ID into the app
					//Find the corresponding solicitation txt fields for the solicitation ids
					if (matches != null && !matches.isEmpty()) {
						s_sql = "SELECT solicitation_txt FROM config_solicitation_list "
								+ "WHERE solicitation_id IN (";

						for (int ii = 1; ii <= matches.size(); ii++) {
							s_sql += "?";

							//Don't add comma for last element
							if (ii != matches.size()) {
								s_sql += ",";
							}
						}

						s_sql += ") AND evaluator_id = ?";

						select_stmt = conn.prepareStatement(s_sql);

						Iterator<String> iter = matches.keySet().iterator();

						int paramCounter = 1;
						while (paramCounter <= matches.size()) {
							select_stmt.setInt(paramCounter, Integer.parseInt(iter.next()));
							paramCounter++;
						}
						select_stmt.setInt(paramCounter, evaluator_id);

						ResultSet solicitationTxtResults = select_stmt.executeQuery();

						//Set the text fields
						String solicitationTxt1 = solicitationTxtResults.next() ? solicitationTxtResults.getString("solicitation_txt") : null;
						String solicitationTxt2 = solicitationTxtResults.next() ? solicitationTxtResults.getString("solicitation_txt") : null;
						String solicitationTxt3 = solicitationTxtResults.next() ? solicitationTxtResults.getString("solicitation_txt") : null;
						String solicitationTxt4 = solicitationTxtResults.next() ? solicitationTxtResults.getString("solicitation_txt") : null;

						ConnectionUtils.closeResultSet(solicitationTxtResults);
						ConnectionUtils.closeStatement(select_stmt);

						//Set the solicitation id fields in requestor
						s_sql = "UPDATE requestor SET solicitation_txt = ?, solicitation_txt2 = ?, "
								+ "solicitation_txt3 = ?, solicitation_txt4 = ? "
								+ "WHERE request_id= ? AND requestor_id= ? AND evaluator_id = ?";

						update_stmt = conn.prepareStatement(s_sql);
						update_stmt.setString(1, solicitationTxt1);
						update_stmt.setString(2, solicitationTxt2);
						update_stmt.setString(3, solicitationTxt3);
						update_stmt.setString(4, solicitationTxt4);
						update_stmt.setInt(5, request_id);
						update_stmt.setInt(6, rs.getInt("requestor_id"));
						update_stmt.setInt(7, evaluator_id);

						update_stmt.executeUpdate();

						ConnectionUtils.closeStatement(update_stmt);
					}

					// Update the Requestor's corresponding SOLICITATION_FLG
					s_sql = "update requestor set solicitation_flg= ? where request_id= ? and requestor_id= ? ";
					update_stmt = conn.prepareStatement(s_sql);
					update_stmt.setInt(1,matches.isEmpty() ? 0 : 1);
					update_stmt.setInt(2,request_id);
					update_stmt.setInt(3,rs.getInt("requestor_id"));
					update_stmt.executeUpdate();
					try {update_stmt.close();} catch (Exception e1) {}

					// Add all the matches to the alertComment for this Requestor
					for(Map.Entry<String, String> entry : matches.entrySet()){
						alertComment += "Solicitation Match " + entry.getKey() + " " + requestor_type_description_txt + " matched on (" + entry.getValue() + ")\n";
					}

					System.out.println(alertComment);            

				} // for each requestor

				try {init_rs.close();} catch (Exception e1) {}
				try {init_stmt.close();} catch (Exception e1) {}

				if(recordsExist){//if (rs.getRow() > 0) {
					// if there was any alert match on the app, record the journal entry and system comment
					if (alertComment.equals("")) {
						if (s_log_file!=null && s_log_file.length()>0)
							log.FmtAndLogMsg("No Solicitation match found for request_id="+request_id+", evaluator_id="+evaluator_id);
					}
					else {
						if (s_log_file!=null && s_log_file.length()>0)
							log.FmtAndLogMsg("Solicitation match(s) found for request_id="+request_id+", evaluator_id="+evaluator_id);

						//have to create a comment event id and then add the follwing statements

						try {
							CommentEvents ce = new CommentEvents(conn,s_log_file);
							ce.addComment(request_id,92,"Solicitation Alert",alertComment.toString().substring(0,alertComment.length()-2),"SYSTEM","",null);
						}
						catch (Exception e) {
							if (s_log_file!=null && s_log_file.length()>0)
								log.FmtAndLogMsg("RID="+request_id+" - DEBUG MESSAGE: SolicitationAlert.java SolicitationAlert Constructor : There was a problem creating the Solicitation system comment for requestId: "+request_id+", evaluatorId: "+evaluator_id, e);
							throw new Exception(e.toString(), e);
						}



					}
				}
				// requestor info query returned no rows, throw an exception (that data is required)
				else {
					if (s_log_file!=null && s_log_file.length()>0)
						log.FmtAndLogMsg("Solicitation alert check failed because application information is incomplete for request_id="+request_id);
					throw new Exception("Incomplete application information");
				}

			}
			catch (Exception e) {
				log.FmtAndLogMsg("RID="+request_id+" - ERROR -DEBUG MESSAGE: SolicitationAlert.java SolicitationAlert Constructor : FAILED for requestId: "+request_id+" and evaluatorId: "+evaluator_id, e);
			       // throw e;     // gl. do not want to throw this because it is called by action/act_routeappmodify.cfm and dataentry/action/act_done_app_entry.cfm
                                // in both cases we do not want to prevent the app from being routed, so just report the error so it can be caught by Support
			}
			finally {
				// make sure all cursors are closed
				if(rs != null) try {rs.close();} catch (Exception e1) {}
				if(alert_rs != null) try {alert_rs.close();} catch (Exception e1) {}
				if(stmt != null) try {stmt.close();} catch (Exception e1) {}
				if(alert_stmt != null) try {alert_stmt.close();} catch (Exception e1) {}
				if(update_stmt != null) try {update_stmt.close();} catch (Exception e1) {}
				if(init_stmt != null) try {init_stmt.close();} catch (Exception e1) {}
				if(init_rs != null) try {init_rs.close();} catch (Exception e1) {}

			}
		}
		else {
			if (s_log_file!=null && s_log_file.length()>0)
				log.FmtAndLogMsg("Solicitation alert check not performed because of no DB connection.");
			throw new Exception("DB connection does not exist");
		}
	}

	/**
	 * 	Find Matching Solicitations based on the full address of the Requestor.
	 */
	private HashMap<String, String> matchOnAddress(HashMap<String,String> matches, int evaluator_id, Date initiation_dt, String street_number_txt, String street_name_txt, String zipcode_txt, String street_type_id, String street_extra_txt){
		Query qry = new Query(conn);
		String sql = " SELECT solicitation_id,                                                                  " +
				"	    'ADDRESS' AS match_type                                                                 " +
				" FROM config_solicitation_list                                                                " +
				" WHERE effective_dt <= ?                                                                      " +
				" AND expiration_dt >= ?                                                                       " +
				" AND evaluator_id = ?                                                                         " +
				" AND nvl(street_number_txt, ?) = ?                                                            " +
				" AND nvl(LOWER(street_name_txt), ?) = ?                                                       " +
				" AND nvl(zipcode_txt, ?) = ?                                                                  " +
				" AND(street_type_id IS NULL OR ? IS NULL OR street_type_id = ?)                               " +
				" AND(address2_txt IS NULL OR ? IS NULL OR LOWER(address2_txt) = ?)                            " +
				" AND(street_number_txt IS NOT NULL OR street_name_txt IS NOT NULL OR zipcode_txt IS NOT NULL) ";

		try {
			qry.prepareStatement(sql);
			qry.setDate(1, initiation_dt);
			qry.setDate(2, initiation_dt);
			qry.setInt(3, evaluator_id);
			qry.setString(4, street_number_txt);
			qry.setString(5, street_number_txt);
			qry.setString(6, street_name_txt);
			qry.setString(7, street_name_txt);
			qry.setString(8, zipcode_txt);
			qry.setString(9, zipcode_txt);
			qry.setString(10, street_type_id);
			qry.setString(11, street_type_id);
			qry.setString(12, street_extra_txt);
			qry.setString(13, street_extra_txt);
			qry.executePreparedQuery();

			log.FmtAndLogMsg(" Found " + qry.getRowCount() + " Address matches" );

			matches = processMatches(matches,qry);

		} catch (Exception e) {
			log.FmtAndLogMsg(" Failed to lookup Address matches ", e);
		}

		return matches;
	}

	/**
	 * 	Find Matching Solicitations based on the full name of the Requestor.
	 */
	private HashMap<String, String> matchOnFullName(HashMap<String,String> matches, int evaluator_id, Date initiation_dt, String first_name_txt, String last_name_txt, String middle_initial_txt, String suffix_id){
		Query qry = new Query(conn);
		String sql = " SELECT solicitation_id,                                                         " +
				"        'NAME' AS match_type                                                     " +
				" FROM config_solicitation_list                                                   " +
				" WHERE effective_dt <= ?                                                         " +
				" AND expiration_dt >= ?                                                          " +
				" AND evaluator_id = ?                                                            " +
				" AND nvl(LOWER(first_name_txt),   ?) = ?                                         " +
				" AND nvl(LOWER(last_name_txt),   ?) = ?                                          " +
				" AND(middle_initial_txt IS NULL OR ? IS NULL OR LOWER(middle_initial_txt) = ?)   " +
				" AND(suffix_id IS NULL OR ? IS NULL OR suffix_id = ?)                            " +
				" AND(first_name_txt IS NOT NULL OR last_name_txt IS NOT NULL)                    ";

		try {
			qry.prepareStatement(sql);
			qry.setDate(1, initiation_dt);
			qry.setDate(2, initiation_dt);
			qry.setInt(3, evaluator_id);
			qry.setString(4, first_name_txt);
			qry.setString(5, first_name_txt);
			qry.setString(6, last_name_txt);
			qry.setString(7, last_name_txt);
			qry.setString(8, middle_initial_txt);
			qry.setString(9, middle_initial_txt);
			qry.setString(10, suffix_id);
			qry.setString(11, suffix_id);
			qry.executePreparedQuery();
			log.FmtAndLogMsg(" Found " + qry.getRowCount() + " Full Name matches" );

			matches = processMatches(matches,qry);

		} catch (Exception e) {
			log.FmtAndLogMsg(" Failed to lookup Full Name matches ", e);
		}

		return matches;
	}

	/**
	 * 	Find Matching Solicitations based on the solicitation text defined by the Requestor.
	 */
	private HashMap<String, String> matchOnSolicitationID(HashMap<String,String> matches, int evaluator_id, Date initiation_dt, String solicitation_txt, String solicitation_txt2, String solicitation_txt3, String solicitation_txt4){
		Query qry = new Query(conn);
		String sql = " SELECT solicitation_id,                     " +
				"   'SOLICITATION ID' AS match_type           " +
				" FROM config_solicitation_list               " +
				" WHERE effective_dt <= ?                     " +
				"  AND expiration_dt >= ?                     " +
				"  AND evaluator_id = ?                       " +
				"  AND ( LOWER(solicitation_txt) = ?  		   " +
				"     OR LOWER(solicitation_txt) = ?  		   " +
				"     OR LOWER(solicitation_txt) = ?  		   " +
				"     OR LOWER(solicitation_txt) = ?)		   ";

		try {
			qry.prepareStatement(sql);
			qry.setDate(1, initiation_dt);
			qry.setDate(2, initiation_dt);
			qry.setInt(3, evaluator_id);
			qry.setString(4, (solicitation_txt == null) ? null : solicitation_txt.toLowerCase());
			qry.setString(5, (solicitation_txt2 == null) ? null : solicitation_txt2.toLowerCase());
			qry.setString(6, (solicitation_txt3 == null) ? null : solicitation_txt3.toLowerCase());
			qry.setString(7, (solicitation_txt4 == null) ? null : solicitation_txt4.toLowerCase());
			qry.executePreparedQuery();

			log.FmtAndLogMsg(" Found " + qry.getRowCount() + " Solicitation Txt matches" );
			matches = processMatches(matches,qry);

		} catch (Exception e) {
			log.FmtAndLogMsg(" Failed to lookup Solicitation Txt matches ", e);
			System.out.print(e);
		}

		return matches;
	}

	/**
	 * 	Find Matching Solicitations based on a partial SSN of the requestor (final 8 digits) AND the first character of the last name of the Requestor.
	 */
	private HashMap<String, String> matchOnFirstCharLastNameAndSSN(HashMap<String,String> matches, int evaluator_id, Date initiation_dt, String last_name_txt, String soc_sec_num_txt){
		Query qry = new Query(conn);
                // gl. we are now matching on the hash value, not the enc value
		String sql = " SELECT solicitation_id,                                                   " +
				"        'SSN/LAST NAME (1st letter)' AS match_type                         " +
				" FROM config_solicitation_list                                             " +
				" WHERE effective_dt <= ?                                                   " +
				" AND expiration_dt >= ?                                                    " +
				" AND evaluator_id = ?                                                      " +
				" AND (id_txt = ?                                   				 " +
				"  	OR id_txt_hash = ?)                           				 " +
				" AND LOWER(SUBSTR(last_name_txt,0,1)) = ?                                  " +
				" AND(last_name_txt IS NOT NULL AND id_txt IS NOT NULL)            ";

		try {

			qry.prepareStatement(sql);
			qry.setDate(1, initiation_dt);
			qry.setDate(2, initiation_dt);
			qry.setInt(3, evaluator_id);
			qry.setString(4, soc_sec_num_txt);
			qry.setString(5, soc_sec_num_txt);
			qry.setString(6, last_name_txt.toLowerCase().substring(0, 1));
			qry.executePreparedQuery();
			log.FmtAndLogMsg(" Found " + qry.getRowCount() + " SSN/LastName matches" );
			matches = processMatches(matches,qry);

		} catch (Exception e) {
			e.printStackTrace();
			log.FmtAndLogMsg(" Failed to lookup SSN/LastName matches ", e);

		}

		return matches;
	}

	/**
	 * processMatches 
	 * @param matches Current working copy of all solicitation matches
	 * @param qry A Query object containing columns 'solicitation_id' and 'match_type' to be added to your matches param
	 * @return The passed in param 'matches', merged with results from the qry
	 */
	private HashMap<String,String> processMatches(HashMap<String,String> matches, Query qry){
		try {
			while (qry.next()) {
				String key = qry.getColValue("solicitation_id");
				String value = qry.getColValue("match_type");

				// If the solicitation id already exists, but the match type doesn't, append it
				if (matches.containsKey(key) && !matches.get(key).contains(value)) {
					matches.put(key, matches.get(key) + " & " + value);
				}
				// If the solicitation id does not exist, add it
				else {
					matches.put(key, value);
				}
			} 
		}
		catch (Exception e) {

		}
		return matches;
	}

	/**
	 * 	Instantiate configuration from CONFIG_SOLICITATION_MATCHES
	 */
	private void initConfig(Connection conn, int requestId) {
		Query qry = new Query(conn);
		String sql = " SELECT * FROM CONFIG_SOLICITATION_MATCHES csm, credit_request cr WHERE request_id = ? AND cr.evaluator_id = csm.evaluator_id AND cr.product_id = csm.product_id";

		try {
			qry.prepareStatement(sql);
			qry.setInt(1, requestId);
			qry.executePreparedQuery();

			if (qry.next()) {
				matchOnAddressFlg = (qry.getColValue("MATCH_ON_ADDRESS_FLG") != null && qry.getColValue("MATCH_ON_ADDRESS_FLG").equals("1")) ? true : false;
				matchOnFullNameFlg = (qry.getColValue("MATCH_ON_FULL_NAME_FLG") != null && qry.getColValue("MATCH_ON_FULL_NAME_FLG").equals("1")) ? true : false;
				matchOnSolicitationIDFlg = (qry.getColValue("MATCH_ON_SOLICITATION_ID_FLG") != null && qry.getColValue("MATCH_ON_SOLICITATION_ID_FLG").equals("1")) ? true : false;
				matchOnFirstCharLastNameAndSSNFlg = (qry.getColValue("MATCH_ON_SSN_AND_LAST_NAME_FLG") != null && qry.getColValue("MATCH_ON_SSN_AND_LAST_NAME_FLG").equals("1")) ? true : false;
			}
			else {
				// If they don't have any configuration defined, default values accordingly.
				matchOnAddressFlg = true;
				matchOnFullNameFlg = true;
				matchOnSolicitationIDFlg = true;
				matchOnFirstCharLastNameAndSSNFlg = false;
			}
		} catch (Exception e) {
			log.FmtAndLogMsg("Failed to find config for Solicitation Alerts. Defaulting values...",e);
		}

		return;
	}

	/**
	 * 	Instantiate configuration from CONFIG_ENCRYPTION
	 */
	private void initEncryption(Connection conn, int request_id) {
		Query qry = new Query(conn);
		String sql = "select nvl(ssn_flg,0) ssn_flg, nvl(id_flg,0) id_flg from config_encryption ce, credit_request cr where cr.evaluator_id = ce.evaluator_id and cr.request_id = ?";

		try {
			qry.prepareStatement(sql);
			qry.setInt(1, request_id);
			qry.executePreparedQuery();

			if (qry.next()) {
				encryptedSSNFlg = (qry.getColValue("ssn_flg") != null && qry.getColValue("ssn_flg").equals("1")) ? true : false;
				encryptedIdFlg = (qry.getColValue("id_flg") != null && qry.getColValue("id_flg").equals("1")) ? true : false;
			}
		} catch (Exception e) {
			log.FmtAndLogMsg("Failed to find encryption values for Solicitation Alerts.",e);
		}

		return;
	}
} 


