/**
 * 
 */
package com.cmsinc.origenate.ae;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Iterator;

import com.cmsinc.origenate.util.LogMsg;
import com.cmsinc.origenate.util.PostRequest;
import com.cmsinc.origenate.util.Query;
import com.cmsinc.origenate.util.SQLUpdate;
import com.cmsinc.origenate.workflow.AppLockingManager;
import com.cmsinc.origenate.workflow.ApplicationStatusManager;
import com.cmsinc.origenate.workflow.WorkFlowManager;

/**
 * @author kylet
 */
public class SubmitAppForApproval {

	public void submitAppForApproval(LogMsg log_obj, String requestID, int i_dbg_lvl, Connection con,
			String evaluator_id, String rootUrl, int debugLevel) throws Exception {

		// THIS CODE IS LIFTED FROM LOANAPPRQ.JAVA IN THE POSTQUEUEPROCESSOR
		String appseqno = "";
		Query query = new Query(con);
		
		log_obj.FmtAndLogMsg("In the SubmitAppForApproval.java ***************************** req: id = " + requestID);

		
		/*
		 * CL141831: CREDIT_REQUEST_ACTIVITY.appseqno is null on external apps. Trigger get_all_activities_trigger fires
		 * after insert on credit_request and creates default activities and attempts to updates asn from
		 * credit_request_finance(??) Manual apps run act_saveinitapp.cfm to update asn. Need to add similar code here.
		 */
		try {
			
			query.prepareStatement("select appseqno from credit_request where request_id = ? ");
			query.setNumeric(1, requestID);
			query.executePreparedQuery();
			

			if (query.next()) {
				appseqno =  query.getColValue("appseqno", "");
				SQLUpdate sqlUpdate = new SQLUpdate();
				sqlUpdate.SetPreparedUpdateStatement(con,"update credit_request_activity set appseqno = ? "
						+ " where request_id = ? ");
				sqlUpdate.setNumeric(1, query.getColValue("appseqno", ""));
				sqlUpdate.setNumeric(2, requestID);
				sqlUpdate.RunPreparedUpdateStatement();
			}
		} catch (Exception e) {
			log_obj.FmtAndLogMsg("RID="+requestID+" - DEBUG MESSAGE: SubmitAppForApproval.java SubmitAppForApproval Constructor : Error updating credit_request_activity.asn from credit_request for requestId: "+requestID+" and evaluatorId: "+evaluator_id, e);
		}

		// need to calc age if birthdate is provided for each requestor

		calcAge(requestID, query, con, log_obj);

		/*
		 * For Finance Loans: Now that we have loaded the app, lets calc the finance fields that are calc'd from the
		 * descrete fields that come in on the app. We need to do this because the totalled up fields are used by the
		 * underwriting screens
		 */

		query.prepareStatement("select loan_type_id from credit_request where request_id = ? ");
		query.setNumeric(1, requestID);
		query.executePreparedQuery();

		String loanType = "";
		if (query.next())
			loanType = query.getColValue("loan_type_id");
		if (loanType == null)
			loanType = "";

		if (loanType.equals("1")) { // Finance loans

			/*
			 * For Finance Loans: Now that we have loaded the app, lets calc the finance fields that are calc'd from the
			 * descrete fields that come in on the app. We need to do this because the totalled up fields are used by the
			 * underwriting screens
			 */

			// log_obj.FmtAndLogMsg("Calculating finance rolled up fields...");
			try {
				query.prepareStatement("select calc_total_deal_adjustments( ? , ? ) as total_value from dual");
				query.setNumeric(1, requestID);
				query.setNumeric(2,evaluator_id);
				query.executePreparedQuery();
				
				query.next();
				String value = query.getColValue("total_value", "0");
				
				SQLUpdate sqlUpdate = new SQLUpdate();
				sqlUpdate.SetPreparedUpdateStatement(con, "update credit_request_loan set total_price_adjustment_num = ? "
						+ " where request_id = ? ");
				sqlUpdate.setNumeric(1, value);
				sqlUpdate.setNumeric(2, requestID);
				sqlUpdate.RunPreparedUpdateStatement();
				
				
				query.prepareStatement("select calc_total_financed_fees( ? , ? "
						+ ") as total_value from dual");
				query.setNumeric(1, requestID);
				query.setNumeric(2, evaluator_id);
				query.executePreparedQuery();
				
				query.next();
				value = query.getColValue("total_value", "0");
				
				sqlUpdate.SetPreparedUpdateStatement(con, "update credit_request_finance set total_finance_fee_num = ? "
						+ " where request_id = ? ");
				sqlUpdate.setNumeric(1, value);
				sqlUpdate.setNumeric(2, requestID);
				sqlUpdate.RunPreparedUpdateStatement();
				
				
				query.prepareStatement("select calc_net_trade_in_num( ? , ? ) as total_value from dual");
				query.setNumeric(1, requestID);
				query.setNumeric(2, evaluator_id);
				query.executePreparedQuery();
				
				query.next();
				value = query.getColValue("total_value", "0");
				
				sqlUpdate.SetPreparedUpdateStatement(con, "update credit_request_finance set net_trade_in_num = ? "
						+ " where net_trade_in_num is null and request_id = ? ");
				sqlUpdate.setNumeric(1, value);
				sqlUpdate.setNumeric(2, requestID);
				sqlUpdate.RunPreparedUpdateStatement();
				

				// GL. 02/02/04 Need to calc credit_request_auto.total_retail_num
				// = invoice_cost_num + equip_options_value_num

				
				sqlUpdate.SetPreparedUpdateStatement(con, "update credit_request_auto set "
						+ " total_retail_num = nvl(invoice_cost_num,0) + nvl(equip_options_value_num,0) + nvl(mileage_value_num,0) + nvl(other_adj_num,0)"
						+ " where request_id = ?  and total_retail_num = null");
				sqlUpdate.setNumeric(1, requestID);
				sqlUpdate.RunPreparedUpdateStatement();
				
				
				sqlUpdate.SetPreparedUpdateStatement(con, "update credit_req_auto_man set "
						+ " total_retail_num = nvl(invoice_cost_num,0) + nvl(equip_options_value_num,0) + nvl(other_adj_num,0)"
						+ " where request_id = ? ");
				sqlUpdate.setNumeric(1, requestID);
				sqlUpdate.RunPreparedUpdateStatement();
				

			} catch (Exception ex) {
			    log_obj.FmtAndLogMsg("RID="+requestID+" - DEBUG MESSAGE: SubmitAppForApproval.java SubmitAppForApproval Constructor : Warning: Problem calculating finance rolled up fields for requestId: "+requestID+" and evaluatorId: "+evaluator_id, ex);
				// not serious enough to log a NOLOAD
			}
		} // Finance loans

		if (loanType.equals("2")) { // Lease loans

			/*
			 * For Lease Loans: Now that we have loaded the app, lets calc the fields that are calc'd from the descrete
			 * fields that come in on the app. We need to do this because the totalled up fields are used by the
			 * underwriting screens
			 */

			// log_obj.FmtAndLogMsg("Calculating lease rolled up fields...");
			try {

				//query.executeQuery("select calc_total_financed_fees(" + requestID + "," + evaluator_id
				//		+ ") as total_value from dual");
				
				query.prepareStatement("select calc_total_financed_fees( ? , ? ) as total_value from dual");
				query.setNumeric(1, requestID);
				query.setNumeric(2, evaluator_id);
				query.executePreparedQuery();
				
				query.next();
				String value = query.getColValue("total_value", "0");
				
				SQLUpdate sqlUpdate = new SQLUpdate();
				sqlUpdate.SetPreparedUpdateStatement(con, "update credit_request_finance set total_finance_fee_num = ? "
						+ " where request_id = ? ");
				sqlUpdate.setNumeric(1, value);
				sqlUpdate.setNumeric(2, requestID);
				sqlUpdate.RunPreparedUpdateStatement();

				
				query.prepareStatement("select calc_net_trade_in_num( ? , ? ) as total_value from dual");
				query.setNumeric(1, requestID);
				query.setNumeric(2, evaluator_id);
				query.executePreparedQuery();
				
				query.next();
				value = query.getColValue("total_value", "0");
				
				sqlUpdate.SetPreparedUpdateStatement(con, "update credit_request_finance set net_trade_in_num = ? "
						+ " where net_trade_in_num is null and request_id = ? ");
				sqlUpdate.setNumeric(1, value);
				sqlUpdate.setNumeric(2, requestID);
				sqlUpdate.RunPreparedUpdateStatement();

				
				query.prepareStatement("select calc_total_other_cap_cost( ? , ? ) as total_value from dual");
				query.setNumeric(1, requestID);
				query.setNumeric(2, evaluator_id);
				query.executePreparedQuery();
				
				query.next();
				value = query.getColValue("total_value", "0");
				
				sqlUpdate.SetPreparedUpdateStatement(con, "update credit_request_lease set total_other_cap_cost_num = ? "
						+ " where request_id = ? ");
				sqlUpdate.setNumeric(1, value);
				sqlUpdate.setNumeric(2, requestID);
				sqlUpdate.RunPreparedUpdateStatement();

				
				query.prepareStatement("select calc_total_cap_cost( ? ,? ) as total_value from dual");
				query.setNumeric(1, requestID);
				query.setNumeric(2, evaluator_id);
				query.executePreparedQuery();
				
				query.next();
				value = query.getColValue("total_value", "0");
				
				sqlUpdate.SetPreparedUpdateStatement(con, "update credit_request_lease set total_capitalized_cost_num = ? " 
						+ " where request_id = ? ");
				sqlUpdate.setNumeric(1, value);
				sqlUpdate.setNumeric(2, requestID);
				sqlUpdate.RunPreparedUpdateStatement();
				
				
				query.prepareStatement("select calc_total_cap_reductions( ? , ? ) as total_value from dual");
				query.setNumeric(1, requestID);
				query.setNumeric(2, evaluator_id);
				query.executePreparedQuery();
				
				query.next();
				value = query.getColValue("total_value", "0");
				
				sqlUpdate.SetPreparedUpdateStatement(con, "update credit_request_lease set total_cap_cost_reductions_num = ? "
						 + " where request_id = ? ");
				sqlUpdate.setNumeric(1, value);
				sqlUpdate.setNumeric(2, requestID);
				sqlUpdate.RunPreparedUpdateStatement();

				
				query.prepareStatement("select calc_net_cap_cost( ? , ? ) as total_value from dual");
				query.setNumeric(1, requestID);
				query.setNumeric(2, evaluator_id);
				query.executePreparedQuery();
				
				query.next();
				value = query.getColValue("total_value", "0");
				
				sqlUpdate.SetPreparedUpdateStatement(con, "update credit_request_lease set total_net_cap_cost_num = ? "
						+ " where request_id = ? ");
				sqlUpdate.setNumeric(1, value);
				sqlUpdate.setNumeric(2, requestID);
				sqlUpdate.RunPreparedUpdateStatement();

				try {
					calcResidualValue(requestID, con);
				} catch (Exception e3) {
				    log_obj.FmtAndLogMsg("RID="+requestID+" - DEBUG MESSAGE: SubmitAppForApproval.java SubmitAppForApproval Constructor : Warning: Problem calculating lease residual value fields for requestId: "+requestID+" and evaluatorId: "+evaluator_id, e3);
				}

				// GL. 02/02/04 Need to calc credit_request_auto.total_retail_num
				// = invoice_cost_num + equip_options_value_num

			
				sqlUpdate.SetPreparedUpdateStatement(con, "update credit_request_auto set "
						+ " total_retail_num = nvl(invoice_cost_num,0) + nvl(equip_options_value_num,0) + nvl(mileage_value_num,0) + nvl(other_adj_num,0)"
						+ " where request_id = ? and total_retail_num = null");
				sqlUpdate.setNumeric(1, requestID);
				sqlUpdate.RunPreparedUpdateStatement();
				
				sqlUpdate.SetPreparedUpdateStatement(con, "update credit_req_auto_man set "
						+ " total_retail_num = nvl(invoice_cost_num,0) + nvl(equip_options_value_num,0) + nvl(other_adj_num,0)"
						+ " where request_id = ? ");
				sqlUpdate.setNumeric(1, requestID);
				sqlUpdate.RunPreparedUpdateStatement();
				
			} catch (Exception ex) {
			    log_obj.FmtAndLogMsg("RID="+requestID+" - DEBUG MESSAGE: SubmitAppForApproval.java SubmitAppForApproval Constructor : Warning: Problem calculating lease rolled up fields for requestId: "+requestID+" and evaluatorId: "+evaluator_id, ex);
				// not serious enough to log a NOLOAD
			}

		} // Lease loans

		// process requestor list

		long reqID = Long.parseLong(requestID);

		ArrayList<String> requestorIDList = new ArrayList<String>();
		ResultSet reqResultSet = null;
		PreparedStatement reqQuery = null;
		String tempRequestorID = "";
		//reqQuery = con.createStatement();
		try {
			reqQuery = con.prepareStatement("SELECT requestor_id, requestor_type_id " + "FROM requestor_header "
					+ "WHERE request_id = ? AND requestor_type_id >= 0 ORDER BY requestor_type_id desc");
			reqQuery.setLong(1, Long.parseLong(requestID));
			
			
			// order by requestor type so that if it is a business, it will be the first record (changing requestor type for
			// id 2 to guarantor instead of cosigner)
			reqResultSet = reqQuery.executeQuery();

			// Step 2: For each of those requestors, search all requestors to
			// determine if another requestor with the same SSN exists
			while (reqResultSet.next()) {
				tempRequestorID = reqResultSet.getString("requestor_id");
				requestorIDList.add(tempRequestorID);
			}
		}catch (Exception e) {
		   log_obj.FmtAndLogMsg("RID="+requestID+" - DEBUG MESSAGE: SubmitAppForApproval.java SubmitAppForApproval Constructor : FAILED to select from requestor_header for requestId: "+requestID+" and evaluatorId: "+evaluator_id, e);
		   e.printStackTrace();
		}
		finally {
			try{ if(reqResultSet != null) reqResultSet.close(); }catch(Exception e1){e1.printStackTrace();}
			try{ if(reqQuery != null) reqQuery.close(); }catch(Exception e1){e1.printStackTrace();}
		}
		// GL. 1/12/06 For each requestor we need to add at least 2 default
		// other_income records so that Loan Verification has rows to work with.
		// See issue: 135972 for details. Does not apply to business apps
		try {
			Query requestorQuery = new Query(con);
			Query incQuery = new Query(con);
			
			requestorQuery.prepareStatement("select appseqno,requestor_id,entity_txt from requestor where request_id = ? ");
			requestorQuery.setNumeric(1, requestID);
			requestorQuery.executePreparedQuery();
			
			String tmpRequestorID = "", tmpentity_txt="";
			int nextID = 0;
			while (requestorQuery.next()) {
				// for each requestor add two default if some not already there
				tmpRequestorID = requestorQuery.getColValue("requestor_id");
				
				// CL 157997 - dhavalt - Add appseqno & entity_txt into REQUESTOR_OTHER_INCOME table
				//appseqno = requestorQuery.getColValue("appseqno");
				tmpentity_txt = requestorQuery.getColValue("entity_txt");
				//System.out.println("dhaval: "+entity_txt+" appseqno: "+appseqno);
				incQuery.prepareStatement("select nvl(max(other_income_id),0) as nextincid from requestor_other_income where request_id = ? "
						+ " and evaluator_id = ? and requestor_id = ? ");
				incQuery.setNumeric(1, requestID);
				incQuery.setNumeric(2, evaluator_id);
				incQuery.setNumeric(3, tmpRequestorID);
				incQuery.executePreparedQuery();
				
				incQuery.next();
				nextID = Integer.parseInt(incQuery.getColValue("nextincid")) + 1;
				while (nextID <= 2) {
					
					SQLUpdate sqlUpdate = new SQLUpdate();
					sqlUpdate.SetPreparedUpdateStatement(con, "INSERT INTO REQUESTOR_OTHER_INCOME "
							+ "(REQUEST_ID,EVALUATOR_ID,REQUESTOR_ID,OTHER_INCOME_ID,INCOME_NUM,INCOME_BASIS_ID,GROSS_FLG,"
							+ "AUDIT_UPDATED_USER_ID,AUDIT_LAST_UPDATED_DT,INCOME_SOURCE_DESC_TXT,APPSEQNO,ENTITY_TXT) VALUES " + "( ? " 
							+ ", ? , ? , ? "
							+ ",0.00,'M',1,'SYSTEM',SYSDATE,'',?,?)");
					sqlUpdate.setNumeric(1, requestID);
					sqlUpdate.setNumeric(2, evaluator_id);
					sqlUpdate.setNumeric(3, tmpRequestorID);
					sqlUpdate.setNumeric(4, String.valueOf(nextID));
					sqlUpdate.setNumeric(5, appseqno);
					sqlUpdate.setString(6, tmpentity_txt);
					sqlUpdate.RunPreparedUpdateStatement();
					
					nextID++;
				}
				// we also need to add a default second current employer record if none exists yet
				
				incQuery.prepareStatement("select request_id from requestor_employer where request_id = ? "
						+ " and evaluator_id = ? and requestor_id = ? "
						+ " and second_current_employer_flg = 1");
				incQuery.setNumeric(1, requestID);
				incQuery.setNumeric(2, evaluator_id);
				incQuery.setNumeric(3, tmpRequestorID);
				incQuery.executePreparedQuery();
				
				if (!incQuery.next()) {
					
					incQuery.prepareStatement("select nvl(max(employer_id),0) as nextincid from requestor_employer where request_id = ? "
							+ " and evaluator_id = ? "
							+ " and requestor_id =  ? "
							);
					incQuery.setNumeric(1, requestID);
					incQuery.setNumeric(2, evaluator_id);
					incQuery.setNumeric(3, tmpRequestorID);
					incQuery.executePreparedQuery();
					
					incQuery.next();
					nextID = Integer.parseInt(incQuery.getColValue("nextincid")) + 1;
					
					SQLUpdate sqlUpdate = new SQLUpdate();
					sqlUpdate.SetPreparedUpdateStatement(con, "INSERT INTO REQUESTOR_EMPLOYER "
							+ "(REQUEST_ID,EVALUATOR_ID,REQUESTOR_ID,EMPLOYER_ID,INCOME_NUM,INCOME_BASIS_ID,GROSS_FLG,"
							+ "AUDIT_UPDATED_USER_ID,AUDIT_LAST_UPDATED_DT,CURRENT_EMPLOYER_FLG,SECOND_CURRENT_EMPLOYER_FLG) VALUES "
							+ "( ? , ? , ? , ? "
							+ ",0.00,'A',1,'SYSTEM',SYSDATE,1,1)");
					sqlUpdate.setNumeric(1, requestID);
					sqlUpdate.setNumeric(2, evaluator_id);
					sqlUpdate.setNumeric(3, tmpRequestorID);
					sqlUpdate.setNumeric(4, String.valueOf(nextID));
					sqlUpdate.RunPreparedUpdateStatement();
				}
			}
		} catch (Exception e) {
			// Not serious enough to abort so just log error
			log_obj.FmtAndLogMsg("RID="+requestID+" - DEBUG MESSAGE: SubmitAppForApproval.java SubmitAppForApproval Constructor : Warning, could not add default other_income or employer rows for requestId: "+requestID+" and evaluatorId: "+evaluator_id, e);
		}

		// ////////// completion checks ////////////////////

		/*
		 * DISABLING COMPLETION CHECK BECAUSE THE SCREENS WILL SET ALL REQUIRED FIELDS AND WE DO NOT WANT TO WASTE TIME
		 * MAKING A POSTING CALL TO ORIGENATE. HOWEVER, WE STILL NEED TO SET THE ACTIVITY STATUS
		 */

		ApplicationStatusManager appStatusMgr = new ApplicationStatusManager(con, log_obj);

		// appStatusMgr.setActivityStatus(reqID, "APPENTRY", 2, 3, "SYSTEM", -1);

		/************/

		log_obj.FmtAndLogMsg("LoanAppRq: RID=" + requestID + ", Calling completion checks...", debugLevel, 5);

		// Call Completion Check to insure that this app has all required data

		String ccURL = rootUrl + "/rules/default.cfm?fuse_action=fuseCompletionCheckDisplayExternal";
		String CC_RESPONSE_BEG_TAG = "<RESPONSE";
		String CC_RESPONSE_TYPE = "type";
		String CC_RESPONSE_COMMENT = "comment";

		ccURL = ccURL + "&request_id=" + requestID + "&user_id=" + "SYSTEM" + "&evaluator_id=" + evaluator_id;
		String response = "";
		boolean failedCCFlg = false;

		try {
			PostRequest postRequest = new PostRequest(log_obj, i_dbg_lvl);
			response = postRequest.post(ccURL, "", 0);
		} catch (Exception e) {
            log_obj.FmtAndLogMsg("RID="+requestID+" - DEBUG MESSAGE: SubmitAppForApproval.java SubmitAppForApproval Constructor : COMPLETEION CHECK POST ERROR:  Error posting to:" + ccURL + " for requestId: "+requestID+" and evaluatorId: "+evaluator_id, e);
			failedCCFlg = true;

		}

		int beg = 0;
		int end = 0;
		String respType = "";
		String respComment = "";

		// Parse out type and comment from response
		if (!failedCCFlg)
			if ((beg = response.indexOf(CC_RESPONSE_BEG_TAG)) >= 0) {

				beg = response.indexOf(CC_RESPONSE_TYPE, beg) + CC_RESPONSE_TYPE.length() + 2;
				end = response.indexOf("\"", beg + 1);

				respType = response.substring(beg, end);

				if (respType.equals("ERROR")) {

					appStatusMgr.setActivityStatus(reqID, "APPENTRY", 2, 1, "SYSTEM", -1);
					appStatusMgr.setActivityStatus(reqID, "UNDERWRITING", 8, 1, "SYSTEM", -1);

					failedCCFlg = true;

					beg = response.indexOf(CC_RESPONSE_COMMENT, end) + CC_RESPONSE_COMMENT.length() + 2;
					end = response.indexOf("\"", beg);

					if (end > beg)
						respComment = response.substring(beg, end);
					else
						respComment = "No Completion Reasons Returned";

					log_obj.FmtAndLogMsg("Warning: Completion check failed, reasons: " + respComment);

				} else { // if success then update missing / completion activities

					log_obj.FmtAndLogMsg("Success in completion check request: " + reqID, debugLevel, 5);

					appStatusMgr.setActivityStatus(reqID, "APPENTRY", 2, 3, "SYSTEM", -1);
					// appStatusMgr.setActivityStatus(reqID, "UNDERWRITING", 8, 3, "SYSTEM", -1);

				}
			}
		// ///////////// end completion checks ////////////////////

		/*********************************/

		log_obj.FmtAndLogMsg("Saving application data: RID=" + requestID + ", Lock app for scoring...", debugLevel, 5);

		// Lock the app prior to calling eValuate for scoring
		AppLockingManager appLockingManager = new AppLockingManager(con, log_obj);

		try {
			SQLUpdate sqlUpdate = new SQLUpdate();
			sqlUpdate.SetPreparedUpdateStatement(con, "delete from concurrency_control where request_id = ? ");
			sqlUpdate.setNumeric(1, requestID);
			sqlUpdate.RunPreparedUpdateStatement();

			appLockingManager.setLockOnApp(reqID, "SYSTEM", 1, "Locked for Evaluation");
		} catch (Exception e) {
		    log_obj.FmtAndLogMsg("RID="+requestID+" - DEBUG MESSAGE: SubmitAppForApproval.java SubmitAppForApproval Constructor : FAILED to delete from concurrency_control for requestId: "+requestID+" and evaluatorId: "+evaluator_id, e);
			throw (e);
		}

		log_obj.FmtAndLogMsg("SaveAppData (portal): RID=" + requestID + ", Set task group to APPENTRY...", debugLevel, 5);

		// Set default default activity on app

		// Query the database to retrieve the product ID
		PreparedStatement prodStmt = null;
		ResultSet prodResultSet = null;
		int productID = -1;
		int evaluatorID = Integer.parseInt(evaluator_id);
		String product_id = "-1";

		try {

			prodStmt = con.prepareStatement("SELECT product_id " + "FROM credit_request WHERE evaluator_id = ? "
					+ " AND request_id = ? ");
			prodStmt.setLong(1, evaluatorID);
			prodStmt.setLong(2, Long.parseLong(requestID));
			
			prodResultSet = prodStmt.executeQuery();

			if (prodResultSet.next()) {
				productID = prodResultSet.getInt("product_id");
				product_id = prodResultSet.getString("product_id");
			}

		} catch (Exception e) {
		    try{ if(prodResultSet != null) prodResultSet.close(); }catch(Exception e1){e1.printStackTrace();}
			try{ if(prodStmt != null) prodStmt.close(); }catch(Exception e1){e1.printStackTrace();}
			throw new Exception("Error setting workflow status: " + e, e);
		} finally {
			try{ if(prodResultSet != null) prodResultSet.close(); }catch(Exception e1){e1.printStackTrace();}
			try{ if(prodStmt != null) prodStmt.close(); }catch(Exception e1){e1.printStackTrace();}
		}

		// GL. 5/12/04 Try mving it to the SCORING task in the SYSTEM group
		// and if unsuccessful then move it to the default task in APPENTRY

		WorkFlowManager wfm = new WorkFlowManager(con, log_obj);

		query.prepareStatement("select evaluator_id from xref_tasks_in_task_group where evaluator_id = ? "
				+ " and product_id = ? "
				+ " and task_id = 'SCORING' AND TASK_GROUP_ID = 'SYSTEM' AND ACTIVE_FLG = 1");
		query.setNumeric(1, evaluator_id);
		query.setNumeric(2, product_id);
		query.executePreparedQuery();
		
		boolean worked = false;
		if (query.next()) {
			try {
				// until the prob w/wfm is resolved do it manually, wfm is always throwing a integ constraint on
				// xref_tasks_in_task_group even though the keys are there
				// worked=wfm.setNewTaskandTaskGroup(reqID,"SCORING", "SYSTEM", "SYSTEM");
				SQLUpdate sqlUpdate = new SQLUpdate();
				
				sqlUpdate.SetPreparedUpdateStatement(con,"update credit_request set task_id = 'SCORING', TASK_GROUP_ID = 'APPENTRY', AUDIT_UPDATED_user_id = 'SYSTEM', AUDIT_LAST_UPDATED_DT = SYSDATE WHERE REQUEST_ID = ? "
						);
				sqlUpdate.setNumeric(1, requestID);
				sqlUpdate.RunPreparedUpdateStatement();

				// Now add app history
				sqlUpdate.SetPreparedUpdateStatement(con, "insert into CREDIT_REQUEST_APP_HISTORY "
						+ "(request_id,evaluator_id,seq_num,user_id,start_task_id,start_app_status_id,start_dt,appseqno,team_id)"
						+ " VALUES( ? ,? "
						+ ",1,'SYSTEM','SCORING',0,sysdate,(select appseqno from credit_request where request_id= ?)"
						+ ",(select team_id from users where user_id = 'SYSTEM'))");
				sqlUpdate.setNumeric(1, requestID);
				sqlUpdate.setNumeric(2, String.valueOf(evaluatorID));
				sqlUpdate.setNumeric(3, requestID);
				sqlUpdate.RunPreparedUpdateStatement();
				
				worked = true;
			} catch (Exception e) {
				worked = false;
				log_obj.FmtAndLogMsg("RID="+requestID+" - DEBUG MESSAGE: SubmitAppForApproval.java SubmitAppForApproval Constructor : FAILED to set SCORING task for requestId: "+requestID+" and evaluatorId: "+evaluator_id, e,
						debugLevel, 0);
			} // err recored
		} else
			worked = false;

		if (!worked) {
			log_obj
					.FmtAndLogMsg("Warning: RID=" + requestID
							+ ", SCORING task not defined for task group SYSTEM, using default APPENTRY task instead",
							debugLevel, 0);
			String defaultTask = wfm.getDefaultTask("APPENTRY", "", evaluatorID, productID);
			if (defaultTask.length() == 0)
				log_obj.FmtAndLogMsg("Warning: RID=" + requestID + ", No default task defined for APPENTRY, task not set",
						debugLevel, 0);
			else {
				// until the prob w/wfm is resolved do it manually, wfm is always throwing a integ constraint on
				// xref_tasks_in_task_group even though the keys are there
				// if (!wfm.setNewTaskandTaskGroup(reqID, defaultTask, "APPENTRY", "SYSTEM"))
				// log_obj.FmtAndLogMsg("Warning: RID="+requestID+", failed to set default task",i_dbg_lvl,0);
				try {
					SQLUpdate sqlUpdate = new SQLUpdate();
					sqlUpdate.SetPreparedUpdateStatement(con, "update credit_request set task_id = ? "
							+ ", TASK_GROUP_ID = 'APPENTRY', AUDIT_UPDATED_user_id = 'SYSTEM', AUDIT_LAST_UPDATED_DT = SYSDATE WHERE REQUEST_ID = ? "
							);
					sqlUpdate.setString(1, defaultTask);
					sqlUpdate.setNumeric(2, requestID);
					sqlUpdate.RunPreparedUpdateStatement();

					// Now add app history
					sqlUpdate.SetPreparedUpdateStatement(con, "insert into CREDIT_REQUEST_APP_HISTORY "
							+ "(request_id,evaluator_id,seq_num,user_id,start_task_id,start_app_status_id,start_dt,appseqno,team_id)"
							+ " VALUES( ? , ? ,1,'SYSTEM', ? "
							+ ",0,sysdate,(select appseqno from credit_request where request_id= ? )"
							+ ",(select team_id from users where user_id = 'SYSTEM'))");
					sqlUpdate.setNumeric(1, requestID);
					sqlUpdate.setNumeric(2, String.valueOf(evaluatorID));
					sqlUpdate.setString(3, defaultTask);
					sqlUpdate.setNumeric(4, requestID);
					sqlUpdate.RunPreparedUpdateStatement();
					
				} catch (Exception e) {
				    log_obj.FmtAndLogMsg("RID="+requestID+" - DEBUG MESSAGE: SubmitAppForApproval.java SubmitAppForApproval Constructor : FAILED to set default task:"+defaultTask+" for requestId: "+requestID+" and evaluatorId: "+evaluator_id, e,
						debugLevel, 0);
				}
			}
		}

		String scriptID = "1"; // score
		String touchPointID = "1"; // app complete
		boolean rescoreRequired = false;

		if (rescoreRequired) {
			log_obj.FmtAndLogMsg("INFO: received update to app, request_id=" + requestID
					+ ", No change to requestor's, hence a rescore instead of score will occur", debugLevel, 5);
			scriptID = "6"; // rescore
			touchPointID = "1"; // app data changed
		} else {
			log_obj.FmtAndLogMsg("SaveAppData (portal): RID=" + requestID
					+ ", Placing scoring request on Routing Queue...", debugLevel, 5);
		}

		// Add entry to evaluate request queue
		Iterator<String> requestorIDListIter = requestorIDList.iterator();

		while (requestorIDListIter.hasNext()) {

			log_obj.FmtAndLogMsg("SaveAppData (portal): RID=" + requestID
					+ ", Insert to evaluate_request_queue for each requestor...", debugLevel, 5);
			StringBuffer erqStringBuf = new StringBuffer();

			erqStringBuf.append("INSERT INTO evaluate_request_queue (");
			erqStringBuf
					.append("evaluate_request_queue_id, request_id, requestor_id, script_id, comment_txt, user_id, requested_dt, touchpoint_id");
			erqStringBuf.append(") VALUES(");
			erqStringBuf.append("EVALUATE_REQUEST_QUEUE_SEQ.nextval,?,?," + scriptID + ",?,?,SYSDATE," + touchPointID);
			erqStringBuf.append(")");

			PreparedStatement erqps = null;

			try {

				erqps = con.prepareStatement(erqStringBuf.toString());
				erqps.setInt(1, Integer.parseInt(requestID));
				erqps.setInt(2, Integer.parseInt((String) requestorIDListIter.next()));
				erqps.setString(3, "Created by LoanAppRq.java");
				erqps.setString(4, "SYSTEM");
				erqps.execute();

			} catch (SQLException e) {
			    try{ if(erqps != null) erqps.close(); }catch(Exception e1){e1.printStackTrace();}
				throw (e);
			} finally {
				try{ if(erqps != null) erqps.close(); }catch(Exception e1){e1.printStackTrace();}
			}

		}

		String routingStateID = "13";
		String evalURL = "";

		evalURL = rootUrl + "/evaluation/default.cfm?fuse_action=app_complete&request_id=";

		String addlData = "CF_URL," + evalURL + requestID + "&evaluator_id=" + evaluator_id;

		StringBuffer rqStringBuf = new StringBuffer();

		rqStringBuf.append("INSERT INTO routing_queue(");
		rqStringBuf
				.append("routing_queue_id, request_id, queue_priority_num, routing_state_id, run_dt, tries_num, additional_data_txt");
		rqStringBuf.append(") VALUES(");
		rqStringBuf.append("ROUTING_QUEUE_SEQ.nextval," + requestID + ",100," + routingStateID + ",SYSDATE,0,'"
				+ addlData + "')");

		SQLUpdate.RunUpdateStatement(con, rqStringBuf.toString());

		// If we just updated an app then we need to reset the
		// app status, decision_status and activities that were marked as complete.
		// We are doing this to make it look like a new app has come in and is being scored

		try {
			// SQLUpdate.RunUpdateStatement(con,
			// "update credit_request set app_status_id = 0, decision_status_id = null where request_id = "+requestID);
			// SQLUpdate.RunUpdateStatement(con,
			// "update credit_request_activity set activity_status_id = 1,audit_updated_user_id = 'SYSTEM',audit_last_updated_dt = sysdate where request_id = "
			// +requestID+" and activity_status_id in (2,3)");
			boolean payment_call_flg = false;
			//query.executeQuery("select payment_call_flg from credit_request where request_id = " + reqID);
			query.prepareStatement("select payment_call_flg from credit_request where request_id = ? ");
			query.setNumeric(1, String.valueOf(reqID));
			query.executePreparedQuery();
			
			if (query.next()) {
				String test = query.getColValue("payment_call_flg");
				payment_call_flg = (test != null && test.equals("1"));
			}

			// If this is not a payment call, set payment call activity to complete,
			// and set decision activity to incomplete.
			if (!payment_call_flg) {
				// Decision = incomplete
				appStatusMgr.setActivityStatus(reqID, "UNDERWRITING", 6, 1, "SYSTEM", -1);
				// Payment call = complete
				appStatusMgr.setActivityStatus(reqID, "UNDERWRITING", 7, 3, "SYSTEM", -1);
			}

			// Calculate application status
			appStatusMgr.calcNewApplicationStatus(reqID, evaluatorID);

		} catch (Exception e) {
		    log_obj.FmtAndLogMsg("RID="+requestID+" - DEBUG MESSAGE: SubmitAppForApproval.java SubmitAppForApproval Constructor : Could not calculate status for this updated app for requestId: "+requestID+" and evaluatorId: "+evaluator_id+ ", err=", e);
		}
		
		log_obj.FmtAndLogMsg("In the SubmitAppForApproval.java: DONE ***************************** ");
	}

	void calcAge(String requestID, Query query, Connection con, LogMsg log_obj) {

		String birthDate = "";
		String requestor_id = "";
		Calendar today = Calendar.getInstance();
		SimpleDateFormat dateFormatter = new SimpleDateFormat("MM/dd/yyyy");

		try {
			// for each requestor calc age if birthdate is provided
			query.prepareStatement("select to_char(birth_dt,'MM/DD/YYYY') as birth_dt,requestor_id from requestor where request_id = ? "
					+ " and birth_dt is not null");
			query.setNumeric(1, requestID);
			query.executePreparedQuery();
			
			while (query.next()) {
				birthDate = query.getColValue("birth_dt");
				requestor_id = query.getColValue("requestor_id");

				/*
				 * CL139490 ChrisN - If birth date has same month, day as tomorrow or day after tomorrow age was calculated
				 * with one extra year Commented out old logic using seconds calc & added new code (further down) using
				 * Calendar methods. date = dateFormatter.parse(birthDate); diff=today.getTime()-date.getTime(); // there
				 * are 86,400,000 milliseconds in a day // covert diff to years age= (long)(diff / (864e5 365));
				 */

				Calendar bdatecal = Calendar.getInstance();
				bdatecal.setTime(dateFormatter.parse(birthDate));

				// Get age based on year
				int age = today.get(Calendar.YEAR) - bdatecal.get(Calendar.YEAR);

				// Add the tentative age to the date of birth to get this year's birthday
				bdatecal.add(Calendar.YEAR, age);

				// If this year's birthday has not happened yet, subtract one from age
				if (today.before(bdatecal)) {
					age--;
				}

				// log_obj.FmtAndLogMsg("Age="+age);
				SQLUpdate sqlUpdate = new SQLUpdate();
				sqlUpdate.SetPreparedUpdateStatement(con, "update requestor set age_num = ? where request_id = ? "
						+ " and requestor_id = ? ");
				sqlUpdate.setNumeric(1, String.valueOf(age));
				sqlUpdate.setNumeric(2, requestID);
				sqlUpdate.setNumeric( 3, requestor_id);
				sqlUpdate.RunPreparedUpdateStatement();
				
			} // for each requestor

		} catch (Exception e) {
		    log_obj.FmtAndLogMsg("RID="+requestID+" - DEBUG MESSAGE: SubmitAppForApproval.java calcAge Method : Error calculating age for requestId: "+requestID, e);
			// not serious enough to stop further processing
		}

		return;
	} // calcAge

	void calcResidualValue(String request_id, Connection con) throws Exception {
        LogMsg log_obj = new LogMsg();
		Query query = new Query(con);

		query.prepareStatement("select nvl(ca.new_used_flg,1) as new_flg,nvl(ca.msrp_num,0) as msrp, "
				+ "nvl(ca.invoice_cost_num,0) invoice, nvl(cl.residual_percentage_num,0) as residual_percentage_num from "
				+ "credit_request_lease cl, credit_request_auto ca,credit_request_collateral cc where "
				+ "cl.request_id = ? and cc.request_id = cl.request_id "
				+ "and cc.collateral_type_id = 0 and cc.request_id = ca.request_id "
				+ "and cc.collateral_request_id = ca.collateral_request_id " + "and ca.credit_request_auto_id = 1");
		query.setNumeric(1,request_id);
		query.executePreparedQuery();
		
		
		if (query.next()) {
			String newFlag = query.getColValue("new_flg");
			String msrp = query.getColValue("msrp");
			String invoice = query.getColValue("invoice");
			String residualPercentage = query.getColValue("residual_percentage_num");
			float fmsrp = 0, finvoice = 0, fresidualPercentage = 0, fresidualValue = 0;

			// log_obj.FmtAndLogMsg(newFlag+" "+msrp+" "+invoice+" "+residualPercentage);
			try {
				fmsrp = Float.parseFloat(msrp);
			} catch (Exception e) {
			    log_obj.FmtAndLogMsg("RID="+request_id+" - DEBUG MESSAGE: SubmitAppForApproval.java calcResidualValue Method : Error calculating residual value for requestId: "+request_id+" and fmsrp: "+fmsrp, e);
				throw new Exception("Error calculating residual value: " + e.toString(), e);
			}
			try {
				finvoice = Float.parseFloat(invoice);
			} catch (Exception e) {
			    log_obj.FmtAndLogMsg("RID="+request_id+" - DEBUG MESSAGE: SubmitAppForApproval.java calcResidualValue Method : Error calculating residual value for requestId: "+request_id+" and finvoice: "+finvoice, e);
				throw new Exception("Error calculating residual value: " + e.toString(), e);
			}
			try {
				fresidualPercentage = Float.parseFloat(residualPercentage);
			} catch (Exception e) {
			    log_obj.FmtAndLogMsg("RID="+request_id+" - DEBUG MESSAGE: SubmitAppForApproval.java calcResidualValue Method : Error calculating residual value for requestId: "+request_id+" and fresidualPercentage: "+fresidualPercentage, e);
				throw new Exception("Error calculating residual value: " + e.toString(), e);
			}

			if (newFlag.equals("1"))
				fresidualValue = fmsrp * fresidualPercentage;
			else
				fresidualValue = finvoice * fresidualPercentage;
			
			SQLUpdate sqlUpdate = new SQLUpdate();
			sqlUpdate.SetPreparedUpdateStatement(con, "update credit_request_lease set residual_value_num = ? "
					+ " where request_id = ? ");
			sqlUpdate.setNumeric(1, String.valueOf(fresidualValue));
			sqlUpdate.setNumeric(2, request_id);
			sqlUpdate.RunPreparedUpdateStatement();
		} else
			throw new Exception("Collateral not found to calc residual_value");

	} // residualValue()

}
