package com.cmsinc.origenate.ae;

public class ChangedBorrowerContainerBean {
	private String entityTxt;
	private int requestorTypeId;
	private int requestorId;
	private String SSNTxt;
	
	/*constructor used by LoanAppRq */
	public ChangedBorrowerContainerBean(String entityTxt, int requestorTypeId, int requestorId, String SSNTxt){
		this.entityTxt = entityTxt;
		this.requestorTypeId = requestorTypeId;
		this.requestorId = requestorId;
		this.SSNTxt = SSNTxt;
	}
	
	/*constructor used by LoanAppRq */
	public ChangedBorrowerContainerBean(String entityTxt, int requestorTypeId, String SSNTxt){
		this.entityTxt = entityTxt;
		this.requestorTypeId = requestorTypeId;
		this.SSNTxt = SSNTxt;
	}
	
	/* constructor used by dataentr/action/act_saveborrowerposition.cfm */
	public ChangedBorrowerContainerBean(String entityTxt, int requestorTypeId, int requestorId){
		this.entityTxt = entityTxt;
		this.requestorTypeId = requestorTypeId;
		this.requestorId = requestorId;
	}
	
	public String getEntityTxt() {
		return entityTxt;
	}
	public void setEntityTxt(String entityTxt) {
		this.entityTxt = entityTxt;
	}
	public int getRequestorTypeId() {
		return requestorTypeId;
	}
	public void setRequestorTypeId(int requestorTypeId) {
		this.requestorTypeId = requestorTypeId;
	}
	public int getRequestorId() {
		return requestorId;
	}
	public void setRequestorId(int requestorId) {
		this.requestorId = requestorId;
	}
	public String getSSNTxt() {
		return SSNTxt;
	}
	public void setSSNTxt(String sSNTxt) {
		SSNTxt = sSNTxt;
	}
	
}