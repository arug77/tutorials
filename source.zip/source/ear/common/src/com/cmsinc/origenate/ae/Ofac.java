/*
 * Ofac.java
 *
 * Created on June 20, 2003
 *
 */

package com.cmsinc.origenate.ae;

import java.sql.*;

import oracle.jdbc.OracleDriver;
import com.cmsinc.origenate.util.LogMsg;
import com.cmsinc.origenate.util.COLEncrypt;
import com.cmsinc.origenate.util.IniFile;
import com.cmsinc.origenate.event.CommentEvents;
import com.cmsinc.origenate.util.Query;

/**
 *
 * @author  brads
 * @version 1.0
 *
 * request_id - the application to perform the OFAC check
 */
public class Ofac extends Object {
    private Connection conn;
    private LogMsg log = new LogMsg();
    private String s_log_file = "";
    /**
    * RequestorAlert Object - used to check application for possible fraud or rego matches
    */

    // Ofac constructor that creates its own db connection
    public Ofac(String argHost, String argSid, String argUserName, String argPwd, String argLogName, String argPort,String tnsEntry) throws Exception {
        s_log_file = argLogName;
        if (argLogName!=null && argLogName.length()>0)
		log.openLogFile(argLogName);

        //String conStr = "jdbc:oracle:thin:@" + argHost + ":" + argPort + ":" + argSid;

        // 150165 - use tns entry if present
        String conStr = "jdbc:oracle:thin:@";
                       if (tnsEntry.equals("")) {
                               conStr = conStr + argHost + ":" + argPort + ":" + argSid;
                       } else {
                               conStr = conStr + tnsEntry;
                       }

        try {
            // Load Oracle driver
            DriverManager.registerDriver (new oracle.jdbc.OracleDriver());

            // Connect to the Oracle database
            this.conn = DriverManager.getConnection (conStr,argUserName,COLEncrypt.sDecrypt(argPwd));
        }
        catch (SQLException e) {
           if (s_log_file!=null && s_log_file.length()>0)
            log.FmtAndLogMsg("DEBUG MESSAGE: Ofac.java Ofac Constructor : Error problem with db connection in constructor " + getClass(), e);
            throw new Exception("Database connect error:"+e.toString(), e);
        }

    }
	
    /******************************   GL. 163319 - Should use TNS constructor instead

    public Ofac(String argHost, String argSid, String argUserName, String argPwd, String argLogName, String argPort) throws Exception {
        s_log_file = argLogName;
        if (argLogName!=null && argLogName.length()>0)
		log.openLogFile(argLogName);

        String conStr = "jdbc:oracle:thin:@" + argHost + ":" + argPort + ":" + argSid;


        try {
            // Load Oracle driver
            DriverManager.registerDriver (new oracle.jdbc.OracleDriver());

            // Connect to the Oracle database
            this.conn = DriverManager.getConnection (conStr,argUserName,COLEncrypt.sDecrypt(argPwd));
        }
        catch (SQLException e) {
           if (s_log_file!=null && s_log_file.length()>0)
            log.FmtAndLogMsg("Error problem with db connection in constructor " + getClass());
            throw new Exception("Database connect error:"+e.toString());
        }

    }

    ***********************/
        
	
    // Ofac constructor that allows a db connection to be passed
    public Ofac(Connection argCon, String argLogName) throws Exception {
        s_log_file = argLogName;
        if (argLogName!=null && argLogName.length()>0)
            log.openLogFile(argLogName);

	this.conn = argCon;
        if (this.conn == null) {
           if (s_log_file!=null && s_log_file.length()>0)
            log.FmtAndLogMsg("Error problem with db connection in constructor " + getClass());
            throw new Exception("Error invalid connection." + getClass());
        }
    }


    public void cleanup() {
        try {conn.close();} catch (Exception ec) {}
        if (s_log_file.length()>0) try {log.closeLogFile(); } catch (Exception e3) {}
    }

    // ofac method checks application for potential ofac violations
    public void ofac(int request_id) throws Exception {
        ResultSet rs = null;
        ResultSet ofac_rs = null;
        PreparedStatement update_stmt = null;
		PreparedStatement ofac_ps = null;
        String comment = "";
		String ofac_txt = null;
		int ofac_flg = -1;
		int biz_str_len;
	    PreparedStatement ps = null;
		String wildcard = "%";
        
        // make sure db connection is available
        if (conn != null){

           try {    
                if (!isEnabled(conn, request_id)) {
                    log.FmtAndLogMsg("Checking OFAC for this evaluator is turned off. Skipping OFAC Lookup.");
                    return;
                }
               
                // retrieve all requestor names for this application
				// (CL 163300)for ofac as of the addition of a second last name, we want to check ofac records for the applicant with and without the second last name
                String s_sql =  "select Replace(Upper(last_name_txt|| " +
					" CASE "+
					" WHEN second_last_name_txt IS NULL THEN '' "+
					" ELSE (' ' ||second_last_name_txt) "+
					" END "+
					" || ' '||first_name_txt||decode(middle_name_txt,'','',' '||Substr(middle_name_txt,1,1))),chr(39),chr(39)||chr(39)) as full_name_txt, "+
					" Replace(Upper(last_name_txt|| ' ' ||first_name_txt||decode(middle_name_txt,'','',' '|| " + 
					" Substr(middle_name_txt,1,1))),chr(39),chr(39)||chr(39)) as partial_full_name_txt, " +
					" requestor_id "+
                                "from requestor "+
                                "where request_id= ? ";
  	            ps = conn.prepareStatement(s_sql);
	            ps.setInt(1, request_id);

	            rs = ps.executeQuery();
                
                // check each requestor against ofac tables
                while (rs.next()) {
					String partialFullName = rs.getString("partial_full_name_txt");
					String fullName = rs.getString("full_name_txt");

					ofac_txt = "F";
                    ofac_flg = 0;
                    // search for ofac matches on the sdn table
                    s_sql = "select sdn_id "+
                            "from ofac_sdn "+
                            "where sdn_type_id = 'I' "+
                            "and (Upper(full_name_txt) like ? ";
					if(!partialFullName.equals(fullName)){ //if they aren't equal that means that a second last name exists, we should check the ofac list again the user with & without the second last name (CL 163300)
						s_sql += " or Upper(full_name_txt) like ? ";
					}
					s_sql += ")"; //close the full name section of the sql statement
					ofac_ps = conn.prepareStatement(s_sql);
					ofac_ps.setString(1,fullName + wildcard);
					if(!partialFullName.equals(fullName)){
						ofac_ps.setString(2,partialFullName + wildcard);
					}
					
                    ofac_rs = ofac_ps.executeQuery();
					
                    // set ofac comment
                    if (ofac_rs.next()) {
                        comment += "OFAC SDN MATCH - "+ofac_rs.getInt("sdn_id")+"; ";
						ofac_txt = "T";
						ofac_flg = 1;		
                    }    

                    try{ if(ofac_rs != null) ofac_rs.close(); }catch(Exception e1){e1.printStackTrace();}
					try{ if(ofac_ps != null) ofac_ps.close(); }catch(Exception e1){e1.printStackTrace();}
                    // search for ofac matches on the alt table
                    s_sql = "select sdn_id "+
                            "from ofac_alt "+
                            "where Upper(full_name_txt) like ? ";
                    ofac_ps = conn.prepareStatement(s_sql);
					ofac_ps.setString(1,fullName + wildcard);

					ofac_rs = ofac_ps.executeQuery();
                    // set ofac comment
                    if (ofac_rs.next()) {
                        comment += "OFAC ALT MATCH - "+ofac_rs.getInt("sdn_id")+"; ";
						ofac_txt = "T";
                        ofac_flg = 1;
                    }    
                    try{ if(ofac_rs != null) ofac_rs.close(); }catch(Exception e1){e1.printStackTrace();}
					try{ if(ofac_ps != null) ofac_ps.close(); }catch(Exception e1){e1.printStackTrace();}
                    // update requestor's corresponding flag on every ofac check (in case he previously had a match and now does not)
                    s_sql = "update requestor "+
                            "set ofac_flg = ? "+
                            "where request_id = ? and requestor_id = ?";

                    update_stmt = conn.prepareStatement(s_sql);
					update_stmt.setString(1, ofac_txt);
					update_stmt.setInt(2, request_id);
					update_stmt.setInt(3,rs.getInt("requestor_id"));
                    update_stmt.execute();
					try{ if(update_stmt != null) update_stmt.close(); }catch(Exception e1){e1.printStackTrace();}
                }

                try{ if(rs != null) rs.close(); }catch(Exception e1){e1.printStackTrace();}
			    try{ if(ps != null) ps.close(); }catch(Exception e1){e1.printStackTrace();}
                // check app type
                s_sql = "select personal_flg "+
                        "from credit_request "+
                        "where request_id= ? ";
  	            ps = conn.prepareStatement(s_sql);
	            ps.setInt(1, request_id);

	            rs = ps.executeQuery();
                rs.next();
                
                // if it is a business app, check it against ofac tables
                if (rs.getInt("personal_flg") == 0) {               

					try{ if(rs != null) rs.close(); }catch(Exception e1){e1.printStackTrace();}
			        try{ if(ps != null) ps.close(); }catch(Exception e1){e1.printStackTrace();}
                    // get business phone
                    s_sql = "select Replace(Upper(business_name_txt),chr(39),chr(39)||chr(39)) as business_name_txt, length(business_name_txt) as biz_len "+
                            "from requestor_business "+
                            "where request_id= ? ";
      	            ps = conn.prepareStatement(s_sql);
    	            ps.setInt(1, request_id);

    	            rs = ps.executeQuery();
                    
                    if (rs.next()) {
						String businessName = rs.getString("business_name_txt");
						ofac_txt = "F";
                        ofac_flg = 0;
						
						// dealertrack only supports 24 char for business name
						// therefore we will match business names <= 24 char against first 24 char in ofac
						// otherwise we will match n char in ofac, where n is the char length of business name
						if (rs.getInt("biz_len") <= 24)
							biz_str_len = 24;
						else
							biz_str_len = rs.getInt("biz_len");
								
                        // search for ofac matches on the sdn table
						try{ if(ofac_rs != null) ofac_rs.close(); }catch(Exception e1){e1.printStackTrace();}
			            try{ if(ofac_ps != null) ofac_ps.close(); }catch(Exception e1){e1.printStackTrace();}
                        s_sql = "select sdn_id "+
                                "from ofac_sdn "+
                                "where sdn_type_id = 'B' "+
                                "and Substr(Upper(full_name_txt),1,?) like ? ";
						ofac_ps = conn.prepareStatement(s_sql);
						ofac_ps.setInt(1,biz_str_len);
						ofac_ps.setString(2,businessName + wildcard);
						ofac_rs = ofac_ps.executeQuery();
                        // set ofac comment
                        if (ofac_rs.next()) {
                            comment += "OFAC SDN MATCH - "+ofac_rs.getInt("sdn_id")+"; ";
			    ofac_txt = "T";
                            ofac_flg = 1;
                        }    
						try{ if(ofac_rs != null) ofac_rs.close(); }catch(Exception e1){e1.printStackTrace();}
						try{ if(ofac_ps != null) ofac_ps.close(); }catch(Exception e1){e1.printStackTrace();}

                        // search for ofac matches on the alt table
                        s_sql = "select sdn_id "+
                                "from ofac_alt "+
                                "where Substr(Upper(full_name_txt),1,?) like ? ";

						ofac_ps = conn.prepareStatement(s_sql);
						ofac_ps.setInt(1,biz_str_len);
						ofac_ps.setString(2,businessName + wildcard);
						ofac_rs = ofac_ps.executeQuery();
                        // set ofac comment
                        if (ofac_rs.next()) {
                            comment += "OFAC ALT MATCH - "+ofac_rs.getInt("sdn_id")+"; ";
			    ofac_txt = "T";
                            ofac_flg = 1;
                        }    
                        try{ if(ofac_rs != null) ofac_rs.close(); }catch(Exception e1){e1.printStackTrace();}
						try{ if(ofac_ps != null) ofac_ps.close(); }catch(Exception e1){e1.printStackTrace();}

                        // update business' corresponding flag on every ofac check (in case he previously had a match and now does not
                        s_sql = "update requestor_business "+
                                "set ofac_flg = ? "+
                                "where request_id= ?";
                        update_stmt = conn.prepareStatement(s_sql);
						update_stmt.setString(1, ofac_txt);
						update_stmt.setInt(2, request_id);
                        update_stmt.execute();
						try{ if(update_stmt != null) update_stmt.close(); }catch(Exception e1){e1.printStackTrace();}
                    }

                }

                try{ if(rs != null) rs.close(); }catch(Exception e1){e1.printStackTrace();}
			    try{ if(ps != null) ps.close(); }catch(Exception e1){e1.printStackTrace();}
                if (ofac_flg >= 0) {
                    // if there is no comment, then the app passed (did not match an ofac record)
                    if (comment.isEmpty()) {
                       if (s_log_file!=null && s_log_file.length()>0)
                        log.FmtAndLogMsg("OFAC check passed for request "+request_id);
                    }
                    // otherwise, there was an ofac comment, so the request failed the ofac check
                    else {
                       if (s_log_file!=null && s_log_file.length()>0)
                        log.FmtAndLogMsg("OFAC check failed for request "+request_id);
                        try {
                            CommentEvents ce = new CommentEvents(conn,s_log_file);
                            ce.addComment(request_id,52,"!OFAC Match",comment.substring(0,comment.length()-2),"SYSTEM","",null);
                        }
                        catch (Exception e) {
                           if (s_log_file!=null && s_log_file.length()>0)
                            log.FmtAndLogMsg("RID="+request_id+" - DEBUG MESSAGE: Ofac.java ofac Constructor : There was a problem creating the OFAC system comment for requestId: "+request_id, e);
                            throw new Exception(e.toString(), e);
                        }
                    }
                }
                // requestor info missing, throw an exception (that data is required)
                else {
                   if (s_log_file!=null && s_log_file.length()>0)
                    log.FmtAndLogMsg("OFAC check failed because application information is incomplete for request_id="+request_id);
                    throw new Exception("Incomplete application information");
                }   
          }
          catch (Exception e) {
		      log.FmtAndLogMsg("RID="+request_id+" - DEBUG MESSAGE: Ofac.java ofac Constructor : OFAC check failed because application information is incomplete for requestId="+request_id);
              throw e;
          }
          finally {
              // make sure all cursors are closed
			  try{ if(rs != null) rs.close(); }catch(Exception e1){e1.printStackTrace();}
			  try{ if(ofac_rs != null) ofac_rs.close(); }catch(Exception e1){e1.printStackTrace();}
			  try{ if(ofac_ps != null) ofac_ps.close(); }catch(Exception e1){e1.printStackTrace();}
			  try{ if(ps != null) ps.close(); }catch(Exception e1){e1.printStackTrace();}
			  
          }
        }
        else {
            log.FmtAndLogMsg("OFAC check not performed because of no DB connection.");
            throw new Exception("DB connection does not exist");
        }
    }
    
	/**
	 * Returns a boolean containing the value of the evaluator's CHECK_OFAC_FLG.
     *  EVALUATOR.CHECK_OFAC_FLG
     *
     *  If it is enabled for the request_id's evaluator, we return true.
     *  If it is disabled for the request_id's evaluator, we return false.
     *  If it is null or otherwise, we return true.
     *
	 * @param Connection a valid connection to use for the database
	 * @param int a Request ID to check for
	 * @return the boolean representation of CHECK_OFAC_FLG
	 */
    public static boolean isEnabled(Connection con, int requestId) {
        LogMsg log = new LogMsg();
        try {
            Query query = new Query(con);
            String sql = "select * from evaluator e, credit_request cr where cr.request_id = ? and cr.evaluator_id = e.evaluator_id and CHECK_OFAC_FLG = 0";
            query.prepareStatement(sql);
            query.setInt(1, requestId);
            query.executePreparedQuery();
            if (query.next()) {
                return false;
            }
        } catch (Exception e) {
		    log.FmtAndLogMsg("RID="+requestId+" - DEBUG MESSAGE: Ofac.java isEnabled Method : FAILED for requestId="+requestId);
            e.printStackTrace();
        }
        return true;
    }
    
}


