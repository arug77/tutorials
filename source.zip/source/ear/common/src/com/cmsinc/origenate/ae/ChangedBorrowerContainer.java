package com.cmsinc.origenate.ae;

import java.util.ArrayList;


//class used by act_saveborrowerposition.cfm only
public class ChangedBorrowerContainer {
	private ArrayList<ChangedBorrowerContainerBean> changedBorrowerBean;
	
	public ChangedBorrowerContainer(){
		if(changedBorrowerBean == null){
			changedBorrowerBean = new ArrayList<ChangedBorrowerContainerBean>();
		}
	}
	
	public void addChangedBorrowerContainerBean(String entityTxt, int requestorTypeId, int requestorId){
		//System.out.println("CHANGEBORROWERCONTAINER adding to bean..entityTxt:" + entityTxt + "/requestorTypeId:"+requestorTypeId + "/requestorId:" + requestorId);
		changedBorrowerBean.add(new ChangedBorrowerContainerBean(entityTxt,requestorTypeId,requestorId));
	}
	
	public ArrayList<ChangedBorrowerContainerBean> getChangedBorrowerContainerBean(){
		return changedBorrowerBean;
	}
}