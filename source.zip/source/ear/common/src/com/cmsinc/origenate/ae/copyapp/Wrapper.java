package com.cmsinc.origenate.ae.copyapp;


public class Wrapper {

    public String addedParentVars="";

    public Wrapper() {}

}
