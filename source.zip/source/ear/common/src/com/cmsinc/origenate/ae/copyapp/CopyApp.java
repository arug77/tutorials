
package com.cmsinc.origenate.ae.copyapp;

import java.io.*;
import java.sql.*;
import java.util.*;


import com.cmsinc.origenate.ae.Ofac;
import com.cmsinc.origenate.event.JournalEvents;
import com.cmsinc.origenate.util.COLEncrypt;
import com.cmsinc.origenate.util.LogMsg;
import com.cmsinc.origenate.util.OWASPSecurity;
import com.cmsinc.origenate.util.Query;
import com.cmsinc.origenate.util.SQLSecurity;


/** <pre>
 *
 * CopyApp.java   Created:  Aug 06, 2001
 *
 * Usage: create a new CopyApp object and pass it a connection to the database,
 *        or database connection parms and a log file name
 *
 *   It simply stores it. Then call the copy() or delete() method to do all the work.
 *
 *   public CopyAppResponse copy(String requestID,String transType,
 *                               String tableName,String additionalParms)
 *                               throws Exception
 *
 *   Copy app assumes you are copying a hierarchy of tables based on a root table.
 *   Its most common use is to make a copy of a credit_request. But you can also
 *   start at any table which allows you to basically copy any part of a request
 *   assuming you pass a request ID (which is required).
 *
 *   Parms:
 *
 *   requestID  - required, target request ID to copy or delete.
 *
 *   transType - required, Used to qualify the rows in the table: copyapp_table.
 *               Normally you would pass 'COPYAPP' to copy an entire application.
 *               But since this is table driven
 *               you could pass a differnt transType to perform a differnt action, like
 *               copy a bureau.
 *   tableName - required, the db_table_name_txt in the copyapp_tables that is the
 *               starting point for copy() to work. For copying a request pass
 *               "CREDIT_REQUEST".
 *
 *   additionalParms - TBD
 *
 *
 *   returns: CopyAppResponse object.
 *        returns information about the copy process. Initially, the only public
 *        variable in the response object is the new request_id assigned to
 *        the copied object.
 *
 *   Exceptions: If you do not catch any exceptions then you can assume it worked fine,
 *               oherwise the exception will describe the error that occured.
 *
 *
 *   Sample call:
 *
 *   LogMsg log = new LogMsg();
 *   CopyApp copyApp = null;
 *   try {copyApp = new CopyApp(s_host,s_sid,s_user,s_password,s_log_file,s_port);}
 *   catch (Exception e) { throw e; }
 *   CopyAppResponse resp;
 *
 *   try {resp=copyApp.copy(4004036,"COPYAPP","CREDIT_REQUEST","");}
 *   catch (Exception e) { throw e; }
 *
 *   System.out.println("Response assigned ID: "+resp.assignedRequestID);
 *
 *   You can also call copyApp.delete() to delete a app THAT WAS CREATED WITH COPYAPP
 *   If the resp.assignedRequestID == 4003189
 *
 *   try {resp=copyApp.delete(4003189,"COPYAPP","CREDIT_REQUEST","");}
 *   catch (Exception e) { throw e; }
 *
 *
 *
 *   How copy() and delete() work:
 *
 *
 *       copy() or delete() call copyApp() to get started, passing in a flag
 *       indicating whether to perform a delete or copy action. It is done this way
 *       because the same table entries in copyapp_tables or fields can be used to
 *       delete an app that was previously copied with copy().
 *
 *
 *       copyApp() sets the current autot-commit mode off so it can rollback if the
 *       copy or delete failed. ( It will restore the current commit mode upon exit).
 *
 *       Basically, the processing starts at a root table which is passed in as
 *       tableName. It sets globals = the passed in request ID to get started.
 *       See globals description below for more info about how globals are handled.
 *
 *       It then calls doCopy() to do all the work. Its done this way because
 *       we needed to prime the pump with the initial global var of request_id.
 *
 *           doCopy() is a recursive method which does the following:
 *
 *
 *             finds the row in copyapp_tables which matches the given tableName and
 *             trans type.
 *
 *
 *             Also selects all rows from the copyapp_fields table for the given table.
 *             These rows only specify special processing actions for cols in the
 *             given table. The first job is to create a select that will select all rows
 *             from the target table (but we need key information). The select_var_txt and key_flg
 *             columns in copyapp_fields tells us where to get the values from globals when
 *             constructing the where clause. If the select_var_txt starts with a # then it assumes
 *             to get the key value from a global var (ex. #NEW_REQUEST_ID#) otherwise
 *             it assumes that the value should be taken literally.
 *
 *
 *             We then create a select to select all the rows from the source table
 *
 *             for each row found
 *
 *                It creates a insert statement that duplicates the row.
 *                however, it looks in the copyapp_fields table for the given table
 *                to see if any column values need to be replaced instead of simply
 *                using the values from the originating row.
 *
 *                The rules for parsing the copyapp_fields:
 *                If a default_value_txt value is specified then it will use it as the
 *                value to be inserted.
 *                else
 *                   if an action_txt is specified then it will execute the action to come
 *                   up with the value to be inserted.
 *                   else
 *                     if a read_var_txt is specified then it will search the globals
 *                     for the given global name and use the value of the global var as the
 *                     insert value.
 *                If none of the above are specifed then it will use the value from the
 *                originating row.
 *
 *
 *                It then executes the insert to create a copy of the row.
 *
 *                Note: For the credit-request table the copyapp_fields entry for the
 *                      request_id column
 *                      will specify that a new request ID is created for the new app.
 *                      This value will be stored in a global var for access later when
 *                      creating new child table rows.
 *
 *                For the current row, it queries the copyapp_tables where
 *                the parent_table_seq_num is equal to the current table's seq num
 *                to find all child tables that are linked to the current table.
 *
 *                For each child table found
 *
 *                   it calls doCopy() again to copy the rows from the source
 *                   to the target. get it? Its recursive.
 *
 *                   Note: for child tables the copyapp_field entries for
 *                         read_var_txt will be set to #NEW_REQUEST_ID# so they
 *                         can be created with the newly assigned request ID when the
 *                         top level credit_request row was duplicated.
 *
 *                end for each child table found
 *
 *             end-for-row-found
 *
 *
 *
 *
 *           Globals is implemented this way:
 *
 *           Globals presents an interesting problem. We are doing a depth first implementation
 *           which means that for every row in the source table we are creating all its children
 *           rows down to the lowest level in a tree. If a row at the lowest level needs a value
 *           based on its parent then we need a way to pass global vars down the recursion
 *           tree that do not persist on the way back up.
 *
 *             For example. If we are copying
 *              rows related to trade-ins and there are many trade-ins then if we were to
 *              call doCopy() for a given trade-in's child table (ex. collateral) then we
 *              want to make sure that the child table gets only those global var values that
 *              apply to its parent (the trade-in that we are curently copying).
 *
 *           To accomplish this we are using the String class which is immuatble. Meaning,
 *           that if we call a method and pass it a string then it will not be changed
 *           as as a result of calling that method, even though, the called method
 *           will have modified the string and passed it on to another method (itself,
 *           remember, its recursive).
 *           This way, as we go up and down the tree of recursion, we can be sure that
 *           the current row is always passing the correct values to its children.
 *           I hope this make sense to you. And if not, call me, I'll be glad to discuss
 *           it with you.
 *
 *
 *
 *
 * @author  Glenn Leyba
 * @version 1.0
 *
 * </pre>
 */

public class CopyApp {

    Connection con=null;
    boolean saveAutoCommitState;
    LogMsg log=null;
    //String sHost=null;
    //String sPort=null;
    //String sSIDName=null;
    String sUser=null;
    //String sPass=null;
    //String sTNS="";
    //String sLogFile=null;
    String sLinkName=""; // set if called by Exporter
    Query copyAppTables=null;
    boolean cachedTransType=false;
    boolean calledByPortal=false;
    boolean terminateCon=false;
	boolean retainDataOnLoanAppRqUpdt=false;

    // Constructor

    /******************************   GL. 163319 - Should use TNS constructor instead

    public CopyApp(String sHost, String sSIDName, String sUser,
                   String sPass,String sLogFile, String sPort) throws Exception {

        this.sHost = sHost;
        this.sPort = sPort;
        this.sSIDName = sSIDName;
        this.sUser = sUser;
        this.sPass = sPass;
        log = new LogMsg();
        this.sLogFile = sLogFile;

        if (sLogFile!=null && sLogFile.length()>0) log.openLogFile(sLogFile);

        // sConStr should be something like:

        // "jdbc:oracle:thin:@172.16.17.108:1521:cmsiprod"

        String sConStr = "jdbc:oracle:thin:@" + sHost + ":" +  sPort + ":" + sSIDName;


        logMsg("Connecting to database: "+sSIDName);

        try {
           // Load Oracle driver
           DriverManager.registerDriver (new oracle.jdbc.OracleDriver());

           // Connect to the Oracle database
           con = DriverManager.getConnection (sConStr,sUser,COLEncrypt.sDecrypt(sPass));
        }
        catch (Exception e) {
            throw new Exception("Database connect error:"+e.toString());
        }


    }  // constructor

    ***/

    // overloaded to pass tns entry - 150165
    public CopyApp(String sHost, String sSIDName, String sUser,
                   String sPass,String sLogFile, String sPort,String tnsEntry) throws Exception {

        //this.sHost = sHost;
        //this.sPort = sPort;
        //this.sSIDName = sSIDName;
        this.sUser = sUser;
        //this.sPass = sPass;
        //this.sTNS = tnsEntry;
        log = new LogMsg();
        //this.sLogFile = sLogFile;

        if (sLogFile!=null && sLogFile.length()>0) log.openLogFile(sLogFile);

        // sConStr should be something like:

        // "jdbc:oracle:thin:@172.16.17.108:1521:cmsiprod"

        //String sConStr = "jdbc:oracle:thin:@" + sHost + ":" +  sPort + ":" + sSIDName;

        String sConStr = "jdbc:oracle:thin:@";
                       if (tnsEntry.equals("")) {
                               sConStr = sConStr + sHost + ":" + sPort + ":" + sSIDName;
                       } else {
                               sConStr = sConStr + tnsEntry;
                       }


        logMsg("Connecting to database: "+sSIDName);

        try {
           // Load Oracle driver
           DriverManager.registerDriver (new oracle.jdbc.OracleDriver());

           // Connect to the Oracle database
           
           con = DriverManager.getConnection (sConStr,sUser,COLEncrypt.sDecrypt(sPass));
           
           // We must remember to close the connection if we create it.
           terminateCon = true;
        }
        catch (Exception e) {
            throw new Exception("Database connect error:"+e.toString(), e);
        }


    }  // constructor



    // second constructor that uses passed in connection to DB

    public CopyApp(Connection con, String sLogFile) throws Exception {

        log = new LogMsg();
        //this.sLogFile = sLogFile;
        this.con = con;

        if (sLogFile!=null && sLogFile.length()>0) log.openLogFile(sLogFile);

    }  // constructor
	
	public CopyApp(LogMsg log, Connection con) throws Exception {

        this.log = log;
        this.con = con;
    }  // constructor

    // constructor called by saveAppData in the portal - deleteapp_for_update

    public CopyApp(Connection con, String sLogFile, boolean calledByPortal) throws Exception {

        log = new LogMsg();
        //this.sLogFile = sLogFile;
        this.calledByPortal = calledByPortal;
        this.con = con;

        if (sLogFile!=null && sLogFile.length()>0) log.openLogFile(sLogFile);

    }  // constructor

	
	//Constructor called by LoanAppRq
    public CopyApp(Connection con, boolean retainDataOnLoanAppRqUpdt, String sLogFile) throws Exception {

        log = new LogMsg();
        //this.sLogFile = sLogFile;
        this.retainDataOnLoanAppRqUpdt = retainDataOnLoanAppRqUpdt;
        this.con = con;

        if (sLogFile!=null && sLogFile.length()>0) log.openLogFile(sLogFile);

    }  // constructor



    // THIS CONSTRUCTOR SHOULD ONLY BE CALLED BY THE EXPORTER!!!

    public CopyApp(Connection con, LogMsg log, String linkName,String transType) throws Exception {

        sLinkName=linkName;
        this.log=log;
        this.con = con;

        copyAppTables= new Query(con);

        copyAppTables.prepareStatement("select cf.db_field_seq_num,"+
           " cf.key_flg, cf.db_field_name_txt, cf.default_value_txt, cf.action_txt,"+
           " cf.read_var_txt, cf.write_var_txt,cf.select_var_txt, cf.db_table_seq_num, ct.db_table_name_txt, "+
           " ct.parent_table_seq_num, ct.order_precedence_num "+
           " from copyapp_fields cf, copyapp_tables ct"+
           " where ct.transaction_type_id = ? and "+
           " ct.db_table_seq_num = cf.db_table_seq_num and "+
           " cf.transaction_type_id = ? order by cf.db_table_seq_num, cf.order_precedence_num");
        copyAppTables.setString(1, transType);
        copyAppTables.setString(2, transType);

        copyAppTables.executePreparedQuery();
        cachedTransType=true;

    }  // constructor




    public void closeDatabaseConnection() {
        // If CopyApp creates its own connection, we have to close it too. Otherwise leave it alone.
        if (terminateCon) {
            logMsg("Closing connection to database");
            try {con.close();} catch (Exception e) {logMsg("Connection in CopyApp failed to close.");}
        }
    }


    //  C O P Y   - called by cfx_callCopyApp


    public CopyAppResponse copy(String requestID,String transType,
                                String tableName,String additionalParms)
                                throws Exception {

        CopyAppResponse resp=null;
        if (additionalParms==null) additionalParms="";


        logMsg("CopyApp.copy() called...requestID="+
                          requestID+" TransType="+transType+
                          " Root table:"+tableName+" Additional parms:"+
                          log.maskDataForLogging(additionalParms,"(SOC_SEC_NUM_TXT)=",5,9)); //TTP 333950 CopyApp debug modification - masking SSN if its coming in additionalParms variable in case it wasnt already masked
        try {

            // if the transType is ADD_REQUESTOR then copyApp will add a
            // requestor to the current request (the source requestor is
            // specified in the additionalParms

            resp=copyApp(requestID,transType,tableName,additionalParms,false,false);

            logMsg("CopyApp.copy()  copyapp method is finished");

              // false - do not delete,false - no export
        }
        catch (Exception e) {
           logMsg("RID="+requestID+" - DEBUG MESSAGE: CopyApp.java copy Method : ERROR for requestID: "+requestID, e);
            throw e;
        }
        finally {
           /*
            logMsg("CopyApp.copy() finsihed...requestID="+
                          requestID+" TransType="+transType+
                          " Root table:"+tableName+" Additional parms:"+
                          additionalParms);
                      */
        }


        return(resp);

    } // copy



    //   D E L E T E


    public CopyAppResponse delete(String requestID,String transType,
                                  String tableName,String additionalParms)
                                  throws Exception {

        CopyAppResponse resp=null;
		
		PreparedStatement pstmt = null;
		
		boolean logFlg = true;
		if(additionalParms != null && additionalParms.equalsIgnoreCase("NO_LOG")){
			logFlg = false;
		}
		
		if (logFlg){
	        logMsg("CopyApp.delete() called...requestID="+
	                          requestID+" TransType="+transType+
	                          " Root table:"+tableName+" Additional parms:"+
	                          log.maskDataForLogging(additionalParms,"(SOC_SEC_NUM_TXT)=",5,9)); //TTP 333950 CopyApp debug modification - masking SSN if its coming in additionalParms variable in case it wasnt already masked
		}

        try {
			
			// set portal_comment_id = null. see CL 150317
			// set latest_final_dec_ref_id and latest_dec_ref_id = null. see CL157158
			// dont set latest_final_dec_ref_id and latest_dec_ref_id = null for all transaction types. see CL159782
			try{
				if(transType.equals("DELETE_APP")) {
					JournalEvents journalEvents= new JournalEvents(con,null);
					journalEvents.addJournal(Integer.parseInt(requestID),113,"Application being deleted via DELETE_APP transaction","SYSTEM");
				}
			
				StringBuffer query = new StringBuffer("UPDATE CREDIT_REQUEST SET PORTAL_COMMENT_ID = NULL");
				if(!transType.equals("DELETEAPP_FOR_UPDATE") && !transType.equals("DELETE_CONTRACT")) {
					query.append(", LATEST_FINAL_DEC_REF_ID = NULL, LATEST_DEC_REF_ID = NULL");
				}
				query.append(" WHERE REQUEST_ID = ?");			
			
				pstmt = con.prepareStatement(query.toString());
				pstmt.setString(1, OWASPSecurity.validationCheck(requestID,OWASPSecurity.SQLPARAMSTRING));
				pstmt.executeUpdate();
			} catch (Exception e){
			    logMsg("RID="+requestID+" - DEBUG MESSAGE: CopyApp.java delete Method : FAILED to UPDATE CREDIT_REQUEST for requestID: "+requestID, e);
				throw e;
			} finally {
				//close prepared statement
				try{ if(pstmt != null) pstmt.close(); }catch(Exception e1){e1.printStackTrace();}
			}
			
            resp=copyApp(requestID,transType,tableName,additionalParms,true,false);
        }
        catch (Exception e) {
		    logMsg("RID="+requestID+" - DEBUG MESSAGE: CopyApp.java delete Method : FAILED for requestID: "+requestID, e);
			
			// On exception, we don't want to leave the delete app journal entry because it
			// will cause any AppCommentsRq's to get added as logging rather than comments.
			try {
				String query = "DELETE FROM CREDIT_REQUEST_JOURNAL WHERE REQUEST_ID = ? AND JOURNAL_EVENT_ID = 113";
				pstmt = con.prepareStatement(query);
				pstmt.setString(1, OWASPSecurity.validationCheck(requestID,OWASPSecurity.SQLPARAMSTRING));
				pstmt.executeUpdate();
			} catch (Exception ex) {
			    logMsg("RID="+requestID+" - DEBUG MESSAGE: CopyApp.java delete Method : FAILED to DELETE record from CREDIT_REQUEST_JOURNAL for requestID: "+requestID, ex);
			} finally {
				//close prepared statement
				try{ if(pstmt != null) pstmt.close(); }catch(Exception e1){e1.printStackTrace();}
			}
			
            throw e;
        }
        finally {
           /*
          logMsg("CopyApp.delete() finished...requestID="+
                          requestID+" TransType="+transType+
                          " Root table:"+tableName+" Additional parms:"+
                          log.maskDataForLogging(additionalParms,"(SOC_SEC_NUM_TXT)=",5,9)); //TTP 333950 CopyApp debug modification - masking SSN if its coming in additionalParms variable in case it wasnt already masked (yes, this is already commented out but doing it to be safe when someone uncomments this section back in.)
                          */
						   
        }

        return(resp);

    } // delete




    //  E X P O R T


    public void export(String requestID,String transType,
                       String tableName,String additionalParms)
                       throws Exception {


        try {
            if (sLinkName.length()==0) throw new Exception("Link name not specified on constructor");
            copyApp(requestID,transType,tableName,additionalParms,false,true);
        }
        catch (Exception e) {
		    logMsg("RID="+requestID+" - DEBUG MESSAGE: CopyApp.java export Method : FAILED for requestID: "+requestID, e);
            throw e;
        }


    } // export



    //  D E L E T E     E X P O R T    ( deletes an app from the linked database )


    public void deleteExport(String requestID,String transType,
                       String tableName,String additionalParms)
                       throws Exception {


        try {
            copyApp(requestID,transType,tableName,additionalParms,true,false); //true-delete,false-no export
        }
        catch (Exception e) {
		    logMsg("RID="+requestID+" - DEBUG MESSAGE: CopyApp.java deleteExport Method : FAILED for requestID: "+requestID, e);
            throw e;
        }


    } // delete export

    ///////////////////////////////////////////////////////////////////////



    public CopyAppResponse copyApp(String requestID,String transType,
                                String tableName,String additionalParms,
                                boolean deleteRows,boolean export)
                                throws Exception {

        CopyAppResponse resp=new CopyAppResponse();
        Statement stmt = null;

        saveAutoCommitState=con.getAutoCommit();
        boolean nocommit=additionalParms.indexOf("NOCOMMIT")>=0;

        tableName=tableName.toUpperCase();
        String parentVars="#SRC_REQUEST_ID#="+requestID+"|";

        // If the transType is ADD_REQUESTOR then copyApp will add a
        // requestor to the current request (the source requestor is
        // specified in the additionalParms

        try { // catch unexpected errors


            stmt = con.createStatement();
            if (!nocommit) con.setAutoCommit(false); // start a transaction

            //logMsg("CopyApp.copyApp()  doCopy method is called");

            doCopy(transType,parentVars,tableName,additionalParms,resp,deleteRows,export,stmt);

            //logMsg("CopyApp.copyApp()  doCopy method is finished");

        } // end catch unexpected errors
        catch (Exception e) {
		    logMsg("RID="+requestID+" - DEBUG MESSAGE: CopyApp.java copyApp Method : FAILED for requestID: "+requestID+" reason: "+e.toString(), e);
            if (!nocommit) {
               try {con.rollback();} catch (Exception e1) {logMsg(e1.toString(), e1);}
               con.setAutoCommit(saveAutoCommitState); // reset commit state
            }
            throw e;
        }
        finally {
			try{ if(stmt != null) stmt.close(); }catch(Exception e1){e1.printStackTrace();}
        }

        // Commit the copy

        if (!nocommit) {
           try {con.commit();} catch (Exception e2) {
                logMsg(e2.toString(), e2);
                con.setAutoCommit(saveAutoCommitState); // reset commit state
                throw e2;
                }

           con.setAutoCommit(saveAutoCommitState); // reset commit state
        }
        
        return resp;

    } // copy




    ///////////////////////////////////////////////////////////////////////


    // This is called recursively
    // This is called recursively
    // This is called recursively
    // This is called recursively


    private void  doCopy(String transType,String parentVars,
                         String tableName, String additionalParms,
                         CopyAppResponse resp,boolean deleteRows,boolean exporting,
                         Statement stmt)
                         throws Exception {


        Query copyAppFields = copyAppTables;
        Query childTables = null;
        Query srcRows = new Query(con);
        String tableNum="",select,deleteStmt="",whereClause="";
        MetaData tableCols=null;
        int currRow=0;
        boolean processSourceRows=false;
        boolean addingRequestor=transType.startsWith("ADD_REQUESTOR");
        boolean didntCopy=false;



        //logMsg("PROCESSING TABLE: "+tableName);

        /***
        CREATE TABLE "COPYAPP_TABLES"(
        "TRANSACTION_TYPE_ID"    VARCHAR2(20),
        "DB_TABLE_SEQ_NUM"       NUMBER(3),
        "DB_TABLE_NAME_TXT"      VARCHAR2(32),
        "PARENT_TABLE_SEQ_NUM"   NUMBER(3),
        "ORDER_PRECEDENCE_NUM"   NUMBER(3)
        ) TABLESPACE CMSI_DATA;


        CREATE TABLE "COPYAPP_FIELDS"(
        "TRANSACTION_TYPE_ID"    VARCHAR2(20),
        "DB_TABLE_SEQ_NUM"       NUMBER(3),
        "DB_FIELD_SEQ_NUM"       NUMBER(3),
        "ORDER_PRECEDENCE_NUM"   NUMBER(3),
        "KEY_FLG"                NUMBER(1),
        "DB_FIELD_NAME_TXT"      VARCHAR2(50),
        "DEFAULT_VALUE_TXT"      VARCHAR2(256),
        "ACTION_TXT"             VARCHAR2(32),
        "READ_VAR_TXT"           VARCHAR2(32),
        "WRITE_VAR_TXT"          VARCHAR2(32),
        "SELECT_VAR_TXT"          VARCHAR2(32)
        ) TABLESPACE CMSI_DATA;
        *****/

        try {

        // All tables must have rows in the copyapp_fields to at least define the keys


        // DO NOT CHG THE ORDER OF THE FIELDS BEING SELECTED. USED BY GETCOLVALUE(COLINDEX)

        if (!cachedTransType) {

           copyAppFields = new Query(con);
           childTables = new Query(con);


           String rawStmt1 = "select cf.db_field_seq_num,"+
              " cf.key_flg, cf.db_field_name_txt, cf.default_value_txt, cf.action_txt,"+
              " cf.read_var_txt, cf.write_var_txt,cf.select_var_txt, cf.db_table_seq_num, ct.db_table_name_txt, "+
              //     6                 7                 8                  9                      10
              " ct.parent_table_seq_num, ct.order_precedence_num "+
              //     11                       12
              " from copyapp_fields cf, copyapp_tables ct"+
              " where ct.transaction_type_id = ? and "+
              " ct.db_table_name_txt  = ? and ct.db_table_seq_num = cf.db_table_seq_num and "+
              " cf.transaction_type_id = ? order by cf.order_precedence_num";
			copyAppFields.prepareStatement(rawStmt1);   
			copyAppFields.setString(1, transType);
			copyAppFields.setString(2, tableName, false);
			copyAppFields.setString(3, transType);
			copyAppFields.executePreparedQuery();
			copyAppFields.next();
            tableNum=copyAppFields.getColValue(9); // db_table_seq_num
		   
		   /*copyAppFields.executeQuery("select cf.db_field_seq_num,"+
              " cf.key_flg, cf.db_field_name_txt, cf.default_value_txt, cf.action_txt,"+
              " cf.read_var_txt, cf.write_var_txt,cf.select_var_txt, cf.db_table_seq_num, ct.db_table_name_txt, "+
              //     6                 7                 8                  9                      10
              " ct.parent_table_seq_num, ct.order_precedence_num "+
              //     11                       12
              " from copyapp_fields cf, copyapp_tables ct"+
              " where ct.transaction_type_id = '"+transType+"' and "+
              " ct.db_table_name_txt  = '"+tableName+"' and ct.db_table_seq_num = cf.db_table_seq_num and "+
              " cf.transaction_type_id = '"+transType+"' order by cf.order_precedence_num",false);
                                                           // false - get Meta Data
           
           copyAppFields.next();
           tableNum=copyAppFields.getColValue(9); // db_table_seq_num
		    */ 
        }
        else {
            // the Exporter caches the trans type in copyAppTables.
            // At the top of this method we set copyAppFields to copyAppTables
            // for convenience


            copyAppTables.reset();
            while(copyAppTables.next()) {
               // 10 - db_table_name_txt
               if (copyAppTables.getColValue(10).trim().equals(tableName)) {
                   tableNum=copyAppTables.getColValue(9).trim(); // db_table_seq_num
                   currRow=copyAppTables.getCurrRowID();
                   //System.out.println("Table num="+tableNum+" row="+currRow);
                   break;
               }
            }

        }


        // create a select to get the rows for this table
        // ex. select ... from credit_request where request_id = 123



        if (exporting || deleteRows)  {
            // select only the columns needed for keys and globals vars


            select = createExportSelect(copyAppFields,tableName,currRow,exporting,deleteRows);

        }
        else {
            // now get info about the columns and primary keys for this table
            // from the database schema

            // done for copyApp, not the Exporter, so no need to check if cachedTransType

            tableCols = new MetaData(con);
            // 10/27/03 for multiple schemas preface user name to get to right schema
            // if avail

            if (sUser!=null && sUser.length()>0)
              tableCols.getMetaData(sUser,tableName,false); // not primary keys
            else
              tableCols.getMetaData(null,tableName,false); // not primary keys



            select = createSourceSelect(tableCols,tableName,copyAppFields,parentVars);


        }

        ArrayList<String> paramVals = new ArrayList<String>();
        whereClause = createWhereClause(tableCols,tableName,copyAppFields,parentVars,exporting,deleteRows,currRow,addingRequestor,additionalParms, paramVals);


        select+=whereClause; // where clause used in delete too


        //logMsg(select);

        //   G E T    S O U R C E    R O W S

        try {
			srcRows.prepareStatement(select);
			 int placeCt = 1;
              for(int i = 0; i < paramVals.size(); i++){
                String v = paramVals.get(i);
                if(v.startsWith("'")){
                  srcRows.setString(placeCt++, OWASPSecurity.validationCheck(v.substring(1,v.length() - 1),OWASPSecurity.SQLPARAMSTRING));
                }
                else if(v.contains(".")){
                  srcRows.setFloat(placeCt++, Float.valueOf(v));
                }
                else{
                  srcRows.setLong(placeCt++, Long.valueOf(v));
                }
              }
			srcRows.executePreparedQuery();
			//srcRows.executeQuery(select,true); 
			
			} // false - get meta data
        catch (Exception e) {
		    logMsg("DEBUG MESSAGE: CopyApp.java doCopy Method : FAILED for select: "+select+" reason: "+e.toString(), e);
            throw new Exception(e.toString()+" select: "+select, e);
        }



        processSourceRows=(srcRows.getRowCount()>0);


        if (exporting && processSourceRows) {
			PreparedStatement pstmt = null;
            // much faster, since not replacing any col values. also copies clobs

            try {
              select="INSERT INTO "+SQLSecurity.sanitize(tableName)+SQLSecurity.sanitize(sLinkName)+" SELECT * FROM "+SQLSecurity.sanitize(tableName)+SQLSecurity.basicSanitize(whereClause);
            	/**
                 * OWASP TOP 10 - 2010 A1 SQL Injection
                 * TTP 324955 Security Remediation Fortify Scan
                 */
              pstmt = con.prepareStatement(select);
              int placeCt = 1;
              for(int i = 0; i < paramVals.size(); i++){
                String v = paramVals.get(i);
                if(v.startsWith("'")){
                  pstmt.setString(placeCt++, OWASPSecurity.validationCheck(v.substring(1,v.length() - 1),OWASPSecurity.SQLPARAMSTRING));
                }
                else if(v.contains(".")){
                  pstmt.setFloat(placeCt++, Float.valueOf(v));
                }
                else{
                  pstmt.setLong(placeCt++, Long.valueOf(v));
                }
              }
            	pstmt.executeUpdate();
            } catch (SQLException se){
              log.FmtAndLogMsg("Class " + this.getClass() + "; " + se.toString());
            }
            catch (Exception e) {
			       logMsg("DEBUG MESSAGE: CopyApp.java doCopy Method : FAILED to insert for tableName: "+tableName+" sLinkName: "+sLinkName+" whereClause: "+whereClause, e);
                /*
                HAVE TO MAKE AN UNFORTUNATE ASSUMPTION HERE:

                If we get a unique constraint error then we are trying to re-insert rows
                to a table for a parent table row that has already been processed.
                For instance, the requestor_bureau_header is keyed by request_id,requestor_id, bureau_id
                however, the child table: xref_bureau_score is only keyed by request_id, bureau_id.
                Not sure why, but in any case if there are two rows in requestor_bureau_header
                then when the first row is processed it will insert all rows for
                xref_bureau_scores only using the bureau_id, request_id. Then when we process
                the second requestor_bureau_header row it will try to recopy the
                same set of rows for xref_bureau_score using the same bureau_id, request_id
                which will cause a unique constraint error.
                This same problem exists between the xrfef_bureau_score and xref_bureau_score_reasons
                table.
                Hence, during an export, if this condition arises then assume its ok
                and stop processing this child table.
                If this is the case then ignore the error and stop processing the source rows.
                */
                if (e.toString().indexOf("unique constraint") >= 0)
                    processSourceRows=false;
                else
                    throw new Exception(e.toString()+" for: "+select);
            } finally {
				//close prepared statement
				try{ if(pstmt != null) pstmt.close(); } catch(Exception e1){e1.printStackTrace();}
			}
        }


        // Find all the child tables of this table so we can recursively
        // copy their rows for each source row found

        if (!cachedTransType && processSourceRows) {
		    String rawStmt2 = "select db_table_name_txt from copyapp_tables "+
                         "where transaction_type_id = ? and "+
                         "parent_table_seq_num = ? order by order_precedence_num";
			childTables.prepareStatement(rawStmt2);   
			childTables.setString(1, OWASPSecurity.validationCheck(transType,OWASPSecurity.SQLPARAMSTRING));
			childTables.setInt(2, OWASPSecurity.validationCheck(tableNum,OWASPSecurity.SQLPARAMSTRING));
			childTables.executePreparedQuery();			 
           /*childTables.executeQuery("select db_table_name_txt from copyapp_tables "+
                         "where transaction_type_id = '"+transType+"' and "+
                         "parent_table_seq_num = "+tableNum+" order by order_precedence_num",false); // false - gather Meta Data
						 */
        }


        // for each source row create an insert into the same table
        // and use the copyapp_fields to define any exceptions for values
        // to move over

        Wrapper ret = new Wrapper();
        int effectedRows=0,rowNumber=0;



        if (processSourceRows)
          while(srcRows.next()) {

              ArrayList<String> paramVals2 = new ArrayList<String>();
              rowNumber++;
              //System.out.println(rowNumber+": "+tableName);

              // need to still call this even if deleting rows because
              // it will set globals vars needed by child table selects

              if (exporting || deleteRows) { // set globals from this row

                 setGlobalsFromSrcRow(copyAppFields,srcRows,ret,currRow,tableName);
                               // modifies globals in ret variable
              }
              else // copy app
                 select = createInsertStatement(tableCols,tableName,copyAppFields,parentVars,
                                                srcRows,ret,resp,deleteRows,additionalParms,addingRequestor, paramVals2);

              // System.out.println(select);



              // execute this insert to copy this row

              if (deleteRows || exporting || (addingRequestor && select.length()==0)) {
                  didntCopy=true;            // true when don't want to copy credit_request, set by createInsertStmt
              }
              // exported rows done above
              else {
				PreparedStatement pstmt2 = null;
                    // execute insert
                 try {

                	 /**
                      * OWASP TOP 10 - 2010 A1 SQL Injection
                      * TTP 324955 Security Remediation Fortify Scan
                      */
                	 pstmt2 = con.prepareStatement(SQLSecurity.basicSanitize(select));
                    int placeCt2 = 1; 
                    for(int i = 0; i < paramVals2.size(); i++){
                      String v = paramVals2.get(i);
					 // logMsg("v is..." +v);
                      if(v.startsWith("'")){
                        pstmt2.setString(placeCt2++, OWASPSecurity.validationCheck(v.substring(1,v.length() - 1),OWASPSecurity.SQLPARAMSTRING));
                      }
                      else if(v.contains(".")){
                        pstmt2.setFloat(placeCt2++, Float.valueOf(v));
                      }
                      else if(v.equals("NULL")){
						pstmt2.setString(placeCt2++, null);
					  } 
					  else {
                        pstmt2.setLong(placeCt2++, Long.valueOf(v));
                      }
                    }

                	 effectedRows = pstmt2.executeUpdate();
                	 }
                 catch (Exception e) {
				     logMsg("DEBUG MESSAGE: CopyApp.java doCopy Method : FAILED for select: "+select, e);
                     throw new Exception(e.toString()+" for: "+select, e);
                 } finally {
					//close prepared statement
					try{ if(pstmt2 != null) pstmt2.close(); } catch(Exception e1){e1.printStackTrace();}
			}
              }

              // make a recursive call to copy the child tables

              if (!cachedTransType) {
                 childTables.reset();  // reposition to first row
                 while (childTables.next()) {

                     // parentVars is immutable so that as we come back from a
                     // depth first recursion the original state of the
                     // parentVars is intact

                     doCopy(transType,parentVars+ret.addedParentVars,
                            childTables.getColValue(1).trim(),
                            additionalParms,
                            resp,deleteRows,exporting,stmt);


                 } // end child tables
              }
              else {
                  int saveRow;
                  copyAppTables.reset();
                  String lastTable="";
                  while (copyAppTables.next()) {

                      // Don't forget that there are multiple rows for each table
                      // depending on how many copyapp_field rows there are

                      if (tableNum.equals(copyAppTables.getColValue(11).trim())
                          &&
                          !lastTable.equals(copyAppTables.getColValue(10).trim())
                          ) { // 11- parent_table_seq_num

                         // parentVars is immutable so that as we come back from a
                         // depth first recursion the original state of the
                         // parentVars is intact

                         saveRow=copyAppTables.getCurrRowID();
                         lastTable=copyAppTables.getColValue(10).trim();

                         doCopy(transType,parentVars+ret.addedParentVars,
                                copyAppTables.getColValue(10).trim(), // 10 - db_table_name_txt
                                additionalParms,
                                resp,deleteRows,exporting,stmt);

                         copyAppTables.gotoRow(saveRow);


                      } // found a child


                  } // end while child tables

              } // cachedTransType



          } // rows to copy



        if (deleteRows && srcRows.getRowCount()>0) {
           if ((transType.equals("DELETE_CONTRACT") && tableName.equals("CREDIT_REQ_CONTRACT")) ||
               (transType.equals("DELETEAPP_FOR_UPDATE") && tableName.equals("CREDIT_REQUEST")) ||
	       (transType.equals("DELETEAPP_FOR_UPDATE") && tableName.equals("REQUESTOR_HEADER")) ||
	       (transType.equals("DELETEAPP_FOR_UPDATE") && tableName.equals("REQUESTOR")) ||
	       // To support business apps we do not want to delete the requestor_business data either
	       (transType.equals("DELETEAPP_FOR_UPDATE") && tableName.equals("REQUESTOR_BUSINESS")) ||
               // From the portal we do not want to delete any value guide lookup data because if we did then they would have to
               // do the lookup again and they are charged by each lookup
               (transType.equals("DELETEAPP_FOR_UPDATE") && calledByPortal && tableName.equals("CREDIT_REQ_AUTO_KELLY")) ||
               (transType.equals("DELETEAPP_FOR_UPDATE") && calledByPortal && tableName.equals("CREDIT_REQ_AUTO_MAN")) ||
               (transType.equals("DELETEAPP_FOR_UPDATE") && calledByPortal && tableName.equals("CREDIT_REQ_AUTO_NADA")) ||
               (transType.equals("DELETEAPP_FOR_UPDATE") && calledByPortal && tableName.equals("CREDIT_REQ_AUTO_BB")) ||
               (transType.equals("DELETEAPP_FOR_UPDATE") && calledByPortal && tableName.equals("CREDIT_REQ_AUTO_CBB")) ||
               (transType.equals("DELETEAPP_FOR_UPDATE") && calledByPortal && tableName.equals("CREDIT_REQ_AUTO_OFG_DISTR")) ||
               (transType.equals("DELETEAPP_FOR_UPDATE") && calledByPortal && tableName.equals("CREDIT_REQ_AUTO_EQP_KELLY")) ||
               (transType.equals("DELETEAPP_FOR_UPDATE") && calledByPortal && tableName.equals("CREDIT_REQ_AUTO_EQP_MAN")) ||
               (transType.equals("DELETEAPP_FOR_UPDATE") && calledByPortal && tableName.equals("CREDIT_REQ_AUTO_EQP_NADA")) ||
               (transType.equals("DELETEAPP_FOR_UPDATE") && calledByPortal && tableName.equals("CREDIT_REQ_AUTO_EQP_BB")) ||
               (transType.equals("DELETEAPP_FOR_UPDATE") && calledByPortal && tableName.equals("CREDIT_REQ_AUTO_EQP_CBB")) ||
			   (transType.equals("DELETEAPP_FOR_UPDATE") && retainDataOnLoanAppRqUpdt && tableName.equals("CREDIT_REQUEST_PAYOFF"))
                           ) {
             // can't delete the root contract table because verification scrren
             // will fail if it doesn't exist
             // ALSO, DELETEAPP_FOR_UPDATE is used to delete all app related data
             // and keep the credit_request, requestor, and requestor_header for the case where we are
             // updating an app from xmldbt (need requestor for appseqno & remote_ref_num. First used by PQP, LoanAppRq imports
           }
           else {
			PreparedStatement pstmt_delete = null;
              // logMsg(deleteStmt);
              try {
                deleteStmt = "DELETE FROM "+SQLSecurity.sanitize(tableName)+SQLSecurity.sanitize(sLinkName)+SQLSecurity.basicSanitize(whereClause);
				
				pstmt_delete = con.prepareStatement(deleteStmt);
				int placeCt = 1;
				  for(int i = 0; i < paramVals.size(); i++){
					String v = paramVals.get(i);
					if(v.startsWith("'")){
					  pstmt_delete.setString(placeCt++, OWASPSecurity.validationCheck(v.substring(1,v.length() - 1),OWASPSecurity.SQLPARAMSTRING));
					}
					else if(v.contains(".")){
					  pstmt_delete.setFloat(placeCt++, Float.valueOf(v));
					}
					else{
					  pstmt_delete.setLong(placeCt++, Long.valueOf(v));
					}
				  }
					pstmt_delete.executeUpdate();
            	  /**
                   * OWASP TOP 10 - 2010 A1 SQL Injection
                   * TTP 324955 Security Remediation Fortify Scan
                   */
            	  //stmt.executeUpdate(SQLSecurity.basicSanitize(deleteStmt));
            	  }
              catch (Exception e) {
			      logMsg("DEBUG MESSAGE: CopyApp.java doCopy Method : FAILED to delete for deleteStmt: "+deleteStmt, e);
                  throw new Exception(e.toString()+" for: "+deleteStmt, e);
              } finally {
				//close prepared statement
				try{ if(pstmt_delete != null) pstmt_delete.close(); } catch(Exception e1){e1.printStackTrace();}
			  }
           }
        }
        }
        catch (Exception e) {
		    logMsg("DEBUG MESSAGE: CopyApp.java doCopy Method : FAILED ", e);
            throw e;
        }

        // done copying this tables rows

        
    } // end doCopy




/////////////////////////////////////////////////////////////////////////////////


private void setGlobalsFromSrcRow(Query copyAppFields,Query srcRow,Wrapper ret,int currRow,
                                  String tableName
                                  ) throws Exception {


        String writeVar="",colName,srcValue;
        ret.addedParentVars="";
        int col=0;


        /*

        the copyapp fields table may specify fields to be extracted from the src row
        that need to be put in globals (usually keys to be used later).

        */

        /* This should only be called when exporting because the created select
           included the columns only from the copyapp_fields table in the same
           order (hence, the use of col++)
        */

        // extract fields that need to go into globals

        try {
           if (cachedTransType)
              copyAppFields.gotoRow(currRow-1);
           else
              copyAppFields.reset(); // so next() will point to first row

           while(copyAppFields.next()) {
                           // 10 - db_table_name_txt
              if (!copyAppFields.getColValue(10).trim().equals(tableName)) break;

              col++;
              writeVar=copyAppFields.getColValue(7); // write_var_txt
              if (writeVar!=null && writeVar.length()>0)
                  ret.addedParentVars+=writeVar+"="+srcRow.getColValue(col)+"|";
           }
        }
        catch (Exception e) {
            logMsg("DEBUG MESSAGE: CopyApp.java setGlobalsFromSrcRow Method : FAILED "+e.toString(), e);		
		    throw new Exception("CopyApp:setGlobalsFromSrcRow - "+e.toString(), e);
		}


} // end setGlobalsFromSrcRow


/////////////////////////////////////////////////////////////////////////////////


private String createInsertStatement(MetaData tableCols,String tableName,
                                  Query copyAppFields,String parentVars,Query srcRow,
                                  Wrapper ret, CopyAppResponse resp,boolean deleteRows,
                                  String additionalParms,boolean addingRequestor,
                                  ArrayList<String> paramVals
                                  ) throws Exception {
        
        // construct a select statement to get data from the source rows
        // in this table.

        String select = "";
        StringBuilder temp_builder = new StringBuilder("");
        String defaultValue="",action="",readVar="",writeVar="",colName;
        ret.addedParentVars="";


        /* If we are adding a requestor to an existing application then don't
           create an insert statement for the credit_request table */

        if (addingRequestor)
          if (tableName.equals("CREDIT_REQUEST")) return("");


        /*
        Special action: if the additionalParms contains 'lease2loan'
        and we are working on the CREDIT_REQ_LEASE table then create
        an insert statement for the CREDIT_REQ_LOAN table since we
        are changing from lease to loan.

        Converse is true for loan2lease.

        */


        if (tableName.equals("CREDIT_REQ_LEASE") && additionalParms.indexOf("lease2loan")>=0)
            return(createInsertForLoan(parentVars, paramVals));

        if (tableName.equals("CREDIT_REQ_LOAN") && additionalParms.indexOf("loan2lease")>=0)
            return(createInsertForLease(parentVars, paramVals));


      try {

        // otherwise create an insert for the given table

        tableCols.reset(); // so next() will point to first row
        while(tableCols.next()) {

            colName=tableCols.getColValue("column_name");
			
            // Do not copy OFAC_FLG if OFAC lookup is turned off.
            if (tableName.equals("REQUESTOR") && colName.equals("OFAC_FLG") && !Ofac.isEnabled(con,Integer.parseInt(getGlobalVar(parentVars,"#SRC_REQUEST_ID#")))) {
                logMsg("CopyApp.createInsertStatement() Skipping the COLUMN of OFAC for REQUESTOR");
                continue; //Skip this iteration
            }
            
            if (tableCols.supportedDataType(colName)){
              try{
                if (temp_builder.length()==0)
                  temp_builder.insert(0,"INSERT INTO "+SQLSecurity.sanitize(tableName)+" ( "+SQLSecurity.sanitize(colName));
                else
                  temp_builder.append(", "+SQLSecurity.sanitize(tableCols.getColValue("column_name")));
              } catch (SQLException se){
                logMsg("Class " + this.getClass() + "; " + se.toString());
              }
            }
        }
        temp_builder.append(" ) values ( ");

        // now go back thru and fill in the values

        boolean found=false,first=true;
        String srcValue="";

        tableCols.reset(); // so next() will point to first row

        while(tableCols.next()) {

          colName=tableCols.getColValue("column_name");

          // Do not copy OFAC_FLG if OFAC lookup is turned off.
          if (tableName.equals("REQUESTOR") && colName.equals("OFAC_FLG") && !Ofac.isEnabled(con,Integer.parseInt(getGlobalVar(parentVars,"#SRC_REQUEST_ID#")))) {
              logMsg("CopyApp.createInsertStatement() Skipping the VALUE of OFAC for REQUESTOR");
              continue; //Skip this iteration
          }


          
          if (!tableCols.supportedDataType(colName)) continue;

          // see if this column has a row specified in copyapp_fields
          copyAppFields.reset(); // so next() will point to first row
          found=false;
          while(copyAppFields.next()) {
                               // 3 - "db_field_name_txt"
             if (copyAppFields.getColValue(3).toUpperCase().equals(tableCols.getColValue("column_name"))) {
                 found=true;
                 break;
             }
          }



          if (!found) { // just move the value from the source

			
			srcValue=getOrigSourceValue(tableCols,srcRow,colName);
			if(!srcValue.equalsIgnoreCase("NULL") && (
				(tableName.equals("REQUESTOR_OTHER_INCOME") && colName.equals("OTHER_INCOME_SOURCE_ID")) || 
				(tableName.equals("REQUESTOR_EMPLOYER") && colName.equals("OCCUPATION_ID")))){
					String new_request_id = getGlobalVar(parentVars,"#SRC_REQUEST_ID#");
					String source_request_id = getAdditionalParmsVar(additionalParms,"(REQUEST_ID)");
					srcValue=getOrigSourceValueAcrossProductIds(srcValue,source_request_id,new_request_id, tableName, colName);
			}
			
              temp_builder.append(createInsertStatementHelper(srcValue,paramVals,first));
              if (first) {
				first=false;
              }

             continue;
          } // just move the value from the source



          // Use the copyapp_fields row to derive the value to insert

          srcValue=getOrigSourceValue(tableCols,srcRow,colName);


          defaultValue=copyAppFields.getColValue(4); // default_value_txt
          if (defaultValue==null) defaultValue="";
          action=copyAppFields.getColValue(5); // action_txt"
          if (action==null) action="";
          readVar=copyAppFields.getColValue(6); // read_var_txt
          if (readVar==null) readVar="";
          writeVar=copyAppFields.getColValue(7); // write_var_txt
          if (writeVar==null) writeVar="";

          if (defaultValue.length()>0)
              srcValue=defaultValue;
          else
              if (readVar.length()>0) {
                  if (readVar.startsWith("("))
                     srcValue=getAdditionalParmsVar(additionalParms,readVar);
                  else
                     if (readVar.startsWith("#"))
                         srcValue=getGlobalVar(parentVars,readVar);
                  if (srcValue.length()==0) srcValue=null;
              }
              else
                  if (action.length()>0) {

                      if (action.equals("act_newRequestID")) {
                        if (deleteRows)
                          srcValue="0";
                        else
                          srcValue=getNewRequestID();
                        // so it can be returned to the caller of copy()
                        resp.assignedRequestID=srcValue;
                      }
                      else
                      if (action.equals("act_checkSwapLoanType")) {
                         if (srcValue!=null)
                          if (additionalParms.indexOf("lease2loan")>=0)
                              srcValue="1"; // switch to loan type of finance
                          else
                          if (additionalParms.indexOf("loan2lease")>=0)
                              srcValue="2"; // switch to loan type of lease
                      }
                      else
                      if (action.equals("act_checkSwapApplicants")) {
                         if (additionalParms.indexOf("swap-applicants")>=0)
                            if (srcValue!=null)
                               if (srcValue.equals("1"))
                                   srcValue="0";
                               else
                                  if (srcValue.equals("0"))
                                       srcValue="1";
                      }
                      else
                      if (action.equals("act_nextRequestorID")) {
                          if (addingRequestor) {
                        	  String destRequestorId = "";
                        	  destRequestorId = getAdditionalParmsVar(additionalParms,"(DEST_REQUESTOR_ID)");
                        	  
                        	  if(!destRequestorId.isEmpty()) {
                        		  srcValue = destRequestorId;
                        	  } else {
                        		  // use the source request ID to determine the next requestor_id
                        		  srcValue = getNextRequestorID(getGlobalVar(parentVars,"#SRC_REQUEST_ID#"));  
                        	  }
                          }
                          else
                              throw new Exception("act_nextRequestorID is only valid for ADD_REQUESTOR trans type");
                      }
                      else
                          throw new Exception("unrecognized action_txt: "+action);
                  }

          // now add the source value to the insert statement

          if (srcValue==null)
             srcValue="NULL";
          else
             if (!tableCols.isNumeric(tableCols.getColValue("column_name"))
                 && !srcValue.equals("NULL")
                 && !srcValue.equals("SYSDATE")
                 )
                 srcValue="'"+replaceChars(srcValue,"'","''")+"'";


          // if none of these were set then this row exists probly just to
          // support writing the value to globals or a select_var

          if (defaultValue.length()==0 &&
              readVar.length()==0 &&
              action.length()==0)
              srcValue=getOrigSourceValue(tableCols,srcRow,colName);

          temp_builder.append(createInsertStatementHelper(srcValue,paramVals,first));
		  if (first) {
			first=false;
		  }
		   
          
          // Now see if we need to add this value to the global vars to be returned

          if (writeVar.length()>0) {
             if (srcValue.startsWith("'") && srcValue.endsWith("'"))
                 srcValue=srcValue.substring(1,srcValue.length()-1);
             ret.addedParentVars+=writeVar+"="+srcValue+"|";
          } // end adding to ret global vars

        } // next insert column value

        temp_builder.append(" )");
        select = temp_builder.toString();
      } catch (SQLException se){
        log.FmtAndLogMsg("Class " + this.getClass() + "; " + se.toString());
      }
      catch (Exception e) { 
	     logMsg("DEBUG MESSAGE: CopyApp.java createInsertStatement Method : FAILED "+e.toString(), e);
		 throw new Exception("CopyApp:createInsertStatement - "+e.toString(), e);
	  }


      return(select);

} // end createInsertStatement()



String createInsertForLoan(String parentVars, ArrayList<String> paramVals) {

    String newReqID="notfound";
    try {newReqID=getGlobalVar(parentVars,"#NEW_REQUEST_ID#");}
    catch (Exception e) {
	   logMsg("DEBUG MESSAGE: CopyApp.java createInsertForLoan Method : New RequestId Not Found for parentVars: " + log.maskDataForLogging(parentVars,"(SOC_SEC_NUM_TXT)=",5,9) , e); //TTP 333950 CopyApp debug modification - masking SSN if its coming in parentVars variable in case it wasnt already masked
	   newReqID="notfound";
	}
    paramVals.add(newReqID);
    return("INSERT INTO CREDIT_REQ_LOAN (REQUEST_ID) VALUES (?)");


} // createInsertForLoan


String createInsertForLease(String parentVars, ArrayList<String> paramVals) {

    String newReqID="notfound";
    try {newReqID=getGlobalVar(parentVars,"#NEW_REQUEST_ID#");}
    catch (Exception e) {
        logMsg("DEBUG MESSAGE: CopyApp.java createInsertForLease Method : New RequestId Not Found for parentVars: "+ log.maskDataForLogging(parentVars,"(SOC_SEC_NUM_TXT)=",5,9), e); 	 //TTP 333950 CopyApp debug modification - masking SSN if its coming in parentVars variable in case it wasnt already masked
     	newReqID="notfound";
	}
    paramVals.add(newReqID);
    return("INSERT INTO CREDIT_REQ_LEASE (REQUEST_ID,CAP_SALES_TAX_FLG,"+
           "CAP_OTHER_FEES_FLG,CAP_LUXURY_TAX_FLG) VALUES (?,1,1,1)");


} // createInsertForLease




private String getOrigSourceValue(MetaData tableCols,Query srcRow,String colName) throws Exception {

      String srcValue=srcRow.getColValue(colName);

      try {
      if (srcValue==null)
         srcValue="NULL";
      else
         if (!tableCols.isNumeric(colName)
              && !srcValue.equals("NULL")
              && !srcValue.equals("SYSDATE")
              )
           if (tableCols.getDataType(colName)==Types.DATE ||
               tableCols.getDataType(colName)==Types.TIMESTAMP) {

               // jdbc dates are returned as 'yyyy-mm-dd hh:mi:ss.mmm' military
               //
               // remove trailing milliseconds if found

               if (srcValue.indexOf(".")>0)
                   srcValue=srcValue.substring(0,srcValue.indexOf("."));

               if (srcValue.endsWith("00:00:00")) {
                  srcValue=srcValue.substring(0,srcValue.indexOf("00:00:00")).trim();
                  
				  srcValue="TO_DATE('"+srcValue+"','yyyy-mm-dd')";//srcValue="TO_DATE(?,'yyyy-mm-dd')"; (this is what the string is turned into in createInsertStatementHelper)
               }
               else
				srcValue="TO_DATE('"+srcValue+"','yyyy-mm-dd HH24:mi:ss')"; //srcValue="TO_DATE(?,'yyyy-mm-dd')";(this is what the string is turned into in createInsertStatementHelper)
				 
           }
           else // just encircle in quotes
                srcValue="'"+replaceChars(srcValue,"'","''")+"'";
      }
      catch (Exception e) { 
	     logMsg("DEBUG MESSAGE: CopyApp.java getOrigSourceValue Method : FAILED "+e.toString(), e);
		 throw new Exception("CopyApp:getOrigSourceValue - "+e.toString(), e);
	  }

      return(srcValue);

}// getOrigSourceValue

/////////////////////////////////////////////////////////////////////////////////

//copy across product ids for configured values...
private String getOrigSourceValueAcrossProductIds(String sourceValID, String source_request_id, String new_request_id, String tableName, String colName) throws Exception{
	String returnSrcValID = sourceValID;
	String evaluator_id = "";
	String evaluator_id_new = ""; //only used for comparison to make sure apps being copied from and to have same evaluator id
	String source_product_id = "";
	String new_product_id = "";
	String source_descripVal = ""; //source_codeVal = "", 
	
	String sqlGetInfo = "", sqlGetSourceValues = "", sqlGetNewValues ="";
	PreparedStatement ps = null;
	ResultSet rs = null;
	try{
		//look up product id and evaluator id from credit_request
		sqlGetInfo = "select evaluator_id, product_id from credit_request where request_id = ?";
		ps = con.prepareStatement(sqlGetInfo);
		ps.setString(1,OWASPSecurity.validationCheck(source_request_id,OWASPSecurity.SQLPARAMSTRING));
		rs = ps.executeQuery();
		
		if(rs.next()){
			source_product_id = rs.getString("product_id");
			evaluator_id = rs.getString("evaluator_id");
		}
		try{ if(rs != null) rs.close(); }catch(Exception e1){e1.printStackTrace();}
		try{ if(ps != null) ps.close(); }catch(Exception e1){e1.printStackTrace();}
		
		ps = con.prepareStatement(sqlGetInfo);
		ps.setString(1,OWASPSecurity.validationCheck(new_request_id,OWASPSecurity.SQLPARAMSTRING));
		rs = ps.executeQuery();
		
		if(rs.next()){
			new_product_id = rs.getString("product_id");
			evaluator_id_new = rs.getString("evaluator_id");
		}
		try{ if(rs != null) rs.close(); }catch(Exception e1){e1.printStackTrace();}
		try{ if(ps != null) ps.close(); }catch(Exception e1){e1.printStackTrace();}
		
		//if the evaluator id's dont equal (should never actually be the case, but this is the catch all) dont copy the value over
		if(!evaluator_id.equals(evaluator_id_new)){
			return "NULL";
		}
		
		//if the product_ids are equal no need to do any additional logic/lookups - can just move the value over
		if(source_product_id.equals(new_product_id)){
			return returnSrcValID;
		}
		
		if(tableName.equals("REQUESTOR_OTHER_INCOME") && colName.equals("OTHER_INCOME_SOURCE_ID")){
			//look up source's code text and description text...
			sqlGetSourceValues = "SELECT OTHER_INCOME_SOURCE_CD_TXT, OTHER_INCOME_SOURCE_DESC_TXT " + 
			" FROM CONFIG_OTHER_INCOME_SOURCE " +
			" WHERE OTHER_INCOME_SOURCE_ID = ? AND EVALUATOR_ID = ? AND PRODUCT_ID = ? AND ACTIVE_FLG = 1";
			
			ps = con.prepareStatement(sqlGetSourceValues);
			ps.setString(1,OWASPSecurity.validationCheck(sourceValID,OWASPSecurity.SQLPARAMSTRING));
			ps.setString(2,OWASPSecurity.validationCheck(evaluator_id,OWASPSecurity.SQLPARAMSTRING));
			ps.setString(3,OWASPSecurity.validationCheck(source_product_id,OWASPSecurity.SQLPARAMSTRING));
			rs = ps.executeQuery();
			
			if(rs.next()){
				//source_codeVal = rs.getString("OTHER_INCOME_SOURCE_CD_TXT");
				source_descripVal = rs.getString("OTHER_INCOME_SOURCE_DESC_TXT");
			}
			try{ if(rs != null) rs.close(); }catch(Exception e1){e1.printStackTrace();}
		    try{ if(ps != null) ps.close(); }catch(Exception e1){e1.printStackTrace();}
			//use the source's code, sources description as well as the new product id and evaluator id to determine the id to save as the copied value
			sqlGetNewValues = "SELECT OTHER_INCOME_SOURCE_ID " + 
			" FROM CONFIG_OTHER_INCOME_SOURCE " +
			" WHERE EVALUATOR_ID = ? AND PRODUCT_ID = ? " +
			//" AND OTHER_INCOME_SOURCE_CD_TXT = ? "
			" AND OTHER_INCOME_SOURCE_DESC_TXT = ? AND ACTIVE_FLG = 1";
			
			ps = con.prepareStatement(sqlGetNewValues);
			ps.setString(1,OWASPSecurity.validationCheck(evaluator_id,OWASPSecurity.SQLPARAMSTRING));
			ps.setString(2,OWASPSecurity.validationCheck(new_product_id,OWASPSecurity.SQLPARAMSTRING));
			//ps.setString(3,source_codeVal);
			ps.setString(3,OWASPSecurity.validationCheck(source_descripVal,OWASPSecurity.SQLPARAMSTRING));
			
			rs = ps.executeQuery();
			
			if(rs.next()){
				returnSrcValID = rs.getString("OTHER_INCOME_SOURCE_ID");
			}else{
				returnSrcValID = "NULL";
			}
			try{ if(rs != null) rs.close(); }catch(Exception e1){e1.printStackTrace();}
		    try{ if(ps != null) ps.close(); }catch(Exception e1){e1.printStackTrace();}
		}else if(tableName.equals("REQUESTOR_EMPLOYER") && colName.equals("OCCUPATION_ID")){
			//look up source's code text and description text...
			sqlGetSourceValues = "SELECT OCCUPATION_CD_TXT, OCCUPATION_DESC_TXT " + 
			" FROM CONFIG_OCCUPATION " +
			" WHERE OCCUPATION_ID = ? AND EVALUATOR_ID = ? AND PRODUCT_ID = ? AND ACTIVE_FLG = 1 ";
			
			ps = con.prepareStatement(sqlGetSourceValues);
			ps.setString(1,OWASPSecurity.validationCheck(sourceValID,OWASPSecurity.SQLPARAMSTRING));
			ps.setString(2,OWASPSecurity.validationCheck(evaluator_id,OWASPSecurity.SQLPARAMSTRING));
			ps.setString(3,OWASPSecurity.validationCheck(source_product_id,OWASPSecurity.SQLPARAMSTRING));
			rs = ps.executeQuery();
			
			if(rs.next()){
				//source_codeVal = rs.getString("OCCUPATION_CD_TXT");
				source_descripVal = rs.getString("OCCUPATION_DESC_TXT");
			}
			try{ if(rs != null) rs.close(); }catch(Exception e1){e1.printStackTrace();}
		    try{ if(ps != null) ps.close(); }catch(Exception e1){e1.printStackTrace();}
			
			//use the source's code, sources description as well as the new product id and evaluator id to determine the id to save as the copied value
			sqlGetNewValues = "SELECT OCCUPATION_ID " + 
			" FROM CONFIG_OCCUPATION " +
			" WHERE EVALUATOR_ID = ? AND PRODUCT_ID = ? " +
			//" AND OCCUPATION_CD_TXT = ? "
			" AND OCCUPATION_DESC_TXT = ? AND ACTIVE_FLG = 1 ";
			
			ps = con.prepareStatement(sqlGetNewValues);
			ps.setString(1,OWASPSecurity.validationCheck(evaluator_id,OWASPSecurity.SQLPARAMSTRING));
			ps.setString(2,OWASPSecurity.validationCheck(new_product_id,OWASPSecurity.SQLPARAMSTRING));
			//ps.setString(3,source_codeVal);
			ps.setString(3,OWASPSecurity.validationCheck(source_descripVal,OWASPSecurity.SQLPARAMSTRING));
			
			rs = ps.executeQuery();
			
			if(rs.next()){
				returnSrcValID = rs.getString("OCCUPATION_ID");
			}else{
				returnSrcValID = "NULL";
			}
			try{ if(rs != null) rs.close(); }catch(Exception e1){e1.printStackTrace();}
		    try{ if(ps != null) ps.close(); }catch(Exception e1){e1.printStackTrace();}
		}
	}
	catch (Exception e) {
	    logMsg("RID="+source_request_id+" - DEBUG MESSAGE: CopyApp.java getOrigSourceValueAcrossProductIds Method : FAILED for source_request_id: "+source_request_id+" and new_request_id: "+new_request_id+" and sourceValID: "+sourceValID+" and tableName: "+tableName+" and colName: "+colName, e);
	    try{ if(rs != null) rs.close(); }catch(Exception e1){e1.printStackTrace();}
		try{ if(ps != null) ps.close(); }catch(Exception e1){e1.printStackTrace();}
		throw new Exception(e.toString(), e);
	}
	finally{
		try{ if(rs != null) rs.close(); }catch(Exception e1){e1.printStackTrace();}
		try{ if(ps != null) ps.close(); }catch(Exception e1){e1.printStackTrace();}
	}
	return returnSrcValID;
}


/////////////////////////////////////////////////////////////////////////////////


private String createSourceSelect(MetaData tableCols,String tableName,
                                  Query copyAppFields,String parentVars
                                  ) throws Exception {

        // construct a select statement to get data from the source rows
        // in this table.


        String select = "",colName="";

        try {
        tableCols.reset(); // so next() will point to first row
        while(tableCols.next()) {

            colName=tableCols.getColValue("column_name");

            if (tableCols.supportedDataType(colName)) {
               if (select.length()==0)
                   select="SELECT "+SQLSecurity.sanitize(colName);
               else
                   select+=", "+SQLSecurity.sanitize(colName);
            }
        }
        select+=" FROM "+SQLSecurity.sanitize(tableName);
        }
        catch (Exception e) { 
		   logMsg("DEBUG MESSAGE: CopyApp.java createSourceSelect Method : FAILED for tableName: "+tableName+" and parentVars: "+log.maskDataForLogging(parentVars,"(SOC_SEC_NUM_TXT)=",5,9)+" and select: "+select, e); //TTP 333950 CopyApp debug modification - masking SSN if its coming in parentVars variable in case it wasnt already masked
		   throw new Exception("CopyApp:createSourceSelect - "+e.toString(), e);
		}

        return(select);

} // end createSourceSelect()

/////////////////////////////////////////////////////////////////////////////////


private String createExportSelect(Query copyAppFields,String tableName,int currRow,boolean exporting,boolean deleteRows) throws Exception {

        // For exports we only need to select the columns that will be used
        // in copyapp_fields
        // in this table.


        String select = "",colName="";

        try {
        if (cachedTransType)
           copyAppFields.gotoRow(currRow-1);
        else
           copyAppFields.reset(); // so next() will point to first row
        while(copyAppFields.next()) {
                        // 10 - db_table_name_txt
            if (!copyAppFields.getColValue(10).trim().equals(tableName)) break;

            colName=copyAppFields.getColValue(3); // db_field_name_txt
            if (select.length()==0)
                select="SELECT "+ SQLSecurity.sanitize(colName);
            else
                select+=", "+ SQLSecurity.sanitize(colName);
        }
        if (!exporting && deleteRows)
          select+=" FROM "+SQLSecurity.sanitize(tableName)+SQLSecurity.sanitize(sLinkName);
        else
          select+=" FROM "+SQLSecurity.sanitize(tableName);
        } // try
        catch (Exception e) { 
		   logMsg("DEBUG MESSAGE: CopyApp.java createExportSelect Method : FAILED for tableName: "+tableName+" and select: "+select, e);
		   throw new Exception("CopyApp:createExportSelect - "+e.toString(), e);
		}

        return(select);

} // end createExportSelect()


/////////////////////////////////////////////////////////////////////////////////


private String createWhereClause(MetaData tableCols,String tableName,
                                  Query copyAppFields,String parentVars,boolean exporting,
                                  boolean deleteRows,int currRow,boolean addingRequestor,String additionalParms, 
                                  ArrayList<String> paramVals
                                  ) throws Exception {

        // construct a where clause to get data from the source rows
        // in this table.

        
        String select = " WHERE ",colName="";

        String value,columnName,keyValue;
        boolean isCharacter=false;
        int colIndex=0;

        // run thru copyapp_fields for this table and gather all keys to add to
        // where clause

        try {

        if (cachedTransType)
           copyAppFields.gotoRow(currRow-1);
        else
           copyAppFields.reset(); // so next() will point to first row

        while(copyAppFields.next()) {

            colIndex++;

                        // 10 - db_table_name_txt
            if (!copyAppFields.getColValue(10).trim().equals(tableName)) break;

            value=copyAppFields.getColValue(2); // key_flg

            if (value!=null && value.indexOf("1")>=0) { // KEY FIELD

                value=copyAppFields.getColValue(8); // select_var_txt
                // the select_var_txt indicates where to get the value from
                if (value!=null) {
                    // If the value starts with # then it references a
                    // global var, else it is a default value
          					// CL157158. For CREDIT_REQ_DECISIONS_PTIDTI and CREDIT_REQ_DECISIONS_MESSAGE, we need to use DECISION_REF_ID
          					// Rather than changing code to pass in decision_ref_id as parameter, we'll get it from request_id (see below)
          					// CL158568 - Also for EVENT table we need to use evalautor_id and clientt_app_id , that we we'll get from request_id (see below)
          					if((value.equalsIgnoreCase("#SRC_DECISION_REF_ID#")) || (value.equalsIgnoreCase("#SRC_EVALUATOR_ID#")) || (value.equalsIgnoreCase("#SRC_CLIENT_APP_ID#")))
          						keyValue=getGlobalVar(parentVars,"#SRC_REQUEST_ID#");
                    else if (value.startsWith("#"))
                       keyValue=getGlobalVar(parentVars,value);
                    else
                       if (value.startsWith("("))
                          keyValue=getAdditionalParmsVar(additionalParms,value);
                       else
                          keyValue=value; // just use the value

                    if (keyValue.length()>0) { // global var
                                                // 3 - db_field_name_txt
                           columnName=copyAppFields.getColValue(3).toUpperCase();
                           if (!exporting && !deleteRows)
                              isCharacter=!tableCols.isNumeric(columnName);
                           else
                              isCharacter=false; // assuming all keys are NUMERIC to avoid
                                                 // accessing tableCols for perf

                           if (isCharacter) keyValue="'"+keyValue+"'";
                           if (columnName!=null) {
								// CL157158. If DECISION_REF_ID, then get decision_ref_id's corresponding to this request_id
								if(value.equalsIgnoreCase("#SRC_DECISION_REF_ID#")) {
									if (select.endsWith("WHERE ")){
										select+=SQLSecurity.sanitize(columnName)+" in (select decision_ref_id from credit_req_decisions_evaluator where request_id=?) ";
                  }
                  else{
										select+=" and "+SQLSecurity.sanitize(columnName)+" in (select decision_ref_id from credit_req_decisions_evaluator where request_id=?) ";
								  }
                  paramVals.add(keyValue);
								}
								// CL158568 - If EVALUATOR_ID, then get EVALUATOR_ID corresponding to this request_id
								else if(value.equalsIgnoreCase("#SRC_EVALUATOR_ID#")) {
									if (select.endsWith("WHERE "))
										select+=SQLSecurity.sanitize(columnName)+" in (select evaluator_id from credit_request where request_id=?) ";
									else
										select+=" and "+SQLSecurity.sanitize(columnName)+" in (select evaluator_id from credit_request where request_id=?) ";
								  paramVals.add(keyValue);
								}
								// CL158568 - If CLIENT_APP_ID, then get CLIENT_APP_ID corresponding to this request_id
								else if(value.equalsIgnoreCase("#SRC_CLIENT_APP_ID#")) {
									if (select.endsWith("WHERE "))
										select+=SQLSecurity.sanitize(columnName)+" in (select client_app_id from credit_request where request_id=?) ";
									else
										select+=" and "+SQLSecurity.sanitize(columnName)+" in (select client_app_id from credit_request where request_id=?) ";
								  paramVals.add(keyValue);
								}
								// CL157158. Otherwise, process as normal
								else {
								   if (select.endsWith("WHERE "))
									   select+=SQLSecurity.sanitize(columnName)+" = ? ";
								   else
									   select+=" and "+SQLSecurity.sanitize(columnName)+" = ? ";
								  paramVals.add(keyValue);
                }
                           }
                    } // global var value exists
                } // select_var value present
            } // key field
        } // looking for key fields to add to where clause

        }
        catch (SQLException se){
          logMsg("Class " + this.getClass() + "; " + se.toString());
        }
        catch (Exception e) { 
		   logMsg("DEBUG MESSAGE: CopyApp.java createWhereClause Method : FAILED for tableName: "+tableName+" and parentVars: "+log.maskDataForLogging(parentVars,"(SOC_SEC_NUM_TXT)=",5,9)+" and select: "+select, e); //TTP 333950 CopyApp debug modification - masking SSN if its coming in parentVars variable in case it wasnt already masked
		   throw new Exception("CopyApp:createWhereClause - "+e.toString(), e);
		}
        return(select);

} // end createWhereClause()




private String getGlobalVar(String parentVars,String name) throws Exception {

    String keyValue="";
    name=name.trim();
    int idx=parentVars.indexOf(name);
    if (idx>=0) {
       // parentVars format:
       // #name#=value|#name#=value|...
       idx=idx+name.length()+1; // skip past = sign
       keyValue=parentVars.substring(idx,parentVars.indexOf("|",idx));
    }
    return(keyValue);

} // getGlobalVar


private String getAdditionalParmsVar(String additionalParms,String name) throws Exception {

    /*
    additionalParms are set by the caller of copyapp and have the following form:
     (parmname)=value|(parmname2)=value|...   must end with a pipe
    */

    String keyValue="";
    name=name.trim();
    int idx=additionalParms.indexOf(name);
    if (idx>=0) {
       idx=idx+name.length()+1; // skip past = sign
       keyValue=additionalParms.substring(idx,additionalParms.indexOf("|",idx));
    }
    return(keyValue);

} // getAdditionalParmsVar


private String getNewRequestID() throws Exception {

    Query query = new Query(con);

    String select  =  "SELECT GET_NEXT_REQUEST_ID.NEXTVAL AS REQUEST_ID FROM DUAL";

    query.executeQuery(select);

    if (!query.next())  // goto first row
        throw new Exception("getNewRequestID did not return a row");

    String reqID=query.getColValue("request_id");
    return(reqID);

} // getNewRequestID()

private String getNextRequestorID(String requestID) throws Exception {


    Query query = new Query(con);

    String select  =  "select nvl(max(requestor_id)+1,1) as next_id from requestor_header where request_id = "+requestID+" and requestor_id > 0";

    query.executeQuery(select);

    if (!query.next())  // goto first row
        throw new Exception("getNextRequestorID did not return a row");

    String reqID=query.getColValue("next_id");
    return(reqID);

} // getNextRequestorID()




public void logMsg(String msg) {
  if (log !=null) log.FmtAndLogMsg(msg);
}

private void logMsg(String msg, Throwable throwable) {
  if (log !=null) log.FmtAndLogMsg(msg, throwable);
}

public boolean isNumeric(int type){
    switch(type) {
         case    Types.BIGINT            :
         case    Types.BIT               :
         case    Types.DECIMAL           :
         case    Types.DOUBLE            :
         case    Types.FLOAT             :
         case    Types.INTEGER           :
         case    Types.NUMERIC           :
         case    Types.REAL              :
         case    Types.SMALLINT          :
         case    Types.TINYINT           :
                 return(true);
    }
    return(false);

} // isNumeric



public String replaceChars(String target,String removeStr,String replaceWith) {

    if (target.indexOf(removeStr)<0) return(target);
    int idx=0,removeLength=removeStr.length(),offset=0;
    while ((idx=target.indexOf(removeStr,offset))>=0) {
        String prefix="",suffix="";
        if (idx>0) 
            prefix=target.substring(0,idx);
        if (idx+removeLength+1<=target.length())
            suffix=target.substring(idx+removeLength);
        offset=prefix.length()+replaceWith.length();
        target=prefix+replaceWith+suffix;
        //System.out.println(target);
        if (offset>=target.length()) break;
    } // while
    return(target);

} 

public String createInsertStatementHelper(String srcValue, ArrayList<String> paramVals, boolean first){
	String helperReturn = "";
	
	//if the string contains to_date, parse out the string text and concatenate it to the sql stringbuffer with bind variable logic
	if(srcValue.contains("TO_DATE")){
			
		String addToQueryString = srcValue.substring(0, srcValue.indexOf('\'', 0)) + "?" + srcValue.substring(srcValue.indexOf(',', 0)) ; 
		String valueToBind = srcValue.substring(srcValue.indexOf('\'', 0),srcValue.indexOf(',', 0));
		
		if (first) {
			helperReturn = addToQueryString;
		}
		  else {
			  helperReturn = ", "+addToQueryString;	
		}
		paramVals.add(valueToBind); 
	} else if (srcValue.equals("SYSDATE")){ 
		if (first) {
			helperReturn = srcValue;
		}
		else{
			helperReturn = ", " + srcValue;
		}
		//do not append to paramVals
	} else {
		if (first) {
			helperReturn = "?";
		}
		else{
			helperReturn = ", ?";
		}
		paramVals.add(srcValue);
	}
	
	return helperReturn;
}

} // CopyApp




