package com.cmsinc.origenate.bbt.persistence;

import java.io.Serializable;
import java.sql.Date;

import com.cmsinc.origenate.evaluator.persistence.Evaluator;
import com.cmsinc.origenate.util.persistence.BaseDataObject;

/**
 * @hibernate.class table="CREDIT_REQ_BBT_SETUP"
 *
 */
public class CreditReqBbtSetup extends BaseDataObject {
	static final long serialVersionUID = 1L;

	private Integer requestId;
	private Evaluator evaluator;
	private Integer appseqno;
	private String applicantAccountNumber;
	private String coAppAccountNumber;
	private String coSigner1AccountNumber;
	private String coSigner2AccountNumber;
	private String reconcilNumber;
	private String noteNumber;
	private String recourse;
	private String recourseAmount;
	private String recoursePercent;
	private String customerIdType;
	private String schedule;
	private Boolean eltCode;
	private Boolean docstmpCode;
	private String mktCode;
	private String altDlrProgCode;

	private String bbtGap;
	private String prePaidFinCharge;
	private String docStmpFee;
	private String rateBuydownFee;

	private String contractType;
	private Boolean returnPaymentFlg;
	private Boolean firstPreferShipFlg;
	private String serviceContractTerm;

	private String businessAccountNumber;
	private String borrower2RecNumber;
	private String borrower2AdType;
	private String borrower3RecNumber;
	private String borrower3AdType;
	private String borrower4RecNumber;
	private String borrower4AdType;
	private String lateChargeCode;
	private Boolean useAltAddrFlg;

	private String officerNumber;

	private boolean readOnly;

	public CreditReqBbtSetup() {
	}

	public Serializable getPrimaryKey() {
		return this.requestId;
	}

	/**
	 * @hibernate.id column="request_id" generator-class="assigned"
	 */
	public Integer getId() {
		return this.requestId;
	}

	public void setId(Integer id) {
		this.requestId = id;
	}

	public Integer getRequestId() {
		return getId();
	}

	public void setRequestId(Integer requestId) {
		setId(requestId);
	}

	/**
	 * @hibernate.many-to-one column="evaluator_id" not-null="true" lazy="false"
	 */
	public Evaluator getEvaluator() {
		return evaluator;
	}

	public void setEvaluator(Evaluator e) {
		this.evaluator = e;
	}

	public Integer getEvaluatorId() {
		return evaluator.getId();
	}

	/**
	 * @hibernate.property column="appseqno"
	 */
	public Integer getAppseqno() {
		return this.appseqno;
	}

	public void setAppseqno(Integer appseqno) {
		this.appseqno = appseqno;
	}

	/**
	 * @hibernate.property column="applicant_account_num"
	 */
	public String getApplicantAccountNumber() {
		return this.applicantAccountNumber;
	}

	public void setApplicantAccountNumber(String accno) {
		this.applicantAccountNumber = accno;
	}

	/**
	 * @hibernate.property column="coapp_account_num"
	 */
	public String getCoAppAccountNumber() {
		return this.coAppAccountNumber;
	}

	public void setCoAppAccountNumber(String accno) {
		this.coAppAccountNumber = accno;
	}

	/**
	 * @hibernate.property column="cosigner1_account_num"
	 */
	public String getCoSigner1AccountNumber() {
		return this.coSigner1AccountNumber;
	}

	public void setCoSigner1AccountNumber(String accno) {
		this.coSigner1AccountNumber = accno;
	}

	/**
	 * @hibernate.property column="cosigner2_account_num"
	 */
	public String getCoSigner2AccountNumber() {
		return this.coSigner2AccountNumber;
	}

	public void setCoSigner2AccountNumber(String accno) {
		this.coSigner2AccountNumber = accno;
	}

	/**
	 * @hibernate.property column="reconcil_num"
	 */
	public String getReconcilNumber() {
		return this.reconcilNumber;
	}

	public void setReconcilNumber(String recno) {
		this.reconcilNumber = recno;
	}

	/**
	 * @hibernate.property column="note_num"
	 */
	public String getNoteNumber() {
		return this.noteNumber;
	}

	public void setNoteNumber(String noteno) {
		this.noteNumber = noteno;
	}

	/**
	 * @hibernate.property column="recourse_txt"
	 */
	public String getRecourse() {
		return this.recourse;
	}

	public void setRecourse(String res) {
		this.recourse = res;
	}

	/**
	 * @hibernate.property column="recourse_amt"
	 */
	public String getRecourseAmount() {
		return this.recourseAmount;
	}

	public void setRecourseAmount(String resamt) {
		this.recourseAmount = resamt;
	}

	/**
	 * @hibernate.property column="recourse_pct"
	 */
	public String getRecoursePercent() {
		return this.recoursePercent;
	}

	public void setRecoursePercent(String recper) {
		this.recoursePercent = recper;
	}

	/**
	 * @hibernate.property column="cust_id_type"
	 */
	public String getCustomerIdType() {
		return this.customerIdType;
	}

	public void setCustomerIdType(String custid) {
		this.customerIdType = custid;
	}

	/**
	 * @hibernate.property column="schedule_txt"
	 */
	public String getSchedule() {
		return this.schedule;
	}

	public void setSchedule(String schd) {
		this.schedule = schd;
	}

	/**
	 * @hibernate.property column="elt_code"
	 */
	public Boolean getEltCode() {
		return this.eltCode;
	}

	public void setEltCode(Boolean ec) {
		this.eltCode = ec;
	}

	/**
	 * @hibernate.property column="docstmp_code"
	 */
	public Boolean getDocstmpCode() {
		return this.docstmpCode;
	}

	public void setDocstmpCode(Boolean dc) {
		this.docstmpCode = dc;
	}

	/**
	 * @hibernate.property column="mkt_code"
	 */
	public String getMktCode() {
		return this.mktCode;
	}

	public void setMktCode(String mc) {
		this.mktCode = mc;
	}

	/**
	 * @hibernate.property column="alt_dlr_prog_code_num"
	 */
	public String getAltDlrProgCode() {
		return this.altDlrProgCode;
	}

	public void setAltDlrProgCode(String adpc) {
		this.altDlrProgCode = adpc;
	}
	
	/**
	 * @hibernate.property column="bbt_gap"
	 */
	public String getBbtGap() {
		return this.bbtGap;
	}

	public void setBbtGap(String bg) {
		this.bbtGap = bg;
	}

	/**
	 * @hibernate.property column="prepaid_fin_charge"
	 */
	public String getPrePaidFinCharge() {
		return this.prePaidFinCharge;
	}

	public void setPrePaidFinCharge(String pfc) {
		this.prePaidFinCharge = pfc;
	}

	/**
	 * @hibernate.property column="doc_stmp_fee"
	 */
	public String getDocStmpFee() {
		return this.docStmpFee;
	}

	public void setDocStmpFee(String dsf) {
		this.docStmpFee = dsf;
	}

	/**
	 * @hibernate.property column="rate_buydown_fee"
	 */
	public String getRateBuydownFee() {
		return this.rateBuydownFee;
	}

	public void setRateBuydownFee(String rbf) {
		this.rateBuydownFee = rbf;
	}

	/**
	 * @hibernate.property column="contract_type"
	 */
	public String getContractType() {
		return this.contractType;
	}

	public void setContractType(String ct) {
		this.contractType = ct;
	}

	/**
	 * @hibernate.property column="return_payment_flg"
	 */
	public Boolean getReturnPaymentFlg() {
		return this.returnPaymentFlg;
	}

	public void setReturnPaymentFlg(Boolean rpf) {
		this.returnPaymentFlg = rpf;
	}

	/**
	 * @hibernate.property column="first_prefer_ship_flg"
	 */
	public Boolean getFirstPreferShipFlg() {
		return this.firstPreferShipFlg;
	}

	public void setFirstPreferShipFlg(Boolean fpsf) {
		this.firstPreferShipFlg = fpsf;
	}

	/**
	 * @hibernate.property column="service_contract_term"
	 */
	public String getServiceContractTerm() {
		return this.serviceContractTerm;
	}

	public void setServiceContractTerm(String sct) {
		this.serviceContractTerm = sct;
	}

	/**
	 * @hibernate.property column="business_account_num"
	 */
	public String getBusinessAccountNumber() {
		return this.businessAccountNumber;
	}

	public void setBusinessAccountNumber(String ban) {
		this.businessAccountNumber = ban;
	}

	/**
	 * @hibernate.property column="borrower2_rec_num"
	 */
	public String getBorrower2RecNumber() {
		return this.borrower2RecNumber;
	}

	public void setBorrower2RecNumber(String b2rn) {
		this.borrower2RecNumber = b2rn;
	}

	/**
	 * @hibernate.property column="borrower2_ad_type"
	 */
	public String getBorrower2AdType() {
		return this.borrower2AdType;
	}

	public void setBorrower2AdType(String b2at) {
		this.borrower2AdType = b2at;
	}

	/**
	 * @hibernate.property column="borrower3_rec_num"
	 */
	public String getBorrower3RecNumber() {
		return this.borrower3RecNumber;
	}

	public void setBorrower3RecNumber(String b3rn) {
		this.borrower3RecNumber = b3rn;
	}

	/**
	 * @hibernate.property column="borrower3_ad_type"
	 */
	public String getBorrower3AdType() {
		return this.borrower3AdType;
	}

	public void setBorrower3AdType(String b3at) {
		this.borrower3AdType = b3at;
	}

	/**
	 * @hibernate.property column="borrower4_rec_num"
	 */
	public String getBorrower4RecNumber() {
		return this.borrower4RecNumber;
	}

	public void setBorrower4RecNumber(String b4rn) {
		this.borrower4RecNumber = b4rn;
	}

	/**
	 * @hibernate.property column="borrower4_ad_type"
	 */
	public String getBorrower4AdType() {
		return this.borrower4AdType;
	}

	public void setBorrower4AdType(String b4at) {
		this.borrower4AdType = b4at;
	}

	/**
	 * @hibernate.property column="late_charge_code"
	 */
	public String getLateChargeCode() {
		return this.lateChargeCode;
	}

	public void setLateChargeCode(String lcc) {
		this.lateChargeCode = lcc;
	}

	/**
	 * @hibernate.property column="USE_ALT_ADDR_FLG"
	 */
	public Boolean getUseAltAddrFlg() {
		return this.useAltAddrFlg;
	}

	public void setUseAltAddrFlg(Boolean uaaf) {
		this.useAltAddrFlg = uaaf;
	}

	/**
	 * @hibernate.property column="officer_number_txt"
	 */
	public String getOfficerNumber() {
		return this.officerNumber;
	}

	public void setOfficerNumber(String on) {
		this.officerNumber = on;
	}

	public void setReadOnly(boolean status) {
		this.readOnly = status;
	}

	public boolean getReadOnly() {
		return readOnly;
	}
}