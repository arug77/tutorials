
package com.cmsinc.origenate.ae.copyapp;

import java.io.*;
import java.sql.*;
import java.util.*;

/** <pre>
 *
 * CopyAppResponse.java   Created:  Aug 06, 2001
 *
 * Response object returned by CopyApp.copy method.
 *
 * Implemented as a class for future additions of items to return
 *
 * @author  Glenn Leyba
 * @version 1.0
 *
 * </pre>
 */

public class CopyAppResponse { 


    public String assignedRequestID="";


    // Constructor

    public CopyAppResponse() {}
                      

} // CopyAppResponse



