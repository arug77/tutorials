package com.cmsinc.origenate.ae;

/**
 * @author kylet
 *
 */
public class ChangeProductFields {
	
	private String requestId;
	private String evaluatorId;
	private String productId;
	private String loanPurpose;
	private String program;

	/**
	 * @param evaluatorId
	 * @param loanPurpose
	 * @param productId
	 * @param program
	 * @param requestId
	 */
	public ChangeProductFields(String evaluatorId, String loanPurpose, String productId, String program, String requestId) {
		super();
		this.evaluatorId = evaluatorId;
		this.loanPurpose = loanPurpose;
		this.productId = productId;
		this.program = program;
		this.requestId = requestId;
	}

	/**
	 * @return the requestId
	 */
	public String getRequestId() {
		return this.requestId;
	}

	/**
	 * @param requestId the requestId to set
	 */
	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}

	/**
	 * @return the evaluatorId
	 */
	public String getEvaluatorId() {
		return this.evaluatorId;
	}

	/**
	 * @param evaluatorId the evaluatorId to set
	 */
	public void setEvaluatorId(String evaluatorId) {
		this.evaluatorId = evaluatorId;
	}

	/**
	 * @return the productId
	 */
	public String getProductId() {
		return this.productId;
	}

	/**
	 * @param productId the productId to set
	 */
	public void setProductId(String productId) {
		this.productId = productId;
	}

	/**
	 * @return the loanPurpose
	 */
	public String getLoanPurpose() {
		return this.loanPurpose;
	}

	/**
	 * @param loanPurpose the loanPurpose to set
	 */
	public void setLoanPurpose(String loanPurpose) {
		this.loanPurpose = loanPurpose;
	}

	/**
	 * @return the program
	 */
	public String getProgram() {
		return this.program;
	}

	/**
	 * @param program the program to set
	 */
	public void setProgram(String program) {
		this.program = program;
	}

	public ChangeProductFields(){}

}
