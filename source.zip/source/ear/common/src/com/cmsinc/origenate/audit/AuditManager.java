/****************************************************************************************************************
   Company: First American CMSI
    Product: Origenate
    Version: Beta
    Author: Akash Pandya
    Copyright (c) 2002. All rights reserved

    Description: Implementation of ApplicationStatusInterface interface to get and set application statuses (decision, app, activity).
                 Also provides additional methods.
*******************************************************************************************************************/

package com.cmsinc.origenate.audit;

import com.cmsinc.origenate.util.DBConnection;

import java.sql.*;

import com.cmsinc.origenate.util.LogMsg;

import java.sql.Connection;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.PreparedStatement;
import java.sql.Date;
import java.util.*;
import java.sql.Timestamp;

import javax.naming.*;
import javax.sql.DataSource;

import com.cmsinc.origenate.util.IniFile;

import org.apache.commons.lang.StringUtils;

public class AuditManager  {

  //Set debugger
  //private boolean b_debugger = false;
  private String keyDescription = "",keyId = "",descQuery = "";
  private String tokens[] = null, keyTokens[] = null;
  //private String qryTokens[] = null;
  //private String table = "", column = "", QUERY_SQL = "";
  PreparedStatement stmt = null;
  ResultSet rs = null;
  protected java.sql.Connection conn;
  protected LogMsg log = new LogMsg();
  //private boolean b_clsConnection = true, b_clsConnectionlocal = true,  b_otherConnection = false;
  public String errMsg = "";
  static String prev_iniFileName="";
  static String prev_clientName="";
  static int s_i_debug_memory = -1;
  

    /***************************************************************/
    /* Create AuditManager obejct and get DB connection */
    /***************************************************************/
	
  public AuditManager(String s_LogName, String s_iniFile) throws Exception {

     String s_clientName = null;
     //Get ini file values for DB connection
     /* GL. 1/7/05 Performance
     Do not reread ini file if it has not changed since the last call
     */
     if (prev_iniFileName.compareToIgnoreCase(s_iniFile)!=0) {
        // changed so reset class vars
        IniFile ini = new IniFile();
        ini.readINIFile(s_iniFile);
        s_clientName = ini.getINIVar("general.client_name");
        set_prev_iniFileName(s_iniFile);
        set_prev_clientName(s_clientName);
     }
     else
        s_clientName = prev_clientName;

      log.openLogFile(s_LogName);

    // Instantiate InitialContext
     javax.naming.InitialContext ctx=null;
     try {
       ctx = new javax.naming.InitialContext();


           // Lookup the datasource
       javax.sql.DataSource  ds = (javax.sql.DataSource) ctx.lookup(s_clientName + "_origpool");

       // Get the connection from the datasource
       this.conn = ds.getConnection();


      if (this.conn == null) {
             log.FmtAndLogMsg("***Connection is null in calling AuditManager ***");
      } else {
       //If debug option is not saved then check for it
      if (s_i_debug_memory == -1) {
        set_s_i_debug_memory(this.log.getDebugSetting(conn));
      }
      if (s_i_debug_memory == 1) {
         log.FmtAndLogMsg("AM:AuditManager:OPEN:Connect using connection pool");
       }
      }
	// Clear the hash table
	AuditServiceInitializationFactory.storedDescriptions.clear();
     } catch (Exception e) {
        log.FmtAndLogMsg("DEBUG MESSAGE: AuditManager.java AuditManager Constructor :Error ", e);
     }
 }



    /***************************************************************/
    /*         get Primary Key  Value with Description Appended    */
    /***************************************************************/
   public String getPrimaryKeyValues(String evaluator_id, String tableName,String primaryKey) throws Exception  {
        
		keyDescription = "";
		String product_id = "";
		// Find If we already have whole primary key with description stored in hash table.
		// If yes, return that description, no need to generate again.
		if(!AuditServiceInitializationFactory.storedDescriptions.isEmpty() && AuditServiceInitializationFactory.getStoredKeyDescription(tableName,primaryKey) != null) {
			return ((String)AuditServiceInitializationFactory.getStoredKeyDescription(tableName,primaryKey));
		}
		
		try {
			/* Splits Primary key */
			/* e.g. If PrimaryKey is: EVALUATOR_ID:65,PRODUCT_ID:1*/
			/* Then here it creates token of primary key, so token1 = EVALUATOR_ID:65 & token2 = PRODUCT_ID:1*/
			tokens = primaryKey.split(",");
			// Loop through every token
			for (int i = 0; i < tokens.length; i++) {
			  keyId = (tokens[i]); // Find Token Value. e.g. EVALUATOR_ID:65
			  
					// Following 5 tables comes in special scenario, where primary key's description depends on that keyId, evaluator_id and product_id
					// we will get keyId from stringtoken, evaluator_id from arguments, but we need product_id
					// so if this table comes in, then save product_id in one saved variable
					//NOTE: we need to save product_id above If condition, because there we check if already have saved product_id description then directly return that description.. 
					//		and primary key should look like EVALUATOR_ID:65,PRODUCT_ID:1,PROGRAM_ID:1 (product_id must come before keyId, else it won't find value of product_id)
					if(tableName.equals("CONFIG_OUTSIDE_SOURCE") || tableName.equals("CONFIG_PRODUCT_PROGRAM") || tableName.equals("CONFIG_PROMO") || tableName.equals("CONFIG_SALES_METHOD") || tableName.equals("CONFIG_SUB_PROGRAM")) {
						keyTokens = keyId.split(":");
						if(keyTokens[0].equalsIgnoreCase("product_id"))
								// save value od product_id
								product_id = keyTokens[1];
					}
			  
			   		// Find If we already have primary key token value with description stored in hash table.
					// If yes, return that description, no need to generate again.
					if(!AuditServiceInitializationFactory.storedDescriptions.isEmpty() && AuditServiceInitializationFactory.getStoredKeyDescription(tableName,keyId) != null) {
						keyDescription = keyDescription + ((String)AuditServiceInitializationFactory.getStoredKeyDescription(tableName,keyId)); 
					}
					/* If Its not stored in hash table than, split the token and select description and store into hash table, */
					/* Splits Token*/
					/* e.g. If Token is: EVALUATOR_ID:65 */
					/* Then here it fetches value of that token, so token1 = EVALUATOR_ID & token2 = 65 */
					else {
						keyDescription = keyDescription + tokens[i]; // Append that to Final Return String
						keyTokens = keyId.split(":");
												
						// Look for query to be executed for description into hash table
						descQuery = AuditServiceInitializationFactory.getKeyDescription(tableName,keyTokens[0]);
						// If there is entry in hash table for this ID , then fetch its description
						if(descQuery != null) {
							// Executes Query
							stmt = conn.prepareStatement(descQuery);
							stmt.setString(1,keyTokens[1]);
							
							//CL157294
							// If descQuery contains more than 2 '?' characters, that means we need to set second parameter and it must be evaluator_id (e.g. see description of TASK_ID in AuditServiceInitializationFactory class)
							if((StringUtils.countMatches(descQuery, "?")) >= 2)
								stmt.setString(2,evaluator_id);
							// If descQuery contains 3 '?' characters, that means we need to set third parameter and it must be product_id (e.g. see description of PROGRAM_ID in AuditServiceInitializationFactory class)
							if((StringUtils.countMatches(descQuery, "?")) == 3)
								stmt.setString(3,product_id);
								
							try {
								rs = stmt.executeQuery();
								// If it contains Description, Append in the end
								// e.g. EVALUATOR_ID:65(PRODUCT TEST)
								if(rs.next()) {
									keyDescription = keyDescription + "("+rs.getString(1)+")";
									// Store that key with its description into another hash table, so next time if same primary key with its values come, then we can avoid select statements.
									AuditServiceInitializationFactory.storedDescriptions.put(keyId,keyId+"("+rs.getString(1)+")");
								}
							} catch (SQLException ex) {
							    log.FmtAndLogMsg("DEBUG MESSAGE: AuditManager.java getPrimaryKeyValues Method :FAILED to execute query for evaluatorId: "+evaluator_id+" and tableName: "+tableName+" and primaryKey: "+primaryKey+" and keyDescription: "+keyDescription, ex);
							    keyDescription = keyDescription + ","; 
							  }
						
						}
						
					}
					
				if(i+1 != tokens.length)
					keyDescription = keyDescription + ",";				
			}
			// Store that key with its description into another hash table, so next time if same primary key with its values come, then we can avoid select statements.
			AuditServiceInitializationFactory.storedDescriptions.put(primaryKey,keyDescription);
			// return Final Primary key with description
			return keyDescription;
			
			  
		}
		catch (Exception ex) {
		  log.FmtAndLogMsg("DEBUG MESSAGE: AuditManager.java getPrimaryKeyValues Method :FAILED for evaluatorId: "+evaluator_id+" and tableName: "+tableName+" and primaryKey: "+primaryKey, ex);
		  return ex.getMessage();
		}
   }
	private static void set_prev_iniFileName(String prev_iniFileName_in){
		prev_iniFileName = prev_iniFileName_in;
	}
	
	private static void set_prev_clientName(String prev_clientName_in){
		prev_clientName = prev_clientName_in;
	}
	
	private static void set_s_i_debug_memory(int s_i_debug_memory_in){
		s_i_debug_memory = s_i_debug_memory_in;
	}

}
