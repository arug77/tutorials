
package com.cmsinc.origenate.ae.copyapp;

import java.sql.*;
import java.util.Vector;
import java.util.Enumeration;
import com.cmsinc.origenate.util.LogMsg;

public class Query {

    private Connection conn;
    private Vector rows;
    private int currRow = -1;
    private int numCols=0;
    private String s_colname[];
    private int sqltypes[];
    

    public Query(Connection conn) {
        this.conn=conn;
    }// constructor


    public void executeQuery(String selectStmt) throws Exception {
        executeSelect(selectStmt,true);
    } // executeQuery

    public void executeQuery(String selectStmt,boolean getMetaData) throws Exception {
        executeSelect(selectStmt,getMetaData);
    } // executeQuery

    public void executeSelect(String selectStmt,boolean getMetaData) throws Exception {
        
        rows = new Vector();

        Statement statement = null;
        RowData rd=null;
        ResultSet rs=null;
        LogMsg log = new LogMsg(); 
        try {

        statement = conn.createStatement();
        rs = statement.executeQuery(selectStmt);


        numCols = rs.getMetaData().getColumnCount();

        if (getMetaData) {
           int ix;
           // get a list of the column names returned for future reference
           s_colname = new String[numCols];
           sqltypes = new int[numCols];
           for (ix=0;ix<s_colname.length;ix++) {
                s_colname[ix] = rs.getMetaData().getColumnName((ix+1));
                sqltypes[ix]=rs.getMetaData().getColumnType(ix+1);
               //System.out.println(s_colname[ix]);
           }
        }

        // now load up the rows found into the rows vector

        while ( rs.next() ) {
            rd = new RowData(rs,numCols);
            rd.setData(rs);
            rows.addElement(rd);
        } // rs.next

        }
        catch (Exception e) {
		    log.FmtAndLogMsg("DEBUG MESSAGE: MetaData.java executeSelect Method : Error executing query for  selectStmt: "+selectStmt+" and getMetaData: "+getMetaData+"  "+e.toString(), e);
            // statement closed in finally block
            throw new Exception("Error executing query: "+e.toString(), e);
        }
        finally {
			try{ if(rs != null) rs.close(); }catch(Exception e1){e1.printStackTrace();}
			try{ if(statement != null) statement.close(); }catch(Exception e1){e1.printStackTrace();}
        }

        currRow = -1;

    } // executeSelect


    public final int getRowCount() { return(rows.size()); }

    public final int getNumCols() { return(numCols); }

    public final void gotoRow(int row) { currRow=row; } // zero based

    public final int getCurrRowID() { return(currRow); }

    public final void reset() { currRow = -1; } // so next() will get first row

    public final String getColName(int col)  { // 1 based
        return(s_colname[col-1]);
    }
    public final int getColType(int col)  { // 1 based
        return(sqltypes[col-1]);
    }

    public final boolean next() {
        currRow++;
        return((currRow>(rows.size()-1)) ? false : true);
    }

    public final String getColValue(String colName) throws Exception {
        //System.out.println(colName);
        return(((RowData)rows.elementAt(currRow)).getColValue(getColPosition(colName)));
    }

    public final String getColValue(int colIndex) throws Exception { // 1- first col
        //System.out.println(colName);
        return(((RowData)rows.elementAt(currRow)).getColValue(colIndex));
    }


    public final int getColPosition(String colName) throws Exception {
        for (int ix=0;ix<s_colname.length;ix++)
            if (colName.equalsIgnoreCase(s_colname[ix])) return(ix+1);
        return(0);
    }// getColPosition


}
