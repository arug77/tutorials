package com.cmsinc.origenate.ae.copyapp;

import java.sql.*;
import com.cmsinc.origenate.util.LogMsg;

public class RowData {

    private String values[];

    public RowData(ResultSet rs,int numColumns) throws Exception{
        values = new String[numColumns];

    }// constructor


    public void setData(ResultSet rs) throws Exception { // for a row
        int ix;
		LogMsg log = new LogMsg(); 
        for (ix=0;ix<values.length;ix++){
            try {
                values[ix] = null;
                if (rs.getMetaData().getColumnType(ix+1)!=Types.CLOB)
                   values[ix] = rs.getString(ix+1);
                if (rs.wasNull()) values[ix] = null;
            }
            catch (Exception e) {
			    log.FmtAndLogMsg("DEBUG MESSAGE: RowData.java setData Method : Exception occured getting column value in "+ getClass() + ":"+ e.toString(), e);
                throw new Exception("Exception occured getting column value in "+ getClass() + ":"+ e.toString(), e);
            }
        }
    }

    public final String getColValue(int idx) { return(values[idx-1]); }



}
