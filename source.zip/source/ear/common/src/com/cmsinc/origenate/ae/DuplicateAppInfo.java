package com.cmsinc.origenate.ae;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import com.cmsinc.origenate.util.ConnectionFactory;

/**
 * Class for recording additional info for Duplicate Requestors 
 * to REQUESTOR_DUP_APPLICATIONS
 * 156965
 * 
 * @author Nestor Walker
 *
 */
public class DuplicateAppInfo {
	private Connection con;
	private PreparedStatement dupInsert, dupCheck;
	private PreparedStatement dupSelect;
	private int requestID;
	private int requestorID;
	private int appseqno;
	private int requestorTypeID;
	private String entityTxt;
    private boolean closeConnection;

	/**
	 * Sets up the new app which duplicates are compared to.
	 */
	public DuplicateAppInfo(int requestID, int requestorID, Connection con) {
		this.con = con;
        this.closeConnection = false;
		setup(requestID, requestorID, con);
	}
	
	/**
	 * Constructor for cf pages.
	 * Sets up the new app which duplicates are compared to.
	 */
	public DuplicateAppInfo(int requestID, int requestorID, String iniPath) {
		try {
			ConnectionFactory.init(iniPath);
			this.con = ConnectionFactory.getConnection();
		} catch (Exception e) {
		    System.out.println("RID="+requestID+" - DEBUG MESSAGE: DuplicateAppInfo.java DuplicateAppInfo Constructor : DUP APP INFO: Error getting connection for requestID: "+requestID+" and requestorID: "+requestorID+" and iniPath: "+iniPath); 
			e.printStackTrace();
		}
        this.closeConnection = true;
		setup(requestID, requestorID, con);
	}
	
	private void setup(int requestID, int requestorID, Connection con) {
		PreparedStatement originalQry = null;
		ResultSet origReq = null;
		PreparedStatement originalQry1 = null;
		ResultSet origReq1 = null;
		try{
			originalQry = con.prepareStatement("SELECT appseqno, entity_txt, requestor_type_id FROM requestor " +
					"WHERE request_id = ? AND requestor_id = ? " ); 
			originalQry.setInt(1, requestID);
			originalQry.setInt(2, requestorID);
			origReq = originalQry.executeQuery();
		if(origReq.next()){
			this.requestID = requestID;
			this.requestorID = requestorID;
			appseqno = origReq.getInt("appseqno");
			entityTxt = origReq.getString("entity_txt");
			requestorTypeID = origReq.getInt("requestor_type_id");
			} else { 
			originalQry1 = con.prepareStatement("SELECT appseqno, requestor_type_id FROM requestor_business " +
					"WHERE request_id = ? AND requestor_id = ? " ); 
			originalQry1.setInt(1, requestID);
			originalQry1.setInt(2, requestorID);
			origReq1 = originalQry1.executeQuery();
			origReq1.next();
			this.requestID = requestID;
			this.requestorID = requestorID;
			appseqno = origReq1.getInt("appseqno");
			entityTxt = null;
			requestorTypeID = origReq1.getInt("requestor_type_id");
			}
			//CL 166540 EXE: Optimize Production Queries
			String sql = "";
			String sqlCheck = "SELECT REQUEST_ID " +
								" FROM REQUESTOR_DUP_APPLICATIONS " +
								" WHERE REQUEST_ID = ? AND REQUESTOR_ID = ? AND DUP_REQUEST_ID = ? " +
								" AND DUP_REQUESTOR_ID = ? ";
				
			String sqlInsert = "INSERT INTO REQUESTOR_DUP_APPLICATIONS " + 
								" (REQUEST_ID, REQUESTOR_ID, DUP_REQUEST_ID, DUP_REQUESTOR_ID, " +
								" DUP_CLIENT_APP_ID, DUP_INITIATION_DT, APPSEQNO, ENTITY_TXT, DUP_NAME_TXT, DUP_ENTITY_TXT) "+
								" VALUES ( ?, ?, ?, ?, ?, ?, ?, ?, ?, ? ) ";	
			
			dupCheck = con.prepareStatement(sqlCheck);
			dupInsert = con.prepareStatement(sqlInsert);
			
			if(requestorTypeID == 3) {
				// as a part of CL 166540 EXE: Optimize Production Queries, adding space back into query string below
			sql = "SELECT cr.client_app_id, cr.initiation_dt, NULL as entity_txt, r.business_name_txt AS name_txt "+
					"FROM credit_request cr, requestor_business r "+
					"WHERE cr.request_id = ? "+
					"AND cr.request_id = r.request_id "+
					"AND r.requestor_id = ? ";
			} else { 
			sql = "SELECT cr.client_app_id, cr.initiation_dt, r.entity_txt, r.first_name_txt||' '||"+
					"CASE "+
					"WHEN r.middle_name_txt IS NULL THEN '' "+
					"ELSE (substr(r.middle_name_txt,0,1)||' ') "+
					"END || r.last_name_txt || " +
					"CASE " +
					"WHEN r.second_last_name_txt IS NULL THEN '' " +
					"ELSE (' '||r.second_last_name_txt ) " +
					"END "+
					"AS name_txt "+
					"FROM credit_request cr, requestor r "+
					"WHERE cr.request_id = ? "+
					"AND cr.request_id = r.request_id "+
					"AND cr.evaluator_id = r.evaluator_id "+
					"AND r.requestor_id = ? ";
					}
			dupSelect = con.prepareStatement(sql);
			System.out.println("Dup App Info Constructor set up for RequestID: "+this.requestID +" Requestor: "+ this.requestorID);
		} catch(Exception e){
		    System.out.println("RID="+requestID+" - DEBUG MESSAGE: DuplicateAppInfo.java setup Method : FAILED DUP APP INFO constructor setup for requestId: "+requestID+" and requestorID: "+requestorID); 
			e.printStackTrace();
		} 
        finally {
		try{if (origReq != null) origReq.close();} catch(Exception e){ e.printStackTrace(); }
		try{if (originalQry != null) originalQry.close();} catch(Exception e){ e.printStackTrace(); }
        try{if (origReq1 != null) origReq1.close();} catch(Exception e){ e.printStackTrace(); }
		try{if (originalQry1 != null) originalQry1.close();} catch(Exception e){ e.printStackTrace(); }
        }
	}

	/**
	 * Duplicates are matched with the new app set up in the constructor
	 */
	public void updateDuplicateTable(int dupRequestID, int dupRequestorID) {
		ResultSet dupInfo = null;
		ResultSet dupCheckRs = null;
		try{

		dupSelect.setInt(1, dupRequestID);
		dupSelect.setInt(2, dupRequestorID);
		dupSelect.execute();
		//System.out.println("comparing requestID: "+requestID+" to "+dupRequestID);
		dupInfo = dupSelect.getResultSet();
		dupInfo.next();
		
		//CL 166540 EXE: Optimize Production Queries
		dupCheck.setInt(1, requestID);
		dupCheck.setInt(2, requestorID);
		dupCheck.setInt(3, dupRequestID);
		dupCheck.setInt(4, dupRequestorID);
		dupCheck.execute();
		dupCheckRs = dupCheck.getResultSet();
		boolean duplicateRecordExists = dupCheckRs.next();
		if(!duplicateRecordExists){ //does not exist in db, insert to REQUESTOR_DUP_APPLICATIONS
			dupInsert.setInt(1, requestID);
			dupInsert.setInt(2, requestorID);
			dupInsert.setInt(3, dupRequestID);
			dupInsert.setInt(4, dupRequestorID);
			dupInsert.setString(5, dupInfo.getString("client_app_id"));
			dupInsert.setDate(6, dupInfo.getDate("initiation_dt"));
			dupInsert.setInt(7, appseqno);
			dupInsert.setString(8, entityTxt);
			dupInsert.setString(9, dupInfo.getString("name_txt"));
			dupInsert.setString(10, dupInfo.getString("entity_txt"));
			dupInsert.executeUpdate();
		}
		
		}catch(SQLException e){
		    System.out.println("RID="+dupRequestID+" - DEBUG MESSAGE: DuplicateAppInfo.java updateDuplicateTable Method : FAILED for dupRequestID: "+dupRequestID+" and dupRequestorID: "+dupRequestorID); 
			e.printStackTrace();
			close();
		}finally {
			try{ if(dupInfo != null) dupInfo.close(); }catch(Exception e){e.printStackTrace();}
		    try{ if(dupCheckRs != null) dupCheckRs.close(); }catch(Exception e){e.printStackTrace();}
		}
	}
	
	public void close() {
		
		try{
			if(dupCheck != null){ dupCheck.close(); };
			if(dupInsert != null){ dupInsert.close(); };
			if(dupSelect != null){ dupSelect.close(); };
			System.out.println("Connection for "+requestID+" : "+requestorID+" closed");
		}catch(SQLException e){
			e.printStackTrace();
		}
        
        // If we created our own connection, close it too
        if (closeConnection)
            try{ if (con!=null) con.close(); } catch (Exception e) { e.printStackTrace(); }

	}
}
