package com.cmsinc.origenate.ae;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Map;
import java.util.TreeMap;
import java.util.Vector;

import com.cmsinc.origenate.event.JournalEvents;
import com.cmsinc.origenate.util.EvaluateApp;
import com.cmsinc.origenate.util.EvaluateFacade;
import com.cmsinc.origenate.util.IniFile;
import com.cmsinc.origenate.util.LogMsg;
import com.cmsinc.origenate.util.OWASPSecurity;
import com.cmsinc.origenate.util.Query;
import com.cmsinc.origenate.util.SQLUpdate;
import com.cmsinc.origenate.workflow.ClientSettingIni;
import com.cmsinc.origenate.workflow.WorkFlowManager;

public class ChangedBorrower {
	private boolean b_debugger = false;
	protected java.sql.Connection con;
	protected LogMsg log = new LogMsg();
	private boolean b_clsConnectionlocal = true,  b_otherConnection = false, b_use_static=false, closeConnectionOnExit = true;

	static String evalEnv="", evalHost = "", evalVer = "", evalPort = "", evalReceivePort = "" , evalFacadeLog = "", dbTTyDirName ="", clientName = "";
	static int debugMemory = -1;

	static String overrideEffectDtFlg = "0";
	static String effectDtType = "", fixedDt="", dynamicDtOpt="";

	private static Vector s_v_clientSetting = null;
	private static String[] strArray = new String[5];
	private String journalTxt = "";


	/******************************************
	 * Implemented database connection
	 ******************************************/

	//constructor used by LoanAppRq
	public ChangedBorrower(IniFile ini, Connection con) throws Exception {
		String logName = ini.getINIVar("logs.changeborrower_log_file","");
		changedBorrowerInitialization(logName,ini);
		this.con = con;
		this.closeConnectionOnExit = false; //keep connection open to be used by LoanAppRq processing
	}

	//constructor used by cfm de/action/act_saveborrowerposition.cfm
	public ChangedBorrower(String s_LogName, String s_iniFile) throws Exception {
		if (clientName==null || clientName.equals("")){
			IniFile ini = new IniFile();
			ini.readINIFile(s_iniFile);
			changedBorrowerInitialization(s_LogName,ini);
		} else {
			changedBorrowerInitialization(s_LogName,null);
		}

		this.b_otherConnection = false;
		this.closeConnectionOnExit = true; //keep connection open to be used by LoanAppRq processing
		// Instantiate InitialContext
		javax.naming.InitialContext ctx=null;
		try {
			ctx = new javax.naming.InitialContext();

			// Lookup the datasource
			javax.sql.DataSource  ds = (javax.sql.DataSource) ctx.lookup(clientName + "_origpool");

			// Get the connection from the datasource
			this.con = ds.getConnection();

			if (this.con == null) {
				log.FmtAndLogMsg("***Connection is null in calling: "+ getClass());
			} else {
				//If debug option is not saved then check for it
				if (debugMemory == -1) {
					setDebugMemory(this.log.getDebugSetting(con));
				}
				if (debugMemory == 1) { 
					log.FmtAndLogMsg("ChangedBorrower:OPEN:Connect using connection pool");
				}

			}
		} catch (Exception e) {
			log.FmtAndLogMsg("Error problem with db connection in constructor " + getClass(), e);
			throw new Exception("Database connect error:"+e.toString(), e);
		}

	}

	private void changedBorrowerInitialization(String s_LogName, IniFile ini) throws Exception {

		//Get ini file values for DB connection
		/* GL. 1/7/05 Performance
	    Do not reread ini file if it has not changed since the last call
		 */
		//assumption is if you have clientName, you also have the ini initialized
		if ((clientName==null || clientName.equals("")) && ini != null){
			setClientName(ini.getINIVar("general.client_name"));
			setOverrideEffectDtFlg(ini.getINIVar("general.override_effect_date_prompt"));
			setEffectDtType(ini.getINIVar("general.effective_date_type"));
			setFixedDt(ini.getINIVar("general.fixed_date"));
			setDynamicDtOpt(ini.getINIVar("general.dynamic_effect_date_option"));

			setEvalReceivePort(ini.getINIVar("evaluate.receive_port"));
			setEvalHost(ini.getINIVar("evaluate.ini_host"));
			setDbTTyDirName(ini.getINIVar("database.tty_dir_name"));
		}
		//Open log file
		log.openLogFile(s_LogName);
		// System.out.println("Log file: " + s_LogName + " opened for log messages.");
	}

	/*****************************************************************************/
	/*       Initialize evaluatefacade call	                                   */
	/****************************************************************************/
	private void evalChangedBorrower(long request_id,int evaluator_id, String user_id,
			String appEntityList,
			String oldReqTypeIdList,
			String newReqTypeIdList,
			String schemaOwner,
			String tableSetName)  throws Exception {

		PreparedStatement ps = null;
		ResultSet rs = null;
		EvaluateFacade ev = null;
		String sql = "";
		Statement stmt  = null;
		String str_startDt = "", str_enddt = "";
		String[] chgTables = null;
		int evappno = 0;
		int cnt = 0,  perBusFlg = 0;
		Vector rsrows = new Vector();
		ClientSettingIni cltVal = null;
		String clientNmTxt = "", effDt = "";
		String inifilepath="";	
		WorkFlowManager wfMangr = new WorkFlowManager(con,log);

		strArray[0] = appEntityList;
		strArray[1] = oldReqTypeIdList;
		strArray[2] =  newReqTypeIdList;
		strArray[3] = schemaOwner;
		strArray[4] = tableSetName;


		log.FmtAndLogMsg("evalChangedBorrower:ENTER");


		try {
			if (!b_use_static || evalEnv.equalsIgnoreCase("")) {
				// get relative path to ini file (ini isn't available thru xmldbt)
				stmt  = con.createStatement();
				rs = stmt.executeQuery( "SELECT PATH_TXT FROM ORIGENATE_INI");
				if(rs.next()) {
					// get evaluate environment vars from ini file
					IniFile ini = new IniFile();
					inifilepath=rs.getString("PATH_TXT");
					//163404 - GL. 4/1/2013 - if -D provided on java runtime then use its path to get the origenate.ini file
					if (System.getProperty("origenate_ini") != null) 
						inifilepath=System.getProperty("origenate_ini");
					else
						log.FmtAndLogMsg("WARNING: Reading origenate_ini table in ChangedBorrower.java");
					// END- 163404 - GL. 4/1/2013 - if -D provided on java runtime then use its path to get the origenate.ini file
					ini.readINIFile(inifilepath);
					setEvalEnv(ini.getINIVar("evaluate.environment"));
					setEvalHost(ini.getINIVar("evaluate.ini_host"));
					setEvalVer(ini.getINIVar("evaluate.version"));
					setEvalPort(ini.getINIVar("evaluate.ini_port"));
					setEvalFacadeLog(ini.getINIVar("logs.evaluate_facade_log_file"));
					// GL. need to get these values too when WFM is created by passing a connection.
					setOverrideEffectDtFlg(ini.getINIVar("general.override_effect_date_prompt"));
					setEffectDtType(ini.getINIVar("general.effective_date_type"));
					setFixedDt(ini.getINIVar("general.fixed_date"));
					setDynamicDtOpt(ini.getINIVar("general.dynamic_effect_date_option"));
					if (evalPort.equalsIgnoreCase("")) {
						throw new Exception("Error in getElapsedTime method no port is defined ");
					}
				}
				try{ if(rs != null) rs.close(); }catch(Exception e1){e1.printStackTrace();}
				try{ if(stmt != null) stmt.close(); }catch(Exception e1){e1.printStackTrace();}
			}

			// log.FmtAndLogMsg(" Request ID : " + request_id + " log file name : " +  evalFacadeLog);

			//initialize evaluate facade                         //    GL. added user_id and con for caching apps
			//ev = new EvaluateFacade(evalFacadeLog, (new Long(request_id)).toString(),user_id,con,inifilepath);
			ev = new EvaluateFacade(evalFacadeLog, (Long.valueOf(request_id)).toString(),user_id,con,inifilepath);
			int i_eval_port = new Integer(evalPort).intValue();
			// initialize evaluate call
			ev.Initialize(evalEnv, evalVer, evalHost,i_eval_port);

			//Get static value of object if available or get from DB
			cltVal = new ClientSettingIni();

			cltVal =  wfMangr.clientValueCheck(request_id,evaluator_id);
			clientNmTxt = cltVal.getEvalNameTxt();
			effDt = cltVal.getEffectDtTxt();


			// close stmt
			//try {rs.close();} catch (Exception e1) {}
			//try {ps.close();} catch (Exception e1) {}

			//Find personal/business app?
			sql = "SELECT PERSONAL_FLG FROM CREDIT_REQUEST WHERE REQUEST_ID = ? ";

			//Prepare statement to execute
			ps = con.prepareStatement(sql);

			//Set param values
			ps.setLong(1, request_id);

			//Execute statement
			rs = ps.executeQuery();

			//Get values
			if (rs.next()) {
				perBusFlg =  rs.getInt("PERSONAL_FLG");
			}

			// close stmt
			try{ if(rs != null) rs.close(); }catch(Exception e1){e1.printStackTrace();}
			try{ if(ps != null) ps.close(); }catch(Exception e1){e1.printStackTrace();}

			if (perBusFlg == 1) {
				//Find personal app
				sql = "SELECT REMOTE_REF_NUM FROM  requestor WHERE REQUEST_ID = ? and requestor_type_id = 0";
			}else {
				//Find business app
				sql = "SELECT REMOTE_REF_NUM FROM requestor_business WHERE REQUEST_ID = ? and requestor_type_id = 3";
			}

			//Prepare statement to execute
			ps = con.prepareStatement(sql);

			//Set param values
			ps.setLong(1, request_id);

			//Execute statement
			rs = ps.executeQuery();
			//Get values
			if (rs.next()) {
				evappno =  rs.getInt("REMOTE_REF_NUM");
			}

			// close stmt
			try{ if(rs != null) rs.close(); }catch(Exception e1){e1.printStackTrace();}
			try{ if(ps != null) ps.close(); }catch(Exception e1){e1.printStackTrace();}

			//get appseqnum
			sql = "SELECT appseqno FROM CREDIT_REQUEST WHERE request_id = ?";
			//Prepare statement to execute
			ps = con.prepareStatement(sql);

			//	Set param values
			ps.setLong(1, request_id);

			//Execute statement
			rs = ps.executeQuery();

			int appseqno=0;
			//Get values
			if (rs.next()) {
				appseqno =  rs.getInt("appseqno");
			}

			// close stmt
			try{ if(rs != null) rs.close(); }catch(Exception e1){e1.printStackTrace();}
			try{ if(ps != null) ps.close(); }catch(Exception e1){e1.printStackTrace();}


			//create eval app
			EvaluateApp ap = new EvaluateApp();
			//ap.EvalAppNo = new Integer(evappno);
			//ap.AppSeqNo = new Integer(appseqno);
			ap.EvalAppNo = Integer.valueOf(evappno);
			ap.AppSeqNo = Integer.valueOf(appseqno);

			//Get list of dirty tables
			sql = "SELECT TABLE_NAME_TXT FROM EVALUATE_SHARE WHERE REQUEST_ID = ? ";

			//Prepare statement to execute
			ps = con.prepareStatement(sql);

			//Set param values
			ps.setLong(1, request_id);

			//Execute statement
			rs = ps.executeQuery();


			while (rs.next()) {
				rsrows.addElement(rs.getString("TABLE_NAME_TXT"));
			}


			chgTables = new String[rsrows.size()];
			cnt = rsrows.size();

			//Get values
			for (int i=0; i<cnt; i++) {
				chgTables[i] =  rsrows.get(i).toString().toUpperCase();
				log.FmtAndLogMsg("Table Name " +  chgTables[i]);
			}

			// close stmt
			try{ if(rs != null) rs.close(); }catch(Exception e1){e1.printStackTrace();}
			try{ if(ps != null) ps.close(); }catch(Exception e1){e1.printStackTrace();}


			//Call evaluate to Changed Borrower Position
			log.FmtAndLogMsg("Call to EvaluateFacade for Request ID: " + request_id + ", Client name: " + clientNmTxt + ", effect date : " + effDt  + ", evappno: " + ap.EvalAppNo.intValue() + ", appseqno: " + ap.AppSeqNo.intValue() + ", strArray:" + strArray[0] + ":" +  strArray[1] + ":" +  strArray[2] + ":" +  strArray[3] + ":" +  strArray[4]);
			boolean s_result = ev.ChangedBorrower(clientNmTxt,effDt,ap,appseqno,strArray, chgTables);


			log.FmtAndLogMsg("The evalChangedBorrower for request ID " + request_id + " : " +  s_result);

		} catch (Exception ex) {
			if (ev != null) ev = null;
			if (stmt != null) stmt = null;
			try{ if(rs != null) rs.close(); }catch(Exception e1){e1.printStackTrace();}
			try{ if(ps != null) ps.close(); }catch(Exception e1){e1.printStackTrace();}
			recordError(ex, "evalChangedBorrower");
		}finally {
			try {
				//Need to close log file
				ev.closeLogFile();
				if (ev != null) ev = null;
				try{ if(rs != null) rs.close(); }catch(Exception e1){e1.printStackTrace();}
				try{ if(ps != null) ps.close(); }catch(Exception e1){e1.printStackTrace();}
				try{ if(stmt != null) stmt.close(); }catch(Exception e1){e1.printStackTrace();}
			} catch (Exception e) {
				recordError(e, "evalChangedBorrower");
			}
		}
	}

	//Array for debug if needed
	private void debugChangeBorrowerArray(ArrayList<ChangedBorrowerContainerBean> arrayToDebug){
		for(int i = 0; i<arrayToDebug.size();i++){
			String entityTxt = arrayToDebug.get(i).getEntityTxt();
			int requestorId = arrayToDebug.get(i).getRequestorId();
			int requestorTypeId = arrayToDebug.get(i).getRequestorTypeId();
			log.FmtAndLogMsg("entity:" +entityTxt + "/requestorId:" + requestorId + "/requestorTypeId:"+ requestorTypeId);
		}

	}

	/**
	 * executes the change borrower logic
	 * called by dataentry/action/act_saveborrowerposition.cfm
	 * CL 171135 State Farm: External Workflow Processing
	 * @param requestID
	 * @param evaluatorID
	 * @param userId
	 * @param prevSavedApplicantsEntityCollection
	 * @param loadingApplicantsEntityCollection
	 * @throws Exception
	 */
	public boolean callChangeBorrower(String requestID, String evaluatorID, String userId, ChangedBorrowerContainer prevSavedApplicantsEntityCollection, ChangedBorrowerContainer loadingApplicantsEntityCollection) throws Exception {
		boolean changeBorrowerSuccess = false;
		log.FmtAndLogMsg("Enter callChangeBorrower from act_saveborrowerposition.");
		try{

			ArrayList<ChangedBorrowerContainerBean> getArrayListPrev = prevSavedApplicantsEntityCollection.getChangedBorrowerContainerBean();
			//debugChangeBorrowerArray(getArrayListPrev);
			ArrayList<ChangedBorrowerContainerBean> getArrayListLoad = loadingApplicantsEntityCollection.getChangedBorrowerContainerBean();
			//debugChangeBorrowerArray(getArrayListLoad);
			changeBorrowerSuccess = callChangeBorrower(requestID,evaluatorID,userId, getArrayListPrev, getArrayListLoad);	

		} catch(Exception e){
			log.FmtAndLogMsg("Error in callChangeBorrower from cfm : ",e);
		} finally {
			if (!b_otherConnection && b_clsConnectionlocal && con != null && closeConnectionOnExit)  { 
				try{ if(con != null) con.close(); }catch(Exception e1){e1.printStackTrace();}
			}
		}
		log.FmtAndLogMsg("End callChangeBorrower from act_saveborrowerposition. return: " + changeBorrowerSuccess);
		return changeBorrowerSuccess;
	}


	/**
	 * executes the change borrower logic, calling evaluate logic, updating database tables as necessary
	 * called from above or from LoanAppRq
	 * CL 171135 State Farm: External Workflow Processing
	 * @param requestID
	 * @param evaluatorID
	 * @param userId
	 * @param prevSavedApplicantsEntityCollection
	 * @param loadingApplicantsEntityCollection
	 * @return
	 * @throws Exception
	 */
	public boolean callChangeBorrower(String requestID, String evaluatorID, String userId, ArrayList<ChangedBorrowerContainerBean> prevSavedApplicantsEntityCollection, ArrayList<ChangedBorrowerContainerBean> loadingApplicantsEntityCollection) throws Exception {
		boolean changeBorrowerSuccess = true;

		//Bring A1 to front to avoid constraint violations
		a1ToFront(prevSavedApplicantsEntityCollection, loadingApplicantsEntityCollection);
		reorderAppEntities(prevSavedApplicantsEntityCollection, loadingApplicantsEntityCollection);

		String oldAppEntityList = getOrderedAppEntityList(prevSavedApplicantsEntityCollection);
		String oldRequestorTypeIdList = getOrderedRequestorTypeIdList(prevSavedApplicantsEntityCollection);
		String newRequestorTypeIdList = getOrderedRequestorTypeIdList(loadingApplicantsEntityCollection);
		try{
			log.FmtAndLogMsg("Enter callChangeBorrower.");
			//System.out.println("DEBUG callChangeBorrower PREVIOUSLY SAVED:");
			//debugChangeBorrowerArray(prevSavedApplicantsEntityCollection);

			//System.out.println("DEBUG callChangeBorrower ONES WE ARE LOADING:");
			//debugChangeBorrowerArray(loadingApplicantsEntityCollection);

			Query query = new Query(con);
			SQLUpdate sqlUpdate = new SQLUpdate();
			JournalEvents journalEvents= null;
			String sql ="";
			String appseqno = "", remoteRefNum = "", evalSchemaUser = "";
			boolean evaluateError = false;

			//////////////
			//1 get appseqno from credit request
			sql = "select appseqno from credit_request where request_id = ? and evaluator_id = ? ";
			query.prepareStatement(sql);
			query.setInt(1,requestID);
			query.setInt(2,evaluatorID);
			query.executePreparedQuery();
			if(query.next()){
				appseqno = query.getColValue("appseqno","");
			}
			//update requestor table with appseqno (reference CL149169)
			//TTP 324955 Security Remediation Fortify Scan
			sqlUpdate.SetPreparedUpdateStatement(con,"update requestor set appseqno = ? where request_id = ?");
			sqlUpdate.setInt(1, appseqno);
			sqlUpdate.setInt(2, requestID);
			sqlUpdate.RunPreparedUpdateStatement();
			//2. get remote ref num from requestor and reupdate all requestor records
			sql = "select remote_ref_num from requestor where request_id = ? and remote_ref_num is not null";
			query.prepareStatement(sql);
			query.setInt(1,requestID);
			query.executePreparedQuery();
			if(query.next()){
				remoteRefNum = query.getColValue("remote_ref_num","");
			}

			//update requestor table with remoteRefNum
			//TTP 324955 Security Remediation Fortify Scan
			sqlUpdate.SetPreparedUpdateStatement(con, "update requestor set remote_ref_num = ? where request_id = ? ");
			sqlUpdate.setInt(1, remoteRefNum);
			sqlUpdate.setInt(2, requestID);
			sqlUpdate.RunPreparedUpdateStatement();

			//3 get schema user
			sql = "select table_owner from user_synonyms where synonym_name = 'EVAPP_INTERFACE'";
			query.prepareStatement(sql);
			query.executePreparedQuery();
			if(query.next()){
				evalSchemaUser = query.getColValue("table_owner","");
			}
			//////////////

			log.FmtAndLogMsg("callChangeBorrower: evalSchemaUser:" + evalSchemaUser);

			try{
				log.FmtAndLogMsg("callChangeBorrower: old app entity list: [" + oldAppEntityList +  "] old requestor type id list: [" + oldRequestorTypeIdList
						+ "] new requestor type id list: [" + newRequestorTypeIdList + "]");
				evalChangedBorrower(Long.parseLong(requestID), Integer.parseInt(evaluatorID), userId, oldAppEntityList, oldRequestorTypeIdList, newRequestorTypeIdList, evalSchemaUser, "ORIG_NONBUREAU_TABLE_SET");
			} catch (Exception e) {
				evaluateError = true;
				log.FmtAndLogMsg("callChangeBorrower error on call to evalChangedBorrower");
			}

			if(!evaluateError){
				log.FmtAndLogMsg("Changedborrower: no error during evalChangedBorrower, continue with updating Borrower Positions");
				//update user positions
				updateBorrowerPositions(requestID, evaluatorID, prevSavedApplicantsEntityCollection, loadingApplicantsEntityCollection);
				log.FmtAndLogMsg("Changedborrower: completed updating Borrower Positions");

				//reset the decision activity to Incomplete in order to force a re-decision.
				//getDecActivityStatus (dataentry/action/act_saveborrowerposition.cfm)
				sql = 	" SELECT activity_status_id " + 
						" FROM credit_request_activity " + 
						" WHERE request_id = ? " + 
						" AND activity_id = 6 ";
				query.prepareStatement(sql);
				query.setInt(1,requestID);
				query.executePreparedQuery();
				if(query.next()){
					int activityStatus = Integer.parseInt(query.getColValue("activity_status_id","-1"));
					if(activityStatus>1){
						//setDecActivityStatus (dataentry/action/act_saveborrowerposition.cfm)
						sql = 	" UPDATE credit_request_activity " +
								" SET activity_status_id = 1 " + 
								" WHERE request_id = ? " +
								" AND activity_id = 6 ";
						sqlUpdate.SetPreparedUpdateStatement(con,sql);
						sqlUpdate.setInt(1, requestID);
						sqlUpdate.RunPreparedUpdateStatement();
					}
				}
				//clear Verification data
				//delVerifHist (dataentry/action/act_saveborrowerposition.cfm)
				sql = 	" DELETE FROM credit_req_verify_method_hist " +
						" WHERE request_id = ? " + 
						" AND evaluator_id = ? " ;
				sqlUpdate.SetPreparedUpdateStatement(con,sql);
				sqlUpdate.setInt(1, requestID);
				sqlUpdate.setInt(2, evaluatorID);
				sqlUpdate.RunPreparedUpdateStatement();

				//delVerifComments (dataentry/action/act_saveborrowerposition.cfm)
				sql = 	" DELETE FROM credit_req_verify_comments " +
						" WHERE request_id = ? " + 
						" AND evaluator_id = ? ";
				sqlUpdate.SetPreparedUpdateStatement(con,sql);
				sqlUpdate.setInt(1, requestID);
				sqlUpdate.setInt(2, evaluatorID);
				sqlUpdate.RunPreparedUpdateStatement();

				//delVerifData (dataentry/action/act_saveborrowerposition.cfm)
				sql = 	" DELETE FROM credit_req_verify_data " +
						" WHERE request_id = ? " + 
						" AND evaluator_id = ? ";
				sqlUpdate.SetPreparedUpdateStatement(con,sql);
				sqlUpdate.setInt(1, requestID);
				sqlUpdate.setInt(2, evaluatorID);
				sqlUpdate.RunPreparedUpdateStatement();

				//check if any cosigner was added/exists on the app
				boolean cosignerAdded = newRequestorTypeIdList.contains("2");

				// if cosigner in new requestor list
				if(cosignerAdded){
					log.FmtAndLogMsg("ChangedBorrower: callChangeBorrower - Request id "+ requestID + ":Creating entity group ALL_COSIGNERS via initial info...");
					//see query/qry_createentitygroups.cfm
					String requestorIdStub = "-3";
					String requestorTypeIdStub = "-3";
					String entityTxtStub = "ALL_COSIGNERS";
					log.FmtAndLogMsg("ChangedBorrower: calling createEntityGroups for " + entityTxtStub  );
					createEntityGroups(requestID,evaluatorID,requestorIdStub,requestorTypeIdStub,entityTxtStub);
					log.FmtAndLogMsg("ChangedBorrower: done createEntityGroups for " + entityTxtStub  );
				}
				//act_addcosignertrades.cfm
				log.FmtAndLogMsg("ChangedBorrower: calling addCosignerTrades");
				addCosignerTrades(requestID, evaluatorID);
				log.FmtAndLogMsg("ChangedBorrower: done calling addCosignerTrades");
				//getjournalid
				sql = 	" SELECT journal_event_id " + 
						" FROM mstr_journal_events " +
						" WHERE	journal_event_desc_txt = 'Toggle Borrower'";
				query.prepareStatement(sql);
				query.executePreparedQuery();
				if(query.next()){	
					int journalId = Integer.parseInt(query.getColValue("journal_event_id"));
					journalEvents= new JournalEvents(con,null);
					journalEvents.addJournal(Integer.parseInt(requestID),journalId,journalTxt,userId); 
				}
			} else {
				changeBorrowerSuccess = false;
			}

			//////////////
			//note: rescore call possible if in UI/Origenate screens, but not through 
			//external app, done in CFM : de/action/act_saveborrowerposition.cfm 
		} catch(Exception e){
			log.FmtAndLogMsg("Error in callChangeBorrower : ",e);
			changeBorrowerSuccess = false;
		} finally {
			if (!b_otherConnection && b_clsConnectionlocal && con != null && closeConnectionOnExit)  { 
				try{ if(con != null) con.close(); }catch(Exception e1){e1.printStackTrace();}
			}
		}
		log.FmtAndLogMsg("End callChangeBorrower. return : "+ changeBorrowerSuccess);
		return changeBorrowerSuccess;
	}

	private void reorderAppEntities(ArrayList<ChangedBorrowerContainerBean> prevSavedApplicantsEntityCollection,
			ArrayList<ChangedBorrowerContainerBean> loadingApplicantsEntityCollection) {

		Map<ChangedBorrowerContainerBean,ChangedBorrowerContainerBean> prevNewMap = 
				new TreeMap<ChangedBorrowerContainerBean,ChangedBorrowerContainerBean>(new Comparator<ChangedBorrowerContainerBean>() {
					@Override
					public int compare(ChangedBorrowerContainerBean o1, ChangedBorrowerContainerBean o2) {
						return o1.getEntityTxt().compareTo(o2.getEntityTxt());
					}		
				});
		
		int index = 0;
		for (ChangedBorrowerContainerBean bean : loadingApplicantsEntityCollection) {
			prevNewMap.put(bean, prevSavedApplicantsEntityCollection.get(index));
			index++;
		}
				
		log.FmtAndLogMsg("ChangedBorrower: reorderAppEntities - Before reordering [new entity -> old entity]");
		for (Map.Entry<ChangedBorrowerContainerBean, ChangedBorrowerContainerBean> entry : prevNewMap.entrySet()) {
			log.FmtAndLogMsg(String.format("%s -> %s", entry.getKey().getEntityTxt(), entry.getValue().getEntityTxt()));
		}
		
		int coApplicantNumber = 1;
		int coSignerNumber = 1;
		
		//First pass populate all the entries with the same type of entity
		for (Map.Entry<ChangedBorrowerContainerBean, ChangedBorrowerContainerBean> entry : prevNewMap.entrySet()) { 
			if (entry.getKey().getRequestorTypeId() == entry.getValue().getRequestorTypeId()) {
				if (entry.getKey().getEntityTxt().startsWith("C")) {
					entry.getKey().setEntityTxt("C"+coApplicantNumber++);
				}
				if (entry.getKey().getEntityTxt().startsWith("S")) {
					entry.getKey().setEntityTxt("S"+coSignerNumber++);
				}
			}
		}
		
		//Second pass populate all the entries with a different entity
		for (Map.Entry<ChangedBorrowerContainerBean, ChangedBorrowerContainerBean> entry : prevNewMap.entrySet()) {		
			if (entry.getKey().getRequestorTypeId() != entry.getValue().getRequestorTypeId()) {
				if (entry.getKey().getEntityTxt().startsWith("C")) {
					entry.getKey().setEntityTxt("C"+coApplicantNumber++);
				}
				if (entry.getKey().getEntityTxt().startsWith("S")) {
					entry.getKey().setEntityTxt("S"+coSignerNumber++);
				}
			}			
		}
		
		log.FmtAndLogMsg("ChangedBorrower: reorderAppEntities - After reordering [new entity -> old entity]");
		for (Map.Entry<ChangedBorrowerContainerBean, ChangedBorrowerContainerBean> entry : prevNewMap.entrySet()) {
			log.FmtAndLogMsg(String.format("%s -> %s", entry.getKey().getEntityTxt(), entry.getValue().getEntityTxt()));
		}
	}

	/**
	 * Move A1 to the front of the entity lists
	 * 
	 * @param prevSavedApplicantsEntityCollection The previous entities 
	 * @param loadingApplicantsEntityCollection The new entities
	 */
	private void a1ToFront(ArrayList<ChangedBorrowerContainerBean> prevSavedApplicantsEntityCollection,
			ArrayList<ChangedBorrowerContainerBean> loadingApplicantsEntityCollection) {
		int index = 0;

		for (ChangedBorrowerContainerBean bean : prevSavedApplicantsEntityCollection) {
			if (bean.getEntityTxt().equalsIgnoreCase("A1")) {
				break;
			}

			index++;
		}
		ChangedBorrowerContainerBean bean = prevSavedApplicantsEntityCollection.get(index);
		prevSavedApplicantsEntityCollection.remove(index);
		prevSavedApplicantsEntityCollection.add(0,bean);

		bean = loadingApplicantsEntityCollection.get(index);
		loadingApplicantsEntityCollection.remove(index);
		loadingApplicantsEntityCollection.add(0,bean);
	}

	/**
	 * creates a String of the entity texts from the ChangedBorrowerContainerBean ArrayList 
	 * CL 171135 State Farm: External Workflow Processing
	 * @param borrowersArray
	 * @return
	 */
	private String getOrderedAppEntityList(ArrayList<ChangedBorrowerContainerBean> borrowersArray){
		StringBuffer entityList = new StringBuffer();
		for(int i =0; i < borrowersArray.size(); i++){
			//comma delimiter
			if(i!=0){
				entityList.append(",");
			}
			entityList.append(borrowersArray.get(i).getEntityTxt());
		}
		return entityList.toString();
	}


	/**
	 * creates a String of the requestor type ids from the ChangedBorrowerContainerBean ArrayList 
	 * CL 171135 State Farm: External Workflow Processing
	 * @param borrowersArray
	 * @return
	 */
	private String getOrderedRequestorTypeIdList(ArrayList<ChangedBorrowerContainerBean> borrowersArray){
		StringBuffer requestorTypeIdList = new StringBuffer();
		for(int i =0; i < borrowersArray.size(); i++){
			//comma delimiter
			if(i!=0){
				requestorTypeIdList.append(",");
			}
			requestorTypeIdList.append(borrowersArray.get(i).getRequestorTypeId());
		}
		return requestorTypeIdList.toString();
	}


	/**
	 * determines which entities acutally changed and calls the method that does the database updates as necessary
	 * creates journal entry text 
	 * Partial logic moved from dataentry/action/act_saveborrowerposition
	 * CL 171135 State Farm: External Workflow Processing
	 * @param requestID
	 * @param evaluatorID
	 * @param prevSavedApplicantsEntityCollection
	 * @param loadingApplicantsEntityCollection
	 * @throws Exception
	 */
	private void updateBorrowerPositions(String requestID, String evaluatorID, ArrayList<ChangedBorrowerContainerBean> prevSavedApplicantsEntityCollection, ArrayList<ChangedBorrowerContainerBean> loadingApplicantsEntityCollection) throws Exception {
		int prevRequestorTypeId; //current requestor_type_id for borrower
		String newEntityTxt = ""; //new entity_txt for borrower
		String prevEntityTxt = ""; //new entity_txt for borrower
		int newRequestorTypeId; //new requestor_type_id for borrower
		int requestorId; //current requestorId for borrower
		String applicantName = "";

		Query query = new Query(con);
		String sql = "";
        
		for(int i =0; i < prevSavedApplicantsEntityCollection.size(); i ++){
			ChangedBorrowerContainerBean prevSavedAppBean = prevSavedApplicantsEntityCollection.get(i);
			ChangedBorrowerContainerBean loadingAppBean = loadingApplicantsEntityCollection.get(i);
			prevEntityTxt = prevSavedAppBean.getEntityTxt();
			prevRequestorTypeId = prevSavedAppBean.getRequestorTypeId();
			//get applicants new info by searching the loadingEntityCollection at the same index
			newRequestorTypeId = loadingAppBean.getRequestorTypeId();
			newEntityTxt = loadingAppBean.getEntityTxt();
			requestorId = prevSavedAppBean.getRequestorId();
			if(prevSavedAppBean.getRequestorId() != loadingAppBean.getRequestorId()){
				log.FmtAndLogMsg("updateBorrowerPositions: Error, requestor ids do not match between array of previous and new applicant position");
			}

			//only run individualBorrowerUpdates updates for modified borrowers

				//one applicant

				log.FmtAndLogMsg("Changedborrower: change borrower individual position in database for : requestID:"+requestID+"/newRequestorTypeId:" + newRequestorTypeId + "/newEntityTxt:" + newEntityTxt + "/prevRequestorTypeId"+prevRequestorTypeId + "/requestorId:" + requestorId + "/");
				individualBorrowerUpdates(requestID,evaluatorID, newRequestorTypeId, newEntityTxt, prevRequestorTypeId, requestorId);
				log.FmtAndLogMsg("Changedborrower: change borrower individual position in database complete");
				//Staying consistant with how we do journal entries already for Change borrower, only including first name, last name and second last name
				//excluding prefix and suffix
				sql = 	" SELECT  first_name_txt||' '||last_name_txt || " + 
						" CASE WHEN second_last_name_txt IS NULL THEN '' ELSE (' '||second_last_name_txt) END  as applicant_name " + 
						" FROM requestor WHERE request_id = ? and evaluator_id = ? and requestor_type_id = ? and requestor_id = ? ";
				query.prepareStatement(sql);
				query.setInt(1,requestID);
				query.setInt(2,evaluatorID);
				query.setInt(3,newRequestorTypeId);
				query.setInt(4,requestorId);
				query.executePreparedQuery();
				if(query.next()){
					applicantName = query.getColValue("applicant_name","");
				}
				journalTxt = journalTxt + "Initial borrower position " + prevEntityTxt + " " + applicantName + " moved to "+ newEntityTxt + ". ";

			
		}
	}


	/**
	 * updates tables for each individual entity that changed
	 * (logic moved from dataentry/query/qry_saveborrowerposition.cfm)
	 * CL 171135 State Farm: External Workflow Processing
	 * @param requestID
	 * @param evaluatorID
	 * @param newRequestorTypeId
	 * @param newEntityTxt
	 * @param currentBorrowerTypeId
	 * @param requestorId
	 * @throws Exception
	 */
	private void individualBorrowerUpdates(String requestID, String evaluatorID, int newRequestorTypeId, String newEntityTxt, int currentBorrowerTypeId, int requestorId) throws Exception {
		Query query = new Query(con);
		Query query2 = new Query(con); //used for TTY qry
		SQLUpdate sqlUpdate = new SQLUpdate();
		String sql = "";
		
		//update requestor
		//updateRequestor (qry_saveborrowerposition.cfm)
		sql = 	" UPDATE requestor " +
				" SET  requestor_type_id = ? " + 	//1 newRequestorTypeId
				" , entity_txt = ? " +			 	//2 newEntityTxt 
				" WHERE evaluator_id = ? " + 		//3 evaluatorID 
				" AND request_id = ? " + 			//4 requestID 
				" AND requestor_type_id = ? " + 	//5 currentBorrowerTypeId 
				" AND requestor_id = ? ";			//6 requestorId 
		sqlUpdate.SetPreparedUpdateStatement(con,sql);
		sqlUpdate.setInt(1, ""+newRequestorTypeId);
		sqlUpdate.setString(2, OWASPSecurity.validationCheck(newEntityTxt,OWASPSecurity.SQLPARAMSTRING));
		sqlUpdate.setInt(3, evaluatorID);
		sqlUpdate.setInt(4, requestID);
		sqlUpdate.setInt(5, ""+currentBorrowerTypeId);
		sqlUpdate.setInt(6, ""+requestorId);
		sqlUpdate.RunPreparedUpdateStatement();		

		//update  REQUESTOR_ALERT (169136 CIT: Change borrower)
		//updateRequestorAlert (qry_saveborrowerposition.cfm)
		sql = 	" UPDATE requestor_alerts " +
				" SET  entity_txt = ? " + 		//1 newEntityTxt
				" WHERE evaluator_id = ? " + 	//2  evaluatorID +
				" AND request_id = ? " + 		//3 requestID +
				" AND requestor_id = ? ";		//4 requestorId ;
		sqlUpdate.SetPreparedUpdateStatement(con,sql);
		sqlUpdate.setString(1, OWASPSecurity.validationCheck(newEntityTxt,OWASPSecurity.SQLPARAMSTRING));
		sqlUpdate.setInt(2, evaluatorID);
		sqlUpdate.setInt(3, requestID);
		sqlUpdate.setInt(4, ""+requestorId);
		sqlUpdate.RunPreparedUpdateStatement();			

		//update CREDIT_REQ_CONTR_REQUESTOR
		//updateReqContrRequestor (qry_saveborrowerposition.cfm)
		sql = 	" UPDATE credit_req_contr_requestor " +
				" SET  requestor_type_id = ? " + 		//1 newRequestorTypeId
				" , entity_txt = ? " + 					//2 newEntityTxt
				" WHERE evaluator_id = ? " + 			//3 evaluatorID
				" AND request_id = ? " + 				//4 requestID
				" AND requestor_type_id = ? " +			//5 currentBorrowerTypeId
				" AND requestor_id = ? "; 				//6 requestorId
		sqlUpdate.SetPreparedUpdateStatement(con,sql);
		sqlUpdate.setInt(1, ""+newRequestorTypeId);
		sqlUpdate.setString(2, OWASPSecurity.validationCheck(newEntityTxt,OWASPSecurity.SQLPARAMSTRING));
		sqlUpdate.setInt(3, evaluatorID);
		sqlUpdate.setInt(4, requestID);
		sqlUpdate.setInt(5, ""+currentBorrowerTypeId);
		sqlUpdate.setInt(6, ""+requestorId);
		sqlUpdate.RunPreparedUpdateStatement();				

		//update CREDIT_REQ_CONTR_VERIF_CAT
		int verif_category_id_value = newRequestorTypeId + 1;
		//updateReqContraVerifCat (qry_saveborrowerposition.cfm)
		sql = 	" UPDATE credit_req_contr_verif_cat " +
				" SET  requestor_type_id = ? " + 	//1 newRequestorTypeId
				" , verif_category_id = ? " + 		//2 verif_category_id_value
				" WHERE evaluator_id = ? " + 		//3 evaluatorID
				" AND request_id = ? " + 			//4 requestID
				" AND requestor_type_id = ? " + 	//5 currentBorrowerTypeId
				" AND requestor_id = ? " ; 			//6 requestorId
		sqlUpdate.SetPreparedUpdateStatement(con,sql);
		sqlUpdate.setInt(1, ""+newRequestorTypeId);
		sqlUpdate.setInt(2, ""+verif_category_id_value);
		sqlUpdate.setInt(3, evaluatorID);
		sqlUpdate.setInt(4, requestID);
		sqlUpdate.setInt(5, ""+currentBorrowerTypeId);
		sqlUpdate.setInt(6, ""+requestorId);
		sqlUpdate.RunPreparedUpdateStatement();				

		//update REQUESTOR_HEADER
		//updateReqHeader (qry_saveborrowerposition.cfm)
		sql = 	" UPDATE requestor_header " +
				" SET  requestor_type_id = ? " + 	// 1 newRequestorTypeId
				" WHERE evaluator_id = ? " + 		// 2 evaluatorID
				" AND request_id = ? " + 			// 3 requestID
				" AND requestor_type_id = ? " + 	// 4 currentBorrowerTypeId 
				" AND requestor_id = ? "; 			// 5 requestorId 
		sqlUpdate.SetPreparedUpdateStatement(con,sql);
		sqlUpdate.setInt(1, ""+newRequestorTypeId);
		sqlUpdate.setInt(2, evaluatorID);
		sqlUpdate.setInt(3, requestID);
		sqlUpdate.setInt(4, ""+currentBorrowerTypeId);
		sqlUpdate.setInt(5, ""+requestorId);
		sqlUpdate.RunPreparedUpdateStatement();		

		// update CREDIT_REQUEST (Applicant Name for MDQ)
		int personalFlg = 0;
		//if personal app (can only do change borrower on personal app but doing this check for consistency)
		sql = "select nvl(personal_flg,0) as personal_flg from credit_request where request_id = ? and evaluator_id = ? ";
		query.prepareStatement(sql);
		query.setInt(1,requestID);
		query.setInt(2,evaluatorID);
		query.executePreparedQuery();
		if(query.next()){
			personalFlg = Integer.parseInt(query.getColValue("personal_flg"));
		}

		int requestorTypePrimary = 0;
		if(personalFlg == 1){ //not possible for it to be a business app, but this was how the original cfm code was written
			//updateAppName (qry_saveborrowerposition.cfm)
			sql = 	" UPDATE credit_request " +
					" SET  application_name_txt = " +
					" ( " + 
					" SELECT last_name_txt || CASE WHEN second_last_name_txt IS NULL THEN '' ELSE (' '|| " +
					" second_last_name_txt) END || ', '||first_name_txt " + 
					" FROM requestor " + 
					" WHERE request_id = ? " + 		// 1 requestID
					" AND evaluator_id = ? " + 		// 2 evaluatorID 
					" AND requestor_type_id = ? " + // 3 requestorTypePrimary
					" ) " +
					" WHERE evaluator_id = ? " + 		// 4 evaluatorID
					" AND request_id = ? "; 			// 5 requestID;
			sqlUpdate.SetPreparedUpdateStatement(con,sql);
			sqlUpdate.setInt(1, requestID);
			sqlUpdate.setInt(2, evaluatorID);
			sqlUpdate.setInt(3, ""+requestorTypePrimary);
			sqlUpdate.setInt(4, evaluatorID);
			sqlUpdate.setInt(5, requestID);
			sqlUpdate.RunPreparedUpdateStatement();	
		}

		log.FmtAndLogMsg("Changedborrower: change borrower individual position, TTY file mod begin ");


		//TTY LOGIC (update REQUESTOR_BUREAU_RAW_TTY)
		//getTTYBureau (qry_saveborrowerposition.cfm)
		ArrayList<Integer> bureau_ids = new ArrayList<Integer>();
		String newRawTTYInfoTxt = "";
		String newRawBureauDataTxt = "";
		String newRawTTYInfoMaskedTxt = "";
		int bureauId = -1;
		String burPullDate = "";

		sql = "select bureau_id, bur_pull_date from requestor_bureau_raw_tty where request_id = ? and evaluator_id = ? and requestor_id = ? ";
		query.prepareStatement(sql);
		query.setInt(1,requestID);
		query.setInt(2,evaluatorID);
		query.setInt(3,requestorId);
		query.executePreparedQuery();
		while(query.next()){
			bureauId = Integer.parseInt(query.getColValue("bureau_id","-1"));
			burPullDate = query.getColValue("bur_pull_date","");

			String strCriteria = "BUREAU_ID="+bureauId+" AND REQUESTOR_ID= "+requestorId+" AND REQUEST_ID = " + requestID;
			if(!burPullDate.equals("") && burPullDate != null){
				strCriteria += " AND BUR_PULL_DATE = to_timestamp('"+burPullDate+"', 'YYYY-MM-DD HH24:MI:SS.FF')";
			}
			//getTTYFiles (qry_saveborrowerposition.cfm)

			sql = "SELECT Get_Bfilename('REQUESTOR_BUREAU_RAW_TTY','RAW_TTY_INFO_TXT',?) as raw_tty_info_txt, " + 
					" Get_Bfilename('REQUESTOR_BUREAU_RAW_TTY','RAW_BUREAU_DATA_TXT',?) as raw_bureau_data_txt, " + 
					" Get_Bfilename('REQUESTOR_BUREAU_RAW_TTY','RAW_TTY_INFO_TXT_MASKED',?) as raw_tty_info_txt_masked " + 
					" FROM dual ";
			query2.prepareStatement(sql);
			query2.setString(1,strCriteria);
			query2.setString(2,strCriteria);
			query2.setString(3,strCriteria);
			query2.executePreparedQuery();
			if(query2.next()){
				String rawTTYInfoTxt = query2.getColValue("raw_tty_info_txt","");
				String rawBureauDataTxt = query2.getColValue("raw_bureau_data_txt","");
				String rawTTYInfoMaskedTxt = query2.getColValue("raw_tty_info_txt_masked","");
				//NOTE IN qry_saveborrowerposition we tried to rename the files ourselves,
				//but the code wasnt functional and evaluate does the file renaming anyway, 
				//so file renaming has been left out
				if(rawTTYInfoTxt.length()>0){
					newRawTTYInfoTxt = rawTTYInfoTxt.substring(0, rawTTYInfoTxt.length()-2) + newEntityTxt;
				}
				if(rawBureauDataTxt.length()>0){
					newRawBureauDataTxt = rawBureauDataTxt.substring(0, rawBureauDataTxt.length()-2) + newEntityTxt;
				}
				if(rawTTYInfoMaskedTxt.length()>0){
					newRawTTYInfoMaskedTxt = rawTTYInfoMaskedTxt.substring(0, rawTTYInfoMaskedTxt.length()-2) + newEntityTxt;
				}
				//updateTTYFiles (qry_saveborrowerposition.cfm)
				sql = 	" UPDATE requestor_bureau_raw_tty " +
						" SET raw_tty_info_txt = BFILENAME(?,?) " + //1 dbTTyDirName, 2 newRawTTYInfoTxt
						" , raw_bureau_data_txt = BFILENAME(?,?) " + //3 dbTTyDirName, 4 newRawBureauDataTxt
						" , raw_tty_info_txt_masked = BFILENAME(?,?) " + // 5 dbTTyDirName, 6 newRawTTYInfoMaskedTxt
						" WHERE bureau_id = ? " + 	// 7 bureauId
						" AND request_id = ? " + 	// 8 requestID
						" AND requestor_id = ? " +  	// 9 requestorId
						" AND bur_pull_date = to_timestamp(?, 'YYYY-MM-DD HH24:MI:SS.FF')" ; //10 burPullDate
				sqlUpdate.SetPreparedUpdateStatement(con,sql);
				sqlUpdate.setString(1, dbTTyDirName);
				sqlUpdate.setString(2, newRawTTYInfoTxt);
				sqlUpdate.setString(3, dbTTyDirName);
				sqlUpdate.setString(4, newRawBureauDataTxt);
				sqlUpdate.setString(5, dbTTyDirName);
				sqlUpdate.setString(6, newRawTTYInfoMaskedTxt);
				sqlUpdate.setInt(7, ""+bureauId);
				sqlUpdate.setInt(8, requestID);
				sqlUpdate.setInt(9, ""+requestorId);
				sqlUpdate.setString(10, burPullDate);
				sqlUpdate.RunPreparedUpdateStatement();	
			}
		}
		log.FmtAndLogMsg("Changedborrower: change borrower individual position, TTY file mod end, begin sync coapplicant mtg trade ");
		//end TTY files 

		//reference UPDATE REQUESTOR_ADDED_TRADE CL 160239
		//getSyncFlg (qry_saveborrowerposition.cfm)
		int syncCoapMtgFlg = 0;
		sql = " SELECT sync_coap_mtg_flg " +
				" FROM EVALUATOR " + 
				" WHERE evaluator_id = ? ";
		query.prepareStatement(sql);
		query.setInt(1,evaluatorID);
		query.executePreparedQuery();
		if(query.next()){
			syncCoapMtgFlg = Integer.parseInt(query.getColValue("sync_coap_mtg_flg"));
		}

		//getRAT (qry_saveborrowerposition.cfm)
		sql = "SELECT rat.owner_txt as owner_txt,r.requestor_type_id as requestor_type_id," + 
				" rat.sequence_number_num as sequence_number_num, nvl(rat.owner_list_txt,'') as owner_list_txt " +
				" FROM requestor_added_trade rat, requestor r " + 
				" WHERE r.request_id = ? " +
				" AND r.evaluator_id = ? " + 
				" AND r.requestor_id = ? " + 
				" AND rat.request_id = r.request_id " + 
				" AND rat.requestor_id = r.requestor_id "; 
		query.prepareStatement(sql);
		query.setInt(1,requestID);
		query.setInt(2,evaluatorID);
		query.setInt(3,requestorId);
		query.executePreparedQuery();
		if(query.next()){
			String ownerTxt = "";
			String ownerList = query.getColValue("owner_list_txt","");
			int sequenceNumber = Integer.parseInt(query.getColValue("sequence_number_num","-1"));
			int reqstrAddTrdRequestorTypeID = Integer.parseInt(query.getColValue("requestor_type_id"));

			if(reqstrAddTrdRequestorTypeID == 0){//applicant
				if(syncCoapMtgFlg==1){
					ownerTxt = "B";
				} else {
					ownerTxt = "A";
				}
			} else if (reqstrAddTrdRequestorTypeID == 1) { //coapplicant
				ownerTxt = "C";
			} else { //cosigner
				ownerTxt = "A";
			}
			//setRAT (qry_saveborrowerposition.cfm)
			sql = 	" UPDATE requestor_added_trade " + 
					" SET owner_txt = ? " + 			// 1 ownerTxt
					" , owner_list_txt = ? " + 			// 2 ownerList
					" WHERE request_id = ? " + 			// 3 requestID
					" AND evaluator_id = ? " + 			// 4 evaluatorID
					" AND requestor_id = ? " + 			// 5 requestorId 
					" AND sequence_number_num = ? " ; 	// 6 sequenceNumber
			sqlUpdate.SetPreparedUpdateStatement(con,sql);
			sqlUpdate.setString(1, OWASPSecurity.validationCheck(ownerTxt,OWASPSecurity.SQLPARAMSTRING));
			sqlUpdate.setString(2, OWASPSecurity.validationCheck(ownerList,OWASPSecurity.SQLPARAMSTRING));
			sqlUpdate.setInt(3, requestID);
			sqlUpdate.setInt(4, evaluatorID);
			sqlUpdate.setInt(5, ""+requestorId);
			sqlUpdate.setInt(6, ""+sequenceNumber);
			sqlUpdate.RunPreparedUpdateStatement();	
		}
		//end update REQUESTOR_ADDED_TRADE
	}


	/**
	 * creates the entity groups in requestor_header and requestor tables for requestor type id of -3/ All cosigners
	 * if any cosigners exist on the saved off app
	 * see query/qry_createentitygroups.cfm
	 * CL 171135 State Farm: External Workflow Processing
	 * @param requestID
	 * @param evaluatorID
	 * @param requestorId
	 * @param requestorTypeId
	 * @param entityTxt
	 * @throws Exception
	 */
	private void createEntityGroups(String requestID, String evaluatorID, String requestorId, String requestorTypeId, String entityTxt) throws Exception {
		SQLUpdate mergeStmnt = new SQLUpdate();
		String sql = "";
		//qry_createentitygroups_rh (query/qry_createentitygroups.cfm)
		sql = 	" MERGE INTO REQUESTOR_HEADER rh " +
				" USING (select ? request_id, ? requestor_id from dual) d " +
				" ON (rh.request_id = d.request_id and rh.requestor_id = d.requestor_id) " +
				" WHEN MATCHED THEN UPDATE SET " +
				" requestor_type_id = ? , " +
				" evaluator_id = ? " +
				" WHEN NOT MATCHED THEN " + 
				" INSERT " + 
				" (request_id, " +
				" requestor_id, " +
				" requestor_type_id, " +
				" evaluator_id ) " +
				" VALUES " +
				" (?, " + //request id
				" ?, " + //requestor id
				" ?, " + //requestor type id
				" ? ) " ; //evaluator id
		mergeStmnt.SetPreparedUpdateStatement(con,sql);
		mergeStmnt.setInt(1,requestID);
		mergeStmnt.setInt(2,requestorId);

		mergeStmnt.setInt(3,requestorTypeId);
		mergeStmnt.setInt(4,evaluatorID);

		mergeStmnt.setInt(5,requestID);
		mergeStmnt.setInt(6,requestorId);
		mergeStmnt.setInt(7,requestorTypeId);
		mergeStmnt.setInt(8,evaluatorID);
		mergeStmnt.RunPreparedUpdateStatement();

		//qry_createentitygroups_r (query/qry_createentitygroups.cfm)
		sql =	" MERGE INTO REQUESTOR r " +
				" USING (select ? request_id, ? evaluator_id, ? requestor_id from dual) d " +
				" ON (r.request_id = d.request_id and r.evaluator_id = d.evaluator_id and r.requestor_id = d.requestor_id) " +
				" WHEN MATCHED THEN UPDATE SET " +
				" requestor_type_id = ?, " +
				" entity_txt = ? " +
				" WHEN NOT MATCHED THEN " +
				" INSERT " +
				" (request_id, "+
				" evaluator_id, " +
				" requestor_id, " +
				" requestor_type_id, " + 
				" entity_txt) " +
				" VALUES " +
				" (? ," + //request id
				" ?, " + //evaluator id 
				" ?, " + //requestor id
				" ?, " + //requestor type id
				" ?) " ; //entity 
		mergeStmnt.SetPreparedUpdateStatement(con,sql);
		mergeStmnt.setInt(1,requestID);
		mergeStmnt.setInt(2,evaluatorID);
		mergeStmnt.setInt(3,requestorId);

		mergeStmnt.setInt(4,requestorTypeId);
		mergeStmnt.setString(5,entityTxt);

		mergeStmnt.setInt(6,requestID);
		mergeStmnt.setInt(7,evaluatorID);
		mergeStmnt.setInt(8,requestorId);
		mergeStmnt.setInt(9,requestorTypeId);
		mergeStmnt.setString(10,entityTxt);

		mergeStmnt.RunPreparedUpdateStatement();
	}


	/**
	 * adds cosigner requestor trades logic as necessary for all cosigners on the app
	 * dataentry/action/act_addcosignertrades.cfm (and some query/qry_getcosignerrequestorid)
	 * CL 171135 State Farm: External Workflow Processing
	 * @param requestID
	 * @param evaluatorID
	 * @throws Exception
	 */
	private void addCosignerTrades(String requestID, String evaluatorID) throws Exception {
		Query queryGetRequestorId = new Query(con);
		Query query = new Query(con);
		SQLUpdate insertStmnt = new SQLUpdate();
		String sql = "";
		//qryGetCoSignerRequestorid (query/qry_getcosignerrequestorid)
		sql = 	" SELECT requestor_id " +
				" FROM requestor " + 
				" WHERE request_id = ? " +
				" AND evaluator_id = ? " +
				" AND requestor_type_id = ? ";
		queryGetRequestorId.prepareStatement(sql);
		queryGetRequestorId.setInt(1,requestID);
		queryGetRequestorId.setInt(2,evaluatorID);
		queryGetRequestorId.setInt(3,"2"); //hard code for requestor type id 2/ cosigner
		queryGetRequestorId.executePreparedQuery();
		while(queryGetRequestorId.next()){
			int cosMtgTradesRequestorId = Integer.parseInt(queryGetRequestorId.getColValue("requestor_id"));
			//findCosignerMortTrades (dataentry/action/act_addcosignertrades.cfm)
			//check to see if the cosigner trade has already been added
			sql = 	" SELECT 1 " + 		
					" FROM requestor_added_trade " +
					" WHERE evaluator_id = ? " +
					" AND request_id = ? " + 
					" AND requestor_id = ? " + 
					" AND debt_type_txt='M' ";
			query.prepareStatement(sql);
			query.setInt(1,evaluatorID);
			query.setInt(2,requestID);
			query.setInt(3,cosMtgTradesRequestorId);
			query.executePreparedQuery();
			// If there is no trade record for this cosigner, add it 
			boolean requestorAddedTradeRecordExists = query.next();
			if(!requestorAddedTradeRecordExists){
				int nextseqno = 1;
				float residencePaymentNum = 0;
				String residencePaymentExists = "";
				String landlordTxt = "";

				//First get the next trade sequence number
				//getNextTradeSeq (dataentry/action/act_addcosignertrades.cfm)
				sql = 	" SELECT nvl(max(sequence_number_num),0) as maxseqno " + 
						" FROM requestor_added_trade " + 
						" WHERE evaluator_id = ?" +
						" AND request_id = ? " +
						" AND requestor_id = ? ";
				query.prepareStatement(sql);
				query.setInt(1,evaluatorID);
				query.setInt(2,requestID);
				query.setInt(3,cosMtgTradesRequestorId);
				query.executePreparedQuery();
				if(query.next()){
					nextseqno = Integer.parseInt(query.getColValue("maxseqno","0")) + 1;
				}

				//Now get the landlord and payment information
				//getTradeInfo (dataentry/action/act_addcosignertrades.cfm)
				sql = 	" SELECT landlord_txt, residence_payment_num " + 
						" FROM requestor_address " +
						" WHERE evaluator_id = ? " +
						" AND request_id = ? " +
						" AND requestor_id = ? ";
				query.prepareStatement(sql);
				query.setInt(1,evaluatorID);
				query.setInt(2,requestID);
				query.setInt(3,cosMtgTradesRequestorId);
				query.executePreparedQuery();
				if(query.next()){
					landlordTxt = query.getColValue("landlord_txt","");
					residencePaymentExists = query.getColValue("residence_payment_num","");
					if(!residencePaymentExists.equals("")){
						residencePaymentNum = Float.parseFloat(query.getColValue("residence_payment_num"));
					}
				}
				if(!residencePaymentExists.equals("")){
					sql = 	" INSERT INTO REQUESTOR_ADDED_TRADE " +
							" (REQUEST_ID, " +//1
							" EVALUATOR_ID, "+//2
							" REQUESTOR_ID, "+//3
							" SEQUENCE_NUMBER_NUM, "+//4
							" CREDITOR_NAME_TXT, "+//5
							" PAYMENT_NUM, "+//6
							" ORIGINAL_PAYMENT_NUM, "+//7
							" DEBT_TYPE_TXT, "+//8
							" BUREAU_INCLUDE_FLG, "+//9
							" OWNER_TXT) "+//10
							" VALUES "+
							" ( ?,?,?,?,?,?,?,?,?,?)";
					insertStmnt.SetPreparedUpdateStatement(con,sql);
					insertStmnt.setInt(1,requestID);
					insertStmnt.setInt(2,evaluatorID);
					insertStmnt.setInt(3,cosMtgTradesRequestorId);
					insertStmnt.setInt(4,nextseqno);
					insertStmnt.setString(5,landlordTxt);
					insertStmnt.setFloat(6,residencePaymentNum);
					insertStmnt.setFloat(7,residencePaymentNum);
					insertStmnt.setString(8,"M");
					insertStmnt.setInt(9,"1");
					insertStmnt.setString(10,"A");
					insertStmnt.RunPreparedUpdateStatement();
				}

			}//not requestorAddedTradeRecordExists

			float taxInsuranceAmnt = 0;
			//qryTaxInsConfig (dataentry/action/act_addcosignertrades.cfm)
			sql = 	" SELECT nvl (insurance_taxes_amount_num, 0) as tax_ins_amt " + 
					" FROM evaluator " + 
					" WHERE evaluator_id = ? ";
			query.prepareStatement(sql);
			query.setInt(1,evaluatorID);
			query.executePreparedQuery();
			if(query.next()){
				taxInsuranceAmnt = Float.parseFloat(query.getColValue("tax_ins_amt","0"));
			}
			if(taxInsuranceAmnt>0){
				// Check to see if this cosigner tax/ins trade has already been added
				//findCosignerTaxInsTrade (dataentry/action/act_addcosignertrades.cfm)
				sql = 	" SELECT 1 " + 
						" FROM requestor_added_trade " +
						" WHERE evaluator_id = ? " +
						" AND request_id = ? " +
						" AND requestor_id = ? " + 
						" AND creditor_name_txt = 'Taxes and Insurance'";
				query.prepareStatement(sql);
				query.setInt(1,evaluatorID);
				query.setInt(2,requestID);
				query.setInt(3,cosMtgTradesRequestorId);
				query.executePreparedQuery();
				//If there is no tax/ins trade record for this cosigner, add it
				boolean taxInsuranceRecordExists = query.next();
				if(!taxInsuranceRecordExists){
					int nextseqno = 1;
					//First get the next trade sequence number
					//getNextTradeSeq (dataentry/action/act_addcosignertrades.cfm)
					sql = 	" SELECT nvl(max(sequence_number_num),0) as maxseqno " +
							" FROM requestor_added_trade " +
							" WHERE Evaluator_id = ? " + 
							" AND Request_id = ? " +
							" AND Requestor_id = ? ";
					query.prepareStatement(sql);
					query.setInt(1,evaluatorID);
					query.setInt(2,requestID);
					query.setInt(3,cosMtgTradesRequestorId);
					query.executePreparedQuery();
					if(query.next()){
						nextseqno = Integer.parseInt(query.getColValue("maxseqno","0")) + 1;
					}
					//insertTaxInsTrade  (dataentry/action/act_addcosignertrades.cfm)
					sql = 	" INSERT INTO REQUESTOR_ADDED_TRADE " +
							" (Request_Id, " + //1
							" Evaluator_Id, " +//2
							" Requestor_Id, " +//3
							" Sequence_Number_Num, " +//4
							" Creditor_Name_Txt, " +//5
							" Payment_Num, " +//6
							" Original_Payment_Num, " +//7
							" Debt_Type_Txt, " +//8
							" Bureau_Include_Flg, " +//9
							" Owner_Txt) " +//10
							" VALUES " +
							" ( ?,?,?,?,?,?,?,?,?,?)";
					insertStmnt.SetPreparedUpdateStatement(con,sql);
					insertStmnt.setInt(1,requestID);
					insertStmnt.setInt(2,evaluatorID);
					insertStmnt.setInt(3,cosMtgTradesRequestorId);
					insertStmnt.setInt(4,nextseqno);
					insertStmnt.setString(5,"Taxes and Insurance");
					insertStmnt.setFloat(6,taxInsuranceAmnt);
					insertStmnt.setFloat(7,taxInsuranceAmnt);
					insertStmnt.setString(8,"O");
					insertStmnt.setInt(9,"1");
					insertStmnt.setString(10,"A");
					insertStmnt.RunPreparedUpdateStatement();
				}
			}
		}
	}

	private static void setEvalEnv(String evalEnvIn){
		evalEnv = evalEnvIn;
	}

	private static void setEvalHost(String evalHostIn){
		evalHost = evalHostIn;
	}

	private static void setEvalVer(String evalVerIn){
		evalVer = evalVerIn;
	}

	private static void setEvalPort(String evalPortIn){
		evalPort = evalPortIn;
	}

	private static void setEvalReceivePort(String evalReceivePortIn){
		evalReceivePort = evalReceivePortIn;
	}

	private static void setEvalFacadeLog(String evalFacadeLogIn){
		evalFacadeLog = evalFacadeLogIn;
	}

	private static void setDebugMemory(int debugMemoryIn){
		debugMemory = debugMemoryIn;
	}

	private static void setOverrideEffectDtFlg(String overrideEffectDtFlgIn){
		overrideEffectDtFlg = overrideEffectDtFlgIn;
	}

	private static void setEffectDtType(String effectDtTypeIn){
		effectDtType = effectDtTypeIn;
	}

	private static void setFixedDt(String fixedDtIn){
		fixedDt = fixedDtIn;
	}

	private static void setDynamicDtOpt(String dynamicDtOptIn){
		dynamicDtOpt = dynamicDtOptIn;
	}

	private static void setDbTTyDirName(String dbTTyDirNameIn){
		dbTTyDirName = dbTTyDirNameIn;
	}

	private static void setClientName(String clientNameIn){
		clientName = clientNameIn;
	}

	/***************************************************************/
	/*                    Reocord error                            */
	/***************************************************************/
	private void recordError(Exception err, String classStr) throws Exception  {
		try {
			if (b_debugger){
				err.printStackTrace();
			}

			StackTraceElement[] stackElements = err.getStackTrace();
			int prnLen = 0;
			//Print first 3 elements
			if (stackElements.length > 3) {
				prnLen = 3;
			}else {
				prnLen = stackElements.length;
			}

			log.FmtAndLogMsg ("////////////////The first " +  prnLen +  " elements of a " +  stackElements.length +  " element stack trace://////////////////////\n");

			for (int lcv = 0; lcv < prnLen; lcv++)  {
				log.FmtAndLogMsg("Full class name: " + stackElements[lcv].getClassName());
				log.FmtAndLogMsg("File name: " +   stackElements[lcv].getFileName());
				log.FmtAndLogMsg("Method name: " + stackElements[lcv].getMethodName());
				log.FmtAndLogMsg("Line number: " +  stackElements[lcv].getLineNumber());
				log.FmtAndLogMsg("Native method?: " +  stackElements[lcv].isNativeMethod());
				log.FmtAndLogMsg("String Message: " +   stackElements[lcv].toString());
			}

			//Print last 2 elements
			if (stackElements.length > 3) {
				prnLen = stackElements.length - 2;
			}else {
				prnLen = 0;
			}

			if (prnLen != 0) {
				log.FmtAndLogMsg ("--------------The last 2  elements of a " +  stackElements.length +  " element stack trace:--------------\n");

				for (int lcv = prnLen; lcv < stackElements.length; lcv++)  {
					log.FmtAndLogMsg("Full class name: " + stackElements[lcv].getClassName());
					log.FmtAndLogMsg("File name: " +   stackElements[lcv].getFileName());
					log.FmtAndLogMsg("Method name: " + stackElements[lcv].getMethodName());
					log.FmtAndLogMsg("Line number: " +  stackElements[lcv].getLineNumber());
					log.FmtAndLogMsg("Native method?: " +  stackElements[lcv].isNativeMethod());
					log.FmtAndLogMsg("String Message: " +   stackElements[lcv].toString());
				}
			}

			log.FmtAndLogMsg ("//////////////// End of stack trace //////////////////////\n");
			throw new Exception("Error in " + classStr + " method of : " + err.toString());
		} catch (Exception e) {
			log.FmtAndLogMsg("Error in recordError method of : ", e);
			throw e;
		}   
	}
}
