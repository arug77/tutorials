



package com.cmsinc.origenate.ae;


import java.sql.*;
import com.cmsinc.origenate.util.LogMsg;
import com.cmsinc.origenate.util.IniFile;


public class FeesSummary {

  //Set debugger
  //private boolean b_debugger = false;

  private Connection con;
  private LogMsg log = new LogMsg();
  private boolean b_clsConnectionlocal = true,  b_otherConnection = false;
  private String callFrom = "APPENTRY";
  private int scenario_ID = 0;
  static int s_i_debug_memory = -1;


   /***************************************************************/
   /*                   Fees constructor                         */
   /***************************************************************/
  public FeesSummary(Connection con,LogMsg log) throws Exception {
 try {
    this.con=con;
    this.log=log;
    this.b_otherConnection  = true;
    //If debug option is not saved then check for it
   if (s_i_debug_memory == -1) {
     s_i_debug_memory = this.log.getDebugSetting(con);
   }
   if (s_i_debug_memory == 1) { 
         log.FmtAndLogMsg("FEE:FeesSummary:OPEN:Connect using external obj");
   }
 } catch (Exception e) {
       log.FmtAndLogMsg("DEBUG MESSAGE: FeesSummary.java FeesSummary Constructor : Error in FeesSummary method of : ", e);
 }
}


  /***************************************************************/
    /* Create FeesSummary obejct and get DB connection */
    /***************************************************************/


 public FeesSummary(String s_LogName, String s_iniFile, String s_callfrom) throws Exception {

   //Get ini file values for DB connection
     IniFile ini = new IniFile();
     ini.readINIFile(s_iniFile);
     String s_clientName = ini.getINIVar("general.client_name");

     log.openLogFile(s_LogName);

   // Instantiate InitialContext
    javax.naming.InitialContext ctx=null;
    try {
      ctx = new javax.naming.InitialContext();

	  String s_jdbcDSName = s_clientName + "_origpool";

	  // Lookup the datasource
      javax.sql.DataSource  ds = (javax.sql.DataSource) ctx.lookup(s_jdbcDSName);

	// Get the connection from the datasource
	this.con = ds.getConnection();
	this.callFrom = s_callfrom;

     if (this.con == null) {
            log.FmtAndLogMsg("***Connection is null in calling FeesSummary ***");
     }  else {
             //If debug option is not saved then check for it
           if (s_i_debug_memory == -1) {
             s_i_debug_memory = this.log.getDebugSetting(con);
           }
           if (s_i_debug_memory == 1) { 
               log.FmtAndLogMsg("FEE:FeesSummary:OPEN:Connect using connection pool");
           }
      }


    } catch (Exception e) {
       log.FmtAndLogMsg("DEBUG MESSAGE: FeesSummary.java FeesSummary Constructor(3 arguments) : Error in FeesSummary method of : ", e);
       throw new Exception("Error in FeesSummary method of : " + e.toString(), e);
    }
}


/***************************************************************/
    /* Create FeesSummary obejct and get DB connection */
    /***************************************************************/


 public FeesSummary(String s_LogName, String s_iniFile, String s_callfrom, String scenarioID) throws Exception {

   //Get ini file values for DB connection
     IniFile ini = new IniFile();
     ini.readINIFile(s_iniFile);
     String s_clientName = ini.getINIVar("general.client_name");

     log.openLogFile(s_LogName);

   // Instantiate InitialContext
    javax.naming.InitialContext ctx=null;
    try {
      ctx = new javax.naming.InitialContext();

	  String s_jdbcDSName = s_clientName + "_origpool";

	  // Lookup the datasource
      javax.sql.DataSource  ds = (javax.sql.DataSource) ctx.lookup(s_jdbcDSName);

	// Get the connection from the datasource
	this.con = ds.getConnection();
	this.callFrom = s_callfrom;
	this.scenario_ID = (new Integer(scenarioID)).intValue();

     if (this.con == null) {
            log.FmtAndLogMsg("***Connection is null in calling FeesSummary ***");
          }  else {
                  //If debug option is not saved then check for it
                if (s_i_debug_memory == -1) {
                  s_i_debug_memory = this.log.getDebugSetting(con);
                }
                if (s_i_debug_memory == 1) { 
                    log.FmtAndLogMsg("FEE:FeesSummary:OPEN:Connect using connection pool");
                }
           }


    } catch (Exception e) {
       log.FmtAndLogMsg("DEBUG MESSAGE: FeesSummary.java FeesSummary Constructor(4 arguments) : Error in FeesSummary method of : ", e);
       throw new Exception("Error in FeesSummary method of : " + e.toString(), e);
    }
}




    /***************************************************************/
    /*             Calculate contract fees summary                 */
   /***************************************************************/
    public void calcContractFeesSum(int request_id) throws Exception {
      this.callFrom = "CONTRACTADMIN";
      calcFeesSum(request_id);
    }


    /***************************************************************/
    /*                   Calculate fees summary                    */
    /***************************************************************/
     public void calcFeesSum(int request_id) throws Exception {
      
      PreparedStatement ps=null, ps1 = null;
      ResultSet rs = null;
      String sql= "" , sql1 = "";
      int i_evalID = 1;
      int i_finID = -1;
      int i_fees_include_flg = 0;
      int i_incFin_flg = 0;
	  int i_incReq_flg = 0;
      int i_ppfc_flg = 0;
      int i_flat_fee_flg = 0;
	  int i_feeID = 0;
	  int appASN = -1;
      float f_totAmt = 0;
      float f_lender_percent_num =0;
      float f_lender_amt_num =0;
      float f_borrower_percent_num =0;
      float f_borrower_amt_num =0;
      float f_other_percent_num =0;
      float f_other_amt_num =0;
      String s_finance_poc_txt = "";
      String s_paidby = "";
      //Total fees
      float f_total_fin_fee = 0;
      float f_total_lender_fee = 0;
      float f_total_borrow_fee = 0;
      float f_total_other_fee = 0;
      float f_total_nonfin_fee = 0;
      float f_total_ppfc_fee = 0;
      float f_total_nonppfc_fee = 0;
      float f_total_poc_fee = 0;
      float f_total_fee = 0;
      float f_total_incfin_fee = 0;
      float f_total_dealer_fee = 0;
	  float f_total_ppfc_fin_fee = 0;
	  float f_total_reqamt_fee = 0;
	  float f_less_nonfin_ppfc_fee = 0;
	  
      String strFee = "CREDIT_REQ_FINANCED_FEE";
      String strFeeSum = "CREDIT_REQ_FINANCED_FEE_SUM";

      boolean b_new_calc_flg = false;
      boolean b_fee_record_flg = false;
      int prodId = -1;
	  
	  
      b_clsConnectionlocal = false;
	  
      
      
      if (s_i_debug_memory == 1) { 
                log.FmtAndLogMsg("FEE:calcFeesSum:ENTER");
 }


      try {
	  
	  
	  
	  sql = "select product_id from credit_request where request_id = ?";

        //Prepare statement to execute
        ps = con.prepareStatement(sql);

        //Set param values
        ps.setInt(1, request_id);

        //Execute statement
        rs = ps.executeQuery();

        //Loop all values
        if (rs.next()) {
	    prodId =  rs.getInt("product_id");
	   }   

        //Close open source
	    try{ if(rs != null) rs.close(); }catch(Exception e1){e1.printStackTrace();}
		try{ if(ps != null) ps.close(); }catch(Exception e1){e1.printStackTrace();}
	  

	    //If call from contract admin then assign CA fees table
	    if  (this.callFrom.equalsIgnoreCase("CONTRACTADMIN") || this.callFrom.equalsIgnoreCase("DEALER")) {
		   strFee = "CREDIT_REQ_CONTRA_FINANCED_FEE";
		   strFeeSum = "CREDIT_REQ_CONTRA_FIN_FEE_SUM";
             } else if  (this.callFrom.equalsIgnoreCase("PSM")) {
                  strFee = "PSM_FINANCED_FEE";
                  strFeeSum = "PSM_FINANCED_FEE_SUM";
	   }

        //Select fees value
           if (!this.callFrom.equalsIgnoreCase("PSM")) {
	    sql =   " select * from  " + strFee +  " where request_id = ?  and finance_id = 1 ";
           } else if (this.callFrom.equalsIgnoreCase("PSM")) {
             sql =   " select * from  " + strFee +  " where request_id = ?  and finance_id = 1 and SCENARIO_ID = ? ";
           }

       //Prepare statement to execute
       ps = con.prepareStatement(sql);

       //Set param values
       ps.setInt(1, request_id);
       if (this.callFrom.equalsIgnoreCase("PSM")) {
          ps.setInt(2, scenario_ID);
        }


       //Execute statement
        rs = ps.executeQuery();

       //Loop all values
       while (rs.next()) {

	        b_fee_record_flg = true;

            f_lender_percent_num =  rs.getFloat("lender_percent_num");
            f_lender_amt_num =  rs.getFloat("lender_amt_num");
            f_borrower_percent_num =  rs.getFloat("borrower_percent_num");
            f_borrower_amt_num =  rs.getFloat("borrower_amt_num");
            f_other_percent_num =  rs.getFloat("other_percent_num");
            f_other_amt_num =  rs.getFloat("other_amt_num");
            f_totAmt =  rs.getFloat("VALUE_NUM");
	    	i_feeID = rs.getInt("FINANCED_FEE_ID");


            //Check for lender amt
            if (f_totAmt != 0 && f_lender_percent_num != 0 && f_lender_amt_num == 0) {
              f_lender_amt_num = (f_totAmt * f_lender_percent_num) / 100;
              b_new_calc_flg = true;
            }
            //Check for lender percent
            if (f_totAmt != 0 && f_lender_percent_num == 0 && f_lender_amt_num != 0) {
              f_lender_percent_num = (f_lender_amt_num * 100) / f_totAmt;
              b_new_calc_flg = true;
            }
            //Check for borrower amt
            if (f_totAmt != 0 && f_borrower_percent_num != 0 && f_borrower_amt_num == 0) {
              f_borrower_amt_num = (f_totAmt * f_borrower_percent_num) / 100;
              b_new_calc_flg = true;
            }
            //Check for borrower percent
            if (f_totAmt != 0 && f_borrower_percent_num == 0 && f_borrower_amt_num != 0) {
              f_borrower_percent_num = (f_borrower_amt_num * 100) / f_totAmt;
              b_new_calc_flg = true;
            }
            //Check for other amt
            if (f_totAmt != 0 && f_other_percent_num != 0 && f_other_amt_num == 0) {
              f_other_amt_num = (f_totAmt * f_other_percent_num) / 100;
              b_new_calc_flg = true;
            }
            //Check for other percent
            if (f_totAmt != 0 && f_other_percent_num == 0 && f_other_amt_num != 0) {
              f_other_percent_num = (f_other_amt_num * 100) / f_totAmt;
              b_new_calc_flg = true;
            }

            //Update calculated values to fees
            if (b_new_calc_flg) {

             if (!this.callFrom.equalsIgnoreCase("PSM")) {
              sql1 =  " update " + strFee + " set  lender_amt_num = ?, lender_percent_num = ?, borrower_amt_num = ?, borrower_percent_num = ?, other_amt_num = ?, other_percent_num = ? " +
             " where request_id = ? " +
	      " and finance_id = 1  and  FINANCED_FEE_ID = " + i_feeID;
             } else  if (this.callFrom.equalsIgnoreCase("PSM")) {
               sql1 =  " update " + strFee + " set  lender_amt_num = ?, lender_percent_num = ?, borrower_amt_num = ?, borrower_percent_num = ?, other_amt_num = ?, other_percent_num = ? " +
               " where request_id = ? " +
	      " and finance_id = 1  and  FINANCED_FEE_ID = " + i_feeID + " and SCENARIO_ID = ? ";
             }



              //Prepare statement to execute
              ps1 = con.prepareStatement(sql1);

              //Set param values
              ps1.setFloat(1, f_lender_amt_num);
              ps1.setFloat(2, f_lender_percent_num);
              ps1.setFloat(3, f_borrower_amt_num);
              ps1.setFloat(4, f_borrower_percent_num);
              ps1.setFloat(5, f_other_amt_num);
              ps1.setFloat(6, f_other_percent_num);
              ps1.setInt(7, request_id);
              if (this.callFrom.equalsIgnoreCase("PSM")) {
                ps1.setInt(8, scenario_ID);
            }

              //Execute statement
              ps1.execute();
              //  need to close stmt
			  try{ if(ps1 != null) ps1.close(); }catch(Exception e1){e1.printStackTrace();}
            }
          }//while



         // close stmt, rs
         try{ if(rs != null) rs.close(); }catch(Exception e1){e1.printStackTrace();}
		 try{ if(ps != null) ps.close(); }catch(Exception e1){e1.printStackTrace();}
        /////Calculate total fees////////

	   if (b_fee_record_flg) {

          //Select latest fees value
              if (!this.callFrom.equalsIgnoreCase("PSM")) {
                sql =   " select * from  " + strFee + " where request_id = ? and finance_id = 1   ";
              } else if (this.callFrom.equalsIgnoreCase("PSM")) {
                 sql =   " select * from  " + strFee + " where request_id = ? and finance_id = 1  and SCENARIO_ID = ? ";
              }

         //Prepare statement to execute
         ps = con.prepareStatement(sql);

         //Set param values
         ps.setInt(1, request_id);
         if (this.callFrom.equalsIgnoreCase("PSM")) {
           ps.setInt(2, scenario_ID);
         }

         //Execute statement
          rs = ps.executeQuery();

         //Loop all values
         while (rs.next()) {

            i_evalID =  rs.getInt("evaluator_id");
            i_finID  =  rs.getInt("FINANCE_ID");
            f_totAmt =  rs.getFloat("VALUE_NUM");
            i_fees_include_flg =  rs.getInt("FEES_INCLUDE_FLG");
            i_ppfc_flg = rs.getInt("ppfc_flg");
	        i_incFin_flg = rs.getInt("is_include_in_amtfin_flg");
			// this flag must default to is_include_in_amtfin_flg if null and since getInt defaults to 0, we have to do this
			if (rs.getObject("include_in_reqamt_flg") == null)
				i_incReq_flg = rs.getInt("is_include_in_amtfin_flg");
			else
				i_incReq_flg = rs.getInt("include_in_reqamt_flg");
			
            i_flat_fee_flg =  rs.getInt("flat_fee_flg");
            s_finance_poc_txt =  rs.getString("finance_poc_txt");
            f_lender_amt_num =  rs.getFloat("lender_amt_num");
            f_borrower_amt_num =  rs.getFloat("borrower_amt_num");
            f_other_amt_num =  rs.getFloat("other_amt_num");
            s_paidby= rs.getString("PAID_BY_TXT");

           //Include this fee
           if (i_fees_include_flg == 1) {
               //Total lender fees
              f_total_lender_fee = f_total_lender_fee +  f_lender_amt_num;
              //Total lender fees
              f_total_borrow_fee = f_total_borrow_fee +  f_borrower_amt_num;
              //Total Other fees
              f_total_other_fee = f_total_other_fee +  f_other_amt_num;




              //Total fin/non-fin fees and total ppfc fees that are financed
			 if (s_finance_poc_txt != null) {
             	if (s_finance_poc_txt.equalsIgnoreCase("Y") || s_finance_poc_txt.equalsIgnoreCase("F")) {
                	f_total_fin_fee = f_total_fin_fee + f_totAmt;
					if(i_ppfc_flg == 1)
					f_total_ppfc_fin_fee = f_total_ppfc_fin_fee + f_totAmt;
              	} 
				else if  (s_finance_poc_txt.equalsIgnoreCase("N") || s_finance_poc_txt.equalsIgnoreCase("P")) {
                	//154744 Removed to match nonfinfee calc in fee grid  
                	//if (s_finance_poc_txt.equalsIgnoreCase("N")) {
				   		//f_total_nonfin_fee = f_total_nonfin_fee + f_totAmt;
					//}
					f_total_poc_fee = f_total_poc_fee + f_totAmt;
			  	} 
				else  {
			    	f_total_nonfin_fee = f_total_nonfin_fee + f_totAmt;
              	}
			 } 
			 else {
			     f_total_nonfin_fee = f_total_nonfin_fee + f_totAmt;
			 }
  
         
             //Total ppfc/non-ppfc fees        
		     //changed back to keep logic the same for all products
		 	 if (i_ppfc_flg == 1) {
                f_total_ppfc_fee = f_total_ppfc_fee + f_totAmt;
             } 
			 else {
                f_total_nonppfc_fee = f_total_nonppfc_fee + f_totAmt;
             }			  
			
			//Less Non-Fin PPFC Fees
			if (i_ppfc_flg == 1) {
				if (s_finance_poc_txt != null) {
					if (s_finance_poc_txt.equalsIgnoreCase("N") || s_finance_poc_txt.equalsIgnoreCase("P")) {
						f_less_nonfin_ppfc_fee = f_less_nonfin_ppfc_fee + f_totAmt;
					}
				}
				else {
					f_less_nonfin_ppfc_fee = f_less_nonfin_ppfc_fee + f_totAmt;
				}
			}
			 
	      //Total incfin fees
	      if (i_incFin_flg == 1) {
                f_total_incfin_fee = f_total_incfin_fee + f_totAmt;
              }
			
		  // total requested amount flagged fees	
		  if (i_incReq_flg == 1) {
		  	f_total_reqamt_fee += f_totAmt;
		  }	
              //Total dealer fees
			if (s_paidby != null) {
              if (s_paidby.equalsIgnoreCase("D")) {
                 f_total_dealer_fee = f_total_dealer_fee + f_totAmt;
              }
			 }

              //Total Fees
              f_total_fee = f_total_fee + f_totAmt;
           }
         } // while rs

         //Get timestamp value
        java.sql.Timestamp sysDate = new java.sql.Timestamp(System.currentTimeMillis());


        // close stmt, rs
		try{ if(rs != null) rs.close(); }catch(Exception e1){e1.printStackTrace();}
		try{ if(ps != null) ps.close(); }catch(Exception e1){e1.printStackTrace();}

 


        /* GL. Before we insert, we need to delete the existing row
        */


        sql =   " delete from  "  + strFeeSum + " where request_id = ? and evaluator_id = ? and finance_id = ?";
        //Prepare statement to execute
        ps = con.prepareStatement(sql);

        //Set param values
        ps.setInt(1, request_id);
        ps.setInt(2, i_evalID);
        ps.setInt(3, i_finID);
        //Execute statement
        ps.execute();

        //Close open source
		try{ if(ps != null) ps.close(); }catch(Exception e1){e1.printStackTrace();}



	//Get ASN
	appASN = getASN(request_id);

        //insert record in  credit_req_contract
        if (appASN != -1) {
         //Insert record in summary fees
           if (!this.callFrom.equalsIgnoreCase("PSM")) {
             sql =   " insert into  "  + strFeeSum + " (request_id, evaluator_id, finance_id, LENDER_PAID_FEES_NUM, BORROWER_PAID_FEES_NUM, OTHER_PAID_FEES_NUM,FINANCED_FEES_NUM, NON_FINANCED_FEES_NUM, PPFC_FEES_NUM, NON_PPFC_FEES_NUM, POC_FEES_NUM, INCIN_AMT_FIN_FEE_NUM,INCIN_REQAMT_FEE_NUM ,DEALER_FEES_NUM, TOTAL_FEES_NUM,ppfc_fin_fees_num,audit_last_updated_dt,LESS_NONFIN_PPFC_NUM, audit_updated_user_id,appseqno) " +
                " values (?, ? , ?, ?, ?, ?, ?, ?, ?, ?, ?, ? , ?, ?, ?,?,?,?,?,?) ";
           } else  if (this.callFrom.equalsIgnoreCase("PSM")) {
             sql =   " insert into  "  + strFeeSum + " (request_id, evaluator_id, finance_id, LENDER_PAID_FEES_NUM, BORROWER_PAID_FEES_NUM, OTHER_PAID_FEES_NUM,FINANCED_FEES_NUM, NON_FINANCED_FEES_NUM, PPFC_FEES_NUM, NON_PPFC_FEES_NUM, POC_FEES_NUM, INCIN_AMT_FIN_FEE_NUM,INCIN_REQAMT_FEE_NUM,DEALER_FEES_NUM, TOTAL_FEES_NUM,ppfc_fin_fees_num, audit_last_updated_dt,LESS_NONFIN_PPFC_NUM,audit_updated_user_id,appseqno,SCENARIO_ID) " +
               " values (?, ? , ?, ?, ?, ?, ?, ?, ?, ?, ?, ? , ?, ?, ?,?,?,?,?,?,?) ";
           }
        } else {
		 //Insert record in summary fees
           if (!this.callFrom.equalsIgnoreCase("PSM")) {
                sql =   " insert into  "  + strFeeSum + " (request_id, evaluator_id, finance_id, LENDER_PAID_FEES_NUM, BORROWER_PAID_FEES_NUM, OTHER_PAID_FEES_NUM,FINANCED_FEES_NUM, NON_FINANCED_FEES_NUM, PPFC_FEES_NUM, NON_PPFC_FEES_NUM, POC_FEES_NUM, INCIN_AMT_FIN_FEE_NUM,INCIN_REQAMT_FEE_NUM,DEALER_FEES_NUM, TOTAL_FEES_NUM,ppfc_fin_fees_num, audit_last_updated_dt,LESS_NONFIN_PPFC_NUM,audit_updated_user_id) " +
                     " values (?, ? , ?, ?, ?, ?, ?, ?, ?, ?, ?, ? , ?, ?, ?,?,?,?,?) ";
           } else  if (this.callFrom.equalsIgnoreCase("PSM")) {
             sql =   " insert into  "  + strFeeSum + " (request_id, evaluator_id, finance_id, LENDER_PAID_FEES_NUM, BORROWER_PAID_FEES_NUM, OTHER_PAID_FEES_NUM,FINANCED_FEES_NUM, NON_FINANCED_FEES_NUM, PPFC_FEES_NUM, NON_PPFC_FEES_NUM, POC_FEES_NUM, INCIN_AMT_FIN_FEE_NUM,INCIN_REQAMT_FEE_NUM,DEALER_FEES_NUM, TOTAL_FEES_NUM,ppfc_fin_fees_num, audit_last_updated_dt,LESS_NONFIN_PPFC_NUM,audit_updated_user_id) " +
               " values (?, ? , ?, ?, ?, ?, ?, ?, ?, ?, ?, ? , ?, ?, ?,?,?,?,?,?) ";
           }
	}

        //Prepare statement to execute
        ps = con.prepareStatement(sql);

				
        //Set param values
        ps.setInt(1, request_id);
        ps.setInt(2, i_evalID);
        ps.setInt(3, i_finID);
        ps.setFloat(4, f_total_lender_fee);
        ps.setFloat(5, f_total_borrow_fee);
        ps.setFloat(6, f_total_other_fee);
        ps.setFloat(7,f_total_fin_fee);
        ps.setFloat(8, f_total_nonfin_fee);
        ps.setFloat(9,f_total_ppfc_fee);
        ps.setFloat(10,f_total_nonppfc_fee);
        ps.setFloat(11,f_total_poc_fee);
		ps.setFloat(12,f_total_incfin_fee);
		ps.setFloat(13,f_total_reqamt_fee);
		
        ps.setFloat(14,f_total_dealer_fee);
        ps.setFloat(15,f_total_fee);
		ps.setFloat(16,f_total_ppfc_fin_fee);
        ps.setTimestamp (17, sysDate);
		ps.setFloat(18,f_less_nonfin_ppfc_fee);		
        ps.setString(19, "SYSTEM");
		if (appASN != -1) {
	  		ps.setInt(20, appASN);
         	if (this.callFrom.equalsIgnoreCase("PSM")) {
           		ps.setInt(21, scenario_ID);
         	}
		} 
		else if (appASN == -1 && this.callFrom.equalsIgnoreCase("PSM")) {
            ps.setInt(20, scenario_ID);
        }

        //Execute statement
        ps.execute();

        //Close open source
        try{ if(ps != null) ps.close(); }catch(Exception e1){e1.printStackTrace();}


	//
	//Determine Loan Type
	//
        int loan_type_id = 1;
	sql = "select loan_type_id from credit_request where request_id = ?";

        //Prepare statement to execute
        ps = con.prepareStatement(sql);

        //Set param values
        ps.setInt(1, request_id);

        //Execute statement
        rs = ps.executeQuery();

        //Loop all values
        while (rs.next()) {
	  loan_type_id =  rs.getInt("loan_type_id");
	}

        //Close open source
        try{ if(rs != null) rs.close(); }catch(Exception e1){e1.printStackTrace();}
		try{ if(ps != null) ps.close(); }catch(Exception e1){e1.printStackTrace();}


	//
	//Update Fee
	//
	if (loan_type_id == 2){
	  sql = "update credit_request_lease set total_lease_fee_num = ? where request_id = ? and finance_id = 1";
	}
	else{
	  sql = "update credit_request_finance set total_finance_fee_num = ? where request_id = ? and finance_id = 1";
	}

        //Prepare statement to execute
        ps = con.prepareStatement(sql);

	//Set params
        ps.setFloat(1,f_total_incfin_fee);
	ps.setInt(2,request_id);

        //Execute statement
        ps.execute();

        //Close open source
        try{ if(ps != null) ps.close(); }catch(Exception e1){e1.printStackTrace();}
	//
	//Set totals based on fees
	//
	if (loan_type_id == 2){
	  float value = 0;

	  sql = "select calc_net_cap_cost(?,?) as total_value from dual";

          //Prepare statement to execute
          ps = con.prepareStatement(sql);

	  //Set params
	  ps.setInt(1, request_id);
          ps.setInt(2, i_evalID);

          //Execute statement
          rs = ps.executeQuery();

          //Loop all values
          while (rs.next()) {
	    value =  rs.getFloat("total_value");
	  }

          //Close open source
          try{ if(ps != null) ps.close(); }catch(Exception e1){e1.printStackTrace();}


	  sql = "update credit_request_lease set total_net_cap_cost_num = ? where request_id = ? and finance_id = 1";


          //Prepare statement to execute
          ps = con.prepareStatement(sql);

	  //Set params
          ps.setFloat(1,value);
	  ps.setInt(2,request_id);

          //Execute statement
          ps.execute();

          //Close open source
          try{ if(ps != null) ps.close(); }catch(Exception e1){e1.printStackTrace();}
	}


        //fees calc successful
        log.FmtAndLogMsg("FeeSum: RID= "+request_id+", fees summary calculation successful.");

	   } //if fees record found then update summary

      } catch (Exception ex) {
	     log.FmtAndLogMsg("RID="+request_id+" - DEBUG MESSAGE: FeesSummary.java calcFeesSum Method : Error in calcFeesSum method for requestId: "+request_id, ex);
        //Roll back changes
       if (!b_otherConnection) {
           con.rollback();
           con.close();
           if (s_i_debug_memory == 1) { 
              log.FmtAndLogMsg("FEE:calcFeesSum:CLOSE");
}

       }
      throw ex;
      } finally {
		try{ if(rs != null) rs.close(); }catch(Exception e1){e1.printStackTrace();}
		try{ if(ps != null) ps.close(); }catch(Exception e1){e1.printStackTrace();}
		try{ if(ps1 != null) ps1.close(); }catch(Exception e1){e1.printStackTrace();}

        try {
		 b_clsConnectionlocal = true;
          if (!b_otherConnection && b_clsConnectionlocal && con != null) {
            con.close();
            if (s_i_debug_memory == 1) { 
             log.FmtAndLogMsg("FEE:calcFeesSum:CLOSE");
}

          }
        } catch (Exception e) {
           // connection may already been closed above
        //throw e;
       }
     }
  }


  /*****************************************************************************/
  /*         Select ASN for evaluate app                                      */
 /****************************************************************************/
 private int getASN(int request_id) throws Exception  {
  int i_ret_success = -1;
  int i_personalFlg = 1;
  PreparedStatement ps = null;
  ResultSet rs = null;
  String sql = "";
  String tblNm = "";

  if (s_i_debug_memory == 1) { 
                 log.FmtAndLogMsg("FEE:getASN:ENTER");
 }


   try {

        //Get evluator id value
        sql = " SELECT	personal_flg FROM credit_request WHERE	request_id = ? ";

         //Prepare statement to execute
        ps = con.prepareStatement(sql);

        //Set param values
        ps.setInt(1, request_id);

        //Execute statement
        rs = ps.executeQuery();

        //Get values
        if (rs.next()) {
             i_personalFlg =  rs.getInt("personal_flg");

	         if (i_personalFlg == 1) {
			  	tblNm = "requestor";
			 } else {
			     tblNm = "requestor_business";
			 }

		   // close stmt
            try{ if(rs != null) rs.close(); }catch(Exception e1){e1.printStackTrace();}
		    try{ if(ps != null) ps.close(); }catch(Exception e1){e1.printStackTrace();}

	         //Get evluator id value
	        sql = " SELECT	appseqno FROM " + tblNm + " WHERE	request_id = ?  and requestor_type_id = 0";

              //Prepare statement to execute
        	 ps = con.prepareStatement(sql);

        	//Set param values
       		ps.setInt(1, request_id);

       		 //Execute statement
        	 rs = ps.executeQuery();

        	//Get values
	    if (rs.next()) {
             i_ret_success =  rs.getInt("appseqno");
            }

        } else {
          // close stmt
          try{ if(rs != null) rs.close(); }catch(Exception e1){e1.printStackTrace();}
		  try{ if(ps != null) ps.close(); }catch(Exception e1){e1.printStackTrace();}
          log.FmtAndLogMsg("Error in getASN method:  app not found");
          return i_ret_success;
        }

        // close stmt
        try{ if(rs != null) rs.close(); }catch(Exception e1){e1.printStackTrace();}
		try{ if(ps != null) ps.close(); }catch(Exception e1){e1.printStackTrace();}



  } catch (Exception ex) {
    try {
      try{ if(rs != null) rs.close(); }catch(Exception e1){e1.printStackTrace();}
      try{ if(ps != null) ps.close(); }catch(Exception e1){e1.printStackTrace();}
    } catch (Exception e1) {}
   log.FmtAndLogMsg("Error in getASN method:  ", ex);
  } finally {
      try{ if(rs != null) rs.close(); }catch(Exception e1){e1.printStackTrace();}
	  try{ if(ps != null) ps.close(); }catch(Exception e1){e1.printStackTrace();}
      try {
        if (!b_otherConnection && b_clsConnectionlocal && con != null)  {
          con.close();
          if (s_i_debug_memory == 1) { 
                 log.FmtAndLogMsg("FEE:getASN:CLOSE");
 }

        }
      } catch (Exception e) {
        log.FmtAndLogMsg("Error in getASN method:  ", e);
      }
    }
    return i_ret_success;
 }
}
