package com.cmsinc.origenate.anb.persistence;

import java.io.Serializable;
import java.sql.Date;

import com.cmsinc.origenate.evaluator.persistence.Evaluator;
import com.cmsinc.origenate.util.persistence.BaseDataObject;

/**
 * @hibernate.class table="CREDIT_REQ_ANB_SETUP"
 *
 */
public class CreditReqAnbSetup extends BaseDataObject {
	static final long serialVersionUID = 1L;

	private Integer requestId;
	private Evaluator evaluator;
	private Integer appseqno;
	
	private String branchTxt;
	private String chargeacctNum;
	private String classcodeTxt;
	private String collcodeTxt;
	private String dlrachNum;
	private String extacctTxt;
	private String extrouteNum;
	private String noteTxt;
	private String payoridTxt;
	private String portTxt;
	private String prodcodeTxt;
	private String promocodeTxt;
	private String purpcodeTxt;
	private String respcodeTxt;
	private String paycodeNum;


	private boolean readOnly;

	public CreditReqAnbSetup() {
	}

	public Serializable getPrimaryKey() {
		return this.requestId;
	}

	/**
	 * @hibernate.id column="request_id" generator-class="assigned"
	 */
	public Integer getId() {
		return this.requestId;
	}

	public void setId(Integer id) {
		this.requestId = id;
	}

	public Integer getRequestId() {
		return getId();
	}

	public void setRequestId(Integer requestId) {
		setId(requestId);
	}

	/**
	 * @hibernate.many-to-one column="evaluator_id" not-null="true" lazy="false"
	 */
	public Evaluator getEvaluator() {
		return evaluator;
	}

	public void setEvaluator(Evaluator e) {
		this.evaluator = e;
	}

	public Integer getEvaluatorId() {
		return evaluator.getId();
	}

	/**
	 * @hibernate.property column="appseqno"
	 */
	public Integer getAppseqno() {
		return this.appseqno;
	}

	public void setAppseqno(Integer appseqno) {
		this.appseqno = appseqno;
	}


	/**
	 * @hibernate.property column="branch_txt"
	 */
	public String getBranchTxt() {
		return this.branchTxt;
	}

	public void setBranchTxt(String brTxt) {
		this.branchTxt = brTxt;
	}	 

	/**
	 * @hibernate.property column="respcode_txt"
	 */
	public String getRespcodeTxt() {
		return this.respcodeTxt;
	}

	public void setRespcodeTxt(String respTxt) {
		this.respcodeTxt = respTxt;
	}		 
	 
	/**
	 * @hibernate.property column="classcode_txt"
	 */
	public String getClasscodeTxt() {
		return this.classcodeTxt;
	}

	public void setClasscodeTxt(String ccTxt) {
		this.classcodeTxt = ccTxt;
	}		 
	 
	/**
	 * @hibernate.property column="purpcode_txt"
	 */
	public String getPurpcodeTxt() {
		return this.purpcodeTxt;
	}

	public void setPurpcodeTxt(String pcTxt) {
		this.purpcodeTxt = pcTxt;
	}		 
	
	/**
	 * @hibernate.property column="port_txt"
	 */
	public String getPortTxt() {
		return this.portTxt;
	}

	public void setPortTxt(String pTxt) {
		this.portTxt = pTxt;
	}		
	 
	/**
	 * @hibernate.property column="prodcode_txt"
	 */
	public String getProdcodeTxt() {
		return this.prodcodeTxt;
	}

	public void setProdcodeTxt(String pcTxt) {
		this.prodcodeTxt = pcTxt;
	}	
	
	/**
	 * @hibernate.property column="collcode_txt"
	 */
	public String getCollcodeTxt() {
		return this.collcodeTxt;
	}

	public void setCollcodeTxt(String ccTxt) {
		this.collcodeTxt = ccTxt;
	}		
	
	/**
	 * @hibernate.property column="note_txt"
	 */
	public String getNoteTxt() {
		return this.noteTxt;
	}

	public void setNoteTxt(String nTxt) {
		this.noteTxt = nTxt;
	}		
	
	/**
	 * @hibernate.property column="paycode_num"
	 */
	public String getPaycodeNum() {
		return this.paycodeNum;
	}

	public void setPaycodeNum(String pcNum) {
		this.paycodeNum = pcNum;
	}		
	
	/**
	 * @hibernate.property column="extacct_txt"
	 */
	public String getExtacctTxt() {
		return this.extacctTxt;
	}

	public void setExtacctTxt(String eaTxt) {
		this.extacctTxt = eaTxt;
	}		
	
	/**
	 * @hibernate.property column="extroute_num"
	 */
	public String getExtrouteNum() {
		return this.extrouteNum;
	}

	public void setExtrouteNum(String erNum) {
		this.extrouteNum = erNum;
	}		
		 
	/**
	 * @hibernate.property column="chargeacct_num"
	 */
	public String getChargeacctNum() {
		return this.chargeacctNum;
	}

	public void setChargeacctNum(String caNum) {
		this.chargeacctNum = caNum;
	}	
	
	/**
	 * @hibernate.property column="payorid_txt"
	 */
	public String getPayoridTxt() {
		return this.payoridTxt;
	}

	public void setPayoridTxt(String piTxt) {
		this.payoridTxt = piTxt;
	}		
	
	/**
	 * @hibernate.property column="promocode_txt"
	 */
	public String getPromocodeTxt() {
		return this.promocodeTxt;
	}

	public void setPromocodeTxt(String pcTxt) {
		this.promocodeTxt = pcTxt;
	}	
	
	/**
	 * @hibernate.property column="dlrach_num"
	 */
	public String getDlrachNum() {
		return this.dlrachNum;
	}

	public void setDlrachNum(String daNum) {
		this.dlrachNum = daNum;
	}		
		
	public void setReadOnly(boolean status) {
		this.readOnly = status;
	}

	public boolean getReadOnly() {
		return readOnly;
	}
}