/*
 * RequestorAlert.java Created on May 12, 2003 Modified June 17, 2003 to add support for business apps
 */

package com.cmsinc.origenate.ae;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;

import com.cmsinc.origenate.event.CommentEvents;
import com.cmsinc.origenate.event.JournalEvents;
import com.cmsinc.origenate.util.COLEncrypt;
import com.cmsinc.origenate.util.ConnectionUtils;
import com.cmsinc.origenate.util.LogMsg;
import com.cmsinc.origenate.util.Query;
import com.cmsinc.origenate.util.SQLSecurity;
import com.cmsinc.origenate.util.SQLUpdate;

/**
 * 
 * @author brads
 * @version 1.0
 * 
 *          request_id - the application to perform the requestor alert check (currently fraud and rego)
 */
public class RequestorAlert extends Object {
	private static final String BORROWER_WATCH_TYPE = "1";
	private static final String SELLER_WATCH_TYPE = "2";

	private static final Integer ALERT_CATEGORY_WATCH = 3;

	private static final Integer MATCH_SSN = 1;
	private static final Integer MATCH_NAME = 2;
	private static final Integer MATCH_NAME_SSN = 3;
	private static final Integer MATCH_ADDRESS = 4;
	private static final Integer MATCH_PHONE = 5;
	private static final Integer MATCH_SELLER_NAME = 6;
	private static final Integer MATCH_SELLER_NAME_STATE = 7;
	private static final Integer MATCH_SELLER_PHONE = 8;

	private final LogMsg log = new LogMsg();

	private Connection conn;
	private String s_log_file = "";

	/**
	 * RequestorAlert Object - used to check application for possible fraud or rego matches
	 */

	// RequestorAlert constructor that creates its own db connection
	public RequestorAlert(String argHost, String argSid, String argUserName, String argPwd, String argLogName, String argPort, String tnsEntry)	throws Exception {
		s_log_file = argLogName;
		if (argLogName != null && argLogName.length() > 0)
			log.openLogFile(argLogName);

		// 150165 - use tns entry if present
		String conStr = "jdbc:oracle:thin:@";
		if (tnsEntry.equals("")) {
			conStr = conStr + argHost + ":" + argPort + ":" + argSid;
		} else {
			conStr = conStr + tnsEntry;
		}
		try {
			// Load Oracle driver
			DriverManager.registerDriver(new oracle.jdbc.OracleDriver());

			// Connect to the Oracle database
			this.conn = DriverManager.getConnection(conStr, argUserName, COLEncrypt.sDecrypt(argPwd));
		} catch (SQLException e) {
			if (s_log_file != null && s_log_file.length() > 0)
				log.FmtAndLogMsg("DEBUG MESSAGE: RequestorAlert.java RequestorAlert Constructor : Error problem with db connection in constructor " + getClass(), e);
			throw new Exception("Database connect error:" + e.toString(), e);
		}

	}

	// RequestorAlert constructor that allows a db connection to be passed
	public RequestorAlert(Connection argCon, String argLogName, String encryptionUserName) throws Exception {
		s_log_file = argLogName;
		
		if (argLogName != null && argLogName.length() > 0)
			log.openLogFile(argLogName);

		this.conn = argCon;
		if (this.conn == null) {
			if (s_log_file != null && s_log_file.length() > 0)
				log.FmtAndLogMsg("Error problem with db connection in constructor " + getClass());
			throw new Exception("Error invalid connection." + getClass());
		}
	}
	
	// No longer need encryption user name, overloading method for backwards compatibility
	public RequestorAlert(Connection argCon, String argLogName) throws Exception {
		this(argCon, argLogName, null);
	}

	public void cleanup() {
		try {
			conn.close();
		} catch (Exception ec) {
		}
		if (s_log_file.length() > 0) {
			try {
				log.closeLogFile();
			} catch (Exception e3) {
			}
		}
	}

	// requestorAlert method checks application for potential fraud and regulation o alerts and returns whether one was found or not
	public void requestorAlert(int request_id, int evaluator_id) throws Exception {
		int requestor_alert = -1;
		int seller_alert = -1;
		int business_alert = 0;
		boolean encryptionFlg = false;
		boolean same_alert;
		ArrayList<String> match_list = new ArrayList<String>();
		ArrayList<String> type_list = new ArrayList<String>();
		ArrayList<String> comment_list = new ArrayList<String>();
		String alert_match_comment = "";
		String seller_alert_match_comment = "";
		StringBuilder temp_builder1 = new StringBuilder("");
		StringBuilder seller_temp_builder1 = new StringBuilder("");
		ResultSet rs = null;
		ResultSet alert_rs = null;
		ResultSet alert_category_rs = null;
		ResultSet bus_rs = null;
		PreparedStatement stmt = null;
		PreparedStatement alert_stmt = null;
		PreparedStatement sellerStmt = null;
		ResultSet sellerRs = null;
		PreparedStatement alert_category_stmt = null;
		PreparedStatement bus_stmt = null;
		SQLUpdate update = new SQLUpdate();

		// make sure db connection is available
		if (conn != null) {
			try {
				HashMap<String, ArrayList<Integer>> allWatchList = getWatchListId(request_id, evaluator_id, conn);
				ArrayList<Integer> borrower = allWatchList.get(BORROWER_WATCH_TYPE);
				ArrayList<Integer> seller = allWatchList.get(SELLER_WATCH_TYPE);

				// Check If Encryption is on for this lender
				Query query = new Query(conn);
				query.prepareStatement("select 1 from config_encryption where evaluator_id = ? and ssn_flg = 1");
				query.setInt(1, evaluator_id);
				query.executePreparedQuery();
				if (query.next()) {
					encryptionFlg = true;
				}

				// retrieve all of the different alert categories to check
				String s_sql = "select alert_category_id, alert_name_txt, alert_description_txt, comment_event_id, journal_event_id "
						+ "from mstr_alert_category, mstr_journal_events, mstr_comment_events "
						+ "where alert_description_txt = journal_event_desc_txt and alert_description_txt = comment_event_desc_txt";
				alert_category_stmt = conn.prepareStatement(s_sql);
				alert_category_rs = alert_category_stmt.executeQuery();

				// create query to pull requestor info to cross reference against alert records (use case insensitive matches)
				// CL 156834 - dhavalt - Removed selecting address values from requestor_address table here
				// Instead we are selecting those values while comparing with Alert table.
				// I did this because we need to compare both current address and mailing address and below query will select 2 records (if current
				// address and mailing address are available), which creates problem while generating alert comment
				s_sql = "select distinct mrt.requestor_type_description_txt,r.requestor_id,r.entity_txt,lower(r.first_name_txt) as first_name_txt,substr(lower(r.middle_name_txt),1,1) as middle_initial_txt,lower(r.last_name_txt) as last_name_txt, lower(r.second_last_name_txt) as second_last_name_txt,r.suffix_id,r.soc_sec_num_txt,r.soc_sec_num_txt_enc,r.soc_sec_num_txt_hash,r.phone_number_txt as home_phone_txt,re.phone_number_txt as employer_phone_txt "
						+ "from mstr_requestor_type mrt,requestor r,requestor_employer re "
						+ "where mrt.requestor_type_id=r.requestor_type_id and r.request_id=? and re.request_id(+)=r.request_id and re.requestor_id(+)=r.requestor_id and re.current_employer_flg(+)=1";

				stmt = conn.prepareStatement(s_sql, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
				stmt.setInt(1, request_id);
				// stmt.setInt(2,request_id);
				rs = stmt.executeQuery();

				// check app type
				s_sql = "select personal_flg from credit_request where request_id = ?";
				query.prepareStatement(s_sql);
				query.setInt(1, request_id);
				query.executePreparedQuery();
				query.next();
				boolean isBusiness = query.getColValue("personal_flg", "1").equals("0");

				// if it is a business app, get business info: phone number and name
				if (isBusiness) {
					// get business phone and business name
					s_sql = "select phone_number_txt, lower(business_name_txt) as business_name, tax_id, requestor_id from requestor_business "
							+ "where request_id=?";
					bus_stmt = conn.prepareStatement(s_sql, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
					bus_stmt.setInt(1, request_id);
					bus_rs = bus_stmt.executeQuery();
				}

				// perform alert check for every alert category
				while (alert_category_rs.next()) {
					Integer alertCategoryId = alert_category_rs.getInt("alert_category_id");
					String alertDescription = alert_category_rs.getString("alert_description_txt");
					String alertName = alert_category_rs.getString("alert_name_txt");
					Integer alertJournalEvent = alert_category_rs.getInt("journal_event_id");
					Integer alertCommentEvent = alert_category_rs.getInt("comment_event_id");

					// for each requestor, check info against alert table data
					// note: we assume that all necessary info is present b/c of completion check, i.e. query returns at least 1 row
					while (rs.next()) {
						requestor_alert = 0;
						// log.FmtAndLogMsg("In query with description: "+rs.getString("first_name_txt"));

						String ssn = encryptionFlg ? rs.getString("soc_sec_num_txt_hash") : rs.getString("soc_sec_num_txt");
						String secondLastName = rs.getString("second_last_name_txt");
						Integer requestorId = rs.getInt("requestor_id");
						String requestorType = rs.getString("requestor_type_description_txt");
						String entity = rs.getString("entity_txt");
						String firstName = rs.getString("first_name_txt");
						String lastName = rs.getString("last_name_txt");
						String middleInitial = rs.getString("middle_initial_txt");
						String suffix = rs.getString("suffix_id");
						String homePhone = rs.getString("home_phone_txt");
						String employerPhone = rs.getString("employer_phone_txt");

						String ssnColumn = encryptionFlg ? "soc_sec_num_txt_hash" : "soc_sec_num_txt";

						// If we add more match methods, put them here in an else if block.
						// Currently, the default method of Method 1 is the else block below.

						String borrower_sql = "";
						if (borrower != null && borrower.size() > 0 && !alertCategoryId.equals(ALERT_CATEGORY_WATCH)) {
							// there are 4 types of checks: 1. address 2. name 3. ssn 4. phone
							// alerts must be EXACT matches (case insensitive), with the condition that if an alert column is null, it is skipped
							// and the rest of the data is matched for a potential hit (hence the nvls in the alert matching sql).
							// also, make sure that for the alert type we're checking, at least 1 data item exists (i.e. all nulls should not match)
							// if a match is found, update the requestor's corresponding flag, store a journal item, store a comment
							// system comments are in the form: '<alert category> <alert_id> <requestor> <type of match> <alert comment>'

							// 1. address - street number, name, and zipcode must match, street type and street extra must match if not
							// null...otherwise skip
							// note: street type and street extra not used because they are not required
							// city and state in alert table are for reference only
							// 2. name - first and last names must match, middle initial and suffix id must match if not null...otherwise skip
							// 3. ssn - check number against individual's unique identifier
							// 4. phone number - check alert number against home and employment
							// CL 156834 dhavalt - Added new condition of checking Mailing Address and Current Address
							if (borrower.contains(MATCH_ADDRESS)) {
								borrower_sql = "select alert_id, nvl(comment_txt,' ') as comment_txt, 'MAILING ADDRESS' as match_type "
										+ "from alert a1, requestor_address ra "
										+ "where a1.evaluator_id = ra.evaluator_id "
										+ "and a1.alert_category_id = ? "
										+ "and lower(a1.street_name_txt) = lower(ra.street_name_txt) "
										+ "and lower(a1.street_number_txt) = lower(ra.street_number_txt) "
										+ "and a1.zipcode_txt = ra.zipcode_txt "
										+ "and (a1.street_type_id is null or ra.street_type_id is null or lower(a1.street_type_id) = lower(ra.street_type_id)) "
										+ "and (a1.street_extra_txt is null or ra.apt_suite_box_txt is null or lower(a1.street_extra_txt) = lower(ra.apt_suite_box_txt))  "
										+ "and (a1.address2_txt is null or ra.address2_txt is null or lower(a1.address2_txt) = lower(ra.address2_txt)) "
										+ "and (a1.street_number_txt is not null or a1.street_name_txt is not null or a1.zipcode_txt is not null) "
										+ "and ra.request_id = ? "
										+ "and ra.evaluator_id = ? "
										+ "and ra.requestor_id = ? "
										+ "and ra.address_type_id = 4 "
										+ "and a1.active_flg=1 "
										+ " UNION "
										+ "select alert_id, nvl(comment_txt,' ') as comment_txt, 'CURRENT ADDRESS' as match_type "
										+ "from alert a1, requestor_address ra "
										+ "where a1.evaluator_id = ra.evaluator_id "
										+ "and a1.alert_category_id = ? "
										+ "and lower(a1.street_name_txt) = lower(ra.street_name_txt) "
										+ "and lower(a1.street_number_txt) = lower(ra.street_number_txt) "
										+ "and a1.zipcode_txt = ra.zipcode_txt "
										+ "and (a1.street_type_id is null or ra.street_type_id is null or lower(a1.street_type_id) = lower(ra.street_type_id)) "
										+ "and (a1.street_extra_txt is null or ra.apt_suite_box_txt is null or lower(a1.street_extra_txt) = lower(ra.apt_suite_box_txt))  "
										+ "and (a1.address2_txt is null or ra.address2_txt is null or lower(a1.address2_txt) = lower(ra.address2_txt)) "
										+ "and (a1.street_number_txt is not null or a1.street_name_txt is not null or a1.zipcode_txt is not null) "
										+ "and ra.request_id = ? " + "and ra.evaluator_id = ? " + "and ra.requestor_id = ? "
										+ "and ra.address_type_id = 0 " + "and a1.watch_type_id = " + BORROWER_WATCH_TYPE + " and a1.active_flg=1 ";

							}
							if (borrower.contains(MATCH_NAME)) {
								if (borrower_sql.trim().toLowerCase().endsWith("and a1.active_flg=1")) {
									borrower_sql += " UNION ";
								}
								borrower_sql += "select alert_id, nvl(comment_txt,' ') as comment_txt, 'NAME' as match_type "
										+ " from alert "
										+ " where evaluator_id = ? and alert_category_id = ? and watch_type_id = "
										+ BORROWER_WATCH_TYPE
										+ " and nvl(lower(first_name_txt), ?) = ? "
										+ " and nvl(lower(last_name_txt), ?) = ? and (middle_initial_txt is null or ? is null or lower(middle_initial_txt) = ?) "
										+ " and (suffix_id is null or ? is null or suffix_id = ?) and (first_name_txt is not null or last_name_txt is not null) and active_flg = 1 ";
								if (secondLastName != null) {
									borrower_sql += "and (nvl(lower(second_last_name_txt), ?) = ? or  second_last_name_txt is null) ";
								}
							}
							// else{
							// borrower_sql += "and second_last_name_txt is null ";
							// }
							if (borrower.contains(MATCH_SSN)) {
								if (borrower_sql.trim().toLowerCase().contains("select")) {
									borrower_sql += " UNION ";
								}
								borrower_sql += "select alert_id, nvl(comment_txt,' ') as comment_txt, 'SSN' as match_type "
										+ "from alert "
										+ "where evaluator_id = ? and alert_category_id = ? and " + ssnColumn + " = ? and active_flg = 1 and watch_type_id = "
										+ BORROWER_WATCH_TYPE;
							}
							if (borrower.contains(MATCH_PHONE)) {
								if (borrower_sql.trim().toLowerCase().contains("select")) {
									borrower_sql += " UNION ";
								}
								borrower_sql += "select alert_id, nvl(comment_txt,' ') as comment_txt, 'PHONE' as match_type "
										+ "from alert "
										+ "where evaluator_id = ? and alert_category_id = ? and (phone_number_txt = ? or phone_number_txt = ?) and active_flg = 1 and watch_type_id = "
										+ BORROWER_WATCH_TYPE;
							}
							if (borrower.contains(MATCH_NAME_SSN)) {
								if (borrower_sql.trim().toLowerCase().contains("select")) {
									borrower_sql += " UNION ";
								}
								borrower_sql += "select alert_id, nvl(comment_txt,' ') as comment_txt, 'SSN' as match_type "
										+ "from alert "
										+ "where evaluator_id = ? and alert_category_id = ? and " + ssnColumn + " = ? and active_flg = 1 and watch_type_id = "
										+ BORROWER_WATCH_TYPE
										+ " UNION "
										+ "select alert_id, nvl(comment_txt,' ') as comment_txt, 'NAME' as match_type "
										+ "from alert "
										+ "where evaluator_id = ? and alert_category_id = ? and watch_type_id = "
										+ BORROWER_WATCH_TYPE
										+ " and nvl(lower(first_name_txt), ?) = ? "
										+ "and nvl(lower(last_name_txt), ?) = ? and (middle_initial_txt is null or ? is null or lower(middle_initial_txt) = ?) "
										+ "and (suffix_id is null or ? is null or suffix_id = ?) and (first_name_txt is not null or last_name_txt is not null) "
										+ "and " + ssnColumn + " is null and active_flg = 1 ";
								if (secondLastName != null) {
									borrower_sql += " and (nvl(lower(second_last_name_txt), ?) = ? or second_last_name_txt is null) ";
								}
							}
						}

						// log.FmtAndLogMsg("Requestor alert check Query= " + borrower_sql);
						int stmtCounter = 1;
						if (borrower_sql != null && borrower_sql.trim().length() > 0) {
							alert_stmt = conn.prepareStatement(borrower_sql);
							if (borrower != null && borrower.size() > 0) {
								if (borrower.contains(MATCH_ADDRESS)) {
									// mailing address params
									alert_stmt.setInt(stmtCounter++, alertCategoryId);
									alert_stmt.setInt(stmtCounter++, request_id);
									alert_stmt.setInt(stmtCounter++, evaluator_id);
									alert_stmt.setInt(stmtCounter++, requestorId);
									// current address params
									alert_stmt.setInt(stmtCounter++, alertCategoryId);
									alert_stmt.setInt(stmtCounter++, request_id);
									alert_stmt.setInt(stmtCounter++, evaluator_id);
									alert_stmt.setInt(stmtCounter++, requestorId);
								}
								if (borrower.contains(MATCH_NAME)) {
									// name params
									alert_stmt.setInt(stmtCounter++, evaluator_id);
									alert_stmt.setInt(stmtCounter++, alertCategoryId);
									alert_stmt.setString(stmtCounter++, firstName);
									alert_stmt.setString(stmtCounter++, firstName);
									alert_stmt.setString(stmtCounter++, lastName);
									alert_stmt.setString(stmtCounter++, lastName);
									alert_stmt.setString(stmtCounter++, middleInitial);
									alert_stmt.setString(stmtCounter++, middleInitial);
									alert_stmt.setString(stmtCounter++, suffix);
									alert_stmt.setString(stmtCounter++, suffix);

									// int counter = 18;// CL163300 need to use a value in order to accurate set bind the values to the query now that
									// we
									// have a conditional statment
									if (secondLastName != null) {
										alert_stmt.setString(stmtCounter++, secondLastName);
										alert_stmt.setString(stmtCounter++, secondLastName);
										// counter = 20; // adjust the value of i so that regardless of whether or not secondLastName was null, the
										// counter
										// incrementation won't be effected.
									}
								}
								if (borrower.contains(MATCH_SSN)) {
									// ssn params
									alert_stmt.setInt(stmtCounter++, evaluator_id);
									alert_stmt.setInt(stmtCounter++, alertCategoryId);
									alert_stmt.setString(stmtCounter++, ssn);

								}
								if (borrower.contains(MATCH_PHONE)) {
									// phone params
									alert_stmt.setInt(stmtCounter++, evaluator_id);
									alert_stmt.setInt(stmtCounter++, alertCategoryId);
									alert_stmt.setString(stmtCounter++, homePhone);
									alert_stmt.setString(stmtCounter++, employerPhone);
								}
								if (borrower.contains(MATCH_NAME_SSN)) {
									// phone params
									alert_stmt.setInt(stmtCounter++, evaluator_id);
									alert_stmt.setInt(stmtCounter++, alertCategoryId);
									alert_stmt.setString(stmtCounter++, ssn);
									alert_stmt.setInt(stmtCounter++, evaluator_id);
									alert_stmt.setInt(stmtCounter++, alertCategoryId);
									alert_stmt.setString(stmtCounter++, firstName);
									alert_stmt.setString(stmtCounter++, firstName);
									alert_stmt.setString(stmtCounter++, lastName);
									alert_stmt.setString(stmtCounter++, lastName);
									alert_stmt.setString(stmtCounter++, middleInitial);
									alert_stmt.setString(stmtCounter++, middleInitial);
									alert_stmt.setString(stmtCounter++, suffix);
									alert_stmt.setString(stmtCounter++, suffix);
									if (secondLastName != null) {
										alert_stmt.setString(stmtCounter++, secondLastName);
										alert_stmt.setString(stmtCounter++, secondLastName);
									}


								}
							}

							alert_rs = alert_stmt.executeQuery();
							// if a match is found, format the system comment (multiple alerts will concatenate comments)
							while (alert_rs.next()) {
								requestor_alert = 1;

								String matchRecord = alertDescription + " Match "
										+ alert_rs.getInt("alert_id") + " " 
										+ requestorType + requestorId
										+ " (" + entity + ")";
								String typeRecord = " " + alert_rs.getString("match_type");
								String commentRecord = alert_rs.getString("comment_txt");

								if (match_list.isEmpty()) {
									match_list.add(matchRecord);
									type_list.add(typeRecord);
									comment_list.add(commentRecord);

								} else {
									same_alert = false;

									for (int i = 0; i < match_list.size(); i++) {
										if (match_list.get(i).toString().equals(matchRecord)) {
											type_list.set(i, type_list.get(i).toString() + "," + typeRecord);
											same_alert = true;
											break;
										}

										if (alert_match_comment.length() > 0 && 
												alert_match_comment.contains(match_list.get(i).toString())) {
											same_alert = true;
											match_list.remove(i);
											break;
										}
									}

									if (!same_alert) {
										match_list.add(matchRecord);
										type_list.add(typeRecord);
										comment_list.add(commentRecord);
									}
								}
							}

							try {
								alert_rs.close();
							} catch (Exception e1) {
							}
							try {
								alert_stmt.close();
							} catch (Exception e1) {
							}
							String colname = alertName + "_flg";

							if (requestor_alert == 1) {
								log.FmtAndLogMsg(String.format("RequestorAlert: %s detected... Setting %s in requestor to %s for requestor %s for request id %s", 
										alertName, colname, requestor_alert, requestorId, request_id));
							}

							// update requestor's corresponding flag on every alert check (in case he previously had a match and now does not)
							try{
								s_sql = "update requestor set " + SQLSecurity.sanitize(colname) + " = ? "
										+ "where request_id= ? and requestor_id= ? ";
							} catch (SQLException se){
								log.FmtAndLogMsg("RequestorAlert; Invalid characters in column name: " + colname);
							}

							/**
							 * OWASP TOP 10 2010 - A1 High SQL Injection
							 * TTP 324955 Security Remediation Fortify Scan
							 */
							//update_stmt = conn.prepareStatement(ESAPI.encoder().encodeForSQL( new OracleCodec(),s_sql.toString()));
							update.SetPreparedUpdateStatement(conn, s_sql);
							update.setInt(1, requestor_alert);
							update.setInt(2, request_id);
							update.setInt(3, requestorId);
							update.RunPreparedUpdateStatement();

							// move alerts into one string							
							for (int i = 0; i < match_list.size(); i++) {
								if (!alert_match_comment.contains(match_list.get(i).toString())) {
									temp_builder1.append(match_list.get(i).toString());
									temp_builder1.append(type_list.get(i).toString());
									temp_builder1.append(" ");
									temp_builder1.append(comment_list.get(i).toString());
									temp_builder1.append("; ");
								}
							}

							alert_match_comment = temp_builder1.toString();

							// clear arraylists
							match_list.clear();
							type_list.clear();
							comment_list.clear();
						}
					} // for each requestor


					String seller_sql = "select crf.seller_name_txt as NAME, crf.seller_state_id as STATE, crf.seller_phone_number_txt as PHONE_NUMBER_TXT "
							+ "from  credit_request_finance crf where crf.request_id = ? ";

					sellerStmt = conn.prepareStatement(seller_sql);
					sellerStmt.setInt(1, request_id);
					sellerRs = sellerStmt.executeQuery();
					while (sellerRs.next()) {
						seller_sql="";
						requestor_alert = -1;

						String sellerName = sellerRs.getString("NAME");
						String sellerState = sellerRs.getString("STATE");
						String sellerPhone = sellerRs.getString("PHONE_NUMBER_TXT");

						if (seller != null && seller.size() > 0 && alertCategoryId.equals(ALERT_CATEGORY_WATCH)) {
							if (seller.contains(MATCH_SELLER_NAME)) {
								seller_sql = "select alert_id, nvl(comment_txt,' ') as comment_txt, 'NAME' as match_type " + "from alert a1 "
										+ "where a1.evaluator_id = ? and a1.alert_category_id = ? and a1.watch_type_id = " + SELLER_WATCH_TYPE
										+ " and  nvl(lower(a1.seller_name_txt), ?) = lower(?) ";
							}
							if (seller.contains(MATCH_SELLER_NAME_STATE)) {
								if (seller_sql.contains("select")) {
									seller_sql += " UNION ";
								}
								seller_sql += "select alert_id, nvl(comment_txt,' ') as comment_txt, 'STATE' as match_type "
										+ "from alert  a1 "
										+ "where a1.evaluator_id = ? and a1.alert_category_id = ? and state_id = ? and active_flg = 1 and watch_type_id = "
										+ SELLER_WATCH_TYPE
										+ " and  nvl(lower(a1.seller_name_txt), ?) = lower(?) ";
							}
							if (seller.contains(MATCH_SELLER_PHONE)) {
								if (seller_sql.contains("select")) {
									seller_sql += " UNION ";
								}
								seller_sql += "select alert_id, nvl(comment_txt,' ') as comment_txt, 'PHONE' as match_type "
										+ "from alert a1 "
										+ "where evaluator_id = ? and alert_category_id = ? and phone_number_txt = ?  and active_flg = 1 and watch_type_id =  "
										+ SELLER_WATCH_TYPE;
							}
							// log.FmtAndLogMsg("Seller alert check Query= " + seller_sql);
							int stmtCounter = 1;
							alert_stmt = conn.prepareStatement(seller_sql);
							if (seller.contains(MATCH_SELLER_NAME)) {
								alert_stmt.setInt(stmtCounter++, evaluator_id);
								alert_stmt.setInt(stmtCounter++, alertCategoryId);
								alert_stmt.setString(stmtCounter++, sellerName);
								alert_stmt.setString(stmtCounter++, sellerName);

							}
							if (seller.contains(MATCH_SELLER_NAME_STATE)) {
								alert_stmt.setInt(stmtCounter++, evaluator_id);
								alert_stmt.setInt(stmtCounter++, alertCategoryId);
								alert_stmt.setString(stmtCounter++, sellerState);
								alert_stmt.setString(stmtCounter++, sellerName);
								alert_stmt.setString(stmtCounter++, sellerName);
							}
							if (seller.contains(MATCH_SELLER_PHONE)) {
								alert_stmt.setInt(stmtCounter++, evaluator_id);
								alert_stmt.setInt(stmtCounter++, alertCategoryId);
								alert_stmt.setString(stmtCounter++, sellerPhone);

							}

							alert_rs = alert_stmt.executeQuery();
							while (alert_rs.next()) {
								seller_alert = 1;

								String matchRecord = alertDescription + " Match " + alert_rs.getInt("alert_id")
								+ " " + sellerName + " " + sellerPhone + " " + sellerState;
								String typeRecord = " " + alert_rs.getString("match_type");
								String commentRecord = alert_rs.getString("comment_txt");

								if (match_list.isEmpty()) {
									match_list.add(matchRecord);
									type_list.add(typeRecord);
									comment_list.add(commentRecord);
									same_alert = true;
								} else {
									same_alert = false;
									for (int i = 0; i < match_list.size(); i++) {
										if (match_list.get(i).toString().equals(matchRecord)) {
											type_list.set(i, type_list.get(i).toString() + "," + typeRecord);
											same_alert = true;
											break;
										}
										if (seller_alert_match_comment.length() > 0
												&& seller_alert_match_comment.contains(match_list.get(i).toString())) {
											same_alert = true;
											match_list.remove(i);
											break;
										}
									}
								}

								if (!same_alert) {
									match_list.add(matchRecord);
									type_list.add(typeRecord);
									comment_list.add(commentRecord);
								}
							}
							try {
								alert_rs.close();
							} catch (Exception e1) {
							}
							try {
								alert_stmt.close();
							} catch (Exception e1) {
							}

							String colname2 = alertName + "_flg";

							if (seller_alert == 1) {
								log.FmtAndLogMsg(String.format("RequestorAlert: %s detected... Setting %s in credit_request_finance to %s for request id %s", 
										alertName, colname2, requestor_alert, request_id));
							}
							
							try{ 
								s_sql = "update credit_request_finance set " + SQLSecurity.sanitize(colname2) + " = ? "
										+ "where request_id= ? ";
							} catch (SQLException se){
								log.FmtAndLogMsg("RequestorAlert; Invalid characters in column name: " + colname2);
							}

							/**
							 * OWASP TOP 10 2010 - A1 High SQL Injection
							 * TTP 324955 Security Remediation Fortify Scan
							 */
							update.SetPreparedUpdateStatement(conn, s_sql);
							//update_stmt = conn.prepareStatement(ESAPI.encoder().encodeForSQL( new OracleCodec(),s_sql.toString()));

							update.setInt(1, seller_alert);
							update.setInt(2, request_id);
							update.RunPreparedUpdateStatement();

							for (int i = 0; i < match_list.size(); i++) {
								if (!seller_alert_match_comment.contains(match_list.get(i).toString())) {
									seller_temp_builder1.append(match_list.get(i).toString());
									seller_temp_builder1.append(type_list.get(i).toString());
									seller_temp_builder1.append(" ");
									seller_temp_builder1.append(comment_list.get(i).toString());
									seller_temp_builder1.append("; ");
								}
							}
							seller_alert_match_comment = seller_temp_builder1.toString();
							// clear arraylists
							match_list.clear();
							type_list.clear();
							comment_list.clear();
						}
					} // for each seller

					// if business
					if (isBusiness) {
						// if there is a record, then check against alert
						if (bus_rs.next()) {

							String phoneNumber = bus_rs.getString("phone_number_txt");
							String businessName = bus_rs.getString("business_name");
							String taxId = bus_rs.getString("tax_id");
							Integer requestorId = bus_rs.getInt("requestor_id");

							// if no requestors were found, set the flag to 0 because requestor_business record but no individual requestors is still
							// valid
							if (requestor_alert == -1)
								requestor_alert = 0;
							// 2. name - first name checks against business name
							// 4. phone number - check alert number against business number
							s_sql = "select alert_id, comment_txt, 'PHONE' as match_type "
									+ "from alert "
									+ "where evaluator_id = ? and alert_category_id = ? and phone_number_txt = ?"
									+ " UNION "
									+ "select alert_id, comment_txt, 'NAME' as match_type "
									+ "from alert "
									+ "where evaluator_id = ? and alert_category_id = ? and nvl(lower(first_name_txt), ?) = ? and first_name_txt is not null"
									+ " UNION " + " select alert_id, comment_txt, 'TAXID' as match_type " + " from alert "
									+ " where evaluator_id = ? and alert_category_id = ? and tax_id = ? ";
							try {
								alert_rs.close();
							} catch (Exception e1) {
							}
							try {
								alert_stmt.close();
							} catch (Exception e1) {
							}
							alert_stmt = conn.prepareStatement(s_sql);
							// set params
							alert_stmt.setInt(1, evaluator_id);
							alert_stmt.setInt(2, alertCategoryId);
							alert_stmt.setString(3, phoneNumber);
							alert_stmt.setInt(4, evaluator_id);
							alert_stmt.setInt(5, alertCategoryId);
							alert_stmt.setString(6, businessName);
							alert_stmt.setString(7, businessName);
							alert_stmt.setInt(8, evaluator_id);
							alert_stmt.setInt(9, alertCategoryId);
							alert_stmt.setString(10, taxId);
							alert_rs = alert_stmt.executeQuery();

							StringBuilder temp_builder2 = new StringBuilder(alert_match_comment);

							while (alert_rs.next()) {
								Integer alertId = alert_rs.getInt("alert_id");
								String matchType = alert_rs.getString("match_type");
								String comment = alert_rs.getString("comment_txt");

								temp_builder2.append(alertDescription);
								temp_builder2.append(" Match ");
								temp_builder2.append(alertId);
								temp_builder2.append(" Business");
								temp_builder2.append(requestorId);
								temp_builder2.append(" ");
								temp_builder2.append(matchType);
								temp_builder2.append(" ");
								temp_builder2.append(comment);
								temp_builder2.append("; ");

								requestor_alert = 1;
								business_alert = 1;
							}
							alert_match_comment = temp_builder2.toString();

							try {
								alert_rs.close();
							} catch (Exception e1) {
							}
							try {
								alert_stmt.close();
							} catch (Exception e1) {
							}

							// update business' corresponding flag on every alert check (in case he previously had a match and now does not)
							// note that business really only makes sense with fraud, rego is for people
							s_sql = "update requestor_business " + "set fraud_flg= ? " + "where request_id= ? ";

							update.SetPreparedUpdateStatement(conn, s_sql);
							update.setInt(1, business_alert);
							update.setInt(2, request_id);
							update.RunPreparedUpdateStatement();
						} // bus rec exists
						bus_rs.beforeFirst();

					} // business app

					if (requestor_alert > -1 || alert_match_comment.length() > 0) {
						// if there was any alert match on the app, record the journal entry and system comment
						if (alert_match_comment.length() == 0) {
							if (s_log_file != null && s_log_file.length() > 0)
								log.FmtAndLogMsg("No " + alertDescription + " match found for request_id="
										+ request_id + ", evaluator_id=" + evaluator_id);
						} else {
							if (s_log_file != null && s_log_file.length() > 0)
								log.FmtAndLogMsg(alertDescription + " match found for request_id=" + request_id
										+ ", evaluator_id=" + evaluator_id);

							try {
								JournalEvents je = new JournalEvents(conn, s_log_file);
								je.addJournal(request_id, alertJournalEvent,
										alertDescription + " Alert", "SYSTEM");
							} catch (Exception e) {
								if (s_log_file != null && s_log_file.length() > 0)
									log.FmtAndLogMsg("There was a problem creating the " + alertDescription
											+ " journal event: ", e);
								throw new Exception(e.toString(), e);
							}
							try {
								CommentEvents ce = new CommentEvents(conn, s_log_file);
								ce.addComment(request_id, alertCommentEvent,
										alertDescription + " Alert",
										alert_match_comment.substring(0, alert_match_comment.length() - 2), "SYSTEM", "", null);
							} catch (Exception e) {
								if (s_log_file != null && s_log_file.length() > 0)
									log.FmtAndLogMsg("There was a problem creating the " + alertDescription
											+ " system comment: ", e);
								throw new Exception(e.toString(), e);
							}
						}

						alert_match_comment = "";
						temp_builder1 = new StringBuilder("");
					}

					if (seller_alert > -1) {
						// if there was any alert match on the app, record the journal entry and system comment
						if (seller_alert_match_comment.length() == 0) {
							if (s_log_file != null && s_log_file.length() > 0)
								log.FmtAndLogMsg("No " + alertDescription + " match found for request_id="
										+ request_id + ", evaluator_id=" + evaluator_id);
						} else {
							if (s_log_file != null && s_log_file.length() > 0)
								log.FmtAndLogMsg(alertDescription + " match found for request_id=" + request_id
										+ ", evaluator_id=" + evaluator_id);

							try {
								JournalEvents je = new JournalEvents(conn, s_log_file);
								je.addJournal(request_id, alertJournalEvent,
										alertDescription + " Alert", "SYSTEM");
							} catch (Exception e) {
								if (s_log_file != null && s_log_file.length() > 0)
									log.FmtAndLogMsg("There was a problem creating the " + alertDescription
											+ " journal event: ", e);
								throw new Exception(e.toString(), e);
							}
							try {
								CommentEvents ce = new CommentEvents(conn, s_log_file);
								ce.addComment(request_id, alertCommentEvent,
										alertDescription + " Alert",
										seller_alert_match_comment.substring(0, seller_alert_match_comment.length() - 2), "SYSTEM", "", null);
							} catch (Exception e) {
								if (s_log_file != null && s_log_file.length() > 0)
									log.FmtAndLogMsg("There was a problem creating the " + alertDescription
											+ " system comment: ", e);
								throw new Exception(e.toString(), e);
							}
						}
					}
					// requestor info query returned no rows, throw an exception (that data is required)
					else {
						if (s_log_file != null && s_log_file.length() > 0)
							log.FmtAndLogMsg("Seller alert check failed because application information is incomplete for request_id=" + request_id);
						// throw new Exception("Incomplete application information");
					}

					// go to the beginning of the requestor info recordset for each category and set the comment back to null
					rs.beforeFirst();
					alert_match_comment = "";
					temp_builder1 = new StringBuilder("");
				} // for each alert category
			} catch (Exception e) {
				throw e;
			} finally {
				// make sure all cursors are closed
				ConnectionUtils.closeDBObjects(rs, alert_rs, alert_category_rs,
						bus_rs, stmt, alert_stmt, alert_category_stmt,
						bus_stmt);
			}
		} else {
			if (s_log_file != null && s_log_file.length() > 0)
				log.FmtAndLogMsg("Requestor alert check not performed because of no DB connection.");
			throw new Exception("DB connection does not exist");
		}
	}

	/**
	 * 
	 * @param request_id
	 * @param evaluator_id
	 * @param conn
	 * @return a map of all the configured watch or fraud or rego
	 * @throws SQLException
	 */
	private HashMap<String, ArrayList<Integer>> getWatchListId(int request_id, int evaluator_id, Connection conn) throws Exception {

		ArrayList<Integer> borrower = new ArrayList<Integer>();
		ArrayList<Integer> seller = new ArrayList<Integer>();
		HashMap<String, ArrayList<Integer>> allWatchList = new HashMap<String, ArrayList<Integer>>();
		String sql = "select alert_match_id, watch_type_id from config_watch_list_lookup where evaluator_id = ?  and product_id = (select max(product_id) from credit_request where request_id = ?)";
		Query query = new Query(conn);
		query.prepareStatement(sql);
		query.setInt(1, evaluator_id);
		query.setInt(2, request_id);
		query.executePreparedQuery();
		while (query.next()) {
			if (query.getColValue("watch_type_id","").equals(BORROWER_WATCH_TYPE)) {
				borrower.add(Integer.parseInt(query.getColValue("alert_match_id")));
			} else {
				seller.add(Integer.parseInt(query.getColValue("alert_match_id")));
			}
		}
		if (borrower.size() > 0) {
			allWatchList.put(BORROWER_WATCH_TYPE, borrower);
		}
		if (seller.size() > 0) {
			allWatchList.put(SELLER_WATCH_TYPE, seller);
		}

		return allWatchList;
	}
}
