package com.cmsinc.origenate.anb.persistence;

import java.math.BigDecimal;
import java.sql.Date;

import com.cmsinc.origenate.evaluator.persistence.Evaluator;
import com.cmsinc.origenate.util.persistence.BaseDAO;

public interface CreditReqAnbSetupDAO extends BaseDAO {
   /** Name of this bean in the Spring configuration. */
   static final String NAME = "creditReqAnbSetupDAO";

   CreditReqAnbSetup get(Integer requestID);

   /**
    * Creates a credit request
    */
   public CreditReqAnbSetup save(Integer requestId, Evaluator e, Integer appseqno, String branchTxt, String respcodeTxt,
                                 String classcodeTxt, String purpcodeTxt, String portTxt, String prodcodeTxt, String collcodeTxt, 
								 String noteTxt, String paycodeNum, String extacctTxt, String extrouteNum, String chargeacctNum, 
								 String payoridTxt, String promocodeTxt, String dlrachNum);							 

   void delete(Integer requestId, Integer evaluatorId);
}