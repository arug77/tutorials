#!/bin/sh
#
# sample call to task execution time calculation
# the args will need to be changed
#

INIFILE=C:/development/origenate/source/app/taskexecutiontimecalculation/config/taskExecutionTimeCalculation.ini
LOGFILE=C:/development/debug.log
CSVFILE=C:/development/origenate/source/app/taskexecutiontimecalculation/results/results.csv

TASK_EXECUTION_TIME_CALCULATION_ARGS="-i$INIFILE -l$LOGFILE -r$CSVFILE"
echo "java com.cmsinc.origenate.taskexecutiontimecalculation.TaskExecutionTimeCalculation $TASK_EXECUTION_TIME_CALCULATION_ARGS"
java com.cmsinc.origenate.taskexecutiontimecalculation.TaskExecutionTimeCalculation $TASK_EXECUTION_TIME_CALCULATION_ARGS