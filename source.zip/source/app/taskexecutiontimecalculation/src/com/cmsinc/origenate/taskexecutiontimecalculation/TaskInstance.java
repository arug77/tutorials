package com.cmsinc.origenate.taskexecutiontimecalculation;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;

public class TaskInstance implements TaskReqIdProvider, Comparable<TaskInstance> {
	private int mReqId;
	private long mStartTimestamp;	// milliseconds
	private long mEndTimestamp;		// milliseconds
	private long mExecutionTime;	// milliseconds
	
	/**
	 * Represents a single task from a log
	 * 
	 * @param pReqID
	 * @param pStartTimestamp
	 */
	public TaskInstance(int pReqID, String pStartDate, String pStartDateFormat) {
		// only create a new task with start timestamp after start regex pattern matched
		// end timestamp will be set when end regex pattern matched
		mReqId = pReqID;
		mStartTimestamp = convertDateToMillis(pStartDate, pStartDateFormat);
		mExecutionTime = 0;
	}
	
	public long convertDateToMillis(String pDate, String pDateFormat) {
		SimpleDateFormat dateFormat = new SimpleDateFormat(pDateFormat);
		Calendar calendar = Calendar.getInstance();
		try {
			calendar.setTime(dateFormat.parse(pDate));
		} catch (ParseException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		// UTC time since epoch
//		System.out.println(calendar.getTimeInMillis());
		return calendar.getTimeInMillis();
	}
	
	@Override
	public int getReqId() {
		return mReqId;
	}
	
	public long getStartTimestamp() {
		return mStartTimestamp;
	}
	
	public long getEndTimestamp() {
		return mEndTimestamp;
	}
	
	public void setEndTimestamp(String pDate, String pDateFormat) {
		mEndTimestamp = convertDateToMillis(pDate, pDateFormat);
		mExecutionTime = mEndTimestamp - mStartTimestamp;
	}
	
	public long getExecutionTime() {
		return mExecutionTime;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + mReqId;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		TaskInstance other = (TaskInstance) obj;
		if (mReqId != other.mReqId)
			return false;
		return true;
	}

	@Override
	public int compareTo(TaskInstance o) {
		if(o.getReqId() < mReqId) {
			return -1;
		}
		
		if(o.getReqId() > mReqId) {
			return 1;
		}
		
		return 0;
	}
	
	@Override
	public String toString() {
		StringBuilder strBuilder = new StringBuilder();
		if(mExecutionTime == 0) {
			strBuilder.append("Request ID: " + mReqId + "\n");
		} else {
			strBuilder.append("Request ID: " + mReqId + "\t");
			strBuilder.append("Execution Time (ms): " + mExecutionTime + "\n");
		}
		
		return strBuilder.toString();
	}
}