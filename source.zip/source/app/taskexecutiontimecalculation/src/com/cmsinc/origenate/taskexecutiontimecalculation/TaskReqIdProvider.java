package com.cmsinc.origenate.taskexecutiontimecalculation;

/**
*  
*/
public interface TaskReqIdProvider {
	public int getReqId();
}
