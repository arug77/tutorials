package com.cmsinc.origenate.taskexecutiontimecalculation;

import java.util.Comparator;

/**
* 
*/
public class TaskReqIdComparator implements Comparator<TaskReqIdProvider> {

	@Override
	public int compare(TaskReqIdProvider pTask1, TaskReqIdProvider pTask2) {
		if(pTask1.getReqId() < pTask2.getReqId()) {
			return -1;
		}
		
		if(pTask1.getReqId() > pTask2.getReqId()) {
			return 1;
		}
		
		return 0;
	}

}
