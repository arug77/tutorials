package com.cmsinc.origenate.taskexecutiontimecalculation;

public class Task {
	private String mName;
	private String mStartRegex;
	private int mStartNameGroup;
	private int mStartDateGroup;
	private String mStartDateFormat;
	private int mStartRequestId;
	private int mStartBeginGroup;
	
	private String mEndRegex;
	private int mEndNameGroup;
	private int mEndDateGroup;
	private String mEndDateFormat;
	private int mEndRequestId;
	private int mEndBeginGroup;
	
	/** 
	 *  
	 * 
	 */
	public Task() {}	
	
	public void setName(String pName) {
		mName = pName;
	}
	
	public String getName() {
		return mName;
	}
	
	public void setStartRegex(String pStartRegex) {
		mStartRegex = pStartRegex;
	}
	
	public String getStartRegex() {
		return mStartRegex;
	}
	
	public void setStartNameGroup(int pStartNameGroup) {
		mStartNameGroup = pStartNameGroup;
	}
	
	public int getStartNameGroup() {
		return mStartNameGroup;
	}
	
	public void setStartDateGroup(int pStartDateGroup) {
		mStartDateGroup = pStartDateGroup;
	}
	
	public int getStartDateGroup() {
		return mStartDateGroup;
	}
	
	public void setStartDateFormat(String pStartDateFormat) {
		mStartDateFormat = pStartDateFormat;
	}
	
	public String getStartDateFormat() {
		return mStartDateFormat;
	}
	
	public void setStartRequestId(int pStartRequestId) {
		mStartRequestId = pStartRequestId;
	}
	
	public int getStartRequestId() {
		return mStartRequestId;
	}
	
	public void setStartBeginGroup(int pStartBeginGroup) {
		mStartBeginGroup = pStartBeginGroup;
	}
	
	public int getStartBeginGroup() {
		return mStartBeginGroup;
	}
	
	public void setEndRegex(String pEndRegex) {
		mEndRegex = pEndRegex;
	}
	
	public String getEndRegex() {
		return mEndRegex;
	}
	
	public void setEndNameGroup(int pEndNameGroup) {
		mEndNameGroup = pEndNameGroup;
	}
	
	public int getEndNameGroup() {
		return mEndNameGroup;
	}
	
	public void setEndDateGroup(int pEndDateGroup) {
		mEndDateGroup = pEndDateGroup;
	}
	
	public int getEndDateGroup() {
		return mEndDateGroup;
	}
	
	public void setEndDateFormat(String pEndDateFormat) {
		mEndDateFormat = pEndDateFormat;
	}
	
	public String getEndDateFormat() {
		return mEndDateFormat;
	}
	
	public void setEndRequestId(int pEndRequestId) {
		mEndRequestId = pEndRequestId;
	}
	
	public int getEndRequestId() {
		return mEndRequestId;
	}
	
	public void setEndBeginGroup(int pEndBeginGroup) {
		mEndBeginGroup = pEndBeginGroup;
	}
	
	public int getEndBeginGroup() {
		return mEndBeginGroup;
	}
	
	@Override
	public String toString() {
		StringBuilder strBuilder = new StringBuilder();
		strBuilder.append(mName);
		strBuilder.append("\n\t" + "start regex: " + mStartRegex);
		strBuilder.append("\n\t" + "start name group: " + mStartNameGroup);
		strBuilder.append("\n\t" + "start date group: " + mStartDateGroup);
		strBuilder.append("\n\t" + "start date format: " + mStartDateFormat);
		strBuilder.append("\n\t" + "start request id: " + mStartRequestId);
		strBuilder.append("\n\t" + "start begin group: " + mStartBeginGroup);
		strBuilder.append("\n\t" + "end regex: " + mEndRegex);
		strBuilder.append("\n\t" + "end name group: " + mEndNameGroup);
		strBuilder.append("\n\t" + "end date group: " + mEndDateGroup);
		strBuilder.append("\n\t" + "end date format: " + mEndDateFormat);
		strBuilder.append("\n\t" + "end request id: " + mEndRequestId);
		strBuilder.append("\n\t" + "end begin group: " + mEndBeginGroup);
		
		return strBuilder.toString();
	}
}
