package com.cmsinc.origenate.taskexecutiontimecalculation;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Map.Entry;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;
import com.cmsinc.origenate.util.OWASPSecurity;

/**
* The <code>TaskExecutionTimeCalculation</code> class reads a log file, searches for patterns which 
* match given regular expressions, and calculates the maximum, minimum, average, and standard deviation 
* of execution times for any number of tasks provided in the INI file.
* 
*/
public class TaskExecutionTimeCalculation {
	private Matcher mMatcher;
	private List<Task> mTaskList;	// list of tasks properties retrieved from INI file
	private Map<Task, List<TaskInstance>> mTaskMap;	// map of tasks vs. task instances list
	private Map<Task, HashMap<Integer, Integer>> mTaskRidOccurrenceMaps;	// map of tasks vs. [map of rid vs number of occurrences]
	private Map<Integer, Integer> mMasterRidMap;	// master map of rid vs. number of occurrences
	
	private TaskExecutionTimeCalculation(String pIniFilePath) {
		mTaskList = createTaskList(pIniFilePath);	
		mTaskMap = createTaskMap(mTaskList);
		mTaskRidOccurrenceMaps = createTaskRidOccurrenceMap(mTaskList);
		mMasterRidMap = new TreeMap<Integer, Integer>();
	}
	
	/**
	 * A method to create a list of <code>Task</code> objects taken from the INI file.
	 * @return list of TaskProperties
	 */
	public List<Task> createTaskList(String pIniFilePath) {
		String filePath = pIniFilePath;
		FileInputStream fis = null;		
		Properties iniProps = new Properties();
		
		// load in properties this way to have the key names
		try {
			fis = new FileInputStream(OWASPSecurity.validationCheck(filePath, OWASPSecurity.DIRANDFILE)); //TTP 324955 security remediation
			iniProps.load(fis);
		} catch(Exception e) {
			e.printStackTrace();
		} finally {
			if(fis != null) {
				try {
					fis.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
		
		// sort key names 
		Set<String> sortedProps = new TreeSet<String>(iniProps.stringPropertyNames());
		Iterator<String> iterator = sortedProps.iterator();
		iterator.next();	// [logs]
		iterator.next();	// [time calculations]

		List<Task> tasks = new ArrayList<Task>();
		int propsLength = sortedProps.size();
		for(int i = 0; i < (propsLength - 2) / 13; i++) {
			Task task = new Task();
			
			task.setEndBeginGroup(Integer.parseInt(iniProps.getProperty(iterator.next())));
			task.setEndDateFormat(iniProps.getProperty(iterator.next()));
			task.setEndDateGroup(Integer.parseInt(iniProps.getProperty(iterator.next())));
			task.setEndNameGroup(Integer.parseInt(iniProps.getProperty(iterator.next())));
			task.setEndRegex(iniProps.getProperty(iterator.next()));
			task.setEndRequestId(Integer.parseInt(iniProps.getProperty(iterator.next())));
			task.setName(iniProps.getProperty(iterator.next()));
			task.setStartBeginGroup(Integer.parseInt(iniProps.getProperty(iterator.next())));
			task.setStartDateFormat(iniProps.getProperty(iterator.next()));
			task.setStartDateGroup(Integer.parseInt(iniProps.getProperty(iterator.next())));
			task.setStartNameGroup(Integer.parseInt(iniProps.getProperty(iterator.next())));
			task.setStartRegex(iniProps.getProperty(iterator.next()));
			task.setStartRequestId(Integer.parseInt(iniProps.getProperty(iterator.next())));
			
			tasks.add(task);
		}
		return tasks;
	}
	
	/**
	 * A method to create a map where the keys are <code>Task</code> objects and the values are 
	 * <code>List</code>s of <code>TaskInstance</code> objects. This map will be used to keep track
	 * of every single task occurrence and its attributes (see {@link Task}).
	 * 
	 * @param pTaskPropsHolders
	 * @return a map of task instance lists [ HashMap(<TaskPropsHolder, List<TaskInstance>) ]
	 */
	public Map<Task, List<TaskInstance>> createTaskMap(List<Task> pTaskList) {
		HashMap<Task, List<TaskInstance>> taskMap = new HashMap<Task, List<TaskInstance>>();
		for(Task task : pTaskList) {
			taskMap.put(task, new ArrayList<TaskInstance>());
		}
		return taskMap;
	}
	
	/**
	* A method to create a map where the keys are <code>Task</code> objects and the values are
	* <code>HashMap</code>s of <code>Integer</code>-<code>Integer</code> key-value pairs. This
	* map will be used to keep track of how many times a task occurs for each request ID which
	* will be needed to print to the CSV result file.
	* 
	* @param pTaskList
	* @return a map of 
	*/
	public Map<Task, HashMap<Integer, Integer>> createTaskRidOccurrenceMap(List<Task> pTaskList) {
		Map<Task, HashMap<Integer, Integer>> taskRidOccurrenceMap = new HashMap<Task, HashMap<Integer, Integer>>();
		for(Task task : pTaskList) {
			taskRidOccurrenceMap.put(task, new HashMap<Integer, Integer>());
		}
		return taskRidOccurrenceMap;
	}
	
	/**
	 * A method to read a given log and create <code>TaskInstance</code> objects when a  
	 * <code>Task</code>'s start_regex pattern is matched. When an end_regex pattern is
	 * matched, this method fills in the end time of the task instance with the  
	 * associated start timestamp and request Id.
	 * 
	 * @param pFileName
	 */	
	public void readLog(String pFileName) {
		FileInputStream fis = null;
		BufferedReader reader = null;
		
		try {
			fis = new FileInputStream(OWASPSecurity.validationCheck(pFileName, OWASPSecurity.DIRANDFILE));//TTP 324955 security remediation
	
			reader = new BufferedReader(new InputStreamReader(fis));
			
			String line = reader.readLine();
            while(line != null) {  
            	if(line.contains("RID=") || line.contains("rid=")) {
	            	for(Task task : mTaskList) {
	            		// check if this line matches any of the start regexes
	            		Pattern startPattern = Pattern.compile(task.getStartRegex());
	            		mMatcher = startPattern.matcher(line);
	            		if(mMatcher.find()) {
	            			try {
	            				int requestId = Integer.parseInt(mMatcher.group(task.getStartRequestId()));
	                    		String startDate = mMatcher.group(task.getStartDateGroup());
	                    		String startDateFormat = task.getStartDateFormat();
	                    		
	                    		// create new task using information from line
	                    		TaskInstance taskInstance = new TaskInstance(requestId, startDate, startDateFormat);
	                    		
	                    		// add task to appropriate collection
	                    		mTaskMap.get(task).add(taskInstance);
	                    		
	                    		Map<Integer, Integer> taskRidOccurrenceMap = mTaskRidOccurrenceMaps.get(task);	                    		
	                    		// increment number of occurrences in this taskRidOccurrenceMap if the request id is already there
	                    		if(taskRidOccurrenceMap.keySet().contains(requestId)) {
	                    			taskRidOccurrenceMap.put(requestId, taskRidOccurrenceMap.get(requestId) + 1);
	                    		} else {
	                    			taskRidOccurrenceMap.put(requestId, 1);
	                    		}
	                    		
	                    		// add this request id to master Rid map if it is not already there
	                    		if(!mMasterRidMap.containsKey(requestId)) {
	                    			mMasterRidMap.put(requestId, 1);
	                    		}
	            			} catch(RuntimeException ex) {
	            				System.out.println("Something may have went wrong with creating a new task.");
	            				ex.printStackTrace();
	            			} catch(Exception ex) {
	            				System.out.println("Something may have went wrong with creating a new task.");
	            				ex.printStackTrace();
	            			}
	            		}
	            		
	            		// check if this line matches any of the end regexes
	            		Pattern endPattern = Pattern.compile(task.getEndRegex());
	            		mMatcher = endPattern.matcher(line);
	            		
	            		if(mMatcher.find()) {
	            			try {
	            				int requestId = Integer.parseInt(mMatcher.group(task.getEndRequestId()));
	                    		String endDate = mMatcher.group(task.getEndDateGroup());
	                    		String endDateFormat = task.getEndDateFormat();	                    		
	                    		
	                    		List<TaskInstance> taskList = mTaskMap.get(task);		// get appropriate list 
	                    		int index = findTaskInstanceIndexByReqId(taskList, requestId);	// find task with same req id that does not already have an end timestamp
	                    		
	                    		// add end timestamp to task object with same request id that does not already have an end timestamp	                    		
	                    		while(taskList.get(index).getEndTimestamp() != 0 && taskList.get(index).getReqId() == requestId) {
	                    			index++;
	                    		}	                    		
	                    		taskList.get(index).setEndTimestamp(endDate, endDateFormat);
	            			} catch(RuntimeException ex) {
	            				System.out.println("Something may have went wrong with finding the correct task.");
	            				ex.printStackTrace();
	            			} catch(Exception ex) {
	            				System.out.println("Something may have went wrong with finding the correct task.");
	            				ex.printStackTrace();
	            			}
	            		}
	            	}
            	}
            	line = reader.readLine();
            }
		} catch (FileNotFoundException ex) {
			  ex.printStackTrace();
		} catch (IOException ex) {
        	  ex.printStackTrace();
		} catch (Exception ex){
			ex.printStackTrace();
	    } finally {
	    	try {
	    		reader.close();
                fis.close();
	    	} catch (IOException ex) {
                ex.printStackTrace();
            }
        }
		
		// print tasks and various metrics
		// for(Task task : mTaskList) {
		// 	System.out.println("Task Name: " + task.getName());
		// 	System.out.println("Minimum Execution Time (ms): " + getMinimumExecutionTime(mTaskMap.get(task)));
		// 	System.out.println("Average Execution Time (ms): " + calculateAverageExecutionTime(mTaskMap.get(task)));
		// 	System.out.println("Standard Deviation: " + calculateStandardDeviation(mTaskMap.get(task)));
		// 	System.out.println("Number of TaskInstance objects created: " + mTaskMap.get(task).size());
//			System.out.println("Task Request Id Occurrence Map: " + mTaskRidOccurrenceMaps.get(task));
//			System.out.println("Task Instance Map: " + mTaskMap.get(task));
		// }
	}
	
	/**
	* A method to return the key to which the specified value is mapped.
	* 
	* @param pMap 
	* @param pValue
	* @return the key to which the specified value is mapped or null if this map contains no mapping for the value
	*/
	public static <T, E> T getKeyByValue(Map<T, E> pMap, E pValue) {
	    for (Entry<T, E> entry : pMap.entrySet()) {
	        if (pValue.equals(entry.getValue())) {
	            return entry.getKey();
	        }
	    }
	    return null;
	}

	/**
	 * 
	 * @param pTaskInstances
	 * @return maximum execution time from a list of <code>TaskInstance</code>s
	 */
	public long getMaximumExecutionTime(List<TaskInstance> pTaskInstances) {
		float max = Float.MIN_VALUE;
	    int index = -1;
	    for (int i = 0; i < pTaskInstances.size(); i++) {
	        Float f = (float) pTaskInstances.get(i).getExecutionTime();
	        if (Float.compare(f.floatValue(), max) > 0) {
	            max = f.floatValue();
	            index = i;
	        }
	    }
	    return pTaskInstances.get(index).getExecutionTime();
	}
	
	/**
	 * 
	 * @param pTaskInstances
	 * @return minimum execution time from a list of <code>TaskInstance</code>s
	 */
	public long getMinimumExecutionTime(List<TaskInstance> pTaskInstances) {
	    float min = Float.MAX_VALUE;
	    int index = -1;
	    for (int i = 0; i < pTaskInstances.size(); i++) {
	        Float f = (float) pTaskInstances.get(i).getExecutionTime();
	        if (Float.compare(f.floatValue(), min) < 0) {
	            min = f.floatValue();
	            index = i;
	        }
	    }	    
	    return pTaskInstances.get(index).getExecutionTime();
	}
	
	/**
	 * A method to get the index of a task instance of a given request id. This method uses
	 * binary search and is used to populate the end time of a task instance.
	 * 
	 * @param pTaskInstances, pReqId
	 * @return index of a <code>TaskInstance</code> with the given request id
	 */
	public int findTaskInstanceIndexByReqId(List<TaskInstance> pTaskInstances, final int pReqId) {
		TaskReqIdComparator taskReqIdComparator = new TaskReqIdComparator();
		// sort list in order to perform binary search;
		Collections.sort(pTaskInstances, taskReqIdComparator);
		return Collections.binarySearch(pTaskInstances, new TaskReqIdProvider() {
			public int getReqId() {
				return pReqId;
			}
		},
		taskReqIdComparator);
	}
	
	/**
	 * A method to get the index of a <code>TaskInstance</code> of a given request id. This 
	 * method does not use binary search and is used primarily for printing to the result 
	 * CSV file.
	 * 
	 * @param pTaskInstances, pReqId, pRandom
	 * @return index of a task instance with the given request id
	 */
	public int findTaskInstanceIndexByReqId(List<TaskInstance> pTaskInstances, int pReqId, boolean pRandom) {
		int index = 0;
		for(TaskInstance taskInstance : pTaskInstances) {
			if(taskInstance.getReqId() == pReqId) {
				break;
			} else {
				index++;
			}
		}
		return index;
	}
	
	/**
	 * A method to calculate the average execution time of a list of <code>TaskInstance</code>s.
	 * 
	 * @param pTaskInstances, pReqId
	 * @return average execution time for a task
	 */
	public double calculateAverageExecutionTime(List<TaskInstance> pTaskInstances) {
		double sum = 0;
		for(TaskInstance taskInstance : pTaskInstances) {
			sum += taskInstance.getExecutionTime();
		}
		
		return sum / pTaskInstances.size();
	}
	
	/**
	 * A method to calculate the standard deviation of execution times of a list of <code>TaskInstance</code>s.
	 * 
	 * @param pTaskInstances
	 * @return standard deviation of execution time for a task
	 */
	public double calculateStandardDeviation(List<TaskInstance> pTaskInstances) {
		double average = calculateAverageExecutionTime(pTaskInstances);
		List<Double> differences = new ArrayList<Double>();
		// find difference from mean for each task instance
		for(TaskInstance taskInstance : pTaskInstances) {
			differences.add(taskInstance.getExecutionTime() - average);
		}
		
		List<Double> squares = new ArrayList<Double>();
		// square each difference
		for(Double difference : differences) {
			squares.add(difference * difference);
		}
		
		double sumSquares = 0;
		// sum squares
		for(Double square : squares) {
			sumSquares += square;
		}		
		// variance is average of the sum of squares
		double variance = sumSquares / squares.size();
		
		// standard deviation is square root of variance
		return Math.sqrt(variance);
	}
	
	/**
	 * A method to populate the values of the master request id occurrence map. This 
	 * will be used to print to the CSV result file.
	 */
	public void setMasterRidOccurrenceValues() {
		for(int requestId : mMasterRidMap.keySet()) {
			int occurrences = 1;
			// iterate through all task request id occurrence maps
			for(Map<Integer, Integer> taskRidOccurrenceMap : mTaskRidOccurrenceMaps.values()) {
				if(taskRidOccurrenceMap.containsKey(requestId)) {
					int taskRidOccurrence = taskRidOccurrenceMap.get(requestId);
					// master rid occurrence map value should be the same as the greatest value of the task request id occurrence maps
					if(taskRidOccurrence > occurrences) {
						occurrences = taskRidOccurrence;
						mMasterRidMap.put(requestId, occurrences);
					}
				}
			}
		}
	}

	/**
	 * A method to generate a CSV file of request Id vs. task instance. The minimum, maximum,
	 * average, and standard deviation of execution times for each task is also printed.
	 */
	public void generateCsvFiles(String pFileName){
		try {
			FileWriter writer = new FileWriter(OWASPSecurity.validationCheck(pFileName, OWASPSecurity.DIRANDFILE)); //TTP 324955 security remediation

			/*     Request Id	|	Task1	|	Task2	|	Task3	*/
			
			writer.append("Request Id");
			writer.append(',');
			
			// print tasks at the top
			for(Task task : mTaskList) {
				writer.append(task.getName() + " (ms)");
				writer.append(',');
			}			
			writer.append('\n');
			
			// prepare master rid occurrence list
			setMasterRidOccurrenceValues();
			
			for(int requestId : mMasterRidMap.keySet()) {
				// loop for number of times this requestId occurs (mMasterRidMap value)
				for(int i = 0; i < mMasterRidMap.get(requestId); i++) {
					writer.append(Integer.toString(requestId));
					writer.append(',');
					
					// print all task execution times on same row if it contains the request id, otherwise blank
					for(Task task : mTaskList) {
						Map<Integer, Integer> taskRidOccurrenceMap = mTaskRidOccurrenceMaps.get(task);
						List<TaskInstance> taskInstanceList = mTaskMap.get(task);
						
						if(taskRidOccurrenceMap.containsKey(requestId) && i < taskRidOccurrenceMap.get(requestId)) {
							int taskInstanceIndex = findTaskInstanceIndexByReqId(mTaskMap.get(task), requestId, true);
							writer.append(Long.toString(taskInstanceList.get(taskInstanceIndex + i).getExecutionTime()));
							writer.append(',');
						} else {
							writer.append(',');
						}
					}
					writer.append('\n');
				}
			}
			
			writer.append('\n');
			writer.append("Number of instances");
			writer.append(',');
			for(Task task : mTaskList) {
				writer.append(Integer.toString(mTaskMap.get(task).size()));
				writer.append(',');
			}

			writer.append('\n');
			writer.append("Minimum (ms)");
			writer.append(',');			
			for(Task task : mTaskList) {
				if(mTaskMap.get(task).size() != 0) {
					writer.append(Long.toString(getMinimumExecutionTime(mTaskMap.get(task))));				
				} else {
					writer.append("N/A");
				}
				writer.append(',');
			}

			writer.append('\n');
			writer.append("Maximum (ms)");
			writer.append(',');			
			for(Task task : mTaskList) {
				if(mTaskMap.get(task).size() != 0) {
					writer.append(Long.toString(getMaximumExecutionTime(mTaskMap.get(task))));				
				} else {
					writer.append("N/A");
				}
				writer.append(',');
			}			

			writer.append('\n');
			writer.append("Average (ms)");
			writer.append(',');
			for(Task task : mTaskList) {					
				if(mTaskMap.get(task).size() != 0) {
					writer.append(Double.toString(calculateAverageExecutionTime(mTaskMap.get(task))));				
				} else {
					writer.append("N/A");
				}
				writer.append(',');
			}

			writer.append('\n');
			writer.append("Standard Deviation (ms)");
			writer.append(',');
			for(Task task : mTaskList) {
				if(mTaskMap.get(task).size() != 0) {
					writer.append(Double.toString(calculateStandardDeviation(mTaskMap.get(task))));				
				} else {
					writer.append("N/A");
				}
				writer.append(',');
			}			
			
			writer.flush();
		    writer.close();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (Exception e){
			e.printStackTrace();
	    }		
	}

	/**
	*  
	* Main method which drives the application.
	*/
	public static void main(String[] args) {
		String iniFilePath = null;
		String csvFilePath = null;
		String logFilePath = null;

		if(args.length != 3) {
			System.out.println("You must provide 3 arguments for the INI file, CSV file, and log file.");
			System.exit(0);
		} else {
			for(int i = 0; i < 3; i++) {
				if(args[i].startsWith("-i")) {
					iniFilePath = args[i].substring(2);
				} else if(args[i].startsWith("-r")) {
					csvFilePath = args[i].substring(2);
				} else if(args[i].startsWith("-l")) {
					logFilePath = args[i].substring(2);
				} else {
					System.out.println("Please ensure your arguments follow this structure: -i<location of INI file> "
							+ "-r<location of result CSV file> + -l<location of log file>");
					System.exit(0);
				}
			}
			if(iniFilePath == null || csvFilePath == null || logFilePath == null) {
				System.out.println("Please ensure your arguments contain exactly one INI file location, one result file location, and one log file location.");
				System.exit(0);
			}
		}
		
		// start time
		long start = System.currentTimeMillis();
			
		TaskExecutionTimeCalculation app = new TaskExecutionTimeCalculation(iniFilePath);
		app.readLog(logFilePath);		 	
		app.generateCsvFiles(csvFilePath);	
		// System.out.println("iniFilePath: " + iniFilePath);
		// System.out.println("csvFilePath: " + csvFilePath);
		// System.out.println("logFilePath: " + logFilePath);
			
		// end time
		long end = System.currentTimeMillis();
		System.out.println("Execution time (ms): " + (end - start));
	}
}
