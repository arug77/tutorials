package com.cmsinc.origenate.tool;

import java.io.BufferedOutputStream;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.math.BigInteger;
import java.sql.Connection;
import java.sql.DriverManager;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.zip.GZIPOutputStream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import org.apache.commons.compress.archivers.tar.TarArchiveEntry;
import org.apache.commons.compress.archivers.tar.TarArchiveOutputStream;
import org.apache.commons.io.FileUtils;

import com.cmsinc.origenate.crypto.Crypto;
import com.cmsinc.origenate.crypto.CryptoFactory;
import com.cmsinc.origenate.doc.GenJob;
import com.cmsinc.origenate.util.ConnectionUtils;
import com.cmsinc.origenate.util.ExitCodeConstants;
import com.cmsinc.origenate.util.LogMsg;
import com.cmsinc.origenate.util.Query;
import com.cmsinc.origenate.util.SQLUpdate;
import com.cmsinc.origenate.util.OWASPSecurity;

public class EDW {
	private String dbName = "", transType = "", sContr = "", sTNSEntry = "", sUser = "",
		encryptionUser = "", sPass = "", evalClient = "", outputDir  = "", evaluatorID  = "",
		orData = "", startDate = "", endDate = "", zip = "", ftpHost = "",
		ftpUser = "", ftpPass = "", ftpDir = "", ftpKeyFile = "", locale = "", decrypt = "",
		numThreads = "", logFile = "", queryID = "", country = "", sConStr = "";

	private BigInteger cksum = null;
	private int cksumLen = -1, iNumThreads=0, retries = 0;
	private boolean decryptFlg = false, useControl = false, useControlDates = false;
	private long start=0, end=0, elapsed=0;
	private List<EDWThread> processThreads=null;
	private List<String> tables = null;
	private int tableNum = 0;
	private Connection conn = null;
	private LogMsg log_obj = null;
	private static java.lang.Object critsec = new java.lang.Object();

	public static void main(String[] args) {
		try {
			EDW EDW = new EDW();
			EDW.run(args);
		} catch (Exception e) {
			e.printStackTrace();
			System.exit(ExitCodeConstants.PROCESS_FAILURE);
		}
		System.exit(ExitCodeConstants.SUCCESS);
	}

	public EDW() {

	}

	private void run(String[] args) throws Exception {
		start = new java.util.Date().getTime();

		try {
			GetArgs(args);
		} catch (Exception e) {
			throw new Exception("Unable to initialize EDW Extract: "+e.toString(), e);
		}

		try {
			Query query = new Query(conn);

			// Load date range for incremental extracts
			if(transType.equals("INCR")) {
				loadIncrementalDateRange();

				// Log request ids for this incremental extract
				query.prepareStatement("select request_id from edw_extract where evaluator_id = ?");
				query.setInt(1, Integer.valueOf(evaluatorID));
				query.executePreparedQuery();

				log_obj.FmtAndLogMsg("--------- EDW_EXTRACT: request_ids COUNT: " + query.getRowCount() + "--------");
				log_obj.FmtAndLogMsg("--------- EDW_EXTRACT: request_ids BEGIN-------- ");

				while(query.next()){
					log_obj.FmtAndLogMsg(" " + query.getColValue("request_id"));
				}

				log_obj.FmtAndLogMsg("--------- EDW_EXTRACT: request_ids END---------- ");
			}

			// Get a list of tables configured for EDW
			String tableSelect = "";
			query.prepareStatement("select table_name from config_edw_tables where evaluator_id = ? and orig_eval_flg = ?");
			query.setInt(1, Integer.valueOf(evaluatorID));
			query.setInt(2, dbName.equals("ORIG")?0:1);
			query.executePreparedQuery();

			// We will check the list of retrieved tables against
			// this set of configured tables
			Set<String> configuredTabs = new HashSet<String>();
			while(query.next()) {
				configuredTabs.add(query.getColValue("table_name"));
			}


			// Get the list of tables to extract
			if(dbName.equals("ORIG") && transType.equals("FULL")) {
				tableSelect = "select tabs.table_name from tabs";
			} else if(dbName.equals("EVAL") && transType.equals("FULL")) {
				tableSelect = "select tabs.table_name from tabs";
			} else if(dbName.equals("ORIG") && transType.equals("INCR")) {
				tableSelect = "select tabs.table_name from tabs where tabs.table_name in (select table_name from user_tab_columns where column_name = 'REQUEST_ID') or tabs.table_name in ('CREDIT_REQ_DECISION_STIP','CREDIT_REQ_DECISION_REASONS','CREDIT_REQ_DECISIONS_PTIDTI')";
			} else if(dbName.equals("EVAL") && transType.equals("INCR")) {
				tableSelect = "select tabs.table_name from tabs where tabs.table_name in (select table_name from user_tab_columns where column_name = 'APPSEQNO')";
			} else if(dbName.equals("ORIG") && transType.equals("MNT")) {
				tableSelect = "select tabs.table_name from tabs where tabs.table_name not in (select table_name from user_tab_columns where column_name = 'REQUEST_ID') and tabs.table_name not in ('CREDIT_REQ_DECISION_STIP','CREDIT_REQ_DECISION_REASONS','CREDIT_REQ_DECISIONS_PTIDTI')";
			} else if(dbName.equals("EVAL") && transType.equals("MNT")) {
				tableSelect = "select tabs.table_name from tabs where tabs.table_name not in (select table_name from user_tab_columns where column_name = 'APPSEQNO')";
			}
			log_obj.FmtAndLogMsg("SELECT TABLE QUERY: "+tableSelect);

			query.prepareStatement(tableSelect);
			query.executePreparedQuery();

			// Get tables. If configurable tables are configured,
			// filter out any unconfigured tables.
			tables = new ArrayList<String>();
			String tableName = "";
			while(query.next()) {
				tableName = query.getColValue("table_name");
				if(!configuredTabs.isEmpty()) {
					if(configuredTabs.contains(tableName)) {
						tables.add(tableName);
					}
				} else {
					tables.add(tableName);
				}
			}

			int tableCnt = tables.size();

			if(tableCnt == 0) {
				log_obj.FmtAndLogMsg("NO TABLES FOUND TO EXTRACT");
				return;
			}

			// Process the tables in alphabetical order
			Collections.sort(tables);

			log_obj.FmtAndLogMsg("FOUND "+tableCnt+" TABLES TO EXTRACT");

			// If the number of tables is less than the number of threads,
			// then decrease the number of threads to match.
			iNumThreads = Integer.parseInt(numThreads);
			if(tableCnt < iNumThreads && tableCnt!=0) {
				iNumThreads = tableCnt;
			}
			log_obj.FmtAndLogMsg("THREAD SIZE: "+iNumThreads);

			processThreads = new ArrayList<EDWThread>();

			for(int currThread = 1; currThread <= iNumThreads; currThread++) {
				processThreads.add(
							new EDWThread(this,"THREAD"+currThread+"  ",
									sConStr, sUser, sPass,
									evaluatorID,dbName, transType, evalClient,
									outputDir,decryptFlg,
									encryptionUser,log_obj, retries));
			}

			ExecutorService threadExecutor = Executors.newCachedThreadPool();

			// start threads and place in runnable state

			log_obj.FmtAndLogMsg("Starting "+iNumThreads+" threads...");
			for (EDWThread t : processThreads) {
				threadExecutor.execute(t);
				try {Thread.sleep(2000);} catch (Exception e) {} // sleep 2 seconds
			}

			threadExecutor.shutdown(); // shutdown worker threads and exit

			while(true) {
				try {Thread.sleep(2000);} catch (Exception e) {} // sleep 2 seconds
				if (iNumThreads == 0) {
					break; // waiting for all threads to finish
				}
			}
			log_obj.FmtAndLogMsg("Finished extracting tables. Performing cleanup");

			cleanup();

			end = new java.util.Date().getTime();
			elapsed = end - start;
			log_obj.FmtAndLogMsg("\n\nExtraction Finished");
			log_obj.FmtAndLogMsg("Total Elapsed Time: "+((int)(elapsed/(60*60*1000F)) % 24)+ " Hr. "+((int)(elapsed/(60*1000F)) % 60)+" min. "+((int)(elapsed/1000F) % 60)+" sec.");
		} catch (Exception e) {
			// This is just a catch to allow us to print the basic exception to
			// the log. The entire stack trace gets printed to the console.
			log_obj.FmtAndLogMsg("Exception running EDW: " + e.toString(), e);
			throw e;
		} finally {
			ConnectionUtils.closeConnection(conn);
		}
	}

	private void GetArgs(String args[]) throws Exception {
        encryptionUser = "origenate";

		if(args.length > 0) {
			for(int i = 0; i < args.length; i++) {
				if((args[i].charAt(0) != '-') && (args[i].length() > 1)) {
					ShowUsage();
				}

				switch(args[i].charAt(1)) {

				case 'n': //numThreads
					numThreads = args[i].substring(2);
					break;

				case 's': //dbName
					dbName = args[i].substring(2);
					break;

				case 'T': //sTNSEntry
					sTNSEntry = args[i].substring(2);
					System.out.println("TNS Entry: "+sTNSEntry);
					break;

				case 't': //transType
					transType = args[i].substring(2);
					break;

				case 'c': //sContr
					sContr = args[i].substring(2);
					break;

				case 'u': //sUser
					sUser = args[i].substring(2);
					break;

				case 'p': //sPass
					sPass = args[i].substring(2);
					break;

				case 'C': //evalClient
					evalClient = args[i].substring(2);
					break;

				case 'd': //orData
					orData = args[i].substring(2);
					break;

				case 'e': //evaluator id
					evaluatorID = args[i].substring(2);
					break;

				case 'S': //start date
					startDate = args[i].substring(2);
					break;

				case 'E': //end date
					endDate = args[i].substring(2);
					break;

				case 'F': //decryptFlg
					decrypt = args[i].substring(2);
					if(decrypt.equalsIgnoreCase("true")) {
						decryptFlg = true;
					}
					break;

				case 'U': //usecontrol
					if(args[i].substring(2).equalsIgnoreCase("y")) {
						useControl = true;
					}
					break;

				case 'R': //useControlDates
					if(args[i].substring(2).equalsIgnoreCase("y")) {
						useControlDates = true;
					}
					break;

				case 'Z': //zip or tar
					zip = args[i].substring(2);
					break;

				case 'l': //logFile
					logFile = args[i].substring(2);
					break;

				case 'h': //ftpHost
					ftpHost = args[i].substring(2);
					break;

				case 'r': //ftpUser
					ftpUser = args[i].substring(2);
					break;

				case 'P': //ftpPass
					ftpPass = args[i].substring(2);
					break;

				case 'k': //ftpKeyFile
					ftpKeyFile = args[i].substring(2);
					break;

				case 'D': //ftpDir
					ftpDir = args[i].substring(2);
					break;

				case 'L': //locale
					locale = args[i].substring(2);
					break;

				case 'Y': //country
					country = args[i].substring(2);
					break;

				case 'q': //queryID
					queryID = args[i].substring(2);
					break;
					
				case 'f': // retries
					retries = Integer.valueOf(args[i].substring(2));
					break;

				default:
					ShowUsage();
					break;
				} // end case
			} // end for loop

			log_obj = new LogMsg();
			if(logFile != null && !logFile.equals("")) {
				log_obj.openLogFile(logFile);
			}

			checkRequiredArgs();

			if(numThreads.equals("")) {
				numThreads = "1";
			}

			if(locale.length() != 2) {
				locale = "en";
			}
			if(country.length() != 2) {
				country = "US";
			}
			Locale.setDefault(new Locale(locale, country));
			
			if(retries < 0) {
				retries = 0;
			}

			// Load Oracle driver
	        DriverManager.registerDriver (new oracle.jdbc.OracleDriver());

	        sConStr = "jdbc:oracle:thin:@";

			if (sTNSEntry.length() == 0) {
				sConStr = sConStr + sContr;
			}
			else {
				sConStr = sConStr + sTNSEntry;
				log_obj.FmtAndLogMsg("Using TNS Entry");
			}

			if(decryptFlg) {
				// PERFORMING DUMMY ENCRYPTION OPERATION, SO IN THREADS IT WON'T THROW ANY ERROR
				try {
					Crypto crypto =  CryptoFactory.getCrypto();
					crypto.encryptString("origenate","ssn","212715432");
				}catch(Exception e) { e.printStackTrace(); }

				// Decrypting passwords
				try {
					Crypto crypto = CryptoFactory.getCrypto();
					sPass = crypto.decryptString(encryptionUser,"password",sPass);
				} catch (Exception e) {
					log_obj.FmtAndLogMsg("Exception occurred decrypting password.", e);
					throw e;
				}
			}

			conn = DriverManager.getConnection(sConStr, sUser, sPass);

			outputDir = orData+"/edw/"+evalClient+"/"+transType+"/"+dbName;
		} // end if
		else {
			ShowUsage();
		}

    } // getArgs

	private void checkRequiredArgs() {
		if(dbName == null || dbName.equals("")) {
			log_obj.FmtAndLogMsg("-s argument is required. Exiting EDW.");
			ShowUsage();
		} else if(transType == null || transType.equals("")) {
			log_obj.FmtAndLogMsg("-t argument is required. Exiting EDW.");
			ShowUsage();
		} else if(sUser == null || sUser.equals("")) {
			log_obj.FmtAndLogMsg("-u argument is required. Exiting EDW.");
			ShowUsage();
		} else if(sPass == null || sPass.equals("")) {
			log_obj.FmtAndLogMsg("-p argument is required. Exiting EDW.");
			ShowUsage();
		} else if(evalClient == null || evalClient.equals("")) {
			log_obj.FmtAndLogMsg("-C argument is required. Exiting EDW.");
			ShowUsage();
		} else if(orData == null || orData.equals("")) {
			log_obj.FmtAndLogMsg("-d argument is required. Exiting EDW.");
			ShowUsage();
		} else if(evaluatorID == null || evaluatorID.equals("")) {
			log_obj.FmtAndLogMsg("-e argument is required. Exiting EDW.");
			ShowUsage();
		} else if((sTNSEntry == null || sTNSEntry.equals("")) &&
				(sContr == null || sContr.equals(""))) {
			log_obj.FmtAndLogMsg("-T OR -c argument is required. Exiting EDW.");
			ShowUsage();
		} else if(logFile == null || logFile.equals("")) {
			log_obj.FmtAndLogMsg("-l argument is recommended. All logging will be printed to SystemOut.");
		}
	}

	private void ShowUsage() {
		System.err.println("Usage: java EDWExtract -n<numThreads> -s<schemaName(ORIG/EVAL)> -t<transType(FULL/INCR/MNT)> " +
				"[-c<dbContr> or -T<sTNSEntry>] -u<dbUser> -p<dbPass> -C<evalClient(e.g.prodtest)> -d<ORData> " +
				"-e<evaluatorID> -F<decryptFlg(true/false)> -S<start MM/DD/YYYY> -E<end MM/DD/YYYY> -q<queryID> " +
				"-f<retry attempts> -U<use control file(y/n)> -R<use control file dates(y/n)> -Z<zip/tar> " +
				"-h<SFTP host or NONE> -r<SFTP user or NONE> -P<SFTP password or NONE> -k<SFTP key file or NONE> -D<SFTP remote directory or NONE> " +
				"-L<2 character locale code(default: en)> -Y<2 character country code(default: US)> -l<logFile>");
		System.exit(ExitCodeConstants.ARGUMENTS_ERROR);
	}

	/**
	 * Performs the cleanup after the text and trailer files are generated. This
	 * includes zipping or tarring the text and trailer files, deleting the text
	 * and trailer files, optionally generating a control file, and then optionally
	 * SFTP'ing the generated zip, tar, and control files to a remote server.
	 * @throws Exception If any of the cleanup steps fail
	 */
	private void cleanup() throws Exception {
		int txtCount = 0;
		String txtFileName = "";
		SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMdd");
		if(zip.equalsIgnoreCase("tar")) {
			txtFileName = transType+dbName+formatter.format(new java.util.Date())+".tar.gz";
			txtCount = tarFiles(txtFileName);
		} else {
			txtFileName = transType+dbName+formatter.format(new java.util.Date())+".zip";
			txtCount = zipFiles(txtFileName);
		}

		if(useControl) {
			generateControlFile(txtFileName, txtCount);
		}

		if(!ftpUser.equals("") && !ftpUser.equals("NONE") &&
				!ftpHost.equals("") && !ftpHost.equals("NONE") &&
				((!ftpPass.equals("") && !ftpPass.equals("NONE")) ||
					(!ftpKeyFile.equals("") && !ftpKeyFile.equals("NONE")))) {
			sftpFiles(txtFileName);
		}
	}

	/**
	 * Creates a file located in <i>orData</i>+"/edw/"+<i>evalClient</i> named
	 * <b>fileName</b>+".control", which consists of 2 lines in the following format:
	 * <br /><br /><i>
	 * StartDate EndDate FileCount
	 * <br />
	 * CheckSum ByteCount FileName
	 * </i><br /><br />
	 * If this is an incremental extract, the start and end date are retrieved
	 * from XREF_EVALUATOR_EXTRACT. Otherwise, they are set to UNKNOWN.
	 * @param fileName - The name of the zip or tar.gz file containing the text files
	 * @param txtCount - The number of text files in fileName
	 * @throws Exception If any of the steps in creating the control file fail
	 */
	private void generateControlFile(String fileName, int txtCount) throws Exception {
		BufferedWriter writer = null;
		try {
			String fileLocation = orData+"/edw/"+evalClient+"/"+fileName;
			generateChecksum(fileLocation);
			/**
			  * OWASP TOP 10 2010 - A4 Path Manipulation
			    * Changes to the below code to fix vulnerabilities
			    * TTP 324955
			    */
			//writer = new BufferedWriter(new FileWriter(orData+"/edw/"+evalClient+"/"+fileName+".control"));
			writer = new BufferedWriter(new FileWriter(OWASPSecurity.validationCheck(orData+"/edw/"+evalClient+"/"+fileName+".control", OWASPSecurity.DIRANDFILE)));
			String line = getControlFileDates() + " " + txtCount;
			line += "\n";
			line += cksum.toString() + " " + cksumLen + " " + fileName;
			line += "\n";
			writer.write(line);
			writer.close();
		} catch (Exception e) {
			throw new Exception("Exception generating control file: " + e.toString(), e);
		} finally {
			try{ if(writer != null) writer.close(); }catch(Exception e1){e1.printStackTrace();}
		}
	}

	/**
	 * Simulates the UNIX cksum command. Puts the checksum into
	 * the <i>cksum</i> instance var and the byte count into the
	 * <i>cksumLen</i> instance var.
	 * @param fileLocation - The full path to the file to run cksum on
	 * @throws Exception If the file specified by <b>fileLocation</b> does not exist
	 */
	private void generateChecksum(String fileLocation) throws Exception {
		int[] table = {
    			0x00000000, 0x04c11db7, 0x09823b6e, 0x0d4326d9,
    			0x130476dc, 0x17c56b6b, 0x1a864db2, 0x1e475005,
    			0x2608edb8, 0x22c9f00f, 0x2f8ad6d6, 0x2b4bcb61,
    			0x350c9b64, 0x31cd86d3, 0x3c8ea00a, 0x384fbdbd,
    			0x4c11db70, 0x48d0c6c7, 0x4593e01e, 0x4152fda9,
    			0x5f15adac, 0x5bd4b01b, 0x569796c2, 0x52568b75,
    			0x6a1936c8, 0x6ed82b7f, 0x639b0da6, 0x675a1011,
    			0x791d4014, 0x7ddc5da3, 0x709f7b7a, 0x745e66cd,
    			0x9823b6e0, 0x9ce2ab57, 0x91a18d8e, 0x95609039,
    			0x8b27c03c, 0x8fe6dd8b, 0x82a5fb52, 0x8664e6e5,
    			0xbe2b5b58, 0xbaea46ef, 0xb7a96036, 0xb3687d81,
    			0xad2f2d84, 0xa9ee3033, 0xa4ad16ea, 0xa06c0b5d,
    			0xd4326d90, 0xd0f37027, 0xddb056fe, 0xd9714b49,
    			0xc7361b4c, 0xc3f706fb, 0xceb42022, 0xca753d95,
    			0xf23a8028, 0xf6fb9d9f, 0xfbb8bb46, 0xff79a6f1,
    			0xe13ef6f4, 0xe5ffeb43, 0xe8bccd9a, 0xec7dd02d,
    			0x34867077, 0x30476dc0, 0x3d044b19, 0x39c556ae,
    			0x278206ab, 0x23431b1c, 0x2e003dc5, 0x2ac12072,
    			0x128e9dcf, 0x164f8078, 0x1b0ca6a1, 0x1fcdbb16,
    			0x018aeb13, 0x054bf6a4, 0x0808d07d, 0x0cc9cdca,
    			0x7897ab07, 0x7c56b6b0, 0x71159069, 0x75d48dde,
    			0x6b93dddb, 0x6f52c06c, 0x6211e6b5, 0x66d0fb02,
    			0x5e9f46bf, 0x5a5e5b08, 0x571d7dd1, 0x53dc6066,
    			0x4d9b3063, 0x495a2dd4, 0x44190b0d, 0x40d816ba,
    			0xaca5c697, 0xa864db20, 0xa527fdf9, 0xa1e6e04e,
    			0xbfa1b04b, 0xbb60adfc, 0xb6238b25, 0xb2e29692,
    			0x8aad2b2f, 0x8e6c3698, 0x832f1041, 0x87ee0df6,
    			0x99a95df3, 0x9d684044, 0x902b669d, 0x94ea7b2a,
    			0xe0b41de7, 0xe4750050, 0xe9362689, 0xedf73b3e,
    			0xf3b06b3b, 0xf771768c, 0xfa325055, 0xfef34de2,
    			0xc6bcf05f, 0xc27dede8, 0xcf3ecb31, 0xcbffd686,
    			0xd5b88683, 0xd1799b34, 0xdc3abded, 0xd8fba05a,
    			0x690ce0ee, 0x6dcdfd59, 0x608edb80, 0x644fc637,
    			0x7a089632, 0x7ec98b85, 0x738aad5c, 0x774bb0eb,
    			0x4f040d56, 0x4bc510e1, 0x46863638, 0x42472b8f,
    			0x5c007b8a, 0x58c1663d, 0x558240e4, 0x51435d53,
    			0x251d3b9e, 0x21dc2629, 0x2c9f00f0, 0x285e1d47,
    			0x36194d42, 0x32d850f5, 0x3f9b762c, 0x3b5a6b9b,
    			0x0315d626, 0x07d4cb91, 0x0a97ed48, 0x0e56f0ff,
    			0x1011a0fa, 0x14d0bd4d, 0x19939b94, 0x1d528623,
    			0xf12f560e, 0xf5ee4bb9, 0xf8ad6d60, 0xfc6c70d7,
    			0xe22b20d2, 0xe6ea3d65, 0xeba91bbc, 0xef68060b,
    			0xd727bbb6, 0xd3e6a601, 0xdea580d8, 0xda649d6f,
    			0xc423cd6a, 0xc0e2d0dd, 0xcda1f604, 0xc960ebb3,
    			0xbd3e8d7e, 0xb9ff90c9, 0xb4bcb610, 0xb07daba7,
    			0xae3afba2, 0xaafbe615, 0xa7b8c0cc, 0xa379dd7b,
    			0x9b3660c6, 0x9ff77d71, 0x92b45ba8, 0x9675461f,
    			0x8832161a, 0x8cf30bad, 0x81b02d74, 0x857130c3,
    			0x5d8a9099, 0x594b8d2e, 0x5408abf7, 0x50c9b640,
    			0x4e8ee645, 0x4a4ffbf2, 0x470cdd2b, 0x43cdc09c,
    			0x7b827d21, 0x7f436096, 0x7200464f, 0x76c15bf8,
    			0x68860bfd, 0x6c47164a, 0x61043093, 0x65c52d24,
    			0x119b4be9, 0x155a565e, 0x18197087, 0x1cd86d30,
    			0x029f3d35, 0x065e2082, 0x0b1d065b, 0x0fdc1bec,
    			0x3793a651, 0x3352bbe6, 0x3e119d3f, 0x3ad08088,
    			0x2497d08d, 0x2056cd3a, 0x2d15ebe3, 0x29d4f654,
    			0xc5a92679, 0xc1683bce, 0xcc2b1d17, 0xc8ea00a0,
    			0xd6ad50a5, 0xd26c4d12, 0xdf2f6bcb, 0xdbee767c,
    			0xe3a1cbc1, 0xe760d676, 0xea23f0af, 0xeee2ed18,
    			0xf0a5bd1d, 0xf464a0aa, 0xf9278673, 0xfde69bc4,
    			0x89b8fd09, 0x8d79e0be, 0x803ac667, 0x84fbdbd0,
    			0x9abc8bd5, 0x9e7d9662, 0x933eb0bb, 0x97ffad0c,
    			0xafb010b1, 0xab710d06, 0xa6322bdf, 0xa2f33668,
    			0xbcb4666d, 0xb8757bda, 0xb5365d03, 0xb1f740b4
    	};
		/**
		  * OWASP TOP 10 2010 - A4 Path Manipulation
		    * Changes to the below code to fix vulnerabilities
		    * TTP 324955
		    */
	//	byte[] bytes = FileUtils.readFileToByteArray(new File(fileLocation));
		byte[] bytes = FileUtils.readFileToByteArray(new File(OWASPSecurity.validationCheck(fileLocation, OWASPSecurity.DIRANDFILE)));
		int crc = 0x0;
		int length = 0;
		for(byte b : bytes) {
			length += 1;
			crc = (crc << 8) ^ table[((crc >>> 24) ^ b) & 0xFF];
		}

		for(; length != 0; length >>= 8) {
			crc = (crc << 8) ^ table[((crc >>> 24) ^ length) & 0xFF];
		}

		crc = ~crc & 0xffffffff;

		cksum = new BigInteger(Integer.toHexString(crc), 16);
		cksumLen = bytes.length;
	}

	/**
	 * SFTP's the file specified by <b>fileName</b> located in the
	 * <i>orData</i>+"/edw/"+<i>evalClient</i> directory. This method will
	 * also SFTP a file by the name of "TRLR"+<b>fileName</b> and,
	 * if the <i>useControl</i> instance variable is true, a file
	 * by the name of <b>fileName</b>+".control" will be SFTP'd. The instance vars
	 * <i>ftpHost</i>, <i>ftpPass</i>, <i>ftpUser</i>, and <i>ftpDir</i> are used to
	 * determine how to SFTP. If <i>decryptFlg</i> is true, the
	 * password will be decrypted before being used.
	 * If <i>ftpDir</i> is set, we will navigate to that directory
	 * before SFTP'ing the files.<br /><br />
	 * <b>Modified 09/24/2013</b><br />
	 * This method will now use the Routing Queue to SFTP the files, rather
	 * than performing the SFTP here. The operations will be the same, just
	 * on the Routing Queue.
	 * @param fileName - The name of the zip or tar.gz containing the text files
	 * @throws Exception If there is any issue SFTP'ing the files.
	 */
	private void sftpFiles(String fileName) throws Exception {
		ArrayList<String> filesToFtp = new ArrayList<String>();
		filesToFtp.add(orData+"/edw/"+evalClient+"/"+fileName);
		filesToFtp.add(orData+"/edw/"+evalClient+"/TRLR"+fileName);
		if(useControl) {
			filesToFtp.add(orData+"/edw/"+evalClient+"/"+fileName+".control");
		}

		for(String fileToFtp : filesToFtp) {
			insertSftpRQEntry(fileToFtp);
		}
	}

	/**
	 * Inserts a SFTP record into the Routing Queue table using
	 * the FTP parameters provided at startup along with the
	 * file name passed in as a parameter.
	 * @param fileName - The full path to the file that is being FTP'd
	 * @throws Exception If there is an issue inserting the RQ record
	 */
	private void insertSftpRQEntry(String fileName) throws Exception {
		String newFileName = "NONE";
		if(!ftpDir.equals("") && !ftpDir.equals("NONE")) {
			if(!ftpDir.endsWith("/")) {
				ftpDir += "/";
			}
			newFileName = ftpDir + fileName.substring(fileName.lastIndexOf("/")+1);
		}

		String additionalDataForFtp = "MODE,SFTP";
		additionalDataForFtp += ",BINARY,1";
		additionalDataForFtp += ",FILE_LOCATION," + fileName;
		additionalDataForFtp += ",NEW_FILE_NAME,"+newFileName;
		additionalDataForFtp += ",DELETE_FILE,0";
		additionalDataForFtp += ",HOST_NAME," + ftpHost;
		additionalDataForFtp += ",USER_NAME," + ftpUser;
		if(ftpKeyFile.equals("") || ftpKeyFile.equals("NONE")) {
			additionalDataForFtp += ",PASSWORD," + ftpPass;
			additionalDataForFtp += ",CERT_PATH,NONE";
		} else {
			additionalDataForFtp += ",PASSWORD,NONE";
			additionalDataForFtp += ",CERT_PATH," + ftpKeyFile;
		}
		additionalDataForFtp += ",CLEANUP,0,CLEANUP_DIR,NONE,CLEANUP_DAYS,NONE,CLEANUP_FILTER,NONE";

		SQLUpdate update = new SQLUpdate();
		update.SetPreparedUpdateStatement(conn, "insert into routing_queue " +
			"(request_id, queue_priority_num, routing_state_id, " +
			"run_dt, tries_num, additional_data_txt, routing_queue_id, routing_state_subtype_txt) " +
			"values (0, 0, 35, sysdate, 0, ?, routing_queue_seq.nextval, 'From EDW')");
		update.setString(1, additionalDataForFtp);
		update.RunPreparedUpdateStatement();
	}

	/**
	 * Tar.gz's all .txt and .trl files. The text files are put into a
	 * tar.gz file named by <b>txtTarName</b>. The trailer files are put
	 * into a tar.gz file named "TRLR"+<i>txtTarName</i>. After a file is
	 * added to one of the tar.gz files, it is deleted.
	 * It is expected that the text and trailer files are located
	 * in the directory specified by the <i>outputDir</i> instance var.
	 * It is also expected that the directory specified by
	 * <i>orData</i>+"/edw/"+<i>evalClient</i> exists. The account running
	 * the extract should have permissions to write to and delete
	 * from both locations.
	 * @param txtTarName - The file name of the tar.gz for the text files
	 * @return The number of files included in <b>txtTarName</b>
	 * @throws Exception If there is any issue tarring the files. If
	 * an individual file cannot be tarred, no exception is thrown.
	 */
	private int tarFiles(String txtTarName) throws Exception {
		String trlTarName = OWASPSecurity.validationCheck("TRLR" + txtTarName, OWASPSecurity.FILENAME);
		// orData + "/edw/" + evalClient + txtTarName
		// orData + "/edw/" + evalClient + trlTarName
		txtTarName = OWASPSecurity.validationCheck(orData + "/edw/" + evalClient + txtTarName, OWASPSecurity.DIRANDFILE);
		trlTarName = OWASPSecurity.validationCheck(orData + "/edw/" + evalClient + trlTarName, OWASPSecurity.DIRANDFILE);
		/**
		  * OWASP TOP 10 2010 - A4 Path Manipulation
		    * Changes to the below code to fix vulnerabilities
		    * TTP 324955
		    */
		//File dir = new File(outputDir);
		File dir = new File(OWASPSecurity.validationCheck(outputDir, OWASPSecurity.FILEDIR));
		String[] files = dir.list();
		byte[] buffer = new byte[1024];
		TarArchiveOutputStream txtTar = null;
		TarArchiveOutputStream trlTar = null;
		int txtCount = 0, trlCount = 0;
		try {
			/**
			  * OWASP TOP 10 2010 - A4 Path Manipulation
			    * Changes to the below code to fix vulnerabilities
			    * TTP 324955
			    */
			/*txtTar = new TarArchiveOutputStream(new GZIPOutputStream(new BufferedOutputStream(new FileOutputStream(txtTarName))));
			trlTar = new TarArchiveOutputStream(new GZIPOutputStream(new BufferedOutputStream(new FileOutputStream(trlTarName))));*/
			txtTar = new TarArchiveOutputStream(new GZIPOutputStream(new BufferedOutputStream(new FileOutputStream(OWASPSecurity.validationCheck(txtTarName, OWASPSecurity.FILENAME)))));
			trlTar = new TarArchiveOutputStream(new GZIPOutputStream(new BufferedOutputStream(new FileOutputStream(OWASPSecurity.validationCheck(trlTarName, OWASPSecurity.FILENAME)))));
			txtTar.setLongFileMode(TarArchiveOutputStream.LONGFILE_GNU);
			trlTar.setLongFileMode(TarArchiveOutputStream.LONGFILE_GNU);
			for(String fileName : files) {
				if(fileName.endsWith(".txt")) {
					FileInputStream in = null;
					try {
						/**
						  * OWASP TOP 10 2010 - A4 Path Manipulation
						  * Changes to the below code to fix vulnerabilities
						  * TTP 324955
						  */
					//	File file = new File(outputDir+"/"+fileName);
						
						File file = new File(OWASPSecurity.validationCheck(outputDir+"/"+fileName, OWASPSecurity.DIRANDFILE));
						TarArchiveEntry te = new TarArchiveEntry(file, fileName);
						txtTar.putArchiveEntry(te);
						in = new FileInputStream(file);
						int len;
						while((len = in.read(buffer)) > 0) {
							txtTar.write(buffer, 0, len);
						}
						txtTar.closeArchiveEntry();
						in.close();
						txtCount++;
						file.delete();
					} catch (Exception e) {
						log_obj.FmtAndLogMsg("Exception writing "+fileName+" to "+txtTarName+": "+e.toString(), e);
					} finally {
						try{ if(txtTar != null) txtTar.closeArchiveEntry(); }catch(Exception e1){e1.printStackTrace();}
		                try{ if(in != null) in.close(); }catch(Exception e1){e1.printStackTrace();}
					}
				} else if(fileName.endsWith(".trl")) {
					FileInputStream in = null;
					try {
						/**
						  * OWASP TOP 10 2010 - A4 Path Manipulation
						  * Changes to the below code to fix vulnerabilities
						  */
						//File file = new File(outputDir+"/"+fileName);
						File file = new File(OWASPSecurity.validationCheck(outputDir+"/"+fileName,OWASPSecurity.DIRANDFILE));
						TarArchiveEntry te = new TarArchiveEntry(file, fileName);
						trlTar.putArchiveEntry(te);
						in = new FileInputStream(file);
						int len;
						while((len = in.read(buffer)) > 0) {
							trlTar.write(buffer, 0, len);
						}
						trlTar.closeArchiveEntry();
						in.close();
						trlCount++;
						file.delete();
					} catch (Exception e) {
						log_obj.FmtAndLogMsg("Exception writing "+fileName+" to "+trlTarName+": "+e.toString(), e);
					} finally {
						try{ if(trlTar != null) trlTar.closeArchiveEntry(); }catch(Exception e1){e1.printStackTrace();}
		                try{ if(in != null) in.close(); }catch(Exception e1){e1.printStackTrace();}
					}
				}
			}

			txtTar.close();
			trlTar.close();
		} catch (Exception e) {
			log_obj.FmtAndLogMsg("Exception tarring txt and trl files: "+e.toString(), e);
			throw e;
		} finally {
			try{ if(txtTar != null) txtTar.close(); }catch(Exception e1){e1.printStackTrace();}
		    try{ if(trlTar != null) trlTar.close(); }catch(Exception e1){e1.printStackTrace();}
		}

		return txtCount;
	}

	/**
	 * Zips all .txt and .trl files. The text files are put into a
	 * zip file named by <b>txtZipName</b>. The trailer files are put
	 * into a zip file named "TRLR"+<b>txtZipName</b>. After a file is
	 * added to one of the zip files, it is deleted.
	 * It is expected that the text and trailer files are located
	 * in the directory specified by the <i>outputDir</i> instance var.
	 * It is also expected that the directory specified by
	 * <i>orData</i>+"/edw/"+<i>evalClient</i> exists. The account running
	 * the extract should have permissions to write to and delete
	 * from both locations.
	 * @param txtZipName - The file name of the zip for the text files
	 * @return The number of files included in <b>txtZipName</b>
	 * @throws Exception If there is any issue zipping the files. If
	 * an individual file cannot be zipped, no exception is thrown.
	 */
	private int zipFiles(String txtZipName) throws Exception {
		String trlZipName = OWASPSecurity.validationCheck("TRLR" + txtZipName, OWASPSecurity.FILENAME);
		txtZipName = OWASPSecurity.validationCheck(orData + "/edw/" + evalClient + "/" + txtZipName, OWASPSecurity.DIRANDFILE);
		trlZipName = OWASPSecurity.validationCheck(orData + "/edw/" + evalClient + "/" + trlZipName, OWASPSecurity.DIRANDFILE);

		/**
		  * OWASP TOP 10 2010 - A4 Path Manipulation
		    * Changes to the below code to fix vulnerabilities
		    * TTP 324955
		    */
		//File dir = new File(outputDir);
		File dir = new File(OWASPSecurity.validationCheck(outputDir, OWASPSecurity.FILEDIR));
		String[] files = dir.list();
		byte[] buffer = new byte[1024];
		ZipOutputStream txtZip = null;
		ZipOutputStream trlZip = null;
		int txtCount = 0, trlCount = 0;

		try {
			/**
			  * OWASP TOP 10 2010 - A4 Path Manipulation
			  * Changes to the below code to fix vulnerabilities
			  * TTP 324955
			  */
		    /* txtZip = new ZipOutputStream(new FileOutputStream(txtZipName));
		       trlZip = new ZipOutputStream(new FileOutputStream(trlZipName));
		      */
		    txtZip = new ZipOutputStream(new FileOutputStream(OWASPSecurity.validationCheck(txtZipName, OWASPSecurity.DIRANDFILE)));
			trlZip = new ZipOutputStream(new FileOutputStream(OWASPSecurity.validationCheck(trlZipName, OWASPSecurity.DIRANDFILE)));
			for(String fileName : files) {
				if(fileName.endsWith(".txt")) {
					FileInputStream in = null;
					try {
						/**
						  * OWASP TOP 10 2010 - A4 Path Manipulation
						    * Changes to the below code to fix vulnerabilities
						    * TTP 324955
						    */

						//File file = new File(outputDir+"/"+fileName);
						File file = new File(OWASPSecurity.validationCheck(outputDir+"/"+fileName, OWASPSecurity.DIRANDFILE));
						ZipEntry ze = new ZipEntry(fileName);
						txtZip.putNextEntry(ze);
						in = new FileInputStream(file);
						int len;
						while((len = in.read(buffer)) > 0) {
							txtZip.write(buffer, 0, len);
						}
						txtZip.closeEntry();
						in.close();
						txtCount++;
						file.delete();
					} catch (Exception e) {
						log_obj.FmtAndLogMsg("Exception writing "+fileName+" to "+txtZipName+": "+e.toString(), e);
					} finally {
						try{ if(txtZip != null) txtZip.closeEntry(); }catch(Exception e1){e1.printStackTrace();}
			            try{ if(in != null) in.close(); }catch(Exception e1){e1.printStackTrace();}
					}
				} else if(fileName.endsWith(".trl")) {
					FileInputStream in = null;
					try {
						/**
						  * OWASP TOP 10 2010 - A4 Path Manipulation
						  * Changes to the below code to fix vulnerabilities
						  * TTP 324955
						  */
						//File file = new File(outputDir+"/"+fileName);
						File file = new File(OWASPSecurity.validationCheck(outputDir+"/"+fileName, OWASPSecurity.DIRANDFILE));
						ZipEntry ze = new ZipEntry(fileName);
						trlZip.putNextEntry(ze);
						in = new FileInputStream(file);
						int len;
						while((len = in.read(buffer)) > 0) {
							trlZip.write(buffer, 0, len);
						}
						trlZip.closeEntry();
						in.close();
						trlCount++;
						file.delete();
					} catch (Exception e) {
						log_obj.FmtAndLogMsg("Exception writing "+fileName+" to "+trlZipName+": "+e.toString(), e);
					} finally {
						try{ if(trlZip != null) trlZip.closeEntry(); }catch(Exception e1){e1.printStackTrace();}
			            try{ if(in != null) in.close(); }catch(Exception e1){e1.printStackTrace();}
					}
				}
			}

			txtZip.close();
			trlZip.close();
		} catch (Exception e) {
			log_obj.FmtAndLogMsg("Exception zipping txt and trl files: "+e.toString(), e);
			try{ if(txtZip != null) txtZip.close(); }catch(Exception e1){e1.printStackTrace();}
			try{ if(trlZip != null) trlZip.close(); }catch(Exception e1){e1.printStackTrace();}
			throw e;
		} finally {
			try{ if(txtZip != null) txtZip.close(); }catch(Exception e1){e1.printStackTrace();}
			try{ if(trlZip != null) trlZip.close(); }catch(Exception e1){e1.printStackTrace();}
		}

		return txtCount;
	}

	/**
	 * Queries XREF_EVALUATOR_EXTRACT to get start and end dates
	 * for an incremental extract. For full and mnt extracts,
	 * this will return UNKNOWN as the start and end dates.
	 * If <i>useControlDates</i> is set to true, the UNKNOWN
	 * value will be replaced with the current date.
	 * @return Start and End dates for extract
	 * @throws Exception If there was an issue querying XREF_EVALUATOR_EXTRACT
	 */
	private String getControlFileDates() throws Exception {
		String sDate = "UNKNOWN";
		String eDate = "UNKNOWN";
		if(useControlDates) {
			SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
			sDate = formatter.format(new Date());
			eDate = sDate;
		}
		if(transType.equals("INCR")) {
			try {
				String sql = "select to_char(start_dt,'YYYY-MM-DD') as STARTDATE, " +
					"to_char(end_dt,'YYYY-MM-DD') as ENDDATE " +
					"from xref_evaluator_extract " +
					"where evaluator_id = ? ";
				Query query = new Query(conn);
				query.prepareStatement(sql);
				query.setInt(1, Integer.valueOf(evaluatorID));
				query.executePreparedQuery();
				if(query.next()) {
					sDate = query.getColValue("STARTDATE",sDate);
					eDate = query.getColValue("ENDDATE",eDate);
					SQLUpdate update = new SQLUpdate();
					update.SetPreparedUpdateStatement(conn, "delete from xref_evaluator_extract where evaluator_id = ? ");
					update.setInt(1, Integer.valueOf(evaluatorID));
					update.RunPreparedUpdateStatement();
				}
			} catch(Exception e) {
				log_obj.FmtAndLogMsg("Exception getting control file dates: " + e.toString(), e);
				throw e;
			}
		}

		return sDate + " " + eDate;
	}

	/**
	 * Handles merges into EDW_EXTRACT and XREF_EVALUATOR_EXTRACT for
	 * incremental EDW extracts. If <i>startDate</i> and/or <i>endDate</i> instance
	 * variables are not initialized, it is assuming that we are running
	 * the incremental extract without a date range, which means we
	 * are pulling apps from yesterday. If the <i>queryID</i> is initialized,
	 * it will be used instead of the date range and the XREF_EVALUATOR_EXTRACT
	 * table will have yesterday as the start date and today as the end date.
	 * @throws Exception If merges fail for any reason, or if EDW_EXTRACT
	 * contains a row with request_id = -1 for this company, which means
	 * that the previous date range merge failed. This should be handled
	 * manually.
	 */
	private void loadIncrementalDateRange() throws Exception {
		boolean dateRange = false;
		if(startDate == null || endDate == null || startDate.equals("") || endDate.equals("") ||
				startDate.equals("NONE") || endDate.equals("NONE")) {
			dateRange = false;
		} else if(!startDate.matches("^[0-9]{2}/[0-9]{2}/[0-9]{4}$") ||
				!endDate.matches("^[0-9]{2}/[0-9]{2}/[0-9]{4}$")) {
			System.err.println("Start Date or End Date in invalid format.");
			ShowUsage();
		} else {
			dateRange = true;
			startDate = startDate.replace("/", "") + " 00:00:00";
			endDate = endDate.replace("/", "") + " 23:59:59";
		}

		// If the query is set, we just want to insert into
		// XREF_EVALUATOR_EXTRACT with the current date range
		if(queryID != null && !queryID.equals("") && !queryID.equals("NONE")) {
			dateRange = false;
		}

		SQLUpdate update = new SQLUpdate();

		try {
			// This insert will throw an exception if another EDW is running at the same time
			update.SetPreparedUpdateStatement(conn, "insert into edw_extract values (-1, ?, sysdate)");
			update.setInt(1, Integer.valueOf(evaluatorID));
			update.RunPreparedUpdateStatement();
		} catch(Exception e) {
			throw new Exception("Exception inserting EDW_EXTRACT safeguard record. Some other process may be running EDW. " +
					"If no other process is running EDW and this safeguard is in place, it will need to be deleted manually " +
					"with the command \"delete from edw_extract where request_id = -1 and evaluator_id = " + evaluatorID +
					";\" before running Incremental EDW again. Ex: " + e.toString(), e);
		}

		try {
			update.SetPreparedUpdateStatement(conn, "delete from edw_extract where request_id != -1 and evaluator_id = ? ");
			update.setInt(1, Integer.valueOf(evaluatorID));
			update.RunPreparedUpdateStatement();

			// Insert into EDW_EXTRACT table
			if(queryID == null || queryID.equals("") || queryID.equals("NONE")) {
				runMerge("CREDIT_REQUEST","LAST_ACCESS_DATE",dateRange);
				runMerge("CREDIT_REQUEST","AUDIT_LAST_UPDATED_DT",dateRange);
				runMerge("CREDIT_REQUEST_JOURNAL","JOURNAL_DT",dateRange);
				runMerge("RO_CR_COMMENT","COMMENT_DT",dateRange);
			} else {
				runInsertWithQueryId();
			}

			// Insert into XREF_EVALUATOR_EXTRACT table
			runDateRangeMerge(dateRange);
		} catch(Exception e) {
			throw e;
		} finally {
			try {
				// Once date range step is complete, always try to delete the safeguard record
				update.SetPreparedUpdateStatement(conn, "delete from edw_extract where request_id = -1 and evaluator_id = ? ");
				update.setInt(1, Integer.valueOf(evaluatorID));
				update.RunPreparedUpdateStatement();
			} catch(Exception ex) {
				log_obj.FmtAndLogMsg("Exception deleting EDW_EXTRACT safeguard record. It will need to be deleted manually " +
						"with the command \"delete from edw_extract where request_id = -1 and evaluator_id = " + evaluatorID +
						";\". " + ex.toString(), ex);
			}
		}
	}

	/**
	 * Puts the start and end date for the extract into XREF_EVALUATOR_EXTRACT
	 * table. If <b>dateRange</b> is true, it is expected that we have instance
	 * variables <i>startDate</i> and <i>endDate</i> initialized correctly in
	 * MMDDYYYY HH24:MI:SS format.
	 * @param dateRange - True if calling code will add in start and end date,
	 * false to just use yesterday as date range
	 * @throws Exception If the merge into XREF_EVALUATOR_EXTRACT failed
	 */
	private void runDateRangeMerge(boolean dateRange) throws Exception {
		String sql = "";
		try {
			String dateRangeStr="to_date(?,'MMDDYYYY HH24:MI:SS')";
			String nonDateRangeStartStr="sysdate-1";
			String nonDateRangeEndStr="sysdate";
			sql = "merge into xref_evaluator_extract using (select ? as evaluator_id from dual) B " +
				"on (xref_evaluator_extract.evaluator_id = B.evaluator_id) " +
				"when matched then update set xref_evaluator_extract.start_dt = ";
			sql += dateRange?dateRangeStr:nonDateRangeStartStr;
			sql += ", xref_evaluator_extract.end_dt = ";
			sql += dateRange?dateRangeStr:nonDateRangeEndStr;
			sql += " when not matched then insert (xref_evaluator_extract.evaluator_id, " +
					"xref_evaluator_extract.start_dt, xref_evaluator_extract.end_dt) values (B.evaluator_id,";
			sql += dateRange?dateRangeStr:nonDateRangeStartStr;
			sql += ",";
			sql += dateRange?dateRangeStr:nonDateRangeEndStr;
			sql += ")";
			SQLUpdate update = new SQLUpdate();
			update.SetPreparedUpdateStatement(conn, sql);
			update.setInt(1, Integer.valueOf(evaluatorID));
			if(dateRange) {
				update.setString(2, startDate);
				update.setString(3, endDate);
				update.setString(4, startDate);
				update.setString(5, endDate);
			}
			update.RunPreparedUpdateStatement();
		} catch (Exception e) {
			throw new Exception("Exception setting xref_evaluator_extract date range " +
					"using "+(dateRange?("start date="+startDate+" and end date="+endDate):
					"default date range")+", sql="+sql+", Exception="+e.toString(), e);
		}
	}

	/**
	 * Runs the WTU query specified by the <i>queryID</i> instance variable.
	 * The query is expected to return a request_id as its first column
	 * and is expected to only require evaluator_id as a source parameter.
	 * @throws Exception If the inserts into EDW_EXTRACT failed
	 */
	private void runInsertWithQueryId() throws Exception {
		try {
			SQLUpdate update = new SQLUpdate();
			Query selectionQuery = null;
			GenJob genJob = new GenJob(conn, log_obj);
			Hashtable<String,String> parms = new Hashtable<String,String>();
			parms.put("evaluator_id", evaluatorID);
			selectionQuery = genJob.buildAndExecuteQuery(conn,queryID,"0",parms);
			while(selectionQuery.next()) {
				String sql = "merge into EDW_EXTRACT using (select ? as REQUEST_ID, ? as EVALUATOR_ID from dual" +
				") A on (EDW_EXTRACT.REQUEST_ID = A.REQUEST_ID) " +
				"when matched then update set EDW_EXTRACT.EXTRACT_DT = SYSDATE " +
				"when not matched then insert (EDW_EXTRACT.REQUEST_ID, EDW_EXTRACT.EVALUATOR_ID, EDW_EXTRACT.EXTRACT_DT) " +
				"values (A.REQUEST_ID, A.EVALUATOR_ID, SYSDATE)";
				update.SetPreparedUpdateStatement(conn, sql);
				update.setInt(1, Integer.valueOf(selectionQuery.getColValue(1))); //request_id
				update.setInt(2, Integer.valueOf(evaluatorID));
				update.RunPreparedUpdateStatement();
			}
		} catch(Exception e) {
			throw new Exception("Exception setting edw_extract date range for queryId="+
					queryID+", Exception="+e.toString(), e);
		}
	}

	/**
	 * Builds a merge statement based on the <b>table</b>/<b>column</b> containing the
	 * date to compare to the date range. If <b>dateRange</b> is true, it is
	 * expected that we have instance variables <i>startDate</i> and <i>endDate</i>
	 * initialized correctly in MMDDYYYY HH24:MI:SS format.
	 * @param table - The table containing the date column to check
	 * @param column - A date column in the database
	 * @param dateRange - True if calling code will add in start and end date,
	 * false to just use yesterday as date range
	 * @throws Exception If the merge into EDW_EXTRACT failed
	 */
	private void runMerge(String table, String column, boolean dateRange) throws Exception {
		String sql = "";
		try {
			SQLUpdate update = new SQLUpdate();

			sql = buildMerge(table,column,dateRange);
			update.SetPreparedUpdateStatement(conn, sql);
			update.setInt(1, Integer.valueOf(evaluatorID));
			if(dateRange) {
				update.setString(2, startDate);
				update.setString(3, endDate);
			}
			update.RunPreparedUpdateStatement();
		} catch (Exception e) {
			throw new Exception("Exception setting edw_extract date range for "+table+"."+column+
					" using "+(dateRange?("start date="+startDate+" and end date="+endDate):
						"default date range")+", sql="+sql+", Exception="+e.toString(), e);
		}
	}

	/**
	 * Builds a SQL merge statement to insert or update EDW_EXTRACT based
	 * on the <b>table</b>/<b>column</b> passed in. If <b>dateRange</b> is true, the merge expects
	 * the code using the returned statement to replace the parameterized
	 * start and end dates (in MMDDYYYY HH24:MI:SS format).
	 * @param table - The table containing the date column to check
	 * @param column - A date column in the database
	 * @param dateRange - True if calling code will add in start and end date,
	 * false to just use yesterday as date range
	 * @return SQL merge into EDW_EXTRACT statement
	 */
	private String buildMerge(String table, String column, boolean dateRange) {
		String selection = "";
		if(dateRange) {
			selection = "select distinct request_id, evaluator_id from "+table+
				" where evaluator_id = ? and "+
				"("+column+" >= to_date(?,'MMDDYYYY HH24:MI:SS') and "+
				column+" <= to_date(?,'MMDDYYYY HH24:MI:SS'))";
		} else {
			selection = "select distinct request_id, evaluator_id from "+table+
				" where evaluator_id = ? and "+
				"to_char("+column+",'MMDDYYYY') = to_char(sysdate-1,'MMDDYYYY')";
		}
		String sql = "merge into EDW_EXTRACT using (" + selection +
			") A on (EDW_EXTRACT.REQUEST_ID = A.REQUEST_ID) " +
			"when matched then update set EDW_EXTRACT.EXTRACT_DT = SYSDATE " +
			"when not matched then insert (EDW_EXTRACT.REQUEST_ID, EDW_EXTRACT.EVALUATOR_ID, EDW_EXTRACT.EXTRACT_DT) " +
			"values (A.REQUEST_ID, A.EVALUATOR_ID, SYSDATE)";
		return sql;
	}

	public void decrementThreadCount() {

	   synchronized (critsec) {

		  iNumThreads--;

		} // sync

    } //decrementThreadCount

	public synchronized String getNextTable() {
		if(tableNum < tables.size()) {
			return tables.get(tableNum++);
		} else {
			return null;
		}
	}
}
