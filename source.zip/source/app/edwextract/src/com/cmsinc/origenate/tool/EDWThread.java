package com.cmsinc.origenate.tool;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.math.BigInteger;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.cmsinc.origenate.crypto.Crypto;
import com.cmsinc.origenate.crypto.CryptoFactory;
import com.cmsinc.origenate.util.ConnectionUtils;
import com.cmsinc.origenate.util.LogMsg;
import com.cmsinc.origenate.util.Query;
import com.cmsinc.origenate.util.SQLSecurity;

public class EDWThread implements Runnable {
	private boolean bDecrypt;
	private String dbName = "", transType = "", selectString="", evalClient = "",
			result="", evaluator="", encryptionUser="", outputDir="", threadName = "",
			connectionString = "", dbUser = "", dbPass = "";
	private int retries = 0;
	private EDW main;
	private LogMsg log_obj;
	private List<String> keyList = new ArrayList<String>();
	private Crypto crypto = null;

	public EDWThread(EDW main,String name, String connectionString,
			String dbUser, String dbPass,
			String evaluatorID, String dbName, 
			String transType, String evalClient, String outputDir,boolean bDecrypt,
			String encryptionUser, LogMsg log_obj, int retries) throws Exception {
		this.threadName = name;
		this.bDecrypt=bDecrypt;
		this.main=main;
		this.transType = transType;
		this.dbName = dbName;
		this.evalClient = evalClient;
		this.evaluator = evaluatorID;
		this.connectionString = connectionString;
		this.dbUser = dbUser;
		this.dbPass = dbPass;
		this.log_obj = log_obj;
		this.outputDir=outputDir;
		this.encryptionUser=encryptionUser;
		this.retries = retries;
		if(this.retries < 0) {
			this.retries = 0;
		}
	}

	public void run() {
		BufferedWriter textFileWriter=null;
		BufferedWriter trlFileWriter=null;
		Connection conn = null;
		try {
			conn = DriverManager.getConnection(connectionString, dbUser, dbPass);

			List<String> decryptSSNCols = Arrays.asList("SOC_SEC_NUM_TXT","SELLER_SSN_TXT","SOCIAL_SEC_NUM_TXT","SOCIAL_INS_NUM_TXT","SSN_TXT"); 
			List<String> decryptAccCols = Arrays.asList("ACCOUNT_NO_TXT","ACCOUNT_NUMBER_TXT","AUTO_PAYMENT_ACCT_TXT","ACCOUNT_1_TXT","ACCOUNT_2_TXT","ACCOUNT_3_TXT","ACCOUNT_4_TXT","DEALER_RESERVE_ACCOUNT_TXT","DDA_NUM","GL_ACCT_TXT","EFTACHNUMBER_TXT","PAYEE_ACCTNUM_TXT","OSGL_ACCT_TXT","DRAFT_ACCT_NUM","CHECKING_NO_TXT","ACCOUNT_NUM_TXT"); 
			List<String> encryptionCols = Arrays.asList("SOC_SEC_NUM_TXT_ENC","SELLER_SSN_TXT_ENC","SOCIAL_SEC_NUM_TXT_ENC","SOCIAL_INS_NUM_TXT_ENC","SSN_TXT_ENC","ACCOUNT_NO_TXT_ENC","ACCOUNT_NUMBER_TXT_ENC","AUTO_PAYMENT_ACCT_TXT_ENC","ACCOUNT_1_TXT_ENC","ACCOUNT_2_TXT_ENC","ACCOUNT_3_TXT_ENC","ACCOUNT_4_TXT_ENC","DEALER_RESERVE_ACCOUNT_TXT_ENC","DDA_NUM_ENC","GL_ACCT_TXT_ENC","EFTACHNUMBER_TXT_ENC","PAYEE_ACCTNUM_TXT_ENC","OSGL_ACCT_TXT_ENC","DRAFT_ACCT_NUM_ENC","CHECKING_NO_TXT_ENC","ACCOUNT_NUM_TXT_ENC","DRIVER_LICENSE_NUMBER_TXT_ENC");
			List<String> evalDecryptSSNCols = Arrays.asList("SSNO","COBORROWERSSN","BORROWERSSN","SSN","INQNAMESSN2","INQNAMESSN1","SPOUSESSN","SUBJECTSSN","INQRSUBSSN","MDBSUBSSN","APPLSSNO","COAPPLSSNO","VERSSNO","SECSSN","PRIMSSN","SOCSECNO","SOCINSNO","SIN","VERINPUTSSN","INPUTCORRECTEDSSN","APPSSNO","VERIFIEDSSN"); 
			List<String> evalDecryptAccCols = Arrays.asList("ACCTNO","ACCOUNTID","LOGINACCOUNTID","LOGINACCOUNTPWD","SECONDARYACCTID","ACCOUNTNO","ACCNO","ACCOUNT_NUMBER_TXT","CREDACCTNO1","CREDACCTNO2","CREDACCTNO3","CREDACCTNO4","CREDACCTNO5","CERTIFICATE_ACCT_NUM_TXT","CREDITED_TO_ACCT_TXT","AUTO_PAYMENT_ACCT_TXT","OSGL_ACCT_TXT","PAYEE_ACCTNUM_TXT","GL_ACCT_TXT","DRAFT_ACCT_NUM","ACCOUNT","PAYACCOUNT"); 
			List<String> origEncTables = Arrays.asList("REQUESTOR","REQUESTOR_BUREAU_FILES","CREDIT_REQ_CONTR_REQUESTOR","CREDIT_REQ_SSN_BUREAU_CHECK","CREDIT_REQ_CONTR_OTHER","CREDIT_REQ_CIS_INTERFACE","POSTING_QUEUE_EXCEPTION","REQUESTOR_ASSET","REQUESTOR_DEBT","CREDIT_REQUEST_FINANCE", "CREDIT_REQUEST_LIEN", "CREDIT_REQ_CONTR_LEASE", "CREDIT_REQ_CONTR_FIN", "CREDIT_REQ_CONTR_LIEN", "EVALUATOR_ORIGINATOR", "CREDIT_REQUEST_PAYOFF", "XREF_CIS_ACCOUNTS", "REQUESTOR_ADDED_TRADE");
			List<String> evalEncTables = Arrays.asList("BUREAU_HEADER","BUYERID_INDEX","BUYERID_INDEX_INQUIRY","CDC_100","CDC_201","EFX_FU","EFX_SS","EVAPP_AUTHORIZED_USER","EVAPP_BURHDR","EVAPP_BURREPORTPATH","EVAPP_CONTRACT_PERSONAL","EVAPP_INFO","EVAPP_PERSONAL", "INSTANTID", "INSTANTID_INQUIRY", "RISK_VIEW", "RISK_VIEW_ATTRIBUTES", "RISK_VIEW_INQUIRY", "RISK_WISE", "TAF_INQUIRY", "XPN_322", "XPN_A1" , "XPN_X4" , "TRU_FD_PI01" , "TRU_PI01" , "EFC_FU", "CDC_302", "CDC_303", "CDC_760", "CDC_761", "CDC_770", "CDM_CLB", "CDM_REQ", "CDM_RSP", "CDM_SPT", "CDM_SPY", "CDM_ULB", "EFC_TC", "EFX_PT", "EVAPP_ADDED_TRADE", "EVAPP_BUSCRED", "EVAPP_COLLAT_MISC_SECURITY", "EVAPP_CONTRACT_FINANCE", "EVAPP_CONTRACT_LEASE", "EVAPP_CONTRACT_MISC_SECURITY", "EVAPP_CONTRACT_REQUEST_PAYOFF", "EVAPP_TRADE", "TRU_TR01", "TUC_TR01", "XPN_A9");

			List<String> ignoreCols = null;
			List<String> encCols = null;

			// This is a list of characters that should be filtered out of the
			// selected values. They will be replaced with a blank space.
			// The prefix and suffix created here are added to each column
			// when building the query.
			List<String> filters = Arrays.asList(
					"CHR(1)","CHR(2)","CHR(3)","CHR(4)","CHR(5)",
					"CHR(6)","CHR(7)","CHR(8)","CHR(9)","CHR(10)",
					"CHR(11)","CHR(12)","CHR(13)","CHR(14)","CHR(15)",
					"CHR(16)","CHR(17)","CHR(18)","CHR(19)","CHR(20)",
					"CHR(21)","CHR(22)","CHR(23)","CHR(24)","CHR(25)",
					"CHR(26)","CHR(27)","CHR(28)","CHR(29)","CHR(30)",
					"CHR(31)","CHR(149)","CHR(166)");
			String filterPrefix = "", filterSuffix = "";
			StringBuffer temp_buffer1 = new StringBuffer("");
			StringBuffer temp_buffer2 = new StringBuffer("");
			for(String filter : filters) {
				temp_buffer1.insert(0,"replace(");
				temp_buffer2.append(","+filter+",' ')");
			}
			// The last filter should be the pipe character
			temp_buffer1.append("replace(TBL.");
			temp_buffer2.insert(0,",'|','')");
			filterPrefix = temp_buffer1.toString();
			filterSuffix = temp_buffer2.toString();

			if(bDecrypt) {
				try {
					crypto = CryptoFactory.getCrypto();
				} catch (Exception e) {
					e.printStackTrace();
					throw new Exception("Unable to initialize Crypto object for decryption: " + e.toString(), e);
				}
			}

			// This thread may process multiple tables. Process each individually in this loop
			int numTablesProcessed = 0;
			String table = "";
			while((table = main.getNextTable()) != null) {
				for(int tryNum = 0; tryNum <= retries; tryNum++) {
					// Try/Catch block for retry logic
					try {
						// First create output file
						try {
							textFileWriter = new BufferedWriter(new FileWriter(outputDir+"/"+table+".txt", false));
							trlFileWriter = new BufferedWriter(new FileWriter(outputDir+"/"+table+".trl", false));
						} catch (Exception e) { 
							// move on to the next table if there's an issue
							throw new Exception("Error creating File: "+table+".txt: " + e.toString(), e);
						}

						// The first step is to get the list of columns to include for this table.
						// The rawStatement query will get the columns. There is logic in this
						// query to filter out columns and order columns based on EDW column configuration.
						selectString="select "; 
						String orderBy = ""; // needs to be empty initially
						StringBuffer temp_buffer3 = new StringBuffer(selectString);
						String rawStatement = "select atc.column_name, atc.data_type " + 
								"FROM user_tab_columns atc, " + 
								"(SELECT table_name, column_name, orig_eval_flg, extract_order_num FROM config_edw_tables where evaluator_id = ? and table_name = ? UNION SELECT '- -++1_1' AS table_name, '- -++1_1' AS column_name, 0 AS orig_eval_flg, 0 AS extract_order_num FROM dual) cee, " + 
								"(SELECT count(*) AS table_count FROM config_edw_tables WHERE evaluator_id = ? AND orig_eval_flg = ?) ceec " + 
								"WHERE ((ceec.table_count = 0 AND cee.table_name = '- -++1_1') OR (ceec.table_count != 0 AND cee.table_name != '- -++1_1' AND cee.column_name != '- -++1_1' AND cee.table_name = atc.table_name AND cee.column_name = atc.column_name AND cee.orig_eval_flg = ?)) " + 
								"AND atc.table_name = ? " + 
								"ORDER BY cee.extract_order_num ASC NULLS LAST, atc.column_id ASC ";

						Query query = new Query(conn);
						query.prepareStatement(rawStatement);
						query.setInt(1, Integer.valueOf(evaluator));
						query.setString(2, table, false);
						query.setInt(3, Integer.valueOf(evaluator));
						if(dbName.equals("ORIG")) {
							query.setInt(4, 0);
							query.setInt(5, 0);
						} else {
							query.setInt(4, 1);
							query.setInt(5, 1);
						}
						query.setString(6, table, false);
						query.executePreparedQuery();

						ignoreCols = new ArrayList<String>();
						encCols = new ArrayList<String>(); 
						String dataType = "";
						String columnName = "";

						while(query.next()) {
							columnName = SQLSecurity.sanitize(query.getColValue("column_name",""));
							dataType = query.getColValue("data_type","");
							
							//TTP 324955 notes: columnName sanitized below for added security
							//in case the above code ever changes for some reason
							
							if(orderBy.equals("") &&
									(columnName.equalsIgnoreCase("REQUEST_ID") || columnName.equalsIgnoreCase("APPSEQNO"))) {
								orderBy = " order by " + SQLSecurity.sanitize(columnName);
							}
							
							// For these datatypes, we just want null
							if(dataType.equals("CLOB") || dataType.equals("BFILE") || dataType.equals("BLOB") || 
									dataType.equals("LONG") || dataType.equals("LONG RAW")) {
								if(temp_buffer3.toString().equals("select ")) {
									temp_buffer3.append("null as "+SQLSecurity.sanitize(columnName));
								} else {
									temp_buffer3.append(",null as "+SQLSecurity.sanitize(columnName));
								}
							} 
							// For all other datatypes, include them in the extract
							else {
								if(dataType.equals("DATE") || dataType.equals("DATETIME")) {
									if(temp_buffer3.toString().equals("select ")) {
										temp_buffer3.append("TO_CHAR(TBL."+SQLSecurity.sanitize(columnName)+",'MM/DD/YYYY  HH:MI:SS AM') as "+SQLSecurity.sanitize(columnName));
									} else {
										temp_buffer3.append(",TO_CHAR(TBL."+SQLSecurity.sanitize(columnName)+",'MM/DD/YYYY  HH:MI:SS AM') as "+SQLSecurity.sanitize(columnName));
									}
								} else {
									// Because the users are now able to customize which columns they want in the extract,
									// they may select to include a masked column, but still want it decrypted. We need the
									// matching _ENC column in Origenate to meet this requirement. So add it to a list of
									// columns to select, but ignore it when generating the output file. If the _ENC column
									// is part of the columns configured to be selected, then put it in the output file
									// in the correct spot.

									String filteredColumnName = filterPrefix + SQLSecurity.sanitize(columnName) + filterSuffix + " as " + SQLSecurity.sanitize(columnName);

									if(dbName.equals("ORIG") && bDecrypt && origEncTables.contains(table)) {
										if(decryptSSNCols.contains(columnName) || decryptAccCols.contains(columnName) || columnName.equals("DRIVER_LICENSE_NUMBER_TXT")) {
											if(!(temp_buffer3.toString().equals("select "))) {
												temp_buffer3.append(",");
											}
											//TTP 324955 notes: filteredColumnName previously sanitized
											temp_buffer3.append(filteredColumnName);
											if(!encCols.contains(columnName+"_ENC")) {
												ignoreCols.add(columnName+"_ENC");
												temp_buffer3.append("," + filterPrefix + SQLSecurity.sanitize(columnName) + "_ENC" + filterSuffix + " as " + SQLSecurity.sanitize(columnName) + "_ENC");
											}
										} else if(encryptionCols.contains(columnName)) {
											if(ignoreCols.contains(columnName)) {
												ignoreCols.remove(columnName);
												encCols.add(columnName);

												// Remove where ignoreCols put it and then put it in its correct spot
												selectString = temp_buffer3.toString();
												selectString = selectString.replace(","+filteredColumnName, "");
												selectString = selectString.replace(filteredColumnName, "");
												temp_buffer3.setLength(0); // reset the StringBuffer temp_buffer3
												temp_buffer3.append(selectString);

												if(!(temp_buffer3.toString().equals("select "))) {
													temp_buffer3.append(",");
												}
												temp_buffer3.append(filteredColumnName);
											} else {
												if(!(temp_buffer3.toString().equals("select "))) {
													temp_buffer3.append(",");
												}
												encCols.add(columnName);
												temp_buffer3.append(filteredColumnName);
											}
										} else {
											if(!(temp_buffer3.toString().equals("select "))) {
												temp_buffer3.append(",");
											}
											temp_buffer3.append(filteredColumnName);
										}
									} else {
										if(!(temp_buffer3.toString().equals("select "))) {
											temp_buffer3.append(",");
										}
										temp_buffer3.append(filteredColumnName);
									}
								}
							}
						}
						temp_buffer3.append(" from "+SQLSecurity.sanitize(table)+" TBL ");
						selectString = temp_buffer3.toString();

						// Add the where clause based on the type of extract
						keyList = new ArrayList<String>();
						selectString = addConditions(conn, selectString, table);
						
						// Add the order by clause if APPSEQNO or REQUEST_ID columns exist
						selectString += orderBy;

						log_obj.FmtAndLogMsg(threadName+"Table Data Query: "+selectString);	

						PreparedStatement ps = null;
						ResultSet rs = null;
						ResultSetMetaData md = null;
						BigInteger cnt = BigInteger.ZERO;

						try {
							/**
							 * OWASP TOP 10 2010 - A1 High SQL Injection
							 *  TTP 324955 Security Remediation Fortify Scan
							 */				
							//Fortify possible false positive
							ps = conn.prepareStatement(SQLSecurity.basicSanitize(selectString));
							//ps = conn.prepareStatement(ESAPI.encoder().encodeForSQL( new OracleCodec(),selectString.toString()));

							// Add in parameterized values from addConditions()
							for(int i = 1; i <= keyList.size(); i++) {
								if((keyList.get(i-1)).equals("EVALCLIENTID")) {
									ps.setString(i, evalClient);
								} else if((keyList.get(i-1)).equals("ORIGEVALID")) {
									ps.setInt(i, Integer.parseInt(evaluator));
								}
							}

							rs = ps.executeQuery();
							md = rs.getMetaData();

							int col = md.getColumnCount();

							log_obj.FmtAndLogMsg(threadName+"RETRIEVED DATA, WRITING FILE FOR: "+table);
							boolean decrypted = false;
							String colValue = null;
							StringBuffer temp_buffer4 = new StringBuffer(result);

							while(rs.next()) {
								cnt = cnt.add(BigInteger.ONE);
								for(int i = 1; i <= col; i++) {
									decrypted = false;
									columnName = md.getColumnName(i);
									colValue = rs.getString(columnName);
									if(dbName.equals("ORIG")) {
										// If decryption is on and current column is ssn then try to decrypt that.
										// If somehow decryption fails, then show actual value.
										// for SSN, we use 'ssn' as key to decrypt data
										if(origEncTables.contains(table) && bDecrypt && decryptSSNCols.contains(columnName)) {
											// Check if value is null
											if(colValue == null) {
												result = "";
											} else {
												// Try to peform Decryption
												try {
													// Encrypted data is saved into another column whose name must be column_'ENC' (e.g. if column is ssn, then encrypted data saved in ss_enc column)
													result = crypto.batchDecryptString(encryptionUser,"ssn",rs.getString(columnName+"_ENC"));
												} catch (Exception ex) { 
													log_obj.FmtAndLogMsg(threadName+"WARNING: Column not encrypted or already decrypted, so Fetching Original column Value for Column:  : "+columnName+"  For Table: "+table);	
													// If Decryption Fails, Fetch actual Column's Value
													result = colValue;
												}
											}
											decrypted = true;
										}

										// If decryption is on and current column is bank Account Number then try to decrypt that.
										// If somehow decryption fails, then show actual value.
										else if(origEncTables.contains(table) && bDecrypt && decryptAccCols.contains(columnName)) {
											// Check if value is null
											if(colValue == null) {
												result = "";
											} else {
												// Try to peform Decryption
												try {
													result = crypto.batchDecryptString(encryptionUser,"bank",rs.getString(columnName+"_ENC"));
												} catch (Exception ex) { 
                                                                                                   log_obj.FmtAndLogMsg(threadName+"WARNING: Column not encrypted or already decrypted, so Fetching Original column Value for Column:  : "+columnName+"  For Table: "+table);	
													// If Decryption Fails, Fetch actual Column's Value
													result = colValue;
												}
											}
											decrypted = true;
										}

										// If decryption is on and current column is drivers License then try to decrypt that.
										// If somehow decryption fails, then show actual value.
										else if(origEncTables.contains(table) && bDecrypt && (columnName.equalsIgnoreCase("DRIVER_LICENSE_NUMBER_TXT"))) {
											// Check if value is null
											if(colValue == null) {
												result = "";
											} else {
												// Try to peform Decryption
												try {
													result = crypto.batchDecryptString(encryptionUser,"drivers",rs.getString(columnName+"_ENC"));
												} catch (Exception ex) { 
                                                                                                   log_obj.FmtAndLogMsg(threadName+"WARNING: Column not encrypted or already decrypted, so Fetching Original column Value for Column:  : "+columnName+"  For Table: "+table);	
													// If Decryption Fails, Fetch actual Column's Value
													result = colValue;
												}
											}
											decrypted = true;
										}
									} // End Origenate Decryption

									// E V A L U A T E    D E C R Y P T I O N
									// WE HAVE TO DECRYPT DATA DIFFERENTLY FOR ORIGENATE AND EVALUATE
									// BECAUSE IN EVALUATE WE SAVE ENCRYPTED DATA INTO SAME COLUMNS
									// WHERE AS IN ORIGENATE WE SAVE ENCRYPTED DATA INTO NEW COLUMN AS COLUMNNAME_ENC
									// HERE WE GONNA DECRYPT ACTUAL COLUMN UNLIKE ORIGENATE
									else {
										// If decryption is on and current column is ssn then try to decrypt that.
										// If somehow decryption fails, then show actual value.
										if(evalEncTables.contains(table) && bDecrypt && evalDecryptSSNCols.contains(columnName)) {
											// Check if value is null
											if(colValue == null) {
												result = "";
											} else {
												// Try to peform Decryption
												try {
													result = crypto.batchDecryptString(encryptionUser,"ssn",colValue);
												} catch (Exception ex) { 
                                                                                                   log_obj.FmtAndLogMsg(threadName+"WARNING: Column not encrypted or already decrypted, so Fetching Original column Value for Column:  : "+columnName+"  For Table: "+table);	
													// If Decryption Fails, Fetch actual Column's Value
													result = colValue;
												}
											}
											decrypted = true;
										}

										// If decryption is on and current column is Trade Account Number then try to decrypt that.
										// If somehow decryption fails, then show actual value.
										else if(evalEncTables.contains(table) && bDecrypt && evalDecryptAccCols.contains(columnName)) {
											// Check if value is null
											if(colValue == null) {
												result = "";
											} else {
												// Try to peform Decryption
												try {
													result = crypto.batchDecryptString(encryptionUser,"trade",colValue);
												} catch (Exception ex) { 
                                                                                                   log_obj.FmtAndLogMsg(threadName+"WARNING: Column not encrypted or already decrypted, so Fetching Original column Value for Column:  : "+columnName+"  For Table: "+table);	
													// If Decryption Fails, Fetch actual Column's Value
													result = colValue;
												}
											}
											decrypted = true;
										}

										// If decryption is on and current column is drivers License then try to decrypt that.
										// If somehow decryption fails, then show actual value.
										else if(evalEncTables.contains(table) && bDecrypt && (columnName.equalsIgnoreCase("DRIVERLICENSENUMBER"))) {
											// Check if value is null
											if(colValue == null) {
												result = "";
											} else {
												// Try to peform Decryption
												try {
													result = crypto.batchDecryptString(encryptionUser,"drivers",colValue);
												} catch (Exception ex) { 
                                                                                                   log_obj.FmtAndLogMsg(threadName+"WARNING: Column not encrypted or already decrypted, so Fetching Original column Value for Column:  : "+columnName+"  For Table: "+table);	
													// If Decryption Fails, Fetch actual Column's Value
													result = colValue;
												}
											}
											decrypted = true;
										}

									} // End Evaluate Decryption

									// FETCH VALUES OF COLUMN, WHERE NO ENCRYPTION OPERATION NEEDED
									if(!decrypted) {
										// Check if value is null
										if(colValue == null) {
											result = "";
										} else {
											result = colValue;
										}
									}

									temp_buffer4.setLength(0);
									temp_buffer4.append(result);
									// Put pipe after all but the last column
									if(i < col) {
										temp_buffer4.append("|");
									}
									result = temp_buffer4.toString();

									// NOW WRITING RESULT DATA INTO TEXT FILE
									// If it is one of the _ENC columns to be ignored,
									// then leave it out of the output file. Otherwise,
									// write it to the output file.
									if(!ignoreCols.contains(columnName)) {
										textFileWriter.write(result);
									}
								} // move on to next column
								textFileWriter.write("\r\n");	
							} // move on to next row
						} catch (Exception e) {
							throw e;
						} finally {
							ConnectionUtils.closeSqlObjects(rs, ps, null);
						}

						// now that we've processed all rows and written to file, 
						// we're done with this table
						textFileWriter.close();

						// we want to fetch the date/time on each iteration of the loop rather
						// than just getting it once, so the trailer will have an accurate time
						SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy  hh:mm:ss a");
						trlFileWriter.write(formatter.format(new java.util.Date())+"|"+cnt.toString()+"||0\r\n");
						try { if (trlFileWriter != null) trlFileWriter.close();} catch (Exception e) {e.printStackTrace();}

						log_obj.FmtAndLogMsg(threadName+"EXTRACTING OVER: "+table+ " : "+cnt.toString());
						tryNum = retries + 1; // get out of the for loop

						numTablesProcessed++;
					} catch(Exception e) {
						if(tryNum < retries) { // trying again
							log_obj.FmtAndLogMsg(threadName+"Exception on attempt " + (tryNum + 1) + 
									" out of " + (retries + 1) + 
									". Attempting to process " + table + " table again.");
							log_obj.FmtAndLogMsg(threadName+"Exception: " + selectString + " Error: " + e.toString(), e);
							
							// Open up a new database connection before retrying
							ConnectionUtils.closeConnection(conn);
							conn = DriverManager.getConnection(connectionString, dbUser, dbPass); // get a new connection
						} else { // no retries remaining
							throw e;
						}
					} finally {
						try { if (textFileWriter != null) textFileWriter.close();} catch (Exception e) {e.printStackTrace();}
						try { if (trlFileWriter != null) trlFileWriter.close();} catch (Exception e) {e.printStackTrace();}
					} // end try/catch for retry loop
				} // end retry loop
			} // end loop over tables

			log_obj.FmtAndLogMsg(threadName+"COMPLETE. Num tables processed: " + numTablesProcessed);
		} catch (Exception e) {
			log_obj.FmtAndLogMsg(threadName+"Exception: "+selectString+" Error: "+e.toString(), e); 
		} finally {
			try{
				if(crypto != null) {
					crypto.closeSession();
				}
			} catch(Exception e) {
				log_obj.FmtAndLogMsg(threadName+"Could not close Decryption Session: "+e.toString(), e);
			}
			try { if (textFileWriter != null) textFileWriter.close();} catch (Exception e) {e.printStackTrace();}
			try { if (trlFileWriter != null) trlFileWriter.close();} catch (Exception e) {e.printStackTrace();}
			ConnectionUtils.closeConnection(conn);
			main.decrementThreadCount();
		}
	}

	private String addConditions (Connection conn, String selectString, String tableName) throws Exception {
		String qry = "";
		String res = "";
		Query condQry = new Query(conn);

		StringBuffer temp_buffer = new StringBuffer(selectString);

		try {

			//If there is evaluatorID column in all columns, then select data for current Evaluator
			if(dbName.equals("ORIG") && (transType.equals("FULL") || transType.equals("MNT"))) {
				qry = "select decode(column_name, 'EVALUATOR_ID', ' where TBL.EVALUATOR_ID = ORIGEVALID ',null,'','') as DATA_TYPE " + 
						"FROM user_tab_columns WHERE column_name = 'EVALUATOR_ID' and table_name = ? ";
				condQry.prepareStatement(qry);
				condQry.setString(1, tableName, false);
				condQry.executePreparedQuery();
				while(condQry.next()) {
					res = condQry.getColValue("DATA_TYPE");
					if(res != null && !res.equals("")) {
						res = res.replace("ORIGEVALID", "?");
						keyList.add("ORIGEVALID");
						temp_buffer.append(res);
					}
				}
				qry = "select decode(table_name, " + 
						"'CREDIT_REQUEST_COMMENT', ' or TBL.EVALUATOR_ID is NULL '," + 
						"'AUDIT_CONFIG_MAINTENANCE',' or TBL.TABLE_NAME_TXT like ' || CHR(39) || 'MSTR%' || CHR(39) ||" + 
						"' or TBL.TABLE_NAME_TXT in (' || " + 
						"CHR(39) || 'BUREAU' || CHR(39) || ',' || " + 
						"CHR(39) || 'XREF_ESIGN_STATUS' || CHR(39) || ',' || " + 
						"CHR(39) || 'XREF_MANU_HOUSING_AMENITIES' || CHR(39) || ',' || " + 
						"CHR(39) || 'XREF_MANU_HOUSING_OPTIONS' || CHR(39) || ',' || " + 
						"CHR(39) || 'XREF_POSTED_AUTO_MAKE' || CHR(39) || ',' || " + 
						"CHR(39) || 'XREF_POSTED_RV_MANUFACTURER' || CHR(39) || ',' || " + 
						"CHR(39) || 'XREF_PRODUCT_RULES' || CHR(39) || ',' || " + 
						"CHR(39) || 'XREF_PRODUCT_TAB' || CHR(39) || ',' || " + 
						"CHR(39) || 'XREF_PSM_GROUP_PRODUCT_OLD' || CHR(39) || ',' || " + 
						"CHR(39) || 'XREF_USER_FUNCTION' || CHR(39) || ',' || " + 
						"CHR(39) || 'XREF_VEHICLE_MAKE' || CHR(39) || ',' || " + 
						"CHR(39) || 'XREF_XML_PARAMS' || CHR(39) || ') '," + 
						"null,'','') " + 
						"as DATA_TYPE " + 
						"FROM tabs where table_name = ? ";
				condQry.prepareStatement(qry);
				condQry.setString(1, tableName, false);
				condQry.executePreparedQuery();
				while(condQry.next()) {
					res = condQry.getColValue("DATA_TYPE");
					if(res != null && !res.equals("")) {
						temp_buffer.append(res);
					}
				}
			}
			else if(dbName.equals("EVAL") && transType.equals("FULL")) {
				qry = "select decode(column_name, " + 
						"'APPSEQNO',', EVAPP_SEQNO es '," + 
						"null,'','') as DATA_TYPE " + 
						"FROM user_tab_columns where column_name = 'APPSEQNO' and table_name = ? ";
				condQry.prepareStatement(qry);
				condQry.setString(1, tableName, false);
				condQry.executePreparedQuery();
				if(condQry.next()) { // expecting just one result
					res = condQry.getColValue("DATA_TYPE");
					if(res != null && !res.equals("")) {
						temp_buffer.append(res);
					}
				}
			
				temp_buffer.append(" where 1 = 1 ");
			
				qry = "select decode(column_name, 'CLIENTID',' and TBL.CLIENTID = EVALCLIENTID '," + 
						"'APPSEQNO',' and TBL.APPSEQNO = es.APPSEQNO and es.clientid = EVALCLIENTID '," + 
						"null,'','') as DATA_TYPE " + 
						"FROM user_tab_columns where column_name in ('CLIENTID','APPSEQNO') and table_name = ? ";
				condQry.prepareStatement(qry);
				condQry.setString(1, tableName, false);
				condQry.executePreparedQuery();
				while(condQry.next()) {
					res = condQry.getColValue("DATA_TYPE");
					if(res != null && !res.equals("")) {
						res = res.replace("EVALCLIENTID", "?");
						keyList.add("EVALCLIENTID");
						temp_buffer.append(res);
					}
				}
			}
			else if(dbName.equals("EVAL") && transType.equals("INCR")) {
				qry = "select decode(table_name, 'EVAPP_SEQNO'," + 
						"', EDW_EXTRACT ee where TBL.FESAPPID = to_char(ee.REQUEST_ID) and TBL.CLIENTID = EVALCLIENTID', " + 
						"null, 'This one is null'," + 
						"', EDW_EXTRACT ee, EVAPP_SEQNO es where TBL.APPSEQNO = es.APPSEQNO and es.FESAPPID = " + 
						"to_char(ee.REQUEST_ID) and es.CLIENTID = EVALCLIENTID') " + 
						"as DATA_TYPE FROM tabs where table_name = ? ";
				condQry.prepareStatement(qry);
				condQry.setString(1, tableName, false);
				condQry.executePreparedQuery();
				while(condQry.next()) {
					res = condQry.getColValue("DATA_TYPE");
					if(res != null && !res.equals("")) {
						res = res.replace("EVALCLIENTID", "?");
						keyList.add("EVALCLIENTID");
						temp_buffer.append(res);
					}
				}
			}
			else if(dbName.equals("ORIG") && transType.equals("INCR")) {
				qry = "select decode(table_name, " +

					"'CREDIT_REQ_DECISIONS_PTIDTI'," +
					"', CREDIT_REQ_DECISIONS_EVALUATOR SEQ, EDW_EXTRACT ee where TBL.DECISION_REF_ID = SEQ.DECISION_REF_ID and SEQ.REQUEST_ID = ee.REQUEST_ID AND SEQ.EVALUATOR_ID = ee.EVALUATOR_ID and SEQ.EVALUATOR_ID = ORIGEVALID'," +

					"'CREDIT_REQ_DECISION_REASONS'," + 
					"', CREDIT_REQ_DECISIONS_EVALUATOR SEQ, EDW_EXTRACT ee where TBL.DECISION_REF_ID = SEQ.DECISION_REF_ID and SEQ.REQUEST_ID = ee.REQUEST_ID AND SEQ.EVALUATOR_ID = ee.EVALUATOR_ID and SEQ.EVALUATOR_ID = ORIGEVALID'," +

					"'CREDIT_REQ_DECISION_STIP'," + 
					"', CREDIT_REQ_DECISIONS_EVALUATOR SEQ, EDW_EXTRACT ee where TBL.DECISION_REF_ID = SEQ.DECISION_REF_ID and SEQ.REQUEST_ID = ee.REQUEST_ID AND SEQ.EVALUATOR_ID = ee.EVALUATOR_ID and SEQ.EVALUATOR_ID = ORIGEVALID'," +

					"null,'This one is null'," + 
					
					"', EDW_EXTRACT ee, CREDIT_REQUEST cr2 where TBL.REQUEST_ID = ee.REQUEST_ID and ee.REQUEST_ID = cr2.REQUEST_ID and ee.EVALUATOR_ID = cr2.EVALUATOR_ID and cr2.EVALUATOR_ID = ORIGEVALID') as DATA_TYPE " + 
					"FROM tabs where table_name = ? ";
				condQry.prepareStatement(qry);
				condQry.setString(1, tableName, false);
				condQry.executePreparedQuery();
				while(condQry.next()) {
					res = condQry.getColValue("DATA_TYPE");
					if(res != null && !res.equals("")) {
						res = res.replace("ORIGEVALID", "?");
						keyList.add("ORIGEVALID");
						temp_buffer.append(res);
					}
				}
			}
			else if(dbName.equals("EVAL") && transType.equals("MNT")) {
				qry = "select decode(column_name,'CLIENTID',' where upper(TBL.CLIENTID) = upper(EVALCLIENTID)',null,'','') as DATA_TYPE " +
						"FROM user_tab_columns where column_name = 'CLIENTID' and table_name = ? ";
				condQry.prepareStatement(qry);
				condQry.setString(1, tableName, false);
				condQry.executePreparedQuery();
				while(condQry.next()) {
					res = condQry.getColValue("DATA_TYPE");
					if(res != null && !res.equals("")) {
						res = res.replace("EVALCLIENTID", "?");
						keyList.add("EVALCLIENTID");
						temp_buffer.append(res);
					}
				}
			}

			selectString = temp_buffer.toString();
		} catch (Exception ex) {
			throw ex;
		}

		return selectString;
	} //addConditions End
}
