#!/bin/ksh 

######## Set Variables Here ###############################################################################
export CURRDATE=`date +%Y%m%d%H%M%S`
export NOW=`date +"%m%d%Y"`
export PATH=`pwd`
export ENV=$1
export EDWCONFIG=$2
export LOG=edw.log
export EDWTYPE=$3
export STARTDATE=$4
export ENDDATE=$5


##########################################################################################################

# Set environment variables and classpath's
set_env(){
	ENV_PATH=/opt/origenate/$ENV
	echo ". $ENV_PATH/config/usrconfig.sh"
	. $ENV_PATH/config/usrconfig.sh
	. $ENV_PATH/config/$EDWCONFIG
	echo "done setting variables"
}

###########################################################################################################


#Log file
log_it(){
	LOG_DIR=$ORLOGS
	LOG_FILE=edw.log
	echo "$(date +%c) $*" >> $LOG_DIR/$LOG_FILE
}

#Display it
display_parm(){
	log_it "echo EDW HOME = $EDW_HOME EVALUATOR ID = $ORIGEVALID EVALUATE CLIENTID = $EVALCLIENTID ORACLE_HOME = $ORACLE_HOME EDW_TYPE = $EDWTYPE USE CONTROL = $USECONTROL" 
}

call_edw(){
	export EDWPARAMS=""

	if [[ $EDWNUMTHREADS != "" ]] 
	then
		export EDWPARAMS="$EDWPARAMS -n$EDWNUMTHREADS"
	fi

	if [[ $DBNAME != "" ]] 
	then
		export EDWPARAMS="$EDWPARAMS -s$DBNAME"
	fi

	if [[ $TRANSTYPE != "" ]] 
	then
		export EDWPARAMS="$EDWPARAMS -t$TRANSTYPE"
	fi

	if [[ $TNSENTRY != "" ]] 
	then
		export EDWPARAMS="$EDWPARAMS -T$TNSENTRY"
	fi

	if [[ $CONTR != "" ]] 
	then
		export EDWPARAMS="$EDWPARAMS -c$CONTR"
	fi

	if [[ $USER != "" ]] 
	then
		export EDWPARAMS="$EDWPARAMS -u$USER"
	fi

	if [[ $PASS != "" ]] 
	then
		export EDWPARAMS="$EDWPARAMS -p$PASS"
	fi

	if [[ $EVALCLIENTID != "" ]] 
	then
		export EDWPARAMS="$EDWPARAMS -C$EVALCLIENTID"
	fi

	if [[ $ORDATA != "" ]] 
	then
		export EDWPARAMS="$EDWPARAMS -d$ORDATA"
	fi

	if [[ $ORIGEVALID != "" ]] 
	then
		export EDWPARAMS="$EDWPARAMS -e$ORIGEVALID"
	fi

	if [[ $DECRYPTFLG != "" ]] 
	then
		export EDWPARAMS="$EDWPARAMS -F$DECRYPTFLG"
	fi

	if [[ $STARTDATE != "" ]] 
	then
		export EDWPARAMS="$EDWPARAMS -S$STARTDATE"
	fi

	if [[ $ENDDATE != "" ]] 
	then
		export EDWPARAMS="$EDWPARAMS -E$ENDDATE"
	fi

	if [[ $QUERYID != "" ]] 
	then
		export EDWPARAMS="$EDWPARAMS -q$QUERYID"
	fi

	if [[ $EDWRETRIES != "" ]]
	then
		export EDWPARAMS="$EDWPARAMS -f$EDWRETRIES"
	fi

	if [[ $USECONTROL != "" ]] 
	then
		export EDWPARAMS="$EDWPARAMS -U$USECONTROL"
	fi

	if [[ $USECONTROLDATES != "" ]] 
	then
		export EDWPARAMS="$EDWPARAMS -R$USECONTROLDATES"
	fi

	if [[ $EDWZIP != "" ]] 
	then
		export EDWPARAMS="$EDWPARAMS -Z$EDWZIP"
	fi

	if [[ $EDWFTPHOST != "" ]] 
	then
		export EDWPARAMS="$EDWPARAMS -h$EDWFTPHOST"
	fi

	if [[ $EDWFTPUSER != "" ]] 
	then
		export EDWPARAMS="$EDWPARAMS -r$EDWFTPUSER"
	fi

	if [[ $EDWFTPPWD != "" ]] 
	then
		export EDWPARAMS="$EDWPARAMS -P$EDWFTPPWD"
	fi

	if [[ $EDWFTPKEY != "" ]] 
	then
		export EDWPARAMS="$EDWPARAMS -k$EDWFTPKEY"
	fi

	if [[ $EDWFTPDIR != "" ]] 
	then
		export EDWPARAMS="$EDWPARAMS -D$EDWFTPDIR"
	fi

	if [[ $EDWLANGUAGE != "" ]] 
	then
		export EDWPARAMS="$EDWPARAMS -L$EDWLANGUAGE"
	fi

	if [[ $EDWCOUNTRY != "" ]] 
	then
		export EDWPARAMS="$EDWPARAMS -Y$EDWCOUNTRY"
	fi

	if [[ $EDW_LOG != "" ]] 
	then
		export EDWPARAMS="$EDWPARAMS -l$EDW_LOG"
	fi

	echo $EDWPARAMS
	log_it $EDWPARAMS
	java com.cmsinc.origenate.tool.EDW $EDWPARAMS  >>$ORLOGS/$LOG 2>&1
}

FULL(){
	log_it "Full Extract was asked for.  First Origenate will be extracted and then Evaluate will be extracted."
	FULLORIG
	FULLEVAL
}

FULLORIG(){
	log_it "Starting Process Origenate Full"
	export STARTDATE="NONE"
	export ENDDATE="NONE"
	cd $EDW_HOME
	export DBNAME="ORIG"
	export TRANSTYPE="FULL"
	if [[ $ORIGUSER != "" ]]
	then
		export USER=$ORIGUSER
	fi
	if [[ $ORIGPASS != "" ]]
	then
		export PASS=$ORIGPASS
	fi
	call_edw
}

FULLEVAL(){
	log_it "Starting Process Evaluate Full"
	export STARTDATE="NONE"
	export ENDDATE="NONE"
	cd $EDW_HOME
	export DBNAME="EVAL"
	export TRANSTYPE="FULL"
	export USER=$EVALUSER
	export PASS=$EVALPASS
	call_edw
}

INCR(){
	log_it "Starting Process Origenate Incremental"
	cd $EDW_HOME
	export DBNAME="ORIG"
	export TRANSTYPE="INCR"
	if [[ $ORIGUSER != "" ]]
	then
		export USER=$ORIGUSER
	fi
	if [[ $ORIGPASS != "" ]]
	then
		export PASS=$ORIGPASS
	fi
	call_edw

	log_it "Starting Process Evaluate Incremental"
	cd $EDW_HOME
	export DBNAME="EVAL"
	export TRANSTYPE="INCR"
	export USER=$EVALUSER
	export PASS=$EVALPASS
	call_edw
}

MNT(){
	export STARTDATE="NONE"
	export ENDDATE="NONE"

	log_it "Starting Process Origenate Maintenance"
	cd $EDW_HOME
	export DBNAME="ORIG"
	export TRANSTYPE="MNT"
	if [[ $ORIGUSER != "" ]]
	then
		export USER=$ORIGUSER
	fi
	if [[ $ORIGPASS != "" ]]
	then
		export PASS=$ORIGPASS
	fi
	call_edw

	log_it "Starting Process Evaluate Maintenance"
	cd $EDW_HOME
	export DBNAME="EVAL"
	export TRANSTYPE="MNT"
	export USER=$EVALUSER
	export PASS=$EVALPASS
	call_edw
}


##########################################################################################################################
# Main Logic #

set_env

log_it "Starting EDW Process"

if [ "$IAM" = "$ADMUSER" ];
then
	log_it "Admin user = $IAM"
	log_it "Real user = `who am i | cut -f1 -d' '`"
	display_parm
	$EDWTYPE 
else
	log_it echo "Please login as the admin user and run the script"
	echo "Please login as the admin user and run the script"
	exit
fi
#########################################################################################################################
