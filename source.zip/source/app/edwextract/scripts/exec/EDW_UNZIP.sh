#!/bin/ksh

######## Set Variables Here ###############################################################################
ENV=$1

#FILETYPE = ORIG, EVAL, BOTH
FILETYPE=$2

export CURRDATE=`date +%Y%m%d%H%M%S`
export SHORT_DT=`date +%Y%m%d`
export EDW_NAS=_BVLVAR_EDW_NAS_
export EDW_OUTPUT=/origenate/$ENV/data/edw/statefarm

if [[ $FILETYPE = "ORIG" ]]; then
	echo "Running EDW UnZip for Origenate"
	export ORIG_FILENAME=FULLORIG$SHORT_DT.zip
	/usr/bin/unzip -o $EDW_OUTPUT/$ORIG_FILENAME -d $EDW_NAS/EDW_ORIG
elif [[ $FILETYPE = "EVAL" ]]; then
	echo "Running EDW UnZip for Evaluate"
	export EVAL_FILENAME=FULLEVAL$SHORT_DT.zip
	/usr/bin/unzip -o $EDW_OUTPUT/$EVAL_FILENAME -d $EDW_NAS/EDW_EVAL
elif [[ $FILETYPE = "BOTH" ]]; then
	echo "Running EDW UnZip for Origenate"
	export ORIG_FILENAME=FULLORIG$SHORT_DT.zip
	/usr/bin/unzip -o $EDW_OUTPUT/$ORIG_FILENAME -d $EDW_NAS/EDW_ORIG

	echo "Running EDW UnZip for Evaluate"
	export EVAL_FILENAME=FULLEVAL$SHORT_DT.zip
	/usr/bin/unzip -o $EDW_OUTPUT/$EVAL_FILENAME -d $EDW_NAS/EDW_EVAL
else
	#Param #2 Not supported
	echo "Error Running EDW UnZip.  Unsupport param #2 passed: $FILETYPE"
	exit 1
fi
