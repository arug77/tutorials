###################################################################################
#Please see the EDW Documentation for how to use each of the parameters
#configured below. Most correspond to one of the startup parameters
#to the EDW program. The list below states which startup parameter
#each parameter configured below corresponds to. The EDW documentation
#provides detailed explainations of the usage of each startup
#parameter. 
#A few parameters are marked as only being in a certain build
#and up, like "Origenate 8.8.13 and up". If your environment is lower than
#the build mentioned, remove or comment out the line that sets the parameter.
#
#  Environment Variable     Startup Parameter
#  EDWNUMTHREADS            -n
#  DBNAME                   -s
#  TRANSTYPE                -t
#  TNSENTRY                 -T
#  CONTR                    -c
#  ORIGUSER                 -u  (only used for ORIG extracts)
#  ORIGPASS                 -p  (only used for ORIG extracts)
#  EVALUSER                 -u  (only used for EVAL extracts)
#  EVALPASS                 -p  (only used for EVAL extracts)
#  EVALCLIENTID             -C
#  ORDATA                   -d  (usually set in standard config, not here)
#  ORIGEVALID               -e
#  DECRYPTFLG               -F
#  STARTDATE                -S
#  ENDDATE                  -E
#  QUERYID                  -q
#  EDWRETRIES               -f
#  USECONTROL               -U
#  USECONTROLDATES          -R  (Origenate 8.8.23 and up)
#  EDWZIP                   -Z
#  EDWFTPHOST               -h
#  EDWFTPUSER               -r
#  EDWFTPPWD                -P
#  EDWFTPKEY                -k  (Origenate 8.8.15 and up)
#  EDWFTPDIR                -D
#  EDWLANGUAGE              -L
#  EDWCOUNTRY               -Y  (Origenate 8.8.13 and up)
#  EDW_LOG                  -l
###################################################################################

#Only fill these out if you are not going to set your environment with . ./usrconfig.sh
#export ORDATA=c:/EDW/data
#export ORLOGS=c:/EDW/logs

#Set to this directory
export EDW_HOME=$ORAPPS/edwextract

#EDW log file
export EDW_LOG=$ORLOGS/EDWExtract.log

#Number of threads
export EDWNUMTHREADS="4"

#Type of extract to run. these should be set
#on a per-run basis or the startup script
#should be modified to no longer use these.
export DBNAME="ORIG"
export TRANSTYPE="FULL"

#FTP specific
export EDWFTPHOST="rfapdv04"
export EDWFTPUSER="dev85adm"
#Must be encrypted if DECRYPTFLG is true
export EDWFTPPWD="EAAQApVIJme6YLDM1Ku6atWRyQ=="
export EDWFTPDIR="NONE"
export EDWFTPKEY="NONE"
export EDWZIP="zip"

#Keep this Entry to true, if we need decrypted data
export DECRYPTFLG="true"

#Database Information
export CONTR="cmdb01:1521:CMSIDB2"
export TNSENTRY="(DESCRIPTION=(ADDRESS_LIST=(ADDRESS=(PROTOCOL=tcp)(HOST=cmdb01)(PORT=1521))(ADDRESS=(PROTOCOL=tcp)(HOST=cmdb01)(PORT=1521))(LOAD_BALANCE=ON)(FAILOVER=ON))(CONNECT_DATA=(SERVICE_NAME=CMSIDB2)))"

#Origenate Database Information
export ORIGUSER="ORIGDV87"
#Must be encrypted if DECRYPTFLG is true
export ORIGPASS="EAAQXsWrFLQoSA21naENd67WSg=="

#Evaluate Database Information
export EVALUSER="EVAL_ORIGDV87"
#Must be encrypted if DECRYPTFLG is true
export EVALPASS="EAAQ8+qk+mHaC50eddlOVuNKJQ=="

#Set to the current client
# eValuate's client id
export EVALCLIENTID="prodtest"

#Origenate's evaluator_id
export ORIGEVALID="65"

#Use control file for extract. Set to "y" to use,
#any other string value to not use control file.
export USECONTROL="y"
#Use dates in the MNT and FULL extracts instead
#of UNKNOWN. Set to "y" to use dates, any other
#string value to use UNKNOWN
export USECONTROLDATES="n"

#Start and End date for incremental extract
export STARTDATE="NONE"
export ENDDATE="NONE"

#Configurable selection query id
export QUERYID="NONE"

#Number of times to retry a failed table
export EDWRETRIES="0"

#Two character Language code as defined by ISO639
export EDWLANGUAGE="en"
#Two character Country code as defined by ISO3166
export EDWCOUNTRY="US"

