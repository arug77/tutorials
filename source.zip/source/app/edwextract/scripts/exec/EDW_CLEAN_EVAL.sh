#!/bin/ksh

######## Set Variables Here ###############################################################################
cd /origenate/or_statefarm/data/edw/statefarm/
rm FULLEVAL*
rm TRLRFULLEVAL*
