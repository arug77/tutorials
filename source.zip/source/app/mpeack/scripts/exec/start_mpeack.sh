#!/bin/sh
#
# Process MPE acknowledgement
#


INIFILE=/opt/jrun4/servers/qs60/cfusion-ear/cfusion-war/config/origenate.ini
# Evaluator ID 
EVALID=26 
# Acknowledgement file to be picked from dir
ACKDIR=/opt/origenate/qs50/data/mpe/LT/ 
# Acknowledgement file to be saved to dir
COPYACKDIR=/opt/origenate/qs50/data/mpe/LT/SAVE/ 
# Log file to log status of process - now defined in origenate.ini
# LOGFILE=/opt/origenate/qs50/log/mpeackprocess.log
  

nohup java -classpath .:../lib/common.jar:../lib/ojdbc6.jar com.cmsinc.origenate.tool.MpeAck $INIFILE $EVALID $ACKDIR $COPYACKDIR &
exit 0
