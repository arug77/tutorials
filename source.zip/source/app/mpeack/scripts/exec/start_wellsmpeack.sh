#!/bin/sh
#
# Start MPE acknowledgement process
#

# First parameter is the location of the origenate.ini file e.g.
# /opt/jrun4/servers/qs60/cfusion-ear/cfusion-war/config/origenate.ini

# Second parameter is the evaluator id e.g. 26
################################################################################

TASK="MPE ACK Listener:"

#######################################################################################################################
# $0 shows -ksh if dot scriptname is used in starting script (i.e. ". scriptname.sh a b c")
# Script can not be run in current shell, i.e. do not run using "dot name" 
SCRIPTNAME=${0##*/} # Show what is to the right of last slash, shows everything if no slash found
SCRIPTPATH=${0%/*}  # Full or relative path of script, OR just the script name was used (script is in $PATH)
if [ $SCRIPTNAME = $SCRIPTPATH ]; then
  SCRIPTPATH=""
  SCRIPTPATH=`which $SCRIPTNAME`    # gives full path and script name
  if [ $? != 0 ]; then  ## which command is not in PATH
    echo "`date +'%m/%d/%Y %X'` Startup ERROR! $TASK Can not use \"which\" command in script ($0)"
    return 1
  fi
  SCRIPTPATH=${SCRIPTPATH%/*}   # remove last slash and script name
fi
#######################################################################################################################

########################################################################################################################
#####  Figure out where startup script is, supporting files and directories should be in the same location
#####  If pathname used in start up then that gives us our directory. If not, use which to figure which script is being run.

STARTING_DIR=`pwd`
cd ${SCRIPTPATH}  # Change to MYDIR so that any relative file names are found, as in *.par file
if [ $? != 0 ]; then 
  echo "`date +'%m/%d/%Y %X'` ERROR! $TASK Can not access directory holding script ($SCRIPTNAME)"
  echo "`date +'%m/%d/%Y %X'` ERROR! $TASK Dirname=$SCRIPTPATH"
  return 1
fi
MYDIR=`pwd`  # This ensures full path is used in MYDIR var
if [ ! -d $MYDIR ]; then   ## Should never happen
  echo "`date +'%m/%d/%Y %X'` $TASK ERROR! Problem accessing Import Directory ($MYDIR)."
  echo "`date +'%m/%d/%Y %X'` $TASK ERROR! Problem accessing Import Directory in this script ($SCRIPTNAME)."
  cd $STARTING_DIR >/dev/null
  return 1
fi
cd $STARTING_DIR >/dev/null
#######################################################################################################################

#######################################################################################################################
# Get env vars.  Keep this setting below MYDIR logic, in case PATH changes where it no longer includes this script
if [ x$MPEACK_ENV_VARS != x ]; then
  ENV_VARS=$MPEACK_ENV_VARS
else 
  ENV_VARS=$MYDIR/mpeack_setenv.sh
fi
if [ -r $ENV_VARS ]; then
  . $ENV_VARS
fi
########################################################################################################################

################################################################################
test_process()
{
  if [ -f $PROCESS_FILE ]; then
    if [ ! -r $PROCESS_FILE -o ! -r $PROCESS_FILE ]; then
      echo "Can not read process file: $PROCESS_FILE"
      return 1
    fi
    exec < $PROCESS_FILE
    read PROCESS_PID
    read PROCESS_USER
    read PROCESS_CMD
    if [ x"${PROCESS_USER}" = x -o x"${PROCESS_CMD}" = x ]; then
      return 0   ## Can not validate running processes, presume okay to start
    fi
    ps -fp$PROCESS_PID 2>/dev/null|grep "${PROCESS_USER}.*${PROCESS_CMD}"
    RESULT=$?
    if [ $RESULT = 0 ]; then
      return 1   ## Process is running, NOT okay to start
    fi
    return 0   ## Process is not running
  fi
  return 0   ## Can not validate running processes, presume okay to start
}
################################################################################

PROCESS_FILE=$ORIGLOGS/mpeack.process

test_process
RESULT=$?
if [ $RESULT != 0 ]; then
  echo Process is running.  Use stop script before running start script.
  return $RESULT
fi

touch $PROCESS_FILE
if [ ! -r $PROCESS_FILE ]; then
  echo "ERROR!  Process file is not readable: $PROCESS_FILE"
  return 1
fi

if [ "x${1}" = x -o "x${2}" = x ]; then
  if [ x$MPEACK_INI = x -o x$MPEACK_ID = x ]; then
    echo 'ERROR!  Start script either expects 2 arguments: Arg1="$ORIGCONFIG/*.ini";  Arg2=Evaluator ID'
    echo 'ERROR!  or Start script expects env vars set: $MPEACK_INI and $MPEACK_ID'
    echo 'ERROR!  $MYDIR/mpeack_setenv.sh can be used to set these variables.'
    return 1
  fi
else
  MPEACK_INI="${1}"
  MPEACK_ID="${2}"
fi

if [ ! -r "${MPEACK_INI}" ]; then
  echo "ERROR!  Can not read \"ini\" file: ${MPEACK_INI}"
  return 1
fi

nohup java -classpath .:../lib/common.jar:../lib/ojdbc6.jar:../lib/xalan-2.7.1.jar:../lib/evidl.jar com.cmsinc.origenate.tool.WellsMpeAck ${MPEACK_INI} ${MPEACK_ID} &

CHILD_PID=$!
echo $CHILD_PID>$PROCESS_FILE
whoami>>$PROCESS_FILE
echo "java -classpath ">>$PROCESS_FILE

exit 0
