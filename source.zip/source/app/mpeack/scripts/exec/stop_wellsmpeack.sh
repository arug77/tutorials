#!/bin/sh
#
# Stop MPE acknowledgement process
#

################################################################################
test_process()
{
  if [ -f $PROCESS_FILE ]; then
    if [ ! -r $PROCESS_FILE -o ! -r $PROCESS_FILE ]; then
      echo "Can not read process file: $PROCESS_FILE"
      return 1
    fi
    exec < $PROCESS_FILE
    read PROCESS_PID
    read PROCESS_USER
    read PROCESS_CMD
    if [ x${PROCESS_USER} = x -o x"${PROCESS_CMD}" = x ]; then
      return 0   ## Can not validate running processes, presume okay to start
    fi
    ps -fp$PROCESS_PID 2>/dev/null|grep "${PROCESS_USER} .*${PROCESS_CMD}"
    RESULT=$?
    if [ $RESULT = 0 ]; then
      return 1   ## Process is running, NOT okay to start
    fi
    return 0   ## Process is not running
  fi
  return 0   ## Can not validate running processes, presume okay to start
}
################################################################################

PROCESS_FILE=$ORIGLOGS/mpeack.process

if [ ! -f $PROCESS_FILE ]; then
  touch $PROCESS_FILE
fi
if [ ! -r $PROCESS_FILE ]; then
  echo "ERROR!  Process file is not readable: $PROCESS_FILE"
  return 1
fi

test_process
RESULT=$?
if [ $RESULT != 0 ]; then
  echo Stop process.
  kill $PROCESS_PID
  return $?
else
  echo Process is NOT running.
  return 0
fi

