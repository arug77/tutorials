export MPEACK_INI=$ORIGCONFIG/origenate.ini
export MPEACK_ID=26
. /evaluate/origenate/cfusion/admin/javaset.sh
