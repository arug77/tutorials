/*
 * Created on Jul 7, 2005
 *
 *  To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.cmsinc.origenate.tool;

/**
 * @author quinnb
 *
 *  To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class AckData {
    private String appId;
    private String loanId;
    private String success;
    private String comment;
    private String bookingDate;                
    
    /**
     * Constructor         
     */
    public AckData(){
        appId=null;
        loanId=null;
        success=null;
        comment=null;
        bookingDate=null;
    }
    /**
     * @return Returns the appId.
     */
    public String getAppId() {
        return appId;
    }
    /**
     * @return Returns the bookingDate.
     */
    public String getBookingDate() {
        return bookingDate;
    }
    /**
     * @return Returns the comment.
     */
    public String getComment() {
        return comment;
    }
    /**
     * @return Returns the loanId.
     */
    public String getLoanId() {
        return loanId;
    }
    /**
     * @return Returns the success.
     */
    public String getSuccess() {
        return success;
    }
    /**
     * @param appId The appId to set.
     */
    public void setAppId(String appId) {
        while (appId.startsWith("0")){
            appId=appId.substring(1);
        }
        this.appId = appId;
    }
    /**
     * @param bookingDate The bookingDate to set.
     */
    public void setBookingDate(String bookingDate) {
        this.bookingDate = bookingDate;
    }
    /**
     * @param comment The comment to set.
     */
    public void setComment(String comment) {
        this.comment = comment;
    }
    /**
     * @param loanId The loanId to set.
     */
    public void setLoanId(String loanId) {
        this.loanId = loanId;
    }
    /**
     * @param success The success to set.
     */
    public void setSuccess(String success) {
        this.success = success;
    }

    public String toString(){
        StringBuffer sb=new StringBuffer();
        sb.append("App ID: ").append(appId).append("\r\n");
        sb.append("Loan ID: ").append(loanId).append("\r\n");
        sb.append("Success: ").append(success).append("\r\n");
        sb.append("Comment: ").append(comment).append("\r\n");
        sb.append("Booking Date: ").append(bookingDate);         
        return sb.toString();
    }
}
