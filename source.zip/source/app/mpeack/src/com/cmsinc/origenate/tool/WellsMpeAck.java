/*******************************************************************************
 * Company: First American CMSI 
 * Product: Origenate 
 * Version: Beta 
 * Author: Akash Pandya/Quinn Briggs 
 * 
 * Copyright (c) 2002-2005. All rights reserved
 * 
 * Description: Manages mpe acknowledgments 
 * Check Start_WellsMpeAck.bat file to start this process.
 * 
 * Make sure Start_WellsMpeAck.bat has two params inifile, evaluator_id
 * Check for evaluator.mpe_ack_frequency_num for frequency of program to be run i.g. 30 * min 
 * Check for format of ack file.
 * 
 *  
 ******************************************************************************/
package com.cmsinc.origenate.tool;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FilenameFilter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Timer;
import java.util.TimerTask;

import com.cmsinc.origenate.event.CommentEvents;
import com.cmsinc.origenate.util.DBConnection;
import com.cmsinc.origenate.util.IniFile;
import com.cmsinc.origenate.util.LogMsg;
import com.cmsinc.origenate.util.SendNotification;
import com.cmsinc.origenate.workflow.ApplicationIDs;
import com.cmsinc.origenate.workflow.ApplicationStatusManager;
import com.cmsinc.origenate.cp.mpe.Mpe;

public class WellsMpeAck {
    
    //Set debugger
    private static boolean b_debugger = true;
    
    private Timer timer;
    
    private static java.sql.Connection con;
    
    private static LogMsg log = new LogMsg();
    
    private static String s_log_file = "";
    
    private static String iniFileNm = "";
    
    private static String baseFilePath = "";
    
    private static int evaluatorID = -1;
    
    private static Hashtable vars=new Hashtable();
    
    /** ************************************************************ */
    /* Main method to call ack process */
    /** ************************************************************ */
    public static void main(String argv[]) throws Exception {
        if (argv.length != 0) {
            //Call time out process with ini file
            iniFileNm = argv[0].trim(); //Ini file path and name
            if (argv[1].length() <= 0) {
                throw new Exception("Error in passed arguments no evaluator specified");
            } else {
                evaluatorID = new Integer(argv[1].trim()).intValue(); //evaluator
                // id
            }
        }
        //Create object of timeout process
        new WellsMpeAck();
    }
    
    /** ************************************************************ */
    /* Create DB connection */
    /** ************************************************************ */
    private static void getDBConnection(String s_iniFile) throws Exception {
        
        try {
            //Get ini file values for DB connection
            IniFile ini = new IniFile();
            ini.readINIFile(s_iniFile);
            String s_host = ini.getINIVar("database.host");
            String s_port = ini.getINIVar("database.port");
            String s_sid = ini.getINIVar("database.sid");
            String s_user = ini.getINIVar("database.user");
            String s_password = ini.getINIVar("database.password");
            String sTNSEntry = ini.getINIVar("database.TNSEntry", "");
            s_log_file = ini.getINIVar("logs.mpeack_log_file");
            baseFilePath = ini.getINIVar("mpe.output_dir");
            
            DBConnection DBConnect = new DBConnection();
            log.openLogFile(s_log_file);
      
            //Get DB connection
			if (sTNSEntry.length() == 0) {
				con = DBConnect.getConnection(s_host, s_sid, s_user, s_password, s_log_file, s_port,"");
			} else {
				// use tns entry if available
				con = DBConnect.getConnectionTNS(sTNSEntry, s_user,  s_password, s_log_file);
			}
      
            
        } catch (Exception e) {
            recordError(e, "getDBConnection");
        }
    }
    
    /** ************************************************************ */
    /* Record error */
    /** ************************************************************ */
    private static void recordError(Exception err, String classStr) throws Exception {
        try {
            if (b_debugger) {
                err.printStackTrace();
            }
            log.FmtAndLogMsg("Error in " + classStr + " method of : " + err.toString());
            throw new Exception("Error in " + classStr + " method of : " + err.toString());
        } catch (Exception e) {
            log.FmtAndLogMsg("Error in recordError method of : " + e.toString());
        }
    }
    
    /** ************************************************************ */
    /* Record thread error */
    /** ************************************************************ */
    private void recordThreadError(Exception err, String classStr) {
        try {
            if (b_debugger) {
                err.printStackTrace();
            }
            log.FmtAndLogMsg("Error in " + classStr + " method of : " + err.toString());
            throw new Exception("Error in " + classStr + " method of : " + err.toString());
        } catch (Exception e) {
            log.FmtAndLogMsg("Error in recordError method of : " + e.toString());
        }
    }
    
    /** ************************************************************ */
    /* Gets Timeout process frequency */
    /** ************************************************************ */
    private long getTimeOutProcessFreq() throws Exception {
        
        long ret_timeOutFreq = 0;
        PreparedStatement ps = null;
        ResultSet rs = null;
        String sql = "";
        
        try {
            
            //Select task time out frequency
            sql = " select mpe_ack_frequency_num from evaluator where evaluator_id = ? ";
            
            //Prepare statement to execute
            ps = con.prepareStatement(sql);
            
            ps.setInt(1, evaluatorID);
            
            //Execute statement
            rs = ps.executeQuery();
            
            //Get value of freq.
            if (rs.next()) {
                ret_timeOutFreq = rs.getLong("mpe_ack_frequency_num");
            }
            
        } catch (Exception ex) {
            recordError(ex, "getTimeOutProcessFreq");
        } finally {
            try {
                if (ps != null) {
                    ps.close();
                }
                if (rs != null) {
                    rs.close();
                }
            } catch (Exception e) {
                recordError(e, "getTimeOutProcessFreq");
            }
        }
        //Convert to millisecs
        ret_timeOutFreq = ret_timeOutFreq * 60 * 1000;
        return ret_timeOutFreq;
    }
    
    public String getEvaluatorName(int evaluator_id) throws Exception{
        String sql="";
        String eval_name="";
        PreparedStatement ps=null;
        ResultSet rs=null;        
        try{
            sql="select evaluator_name_txt from evaluator where evaluator_id = ?";
            ps=con.prepareStatement(sql);
            ps.setInt(1,evaluator_id);
            rs=ps.executeQuery();
            if (rs.next()){
                eval_name=rs.getString(1);                
            }
            if (eval_name==null){
                eval_name="";
            }
            eval_name=eval_name.replace(' ','_');
        }
        catch (Exception ex){
            recordError(ex, "getEvaluatorName");
        }
        finally{
            if (rs!=null){
                try{rs.close();}catch (Exception x){}                
            }
            if (ps!=null){
                try{ps.close();}catch (Exception x){}
            }            
        }
        return eval_name;
    }
    
    /**
     * Parse the list of directories to process
     * 
     */
    public ArrayList getAckDirectories() throws Exception{
        
        String sql="";
        PreparedStatement ps=null;
        ResultSet rs=null;
        ArrayList list=new ArrayList();
        try{            
            sql="select mpe_file_name_txt, mpe_type_id from config_mpe c where c.evaluator_id = ? and c.active_flg = 1";
            ps=con.prepareStatement(sql);
            ps.setInt(1, evaluatorID);                                   
            rs=ps.executeQuery();
            
            while (rs.next()){
                String dir=rs.getString(1);
                String mpe_type_id=rs.getString(2);
                if (mpe_type_id==null)
                    mpe_type_id="";
                vars.put("MPE_TYPE",mpe_type_id);
                if (dir!=null && !dir.trim().equals("")){
                    dir=Mpe.getFileDir(Mpe.parseFileName(dir, vars));
                    if (dir!=null && !dir.trim().equals("")){
                        list.add(dir);
                    }
                }
            }
        }
        catch (Exception ex){
            recordError(ex, "getAckDirectories");
        }
        finally{
            if (rs!=null){
                try{rs.close();}catch (Exception x){}                
            }
            if (ps!=null){
                try{ps.close();}catch (Exception x){}
            }            
        }
        // remove duplicates
        HashSet set=new HashSet(list);
        list=new ArrayList(set);
        return list;
    }
    
    /** ************************************************************ */
    /* Schedule a task for each mpe type that executes at specific time */
    /** ************************************************************ */
    public WellsMpeAck() throws Exception {
        try {
            
            timer = new Timer();
            
            //Get db connection
            getDBConnection(iniFileNm);
            
            // Setup parse variables for directory
            vars.put("EVALUATOR_ID",""+evaluatorID);
            vars.put("MPE_OUT_DIR",baseFilePath);
            vars.put("EVALUATOR_NAME",getEvaluatorName(evaluatorID));
            
            // Here we assume that the following vars are only ever part
            // Of the filename, and not part of the dirname. Still, to 
            // ensure that the directory is parsed without error these 
            // blank values are added
            vars.put("CLIENT_APP_ID","");            
            vars.put("SYSDATE","");
            
            // Get list of ack directories
            ArrayList ackDirs=getAckDirectories();
            
            // Add standard XL2 directory
            ackDirs.add(baseFilePath+File.separator+"XL2");
            
            //Get frquency of mpe ack out process execution
            long procFreq = getTimeOutProcessFreq();
            
            //If frequency is not set then do not schedule process
            if (procFreq != 0) {
                
                Timestamp procDt = new java.sql.Timestamp(System.currentTimeMillis());
                timer = new Timer();
                
                for (int i=0; i<ackDirs.size(); i++){
                    log.FmtAndLogMsg("Scheduling MPE ACK Process for: "+ackDirs.get(i));
                }
                //Create thread to manage scheduling
                timer.schedule(new CheckWellsMpeAck(ackDirs), procDt, procFreq);
            } else {
                log.FmtAndLogMsg("Error: Frequecy period is not defined. MPE ack process has not been scheduled...");
                System.out.println("Error: Frequecy period is not defined. MPE ack process has not been scheduled...");
                System.exit(0);
            }
            
        } catch (Exception ex) {
            recordError(ex, "callTimeOut");
            System.exit(0);
        }
    }
    
    /** ************************************************************ */
    /* Thread class for time out task */
    /** ************************************************************ */
    /**
     * @author quinnb
     *
     */
    class CheckWellsMpeAck extends TimerTask {
        private CommentEvents commEvent;
        private ArrayList ackDirs;
        private AckFileFilter ackFileFilter;
        private ApplicationStatusManager appManager;
        
        public CheckWellsMpeAck(ArrayList ackDirs){
            this.ackDirs=ackDirs;
            this.ackFileFilter=new AckFileFilter();
        }
        
        /** ************************************************************ */
        /* Default method of the thread */
        /** ************************************************************ */
        public void run() {
            try {
                //Get db connection; if it is closed
                if (con.isClosed()) {
                    getDBConnection(iniFileNm);                
                }                    
                
                //Create comment obj
                commEvent = new CommentEvents(con, s_log_file);
                appManager = new ApplicationStatusManager(con, log);
                                 
                //Update timeout tasks
                Iterator iter=ackDirs.iterator();
                while (iter.hasNext()){              
                    String ackDir=(String)iter.next();
                    if (!ackDir.endsWith(File.separator))
                        ackDir+=File.separator;
                    processDirectory(ackDir);
                }
                
            } catch (Exception ex) {
                recordThreadError(ex, "run");
            }
            finally{
                if (commEvent != null) {                 
                    commEvent = null;
                }
            }
        }
        
           
        /** ************************************************************ */
        /* Add comments */
        /** ************************************************************ */
        private void addComment(long request_id, Timestamp sysDate, String user_id, String expiredOfferDesc)
        throws Exception {
            try {
                //Add comment
                commEvent.addComment(Long.valueOf(request_id).intValue(), 67, "Acknowledgement", expiredOfferDesc,
                        user_id, null, "");
            } catch (Exception ex) {
                try {
                    con.rollback();
                    recordError(ex, "addComment");
                    log.FmtAndLogMsg("*** All MPE acknowledgement updates were rolled back from last run. Please contact Administrator. ***");
                    // con.close();
                } finally {
                    try {
                        if (commEvent != null) {
                            commEvent = null;
                        }
                        if (con != null) {
                            // con.close();
                        }
                        System.exit(0);
                    } catch (Exception e) {
                        recordError(e, "addComment");
                        log.FmtAndLogMsg("*** All MPE acknowledgement updates were rolled back from last run. Please contact Administrator. ***");
                    }
                }
            }
        }       
        
        /**
         * Updates the task and task group without replacing the previous task group info
         * @param request_id the request id (CREDIT_REQUEST.REQUEST_ID)
         * @param task_id the new task id
         * @param task_group_id the new task group id
         * @param user_id the user making this update
         * @throws Exception
         */
        private void setNewTaskandTaskGroup(long request_id, String task_id, String task_group_id, String user_id)
        throws Exception{
            PreparedStatement ps=null;
            String sql="";
            try{
                sql="update credit_request set task_id=?,task_group_id=?,audit_last_updated_dt=sysdate,audit_updated_user_id='"+user_id+"' where request_id=?";
                ps=con.prepareStatement(sql);
                ps.setString(1, task_id);
                ps.setString(2, task_group_id);
                ps.setLong(3, request_id);
                
                ps.execute();
            }
            catch (Exception e){
                recordError(e, "WellsMpeAck:setNewTaskandTaskGroup");
            }
            finally{
                try{ 
				    if (ps != null)
                    ps.close();
                }
                catch (Exception ex){
                    recordError(ex, "WellsMpeAck:setNewTaskandTaskGroup:finally");
                }
            }
        }
        
        // Removes Mpe Entries so that files can be regenerated
        private void removeMpeEntries(long request_id)
        throws Exception{
            PreparedStatement ps=null;
            String sql="";
            try{
                sql="delete from credit_req_contr_mpe where request_id=?";
                ps=con.prepareStatement(sql);
                ps.setLong(1, request_id);
                
                ps.execute();
            }
            catch (Exception e){
                recordError(e, "WellsMpeAck:removeMpeEntries");
            }
            finally{
                try{
				    if (ps != null)
                    ps.close();
                }
                catch (Exception ex){
                    recordError(ex, "WellsMpeAck:removeMpeEntries:finally");
                }
            }
        }
        
        /**
         * Reads the directory looking for files to process 
         * @param ackDir the directory potentially containing ack files to process
         * @throws Exception
         */
        private void processDirectory(String ackDir) throws Exception{
            // Get file list - file filter ensures only XL1, XL2 or ACK files are found
            // No need to check for dir vs. file
            log.FmtAndLogMsg("Processing "+ackDir);
            File dir=new File(ackDir);
            String[] files=dir.list(ackFileFilter);
            if (files==null){
                log.FmtAndLogMsg("Found 0 files.");
                return;
            }
            
            log.FmtAndLogMsg("Found "+files.length+" file(s).");
            String ackSaveDir=ackDir+"SAVE"+File.separator;
            
            // Look through file list 
            for (int i=0; i<files.length; i++){
                
                // Read file contents and parse
                String filename=ackDir+files[i];
                int extensionIndex=filename.lastIndexOf(".");
                if (extensionIndex==-1){
                    log.FmtAndLogMsg(filename+"Cannot determine file format. File extension missing.");
                    moveFile(filename, ackSaveDir+files[i]);
                    continue;
                }                
                String extension=filename.substring(extensionIndex+1).toLowerCase();
                log.FmtAndLogMsg("Processing file "+filename+" Extension: "+extension);
                AckData ackData=null;
                if (extension.equals("ack")){
                    ackData=parseAckFile(filename);
                }
                else if (extension.equals("xl1")){
                    ackData=parseXl1File(filename);                    
                }
                else if (extension.equals("xl2")){
                    ackData=parseXl2File(filename);
                }
                else {
                    // Assert: this will never happen because the file filter only picks up ack, xl1 and xl2 files
                    log.FmtAndLogMsg("Cannot determine file format. File extension is not ack, xl1 or xl2. File moved to SAVE directory.");
                    moveFile(filename, ackSaveDir+files[i]);
                    continue;
                }
                	
                // Get request id from app id in file                
                long request_id=getRequestId(con, ackData.getAppId());
                Timestamp sysDate = new java.sql.Timestamp(System.currentTimeMillis());

                // Add comment from file
                addComment(request_id, sysDate, ApplicationIDs.sysuser, ackData.getComment());
                
                try{
                    con.setAutoCommit(false);
                    // If success move to next station
                    // If failure move to problem resolution
                    if (ackData.getSuccess().equals("1")){
                        log.FmtAndLogMsg("Processing success acknowledgement for App ID: "+ackData.getAppId()+" Request ID:"+request_id);
                        processSuccess(request_id, extension, ackData);
                    }
                    else if (ackData.getSuccess().equals("2")){
                        log.FmtAndLogMsg("Processing failure acknowledgement for App ID: "+ackData.getAppId()+" Request ID:"+request_id);
                        processFailure(request_id);
                    }
                    else {
                        log.FmtAndLogMsg("Unrecognized success flag value ["+ackData.getSuccess()+"] for AppId: "+ackData.getAppId()+" RequestId: "+request_id);
                    }
                    con.commit();                    
                }
                catch (Exception e){
                    con.rollback();
                    log.FmtAndLogMsg("Exception while updating application status for App Id: "+ackData.getAppId()+" Request ID:"+request_id+": "+e.getMessage());
                    // Files will be moved to SAVE directory in subsequent code...
                }
                finally{
                    con.setAutoCommit(true);
                }
                
                // Move processed file to SAVE location                                
                moveFile(filename, ackSaveDir+files[i]);
                //log.FmtAndLogMsg("Moved "+filename+" to "+ackSaveDir+files[i]);
                
                // Move original data file to SAVE if not xl2 file
                if (!extension.equals("xl2")){
                    // Locate original file.  This may be in another directory.
                    // File name will contain app id (actual file name may vary...)
                    boolean moved=false;
                    for (int j=0; j < ackDirs.size(); j++){
                        String findDir=(String)ackDirs.get(j);                                                
                        if (!findDir.endsWith(File.separator))
                            findDir=findDir+File.separator;
                        File findFileDir=new File(findDir);                        
                        String findSaveDir=findDir+"SAVE"+File.separator;

                        String[] appfiles=findFileDir.list(new AppFileFilter(ackData.getAppId()));
                        if (appfiles!=null && appfiles.length > 0){
                            moveFile(findDir+appfiles[0], findSaveDir+appfiles[0]);
                            log.FmtAndLogMsg("Moved "+findDir+appfiles[0]+" to "+findSaveDir+appfiles[0]);
                            moved=true;
                        }
                    }
                    if (!moved){
                        log.FmtAndLogMsg("No files found for app "+ackData.getAppId());
                    }
                }
                
            }// end look through files
        }// end process directory       
        
        /**
         * Gets the request ID based on the app id
         * @param con A valid connection to the db
         * @param appId The application id read from the acknowledgement file
         * @return long request id
         */
        private long getRequestId(Connection con, String appId){
            PreparedStatement ps=null;
            ResultSet rs=null;
            String sql=null;
            long request_id=-1;
            try{
                sql="select request_id from credit_request where evaluator_id=? and client_app_id=?";
                ps=con.prepareStatement(sql);
                ps.setInt(1, evaluatorID);
                ps.setInt(2, Integer.parseInt(appId));
                rs=ps.executeQuery();
                if (rs.next()){
                    request_id=rs.getLong(1);
                }
            }
            catch (SQLException e){
                log.FmtAndLogMsg("Error while retrieving request_id from client_app_id ["+appId+"]:"+e.getMessage());
            }
            finally{
                if (rs!=null)
                    try{rs.close();}catch (Exception x){}
                if (ps!=null)
                    try{ps.close();}catch (Exception x){}                
            }
            return request_id;
        }
        
        /**
         * Parses an ACK file
         * @param filename the ACK file to read
         * @return AckData structure for this file
         */
        private AckData parseAckFile(String filename){
            AckData ackData=new AckData();
			BufferedReader br = null;
            try{
                br=new BufferedReader(new FileReader(filename));
                // Read to the end of the file and parse the last line
                String data=null;
                String temp=br.readLine();
                while (temp!=null){
                    data=temp;
                    temp=br.readLine();
                }
                br.close();
                if (data==null)
                    throw new Exception();
                ackData.setAppId(data.substring(0,7));
                ackData.setLoanId(data.substring(10,27));
                ackData.setSuccess(data.substring(27,28));
                ackData.setComment(data.substring(28,88).trim());
                ackData.setBookingDate(data.substring(88, 94));                
            }
            catch (Exception e){
                log.FmtAndLogMsg("Unable to process ACK file "+filename+" due to unexpected format.");
            }
			finally {
			    try { if (br != null) br.close();} catch (Exception ex) {ex.printStackTrace();}
			}
            return ackData;
        }
        
        /**
         * Parses an XL1 file
         * @param filename the file to parse
         * @return AckData the parsed acknowledgement data
         */
        private AckData parseXl1File(String filename){
            AckData ackData=new AckData();
			BufferedReader br = null;
            try{
                br=new BufferedReader(new FileReader(filename));                                
                String data=br.readLine();// Assert - each xl1 file is a one line file 
                br.close();
                
                // A loan has a 12 byte app number
                boolean lease=false;
                for (int i=11; i >= 9 && !lease; i--){
                    if (data.charAt(i) < '0' || data.charAt(i) > '9')
                        lease=true;                    
                }
               
                if (lease){ // Lease file
                    log.FmtAndLogMsg("Parsing XL1 as lease.");
                    ackData.setAppId(data.substring(0,7));
                    ackData.setSuccess(data.substring(7,8));
                    ackData.setComment(data.substring(8,73).trim());                                        
                }
                else { // Loan file
                    log.FmtAndLogMsg("Parsing XL1 as loan.");
                    ackData.setAppId(data.substring(0,12));
                    ackData.setSuccess(data.substring(12,13));
                    ackData.setComment(data.substring(13,73).trim());                                        
                }
            }
            catch (Exception e){
                log.FmtAndLogMsg("Unable to process XL1 file "+filename+" due to unexpected format.");
            }
			finally {
				try { if (br != null) br.close();} catch (Exception ex) {ex.printStackTrace();}
			}
            return ackData;
        }

        /**
         * Parses an XL2 file
         * @param filename the file to parse
         * @return AckData the data from the file parse
         */
        private AckData parseXl2File(String filename){
            AckData ackData=new AckData();
			BufferedReader br = null;
            try{
                br=new BufferedReader(new FileReader(filename));                                
                String data=br.readLine();// Assert - each xl2 file is a one line file 
                br.close();
                
                // A loan has a 12 byte app number
                boolean lease=false;
                for (int i=11; i >= 9 && !lease; i--){
                    if (data.charAt(i) < '0' || data.charAt(i) > '9')
                        lease=true;                    
                }
                
                if (lease){ // Lease file
                    log.FmtAndLogMsg("Parsing XL2 as lease.");
                    ackData.setAppId(data.substring(0,7));
                    ackData.setSuccess(data.substring(7,8));
                    ackData.setComment(data.substring(8,87).trim());                    
                    ackData.setLoanId(data.substring(42,59));
                }
                else { // Loan file
                    log.FmtAndLogMsg("Parsing XL2 as loan.");
                    ackData.setAppId(data.substring(0,12));
                    ackData.setSuccess(data.substring(12,13));
                    ackData.setComment(data.substring(13,87).trim());                    
                    ackData.setLoanId(data.substring(49,66));
                }
            }
            catch (Exception e){
                log.FmtAndLogMsg("Unable to process XL2 file "+filename+" due to unexpected format.");
            }
			finally {
				try { if (br != null) br.close();} catch (Exception ex) {ex.printStackTrace();}
			}
            return ackData;
        }        
        
        private void processSuccess(long request_id, String extension, AckData data)
        throws Exception{
            // Successful XL1 requires no action 
            if (extension.equals("xl1"))
                return;            
            // Move to system/done
            setNewTaskandTaskGroup(request_id, ApplicationIDs.tsk_done, ApplicationIDs.tsk_grp_system, ApplicationIDs.sysuser);
            //Set booking to booked
            appManager.setBookingStatus(request_id, 2);
            //Set booking activity to complete
            appManager.setActivityStatus(request_id, ApplicationIDs.tsk_grp_contractadmin, ApplicationIDs.act_booking, ApplicationIDs.act_status_complete, ApplicationIDs.sysuser, -1);
            //Calc new app status
            appManager.setApplicationStatus(request_id, evaluatorID, ApplicationIDs.app_done);
            // Update servicing account number
            appManager.setServicingAccountNumber(request_id, data.getLoanId());
            // Send notification
			try {
            	SendNotification mysender=new SendNotification(con);
            	mysender.sendNotification(request_id);
			}
			catch (Exception e){
                log.FmtAndLogMsg("Send dealer notification failed for request "+request_id+", "+e.toString());
            }
        }
        
        private void processFailure(long requestID)
        throws Exception{
            // move to system/problem resolution                                        
            setNewTaskandTaskGroup(requestID, ApplicationIDs.tsk_problemResolution, ApplicationIDs.tsk_grp_system,ApplicationIDs.sysuser);
            // Set booking to pending
            appManager.setBookingStatus(requestID, 1);
            // Set booking activity to incomplete
            appManager.setActivityStatus(requestID, ApplicationIDs.tsk_grp_contractadmin, ApplicationIDs.act_booking, ApplicationIDs.act_status_incomplete, ApplicationIDs.sysuser, -1);
            // Calc new app status
            appManager.setApplicationStatus(requestID, evaluatorID, ApplicationIDs.app_penbk);

            // Remove mpe entries
            removeMpeEntries(requestID);
            
            //release lock on app
            String sql;
            PreparedStatement ps;
            sql = "delete concurrency_control where request_id = ?  ";
            //Prepare statement to execute
            ps = con.prepareStatement(sql);
            //Set param values
            ps.setLong(1, requestID);
            //Execute statement
            ps.execute();
            //Close statement
            try { if (ps != null) ps.close();} catch (Exception e) {e.printStackTrace();}          
        }
        
        /**
         * Moves a file, renaming the old file if one exists.
         * @param from
         * @param to
         */
        private void moveFile(String from, String to){
            File fromFile=new File(from);
            File toFile=new File(to);            
            try {toFile.delete();}catch (Exception e){}
            boolean test=fromFile.renameTo(toFile);
            log.FmtAndLogMsg("File move from "+fromFile.getPath()+" to "+toFile.getPath()+" was "+(test?"successful":"unsuccessful"));
        }

    }// end CheckWellsMpeAck class
    
   
    /**
     * Filters the file list to include only acknowledgement files
     * @author quinnb
     */
    class AckFileFilter implements FilenameFilter{
        
        public boolean accept(File dir, String name){
        	File f=new File(dir.getPath()+File.separator+name);
            name=name.toLowerCase();                        
            if (f.isDirectory())
                return false;            
            return (name.endsWith("xl1") ||
                    name.endsWith("xl2") ||
                    name.endsWith("ack"));
        }
    }
    
    /**
     * Filters the files to include only those files with the app id in the filename.
     * @author quinnb
     */
    class AppFileFilter implements FilenameFilter{
        
        private String appId;
        
        public AppFileFilter(String appId){
            this.appId=appId;
        }
        
        public boolean accept(File dir, String name){            
            return (name.indexOf(appId)!=-1);
        }
    }
    
}

