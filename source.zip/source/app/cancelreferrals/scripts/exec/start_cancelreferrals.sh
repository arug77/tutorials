
PATH=$PATH:$JAVA_HOME/bin;            export PATH

nohup java -classpath .:../lib/common.jar:../lib/crypto.jar:../lib/ojdbc6.jar com.cmsinc.origenate.tool.CancelReferrals  -i/opt/origenate/or_dev87/config/origenate.ini -e65 >>err.out >>err.out & 
