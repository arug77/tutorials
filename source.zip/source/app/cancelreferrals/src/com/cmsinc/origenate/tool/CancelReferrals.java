/****************************************************************************************************************
	Company: CMSI
    Product: Origenate
    Author: Saima Kanwal

    Description: Cancels referrals after a specified amount of time.
                 Check start.bat file to start this process.
 *******************************************************************************************************************/
package com.cmsinc.origenate.tool;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.*;
import java.sql.Timestamp;


import com.cmsinc.origenate.event.CommentEvents;
import com.cmsinc.origenate.event.JournalEvents;
import com.cmsinc.origenate.util.COLEncrypt;
import com.cmsinc.origenate.util.IniFile;
import com.cmsinc.origenate.util.LogMsg;
import com.cmsinc.origenate.util.PostRequest;
import com.cmsinc.origenate.util.Query;
import com.cmsinc.origenate.util.SQLUpdate;
import com.cmsinc.origenate.workflow.ApplicationStatusManager;
import com.cmsinc.origenate.util.PostRequest;

public class CancelReferrals {

	private static String VERSION = "1.0";

	private String evaluatorID = "";
	private LogMsg log_obj = new LogMsg();;
	private String sHost = "";
	private String sSIDname = "";
	private String sUser = "";
	private String sPass = "";
	private String sPort = "";
	private String sTNSEntry = "";
	private String sIniFile = "";
	private String sHttps_only = "";
	private String sApp_root = "";
	private String protocol = "";
	private String sOrig_server_id = "";
	private int i_dbg_level = 0;
	private IniFile ini = new IniFile();
	private String logFile = "";
	//private CommentEvents comment = null;
	private JournalEvents journal = null;
	//private boolean redirect = false;
	private Connection con = null;
	private Timestamp sysDate = null;
	private int i_timeout_sec = 0;
	private String cf_url="";



	/***************************************************************/
	/*              Main method to call cancel referrals process      */
	/***************************************************************/
	public static void main(String[] args) {
		CancelReferrals cr = new CancelReferrals();
		try {
			cr.run(args);
		}
		catch (Exception e) { 
		}

		System.exit(0);
	}

	public CancelReferrals() {
	}

	public void run(String[] args) throws Exception {
		log(0, "CancelReferrals initializing...");

		GetArgs(args, log_obj);

		String sConStr = "jdbc:oracle:thin:@";
		if (sTNSEntry.length() == 0) {
			sConStr = sConStr + sHost + ":" + sPort + ":" + sSIDname;
		}
		else {
			sConStr = sConStr + sTNSEntry;
			log(0, "Using TNS Entry");
		}

		try {
			// Load Oracle driver
			DriverManager.registerDriver(new oracle.jdbc.OracleDriver());

			log(0, "Connecting to database: " + sConStr);

			sPass = COLEncrypt.sDecrypt(sPass);

			// Connect to the Oracle database
			con = DriverManager.getConnection(sConStr, sUser, sPass);
			sysDate = new java.sql.Timestamp(System.currentTimeMillis());
		}
		catch (Exception e) {
			log(0, "Error connecting to database: " + e.toString(), e);
			throw e;
		}


		try {
			updateCancelReferrals();
		}
		catch (Exception e) {
			log(0, "Error in CancelReferrals: " + e.toString(), e);
		}

		try {
			con.close();
		}
		catch (Exception e1){}

		log(0, "CancelReferrals exiting...");
	}

	private void GetArgs(String args[], LogMsg log_obj) {
		if(args.length > 0) {
			for(int i = 0; i < args.length; i++) {
				if((args[i].charAt(0) != '-') && (args[i].length() > 1)) {
					ShowUsage();
				}

				switch(args[i].charAt(1)) {

				case 'e': //evaluator id
					evaluatorID = args[i].substring(2);
					log(0, "Evaluator ID: " + evaluatorID);
					break;


				case 'i':
					sIniFile = args[i].substring(2);
					log(0, "IniFile is '" + sIniFile + "'");
					try {
						// Read host, user, sid and password from ini file
						ini.readINIFile(sIniFile);

						logFile = ini.getINIVar("logs.cancel_referrals_log_file", "");
						if(logFile.length() > 0) {
							log_obj.openLogFile(logFile);
						}

						log(0, "CancelReferrals version " + VERSION + " initializing...");

						sHost = ini.getINIVar("database.host", "");
						log(0, "Host is '" + sHost + "'");

						sPort = ini.getINIVar("database.port", "");
						log(0, "Port is '" + sPort + "'");

						sUser = ini.getINIVar("database.user", "");
						log(0, "User is '" + sUser + "'");

						sPass = ini.getINIVar("database.password", "");
						// log(0,"Password:"+sPass);

						sSIDname = ini.getINIVar("database.sid", "");
						log(0, "Database (SID name) is '" + sSIDname + "'");

						sTNSEntry = ini.getINIVar("database.TNSEntry", "");
						log(0, "TNS Entry is '" + sTNSEntry + "'");

						// Read https_only, app_root and orig_server_id from ini file						
						sHttps_only = ini.getINIVar("general.https_only", "");
						log(0, "https_only is '" + sHttps_only + "'");

						sApp_root = ini.getINIVar("general.app_root", "");
						log(0, "app_root is '" + sApp_root + "'");

						sOrig_server_id = ini.getINIVar("general.orig_server_id", "");
						log(0, "orig_server_id is '" + sOrig_server_id + "'");

						i_timeout_sec = new Integer(ini.getINIVar("general.evaluate_trans_timeout")).intValue();
						log(0, "i_timeout_sec '" + i_timeout_sec + "'");

						cf_url = ini.getINIVar("urls.eval_app_complete_url", "");
						log(0, "cf_url is '" + cf_url + "'");


					}
					catch(Exception e){
						log(0, "Caught exception reading ini file '" + sIniFile + "': " + e.toString(), e);
					}
					break;


				default:
					log(0, "Unknown parameter: " + args[i]);
					ShowUsage();
					break;
				} // end case
			} // end for loop

			//edits
			if ((sHost.length() == 0) || (sUser.length() == 0)
					|| (sSIDname.length() == 0) || (sPort.length() == 0)) {
				log(0, "Host,User,Pwd,SID or Port not specified in INI file");
				ShowUsage();
			}
			if (evaluatorID.length() == 0) {
				log(0, "-e parm is required");
				ShowUsage();
			}

		} // end if
		else {
			ShowUsage();
		}
	}

	private void ShowUsage() {
		System.out.println();
		System.out.println("Usage: java CancelReferrals -i<inifile>");
		System.out.println("---------------------");
		System.out.println("-e - required: evaluator id");
		System.out.println("-i - required: INI file to use for configuration");
		System.exit(1);
	}

	private void log(int level, String msg) {
		log_obj.FmtAndLogMsg(msg, i_dbg_level, level);
	}

	private void log(int level, String msg, Throwable throwable) {
		log_obj.FmtAndLogMsg(msg, throwable, i_dbg_level, level);
	}

	private void updateCancelReferrals() { 
		log(0, "Executing updateCancelReferrals..");

		PreparedStatement ps = null, ps2 = null, psX = null, psReferralData = null;
		PreparedStatement update = null;
		ResultSet rs = null, rs2 = null, rsX = null, rsReferralData = null;
		String sql = null, sql2 = null, sql_update = null, sqlX = null, sql_ReferralData = null;
		int app_status = 24;
		Long request_id = null;
		Integer client_app_id = null;
		Integer product_id = null;
		Long referralDays = null;
		Timestamp timePeriod = null;

		String network_index = null;
		String destination = null;
		String col_destination = null;
		String postConfigId = null;
		int gateway_flg = 0;
		Integer referred_lender = null;
		String originator_code_txt = null;
		ArrayList<Integer> decEvalIDs = new ArrayList<Integer>();
		try { 
			journal = new JournalEvents(con, null);
		} catch (Exception e) { e.printStackTrace(System.out); }

		sql = "SELECT request_id, client_app_id, product_id FROM credit_request " +
				"WHERE evaluator_id = ? AND app_status_id = ?";

		try {
			ps = con.prepareStatement(sql);
			ps.setInt(1, Integer.valueOf(evaluatorID.trim()));
			ps.setInt(2, app_status);
			rs = ps.executeQuery();

			while (rs.next()) { 
				request_id = rs.getLong("request_id");
				client_app_id = rs.getInt("client_app_id");
				product_id = rs.getInt("product_id");

				log(0, "RID = " + request_id.toString() + ", appId = " + client_app_id.toString() + " is a referred app");

				sql_ReferralData = "SELECT REF_CANCEL_DAYS_NUM " +
						"FROM config_product_settings " +
						"WHERE evaluator_id = ? " +
						"AND product_id = ?";

				psReferralData = con.prepareStatement(sql_ReferralData);
				psReferralData.setInt(1,Integer.valueOf(evaluatorID.trim()));
				psReferralData.setInt(2,product_id);
				rsReferralData = psReferralData.executeQuery();	

				if(rsReferralData.next()) {	
					referralDays = rsReferralData.getLong("REF_CANCEL_DAYS_NUM");
				} else { log(0, "RID = " + request_id.toString() + " Referral Cancellation days is not configured for evaluator_id = " + evaluatorID + ", product_id = " + product_id.toString()); }

				try {rsReferralData.close();} catch (Exception e) {}
				try {psReferralData.close();} catch (Exception e) {}

				if(referralDays != null) {
					log(0, "Delay days for referral cancellation for evaluator_id = " + evaluatorID + ", product_id = " + product_id.toString() + " is configured to be " + referralDays.toString());	
					if(referralDays.longValue() != 0) { 
						// convert time duration into millisecs
						referralDays = referralDays.longValue() * 24 * 60 * 60 * 1000;

						sql_ReferralData = "SELECT journal_dt FROM credit_request_journal " + 
								"WHERE request_id = ? and journal_event_id = 43 " +
								"ORDER BY journal_id DESC";

						psReferralData = con.prepareStatement(sql_ReferralData);
						psReferralData.setLong(1, request_id);
						rsReferralData = psReferralData.executeQuery();

						if(rsReferralData.next()) { 
							timePeriod = new Timestamp(rsReferralData.getTimestamp("journal_dt").getTime() + referralDays);
						}
						try {rsReferralData.close();} catch (Exception e) {}
						try {psReferralData.close();} catch (Exception e) {}

						if (sysDate.after(timePeriod)) { 

							/* verify lock still exists:
			referring to a lender will put a type 2 lock on the app */

							sql2 = "SELECT 1 FROM concurrency_control " + 
									"WHERE request_id = ? " + 
									"AND lock_type_id = 2";

							ps2 = con.prepareStatement(sql2);
							ps2.setLong(1, request_id);
							rs2 = ps2.executeQuery();

							if(rs2.next()) {  
								try { 
									/* Update application status to pending decision (PENDEC) */
									ApplicationStatusManager appStatusMgr = new ApplicationStatusManager(con,log_obj);
									log(0, "RID= " + request_id.toString() + " Setting app status to PENDEC...");
									appStatusMgr.setApplicationStatus(request_id, Integer.valueOf(evaluatorID.trim()), 7);
								} catch (Exception e) { e.printStackTrace(System.out); }


								sqlX = "SELECT DISTINCT decisioning_evaluator_id " +
										"FROM credit_req_decisions_evaluator " + 
										"WHERE request_id = ? " +
										"AND decision_category_id = 4";

								psX = con.prepareStatement(sqlX);
								psX.setLong(1, request_id);
								rsX = psX.executeQuery();

								while(rsX.next()) { 
									PreparedStatement ps3 = null, ps4 = null;
									ResultSet rs3 = null, rs4 = null;
									String sql3 = null, sql4 = null;
									referred_lender = rsX.getInt("decisioning_evaluator_id");
									decEvalIDs.add(referred_lender);

									sql3 = "SELECT network_txt " +    		
											"FROM evaluator " +
											"WHERE evaluator_id = ?";
									ps3 = con.prepareStatement(sql3);
									ps3.setInt(1,Integer.valueOf(evaluatorID.trim()));
									rs3 = ps3.executeQuery();

									if(rs3.next()) { network_index = rs3.getString("network_txt");
									log(0, "RID= " + request_id.toString() + " Network index is " + network_index);}

									try {rs3.close();} catch (Exception e) {}
									try {ps3.close();} catch (Exception e) {}

									sql3 = "SELECT nvl(be_use_gateway_flg,0) as be_use_gateway_flg " +
											"FROM evaluator " +
											"WHERE  evaluator_id = ?";	   
									ps3 = con.prepareStatement(sql3);
									ps3.setInt(1,referred_lender);
									rs3 = ps3.executeQuery();
									if(rs3.next()) { 
										gateway_flg = rs3.getInt("be_use_gateway_flg");

										log(0,  "RID= " + request_id.toString() + " gateway_flg = " + gateway_flg + " for referred_lender = " + referred_lender.toString());

										if(gateway_flg == 1){
											
											sql4 = "SELECT network_txt " +    		
													"FROM evaluator " +
													"WHERE evaluator_id = ?";
											ps4 = con.prepareStatement(sql4);
											ps4.setInt(1, referred_lender);
											rs4 = ps4.executeQuery();
											if(rs4.next()) {
												network_index = rs4.getString("network_txt");
											}
											
											try {rs4.close();} catch (Exception e) {}
											try {ps4.close();} catch (Exception e) {}
											
											sql4 = "select mn.gateway_url_txt, mn.response_url_txt, cnop.post_config_id "
													+ "from mstr_networks mn, config_network_outbound_post cnop "
													+ "where mn.network_txt = ? "
													+ "and mn.active_flg = 1 "
													+ "and mn.network_txt = cnop.network_txt (+) "
													+ "and cnop.evaluator_id (+) = ? "
													+ "and cnop.active_flg (+) = 1 ";
											ps4 = con.prepareStatement(sql4);
											ps4.setString(1,network_index);
											ps4.setInt(2, referred_lender);
											rs4 = ps4.executeQuery();

											if(rs4.next()) { 
												destination = rs4.getString("response_url_txt");
												col_destination = rs4.getString("gateway_url_txt");
												postConfigId = rs4.getString("post_config_id");
												if(postConfigId == null) {
													postConfigId = "";
												}
											}
											try {rs4.close();} catch (Exception e) {}
											try {ps4.close();} catch (Exception e) {}

										} else { 
											if((sHttps_only != "") && sHttps_only.trim().equals(1)) {
												protocol = "https://";
											} else { 
												protocol = "http://";
											}
											destination = "NONE";
											col_destination = protocol + sOrig_server_id + sApp_root + "/postreceive/default.cfm";
											postConfigId = "";
										}				

									}
									try {rs3.close();} catch (Exception e) {}
									try {ps3.close();} catch (Exception e) {}
									log(0, "RID= " + request_id.toString() + " destination = " + destination);
									log(0, "RID= " + request_id.toString() + " col_destination = " + col_destination);

									sql3 = "SELECT eo.ORIGINATOR_CODE_TXT " +
											"FROM   CREDIT_REQUEST_ORIGINATOR cro, EVALUATOR_ORIGINATOR eo " +
											"WHERE  cro.request_id = ? " +
											"AND    cro.originator_id =  eo.originator_id " +
											"AND    cro.evaluator_id = eo.evaluator_id";	   

									ps3 = con.prepareStatement(sql3);
									ps3.setLong(1,request_id);
									rs3 = ps3.executeQuery();	

									if(rs3.next()) { 
										originator_code_txt = rs3.getString("ORIGINATOR_CODE_TXT");
									}
									try {rs3.close();} catch (Exception e) {}
									try {ps3.close();} catch (Exception e) {}

									String addlInfo = "REQUEST_ID," + request_id +
											",CLIENT_APP_ID," + client_app_id +
											",NETWORK," + network_index +
											",COMMENT,Referral has been cancelled due to inactivity by the referral lender" +
											",TARGET_EVALUATOR_ID," + referred_lender +
											",EVALUATOR_ID," + evaluatorID.trim() +
											",ORIGINATOR_ID," + originator_code_txt +
											",DESTINATION," + destination  +
											",NETWORK_TXT,'" + network_index + "'" +
											",COL_DESTINATION," + col_destination  +
											",TRANSACTION_TYPE,AppCommentsRq" + 
											",POST_CONFIG_ID," + postConfigId;

									log(0, "RID= " + request_id.toString() + " Additional Info is " + addlInfo);
									log(0, "RID= " + request_id.toString() + " Sending system comment to referral lender... ");
									sql_update = "INSERT INTO routing_queue(routing_queue_id, request_id, " +
											"queue_priority_num, routing_state_id, " +
											"run_dt, tries_num, additional_data_txt) " +
											"VALUES(ROUTING_QUEUE_SEQ.nextval,?,0,9,sysdate,0,?)";

									update = con.prepareStatement(sql_update);
									update.setLong(1, request_id);
									update.setString(2, addlInfo);

									update.executeUpdate();
									try {update.close();} catch (Exception e) {}

								}
								try {rsX.close();} catch (Exception e) {}
								try {psX.close();} catch (Exception e) {}
								log(0, "RID= " + request_id.toString() + " Making a journal entry for referral cancellation for evaluator_id = " + decEvalIDs.toString());	
								journal.addJournal(Integer.valueOf(request_id.toString()), 51, "Cancel Lender Referrals for evaluator_id = " + decEvalIDs.toString(), "SYSTEM");
								// Move Decision	
								log(0, "RID= " + request_id.toString() + " Moving decision in credit_request...");	

								sql_update = "UPDATE credit_request cr " +
										"SET cr.latest_dec_ref_id = (SELECT Max(decision_ref_id) FROM credit_req_decisions_evaluator crde " + 
										"WHERE crde.request_id = ? and crde.decision_category_id != 4) " +
										"WHERE cr.request_id = ?";
								update = con.prepareStatement(sql_update);
								update.setLong(1, request_id);
								update.setLong(2, request_id);			
								update.executeUpdate();	

								// Delete lender referral decisions
								log(0, "RID= " + request_id.toString() + " Deleting lender referral decisions from CREDIT_REQ_DECISIONS_EVALUATOR...");	

								sql_update = "DELETE CREDIT_REQ_DECISIONS_EVALUATOR " + 
										"WHERE request_id = ? " +
										"AND decision_category_id = 4";

								update = con.prepareStatement(sql_update);
								update.setLong(1, request_id);
								update.executeUpdate();

								log(0, "RID= " + request_id.toString() + " Releasing lock from app...");	

								sql_update = "DELETE concurrency_control " +
										"WHERE request_id = ?";

								update = con.prepareStatement(sql_update);
								update.setLong(1, request_id);
								update.executeUpdate();

								//Calling Rescore
								ArrayList<String> requestorIDList = new ArrayList<String>();
								String str_sql = "SELECT requestor_id, requestor_type_id " +
										"FROM requestor_header " +
										"WHERE request_id = ? AND requestor_id >= 0 " +
										"ORDER BY requestor_type_id desc";
								PreparedStatement reqQuery = con.prepareStatement(str_sql);
								// order by requestor type so that if it is a business, it will be the first record (changing requestor type for id 2 to guarantor instead of cosigner)
								reqQuery.setLong(1, request_id);
								ResultSet reqResultSet = reqQuery.executeQuery();

								while (reqResultSet.next()) {
									requestorIDList.add(reqResultSet.getString("requestor_id"));
								} // while more requestors

								try {reqResultSet.close();} catch (Exception e) {}
								try {reqQuery.close();} catch (Exception e) {}


								// use the RoutingQueue to submit a ReScore request
								String scriptID = "6"; // ReScore
								String touchPointID = "1"; // application complete
								// add entry to evaluate request queue
								Iterator<String> requestorIDListIter = requestorIDList.iterator();

								while (requestorIDListIter.hasNext()) {
									log(0, "RID= " + request_id.toString() + " Calling Rescore:Inserting into evaluate_request_queue for each requestor...");
									StringBuffer erqStringBuf = new StringBuffer();

									erqStringBuf.append("INSERT INTO evaluate_request_queue (");
									erqStringBuf.append("evaluate_request_queue_id, request_id, requestor_id, script_id, comment_txt, user_id, requested_dt, touchpoint_id");
									erqStringBuf.append(") VALUES (");
									erqStringBuf.append("EVALUATE_REQUEST_QUEUE_SEQ.nextval, ?, ?, " + scriptID + ", ?, ?, SYSDATE, " + touchPointID);
									erqStringBuf.append(")");

									PreparedStatement erqps = null;

									try {
										erqps = con.prepareStatement(erqStringBuf.toString());
										erqps.setLong(1, request_id);
										erqps.setInt(2, Integer.parseInt((String) requestorIDListIter.next()));
										erqps.setString(3, "Created by CancelReferrals.java");
										erqps.setString(4, "SYSTEM");
										erqps.execute();
									} catch (Exception e) {
										throw (e);
									} finally {
										try {
											erqps.close();
										} catch (Exception e) {
										}
									}
								}


								String response="";
								String errmsg="";
								String url_temp="";
								boolean errorOccurred=false;
								url_temp = cf_url + request_id.toString() + "&evaluator_id=" + evaluatorID.trim() + "&redecEligFlg=0&calledfrom=CancelReferral"+ "&closeSession=true";
								/*
        For eValuate failover if we get an error on the first try then it means that the primary instance has gone down
        and the evaluatefacade has switched over to the secondary instance for subsequent calls. So, on the second try it should work. If it
        fails on the second try then there is probly only one instance or both are down.
								 */
								/*  Not doing retries because it can cause hangs in evaluate under certain circumstances (as done in RQTools.java in evaluateScoring)*/
								for (int i = 0; i< 2; i++) {
									errorOccurred=false;
									try {
										// Need to time calls to eValuate
										log(0, "RID= " + request_id.toString() + " Calling Rescore: Posting to url= " + url_temp);
										PostRequest postRequest = new PostRequest(log_obj,i_dbg_level);
										response=postRequest.post(url_temp,"",i_timeout_sec);// Get time out sec from INI file
										log(0, "RID= " + request_id.toString() + " Calling Rescore: Done." + url_temp);

										log(0, "RID= " + request_id.toString() + " Response from '"+url_temp+"' was '"+response+"'");
									}
									catch (Exception e) {
										errorOccurred=true;
										errmsg="Error posting to:"+url_temp+"  "+e.toString();
										log(0,"Error posting to:"+url_temp, e);
									}


									if (!errorOccurred && response.indexOf("err_status=0")<0) {
										// error processing page, err msg is in tag <err_message>..</err_message>
										String err="Unknown";
										if (response.indexOf("<err_message>")>=0) {
											try {
												err=response.substring(response.indexOf("<err_message>")+13);
												err=err.substring(0,err.indexOf("</err_message>"));
											}
											catch (Exception e) {err="Unknown";}
										}
										errmsg=err;
										errorOccurred=true;
									} // error returned from CF

									if (!errorOccurred) break; // success on first or second try


									/* Not doing retries because it can cause hangs in evaluate under certain circumstances */
									if (errorOccurred) {
										log(0, "RID= " + request_id.toString() + " Error occurred on first try; not retrying; just returning error; error was: "+errmsg);
										break;
									}

									// errorOccurred, if its the first try then it will try again, if its the second then the loop will break normally

									if (i==0)  {
										log(0, "RID= " + request_id.toString() + "Error occurred on first try; retrying after sleep time of 2 secs; error was: "+errmsg);
										try {Thread.sleep(2000);} catch (Exception e) {}
									}
									else
										log(0, "RID= " + request_id.toString() + "Error occurred on second try; giving up; error was: "+errmsg);
								} // for

								if (errorOccurred) throw new Exception(errmsg);



								log(0, "Referrals have been successfully cancelled for RID = " + request_id.toString());
							} else { log(0, "RID = " + request_id.toString() + " Application is not locked");}
							try {rs2.close();} catch (Exception e) {}
							try {ps2.close();} catch (Exception e) {}
						} else { log(0, "RID = " + request_id.toString() + " Referral is not eligible for cancellation."); } 
					} else { log(0, "RID = " + request_id.toString() + " Referral Cancellation days is either not configured or set to 0 for evaluator_id = " + evaluatorID + ", product_id = " + product_id.toString());}
				} 

				// clear variables

				decEvalIDs.clear();
				request_id = null;
				client_app_id = null;
				product_id = null;
				referralDays = null;
				timePeriod = null;

				network_index = null;
				destination = null;
				col_destination = null;
				gateway_flg = 0;
				referred_lender = null;
				originator_code_txt = null;

			}     		
			try {rs.close();} catch (Exception e) {}
			try {ps.close();} catch (Exception e) {}
		} catch (Exception e) { e.printStackTrace(System.out); }
		finally {
			try{ if(rs != null)rs.close(); } catch(Exception e){e.printStackTrace();}
			try{ if(ps != null)ps.close(); } catch(Exception e){e.printStackTrace();}
			try{ if(rs2 != null)rs.close(); } catch(Exception e){e.printStackTrace();}
			try{ if(ps2 != null)ps.close(); } catch(Exception e){e.printStackTrace();}
			try{ if(rsX != null)rs.close(); } catch(Exception e){e.printStackTrace();}
			try{ if(psX != null)ps.close(); } catch(Exception e){e.printStackTrace();}
			try{ if(rsReferralData != null)rsReferralData.close(); } catch(Exception e){e.printStackTrace();}
			try{ if(psReferralData != null)psReferralData.close(); } catch(Exception e){e.printStackTrace();}
			try{ if(update != null)update.close(); } catch(Exception e){e.printStackTrace();}
		}

	}
}