/*
 * Created on Apr 25, 2005
 * Description: See Clientele #130701
 * This program will concatinate all txt letters that have
 * accumulated through the day as well as the ones created
 * with Nightly Letters, zip it up, FTP it somewhere, and
 * then do a cleanup process to delete the older letters that
 * are no longer needed.  This needs to run on a windows box
 * that has access to the letters and should run about 1 hr after
 * NightlyLetters.  If any FTP parameters are missing from the INI file,
 * the concatenated file will not be FTP'd.
 */
package com.cmsinc.origenate.concatletters;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.FilenameFilter;
import java.io.IOException;
import java.io.OutputStream;
import java.io.ByteArrayInputStream;
import java.sql.Connection;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Enumeration;
import java.util.GregorianCalendar;
import java.util.Hashtable;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import org.apache.commons.net.ftp.*;
import org.apache.commons.net.io.*;
import org.apache.commons.io.*;

import com.cmsinc.origenate.util.COLEncrypt;
import com.cmsinc.origenate.util.DBConnection;
import com.cmsinc.origenate.util.IniFile;
import com.cmsinc.origenate.util.LogMsg;
import com.cmsinc.origenate.util.Query;
import com.cmsinc.origenate.util.SQLUpdate;
import com.cmsinc.origenate.util.OWASPSecurity;
/**
 * @author Chuck Caplan
 */
public class ConcatLetters {

	private LogMsg log = new LogMsg(); // log

	private String evaluator_id;

	private String dbHost; // db settings

	private String dbUser; // db settings

	private String dbPass; // db settings

	private String dbPort; // db settings

	private String dbSID; // db settings

	private String sTNSEntry; // db settings
	
	private Connection con; // db settings

	private String ftpServer; // ftp settings

	private String ftpUser; // ftp settings

	private String ftpPass; // ftp settings

	private String ftpDir; // ftp settings

	private boolean zip; // whether or not to zip the file.

	private String localFile; // location of concatenated file.

	private String concatDir; // location of the files to be concatenated

	private String header; // header

	private String fixedTrailerBeginning; // trailer beginning

	private boolean showSummary; // Whether or not to show the summary at the

	// end of the file

	private int cleanupDays; // number of days to keep backed up files

	private String backupDir; // dir where backed up files go

	Hashtable docs = new Hashtable();

	int numdocs = 0;

	public static void main(String[] args) {
		if (args.length != 1) {
			showUsageAndExit();
		}
		ConcatLetters cl = new ConcatLetters();
		// read INI file or DB to find information about which files to read.
		String iniFile = args[0];
		cl.init(iniFile);

		// run the program only if the active flag in the INI is true
		cl.addHeader();
		cl.concatenateFiles();
		cl.addTrailer();

		if (cl.zip) {
			cl.zipFile();
		}

		try {
			cl.ftpFile();
		} catch (IOException e) {
			cl.log.FmtAndLogMsg("Error FTP'ing File - " + e, e);
		}

		cl.cleanupFiles();
		cl.log.FmtAndLogMsg("\n\n*****ENDING ConcatLetters - " + new Date()
				+ "*****");
		cl.log.closeLogFile();
	}

	public static void showUsageAndExit() {
		System.out
				.println("Usage: java com.cmsinc.origenate.concatletters.ConcatLetters <INI Location>");
		System.exit(0);
	}

	public void init(String iniFile) {
		IniFile ini = new IniFile();
		try {
			
			ini.readINIFile(iniFile);
			// log location
			String s_log_file = ini.getINIVar("log.logLocationAndName", ""); 
			log.openLogFile(s_log_file);

			log
					.FmtAndLogMsg("\n\n*****ConcatLetters - " + new Date()
							+ "*****");
			log.FmtAndLogMsg("logLocationAndName - "
					+ ini.getINIVar("log.logLocationAndName").trim());

			log.FmtAndLogMsg("iniFile - " + iniFile);

			evaluator_id = ini.getINIVar("general.evaluator_id").trim();
			log.FmtAndLogMsg("evaluator_id - " + evaluator_id);

			// connect to the DB
			dbHost = ini.getINIVar("database.host", "").trim();
			log.FmtAndLogMsg("dbHost - " + dbHost);
			dbPort = ini.getINIVar("database.port", "").trim();
			log.FmtAndLogMsg("dbPort - " + dbPort);
			dbUser = ini.getINIVar("database.user", "").trim();
			log.FmtAndLogMsg("dbUser - " + dbUser);
			dbPass = ini.getINIVar("database.password", "").trim();
			dbSID = ini.getINIVar("database.sid", "").trim();
			log.FmtAndLogMsg("dbSID = " + dbSID);
			sTNSEntry = ini.getINIVar("database.TNSEntry", "");
			log.FmtAndLogMsg("TNS Entry = " + sTNSEntry);

			try {
				DBConnection DBConnect = new DBConnection();

				if (sTNSEntry.length() == 0) {
					con = DBConnect.getConnection(dbHost, dbSID, dbUser, dbPass, s_log_file, dbPort,"");
				} else {
					// use tns entry if available
					con = DBConnect.getConnectionTNS(sTNSEntry, dbUser,  dbPass, s_log_file);
				}
			} 
			catch (Exception e) {
				log.FmtAndLogMsg("Error connecting to database: "+ e.toString(), e);
			}
			
			log.FmtAndLogMsg("Connected to DB");
			zip = Boolean.valueOf(ini.getINIVar("general.zipFiles").trim())
					.booleanValue();
			log.FmtAndLogMsg("zip - " + zip);

			try {
				ftpServer = ini.getINIVar("ftp.ftpServer").trim();
				log.FmtAndLogMsg("ftpServer - " + ftpServer);
				ftpUser = ini.getINIVar("ftp.ftpUser").trim();
				log.FmtAndLogMsg("ftpUser - " + ftpUser);
				ftpPass = ini.getINIVar("ftp.ftpPass").trim();
				ftpDir = ini.getINIVar("ftp.ftpDir").trim();
				log.FmtAndLogMsg("ftpDir - " + ftpDir);
			} catch (Exception e) {
				log
						.FmtAndLogMsg("Some or all FTP values were not found in the INI file.  The concatenated file will not be FTP'd.", e);
			}

			// concat dir
			concatDir = ini.getINIVar("general.concatDir").trim();
			if (concatDir.charAt(concatDir.length() - 1) != '\\') {
				concatDir = concatDir + "\\";
			}
			log.FmtAndLogMsg("concatDir - " + concatDir);
			// concat into what file
			localFile = ini.getINIVar("general.localFile").trim();
			// add .yymmdd to the end of the file
			Date d = new Date();
			SimpleDateFormat sdf = new SimpleDateFormat("yy");
			String yy = sdf.format(d);
			sdf = new SimpleDateFormat("MM");
			String mm = sdf.format(d);
			sdf = new SimpleDateFormat("dd");
			String dd = sdf.format(d);
			localFile = localFile + "." + yy + mm + dd;
			log.FmtAndLogMsg("localFile - " + localFile);

			// header
			try {
				header = ini.getINIVar("general.header").trim();
			} catch (Exception e) {
				header = null;
			}
			log.FmtAndLogMsg("header - " + header);
			// trailer
			try {
				fixedTrailerBeginning = ini.getINIVar(
						"general.fixedTrailerBeginning").trim();
			} catch (Exception e) {
				fixedTrailerBeginning = null;
			}
			log
					.FmtAndLogMsg("fixedTrailerBeginning - "
							+ fixedTrailerBeginning);

			showSummary = Boolean.valueOf(ini.getINIVar("general.showSummary")
					.trim()).booleanValue();
			log.FmtAndLogMsg("showSummary - " + showSummary);

			// number of days to hold files in backup before deleting
			// default is -1, i.e. never delete
			try {
				cleanupDays = (int) Integer.parseInt(ini.getINIVar(
						"general.cleanupDays").trim());
			} catch (Exception f) {
				cleanupDays = -1;
			}

			// backup directory
			backupDir = ini.getINIVar("general.backupDir").trim();
			if (backupDir.charAt(backupDir.length() - 1) != '\\') {
				backupDir = backupDir + "\\";
			}
		} catch (Exception e) {
			System.out.println("Error in init() method.  Exiting - " + e);
			e.printStackTrace();
			System.exit(-1);
		}
	}

	public void addHeader() {
		if (header != null && !header.trim().equals("")) {
			header = header + "\n\n";
			try {
				log.FmtAndLogMsg("Adding header - " + header);
				
				/** OWASP Top 10 2010 - A4 path manipluation
				 * Change to the below code to fix vulnerabilities
				 * TTP 324955
				 */
				//BufferedWriter out = new BufferedWriter(new FileWriter(localFile, true));
				BufferedWriter out=null;
				try
				{
				out = new BufferedWriter(new FileWriter(OWASPSecurity.validationCheck(localFile, OWASPSecurity.DIRANDFILE), true));
				}
				catch(Exception e)
				{
					e.printStackTrace();
				}
				out.write(header);
				out.close();
				log.FmtAndLogMsg("Finished adding header");
			} catch (IOException e) {
				log.FmtAndLogMsg("Error adding header - " + e, e);
			}
		}
	}

	public void concatenateFiles() {
		
		/**OWASP Top 10 2010 -A4 path  manipluation
		 * Change to the below code to fix vulnerabilities
		 * TTP 324955
		 */
		//File dir = new File(concatDir);
		File dir=null;
		try
		{
		 dir = new File(OWASPSecurity.validationCheck(concatDir, OWASPSecurity.DIRANDFILE));
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		// make sure only the files that need to be in the list show up.
		concatFilter filter = new concatFilter();
		filter.setEvaluator_id(evaluator_id);
		filter.setLocalFile(localFile);
		String[] files = dir.list(filter);
		int numfiles = files.length;
		for (int i = 0; i < numfiles; i++) {
			try {
				int batch_job_id = 0;
				try {
					batch_job_id = (int) Integer.parseInt(files[i].substring(
							files[i].indexOf("batch_") + 6, files[i]
									.indexOf("job_") - 1));
				} catch (Exception e) {
					log
							.FmtAndLogMsg("Error getting batch ID, setting it to 0 for "
									+ files[i] + " - " + e, e);
				}
				int job_id = (int) Integer.parseInt(files[i].substring(files[i]
						.lastIndexOf("_") + 1, files[i].length() - 4));
				
				/** OWASP Top 10 2010 - A4 path manipluation
				 * Change to the below code to fix vulnerabilities
				 * TTP 324955
				 */
				//FileInputStream f = new FileInputStream(concatDir + files[i]);
				FileInputStream f=null;
				try
				{
				 f = new FileInputStream(OWASPSecurity.validationCheck(concatDir + files[i], OWASPSecurity.DIRANDFILE));
				}
				catch(Exception e)
				{
					e.printStackTrace();
				}
				int len = f.available();
				StringBuffer filecontents = new StringBuffer();
				for (int j = 0; j < len; j++) {
					char read = (char) f.read();
					if (read != 13) {
						filecontents = filecontents.append(read);
					}
				}

				/** OWASP Top 10 2010 - A4 path manipluation
				 * Change to the below code to fix vulnerabilities
				 * TTP 324955
				 */
				//BufferedWriter out = new BufferedWriter(new FileWriter(localFile, true));
				BufferedWriter out=null;
				try
				{
				 out = new BufferedWriter(new FileWriter(OWASPSecurity.validationCheck(localFile, OWASPSecurity.DIRANDFILE), true));
				}
				catch(Exception e)
				{
					e.printStackTrace();
				}		
				out.write(filecontents.toString() + "\n");
				out.close();
				f.close();
				log.FmtAndLogMsg("File " + files[i] + ": concatenated");
				
				/** OWASP Top 10 2010 - A4 path manipluation
				 * Change to the below code to fix vulnerabilities
				 * TTP 324955
				 */
				//File delFile = new File(concatDir + files[i]);
				File delFile=null;
				try
				{
				delFile = new File(OWASPSecurity.validationCheck(concatDir, OWASPSecurity.DIRANDFILE) + files[i]);
				}
				catch(Exception e)
				{
					e.printStackTrace();
				}
				boolean isDeleted = delFile.delete();
				log.FmtAndLogMsg("File " + files[i] + " deleted: " + isDeleted);
				delFile = null;
				String docID = getDocID(job_id, batch_job_id);
				try {
					docs.put(docID, Integer.valueOf((((Integer) docs.get(docID))
							.intValue()) + 1));
				} catch (Exception e) {
					docs.put(docID, Integer.valueOf(1));
				}
				numdocs++;

				// Set the credit_req_doc_history status to "Success"
				update_credit_req_doc_history(job_id, batch_job_id);

				// Delete the entry from the printfax_queue table
				delete_from_printfax_queue(job_id, batch_job_id);
			} catch (IOException e) {
				log.FmtAndLogMsg("Error concatenating file " + files[i] + " - "
						+ e, e);
			}
		}
		concatDir = null;
	}

	public void addTrailer() {
		if (fixedTrailerBeginning != null
				&& !fixedTrailerBeginning.trim().equals("")) {
			fixedTrailerBeginning = fixedTrailerBeginning + "\n\n";
			try {
				log.FmtAndLogMsg("Adding trailer - " + fixedTrailerBeginning);
				
				/** OWASP Top 10 2010 - A4 path manipluation
				 * Change to the below code to fix vulnerabilities
				 * TTP 324955
				 */
				//BufferedWriter out = new BufferedWriter(new FileWriter(localFile, true));
				BufferedWriter out =null;
				try
				{
				out = new BufferedWriter(new FileWriter(OWASPSecurity.validationCheck(localFile, OWASPSecurity.DIRANDFILE), true));
				}
				catch(Exception e)
				{
					e.printStackTrace();
				}		
				out.write(fixedTrailerBeginning);
				out.close();
				log.FmtAndLogMsg("Finished Adding Trailer");
			} catch (IOException e) {
				log.FmtAndLogMsg("Error adding trailer - " + e, e);
			}
		}
		if (showSummary) {
			String summary = getSummary();
			try {
				log.FmtAndLogMsg("Adding summary");
				
				/** OWASP Top 10 2010 - A4 path manipluation
				 * Change to the below code to fix vulnerabilities
				 * TTP 324955
				 */
				//BufferedWriter out = new BufferedWriter(new FileWriter(localFile, true));
				BufferedWriter out=null;
				try
				{
				 out = new BufferedWriter(new FileWriter(
						OWASPSecurity.validationCheck(localFile, OWASPSecurity.DIRANDFILE), true));
				}
				catch(Exception e)
				{
					e.printStackTrace();
				}		
				out.write(summary);
				out.close();
				log.FmtAndLogMsg("Finished Adding Summary");
			} catch (IOException e) {
				log.FmtAndLogMsg("Error adding summary - " + e, e);
			}
		} else {
			log
					.FmtAndLogMsg("Showing the summary was not selected so it is not being added to the file");
		}
	}

	public String getSummary() {
		Date date = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yy");
		String today = sdf.format(date);
		String strReturn = "RUN DATE: " + today;
        StringBuilder temp_builder = new StringBuilder(strReturn);
		Enumeration keys = docs.keys();

		while (keys.hasMoreElements()) {
			Object key = keys.nextElement();
			Object value = docs.get(key);
            temp_builder.append("\n\nLETTER TYPE: ");
            temp_builder.append((String) key);
            temp_builder.append("\tTOTAL Generated: ");
            temp_builder.append(((Integer) value).intValue());
		}

        temp_builder.append("\n\nGRAND TOTAL: ");
        temp_builder.append(numdocs);
		
        strReturn = temp_builder.toString();
		// strReturn = strReturn + "\n\nLetter Sequence No. From: 2,442\n\nTo:
		// 2,445";
		return strReturn;
	}

	public void zipFile() {
		// Create a buffer for reading the files
		byte[] buf = new byte[1024];
		FileInputStream in = null;
		try {
			log.FmtAndLogMsg("Trying to zip file" + localFile + ".zip");
			// Create the ZIP file
			
			/** OWASP Top 10 2010 - A4 path manipluation
			 * Change to the below code to fix vulnerabilities
			 * TTP 324955
			 */
			//ZipOutputStream out = new ZipOutputStream(new FileOutputStream(localFile + ".zip"));
			ZipOutputStream out=null;
			try
			{
			 out = new ZipOutputStream(new FileOutputStream(OWASPSecurity.validationCheck(localFile, OWASPSecurity.DIRANDFILE) + ".zip"));
			// Compress the file
		    //in = new FileInputStream(localFile);
			in = new FileInputStream(OWASPSecurity.validationCheck(localFile, OWASPSecurity.DIRANDFILE));
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			// Add ZIP entry to output stream.
			out.putNextEntry(new ZipEntry(getFileName(localFile)));
			// Transfer bytes from the file to the ZIP file
			int len;
			while ((len = in.read(buf)) > 0) {
				out.write(buf, 0, len);
			}
			// Complete the entry
			out.closeEntry();
			in.close();
			// Complete the ZIP file
			out.close();
			log.FmtAndLogMsg("Finished Zipping File");
			
			/** OWASP Top 10 2010 - A4 path manipluation
			 * Change to the below code to fix vulnerabilities
			 * TTP 324955
			 */
			//File file = new File(localFile);
			File file=null;
			try
			{
			 file = new File(OWASPSecurity.validationCheck(localFile, OWASPSecurity.DIRANDFILE));
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			log.FmtAndLogMsg("Deleted localfile " + localFile + ": "
					+ file.delete());
			localFile = localFile + ".zip";
			file = null;
		} catch (IOException e) {
			log.FmtAndLogMsg("Error zipping file - " + e, e);
		}
		finally {
		    try{ if(in != null) in.close(); }catch(Exception e1){e1.printStackTrace();}
		}
	}

	public void ftpFile() throws IOException {
		if (ftpDir != null && ftpPass != null && ftpServer != null
				&& ftpUser != null && !ftpDir.trim().equals("")
				&& !ftpUser.trim().equals("") && !ftpPass.trim().equals("")
				&& !ftpServer.trim().equals("")) {
			File F = new File(getFileName(localFile));
			FTPClient ftp = new FTPClient();
			ftp.connect(ftpServer, 21);
		//	FtpClient ftp = FtpClient.create(ftpServer);
			ftp.login(ftpUser, COLEncrypt.sCfgPwdDecrypt(ftpPass) );
			log.FmtAndLogMsg("Logged into FTP server " + ftpServer);
			log.FmtAndLogMsg("Welcome Msg - " + ftp.getReplyString());
			ftp.changeWorkingDirectory(ftpDir);
			if (zip) {
				log.FmtAndLogMsg("Setting Binary Mode");
				ftp.setFileType(FTP.BINARY_FILE_TYPE);
				ftp.setFileTransferMode(FTP.BINARY_FILE_TYPE);
			}
			log.FmtAndLogMsg("Uploading File");
			ByteArrayInputStream bais;
		//	OutputStream os = ftp.putFileStream(getFileName(localFile));
		//	BufferedOutputStream bos = new BufferedOutputStream(os);
			
			/** OWASP Top 10 2010 - A4 path manipluation
			 * Change to the below code to fix vulnerabilities
			 * TTP 324955
			 */
			//FileInputStream is = new FileInputStream(localFile);
		//	FileInputStream is=null;
			try
			{
			OWASPSecurity.validationCheck(getFileName(localFile), OWASPSecurity.DIRANDFILE);
		//	is = new FileInputStream(OWASPSecurity.validationCheck(localFile, OWASPSecurity.DIRANDFILE));
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}			
		/*	BufferedInputStream bis = new BufferedInputStream(is);
			byte[] buffer = new byte[1024];
			int readCount;
			while ((readCount = bis.read(buffer)) > 0) {
				bos.write(buffer, 0, readCount);
			}
		*/
			bais = new ByteArrayInputStream(FileUtils.readFileToByteArray(F));
			ftp.storeFile(getFileName(localFile), bais);
		/*	bos.close();
			bis.close();
			os.close();
			is.close();
		*/
			bais.close();
			log.FmtAndLogMsg("Finished Uploading File");
			// ftp.closeServer(); //Commented out because it made the app hang
			ftp.logout();
			ftp.disconnect();
			ftp = null;
			log.FmtAndLogMsg("Finished FTPing file");
		}
	}

	public void update_credit_req_doc_history(int job_id, int batch_job_id) {
		try {
			SQLUpdate.RunUpdateStatement(con,
					"UPDATE CREDIT_REQ_DOC_HISTORY SET STATUS_ID = 'SUCCESS' WHERE JOB_ID = "
							+ job_id + " AND BATCH_JOB_ID = " + batch_job_id
							+ " AND EVALUATOR_ID = " + evaluator_id);
			log
					.FmtAndLogMsg("Updated row in CREDIT_REQ_DOC_HISTORY with job_id of "
							+ job_id + " and batch_job_id of " + batch_job_id);
		} catch (Exception e) {
			log
					.FmtAndLogMsg("Error updating row in CREDIT_REQ_DOC_HISTORY with job_id of "
							+ job_id
							+ " and batch_job_id of "
							+ batch_job_id
							+ " - " + e, e);
		}
	}

	public void delete_from_printfax_queue(int job_id, int batch_job_id) {
		try {
			SQLUpdate.RunUpdateStatement(con,
					"DELETE FROM PRINTFAX_QUEUE WHERE JOB_ID = " + job_id
							+ " AND BATCH_JOB_ID = " + batch_job_id
							+ " AND EVALUATOR_ID = " + evaluator_id);
			log.FmtAndLogMsg("Deleted row in PRINTFAX_QUEUE with job_id of "
					+ job_id + " and batch_job_id of " + batch_job_id);
		} catch (Exception e) {
			log
					.FmtAndLogMsg("Error deleting row in PRINTFAX_QUEUE with job_id of "
							+ job_id
							+ " and batch_job_id of "
							+ batch_job_id
							+ " - " + e, e);
		}
	}

	public void cleanupFiles() {
		// cleanup files older than 1 month
		/*
		 * Cleanup the files on disk - i.e. move them to a backup location for
		 * some number of days and then remove files from the backup location
		 * once they are older than n days.
		 */
		log.FmtAndLogMsg("Beginning cleanup of files");
		// move local file to backup dir
		
		/** OWASP Top 10 2010 - A4 path manipluation
		 * Change to the below code to fix vulnerabilities
		 * TTP 324955
		 */
		//File file = new File(localFile);
		File file=null;
		try
		{
		file = new File(OWASPSecurity.validationCheck(localFile, OWASPSecurity.DIRANDFILE));
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		// Destination directory
		
		//File dir = new File(backupDir);
		File dir=null;
		try
		{
		 dir = new File(OWASPSecurity.validationCheck(backupDir, OWASPSecurity.DIRANDFILE));
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		// Move file to new directory
		boolean success = file.renameTo(new File(dir, file.getName()));
		if (!success) {
			log.FmtAndLogMsg("Error moving " + localFile + " to " + backupDir);
		} else {
			log.FmtAndLogMsg("Successfully moved " + localFile + " to "
					+ backupDir);
		}
		file = null; // no longer needed
		dir = null; // no longer needed
		if (cleanupDays >= 0) {
			// get list of all files in backup dir
			
			/** OWASP Top 10 2010 - A4 path manipluation
			 * Change to the below code to fix vulnerabilities
			 * TTP 324955
			 */
			//File flBackupDir = new File(backupDir);
			File flBackupDir=null;
			try
			{
			flBackupDir = new File(OWASPSecurity.validationCheck(backupDir, OWASPSecurity.DIRANDFILE));
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}	
					String[] backupFiles = flBackupDir.list();
			for (int i = 0; i < backupFiles.length; i++) {
				File backupFile = new File(flBackupDir.getAbsolutePath() + "\\"
						+ backupFiles[i]);
				Date lastModified = new Date(backupFile.lastModified());
				GregorianCalendar gc = new GregorianCalendar();
				gc.add(Calendar.DATE, 0 - cleanupDays);
				Date cleanupDate = gc.getTime();
				if (cleanupDate.after(lastModified)) {
					log.FmtAndLogMsg("Deleted file " + backupFiles[i] + ": "
							+ backupFile.delete());
				}
				backupFile = null;
			}
			flBackupDir = null;
		} else {
			log.FmtAndLogMsg("Not deleting any files since cleanupDays = "
					+ cleanupDays);
		}
		log.FmtAndLogMsg("Ended cleanup of files");
	}

	public String getDocID(int job_id, int batch_job_id) {
		Query query = new Query(con);
		try {
			String select = "SELECT * FROM PRINTFAX_QUEUE WHERE JOB_ID = ? "
					+ " AND BATCH_JOB_ID = ? " 
					+ " AND EVALUATOR_ID = ? ";
			query.prepareStatement(select);
			query.setInt(1, job_id);
			query.setInt(2, batch_job_id);
			query.setInt(3, evaluator_id);
			query.executePreparedQuery();
			while (query.next())
				return query.getColValue("DOCUMENT_ID");
		} catch (Exception e) {
			log.FmtAndLogMsg("Error retrieving DOCUMENT ID for job " + job_id
					+ " with batch_job_id of " + batch_job_id + " Error: " + e, e);
			return "UNKNOWN";
		}
		return "UNKNOWN2";
	}

	public String getFileName(String file) {
		return file.substring(file.lastIndexOf("\\") + 1, file.length());
	}

	/*
	 * public String getDirectoryName(String file) { return file.substring(0,
	 * file.lastIndexOf("\\")); }
	 */

	public class concatFilter implements FilenameFilter {
		private String evaluator_id;

		private String localFile;

		/**
		 * @param evaluator_id
		 *            The evaluator_id to set.
		 */
		public void setEvaluator_id(String evaluator_id) {
			this.evaluator_id = evaluator_id;
		}

		/**
		 * @param localFile
		 *            The localFile to set.
		 */
		public void setLocalFile(String localFile) {
			this.localFile = localFile;
		}

		public boolean accept(File dir, String name) {
			String extension = name.substring(name.lastIndexOf("."), name
					.length());
			String beginning = name.substring(0, 5);
			String ev = name.substring(5, name.indexOf("_", 5));
			String loc = name;
			if (!ev.equals(evaluator_id) || loc.equals(localFile)
					|| !extension.equals(".txt")
					|| !beginning.equalsIgnoreCase("eval_")) {
				return false;
			} else {
				return true;
			}
		}
	}
}