#!/bin/ksh

cd /origenate/or_statefarm/apps/connectwarepasswordutility/

. ../../config/usrconfig.sh

java com.cmsinc.origenate.connectware.ConnectwareChangePasswords $ORCONFIG/origenate.ini 148

if [ "$?" -ne "0" ]; then
  echo "Error Running Connectware Change Password"
  exit 1
fi
