package com.cmsinc.origenate.connectware;

import com.cmsinc.origenate.cp.mpe.ws.connectware.ConnectwarePasswordChange;
import com.cmsinc.origenate.util.ExitCodeConstants;

public class ConnectwareChangePasswords {

	/**
	 * Kicks off the logic to change Connectware passwords.
	 * @param args String array containing full path to the
	 * 				Origenate INI in index 0 and the
	 * 				Evaluator ID in index 1
	 */
	public static void main(String[] args) {
		try {
			if(args.length != 2) {
				System.err.println("Must be two arguments. Origenate INI and Evaluator ID.\n" + 
						"Ex: java " + ConnectwareChangePasswords.class.getSimpleName() + " /opt/origenate/or_test/config/origenate.ini 65");
				System.exit(ExitCodeConstants.ARGUMENTS_ERROR);
			}
			
			String iniFile = args[0];
			String evaluatorId = args[1];
			
			ConnectwarePasswordChange passwordChange = new ConnectwarePasswordChange(iniFile, evaluatorId);
			passwordChange.changePasswords();
			
			if(passwordChange.isAnyPasswordChangeFailed()) {
				System.exit(ExitCodeConstants.PROCESS_FAILURE); // exit with an error code to indicate that at least one failed
			}
		} catch(Exception e) {
			e.printStackTrace();
			System.exit(ExitCodeConstants.PROCESS_FAILURE);
		}
		
		System.exit(ExitCodeConstants.SUCCESS);
	}

}
