#!/bin/sh
#
# Process TAF Follow Up
#


INIFILE=/opt/jrun4/servers/dev84/cfusion-ear/cfusion-war/config/origenate.ini
LOGFILE=/opt/origenate/dev84/log/taffollowup.log

nohup java -classpath .:../lib/evidl.jar:../lib/common.jar:../lib/dom4j-1.6.1.jar:../lib/jaxen-1.1.1.jar:../lib/commons-io-1.3.1.jar:../lib/ojdbc6.jar com.cmsinc.origenate.tool.TAFFollowUp $INIFILE $1 >> $LOGFILE &
exit 0
