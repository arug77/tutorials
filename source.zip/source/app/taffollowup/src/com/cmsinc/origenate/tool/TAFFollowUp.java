/****************************************************************************************************************
   Company: CMSI
    Product: Origenate
    Version: Beta
    Author: Tamer Beshai

    Description: TAF follow up scheduled process
                 Check start.bat file to start this process.
*******************************************************************************************************************/
package com.cmsinc.origenate.tool;

import com.cmsinc.origenate.util.DBConnection;
import com.cmsinc.origenate.workflow.ApplicationIDs;

import org.dom4j.Document;
import org.dom4j.DocumentHelper;
import org.dom4j.Node;

import com.cmsinc.origenate.workflow.WorkFlowManager;
import com.cmsinc.origenate.util.IniFile;
import com.cmsinc.origenate.evaluation.XMLInitiatorInterface;
import com.cmsinc.origenate.event.CommentEvents;
import com.cmsinc.origenate.event.JournalEvents;
import java.sql.Types;

import java.util.*;
import com.cmsinc.origenate.util.LogMsg;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.PreparedStatement;
import java.sql.Timestamp;
import java.text.*;

public class TAFFollowUp {

  //Set debugger
  private static boolean b_debugger = true;
  private static CommentEvents commEvent;
  private static JournalEvents journalEvent;


  private Timer timer;
  private static java.sql.Connection con;
  private static LogMsg log = new LogMsg();
  private static  String s_log_file = "";
  private static String iniFileNm = "C:\\JRun4\\servers\\cfusion\\cfusion-ear\\cfusion-war\\config\\origenate.ini";


  /***************************************************************/
  /*             Main method to call taf follow up process       */
  /***************************************************************/
  public static void main(String argv[]) throws Exception {
    if (argv.length != 0) {
      //Call time out process with ini file
      iniFileNm = argv[0].trim();
    }
     new TAFFollowUp();
  }


  /***************************************************************/
  /* Create Expired offer obejct and get DB connection         */
  /***************************************************************/
  private static void getDBConnection(String s_iniFile) throws Exception {

    try {
      //Get ini file values for DB connection
      IniFile ini = new IniFile();
      ini.readINIFile(s_iniFile);
      String s_host = ini.getINIVar("database.host");
      String s_port = ini.getINIVar("database.port");
      String s_sid = ini.getINIVar("database.sid");
      String s_user = ini.getINIVar("database.user");
      String s_password = ini.getINIVar("database.password");
      String sTNSEntry = ini.getINIVar("database.TNSEntry", "");
      s_log_file = ini.getINIVar("logs.taffollowup_log_file");

      DBConnection DBConnect = new DBConnection();
      log.openLogFile(s_log_file);

      if (sTNSEntry.length() == 0) {
    	  con = DBConnect.getConnection( s_host,  s_sid, s_user,  s_password, s_log_file, s_port,"");
      } else {
    	  // use tns entry if available
    	  con = DBConnect.getConnectionTNS(sTNSEntry, s_user,  s_password, s_log_file);
      }
    } catch (Exception e) {
      recordError(e, "getDBConnection");
    }
  }

  /***************************************************************/
  /*                    Reocord error                            */
  /***************************************************************/
  private static void recordError(Exception err, String classStr) throws Exception  {
    try {
      if (b_debugger)
        err.printStackTrace();
      log.FmtAndLogMsg("Error in " + classStr + " method of : " + err.toString());
      throw new Exception("Error in " + classStr + " method of : " + err.toString());
    } catch (Exception e) {
      log.FmtAndLogMsg("Error in recordError method of : " + e.toString());
    }
  }

  /***************************************************************/
  /*                    Reocord thread  error                    */
  /***************************************************************/
  private void recordThreadError(Exception err, String classStr)  {
    try {
      if (b_debugger)
        err.printStackTrace();
      log.FmtAndLogMsg("Error in " + classStr + " method of : " + err.toString());
      throw new Exception("Error in " + classStr + " method of : " + err.toString());
    } catch (Exception e) {
      log.FmtAndLogMsg("Error in recordError method of : " + e.toString());
    }
  }

  /***************************************************************/
  /*    Gets Expired offer frequency                             */
  /***************************************************************/
  private long getTafFollowUpFreq() throws Exception  {

    long ret_tafFollowUpFreq = 0;
    PreparedStatement ps = null;
    ResultSet rs = null;
    String sql = "";

    try {

      //Select Taf Follow Up frequency
      sql =   " select taf_follow_up_num from origenate_setting ";

      //Prepare statement to execute
      ps = con.prepareStatement(sql);

      //Execute statement
      rs = ps.executeQuery();

      //Get value of freq.
      if (rs.next())
    	  ret_tafFollowUpFreq = rs.getLong("taf_follow_up_num");


    } catch (Exception ex) {
      recordError(ex, "getTafFollowUpFreq");
    } finally {
        try{ if(rs != null) rs.close(); }catch(Exception e1){e1.printStackTrace();}
		try{ if(ps != null) ps.close(); }catch(Exception e1){e1.printStackTrace();}
    }
    //Convert to millisecs
    ret_tafFollowUpFreq = ret_tafFollowUpFreq * 24 * 60 * 60 * 1000;
    return ret_tafFollowUpFreq;
  }

  /***************************************************************/
  /*    Schedule a task that executes at specific time           */
 /***************************************************************/
  public TAFFollowUp() throws Exception  {
    try {


      timer = new Timer();

      //Get db connection
      getDBConnection(iniFileNm);

      //Get frquency of taf follow up execution
      long procFreq = getTafFollowUpFreq();

      //If frequency is not set then do not schedule process
      if (procFreq != 0) {

        Timestamp procDt = new java.sql.Timestamp(System.currentTimeMillis());
        timer = new Timer();

        log.FmtAndLogMsg("About to Schedule TAF Follow Up Process....");
        //Create thread to manage scheduling
        timer.schedule(new CheckTafFollowUp(), procDt, procFreq);

      } else {
        log.FmtAndLogMsg("Error: Frequecy period is not defined. TAF Follow Up process has not been scheduled...");
        System.out.println("Error: Frequecy period is not defined. TAF Follow Up process has not been scheduled...");
        System.exit(0);
      }
    } catch (Exception ex) {
      recordError(ex, "TAF Follow Up");
      System.exit(0);
    }
  }


  /***************************************************************/
   /*               Thread class for time out task                */
   /***************************************************************/
  class CheckTafFollowUp extends TimerTask {

    /***************************************************************/
    /*    Default method of the thread                             */
    /***************************************************************/
    public void run() {
      try {
        //Get db connection; if it is closed
        if (con.isClosed())
          getDBConnection(iniFileNm);

        //Create comment obj
        commEvent = new CommentEvents(con,s_log_file);

        //Create comment obj
        journalEvent = new JournalEvents(con,s_log_file);

        //Run TAF Follow Up
        runTafFollowUp();

      }  catch (Exception ex) {
        recordThreadError(ex, "run");
      }
    }
  }

  /***************************************************************/
  /*   Run TAF follow up                                         */
  /***************************************************************/
  private static void runTafFollowUp() throws Exception {
  	PreparedStatement ps = null, ps1 = null;
  	ResultSet rs = null, rs1 = null, rs2 = null;
  	String sql = "";
  	WorkFlowManager wfManager = null;

  	// get current date and time
  	Timestamp sysDate = new java.sql.Timestamp(System.currentTimeMillis());

  	PreparedStatement stmt = null;
	Statement stmt2 = null;
    String inifilepath="";
	String effDateType="";
	String fixedDate="";
	String s_sql = "";
	IniFile ini = null;

	//Title
	try{
  		// get db connection; if it is closed
  		getDBConnection(iniFileNm);
  		// create comment obj
  		commEvent = new CommentEvents(con,s_log_file);
  		// create comment obj
  		journalEvent = new JournalEvents(con,s_log_file);

  		log.FmtAndLogMsg("*** Title follow up process started successfully. ****");

  		//Set defaults
		String tafTypeTxt = "T";
    	long requestID = -1;
    	int seqno = -1;
    	int homeEquityID = -1;
    	int evaluatorID = -1;
    	int productID = -1;
    	int personalFlg = 1;
    	int vendorID = -1;
    	String orderRequestID = "-1";
    	String providerIDTxt = "-1";
    	String vendorNameTxt = "-1";
    	String remoteRefNum = "-1";
    	String evalClientID = "-1";
    	String serviceType = "-1";
    	Date orderDate = new Date();
    	String transactionType = "Comment";
    	String requestorTable = "REQUESTOR";
    	String requestorSQL = "AND    CRTR.REQUEST_ID = R.REQUEST_ID " +
							  "AND    CRTR.EVALUATOR_ID = R.EVALUATOR_ID " +
							  "AND    R.REQUESTOR_TYPE_ID = 0 ";

        //Title
        sql =   "SELECT CRTO.REQUEST_ID, CRTO.FOLLOWUP_DT, CRTO.ORDER_DT, CRTO.SEQNO, CRTO.HOME_EQUITY_ID, CR.PERSONAL_FLG " +
        		"FROM credit_req_title_order CRTO, credit_request CR " +
					"WHERE 	FOLLOWUP_DT > SYSDATE " +
					"AND	CRTO.REQUEST_ID =  CR.REQUEST_ID " +
					"AND	(CRTO.TAF_ORDER_STATUS_ID <> 1 AND CRTO.TAF_ORDER_STATUS_ID <> 4) ";

        //Prepare statement to execute
        ps = con.prepareStatement(sql);
        //Execute statement
        rs = ps.executeQuery();
        while (rs.next()) {
        	orderRequestID = rs.getString("REQUEST_ID");
        	personalFlg = rs.getInt("PERSONAL_FLG");
        	if (personalFlg != 1){
        		requestorTable = "REQUESTOR_BUSINESS";
            	requestorSQL = "AND    CRTR.REQUEST_ID = R.REQUEST_ID " +
            				   "AND    R.REQUESTOR_TYPE_ID = 0 ";
        	}

            //log.FmtAndLogMsg("orderRequestID: " + orderRequestID);
			s_sql = "SELECT	REQUEST_ID FROM CREDIT_REQUEST_JOURNAL " +
									"WHERE JOURNAL_EVENT_ID = 98	" +
									"AND REQUEST_ID = ?";
			
            stmt = con.prepareStatement(s_sql);
			stmt.setInt(1, Integer.valueOf(orderRequestID));
			
				
				
            rs1 = stmt.executeQuery();

            if (!rs1.next()){	//means no follow up has been sent to this order so send a follow up
				s_sql = "SELECT	CRTR.REQUEST_ID, CRTR.EVALUATOR_ID, CRTR.TAF_TYPE_TXT, CRTR.VENDOR_ID, " +
												"CRTR.PROVIDER_TXT AS PROVIDER_ID_TXT, CRTR.SERVICE_TYPE_CODE_TXT, CRTR.ORDER_NUM_TXT AS VENDOR_ORDER_NUM_TXT, " +
												"CR.PRODUCT_ID AS PRODUCT_ID, E.EVALUATE_CLIENT_ID_TXT AS EVALUATE_CLIENT_ID_TXT, " +
												"R.REMOTE_REF_NUM AS REMOTE_REF_NUM, CV.VENDOR_NAME_TXT AS VENDOR_NAME_TXT " +
		            						"FROM 	CREDIT_REQ_TITLE_RESP CRTR, CONFIG_TAF_RESPONSE_STATUS CTRS, MSTR_TAF_PROVIDER MTP, EVALUATOR E, " + requestorTable + " R, CREDIT_REQUEST CR, CONFIG_VENDOR CV " +
		            						"WHERE 	CRTR.RESPONSE_STATUS_CODE_TXT = CTRS.RESPONSE_STATUS_CODE_TXT " +
		            						"AND 	CTRS.COMPLETE_FLG <> 1 " +
		            						"AND 	CRTR.EVALUATOR_ID = CTRS.EVALUATOR_ID " +
		            						"AND 	CRTR.EVALUATOR_ID = E.EVALUATOR_ID " +
		            						"AND 	UPPER(CRTR.PROVIDER_TXT) = UPPER(MTP.PROVIDER_NAME_TXT) " +
		            		        		"AND    CRTR.REQUEST_ID = CR.REQUEST_ID " +
		            		        		"AND    CRTR.EVALUATOR_ID = CR.EVALUATOR_ID " +
		            		        		"AND 	CR.INITIATION_DT > SYSDATE-90 " +
		            		        		requestorSQL +
		            		 				"AND 	CRTR.EVALUATOR_ID = CV.EVALUATOR_ID " +
		            		 				"AND 	CRTR.VENDOR_ID = CV.VENDOR_ID " +
		            						"AND 	CRTR.REQUEST_ID in (SELECT REQUEST_ID FROM CREDIT_REQ_TITLE_ORDER CRTO " +
			            						"WHERE 	FOLLOWUP_DT > SYSDATE " +
			            						"AND   	(CRTO.TAF_ORDER_STATUS_ID <> 1 AND CRTO.TAF_ORDER_STATUS_ID <> 4) ) " +
			            						"AND 	RESPSEQNO = (SELECT MAX(RESPSEQNO) RESPSEQNO FROM CREDIT_REQ_TITLE_RESP CRTR " +
				            						"WHERE 	REQUEST_ID = ?)";
				
				stmt = con.prepareStatement(s_sql);
				
				stmt.setInt(1, Integer.valueOf(orderRequestID));
				
	            rs1 = stmt.executeQuery();

	            int i = 1;

		        while (rs1.next()) {
		        	tafTypeTxt = rs1.getString("taf_type_txt");
		        	requestID = rs1.getLong("request_id");
		        	seqno = rs.getInt("seqno");
		        	homeEquityID = rs.getInt("HOME_EQUITY_ID");
		        	evaluatorID = rs1.getInt("evaluator_id");
		        	productID = rs1.getInt("product_id");
		        	vendorID = rs1.getInt("vendor_id");
		        	providerIDTxt = rs1.getString("PROVIDER_ID_TXT");
		        	vendorNameTxt = rs1.getString("vendor_name_txt");
		        	remoteRefNum = rs1.getString("REMOTE_REF_NUM");
		        	evalClientID = rs1.getString("EVALUATE_CLIENT_ID_TXT");
		        	serviceType = rs1.getString("SERVICE_TYPE_CODE_TXT");
		        	orderDate = rs.getDate("ORDER_DT");
		            //log.FmtAndLogMsg("tafTypeTxt: " + tafTypeTxt + " requestID: " + requestID + " seqno: " + seqno + " evaluatorID: " + evaluatorID +
		            //		" productID: " + productID + " vendorID: " + vendorID + " providerIDTxt: " + providerIDTxt + " vendorNameTxt: " + vendorNameTxt +
		            //		" remoteRefNum: " + remoteRefNum + " evalClientID: " + evalClientID + " serviceType: " + serviceType + " orderDate: " + orderDate);

		        	transactionType = "Comment";
		           	String confirmationNo = "" + evaluatorID + "-" + seqno + "-" + requestID + "-" + homeEquityID + "-1";
		           	String commentTxt = "Our records indicate that order # " +  confirmationNo + " was placed on " + orderDate +
		           					" and is currently outstanding. Please provide an update as to the status and estimated completion date of this order." ;

		            //log.FmtAndLogMsg(commentTxt);

		            stmt2  = con.createStatement();
		            rs2 = stmt2.executeQuery( "SELECT PATH_TXT FROM ORIGENATE_INI");
		            if(rs2.next()) {
		              // get evaluate environment vars from ini file
		              ini = new IniFile();
		              inifilepath=rs2.getString("PATH_TXT");
                              //163404 - GL. 4/1/2013 - if -D provided on java runtime then use its path to get the origenate.ini file
                              if (System.getProperty("origenate_ini") != null) 
                                 inifilepath=System.getProperty("origenate_ini");
                              else
                                 log.FmtAndLogMsg("WARNING: Reading origenate_ini table in TAFFollowUP");
                              // END- 163404 - GL. 4/1/2013 - if -D provided on java runtime then use its path to get the origenate.ini file
		              ini.readINIFile(inifilepath);
		              //ini.readINIFile("C:\\JRun4\\servers\\cfusion\\cfusion-ear\\cfusion-war\\config\\origenate.ini");
				        // get the effective date/time, eValuate host and receive port from the INI file
						effDateType = ini.getINIVar("general.effective_date_type", "").trim();
						fixedDate = ini.getINIVar("general.fixed_date", "").trim();
		    		}
		    		Date effDateTime;

		    		if (effDateType.compareToIgnoreCase("dynamic") == 0 || fixedDate.length() == 0) {
		    			// use current date/time
		    			effDateTime = new Date();
		    		} else {
		    			// use fixed date/time
		    			effDateTime = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss").parse(fixedDate);
		    		}

					String host = ini.getINIVar("evaluate.ini_host", "").trim();
		    		String port = ini.getINIVar("evaluate.receive_port", "").trim();

		    		log.FmtAndLogMsg("HOST: " + host);
		    		log.FmtAndLogMsg("PORT: " + port);

					// get ready to call eValuate via XML Initiator
					XMLInitiatorInterface xmlInit = new XMLInitiatorInterface();

					xmlInit.initializeXML(remoteRefNum, evalClientID, effDateTime, "TAFOrder", "", "","TAFORDER_PRELOAD_TABLESET");

					xmlInit.setEvappValue("EVAPP_INTERFACE", "TAFTYPE_TXT", tafTypeTxt, i);
					xmlInit.setEvappValue("EVAPP_INTERFACE", "EVALUATOR_NUM", Integer.toString(evaluatorID), i);
					xmlInit.setEvappValue("EVAPP_INTERFACE", "PRODUCT_NUM", Integer.toString(productID), i);
					xmlInit.setIntermediateValue("ALL", "Inter!TMP_CollateralNum", Integer.toString(homeEquityID), "1");
					xmlInit.setIntermediateValue("ALL", "Inter!TMP_VendorID", Integer.toString(vendorID), "1");
					xmlInit.setIntermediateValue("ALL", "Inter!TMP_ProviderID", providerIDTxt, "2");
					xmlInit.setIntermediateValue("ALL", "Inter!TMP_VendorProduct", serviceType, "2");
					xmlInit.setIntermediateValue("ALL", "Inter!TMP_TransactionType", "Comment", "2");
					xmlInit.setIntermediateValue("ALL", "Inter!TMP_CommentText", commentTxt, "2");
					xmlInit.setIntermediateValue("ALL", "Inter!TMP_TAF_OrderID", Integer.toString(seqno), "1");
					xmlInit.setIntermediateValue("ALL", "Inter!TMP_TAF_UserID", "SYSTEM", "2");
					xmlInit.setIntermediateValue("ALL", "Inter!TMP_ConfirmationNo", confirmationNo, "1");
					i++;

					// make the call to eValuate
					Document document = DocumentHelper.parseText(xmlInit.call(host, port));
					Node evappError = document.selectSingleNode("/ev_transaction/ev_error");

					// there was an error calling eValuate
					if (evappError != null) {
						log.FmtAndLogMsg("ERROR CALLING EVALUATE - MAKE SURE EVALUATE IS UP");
						log.FmtAndLogMsg("ERROR CALLING EVALUATE - MAKE SURE XMLINITIATOR IS RUNNING");
						log.FmtAndLogMsg("ERROR CALLING EVALUATE - TAFOrder CALL FAILED");
					} else {
						// create string comment
						String strComment = "Title Follow Up for RID: " + requestID + " Order # " + confirmationNo;

						// add comment entry
						addComment(requestID, sysDate, ApplicationIDs.sysuser, strComment);

						// add journal entry
						addJournal(requestID, ApplicationIDs.sysuser, tafTypeTxt);
					}
		        }
        	}
        }
        		 try {rs.close();} catch (Exception e1) {}
			 try {rs1.close();} catch (Exception e1) {}
			 try {rs2.close();} catch (Exception e1) {}
			 try {stmt.close();} catch (Exception e1) {}
			 try {stmt2.close();} catch (Exception e1) {}
			 try {ps.close();} catch (Exception e1) {}
		}catch(Exception e){
			log.FmtAndLogMsg("Error Appraisal Follow Up: " + stack2string(e));
		}
		finally {
			try {
				if (rs != null) rs.close();
				if (rs1 != null) rs1.close();
				if (rs2 != null) rs2.close();
				if (stmt != null) stmt.close();
				if (stmt2 != null) stmt2.close();
				if (ps != null) ps.close();
				if (commEvent != null) commEvent = null;
				if (journalEvent != null) journalEvent = null;
				if (con != null) con.close();
			}
			catch (Exception e) {
				recordError(e, "Run Taf Follow Up");
			}
  			log.FmtAndLogMsg("*** Title follow up process completed successfully. ****");
		}

	//Appraisal
	try{
  		// get db connection; if it is closed
  		getDBConnection(iniFileNm);
  		// create comment obj
  		commEvent = new CommentEvents(con,s_log_file);
  		// create comment obj
  		journalEvent = new JournalEvents(con,s_log_file);

  		log.FmtAndLogMsg("*** Appraisal follow up process started successfully. ****");

  		//Set defaults
		String tafTypeTxt = "A";
    	long requestID = -1;
    	int seqno = -1;
    	int homeEquityID = -1;
    	int evaluatorID = -1;
    	int productID = -1;
    	int personalFlg = 1;
    	int vendorID = -1;
    	String orderRequestID = "-1";
    	String providerIDTxt = "-1";
    	String vendorNameTxt = "-1";
    	String remoteRefNum = "-1";
    	String evalClientID = "-1";
    	String serviceType = "-1";
    	Date orderDate = new Date();
    	String transactionType = "Comment";
    	String requestorTable = "REQUESTOR";
    	String requestorSQL = "AND    CRAR.REQUEST_ID = R.REQUEST_ID " +
							  "AND    CRAR.EVALUATOR_ID = R.EVALUATOR_ID " +
							  "AND    R.REQUESTOR_TYPE_ID = 0 ";

        //Appraisal
        sql =   "SELECT CRAO.REQUEST_ID, CRAO.FOLLOWUP_DT, CRAO.ORDER_DT, CRAO.SEQNO, CRAO.HOME_EQUITY_ID, CR.PERSONAL_FLG " +
        		"FROM credit_req_appraisal_order CRAO, credit_request CR " +
					"WHERE 	FOLLOWUP_DT > SYSDATE " +
					"AND	CRAO.REQUEST_ID =  CR.REQUEST_ID " +
					"AND	(CRAO.TAF_ORDER_STATUS_ID <> 1 AND CRAO.TAF_ORDER_STATUS_ID <> 4) ";

        //Prepare statement to execute
        ps = con.prepareStatement(sql);
        //Execute statement
        rs = ps.executeQuery();
        while (rs.next()) {
        	orderRequestID = rs.getString("REQUEST_ID");
        	personalFlg = rs.getInt("PERSONAL_FLG");
        	if (personalFlg != 1){
        		requestorTable = "REQUESTOR_BUSINESS";
            	requestorSQL = "AND    CRAR.REQUEST_ID = R.REQUEST_ID " +
            				   "AND    R.REQUESTOR_TYPE_ID = 0 ";
        	}

            //log.FmtAndLogMsg("orderRequestID: " + orderRequestID);
 			
			s_sql = "SELECT	REQUEST_ID FROM CREDIT_REQUEST_JOURNAL " +
									"WHERE JOURNAL_EVENT_ID = 96	" +
									"AND REQUEST_ID = ?";	
            stmt = con.prepareStatement(s_sql);
			stmt.setInt(1, Integer.valueOf(orderRequestID));
            rs1 = stmt.executeQuery();

            if (!rs1.next()){	//means no follow up has been sent to this order so send a follow up
				s_sql = "SELECT	CRAR.REQUEST_ID, CRAR.EVALUATOR_ID, CRAR.TAF_TYPE_TXT, CRAR.VENDOR_ID, " +
												"CRAR.PROVIDER_TXT AS PROVIDER_ID_TXT, CRAR.SERVICE_TYPE_CODE_TXT, CRAR.VENDOR_ORDER_NUM_TXT, " +
												"CR.PRODUCT_ID AS PRODUCT_ID, E.EVALUATE_CLIENT_ID_TXT AS EVALUATE_CLIENT_ID_TXT, " +
												"R.REMOTE_REF_NUM AS REMOTE_REF_NUM, CV.VENDOR_NAME_TXT AS VENDOR_NAME_TXT " +
		            						"FROM 	CREDIT_REQ_APPRAISAL_RESP CRAR, CONFIG_TAF_RESPONSE_STATUS CTRS, MSTR_TAF_PROVIDER MTP, EVALUATOR E, " + requestorTable + " R, CREDIT_REQUEST CR, CONFIG_VENDOR CV " +
		            						"WHERE 	CRAR.RESPONSE_STATUS_CODE_TXT = CTRS.RESPONSE_STATUS_CODE_TXT " +
		            						"AND 	CTRS.COMPLETE_FLG <> 1 " +
		            						"AND 	CRAR.EVALUATOR_ID = CTRS.EVALUATOR_ID " +
		            						"AND 	CRAR.EVALUATOR_ID = E.EVALUATOR_ID " +
		            						"AND 	UPPER(CRAR.PROVIDER_TXT) = UPPER(MTP.PROVIDER_NAME_TXT) " +
		            		        		"AND    CRAR.REQUEST_ID = CR.REQUEST_ID " +
		            		        		"AND    CRAR.EVALUATOR_ID = CR.EVALUATOR_ID " +
		            		        		"AND 	CR.INITIATION_DT > SYSDATE-90 " +
		            		        		requestorSQL +
		            		 				"AND 	CRAR.EVALUATOR_ID = CV.EVALUATOR_ID " +
		            		 				"AND 	CRAR.VENDOR_ID = CV.VENDOR_ID " +
		            						"AND 	CRAR.REQUEST_ID in (SELECT REQUEST_ID FROM CREDIT_REQ_APPRAISAL_ORDER CRAO " +
			            						"WHERE 	FOLLOWUP_DT > SYSDATE " +
			            						"AND   	(CRAO.TAF_ORDER_STATUS_ID <> 1 AND CRAO.TAF_ORDER_STATUS_ID <> 4) ) " +
			            						"AND 	RESPSEQNO = (SELECT MAX(RESPSEQNO) RESPSEQNO FROM CREDIT_REQ_APPRAISAL_RESP CRAR " +
				            						"WHERE 	REQUEST_ID = ?)";
													
				stmt = con.prepareStatement(s_sql);
				stmt.setInt(1, Integer.valueOf(orderRequestID));
	            rs1 = stmt.executeQuery();

	            int i = 1;

		        while (rs1.next()) {
		        	tafTypeTxt = rs1.getString("taf_type_txt");
		        	requestID = rs1.getLong("request_id");
		        	seqno = rs.getInt("seqno");
		        	homeEquityID = rs.getInt("HOME_EQUITY_ID");
		        	evaluatorID = rs1.getInt("evaluator_id");
		        	productID = rs1.getInt("product_id");
		        	vendorID = rs1.getInt("vendor_id");
		        	providerIDTxt = rs1.getString("PROVIDER_ID_TXT");
		        	vendorNameTxt = rs1.getString("vendor_name_txt");
		        	remoteRefNum = rs1.getString("REMOTE_REF_NUM");
		        	evalClientID = rs1.getString("EVALUATE_CLIENT_ID_TXT");
		        	serviceType = rs1.getString("SERVICE_TYPE_CODE_TXT");
		        	orderDate = rs.getDate("ORDER_DT");
		            //log.FmtAndLogMsg("tafTypeTxt: " + tafTypeTxt + " requestID: " + requestID + " seqno: " + seqno + " evaluatorID: " + evaluatorID +
		            //		" productID: " + productID + " vendorID: " + vendorID + " providerIDTxt: " + providerIDTxt + " vendorNameTxt: " + vendorNameTxt +
		            //		" remoteRefNum: " + remoteRefNum + " evalClientID: " + evalClientID + " serviceType: " + serviceType + " orderDate: " + orderDate);

		        	transactionType = "Comment";
		           	String confirmationNo = "" + evaluatorID + "-" + seqno + "-" + requestID + "-" + homeEquityID + "-2";
		           	String commentTxt = "Our records indicate that order # " +  confirmationNo + " was placed on " + orderDate +
		           					" and is currently outstanding. Please provide an update as to the status and estimated completion date of this order." ;

		            //log.FmtAndLogMsg(commentTxt);

		            stmt2  = con.createStatement();
		            rs2 = stmt2.executeQuery( "SELECT PATH_TXT FROM ORIGENATE_INI");
		            if(rs2.next()) {
		              // get evaluate environment vars from ini file
		              ini = new IniFile();
		              inifilepath=rs2.getString("PATH_TXT");
                              //163404 - GL. 4/1/2013 - if -D provided on java runtime then use its path to get the origenate.ini file
                              if (System.getProperty("origenate_ini") != null) 
                                 inifilepath=System.getProperty("origenate_ini");
                              else
                                 log.FmtAndLogMsg("WARNING: Reading origenate_ini table in TAFFollowUP");
                              // END- 163404 - GL. 4/1/2013 - if -D provided on java runtime then use its path to get the origenate.ini file
		              ini.readINIFile(inifilepath);
		              //ini.readINIFile("C:\\JRun4\\servers\\cfusion\\cfusion-ear\\cfusion-war\\config\\origenate.ini");
				        // get the effective date/time, eValuate host and receive port from the INI file
						effDateType = ini.getINIVar("general.effective_date_type", "").trim();
						fixedDate = ini.getINIVar("general.fixed_date", "").trim();
		    		}
		    		Date effDateTime;

		    		if (effDateType.compareToIgnoreCase("dynamic") == 0 || fixedDate.length() == 0) {
		    			// use current date/time
		    			effDateTime = new Date();
		    		} else {
		    			// use fixed date/time
		    			effDateTime = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss").parse(fixedDate);
		    		}

					String host = ini.getINIVar("evaluate.ini_host", "").trim();
		    		String port = ini.getINIVar("evaluate.receive_port", "").trim();

		    		log.FmtAndLogMsg("HOST: " + host);
		    		log.FmtAndLogMsg("PORT: " + port);

					// get ready to call eValuate via XML Initiator
					XMLInitiatorInterface xmlInit = new XMLInitiatorInterface();

					xmlInit.initializeXML(remoteRefNum, evalClientID, effDateTime, "TAFOrder", "", "","TAFORDER_PRELOAD_TABLESET");

					xmlInit.setEvappValue("EVAPP_INTERFACE", "TAFTYPE_TXT", tafTypeTxt, i);
					xmlInit.setEvappValue("EVAPP_INTERFACE", "EVALUATOR_NUM", Integer.toString(evaluatorID), i);
					xmlInit.setEvappValue("EVAPP_INTERFACE", "PRODUCT_NUM", Integer.toString(productID), i);
					xmlInit.setIntermediateValue("ALL", "Inter!TMP_CollateralNum", Integer.toString(homeEquityID), "1");
					xmlInit.setIntermediateValue("ALL", "Inter!TMP_VendorID", Integer.toString(vendorID), "1");
					xmlInit.setIntermediateValue("ALL", "Inter!TMP_ProviderID", providerIDTxt, "2");
					xmlInit.setIntermediateValue("ALL", "Inter!TMP_VendorProduct", serviceType, "2");
					xmlInit.setIntermediateValue("ALL", "Inter!TMP_TransactionType", "Comment", "2");
					xmlInit.setIntermediateValue("ALL", "Inter!TMP_CommentText", commentTxt, "2");
					xmlInit.setIntermediateValue("ALL", "Inter!TMP_TAF_OrderID", Integer.toString(seqno), "1");
					xmlInit.setIntermediateValue("ALL", "Inter!TMP_TAF_UserID", "SYSTEM", "2");
					xmlInit.setIntermediateValue("ALL", "Inter!TMP_ConfirmationNo", confirmationNo, "1");
					i++;

					// make the call to eValuate
					Document document = DocumentHelper.parseText(xmlInit.call(host, port));
					Node evappError = document.selectSingleNode("/ev_transaction/ev_error");

					// there was an error calling eValuate
					if (evappError != null) {
						log.FmtAndLogMsg("ERROR CALLING EVALUATE - MAKE SURE EVALUATE IS UP");
						log.FmtAndLogMsg("ERROR CALLING EVALUATE - MAKE SURE XMLINITIATOR IS RUNNING");
						log.FmtAndLogMsg("ERROR CALLING EVALUATE - TAFOrder CALL FAILED");
					} else {
						// create string comment
						String strComment = "Appraisal Follow Up for RID: " + requestID + " Order # " + confirmationNo;

						// add comment entry
						addComment(requestID, sysDate, ApplicationIDs.sysuser, strComment);

						// add journal entry
						addJournal(requestID, ApplicationIDs.sysuser, tafTypeTxt);
					}
		        }
        	}
        }
		 try {rs.close();} catch (Exception e1) {}
		 try {rs1.close();} catch (Exception e1) {}
		 try {rs2.close();} catch (Exception e1) {}
		 try {stmt.close();} catch (Exception e1) {}
		 try {stmt2.close();} catch (Exception e1) {}
		 try {ps.close();} catch (Exception e1) {}
	}catch(Exception e){
		log.FmtAndLogMsg("Error Appraisal Follow Up: " + stack2string(e));
	}
	finally {
		try {
			if (rs != null) rs.close();
			if (rs1 != null) rs1.close();
			if (rs2 != null) rs2.close();
			if (stmt != null) stmt.close();
			if (stmt2 != null) stmt2.close();
			if (ps != null) ps.close();
			if (commEvent != null) commEvent = null;
			if (journalEvent != null) journalEvent = null;
			if (con != null) con.close();
		}
		catch (Exception e) {
			recordError(e, "Run Taf Follow Up");
		}
  		log.FmtAndLogMsg("*** Appraisal follow up process completed successfully. ****");
	}

	//Flood
	try{
  		// get db connection; if it is closed
  		getDBConnection(iniFileNm);
  		// create comment obj
  		commEvent = new CommentEvents(con,s_log_file);
  		// create comment obj
  		journalEvent = new JournalEvents(con,s_log_file);

  		log.FmtAndLogMsg("*** Flood follow up process started successfully. ****");

  		//Set defaults
		String tafTypeTxt = "F";
    	long requestID = -1;
    	int seqno = -1;
    	int homeEquityID = -1;
    	int evaluatorID = -1;
    	int productID = -1;
    	int personalFlg = 1;
    	int vendorID = -1;
    	String orderRequestID = "-1";
    	String providerIDTxt = "-1";
    	String vendorNameTxt = "-1";
    	String remoteRefNum = "-1";
    	String evalClientID = "-1";
    	String serviceType = "-1";
    	Date orderDate = new Date();
    	String transactionType = "Comment";
    	String requestorTable = "REQUESTOR";
    	String requestorSQL = "AND    CRFR.REQUEST_ID = R.REQUEST_ID " +
							  "AND    CRFR.EVALUATOR_ID = R.EVALUATOR_ID " +
							  "AND    R.REQUESTOR_TYPE_ID = 0 ";

        //Flood
        sql =   "SELECT CRFO.REQUEST_ID, CRFO.FOLLOWUP_DT, CRFO.ORDER_DT, CRFO.SEQNO, CRFO.HOME_EQUITY_ID, CR.PERSONAL_FLG " +
        		"FROM credit_req_flood_order CRFO, credit_request CR " +
					"WHERE 	FOLLOWUP_DT > SYSDATE " +
					"AND	CRFO.REQUEST_ID =  CR.REQUEST_ID " +
					"AND	(CRFO.TAF_ORDER_STATUS_ID <> 1 AND CRFO.TAF_ORDER_STATUS_ID <> 4) ";

        //Prepare statement to execute
        ps = con.prepareStatement(sql);
        //Execute statement
        rs = ps.executeQuery();
        while (rs.next()) {
        	orderRequestID = rs.getString("REQUEST_ID");
        	personalFlg = rs.getInt("PERSONAL_FLG");
        	if (personalFlg != 1){
        		requestorTable = "REQUESTOR_BUSINESS";
            	requestorSQL = "AND    CRFR.REQUEST_ID = R.REQUEST_ID " +
            				   "AND    R.REQUESTOR_TYPE_ID = 0 ";
        	}

            //log.FmtAndLogMsg("orderRequestID: " + orderRequestID);
           				
			s_sql = "SELECT	REQUEST_ID FROM CREDIT_REQUEST_JOURNAL " +
									"WHERE JOURNAL_EVENT_ID = 97	" +
									"AND REQUEST_ID = ?";
            stmt = con.prepareStatement(s_sql);
			stmt.setInt(1, Integer.valueOf(orderRequestID));
            rs1 = stmt.executeQuery();

            if (!rs1.next()){	//means no follow up has been sent to this order so send a follow up
				s_sql = "SELECT	CRFR.REQUEST_ID, CRFR.EVALUATOR_ID, CRFR.TAF_TYPE_TXT, CRFR.VENDOR_ID, " +
												"CRFR.PROVIDER_TXT AS PROVIDER_ID_TXT, CRFR.SERVICE_TYPE_CODE_TXT, CRFR.VENDOR_ORDER_NUM_TXT, " +
												"CR.PRODUCT_ID AS PRODUCT_ID, E.EVALUATE_CLIENT_ID_TXT AS EVALUATE_CLIENT_ID_TXT, " +
												"R.REMOTE_REF_NUM AS REMOTE_REF_NUM, CV.VENDOR_NAME_TXT AS VENDOR_NAME_TXT " +
		            						"FROM 	CREDIT_REQ_FLOOD_RESP CRFR, CONFIG_TAF_RESPONSE_STATUS CTRS, MSTR_TAF_PROVIDER MTP, EVALUATOR E, " + requestorTable + " R, CREDIT_REQUEST CR, CONFIG_VENDOR CV " +
		            						"WHERE 	CRFR.RESPONSE_STATUS_CODE_TXT = CTRS.RESPONSE_STATUS_CODE_TXT " +
		            						"AND 	CTRS.COMPLETE_FLG <> 1 " +
		            						"AND 	CRFR.EVALUATOR_ID = CTRS.EVALUATOR_ID " +
		            						"AND 	CRFR.EVALUATOR_ID = E.EVALUATOR_ID " +
		            						"AND 	UPPER(CRFR.PROVIDER_TXT) = UPPER(MTP.PROVIDER_NAME_TXT) " +
		            		        		"AND    CRFR.REQUEST_ID = CR.REQUEST_ID " +
		            		        		"AND    CRFR.EVALUATOR_ID = CR.EVALUATOR_ID " +
		            		        		"AND 	CR.INITIATION_DT > SYSDATE-90 " +
		            		        		requestorSQL +
		            		 				"AND 	CRFR.EVALUATOR_ID = CV.EVALUATOR_ID " +
		            		 				"AND 	CRFR.VENDOR_ID = CV.VENDOR_ID " +
		            						"AND 	CRFR.REQUEST_ID in (SELECT REQUEST_ID FROM CREDIT_REQ_FLOOD_ORDER CRFO " +
			            						"WHERE 	FOLLOWUP_DT > SYSDATE " +
			            						"AND   	(CRFO.TAF_ORDER_STATUS_ID <> 1 AND CRFO.TAF_ORDER_STATUS_ID <> 4) ) " +
			            						"AND 	RESPSEQNO = (SELECT MAX(RESPSEQNO) RESPSEQNO FROM CREDIT_REQ_FLOOD_RESP CRFR " +
				            						"WHERE 	REQUEST_ID = ?)";
													
				stmt = con.prepareStatement(s_sql);
				stmt.setInt(1, Integer.valueOf(orderRequestID));
	            rs1 = stmt.executeQuery();

	            int i = 1;

		        while (rs1.next()) {
		        	tafTypeTxt = rs1.getString("taf_type_txt");
		        	requestID = rs1.getLong("request_id");
		        	seqno = rs.getInt("seqno");
		        	homeEquityID = rs.getInt("HOME_EQUITY_ID");
		        	evaluatorID = rs1.getInt("evaluator_id");
		        	productID = rs1.getInt("product_id");
		        	vendorID = rs1.getInt("vendor_id");
		        	providerIDTxt = rs1.getString("PROVIDER_ID_TXT");
		        	vendorNameTxt = rs1.getString("vendor_name_txt");
		        	remoteRefNum = rs1.getString("REMOTE_REF_NUM");
		        	evalClientID = rs1.getString("EVALUATE_CLIENT_ID_TXT");
		        	serviceType = rs1.getString("SERVICE_TYPE_CODE_TXT");
		        	orderDate = rs.getDate("ORDER_DT");
		            //log.FmtAndLogMsg("tafTypeTxt: " + tafTypeTxt + " requestID: " + requestID + " seqno: " + seqno + " evaluatorID: " + evaluatorID +
		            //		" productID: " + productID + " vendorID: " + vendorID + " providerIDTxt: " + providerIDTxt + " vendorNameTxt: " + vendorNameTxt +
		            //		" remoteRefNum: " + remoteRefNum + " evalClientID: " + evalClientID + " serviceType: " + serviceType + " orderDate: " + orderDate);

		        	transactionType = "Comment";
		           	String confirmationNo = "" + evaluatorID + "-" + seqno + "-" + requestID + "-" + homeEquityID + "-3";
		           	String commentTxt = "Our records indicate that order # " +  confirmationNo + " was placed on " + orderDate +
		           					" and is currently outstanding. Please provide an update as to the status and estimated completion date of this order." ;

		            //log.FmtAndLogMsg(commentTxt);

		            stmt2  = con.createStatement();
		            rs2 = stmt2.executeQuery( "SELECT PATH_TXT FROM ORIGENATE_INI");
		            if(rs2.next()) {
		              // get evaluate environment vars from ini file
		              ini = new IniFile();
		              inifilepath=rs2.getString("PATH_TXT");
                              //163404 - GL. 4/1/2013 - if -D provided on java runtime then use its path to get the origenate.ini file
                              if (System.getProperty("origenate_ini") != null) 
                                 inifilepath=System.getProperty("origenate_ini");
                              else
                                 log.FmtAndLogMsg("WARNING: Reading origenate_ini table in TAFFollowUP");
                              // END- 163404 - GL. 4/1/2013 - if -D provided on java runtime then use its path to get the origenate.ini file
		              ini.readINIFile(inifilepath);
		              //ini.readINIFile("C:\\JRun4\\servers\\cfusion\\cfusion-ear\\cfusion-war\\config\\origenate.ini");
				        // get the effective date/time, eValuate host and receive port from the INI file
						effDateType = ini.getINIVar("general.effective_date_type", "").trim();
						fixedDate = ini.getINIVar("general.fixed_date", "").trim();
		    		}
		    		Date effDateTime;

		    		if (effDateType.compareToIgnoreCase("dynamic") == 0 || fixedDate.length() == 0) {
		    			// use current date/time
		    			effDateTime = new Date();
		    		} else {
		    			// use fixed date/time
		    			effDateTime = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss").parse(fixedDate);
		    		}

					String host = ini.getINIVar("evaluate.ini_host", "").trim();
		    		String port = ini.getINIVar("evaluate.receive_port", "").trim();

		    		log.FmtAndLogMsg("HOST: " + host);
		    		log.FmtAndLogMsg("PORT: " + port);

					// get ready to call eValuate via XML Initiator
					XMLInitiatorInterface xmlInit = new XMLInitiatorInterface();

					xmlInit.initializeXML(remoteRefNum, evalClientID, effDateTime, "TAFOrder", "", "","TAFORDER_PRELOAD_TABLESET");

					xmlInit.setEvappValue("EVAPP_INTERFACE", "TAFTYPE_TXT", tafTypeTxt, i);
					xmlInit.setEvappValue("EVAPP_INTERFACE", "EVALUATOR_NUM", Integer.toString(evaluatorID), i);
					xmlInit.setEvappValue("EVAPP_INTERFACE", "PRODUCT_NUM", Integer.toString(productID), i);
					xmlInit.setIntermediateValue("ALL", "Inter!TMP_CollateralNum", Integer.toString(homeEquityID), "1");
					xmlInit.setIntermediateValue("ALL", "Inter!TMP_VendorID", Integer.toString(vendorID), "1");
					xmlInit.setIntermediateValue("ALL", "Inter!TMP_ProviderID", providerIDTxt, "2");
					xmlInit.setIntermediateValue("ALL", "Inter!TMP_VendorProduct", serviceType, "2");
					xmlInit.setIntermediateValue("ALL", "Inter!TMP_TransactionType", "Comment", "2");
					xmlInit.setIntermediateValue("ALL", "Inter!TMP_CommentText", commentTxt, "2");
					xmlInit.setIntermediateValue("ALL", "Inter!TMP_TAF_OrderID", Integer.toString(seqno), "1");
					xmlInit.setIntermediateValue("ALL", "Inter!TMP_TAF_UserID", "SYSTEM", "2");
					xmlInit.setIntermediateValue("ALL", "Inter!TMP_ConfirmationNo", confirmationNo, "1");
					i++;

					// make the call to eValuate
					Document document = DocumentHelper.parseText(xmlInit.call(host, port));
					Node evappError = document.selectSingleNode("/ev_transaction/ev_error");

					// there was an error calling eValuate
					if (evappError != null) {
						log.FmtAndLogMsg("ERROR CALLING EVALUATE - MAKE SURE EVALUATE IS UP");
						log.FmtAndLogMsg("ERROR CALLING EVALUATE - MAKE SURE XMLINITIATOR IS RUNNING");
						log.FmtAndLogMsg("ERROR CALLING EVALUATE - TAFOrder CALL FAILED");
					} else {
						// create string comment
						String strComment = "Flood Follow Up for RID: " + requestID + " Order # " + confirmationNo;

						// add comment entry
						addComment(requestID, sysDate, ApplicationIDs.sysuser, strComment);

						// add journal entry
						addJournal(requestID, ApplicationIDs.sysuser, tafTypeTxt);
					}
		        }
        	}
        }
        		 try {rs.close();} catch (Exception e1) {}
			 try {rs1.close();} catch (Exception e1) {}
			 try {rs2.close();} catch (Exception e1) {}
			 try {stmt.close();} catch (Exception e1) {}
			 try {stmt2.close();} catch (Exception e1) {}
			 try {ps.close();} catch (Exception e1) {}
		}catch(Exception e){
			log.FmtAndLogMsg("Error Appraisal Follow Up: " + stack2string(e));
		}
		finally {
			try {
				if (rs != null) rs.close();
				if (rs1 != null) rs1.close();
				if (rs2 != null) rs2.close();
				if (stmt != null) stmt.close();
				if (stmt2 != null) stmt2.close();
				if (ps != null) ps.close();
				if (commEvent != null) commEvent = null;
				if (journalEvent != null) journalEvent = null;
				if (con != null) con.close();
			}
			catch (Exception e) {
				recordError(e, "Run Taf Follow Up");
			}
  			log.FmtAndLogMsg("*** Flood follow up process completed successfully. ****");
		}
  }


   /***************************************************************/
  /*               Add comments                                  */
  /***************************************************************/
    private static void addComment(long request_id, Timestamp sysDate, String user_id, String commentTxt) throws Exception  {
      try {
        //Add comment
        commEvent.addComment(Long.valueOf(request_id).intValue(),81,"Send TAF Comment to provider",commentTxt,user_id, "", "");
      } catch (Exception ex) {
        try {
          con.rollback();
          recordError(ex, "addComment");
          log.FmtAndLogMsg("*** All taf followups are rollback from last run. Please contact Administrator. ***");
          con.close();
        } finally {
          try {
            if (commEvent != null) commEvent = null;
            if (journalEvent != null) journalEvent = null;
            if (con != null) con.close();
            System.exit(0);
          } catch (Exception e) {
            recordError(e, "addComment");
            log.FmtAndLogMsg("*** All taf followups are rollback from last run. Please contact Administrator. ***");
          }
        }
      }
    }


  /***************************************************************/
  /*               Add journals                                 */
  /***************************************************************/
    private static void addJournal(long request_id,  String user_id, String tafType) throws Exception  {
    	String jounrnalTxt = "";
    	int jounrnalID = -1;
    	if (tafType.equalsIgnoreCase("A")){
    		jounrnalTxt = "Apparaisal Follow Up Sent";
    		jounrnalID = 96;
    	} else if (tafType.equalsIgnoreCase("F")) {
    		jounrnalTxt = "Flood Follow Up Sent";
    		jounrnalID = 97;
    	} else {
    		jounrnalTxt = "Title Follow Up Sent";
    		jounrnalID = 98;
    	}
    	try {


        //Add journal
        journalEvent.addJournal(Long.valueOf(request_id).intValue(),jounrnalID,jounrnalTxt,user_id);
      } catch (Exception ex) {
        try {
          con.rollback();
          recordError(ex, "addJournal");
          log.FmtAndLogMsg("*** All taf followups are rollback from last run. Please contact Administrator. ***");
          con.close();
        } finally {
          try {
            if (commEvent != null) commEvent = null;
            if (journalEvent != null) journalEvent = null;
            if (con != null) con.close();
            System.exit(0);
          } catch (Exception e) {
            recordError(e, "addJournal");
            log.FmtAndLogMsg("*** All taf followups are rollback from last run. Please contact Administrator. ***");
          }
        }
      }
    }

  /***************************************************************/
  /*               Date formatter                                */
 /***************************************************************/
  public static String getDateTimeStr(Timestamp stamp, String formatString) {

      if (stamp==null) return "";
      String dateStr = null;
      Locale curLocale = Locale.getDefault();
      java.util.Date date = (java.util.Date)stamp;

      if(curLocale.equals(Locale.US))
      {
         SimpleDateFormat formatter = new SimpleDateFormat(formatString, curLocale);
         dateStr = formatter.format(date);
      }else
      {
          DateFormat formatter = DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.MEDIUM, curLocale);
          dateStr = formatter.format(date);
      }

      return dateStr;
    }

	public static String stack2string(Exception e) {
		  try {
		    StringWriter sw = new StringWriter();
		    PrintWriter pw = new PrintWriter(sw);
		    e.printStackTrace(pw);
		    return "------\r\n" + sw.toString() + "------\r\n";
		  }
		  catch(Exception e2) {
		    return "bad stack2string";
		  }
	}

}