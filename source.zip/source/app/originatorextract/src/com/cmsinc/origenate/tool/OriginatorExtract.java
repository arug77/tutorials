/*
 * Shaw Dealer Extract
 * Created: Aug 13 2013
 * Description: This program generates a 
 * Originator Extract and either posts or sftps 
 * the data in xml format
 */

package com.cmsinc.origenate.tool;

import com.cmsinc.origenate.util.DBConnection;
import com.cmsinc.origenate.util.IniFile;
import com.cmsinc.origenate.util.LogMsg;
import com.cmsinc.origenate.util.Query;

import java.io.File;
import java.sql.Connection;
import java.sql.Date;
import javax.xml.transform.stream.*;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Vector;
import com.cmsinc.origenate.doc.GenJob;
import com.cmsinc.origenate.originator.extract.OriginatorDataExtract;
import com.cmsinc.origenate.util.OWASPSecurity;
import com.cmsinc.origenate.util.ConnectionUtils;

public class OriginatorExtract 
{
    private static char ch; //cmd line character
	private static LogMsg log = new LogMsg(); //log
	private static OriginatorExtract s1 = new OriginatorExtract(); //class instance
	private static String evaluator_id; //evaluator_id
	private static Connection con; // db connection
	private static String s_iniFile; //ini file location
	private static String dir; //output directory
	private static String profile_id; //profile Id as configured in CM tool Originator Extract
	private static String queryDays = "1"; //days to pull dealers
	private static ArrayList<String> qryOriginatorId;
	private static String stylesheet="";//stylsheet 
	private static String sequenceOwner ="";//ini.getINIVar("database.user").trim();
	private static String encryption_flg="";
	private static String xmlout="";//xml for each dealer;
	private static IniFile ini = new IniFile();
	private static Vector cmdargs = new Vector(10,10);	//Vector to hold the command line args
	private static boolean seperateFilePerOriginator = false;//
	private static boolean sftp_file = false;//
	private static boolean post_file = false;//
	private static boolean queryDays_flg = false;
	private static boolean queryOriginatorId_flg = false;
	private static int output_format_id;
	private static String wtu_query_id = "";
	private static String ftp_user_txt = "";
	private static String ftp_file_server_txt = "";
	private static String ftp_passwordkey_path_txt = "";
	private static String ftp_password_txt = "";
	private static String destination_url_txt = "";
	private static String extract_file_name_txt = "";

	public static void main(String[] args) throws Exception
	{
	/***************************GATHER COMMAND LINE PARAMETERS*************************/
		String s_log_file = "";
		if(args.length>0)
		{
			for (int i=0; i < args.length; ++i) 
			{
				if((args[i].charAt(0) !='-') && (args[i].length() > 1)) 
				{
					showUsageAndExit();
				}
				ch = args[i].charAt(1);
				cmdargs.add(ch);
				switch (args[i].charAt(1))
				{
					case 'i':
						s_iniFile = args[i].substring(2); // ini file
						try
						{
							ini.readINIFile(s_iniFile);
							s_log_file = ini.getINIVar("logs.originator_extract_log_file", "");
							//if no log file path supplied, exit extract
							if(s_log_file.length() > 0)
							{
								log.openLogFile(s_log_file);
							}
							else{
								String printError = "No log file location provided in the ini. Please add log file location to ini.";
								System.out.println(printError);
								throw new Exception(printError);
							}
						}
						catch (Exception e)
						{
							log.FmtAndLogMsg("Caught exception reading ini file '"+s_iniFile+"' :"+e.toString());
						}
						log.FmtAndLogMsg("\r");
						log.FmtAndLogMsg("Starting Shaw Extract Tool");
						log.FmtAndLogMsg("\r");
						log.FmtAndLogMsg("iniFile name: " + s_iniFile);
						break;
					case 'e':
						evaluator_id = args[i].substring(2); // evaluator id
						log.FmtAndLogMsg("evaluator id : " + evaluator_id);
						break;
					case 'p':
						profile_id = args[i].substring(2); // directory location
						log.FmtAndLogMsg("profile selected: " + profile_id);
						break;
					default:
						log.FmtAndLogMsg("Unknown parameter: " + args[i]);
						showUsageAndExit();
						break;
				}
			}
		}
		/*************************GATHERING COMMAND LINE PARAMETERS COMPLETE ******************/

		/* Check if the required command line args are present*/
		try 
		{
			log.FmtAndLogMsg("********Calling checkCmdLineArgs Method********");
			checkCmdLineArgs();
		} 
		catch (Exception e) 
		{
			log.FmtAndLogMsg("Error in checkCmdLineArgs method of : "
				+ e.toString());
		}
		log.FmtAndLogMsg("********checkCmdLineArgs Method Completed********");

		//Check if directory provided in ini is valid (should be 
		try{
			dir = ini.getINIVar("originator_extract.default_extract_location", "");
			validateDirectory(dir);
		}
		catch (Exception e) 
		{
			log.FmtAndLogMsg("Error in checkCmdLineArgs method of : " + e.toString());
		}
		
		/*GET DB CONNECTION */
		try 
		{
			log.FmtAndLogMsg("********Calling getDBConnection Method********");
			getDBConnection(s_log_file);
		} 
		catch (Exception e) 
		{
			log.FmtAndLogMsg("Error in getDBConnection method of : "
				+ e.toString());
		}
		log.FmtAndLogMsg("********getDBConnection Method Completed********");

		/*Run getDataExtract Method */

		try 
		{
			//check if profile active
			String sqlConfig = "SELECT COE.OUTPUT_FORMAT_ID, COE.WTU_QUERY_ID, COE.DESCRIPTION_TXT, COE.STYLESHEET_TXT, " + 
			" COE.FTP_USER_TXT, COE.FTP_FILE_SERVER_TXT, COE.FTP_PASSWORDKEY_PATH_TXT, COE.FTP_PASSWORD_TXT, " + 
			" COE.DESTINATION_URL_TXT, COE.EXTRACT_FILE_NAME_TXT " + 
			" FROM CONFIG_ORIGINATOR_EXTRACT COE " +
			" WHERE COE.EVALUATOR_ID = ? AND COE.ORIGINATOR_EXTRACT_ID = ? AND COE.ACTIVE_FLG = 1 " ;
			//run selection query if none specified, then default to checking only one day
			Query queryConfig = new Query(con);
			queryConfig.prepareStatement(sqlConfig);
			queryConfig.setString(1,evaluator_id);
			queryConfig.setString(2,profile_id);
			queryConfig.executePreparedQuery();
			
			if(queryConfig.next()){
				
				log.FmtAndLogMsg("Success retrieving configuration for Originator Extract, will attempt to run extract.");
				//get values from query.
				output_format_id = Integer.valueOf(queryConfig.getColValue("OUTPUT_FORMAT_ID")); //will never be null (CM wont allow a blank value for this field, and in the db it's not null)
				//the rest of the fields can be null
				wtu_query_id = queryConfig.getColValue("WTU_QUERY_ID","");
				stylesheet = queryConfig.getColValue("STYLESHEET_TXT",""); 
				ftp_user_txt = queryConfig.getColValue("FTP_USER_TXT","");
				ftp_file_server_txt = queryConfig.getColValue("FTP_FILE_SERVER_TXT","");
				ftp_passwordkey_path_txt = queryConfig.getColValue("FTP_PASSWORDKEY_PATH_TXT","");
				ftp_password_txt = queryConfig.getColValue("FTP_PASSWORD_TXT","");
				destination_url_txt = queryConfig.getColValue("DESTINATION_URL_TXT","");
				extract_file_name_txt = queryConfig.getColValue("EXTRACT_FILE_NAME_TXT","");
				//check that the stylesheet configured exists.
				if(stylesheet.length()>0){
					String printOnErr = "Stylesheet configured does not exist ("+stylesheet+"), please verify the name and location of the stylesheet and check configuration."; 
					validateFile(stylesheet,printOnErr);
				}
				
				//run wtu query if one is configured, get returned value.  Otherwise use the default of checking within a 1 day/24 hour period.
				queryDays_flg = true;//reset to false in logic below if a code value is what we need to query by
				boolean continueExtract = true;
				if(wtu_query_id.length()>0){//no need to check if the query is a valid wtu type query bc the CM tool is checking that at time of configuration
					GenJob genJob = new GenJob(con, log);
					Hashtable<String, String> runtimeValues = new Hashtable<String, String>();
					runtimeValues.put("evaluator_id", evaluator_id);
					Query getWtuVals =  genJob.buildAndExecuteQuery(con, wtu_query_id, "", runtimeValues);
					//getWtuVals.executePreparedQuery();
					if(getWtuVals.next()){
						String colType = getWtuVals.getColName(1);
						if(colType.equalsIgnoreCase("DAYS")){
							queryDays_flg = true;
							queryDays = getWtuVals.getColValue(1); //
							queryOriginatorId_flg = false;
						} else if (colType.equalsIgnoreCase("ORIGINATOR_ID")){
							queryOriginatorId_flg = true;
							queryDays_flg = false;
							qryOriginatorId = new ArrayList<String>();
							getWtuVals.reset();
							while(getWtuVals.next()){
								qryOriginatorId.add(getWtuVals.getColValue(1)); //
							}
						}	
					}
					else{
						log.FmtAndLogMsg("Configured Query did not return any values, Originator Extract will not be generated.");
						continueExtract = false;
					}
				}
				
				if(continueExtract){//only false when WTU query is configured but returns no values
					//set flags
					if(output_format_id == 1){ //  MSTR_EXTRACT_OUTPUT_FMT_TYPE.EXTRACT_OUTPUT_DESC_TXT > Write output to a single file on disk
						seperateFilePerOriginator = false;
						sftp_file = true;
						post_file = false;
					} else if (output_format_id == 2){//  MSTR_EXTRACT_OUTPUT_FMT_TYPE.EXTRACT_OUTPUT_DESC_TXT > Write output to seperate files on disk
						seperateFilePerOriginator = true;
						sftp_file = true;
						post_file = false;
					} else if (output_format_id == 3) {//  MSTR_EXTRACT_OUTPUT_FMT_TYPE.EXTRACT_OUTPUT_DESC_TXT > Post output to a specified URL
						seperateFilePerOriginator = false;
						sftp_file = false;
						post_file = true;
					}
					
					if(extract_file_name_txt.length()==0){
						extract_file_name_txt = "OriginatorExtract_%SYSDATE%.xml";
						if(seperateFilePerOriginator){
							extract_file_name_txt = "%ORIGINATOR_CODE%_" + extract_file_name_txt;
						}
					}
					
					//get sequence owner from ini (this is the db owner)
					sequenceOwner = ini.getINIVar("database.user").trim();
					//get encryption flag from ini
					encryption_flg = ini.getINIVar("encryption.encryption_flg");
					
					OriginatorDataExtract.OriginatorContainer odeVars = new OriginatorDataExtract.OriginatorContainer();
					odeVars.setSeperateFilePerOriginator(seperateFilePerOriginator);
					odeVars.setEvaluatorId(evaluator_id);
					odeVars.setExtractFileName(extract_file_name_txt);
					odeVars.setQueryDays(queryDays);
					odeVars.setStylesheet(stylesheet);
					odeVars.setDir(dir);
					odeVars.setSequenceOwner(sequenceOwner);
					odeVars.setSftpFile(sftp_file);
					odeVars.setPostFile(post_file);
					odeVars.setFtpUserTxt(ftp_user_txt);
					odeVars.setFtpFileServerTxt(ftp_file_server_txt);
					odeVars.setFtpPasswordTxt(ftp_password_txt);
					odeVars.setFtpPasswordkeyPathTxt(ftp_passwordkey_path_txt);
					odeVars.setDestinationUrlTxt(destination_url_txt);
					odeVars.setEncryptionFlg(encryption_flg);
					odeVars.setQueryDaysFlg(queryDays_flg);
					odeVars.setQueryOriginatorIdFlg(queryOriginatorId_flg);
					odeVars.setQueryOriginatorId(qryOriginatorId);
					odeVars.setDebugLvl(Integer.parseInt(ini.getINIVar("debug.genx_debug_lvl","0")));
					
					//run the extract
					OriginatorDataExtract ode = new OriginatorDataExtract();
					log.FmtAndLogMsg("Start calling originator extract logic ");
					ode.runExtract(con,log,odeVars);
					log.FmtAndLogMsg("Done calling originator extract logic");
				}
			}
			else{
				log.FmtAndLogMsg("Unable to run Originator extract, the profile id provided (" + profile_id +") is not an active profile for evaluator "+evaluator_id+".  Please try running the extract again with a valid active profile configuration. ");
			}
		} 
		catch (Exception e) 
		{
			log.FmtAndLogMsg("Error in Originator Extract Tool method of : " + e.toString());
		} finally {
			ConnectionUtils.closeConnection(con);
		}
		//log.FmtAndLogMsg("getDataExtract Method Completed");
		log.FmtAndLogMsg("********Originator Extract Tool Completed********");
		System.exit(0);
	}
	/*Method checks if the command line args are present*/
	
	public static void checkCmdLineArgs() 
	{
			if(cmdargs.contains(Character.valueOf('i')) && cmdargs.contains(Character.valueOf('p')) && 
			cmdargs.contains(Character.valueOf('e')))
		{
			log.FmtAndLogMsg("Required Command Line Parameters Present");
		}
		else 
		{
			log.FmtAndLogMsg("Required Command Line Parameters Missing");
			log.FmtAndLogMsg("Calling showUsageAndExit() method to exit");
			showUsageAndExit();
		}
	}
	
	
	/*
	 * check if directory value set in ini is an existing directory.  
	 */
	public static void validateDirectory(String dir){
		try
		{
			
			//if no value supplied, exit extract
			if(dir.length() == 0)
			{
				String printError = "No default directory location provided in the ini for Originator Extract, please add this path to the ini and try again.";
				System.out.println(printError);
				throw new Exception(printError);
			}
			//then Check if the directory is an existing directory.
			
			/**  
			* OWASP TOP 10 2010 - A4 Path Manipulation
			* Changes to the below code to fix vulnerabilities
			* TTp 324955
			*/
			//File file = new File(dir);
			//File file = new File(Encode.forJava(dir));
			File file = new File(OWASPSecurity.validationCheck(dir, OWASPSecurity.DIRANDFILE));
			if (!file.isDirectory()){
				String printError = "Default directory location provided in the ini for Originator Extract is not a valid directory ("+dir+"), please resolve this issue and try again.";
				System.out.println(printError);
				throw new Exception(printError);
			}
			
		}
		catch (Exception e)
		{
			log.FmtAndLogMsg("Caught exception :"+e.toString());
			//dont need to try to close connection here, it wasnt opened yet
			System.exit(0);
		}
	}
	
	/*
	 * check if file exists  
	 */
	public static void validateFile(String fileName, String printError){
		try
		{
			
			/**  
			* OWASP TOP 10 2010 - A4 Path Manipulation
			* Changes to the below code to fix vulnerabilities
			* TTP 324955
			*/
			//File file = new File(fileName);
			//File file = new File(Encode.forJava(fileName));
			File file = new File(OWASPSecurity.validationCheck(fileName, OWASPSecurity.DIRANDFILE));
			if (!file.isFile()){
				//String printError = "Default directory location provided in the ini for Originator Extract is not a valid directory ("+dir+"), please resolve this issue and try again.";
				System.out.println(printError);
				throw new Exception(printError);
			}
			
		}
		catch (Exception e)
		{
			log.FmtAndLogMsg("Caught exception :"+e.toString());
			ConnectionUtils.closeConnection(con);
			System.exit(0);
		}
	}
	

	/*
	 * Method to inform that expected values are missing on the command line.
	 */

	public static void showUsageAndExit() 
	{
		System.out
			.println("Usage: java com.cmsinc.origenate.tool.OriginatorExtract");
		System.out
			.println("-e<evaluator id> -i<ini file> -p<profile id>");
		System.out
			.println("------------------------------------------------------------------------------");
		System.out.println("Parameter	Data Type	Required/Optional				Description");
		System.out.println("  -e 		 Integer	Required						Evaluator ID");
		System.out.println("  -i 		 String		Required						ini file name including the location");		
		System.out.println("  -p		 String		Required						configured profile id ");
		System.exit(0);
	}

	/*get DB connection Method*/

	public static void getDBConnection(String s_log_file) throws Exception 
	{

		try 
		{
			// Get ini file values for DB connection

			String s_dbhost = ini.getINIVar("database.host").trim();
			log.FmtAndLogMsg("dbHost : " + s_dbhost);

			String s_dbport = ini.getINIVar("database.port").trim();
			log.FmtAndLogMsg("dbPort : " + s_dbport);

			String s_dbsid = ini.getINIVar("database.sid").trim();
			log.FmtAndLogMsg("dbSID : " + s_dbsid);

			String s_dbuser = ini.getINIVar("database.user").trim();
			log.FmtAndLogMsg("dbUser : " + s_dbuser);

			String s_dbpassword = ini.getINIVar("database.password").trim();
			
			String sTNSEntry = ini.getINIVar("database.TNSEntry");
			log.FmtAndLogMsg("TNSEntry : " + sTNSEntry);
			
			
			DBConnection DBConnect = new DBConnection();
			
			if (sTNSEntry == null) 
			{
				con = DBConnect.getConnection(s_dbhost, s_dbsid, s_dbuser, s_dbpassword, s_log_file, s_dbport,"");
				//88 con = DBConnect.getConnection(s_dbhost, s_dbsid, s_dbuser, s_dbpassword, s_log_file, s_dbport,"");
				//87 con = DBConnect.getConnection(s_dbhost, s_dbsid, s_dbuser, s_dbpassword, s_log_file, s_dbport);

			} 
			else 
			{
				// use tns entry if available
				con = DBConnect.getConnectionTNS(sTNSEntry, s_dbuser,  s_dbpassword, s_log_file);
			}
		} 
		catch (Exception e) 
		{
			log.FmtAndLogMsg("Failed to Connect to DB:"+e);
			recordError("getDBConnection", e);
		}
	} // end getDBConnection method
	
	//Borrowed from ODE Extract
	public static void recordError(String methodName, Exception err)
		throws Exception 
	{
		try 
		{
			log.FmtAndLogMsg("Error occured in " + methodName + " method of : "	+ err.toString());
			throw new Exception("    Error occured in " + methodName + " method of : " + err.toString());
		} 
		catch (Exception e) 
		{
			log.FmtAndLogMsg("Error in reportError method of : " + e.toString());
		}

	}
}