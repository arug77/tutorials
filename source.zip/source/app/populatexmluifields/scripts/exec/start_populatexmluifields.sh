#!/bin/sh
#
# sample call to reporting db export
#

echo "java -classpath .:../lib/common.jar:../lib/ojdbc6.jar:../lib/xercesImpl-2.10.0.jar:../lib/xml-apis-2.10.0.jar:../lib/xalan-2.7.1.jar com.cmsinc.origenate.xmldbt.PopulateXmlUIFields add_arguments_here"
java -classpath .:../lib/common.jar:../lib/ojdbc6.jar:../lib/xercesImpl-2.10.0.jar:../lib/xml-apis-2.10.0.jar:../lib/xalan-2.7.1.jar com.cmsinc.origenate.xmldbt.PopulateXmlUIFields add_arguments_here

