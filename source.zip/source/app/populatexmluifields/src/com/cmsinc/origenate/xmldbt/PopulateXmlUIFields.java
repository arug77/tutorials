/*
 * PopulateXmlUIFields.java
 *
 * Created on July 16, 2008
 */

package com.cmsinc.origenate.xmldbt;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Vector;
import java.util.StringTokenizer;

import com.cmsinc.origenate.util.DBConnection;
import com.cmsinc.origenate.util.IniFile;
import com.cmsinc.origenate.util.LogMsg;


/**
 */
public class PopulateXmlUIFields {
	private static String sLogFile = "D:\\populatexmluifields_log_file.log";
    static Connection con = null;
    static LogMsg log = new LogMsg();;
    int i_dbg_lvl;
    String dbConnectErr="";

   
    private static String iniFileNm = "c:\\development\\origenate\\config\\origenate.ini";
    private static Character ch;
    private static Vector cmdargs = new Vector(2,2);
    
    private ArrayList<String> displayTxtList = new ArrayList();
    /***************************************************************/
     /*              Main method to call Report Retention process      */
     /***************************************************************/
    public static void main(String args[]) throws Exception {
      if (args.length > 0) {
  		for (int i = 0; i < args.length; ++i) {
  			if ((args[i].charAt(0) != '-') && (args[i].length() > 1)) {
  				showUsageAndExit();
  			}
  			ch = new Character(args[i].charAt(1));
  			cmdargs.add(ch);
  			switch (args[i].charAt(1)) {
  			case 'i':
  				iniFileNm = args[i].substring(2);
  				log.FmtAndLogMsg("iniFile name: " + iniFileNm);
  				break;
  			case 'l':
  				sLogFile = args[i].substring(2);
  				log.FmtAndLogMsg("Log File name: " + sLogFile);
  				break;
  			default:
  				log.FmtAndLogMsg("Unknown parameter: " + args[i]);
  				showUsageAndExit();
  				break;
  			}
  		}

  		 /* Check if the required command line args are present*/
  		try {  			 
  			checkCmdLineArgs();
  		} catch (Exception e) {
  			log.FmtAndLogMsg("Error in checkCmdLineArgs method of : "+ e.toString());
  		}
      
    }
      new PopulateXmlUIFields();
    }
    /***************************************************************/
    /* Create Report Retention obejct and get DB connection         */
    /***************************************************************/
    private static void getDBConnection(String s_iniFile) throws Exception {

      try {
        //Get ini file values for DB connection
        IniFile ini = new IniFile();
        ini.readINIFile(s_iniFile);
        String s_host = ini.getINIVar("database.host");
        String s_port = ini.getINIVar("database.port");
        String s_sid = ini.getINIVar("database.sid");
        String s_user = ini.getINIVar("database.user");
        String s_password = ini.getINIVar("database.password");
        String sTNSEntry = ini.getINIVar("database.TNSEntry", "");
        
        DBConnection DBConnect = new DBConnection();
        
  	  
  	  log.openLogFile(sLogFile);
        if (sTNSEntry.length() == 0) {
      	  con = DBConnect.getConnection( s_host,  s_sid, s_user,  s_password, sLogFile, s_port,"");
        } else {
      	  // use tns entry if available
      	  con = DBConnect.getConnectionTNS(sTNSEntry, s_user,  s_password, sLogFile);
        }
      } catch (Exception e) {
        e.printStackTrace();
    	  log.FmtAndLogMsg("********getDBConnection: " + e +" ********");
      }
    }
    /** Creates new PopulateXmlUIFields passing in db connection, log file, and debug level */
    public PopulateXmlUIFields() throws Exception {
        
        getDBConnection(iniFileNm);
        poulateFields();
        cleanup();
        System.out.println("PopulateXmlUIFields completed successfully");
    }

    //////////////////////////////////////////////////////////////////////////


    public void cleanup() {
        try {con.close();} catch (Exception ec) {}
        if (sLogFile.length()>0) try {log.closeLogFile(); } catch (Exception e3) {}
    }


    public void poulateFields(){
    	PreparedStatement ps=null,ps1=null,ps2=null,ps3=null;
    	ResultSet rs=null,rs1=null;
    	String sql, sql1, sql2, sql3;
    	String fldName="", xPath="", actfldName="",genXPath="";
    	int vType, groupId, maxLen=0, fType ;
    	boolean bRecordExist = false;
    	String displayTxt="",xpath="";   
    	try {
    		System.out.println("loading fields");

    		sql = "select xf.* from xml_fields xf,xml_tables xt " +
    				"where UPPER(xf.TRANSACTION_TYPE_ID)= 'LOANAPPRQ' " +
    				"and xf.process_in_flg = 1 " +
    				"and UPPER(xf.db_field_name_txt) <> 'NONE' and xf.transaction_type_id = xt.transaction_type_id and xf.db_table_seq_num = xt.db_table_seq_num " +
                   // exclude tables that are not app related
                    " and not xt.db_table_name_txt like '%_CONTR%'   and xt.db_table_seq_num not in (42,43,39,86,87,99,117,118,119,120,121,122,123,126) " +
                    "order by xf.db_table_seq_num, xf.field_seq_num";
			ps = con.prepareStatement(sql);
			rs = ps.executeQuery();

            //get xpath value
			sql1 = "select Getparentxpath(?,?,?) from dual";
			
			//get field max length
			sql2 = "SELECT DATA_LENGTH FROM user_tab_columns " +
				  "WHERE table_name = " +
				  "(SELECT db_table_name_txt FROM XML_TABLES " +
				  "WHERE db_table_seq_num = ? " + 
				  "AND transaction_type_id =  ?  ) " +
				  "AND COLUMN_NAME =  ? ";
				  
		    //get ui field id for insert/update		  
			sql3 = "SELECT DISPLAY_TXT FROM XML_UI_FIELDS " +
				"WHERE 	TRANSACTION_TYPE_ID = ? " +
				"AND	DB_TABLE_SEQ_NUM = ? " +
				"AND	FIELD_SEQ_NUM = ?";	  
			 

			while (rs.next()){
				
				/*********
				 * Determine DEFAULT_DISPLAY_TYPE_NUM
                                 1 - text
                                 2 - drop down
                                 3 - flag

                                 -- the following are for config tables only

                                 0 - label only
                                 5 - hidden
                                 6 - separating line
				 **/

				fldName = rs.getString("DB_FIELD_NAME_TXT");
				actfldName = rs.getString("ACTION_TXT");
                if (actfldName==null) actfldName="";
				
					vType = 1; // default

                if(fldName.toUpperCase().endsWith("FLG")){
					vType = 3;       // flag
				}else // if it has a conversion object then its a drop down
                                if( actfldName != null && actfldName.length()>0 &&
                                    (actfldName.indexOf("#") == -1 
                                    && !actfldName.toUpperCase().startsWith("SELECT") 
                                    && !actfldName.toUpperCase().startsWith("TAG") 
                                    && !actfldName.toUpperCase().startsWith("STRIP")
                                    && !actfldName.equals("AutoYear")
                                     )
                                    ) {  // CONVERSION OBJECT
					vType = 2; // drop down
				}else 
				if(fldName.toUpperCase().endsWith("TXT")){
					vType = 1;   // text
				}else 
                                {
				    vType = 1;  // default text
				}

                
                
				/** decide FORMAT_TYPE_NUM
				 * 0 - None
				 * 1 - integer
				 * 2 - Percent
				 * 3 - Date
				 * 4 - Money
				 * 5 - Mask
				 * 6 - SSN
				 * 7 - Phone Number
				 ***************************/
                
				String nodeType = rs.getString("NODE_TYPE_ID");
				String attributeName = rs.getString("ATTRIBUTE_NAME_TXT");

				xPath = rs.getString("PATH_TXT");
				if (xPath==null)xPath="";
				//Get xpath
				if(xPath!=null && xPath.startsWith("..")){					
					ps1  = con.prepareStatement(sql1);
					ps1.setString(1, rs.getString("TRANSACTION_TYPE_ID"));
					ps1.setInt(2, rs.getInt("DB_TABLE_SEQ_NUM"));
					ps1.setString(3, rs.getString("PATH_TXT"));
					rs1 = ps1.executeQuery();
					if(rs1.next()){
						xPath = rs1.getString(1);
					}
					if(ps1!=null)
						ps1.close();
					if(rs1!=null)
						rs1.close();
				}

                if (xPath!=null && xPath.length()>0 && nodeType!=null && nodeType.equals("2") && attributeName!=null) { // attribute
                //log.FmtAndLogMsg("attribute xpath: " + attributeName);
                   xPath+="/@"+attributeName;
                }
				//log.FmtAndLogMsg("xpath="+xPath);
				
				fType = 0;
				if(rs.getString("DB_DATA_TYPE_TXT").toUpperCase().startsWith("DATE")){//date or datetime
					fType = 3;
					vType = 1;
					//log.FmtAndLogMsg("Date field xpath="+xPath);
				}
				else 
				if (xPath.endsWith("Phone") || xPath.endsWith("PhoneNumber")) {
					fType=7; // phonenumber
					//log.FmtAndLogMsg("Phone number field xpath="+xPath);
				}
				else 
					if (xPath.endsWith("SSN")) {
						fType=6; // SSN
						//log.FmtAndLogMsg("SSN field xpath="+xPath);
					}
				else if(rs.getString("DB_DATA_TYPE_TXT").equalsIgnoreCase("number")){
					//log.FmtAndLogMsg("Number field xpath="+xPath);
					int precision = 0;
                                        precision=rs.getInt("PRECISION_NUM");
					if(precision==0){
						fType = 1;  // number
					}else if(precision==2){
						fType = 4; // money
					}else if(precision>2){
                        fType=2; // percent or rate
                    } else {
						fType = 1;
						//log.FmtAndLogMsg("Text field xpath="+xPath);
					}
				}


				// format the db_field name txt for display if we want to use that instead of the tag name


				String tableNum = rs.getString("DB_TABLE_SEQ_NUM");
				String fieldNum = rs.getString("FIELD_SEQ_NUM");
                 // log.FmtAndLogMsg("Processing table: " + tableNum+", Field: "+fieldNum);

				String dbFieldName = rs.getString("DB_FIELD_NAME_TXT");
                                String dbFieldNameDisplay="";
                                if (dbFieldName!=null && dbFieldName.length()>0) {

                                   //log.FmtAndLogMsg("DBFIELDNAME: " + dbFieldName);
                                   String tmp="";
                                   StringTokenizer tok = new StringTokenizer(dbFieldName,"_");
                                   while (tok.hasMoreTokens()) {
                                       tmp = tok.nextToken();
                                       if (!tmp.equals("TXT") && !tmp.equals("ID") && !tmp.equals("DT")) {
                                          if (dbFieldNameDisplay.length()>0)
                                             dbFieldNameDisplay+=" ";
                                          if (tmp.equals("FLG")) 
                                             dbFieldNameDisplay+="Flag";
                                          else
                                             dbFieldNameDisplay+=tmp.substring(0,1).toUpperCase()+tmp.substring(1).toLowerCase();
                                       }
                                  } // while

                                        //    log.FmtAndLogMsg("dbFieldNameDisplay:: " + dbFieldNameDisplay);
                                }    // dbfieldname





				

				
				/*** determine group ******
				 * 1 - Initial Info
				 * 2 - Applicant
				 * 3 - Finance
				 * 4 - Collateral
				 * 5 - Credit
				 **************************/
				groupId = 1;
				if(xPath!= null){
					if(xPath.toUpperCase().contains("CREDIT/")){
						groupId = 5;
					}else if(xPath.toUpperCase().contains("APPLICANT")){
						groupId = 2;
					}else if(xPath.toUpperCase().contains("COLLATERAL")){//Collateral
						groupId = 4;					
					}else if(xPath.toUpperCase().contains("FINANCE")){//Finance
						groupId = 3;					
					}
				}

				
				//get maxlength
                if (fType == 3 || fType == 11)
                    //if the type is a date, the length will always be 10
                    maxLen = 10;
                else {
                    ps1  = con.prepareStatement(sql2);
                    ps1.setInt(1, rs.getInt("DB_TABLE_SEQ_NUM"));
                    ps1.setString(2, rs.getString("TRANSACTION_TYPE_ID"));
                    ps1.setString(3, rs.getString("DB_FIELD_NAME_TXT"));
                    rs1 = ps1.executeQuery();
                    if(rs1.next()){
                        maxLen = rs1.getInt("DATA_LENGTH");
                    }
                    if(rs1!=null)
                        rs1.close();
                    if(ps1!=null)
                        ps1.close();
                }

	
				//decide insert or update record
			 	ps1 = con.prepareStatement(sql3);
				ps1.setString(1, rs.getString("TRANSACTION_TYPE_ID"));
				ps1.setInt(2, rs.getInt("DB_TABLE_SEQ_NUM"));
				ps1.setInt(3, rs.getInt("FIELD_SEQ_NUM"));
				rs1 = ps1.executeQuery();

				//if record exist then get ui_field_id to update row
				if (rs1.next()) {
					bRecordExist = true;
					// System.out.println("Field exists with display Text: " + rs1.getString(1));
				}else{
					bRecordExist = false;
				}
				if(rs1!=null) rs1.close();
				if(ps1!=null) ps1.close();
				//generate field name form last element of xpath
				
				if (xPath!=null && xPath.length()>0 && nodeType!=null && nodeType.equals("2")) { // attribute
					displayTxt = generateName(dbFieldNameDisplay,xPath);
				}else{
					displayTxt = generateName("",xPath);
				}
				
                 // don't include rotuing section fields, or fields that are replaced with global vars, ie) #requestor_id#
                if (xPath != null && xPath.length()>0 && !xPath.contains("/Routing") && !( actfldName.startsWith("#") && actfldName.endsWith("#") ))
				if(!bRecordExist){//insert			
					if(ps2==null){
						sql = "INSERT INTO XML_UI_FIELDS (" +
						"TRANSACTION_TYPE_ID," +
						"DB_TABLE_SEQ_NUM," +
						"FIELD_SEQ_NUM," +
						"GROUP_ID," +
						"DISPLAY_TXT," +
						"XPATH_TXT," +
						"DEFAULT_DISPLAY_TYPE_NUM," +
						"DEFAULT_VALUE_TXT," +
						"DISPLAY_LENGTH_NUM," +
						"MAX_LENGTH_NUM," +
						"FORMAT_TYPE_NUM," + 
						"AUDIT_LAST_UPDATED_DT," +
						"AUDIT_UPDATED_USER_ID" +
						")" +
					"VALUES (" +
						"?," +
						"?," +
						"?," +
						"?," +
						"?," +
						"?," +
						"?," +
						"?," +
						"?," +
						"?," +
						"?," +						 
						"sysdate," +
						"'SYSTEM')";
						ps2 = con.prepareStatement(sql);
					}
					ps2.setString(1, rs.getString("TRANSACTION_TYPE_ID"));
					ps2.setInt(2, rs.getInt("DB_TABLE_SEQ_NUM"));
					ps2.setInt(3, rs.getInt("FIELD_SEQ_NUM"));
					ps2.setInt(4, groupId);
					ps2.setString(5, displayTxt);
					ps2.setString(6, xPath);
					
					ps2.setInt(7, vType);//DEFAULT_DISPLAY_TYPE_NUM
					ps2.setString(8, rs.getString("DEFAULT_IN_VALUE_TXT"));
					ps2.setInt(9, rs.getInt("LENGTH_NUM"));
					ps2.setInt(10, maxLen);
					ps2.setInt(11, fType); 
					ps2.addBatch();
					
                                        // GL. TURN OFF FOR NOW    22- WAS 2
					if(groupId==22){//insert co-applicant and co-signer records
						genXPath = xPath.replace("Applicant", "CoApplicant[@ID='<ID>']");
						for (int i=1;i<=10; i++){
							ps2.setString(1, rs.getString("TRANSACTION_TYPE_ID"));
							ps2.setInt(2, rs.getInt("DB_TABLE_SEQ_NUM"));
							ps2.setInt(3, rs.getInt("FIELD_SEQ_NUM"));
							ps2.setInt(4, groupId);
							ps2.setString(5, displayTxt);
							ps2.setString(6, genXPath.replace("<ID>", String.valueOf(i)));
							ps2.setInt(7, vType);//DEFAULT_DISPLAY_TYPE_NUM
							ps2.setString(8, rs.getString("DEFAULT_IN_VALUE_TXT"));
							ps2.setInt(9, rs.getInt("LENGTH_NUM"));
							ps2.setInt(10, maxLen);
							ps2.setInt(11, fType); 
							ps2.addBatch();
						}
						genXPath = xPath.replace("Applicant", "CoSigner[@ID='<ID>']");
						for (int i=1;i<=10; i++){
							ps2.setString(1, rs.getString("TRANSACTION_TYPE_ID"));
							ps2.setInt(2, rs.getInt("DB_TABLE_SEQ_NUM"));
							ps2.setInt(3, rs.getInt("FIELD_SEQ_NUM"));
							ps2.setInt(4, groupId);
							ps2.setString(5, displayTxt);
							ps2.setString(6, genXPath.replace("<ID>", String.valueOf(i)));
							
							ps2.setInt(7, vType);//DEFAULT_DISPLAY_TYPE_NUM
							ps2.setString(8, rs.getString("DEFAULT_IN_VALUE_TXT"));
							ps2.setInt(9, rs.getInt("LENGTH_NUM"));
							ps2.setInt(10, maxLen);
							ps2.setInt(11, fType); 
							ps2.addBatch();
						}
						 
					}
					
				} else {//update
				
 				   if(ps3==null){
					sql = "UPDATE XML_UI_FIELDS xuf SET " +
						"GROUP_ID = ?, " +
						"XPATH_TXT = ?, " +
						"DEFAULT_DISPLAY_TYPE_NUM = ?, " +
						"DEFAULT_VALUE_TXT = ?, " +
						"DISPLAY_LENGTH_NUM = ?, " +
						"MAX_LENGTH_NUM = ?, " +
						"FORMAT_TYPE_NUM = ?, " +
						"DISPLAY_TXT = ?," +
						"AUDIT_LAST_UPDATED_DT = sysdate, " +
						"AUDIT_UPDATED_USER_ID = 'System' " +
						"WHERE 	TRANSACTION_TYPE_ID = ? " +
						"AND	DB_TABLE_SEQ_NUM = ? " +
						"AND	FIELD_SEQ_NUM = ?";	 
						ps3 = con.prepareStatement(sql);
				 	}	
					ps3.setInt(1, groupId);
					ps3.setString(2, xPath);
					ps3.setInt(3, vType); 
					ps3.setString(4, rs.getString("DEFAULT_IN_VALUE_TXT"));
					ps3.setInt(5, rs.getInt("LENGTH_NUM"));
					ps3.setInt(6, maxLen);
					ps3.setInt(7, fType);
					ps3.setString(8, displayTxt);
					ps3.setString(9, rs.getString("TRANSACTION_TYPE_ID"));
					ps3.setInt(10, rs.getInt("DB_TABLE_SEQ_NUM"));
					ps3.setInt(11, rs.getInt("FIELD_SEQ_NUM"));
					ps3.addBatch();
					
                                        // GL. TURN OFF FOR NOW -- 22 WAS 2
					if(groupId==22){//update co-applicant and co-signer records
						genXPath = xPath.replace("Applicant", "CoApplicant[@ID='<ID>']");
						for (int i=1;i<=10; i++){
							ps3.setInt(1, groupId);							
							ps3.setString(2, genXPath.replace("<ID>", String.valueOf(i)));
							ps3.setInt(3, vType); 
							ps3.setString(4, rs.getString("DEFAULT_IN_VALUE_TXT"));
							ps3.setInt(5, rs.getInt("LENGTH_NUM"));
							ps3.setInt(6, maxLen);
							ps3.setInt(7, fType);
							ps3.setString(8, displayTxt);
							ps3.setString(9, rs.getString("TRANSACTION_TYPE_ID"));
							ps3.setInt(10, rs.getInt("DB_TABLE_SEQ_NUM"));
							ps3.setInt(11, rs.getInt("FIELD_SEQ_NUM"));
							ps3.addBatch();
						}
						genXPath = xPath.replace("Applicant", "CoSigner[@ID='<ID>']");
						for (int i=1;i<=10; i++){
							ps3.setInt(1, groupId);							
							ps3.setString(2, genXPath.replace("<ID>", String.valueOf(i)));
							ps3.setInt(3, vType); 
							ps3.setString(4, rs.getString("DEFAULT_IN_VALUE_TXT"));
							ps3.setInt(5, rs.getInt("LENGTH_NUM"));
							ps3.setInt(6, maxLen);
							ps3.setInt(7, fType);
							ps3.setString(8, displayTxt);
							ps3.setString(9, rs.getString("TRANSACTION_TYPE_ID"));
							ps3.setInt(10, rs.getInt("DB_TABLE_SEQ_NUM"));
							ps3.setInt(11, rs.getInt("FIELD_SEQ_NUM"));
							ps3.addBatch();
						}
					} 
				}

			} // loop for each field
			
			//execute batch of insert and update
			if(ps2!=null) {
				log.FmtAndLogMsg(ps2.executeBatch().length + " Rows Inserted.");
				ps2.close();
			}	
			if(ps3!=null) {
				log.FmtAndLogMsg(ps3.executeBatch().length + " Rows Updated." );
				ps3.close();
			}	
	 
			log.FmtAndLogMsg("poulateFields() Completed Successfully.");
		} catch (SQLException e) {
			log.FmtAndLogMsg(e.getMessage());
			e.printStackTrace();
		}finally{
			try {
				ps.close();
				rs.close();
				if(ps1!=null)
				ps1.close();
				if(rs1!=null)
				rs1.close();
				if(ps2!=null)
					ps2.close();
				if(ps3!=null)
					ps3.close();
			} catch (SQLException e) {
				log.FmtAndLogMsg(e.getMessage());
				e.printStackTrace();
			}
		}
    	
    }
    /**
     * Method to generate unique name to display
     * @param fldName
     * @param xmlStr
     * @return
     */
    private String generateName(String fldName, String xmlStr){
    	String preStr="", postStr="", tmpStr="";
    	String str = xmlStr;
		if (str == null||str.equalsIgnoreCase("")) return fldName;
		if (str.endsWith("/Date")) str=str.substring(0,str.length()-5);
		
		if(fldName.equalsIgnoreCase("")){
			if(str.contains("/")){
				fldName = str.substring(str.lastIndexOf("/")+1);
			}
			if(fldName != null && fldName.contains("[")){
				fldName = fldName.substring(0,fldName.indexOf("["));
			}
			if (fldName == null||fldName.equalsIgnoreCase("")) return "";
				//fldName = str;
		}
		StringBuffer sb = new StringBuffer();

		if(str.contains("/ContactInfo")){
			tmpStr = str.substring(0,str.indexOf("/ContactInfo"));
			preStr = tmpStr.substring(tmpStr.lastIndexOf("/")+1)+ " ";
			if(preStr.equalsIgnoreCase("Individual ")){
				preStr = "Applicant ";
			}
		}else if(str.contains("Specification")){
			/*for specification*/
			if(str.contains("[@Type='")){
				tmpStr = str.substring(str.indexOf("[@Type='")+8);
				postStr = " for " + tmpStr.substring(0,tmpStr.indexOf("']"));
			}
			tmpStr = str;
			while(tmpStr.contains("[@Name='")){
				
				tmpStr = tmpStr.substring(tmpStr.indexOf("[@Name='")+8);
				if(!preStr.equalsIgnoreCase(""))
					preStr += "- ";
				preStr += (tmpStr.substring(0,tmpStr.indexOf("']")) + " ");
			}
		}else if(str.contains("[@Type='")){
			tmpStr = str.substring(str.indexOf("[@Type='")+8);
			postStr = " for " + tmpStr.substring(0,tmpStr.indexOf("']"));
		}
		//find out prefix value
		if(preStr.equalsIgnoreCase("")){
			if(str.contains("/Closing/") && !fldName.contains("Closing")){
				preStr = "Closing ";
			}else if(str.contains("/Finance/") && !fldName.contains("Finance")){
				preStr = "Finance ";
			}else if(str.contains("/Lease/") && !fldName.contains("Lease")){
				preStr = "Lease ";
			}else if(str.contains("/Originator/") && !fldName.contains("Originator")){
				preStr = "Originator ";
			}else if(str.contains("/HMDA/") && !fldName.contains("HMDA")){
				preStr = "HMDA ";
			}else if(str.contains("/Business/") && !fldName.contains("Business")){
				preStr = "Business ";
			}
		}

		if(!preStr.equalsIgnoreCase("") && !str.startsWith(preStr)){
			fldName = preStr + fldName;
		}
		if(!postStr.equalsIgnoreCase("") && !str.endsWith(postStr)){
			fldName += postStr;
		}

		char[] strAsChars = fldName.toCharArray();
		sb.append(strAsChars[0]);
		int i;
		for (i=1; i<strAsChars.length-1; i++) {
			if ((!Character.isWhitespace(strAsChars[i-1]))&& Character.isLetter(strAsChars[i+1]) && Character.isUpperCase(strAsChars[i])&&(!Character.isUpperCase(strAsChars[i+1]))) {
				sb.append(" ");
			}
			sb.append(strAsChars[i]);
		}
		sb.append(strAsChars[i]);
		fldName = sb.toString();
		//check is it unique
		if(displayTxtList.contains(fldName)){
			//fldName = getUniqueDisplayName(fldName, xmlStr);
	    	String uName=fldName;
	    	preStr = xmlStr.substring(0, xmlStr.lastIndexOf("/"));
	    	preStr = preStr.substring(preStr.lastIndexOf("/")+1);
			if(preStr != null && preStr.contains("[")){
				preStr = preStr.substring(0,preStr.indexOf("["));
			}
			
			if(!uName.contains(preStr))
	    		uName = preStr+ " " +uName;
	    	int indx=2;
	   		while(displayTxtList.contains(uName)){
	    		if(uName.endsWith(""+indx))
	    			uName = uName.substring(0,uName.length()-1);
	   			uName = uName+indx;
	    		indx++;
	    	}
	   		fldName = uName;
		}

		//record in fieldnames
		displayTxtList.add(fldName);
		return fldName;
    }
	/*
	 * Method to inform that expected values are missing on the command line.
	 */
	public static void showUsageAndExit() {
		System.out
				.println("Usage: java com.cmsinc.origenate.xmldbt");
		System.out
				.println("-i<ini file>  -l<logfile location>");
		System.out
				.println("------------------------------------------------------------------------------");
		System.out.println("Parameter	Data Type	Required/Optional			Description");
		System.out.println("  -i 		 String			Required		ini file name including the location");
		System.out.println("  -l		 String 		Optional		Location of log file");
		System.exit(0);
	}   
	/*checks if the command line args are present*/
	
	public static void checkCmdLineArgs() {
		if(!cmdargs.contains(new Character('i'))) {		 
			log.FmtAndLogMsg("Required Command Line Parameters Missing");
			log.FmtAndLogMsg("Calling showUsageAndExit() method to exit");
			showUsageAndExit();
		}
	}
} // PopulateXmlUIFields

