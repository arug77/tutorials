#!/bin/ksh
# script to run ATT -- App Transfer Tool -- from the UNIX command line.
# Typically this command is called from Origenate.

if [ -r ./setenvatt.sh ]
then
	. ./setenvatt.sh
elif [ "$ORCONFIG". != . -a -d "$ORCONFIG" -a -f "$ORCONFIG"/setenvatt.sh ]
then
	. $ORCONFIG/setenvatt.sh
else 
	echo "$0: ERROR, Cannot find setenvatt.sh file. ORCONFIG='$ORCONFIG'!"
	exit 1
fi

##########
# Check that everything that needs to be set, is set.
if [ "$ATTINIFILE". = . -o "!" -r $ATTINIFILE ]
then
	echo "$0: ATTINIFILE='$ATTINIFILE' not set, or INI file not readable."
	echo "ATTINIFILE should have been specified in setenvatt.sh."
	exit 2
fi
if [ "$ATTBASE". = . -o "!" -d "$ATTBASE" ]
then
	echo "$0: ATTBASE='$ATTBASE' not set, or not a valid directory."
	echo "ATTBASE should have been specified in setenvatt.sh."
	exit 2
fi
if [ "$ATTLOGFILE". = . ]
then
	ATTLOGFILE=ATT.log	# default in current directory.
fi
	


##########
# declare a routine for later use
Usage()
{
cat <<-EOF
Usage:
  Import:
    ATT IMPORT USERNAME=EvaluateUserId PASSWORD=EvaluateUserPasswd 
      ARCHIVENAME=NameOfArchive IMPORTFROMLOCATION=FullPathNameOfArchiveToImport 
      ORACLEDIROBJECT=OracleDirectoryObjectName
  
  Export, specifying a range of apps:
    ATT EXPORT USERNAME=EvaluateUserId PASSWORD=EvaluateUserPasswd 
      ARCHIVENAME=NameOfArchive EVALUATORNAME=Evaluator 
      APPNOFROM=StartingAppNumber APPNOTHROUGH=EndingAppNumber
  
  Export, specifying a selection criteria:
    ATT EXPORT USERNAME=EvaluateUserId PASSWORD=EvaluateUserPasswd 
      ARCHIVENAME=NameOfArchive EVALUATORNAME=Evaluator 
      MAXNOAPPS=MaxNumberAppsToArchive DATEFROM=FromInitialDate DATETHROUGH=ToInitialDate 
      [APPSTATUS=AppStatus] [DECSTATUS=DecisionStatus] 
      [TASKID=CurrentTask] [ANALYSTUSER=DecisioningUser]

  Date formats are mm-dd-yyyy.

EOF
}

cd $ATTBASE

exec  >> $ATTLOGFILE 2>&1	# Output into ATT.log file

echo "***** $(date) Executing $0 $@"

if [ "$1". = . ]
then
  echo "$0: Missing arguments"
  Usage
  exit 1
fi

./ATT "$@" CONFIG="$ATTINIFILE" LOGFILE="$ATTLOGFILE"