# setenvatt.sh:
# Set environment variables for ATT -- App Transfer Tool
# This command is called from runATT.sh.

#########################################################
# The next lines may need to be set for each installation.
# The settings in this file as distributed assume that it is being run
# from Origenate, and Origenate has set $ORAPPS, $ORCONFIG, $ORLOGS.

ORACLE_HOME=/opt/oracle9; export ORACLE_HOME
	# The location of the Oracle 9 drivers.	MUST be Oracle 9 or higher.
ATTBASE=$ORAPPS/att; export ATTBASE
	# Location of the ATT executable files
	# For Origenate, usually $ORAPPS/att.
ATTINIFILE=$ORCONFIG/ATT.ini ; export ATTINIFILE
	# Location of the ATT.ini file
	# For Origenate, usually $ORCONFIG/ATT.ini. Otherwise $ATTBASE/ATT.ini.
ATTLOGFILE=$ORLOGS/ATT.log ; export ATTLOGFILE
	# Location of the ATT.log file.
	# For Origenate, usually $ORLOGS/ATT.log. Otherwise $ATTBASE/ATT.log.

#########################################################
# The rest of this file is usually left unchanged.

ATTLIBPATH=$ATTBASE/lib; export ATTLIBPATH
LD_LIBRARY_PATH=$ATTLIBPATH:$ORACLE_HOME/lib::$LD_LIBRARY_PATH; export LD_LIBRARY_PATH
SHLIB_PATH=$ATTLIBPATH::$SHLIB_PATH; export SHLIB_PATH



