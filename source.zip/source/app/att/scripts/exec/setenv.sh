RWPATH=$ORAPPS/att
export ORACLE_HOME=/opt/oracle9
export LD_LIBRARY_PATH=$RWPATH/lib::$ORACLE_HOME/lib;
SHLIB_PATH=$RWPATH/lib;				    export SHLIB_PATH
