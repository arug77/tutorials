#!/bin/ksh
#
#  JAVA Process 
#
#  Author:  Craig Nauman 07/20/2005
#
##############################
#### Environment Variables
export vEnv=$1
export vLog=$ORLOGS/GenPQProcessor.log

java -Xms64m com.cmsinc.origenate.tool.pqp.PostQueueProcessor -u$vEnv -n3 -i$ORCONFIG/origenate.ini -s2 -T\'R-XML\' >> $ORLOGS/GenPQProcessor.log &
exit 0

