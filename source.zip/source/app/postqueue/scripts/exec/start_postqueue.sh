#!/bin/sh
#
# Starts the Post Queue Processor
#
# Make sure origenate.ini is set up properly before running this process
#
INIFILE=$ORCONFIG/$ENVPATH.ini
HOSTNAME=`hostname`

nohup java -Xms64m com.cmsinc.origenate.tool.pqp.PostQueueProcessor -n3 -i$INIFILE -uhttp://$HOSTNAME/postreceive/default.cfm -s2 -T\'R-XML\' $1 >> $ORLOGS/GenPQProcessor.log &
exit 0
