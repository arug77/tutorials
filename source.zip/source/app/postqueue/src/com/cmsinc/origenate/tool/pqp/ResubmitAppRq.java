package com.cmsinc.origenate.tool.pqp;

//import java.sql.*;
//import com.cmsinc.origenate.xmldbt.Translator;
//import com.cmsinc.origenate.xmldbt.RecordInsert;
//import com.cmsinc.origenate.xmldbt.ValidationException;
//import org.apache.xerces.parsers.DOMParser;
//import org.w3c.dom.*;
//import org.xml.sax.InputSource;
//import org.apache.xalan.xslt.XSLTInputSource;
//import org.apache.xalan.xslt.XSLTResultTarget;
//import org.apache.xalan.xslt.XSLTProcessor;
//import org.apache.xalan.xslt.XSLTResultTarget;
//import org.apache.xalan.xslt.StylesheetSpec;
//import org.apache.xerces.dom.DocumentImpl;
//import com.cmsinc.origenate.util.LogMsg;
//import com.cmsinc.origenate.util.XPathAPI;
//import com.cmsinc.origenate.util.RecordData;
//import com.cmsinc.origenate.util.IniFile;
//import com.cmsinc.origenate.event.JournalEvents;
//import com.cmsinc.origenate.util.Query;
//import java.io.*;
//import java.net.*;
//import oracle.jdbc.OracleResultSet;
import com.cmsinc.origenate.util.SQLUpdate;
//import com.cmsinc.origenate.util.Query;
//import java.util.Vector;
//import com.cmsinc.origenate.util.PostRequest;
//import com.cmsinc.origenate.workflow.*;


/**
 * <pre>
 *
 * This class is loaded by InsretPostObject.java to process an incoming XML transaction
 * when no other Controller class for the transaction type is found.
 * 
 *
 * If you are implementing a Controller for a particular trans type ( LoanAppRq )
 * then make a copy of this .java file and rename it to LoanAppRq.java. Then change
 * the class name and constructor and add any business logic in runController
 * as required.
 *
 * </pre>
 *
 */
public class ResubmitAppRq extends com.cmsinc.origenate.webservices.utils.BaseController {


    public void ResubmitAppRq() {};


    /////////////////////////////////////////////////////////////////////////////////////////



    public void runController() throws Exception {



        /*
        In its unaltered form the DefaultController class simply loads the supplied XML into the database
        in either create mode or update (based on a matching remoteRefNum in the XML.

        If a validation error occurs it will optionally send a noload notification back to
        the sender based on the EIP (Network) and the settings in the XREF_SOURCE_STATES
        table (use the network tool to setup). 

        If the load is successful it will optionally send a LOAD notification using the 
        same technique.

        You can override sending notifications by setting the boolean sendNotification to false


        */





        try {


           getRoutingInfo();  // sets BaseController instance variables if they exist in the xml
                              // transID (ie. LoanAppRq), network (ie. COL),
                              // remoteRefNum, evaluator_id, etc
                              // see method in base class for a complete list


           // All transactions MUST specify a network and evaluator ID

           /*  VALIDATE  NETWORK  AGAINST  EVALUATOR

           Verify that the Network (EIP) is valid for the evaluator.
           The xref_eval_networks table lists all networks that are valid for a given evaluator
           If its not valid then validateEvaluatorNetwork will throw a ValidationException

           network_id and evaluator_id were pulled from the xml by getRoutingInfo()
           */

           validateEvaluatorNetwork(network,evaluator_id);



           //  P R E P R O C E S S I N G   G O E S   H E R E 




           //  L O A D    X M L   T O    D A T A B A S E



           loadXML();


        }
        catch (Exception e) {


            // errorMsg is set by loadXML, etc

            // You can check the following booleans to see what type of error
            // occurred. A verification error happens when a column failed
            // a valiadtion like invalid state code, a general error occurs
            // when an unexpected error occurs like a null pointer exception

            // here for your use
            if (validationErrorOccurred || generalErrorOccurred) {
            }

            // FAILED TO LOAD, see if we need to send a notification back to the originator
            // based on EIP

            /*
            The network in a xml doc is the EIP (External Internet Partner) ID.
            If an entry exists in the xref_source_states for a NOLOAD state for this
            EIP then send a notification to this partner by putting an entry on the routing
            queue that specifies an action that will send a response to the response_url.
             */

            // loadXML() sets network,transID, etc.

            if (sendNotification)
                try {sendNotification("NOLOAD",network,transID,errorMsg,e.toString(),requestID,remoteRefNum,clientAppID,evaluator_id);}
                catch (Exception e1) {
                    // don't throw an error, not important enough, just log it
                    log_obj.FmtAndLogMsg("Error processing NOLOAD Notification: " + e1.toString());
                }




            throw (e);   // throw it back to the caller so they can set the status of 
                         // the job to error

        } // exception




        //   S U C C E S S F U L     L O A D



        // D O    P O S T    L O A D    P R O C E S S I N G 



	
        // Update the app_resubmit_flg in the credit request table
        // so the queue will show a flashing icon that a comment was received
		// Michaelsw. CL155465. We now want to support resubmit remarks based on the latest_final_dec_ref_id
		// of the resubmitted app. Supporting two new columns to handle date and latest decision.
		SQLUpdate sqlup = new SQLUpdate();
        try {
            //TTP 324955 Security Remediation Fortify Scan
            sqlup.SetPreparedUpdateStatement(con,"UPDATE CREDIT_REQUEST SET app_resubmit_flg = 1, "+
						"app_resubmit_dt = sysdate, app_resubmit_num = (" + 
						"select decode(count(1),0,3,max(app_resubmit_num)) as app_resubmit_num from ("+
						"select decode(crde.decision_id,3,0,102,0,1,1,2,2,103,2,3) as app_resubmit_num "+
						"from credit_request cr, credit_req_decisions_evaluator crde "+
						"where cr.request_id = ?" +
						" and cr.request_id = crde.request_id "+
						"and cr.latest_final_dec_ref_id = crde.decision_ref_id)"+
						") WHERE REQUEST_ID = ?");
            sqlup.setInt(1, requestID);
            sqlup.setInt(2, requestID);
            sqlup.RunPreparedUpdateStatement();
        }
        catch (Exception e) {
            log_obj.FmtAndLogMsg("Can't update credit_request.app_resubmit_flg for jobID:"+jobID+" request_id:"+requestID+" err="+e.toString());
            // not serious enough to abort
        }


        // unlock the app
        try {
			//TTP 324955 Security Fortify Scan

			String deleteStmnt = "delete from concurrency_control WHERE "+
               "REQUEST_ID = ? and lock_type_id = 2";
			sqlup.SetPreparedUpdateStatement(con,deleteStmnt);
			sqlup.setInt(1,requestID);
			sqlup.RunPreparedUpdateStatement();
        }
        catch (Exception e) {
            log_obj.FmtAndLogMsg("Failed to unlock app, request id = "+requestID+", err="+e.toString());
            // not serious enough to abort
        }


        // delete the outstanding pending CRDE row if one exists (waiting for the decision to come back)

        try {
			//TTP 324955 Security Fortify Scan
	
			String deleteStmnt = "delete from credit_req_decisions_evaluator where "+
                "REQUEST_ID = ? and decision_category_id = 4";
			sqlup.SetPreparedUpdateStatement(con,deleteStmnt);
			sqlup.setInt(1,requestID);
			sqlup.RunPreparedUpdateStatement();	
				
        }
        catch (Exception e) {
            log_obj.FmtAndLogMsg("Failed to remove CRDE for request_id:"+requestID+" err="+e.toString());
            // not serious enough to abort
        }


        // NOW REDIRECT THE APP TO THE 'EDIT REQUIRED' TASK IN UNDERWRITING


        try {
          // have to do it manually until akash's rtn doesn't throw a integrity constraint
          // WorkFlowManager wfm = new WorkFlowManager(con, log_obj);
          // wfm.setNewTaskandTaskGroup(Long.parseLong(requestID),"EDIT REQUIRED", "UNDERWRITING", "SYSTEM");
           String selct="update credit_request set task_id = 'EDIT REQUIRED', TASK_GROUP_ID = 'UNDERWRITING', AUDIT_UPDATED_user_id = 'SYSTEM', AUDIT_LAST_UPDATED_DT = SYSDATE WHERE REQUEST_ID = "+requestID;
           SQLUpdate.RunUpdateStatement(con,selct);
        }
        catch (Exception e) {
            log_obj.FmtAndLogMsg("Failed to redirect to EDIT REQUIRED task, request_id:"+requestID+" err="+e.toString());
            // not serious enough to abort
        }


        // If got this far then we successfully loaded the XML into the database
        // requestID = the assigned request_id

        // see if the originator wants to be notified of successful loads

        if (sendNotification)
          try {sendNotification("LOAD",network,transID,"Successful","Successfully loaded",requestID,remoteRefNum,clientAppID,evaluator_id);}
              catch (Exception e1) {
                  log_obj.FmtAndLogMsg("Error processing LOAD Notification: " + e1.toString());
              }




        // if haven't thrown an error by now then the calling PQP will delete the
        // job row from the PQP queue



    }  // runController()









} // LenderLinkDecRs


