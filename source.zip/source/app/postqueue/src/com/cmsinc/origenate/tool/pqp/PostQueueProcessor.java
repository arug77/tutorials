/*
 * PostQueueProcessor.java
 *
 * Created on June 14, 2000, 1:43 PM
 *
 * Converted to use oracle.jdbc
 * and logged all errors to System.out instead of System.err
 * August 7th, 2000
 *
 */

package com.cmsinc.origenate.tool.pqp;

import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Enumeration;
import java.util.StringTokenizer;
import java.util.Vector;

import com.cmsinc.origenate.crypto.Crypto;
import com.cmsinc.origenate.crypto.CryptoFactory;
import com.cmsinc.origenate.util.COLEncrypt;
import com.cmsinc.origenate.util.IniFile;
import com.cmsinc.origenate.util.LogMsg;
import com.cmsinc.origenate.util.RecordData;
//import com.cmsinc.origenate.util.SQLUpdate;
import com.cmsinc.origenate.util.OWASPSecurity;

/**
 *
 * @author  marca
 * @version
 */
public class PostQueueProcessor {

   String sIniFile="";
    String sURL = "";
    String sHost = "";
    String sSIDname = "";
    String sUser = "";
    String sPort = "";
    String sPass = "";
    String sTNSEntry = "";
    String xsltDir="";
    String sRunningOnTransType = "";
	String[] listTransTypes = new String[0];
    LogMsg log_obj = null;
    long lSleepSecs;
    //boolean bDebug;
    IniFile ini= new IniFile();
    int maxThreads=1;
    int conn_to_secs = 60;
    Vector processThreads=null;
    int runningThreads;
	int numRetries=0, waitTime=0, maxRetries=0;
    int i_dbg_level=0;
    boolean storeXML=true;   // -x will turn it off
	boolean encryption_flg = false; // Used for Encryption 
	boolean includeSourceList = true;

    String[] sourceList=new String[0]; // 159112, set by -L param to specify list of sources to process only ie) -L'DDS','RT1'
    // -l : lowercase means any source but the one specified (only one specified) ie) -l'DDS'
    // -L and -l are mutually exclusive, they can not exist on the cmd line at the same time.


    /*
      GL. When submittng entries to the routing queue for eval_scoring we want the optional ability to
      evenly distribute the routing state ids that are assigned. They will all cause scoring to be done but we
      can set up separate routing queue processors to handle the load at the same time by looking for different
      routing state ids. A new optional command line parm -r can specify the routing states to iterate thru.
      Routing states 24-30 for additional eval scores must be in the mstr_routing_states table.
      See LoanAppRq for other details when submitting to the routing queue,
    */

    String sRoutingStateIDs = "13"; // when submitting eval_scoring requests on the routing queue (LoanAppRq)
    Vector routingStateIDs = new Vector();
    int lastRoutingIdx=1;

    File eojFile = null; // 162583 - if this file is specified with the -z parm then the presence of this file will cause the pgm to shutdown gracefully
    int jobCount=0; // the first 3 jobs, will wait 10 secs before assigning a new job so as not to overrun eValuate on startup

    public PostQueueProcessor() {
        log_obj = new LogMsg();
        log_obj.setLogID("MAIN: ");
    }

    /////////////////////////////////////////////////////////////////////////////////


    public static void main (String args[]) {

        PostQueueProcessor pqp = new PostQueueProcessor();

        try {
          pqp.run(args);
        }
        catch (Exception e) {} // error already reported

        System.exit(0);
    }


    ////////////////////////////////////////////////////////////////////////////////

    void run(String args[]) throws Exception {

        String sConStr = "";
        Vector vec_rd= new Vector();
        RecordData rd = null;


        GetArgs(args,log_obj);

        /*  159988 - if maxretries,waittime, and store xml have not been specified on startup parms then get them from the
        origenate.ini file.
        */

        if (maxRetries==0) maxRetries  = Integer.parseInt(ini.getINIVar("postqueue.max_retries","0")); 
        if (waitTime==0) waitTime  = Integer.parseInt(ini.getINIVar("postqueue.wait_time","0")); 
        if (storeXML) storeXML= ini.getINIVar("postqueue.store_xml","1").equals("1"); 
        log_obj.FmtAndLogMsg("maxRetries = "+maxRetries);
        log_obj.FmtAndLogMsg("waitTime = "+waitTime);
        log_obj.FmtAndLogMsg("storeXML = "+storeXML);
           

        log_obj.FmtAndLogMsg("PostQueueProcessor running for trans type "+sRunningOnTransType+"...");


        // GL. load up the vector for keeping track of submitted routing state IDs in LoanAppRq class
        StringTokenizer t = new StringTokenizer(sRoutingStateIDs, ",");
        String id="";
        while (t.hasMoreTokens()) {
            id = t.nextToken();
            routingStateIDs.addElement(id);
        }




        // sConStr should be something like:
        // "jdbc:oracle:thin:@172.16.17.108:1521:cmsiprod"
        sConStr = "jdbc:oracle:thin:@";

		if (sTNSEntry.length() == 0) {
			sConStr = sConStr + sHost + ":" + sPort + ":" + sSIDname;
		} else {
			// use tns entry if available
			sConStr = "jdbc:oracle:thin:@" + sTNSEntry;
		}
        
        // Load Oracle driver
        try {
        DriverManager.registerDriver (new oracle.jdbc.OracleDriver());
        }
        catch (Exception e) {
            log_obj.FmtAndLogMsg(e.toString());
            return;
        }

        Connection con = null;
		//Statement stmt = null;
        ResultSet rs = null;
        PreparedStatement ps = null;

        //
        // This loop will force the program to continue retrying connecting to the db
        // if an exception occurs from here down into the main loop
        //

        while (true) { // until killed



            //  S T A R T     P R O C E S S    T H R E A D S

            log_obj.FmtAndLogMsg("Creating process threads...");
            processThreads = new Vector();
            runningThreads=0;
            for (int i=0; i<maxThreads; i++) {

                ProcessThread pt=null;
                try {pt = new ProcessThread(this,sConStr,sUser,sPass,i+1,i_dbg_level);}
                catch (Exception e) {
                    log_obj.FmtAndLogMsg("Error starting thread "+(i+1)+", error="+e.toString());
                    pt=null;
                }
                if (pt!=null) {
                   processThreads.addElement(pt);
                   pt.start(); // they will wait until they are given work to do
                   runningThreads++;
                }
            }

            log_obj.FmtAndLogMsg(runningThreads+" threads running...");

            if (runningThreads==0) break;

            /* 141699 - Perf, using prepared statements now */
            boolean initFailed = false;
			
			if(!sRunningOnTransType.equals("")) {
				listTransTypes = sRunningOnTransType.split(",");
				for(int i = 0; i < listTransTypes.length; i++) {
					listTransTypes[i] = listTransTypes[i].replace("'","");
				}
			}

            String sql = "SELECT TRANSACTION_ID, PQH.TRANSACTION_TYPE_ID, NVL(TRIES_NUM,0) AS TRIES_NUM, MPT.MAX_RETRIES_NUM " +
                "FROM POSTING_QUEUE_HEADER PQH, MSTR_POSTING_TRANSACTIONS MPT " +
                "WHERE PQH.STATUS_ID <> -1 AND PQH.STATUS_ID <> 1 AND PQH.TRANSACTION_DT < SYSDATE " + // STATUS_ID <> -1 AND STATUS_ID <> 1  -1 = actively posting 1 = failed validations
                " AND PQH.TRANSACTION_TYPE_ID IN (";
            StringBuilder temp_builder1 = new StringBuilder(sql);
				for(int i = 0; i < listTransTypes.length; i++) {
                    temp_builder1.append("?");
					if(i < (listTransTypes.length - 1)) {
                        temp_builder1.append(",");
                    }
				}
                
                sql = temp_builder1.toString();
				sql += ") "+
                " AND PQH.TRANSACTION_TYPE_ID = MPT.TRANSACTION_TYPE_ID "+
                " AND NVL(PQH.TRIES_NUM,0) <= MPT.MAX_RETRIES_NUM ";
            // 159112 gl. 6/18/12 if source_txt filtering is specified on the command line then include it, otherwise it will be an empty string
                 if(sourceList.length > 0) {
					sql += " and pqh.source_txt ";
					
					if(includeSourceList) sql += "in (";
					else sql += "not in (";
                    
                    StringBuilder temp_builder2 = new StringBuilder(sql);
					
					for(int i = 0; i < sourceList.length; i++) {
                        temp_builder2.append("?");
						if(i < (sourceList.length - 1)) {
                            temp_builder2.append(",");
                        }
					}
                    sql = temp_builder2.toString();
					sql += ") ";
				 }
                sql+=" ORDER BY TRANSACTION_ID";

            log_obj.FmtAndLogMsg("PQP job select sql: " + sql);  // 159112 - added log to show pqp select sql



            try {
               // Connect to the Oracle database
               con = DriverManager.getConnection (sConStr,sUser,sPass);
               ps = con.prepareStatement(sql);
			   int parameterNum = 1;
			   for(int i = 0; i < listTransTypes.length; i++) {
					ps.setString(parameterNum, listTransTypes[i]);
					parameterNum++;
			   }
			   for(int i = 0; i < sourceList.length; i++) {
					ps.setString(parameterNum, sourceList[i]);
					parameterNum++;
			   }
            }
            catch (Exception e) {
               initFailed=true;
               log_obj.FmtAndLogMsg("Severe Error: "+e.toString());
               try {ps.close();} catch (Exception e1) {}
               try {con.close();} catch (Exception e1) {}
            }



            if (!initFailed)
            try {


                // re-using prepared statement now
                // stmt = con.createStatement();


                //
                // main loop runs forever
                //
                while (true) {


                   if (eojFile!=null && eojFile.exists()) {
                      log_obj.FmtAndLogMsg("Gracefull shutdown detected, shutting down...");
                      break;
                   }

                    //log_obj.FmtAndLogMsg("Running query");

                    rs = ps.executeQuery();
                    /* 141699 - performance: using prepared statement now
                    rs = stmt.executeQuery(   "SELECT TRANSACTION_ID, PQH.TRANSACTION_TYPE_ID, NVL(TRIES_NUM,0) AS TRIES_NUM, MPT.MAX_RETRIES_NUM " +
                        "FROM POSTING_QUEUE_HEADER PQH, MSTR_POSTING_TRANSACTIONS MPT " +
                        "WHERE PQH.STATUS_ID <> -1 AND PQH.STATUS_ID <> 1 AND PQH.TRANSACTION_DT < SYSDATE " + // STATUS_ID <> -1 AND STATUS_ID <> 1  -1 = actively posting 1 = failed validations
                        " AND PQH.TRANSACTION_TYPE_ID IN (" + sRunningOnTransType +") "+
                        " AND PQH.TRANSACTION_TYPE_ID = MPT.TRANSACTION_TYPE_ID "+
                        " AND NVL(PQH.TRIES_NUM,0) <= MPT.MAX_RETRIES_NUM " +
                        "ORDER BY TRANSACTION_ID");
                       *****/

                    // log_obj.FmtAndLogMsg("Query executed");
                    //
                    // Quickly read the record set into a vector or record objects
                    //
                    vec_rd.clear();

                    while (rs.next()) {
                       rd = new RecordData(rs);
                       rd.SetData(rs);
                       vec_rd.add(rd);
                    }
                    //
                    // we are finished with ResultSet and Statment... close it
                    //
                    rs.close();


                    //
                    // If there were no records in the last query then sleep
                    //
                    if (vec_rd.size()==0) {
                       Thread.sleep(lSleepSecs * 1000);
                       if (eojFile!=null && eojFile.exists()) {
                          log_obj.FmtAndLogMsg("Gracefull shutdown detected, shutting down...");
                          break;
                       }
                       continue;
                    }


                    if (processRecords(con,vec_rd)) break; // allThreads are disabled so break out of loop and exit

                    if (eojFile!=null && eojFile.exists()) {
                       log_obj.FmtAndLogMsg("Gracefull shutdown detected, shutting down...");
                       break;
                    }

                } // while true (check queue for next set of records to process)


            }
            catch (Exception e) {
                log_obj.FmtAndLogMsg("Severe Error: "+e.toString());
            }
            finally {
                try {rs.close();} catch (Exception e1) {e1.printStackTrace();}
                /* 141699 - perf, using ps instead
                try { stmt.close();} catch (Exception e1) {}
                */
				try {ps.close();} catch (Exception e1) {e1.printStackTrace();}

            }


            // tell all threads to terminate themselves gracefully

            for (Enumeration e = processThreads.elements(); e.hasMoreElements (); ) {
              ProcessThread processThread=(ProcessThread)e.nextElement ();
              processThread.endThread=true;
            }  // for

            // wait for threads to end gracefully
            int maxWait=0;
            log_obj.FmtAndLogMsg("Waiting on threads to end...");
            while(maxWait<30) { // give up in 30 seconds
               if (threadCount(false)<=0) break;
               try {Thread.sleep(1000);} catch (Exception e) {}
               maxWait++;
            }



            // Database error, need to reconnect


            if (eojFile!=null && eojFile.exists()) {
               //log_obj.FmtAndLogMsg("Gracefull shutdown detected, shutting down...");
               break;
            }
            else
            try {
                log_obj.FmtAndLogMsg("Sleeping for 5 seconds, before retrying db open",i_dbg_level,5);
                Thread.sleep(5000);
                log_obj.FmtAndLogMsg("Awake..",i_dbg_level,5);
            }
            catch (Exception e) {
                log_obj.FmtAndLogMsg("Warning: Sleep was forced awake");
            }

        } // while true

		
		try {rs.close();} catch (Exception e1) {e1.printStackTrace();}
		try {ps.close();} catch (Exception e1) {e1.printStackTrace();}
        try {con.close();} catch (Exception e1) {e1.printStackTrace();}


        if (eojFile!=null && eojFile.exists()) {
           eojFile.delete();
           log_obj.FmtAndLogMsg("Gracefull shutdown detected, exiting program now");
        }

    } // run()


    ///////////////////////////////////////////////////////////////////////////////////////

    private boolean processRecords(Connection con,Vector vec_rd) throws Exception {

        RecordData rd = null;
        long l_trans_id;
        //int num_retries,max_retries;
        String s_trans_type;
        boolean allThreadsBusy=true;
        boolean allThreadsDisabled=true;
				String sql = "";
				PreparedStatement ps = null;


        int ix;
        
        //
        // now process each row in the post queue vector
        //
        for (ix = 0; ix < vec_rd.size();ix++) { // for each job in post queue

            rd = (RecordData) vec_rd.elementAt(ix);
            l_trans_id = Long.valueOf(rd.sGetColumn("TRANSACTION_ID")).longValue();
            //num_retries = Integer.parseInt(rd.sGetColumn("TRIES_NUM"));
            //max_retries = Integer.parseInt(rd.sGetColumn("MAX_RETRIES_NUM"));
            s_trans_type = rd.sGetColumn("TRANSACTION_TYPE_ID");


            // find a free thread to process this job

            allThreadsBusy=true;
            allThreadsDisabled=true;
            ProcessThread processThread;

            while (allThreadsBusy) {

				// Encryption Dummy Block start
				// This block is redundant. But as we are getting NAE Session encryption error while performing from multi threaded environment.
				// It turned out, that before calling encryption operation from thread, if we call them outside, then it creates NAE session and after that it can be called without error from threads
				// so , we are just encryption dummy string to create NAE session.
				// After figured out NAE session error from multithreaded environment. This step actually not needed
				if(encryption_flg) {
					Crypto crypto =  CryptoFactory.getCrypto();
					String encryptionUser = "origenate_"+sUser;
					try {
						crypto.encryptString(encryptionUser.toLowerCase(),"clob","tempValue");
						log_obj.FmtAndLogMsg("Encryption Session Created",i_dbg_level,5);
					} catch(Exception e) { log_obj.FmtAndLogMsg("Error in Creating Encryption Session: "+e.toString(),i_dbg_level,5);}
				} // Encryption dummy block end
				
                for (Enumeration e = processThreads.elements(); e.hasMoreElements (); ) {

                    processThread=(ProcessThread)e.nextElement ();

                    if (processThread.busy) {
                        if (!processThread.errorOccurred)
                            allThreadsDisabled=false;
                    }
                    else {
                        // thread not busy so assign it this Job ID
                        jobCount++;
                        allThreadsBusy=false;
                        allThreadsDisabled=false;
                        processThread.busy=true;
                        processThread.jobID=l_trans_id;
                        processThread.s_trans_type=s_trans_type;

                        // update the queue so that this job doesn't get selected again
                        // 1/24/07 ChrisN CL140795 Replaced with SQL using bind variable for Triad performance enhancement
                        //SQLUpdate.RunUpdateStatement(con,"UPDATE POSTING_QUEUE_HEADER SET STATUS_ID = 3, TRIES_NUM = TRIES_NUM +1 WHERE TRANSACTION_ID = "+l_trans_id);
             		        try {
       					sql = "UPDATE POSTING_QUEUE_HEADER SET STATUS_ID = 3, TRIES_NUM = TRIES_NUM +1 WHERE TRANSACTION_ID = ?";
       					ps = con.prepareStatement(sql);
       					ps.setLong(1, l_trans_id);
       					ps.execute();
       					ps.close();
       				}
       				catch (Exception e1) {
       				}
       				finally {
       					try {ps.close(); } catch (Exception e2) {}
       				}


                        // setting workToDo will cause this thread to process this job
                        processThread.workToDo=true;
                        break;
                    }


                }  // for

                if (allThreadsDisabled) break; // all threads disabled

                if (allThreadsBusy)  {
                    // sleep for 1/5 sec before checking if any are free
                    try {Thread.sleep(200);} catch (Exception e) {}
                }


                if (eojFile!=null && eojFile.exists()) {     // 162583 - gracefull shutdown
                   break;
                }



            } // while allThreadsBusy

            if (allThreadsDisabled) {
                log_obj.FmtAndLogMsg("All threads are disabled, can't assign work, restarting",i_dbg_level,5);
                return allThreadsDisabled;
            }

            if (eojFile!=null && eojFile.exists()) {
               log_obj.FmtAndLogMsg("Gracefull shutdown detected, shutting down...");
               break;
            }

            
            // 162583:
            // the first 3 jobs, will wait 10 secs before assigning a new job so as not to overrun eValuate on startup
            if (jobCount<=3) {
               log_obj.FmtAndLogMsg("Sleeping 10 seconds before assigning next job...(only applies to first 3 jobs upon startup)");
               try {Thread.sleep(10000);} catch (Exception e) {}
               if (eojFile!=null && eojFile.exists()) {
                  log_obj.FmtAndLogMsg("Gracefull shutdown detected, shutting down...");
                  break;
               }
            }

        } // for each job in vector

        return false; // allThreads are not disabled

    }// processRecords()


    //////////////////////////////////////////////////////////////////////////////////////



    private void ShowUsage() {
        System.out.println("Usage:");
        System.out.println("PostQueueProcessor -n<numthreads> -u<url> -d<Database> -s<SleepSeconds> -L<source filter> -h<DBHost> -p<DBpasswd> -c<ConnectionTimeout> -r[eval_scoring routing state IDs] -U<DBUser> -TTranstype(s) [-D] [-x]");
        System.out.println("------------------");
        System.out.println("url - url to connect to passing a fuseaction of insert, and transaction id to");
        System.out.println("Database  - SID name of db to log on to");
        System.out.println("DBHost - name or ip of machine serving the database");
        System.out.println("DBUser - user for database");
        System.out.println("DBPasswd - passord for database");
        System.out.println("Source_txt filer - only process jobs with a source_txt value in this list, ex) -L'DDS' or -L'DDS','DEALERTRACK' ");
        System.out.println("TransType - Transaction type list (must include single quotes) to work on ie:(-T'R-ITDEC','R-XML')");
        System.out.println("SleepSeconds - Seconds to sleep before polling db");
        System.out.println("ConnectionTimeout - Seconds to wait for an unresponsive url connection before severing thread");
        System.out.println("Routing state IDs - Comma separated list of eval_scoring routing state IDs when submitting scoring requests to the ruting queue (LoanAppRq)");
        System.out.println("-x (optional) If specifed then xml clob will NOT be stored in the credit_request_xml table, if not specified then xml WILL be loaded in this table ");
        System.exit(1);
    }


    ////////////////////////////////////////////////////////////////////////////////




    private void GetArgs(String args[],LogMsg log_obj) {
        int ix;

        if (args.length > 0) {
            for (ix = 0; ix < args.length; ++ix) {
                if ((args[ix].charAt(0) != '-') && (args[ix].length() > 1)){
                    ShowUsage();
                }

                switch (args[ix].charAt(1)) {
                   case 'i':
                    sIniFile = args[ix].substring(2);
                    log_obj.FmtAndLogMsg("IniFile is '" + sIniFile + "'");
                    try {
                        //
                        // Read host, user, sid and password from ini file
                        //
                        ini.readINIFile(sIniFile);

                        sHost = ini.getINIVar("database.host");
                        log_obj.FmtAndLogMsg("Host is '" + sHost + "'");

                        sUser = ini.getINIVar("database.user");
                        log_obj.FmtAndLogMsg("Set User");

                        sPort = ini.getINIVar("database.port");
                        log_obj.FmtAndLogMsg("Port is '" + sPort + "'");

                        sPass = ini.getINIVar("database.password");
                        log_obj.FmtAndLogMsg("Set Password");
                        sPass = COLEncrypt.sDecrypt(sPass);

                        sSIDname = ini.getINIVar("database.sid");
                        log_obj.FmtAndLogMsg("Database (SID name) is '" + sSIDname + "'");
                        
                        sTNSEntry = ini.getINIVar("database.TNSEntry", "");
                        log_obj.FmtAndLogMsg("TNS Entry is '" + sTNSEntry + "'");
						
						if(Integer.parseInt(ini.getINIVar("encryption.encryption_flg","0")) == 1) {
							encryption_flg = true;
						}
						
                        xsltDir = ini.getINIVar("mpe.xslt_dir","");
                        if (xsltDir.length()>0) {
                          log_obj.FmtAndLogMsg("XSLT Dir: "+xsltDir);
                          xsltDir+=File.separator;
                        }

                    }
                    catch (Exception e) {
                        log_obj.FmtAndLogMsg("Caught exception reading ini file '" + sIniFile + "':"+e.toString());
                    }
                    break;


                    case 'u':
                    sURL = args[ix].substring(2);
                    log_obj.FmtAndLogMsg("URL is '" + sURL + "'");
                    break;

                    case 'z':
                    	
                    /** OWASP Top 10 2010 - A4 path manipluation
                      * Change to the below code to fix vulnerabilities
                      * TTP 324955
                      */	
                    //eojFile = new File(args[ix].substring(2));
                    //eojFile = new File(Encode.forJava(args[ix].substring(2)));
                    try
                    {
                    eojFile = new File(OWASPSecurity.validationCheck(args[ix].substring(2), OWASPSecurity.DIRANDFILE));
                    }
                    catch(Exception e)
                    {
                        e.printStackTrace();
                    }
                    log_obj.FmtAndLogMsg("End of job file is '" + args[ix].substring(2) + "'");
                    break;

                    case 's':
                    try {
                        lSleepSecs = Long.valueOf(args[ix].substring(2)).longValue();
                        log_obj.FmtAndLogMsg("Sleep seconds set at " + lSleepSecs);

                    }
                    catch (Exception e) {
                        log_obj.FmtAndLogMsg("Unable to convert parameter: " + args[ix]+":"+e.toString());
                    }
                    break;

					// CL157271 - Add Wait Time before retrying.
					case 'W':
						try {
							waitTime = Integer.parseInt(args[ix].substring(2));
							// Convert waitTime into Millisecs from Minute
							waitTime = waitTime*60000;
						}
						catch (Exception e) {
							waitTime=0;
						}
                    break;
					
					// CL157271 - Add number of retry.
					case 'R':
						try {
							numRetries = Integer.parseInt(args[ix].substring(2));
							maxRetries = numRetries;
						}
						catch (Exception e) {
							numRetries = 0;
							maxRetries = 0;
						}
						
                    break;
					
					
                   case 'r':
                   sRoutingStateIDs = args[ix].substring(2);
                   log_obj.FmtAndLogMsg("eval_scoring routing state IDs: " + sRoutingStateIDs);
                   break;

                    case 'n':
                    try {
                        maxThreads = Integer.parseInt(args[ix].substring(2));
                    }
                    catch (Exception e) {
                        maxThreads=1;
                    }
                    log_obj.FmtAndLogMsg("Num threads = " + maxThreads);
                    break;

                    case 'D':
                    log_obj.FmtAndLogMsg("Running with debugs on");
                    //bDebug = true;
                    i_dbg_level=5;
                    break;



                    // 159112 gl 6/18/12
                    case 'L':  // capital L means only process jobs that are in this source list
                    String tmpSourceList = args[ix].substring(2);
                    tmpSourceList=tmpSourceList.replace('.',' ');  // converrt periods to spaces since the comand line can not have spaces in the 'in' list
                    log_obj.FmtAndLogMsg("Only processing jobs with source_txt values of: " + tmpSourceList);
					if(!tmpSourceList.equals("")) {
						sourceList = tmpSourceList.split(",");
						for(int i = 0; i < sourceList.length; i++) {
							sourceList[i] = sourceList[i].replace("'","");
						}
					}
                    //sourceList=" and pqh.source_txt in ("+sourceList+") ";
					includeSourceList = true;
                    break;

                    case 'l':  // lowercase L means process any job that does not match this source_txt
                    String tmpSourceList2 = args[ix].substring(2);
                    tmpSourceList2=tmpSourceList2.replace('.',' ');  // converrt periods to spaces since the comand line can not have spaces in the 'in' list
                    log_obj.FmtAndLogMsg("Processing all jobs that DO NOT  contain a source_txt values of: " + tmpSourceList2);
					if(!tmpSourceList2.equals("")) {
						sourceList = tmpSourceList2.split(",");
						for(int i = 0; i < sourceList.length; i++) {
							sourceList[i] = sourceList[i].replace("'","");
						}
					}
                    //sourceList=" and pqh.source_txt not in ("+sourceList+") ";
					includeSourceList = false;
                    break;

                    case 'd':
                    log_obj.FmtAndLogMsg("Running with debugs on");
                    //bDebug = true;
                    i_dbg_level=5;
                    break;
                    // end 159112 gl 6/18/12

                    case 'x':
                    log_obj.FmtAndLogMsg("CREDIT_REQUEST_XML storage is turned off");
                    storeXML=false;
                    break;

                    case 'T':
                    sRunningOnTransType = args[ix].substring(2);
                    log_obj.FmtAndLogMsg("Running with trans type:"+sRunningOnTransType);
                    break;


		    case 'c':
                    try {
		        conn_to_secs = Integer.parseInt(args[ix].substring(2));
                        log_obj.FmtAndLogMsg("Connection time out seconds set at " + conn_to_secs);
                    }
                    catch (Exception e) {
                        log_obj.FmtAndLogMsg("Unable to convert parameter: " + args[ix] + ":" + e.toString());
                    }
                    break;

                    default:
                    log_obj.FmtAndLogMsg("Unknown parameter: " + args[ix]);
                    ShowUsage();
                    break;
                }
            }
			
			log_obj.FmtAndLogMsg("Wait Time is: " + waitTime);
			log_obj.FmtAndLogMsg("Number of Retries is: " + numRetries);
			
            if ((sHost.length()==0) || (sPort.length()==0)  || (sUser.length()==0) || (sSIDname.length()==0) || (sRunningOnTransType.length()==0) || (sURL.length()==0) || (lSleepSecs == 0)) {
                log_obj.FmtAndLogMsg("Parameter host:"+sHost);
                log_obj.FmtAndLogMsg("Parameter port:"+sPort);
                log_obj.FmtAndLogMsg("Parameter user:"+sUser);
                log_obj.FmtAndLogMsg("Parameter sid:"+sSIDname);
                log_obj.FmtAndLogMsg("Parameter URL:"+sURL);
                log_obj.FmtAndLogMsg("Parameter sleep seconds:"+lSleepSecs);
                log_obj.FmtAndLogMsg("Parameter Trans Type:"+sRunningOnTransType);
                log_obj.FmtAndLogMsg("Error: Valid parameters were not supplied on the commandline or in ini file");
                ShowUsage();
            }
        }
        else {
            ShowUsage();
        }


    }

    /////////////////////////////////////////////////////////////////

    public synchronized int threadCount(boolean decreaseCount) {
        if (decreaseCount)
            runningThreads--;
        return(runningThreads);
    }

    public synchronized String  getNextRoutingStateID() {
       if (routingStateIDs.size()==1) return((String)routingStateIDs.get(0)); // only one (13) so return it
       lastRoutingIdx++;
       if (lastRoutingIdx > routingStateIDs.size()) lastRoutingIdx=1;
       return((String)routingStateIDs.get(lastRoutingIdx-1)); // Vector is zero based but idx is one based
    }



} // PostQueueProcessor