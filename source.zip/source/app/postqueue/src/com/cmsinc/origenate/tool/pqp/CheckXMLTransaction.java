/*
 * InsertXML.java
 *
 * Created on November 14, 2002, 2:45 PM
 */

package com.cmsinc.origenate.tool.pqp;

import java.sql.*;
//import org.apache.xerces.parsers.DOMParser;
import org.w3c.dom.*;
//import org.xml.sax.InputSource;
//import org.apache.xalan.xslt.XSLTInputSource;
//import org.apache.xalan.xslt.XSLTResultTarget;
//import org.apache.xalan.xslt.XSLTProcessor;
//import org.apache.xalan.xslt.XSLTResultTarget;
//import org.apache.xalan.xslt.StylesheetSpec;
//import org.apache.xerces.dom.DocumentImpl;
//import com.cmsinc.origenate.util.LogMsg;
import com.cmsinc.origenate.util.XPathAPI;

/**
 *
 * @author  marca
 * @version
 */
public class CheckXMLTransaction extends Object {
    final static String erqXPath="/IFX/*/*/Routing/To/IDs/ID[@Type='EvaluateRequestQueueID']/text()";

    public static boolean CheckXMLTransaction(Connection con,Node nod_root) {
        Node nd = null;
        boolean b_insert_the_xml = true;

        //
        // allow insertion of the xml if there was no EvaluateRequestQueueID 
        // in the transaction or if it is still Pending
        // /IFX/*/*/Routing/To/IDs/ID[@Type='EvaluateRequestQueueID']/text()
        //
        try { nd = XPathAPI.selectSingleNode(nod_root,erqXPath); }
        catch (Exception e) {}

        if (nd != null && nd.getNodeValue()!=null) {
		    PreparedStatement ps = null;
			ResultSet rs_erq = null;
            try {
                String s_sql = "SELECT status_id FROM evaluate_transactions " +
                                "WHERE evaluate_request_queue_id = ? ";
                
				ps = con.prepareStatement(s_sql);
				
				ps.setInt(1, Integer.valueOf(nd.getNodeValue()).intValue());
				ps.execute();
				
				rs_erq = ps.getResultSet();
                
                if (rs_erq.next()) {
                    if (rs_erq.getLong("status_id") != 1) {
                        b_insert_the_xml = false;
                    }
                }
                else {
                    b_insert_the_xml = false;
                }
                rs_erq.close();
                ps.close();
            }
            catch (Exception e) {
            }
			finally {// release resources
			   try{ if(rs_erq != null) rs_erq.close(); }catch(Exception e1){e1.printStackTrace();}
			   try{ if(ps != null) ps.close(); }catch(Exception e1){e1.printStackTrace();}
		    }
        }
        return b_insert_the_xml;
    }


}