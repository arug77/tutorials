package com.cmsinc.origenate.tool.pqp;


import org.w3c.dom.Node;

import com.cmsinc.origenate.event.CommentEvents;
import com.cmsinc.origenate.event.JournalEvents;
import com.cmsinc.origenate.util.Query;
import com.cmsinc.origenate.util.SQLUpdate;
import com.cmsinc.origenate.util.XPathAPI;



/**
 * <pre>
 *
 * This class is loaded by ProcessThread.java to process an incoming XML transaction
 * when no other Controller class for the transaction type is found.
 *
 *
 * If you are implementing a Controller for a particular trans type ( LoanAppRq )
 * then make a copy of this .java file and rename it to LoanAppRq.java. Then change
 * the class name and constructor and add any business logic in runController
 * as required.
 *
 * </pre>
 *
 */
public class EsignResponseRs extends com.cmsinc.origenate.webservices.utils.BaseController {


    public void EsignResponseRs() {};


    /////////////////////////////////////////////////////////////////////////////////////////



    public void runController() throws Exception {



        /*
        This class handles responses from DocuSign that updates the status of an outstanding siging request. 
        The only information that they provide is the envelope ID (GUID) which is in the routing section. When we
        have that we can do a scan of the credit_req_doc_history on this GUID to findout info about the document 
        to be updated. The crdh guid has an index on it so it should be quick.

        */



        Query query = new Query(con);
        boolean continueProcessing=true;
        CommentEvents ce = new CommentEvents(con, log_obj);
        JournalEvents journalEvents= new JournalEvents(con,null);

        try {


           getRoutingInfo();  // sets BaseController instance variables if they exist in the xml
                              // transID (ie. LoanAppRq), network (ie. COL),
                              // remoteRefNum, evaluator_id, etc
                              // see method in base class for a complete list


            //  No need to load XML, just check for a return error or success



               String envelopeID="";
               String status="";

               Node nd = XPathAPI.selectSingleNode(nod_root,"/IFX/CreditSvcRs/LoanAppSvcRs/Routing/From/IDs/ID[@Type='EnvelopeID']/text()");

               if (nd != null && nd.getNodeValue()!=null) 
                  envelopeID = nd.getNodeValue();
               else
                  throw new Exception("ERROR: Received a EsignResponseRs from the Gateway that did not contain a /IFX/CreditSvcRs/LoanAppSvcRs/Routing/From/IDs/ID[@Type=EnvelopeID]/text(), can not process request ");

                nd = XPathAPI.selectSingleNode(nod_root,"/IFX/CreditSvcRs/LoanAppSvcRs/Routing/From/IDs/ID[@Type='EnvelopeStatus']/text()");
                if (nd != null && nd.getNodeValue()!=null) 
                   status = nd.getNodeValue();
                else
                   throw new Exception("ERROR: Received a EsignResponseRs from the Gateway that did not contain a /IFX/CreditSvcRs/LoanAppSvcRs/Routing/From/IDs/ID[@Type=EnvelopeStatus]/text(), can not process request ");

                // find the credit_req_doc_hist row that this response belongs to so we can get the request id etc.

                query.prepareStatement("select crdh.seq_id,crdh.document_id, crdh.request_id,crdh.evaluator_id,cd.description_txt from credit_req_doc_history crdh,config_documents cd where docusign_envelope_guid_txt = ? and crdh.evaluator_id = cd.evaluator_id and crdh.document_id = cd.document_id");
                query.setString(1,envelopeID);
                query.executePreparedQuery();
                if (!query.next()) 
                   throw new Exception("ERROR: Received a EsignResponseRs from the Gateway that did not match a doc history record, can not process request, Envelope GUID: "+envelopeID);
                requestID=query.getColValue("request_id");
                evaluator_id=query.getColValue("evaluator_id");
                String seqID="";
                String docDesc="";
                seqID=query.getColValue("seq_id");
                docDesc=query.getColValue("description_txt","Unknown");

                // Now that we have the hist row that it belongs to we can update the status and write a comment

                String origStatus="N/A";
                if (status.equals("Completed")) origStatus="COMPLETED";
                if (status.equals("Declined")) origStatus="DECLINED";
                if (status.equals("Delivered")) origStatus="DELIVERED";
                if (status.equals("Sent")) origStatus="SENT";
                if (status.equals("Signed")) origStatus="SIGNED";
                if (status.equals("Voided")) origStatus="VOIDED";

                SQLUpdate.RunUpdateStatement(con,
                               "update credit_req_doc_history set status_id = '"+origStatus+"', print_date = sysdate, error_txt = null where seq_id = "+seqID);

                String msg="DocuSign Status received for document: "+docDesc+", status = "+origStatus;

                //add a comment so we will know that a comment was trying to be sent when it shouldn't
                ce.addComment(
                                Integer.parseInt(requestID.trim()), //request id as an int 
                                85, // esign event
                                "DocuSign Response", //subject
                                msg,
                                "SYSTEM", //SYSTEM USER
                                "", //no assigned user
                                "" //no due date
                );


                journalEvents.addJournal(Integer.parseInt(requestID),105,msg,"SYSTEM");


                // Update the comments_received_flg in the credit request table
                // so the queue will show a flashing icon that a comment was received

                SQLUpdate.RunUpdateStatement(con,"UPDATE CREDIT_REQ_LATEST_COMMENT SET COMMENTS_RECEIVED_FLG = 1 WHERE "+
                    "REQUEST_ID = "+requestID);


        }
        catch (Exception e) {


            // can't send a NOLOAD back because the DocuSign doesn't know how to handle a noload


            log_obj.FmtAndLogMsg("EsignResponseRs ERROR: "+e.toString());

            throw (e);   // throw it back to the caller so they can set the status of
                         // the job to error

        } // exception


             // can't send a LOAD back because the Gateway doesn't know how to handle a load notification


        // if haven't thrown an error by now then the calling PQP will delete the
        // job row from the PQP queue



    }  // runController()

} // EsignResponseRs


