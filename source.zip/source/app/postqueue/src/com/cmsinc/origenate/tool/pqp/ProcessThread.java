package com.cmsinc.origenate.tool.pqp;

import java.io.BufferedReader;
import java.io.StringReader;
import java.math.BigDecimal;
import java.sql.Clob;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;


import org.apache.xerces.parsers.DOMParser;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.xml.sax.InputSource;

import com.cmsinc.origenate.crypto.Crypto;
import com.cmsinc.origenate.crypto.CryptoFactory;
import com.cmsinc.origenate.util.LogMsg;
import com.cmsinc.origenate.util.Query;
import com.cmsinc.origenate.util.XPathAPI;
import com.cmsinc.origenate.webservices.utils.*;
//import com.cmsinc.origenate.util.SQLUpdate;
//import org.apache.xalan.xslt.XSLTInputSource;
//import org.apache.xalan.xslt.XSLTResultTarget;
//import org.apache.xalan.xslt.XSLTProcessor;
//import org.apache.xalan.xslt.XSLTResultTarget;
//import org.apache.xalan.xslt.StylesheetSpec;
//import java.io.*;
//import com.cmsinc.origenate.util.SQLUpdate;





/**
 *
 *
 */
public class ProcessThread extends Thread  {


    // INSTANCE VARIABLES

    int threadID=0;
    PostQueueProcessor main;
    boolean busy=false;
    boolean workToDo=false;
    Connection con=null;
    boolean endThread=false;
    long jobID=0;
	int numRetries=0;
    int i_dbg_level=0;
    String s_trans_type="";
    LogMsg log_obj = null;
	boolean encryption_flg = false;
	String encryption_user_name="";
    boolean errorOccurred=false; // set to true if this thread is disabled because
                                 // of an unrecoverable error. Can't just let thread
                                 // end because main will reference a thread that
                                 // doesn't exist
    String errorMessage="";
    String sConStr,sUser,sPass;

    // CONSTRUCTOR

    public ProcessThread(PostQueueProcessor main,String sConStr,String sUser,String sPass, int ID,int i_dbg_level) throws Exception {
       threadID=ID;

       this.main=main;
       this.sConStr=sConStr;
       this.sUser=sUser;
       this.sPass=sPass;
       this.i_dbg_level=i_dbg_level;
	   this.numRetries=main.maxRetries;
	   
	   // E N C R Y P T I O N      N O T E 
	   
	   // Stores Username as origneate_dbusername (e.g. origenate_origdv85) 
	   // Username will be used as UserKey in encryption operation (e.g. decryptString("origenate_origdv85","ssn","123456789"))
	   this.encryption_user_name = "origenate_"+main.sUser;
	   // Sets Encryption Flag (defined in origenate.ini)
	   // encryption_flg is used to identify if Encryption is on for lender or not?
	   // If Encryption is on; i.e. Value_Txt (XML) in Posting_Queue table is stored in encrypted form
	   // Thus, Its necessary to decrypt XML field before its parsing
	   this.encryption_flg = main.encryption_flg;

       log_obj = new LogMsg();
       log_obj.setLogID("THREAD "+threadID+": ");

       // Connect to the Oracle database
       con = DriverManager.getConnection (sConStr,sUser,sPass);
    } // end constructor


/////////////////////////////////////////////////////////////////////////////

    // RUN METHOD - execution continues in its own thread

    public void run() {

        errorOccurred=false;
        errorMessage="";
		
        log_obj.FmtAndLogMsg(" running...");
		
        while (!endThread) {

          if (!workToDo) {
              // sleep for 1/5 sec before checking if any are free
              try {Thread.sleep(200);} catch (Exception e) {}
              continue;
          }

          // wake up to process a job

          busy=true;
          workToDo=false;

		  this.numRetries=main.maxRetries;
          int tryCount=0;
          boolean tryAgain=true;

          // jobID and s_trans_type set by main before setting workToDo to true

          while(tryAgain) {

             tryAgain=false;

             // try twice if a broken pipe occurred

             try {

                errorOccurred=false;

                long l_start_time = System.currentTimeMillis();
                log_obj.FmtAndLogMsg("JOB: "+jobID+" STARTED, with Retries: "+this.numRetries,i_dbg_level,5);


                insertXML(jobID);  // this is where all the work is done


                log_obj.FmtAndLogMsg("JOB: "+jobID+" ENDED, PROC TIME:"+(System.currentTimeMillis()-l_start_time)+" ms",i_dbg_level,5);


                // reset error flag so this thread is free to process another job

                errorOccurred=false;

             }
             catch (Exception e) {

                 // serious error, disable thread if max retries reached
                 String tmp=e.toString();

                 // retry 5 times and then give up

                 if (tryCount < 5 && (tmp.indexOf("Broken pipe")>=0 ||
                                      tmp.indexOf("deadlock")>=0 ||
                                      tmp.indexOf("Connection timed out")>=0 ||
                                      tmp.indexOf("Closed Connection")>=0
                                      )) {

                     // re-establish the connection and try one more time
                     try {con.close();} catch (Exception e9) {}
                     log_obj.FmtAndLogMsg("Lost connection, re-establishing connection and retrying job");
                     try {Thread.sleep(1000);} catch (Exception et) {} // sleep a second to let condition clear
                     try {con = DriverManager.getConnection (sConStr,sUser,sPass);
                     }
                     catch (Exception e1) {con=null; }
                     if (con!=null) {
                       tryAgain=true;
                       tryCount++;
                     }
                     else {
                         errorOccurred=true;
                         errorMessage="DISABLED, unrecoverable error: "+tmp;
                         log_obj.FmtAndLogMsg(errorMessage);
                     }
                 }
				 // CL157271 - If Number of Retries is not 0, then retry posting XML after waiting waittime
                 // gl. We do not want to hold up this thread so put it back in the queue to be processed again after the wait time
                  else 
                           if((tmp.indexOf("PreLoadError") >=0 || tmp.indexOf("Unable to decrypt") >= 0) && this.numRetries!=0) { // retries is on and a preload error occurred
                                try {
                                         Query query = new Query(con);

                                         PreparedStatement ps2 = null;

                                         query.prepareStatement("select nvl(wait_tries_num,0) wait_tries_num from posting_queue_header where transaction_id = ?");                      
                                         query.setLong(1, jobID);
                                         query.executePreparedQuery();	  
                                         query.next();
                                         int waitTries = Integer.parseInt(query.getColValue("wait_tries_num"));
                                         waitTries++;
                                         int waitMins = 1;    // default to wait for one min in case wait time not supplied on start up script
                                         if (main.waitTime>0) waitMins=main.waitTime/60000;  // waitTime is optional in main (will be 0), convert back to mins
                                         // Oracle date math, 10 mins from now is:  sysdate + 10/1440

                                         if (waitTries <= main.maxRetries) {
                                             String errMsg="Will RETRY "+waitTries+" of "+main.maxRetries+" after getting error: "+e.toString();
                                             errMsg=errMsg.replace("'"," "); // remove single quotes

                                             String sql = "UPDATE POSTING_QUEUE_HEADER SET tries_num = -1, wait_tries_num = ?, status_id = 0, transaction_dt = sysdate + ?/1440 , error_txt = ?  WHERE TRANSACTION_ID = ?";

                                             log_obj.FmtAndLogMsg("JOB: "+jobID+" Putting job back on post queue to be processed in "+waitMins+" mins, next try "+waitTries+" of "+main.maxRetries+" because: msg= "+errMsg);

                                             /**
                                              * TTP 324955 Security Remediation Fortify Scan
                                              */
                                             ps2 = con.prepareStatement(sql);
                                             
                                             ps2.setInt(1, waitTries);
                                             ps2.setInt(2, waitMins );//ps2.setBigDecimal(2, BigDecimal.valueOf((double) waitMins / 1440.0));
                                             ps2.setString(3, errMsg);
                                             ps2.setLong(4, jobID);
                                             ps2.execute();
                                             ps2.close();
                                         }
                                         else {
                                             log_obj.FmtAndLogMsg("JOB: "+jobID+" NOT being put back on post queue. It has been attempted "+main.maxRetries+" time(s). msg= "+e.toString());

                                         }
                                }
                                catch (Exception eg) {
                                   log_obj.FmtAndLogMsg("JOB: "+jobID+" Error trying to reset job for retry, err="+eg.toString());
                                }
        		 }


                 else {
                    // Disable this thread, can't continue
                    errorOccurred=true;
                    errorMessage="DISABLED, unrecoverable error: "+tmp;
                    log_obj.FmtAndLogMsg(errorMessage);
                 }


             } // catch


          } // while tryagain


          try {incrementTries(jobID);} catch (Exception e) {} // in case it failed

          // finished with this job so reset flags and wait for more work to do

          // once the errorOccurred flag is set then this thread will not be given
          // any new work until the error has been examined by the caller. The caller
          // will then reset the busy flag after processing the error message.

          if (!errorOccurred) busy=false;


        } // while not end thread




        try {con.close();} catch (Exception e1) {}

        log_obj.FmtAndLogMsg(" ended gracefully");

        main.threadCount(true); // decrease thread count

      // fall thru to end thread

    } // end run()




    ///////////////////////////////////////////////////////////////////////////////////////


    /**
     * Inserts an XML document into the system
     */
    private void insertXML(long jobID) throws Exception {
    	Clob clob_value;
    	String sql = "";
		PreparedStatement ps = null;
		PreparedStatement ps2 = null;
    	ResultSet rs = null;
        String decXML="";
        try {
        	DOMParser parser = new DOMParser();
        	Document doc;
        	Node nod_root,nd;


            //  G E T    T H E    X M L    F R O M    T H E   P O S T I N G    Q U E U E

            /*  141699 - Perf, use prepared stmt instead
            stmt = con.createStatement();
            rs = stmt.executeQuery("SELECT VALUE_TXT FROM POSTING_QUEUE WHERE TRANSACTION_ID = " + jobID + " AND  POSTED_FIELD_NAME_TXT = 'XML' ");
            ********/

        	sql = "SELECT VALUE_TXT FROM POSTING_QUEUE WHERE TRANSACTION_ID = ? AND POSTED_FIELD_NAME_TXT = 'XML'";
            ps = con.prepareStatement(sql);
            ps.setLong(1, jobID);
            rs = ps.executeQuery();

            //
            // go to first record, SHOULD ONLY BE ONE
            //
            if (rs.next()) {
                
                //  G E T   T H E   C L O B   T H A T   H O L D S    T H E     X M L

                //
                // get the value_txt clob, this will hold the XML
                //
                clob_value = (java.sql.Clob) rs.getObject("VALUE_TXT");
                
                // done with rs and ps, close them
                rs.close();
                ps.close();

				//   E N C R Y P T I O N    N O T E 
				// Checks encryption_flg (Fetched from postQueueProcessor.java)
				// If Encryption is on and clob value is not null; Convert Clob into String and then decrypt String 
				
				// NOTE:
					// decryptString (User_Name, KeyName, Value)
					// USER NAME = encryption_user_name (e.g. origenate_origdv85 (if dbuser is origdv85))
					// Key Name = clob
					// Encrypted String = clobString(casted String from clob)
										
				// Encryption Starts
				if(encryption_flg && clob_value != null)
				{
					// Converts clob into String
					BufferedReader bufferReader = null;
					String clobString = "";
					try {
						bufferReader = new BufferedReader(clob_value.getCharacterStream());
						clobString = bufferReader.readLine();
					} catch (Exception ex) {
						log_obj.FmtAndLogMsg("Exception reading clob from buffer: " + ex.getMessage());
					} finally {
					    try{ if(bufferReader != null) bufferReader.close(); }catch(Exception ex){ex.printStackTrace();}
					}
					//Initializes Crypto Object
					Crypto crypto =  CryptoFactory.getCrypto();
					// Decrypts XML
                    
					try {
                        decXML = crypto.decryptString(encryption_user_name.toLowerCase(),"clob",clobString);
                    } catch (Exception ex) {
                        throw new Exception("Unable to decrypt VALUE_TXT from POST_QUEUE. Will retry job in PostQueue Process Thread: " + ex.getMessage());
					}
                    
					
					
				} //Encryption Ends
				
                /*	calling the old xalan processor in this way causes the following error under newer versions of JDK 1.4._03 and higher because
					of new versions of xerces/xalan embedded in Java 1.4.
					
					java.lang.VerifyError: (class: org/apache/xalan/xpath/xdom/XercesLiaison, method: parse signature: (Lorg/xml/sax/InputSource;)V) Incompatible object argument for method call 
						at java.lang.Class.forName1(Native Method) 
						at java.lang.Class.forName(Class.java:180) 
						at org.apache.xalan.xslt.XSLTEngineImpl.<init>(XSLTEngineImpl.java:360) 
						at org.apache.xalan.xslt.XSLTProcessorFactory.getProcessor(XSLTProcessorFactory.java:79) 
						at com.cmsinc.origenate.tool.pqp.ProcessThread.insertXML(Unknown Source) 
						at com.cmsinc.origenate.tool.pqp.ProcessThread.run(Unknown Source) 

					The feature of applying a styleheet based on commands in the incoming xml has never been used so I am backing out this feature
					
					XSLTProcessor xslprocessor = org.apache.xalan.xslt.XSLTProcessorFactory.getProcessor();
                */

                //   L O A D   T H E   X M L   I N   M E M O R Y

                //
                // parse the file using xerces
                //
                InputSource input_source;
				// If Encryption is on
				// Convert Decrypted String(Original XML) to StringRedaer and pass it to the InputSource
				// InputSource will parse the XML
				if(encryption_flg)
				{
					StringReader br = new StringReader(decXML);
					input_source = new InputSource(br);
				}
				// If Encryption is off
				// Pass the clob which contains original XML
				else
					input_source = new InputSource(clob_value.getCharacterStream());

                // see above comment
                // XSLTInputSource xml_source = new XSLTInputSource(input_source);
                // Vector vec_stylesheets = xslprocessor.getAssociatedStylesheets(xml_source,(String)null,(String)null);

                //
                // Make input_source point to the original xml
                // I am not sure why but I had to reinitialize xml_source and
                // input_source
                //

                //  O P T I O N A L L Y     A P P L Y    S T Y L E S H E E T

                /* see notes above
                input_source = null;
                input_source = new InputSource(clob_value.getCharacterStream());

                if ((vec_stylesheets != null)&&(vec_stylesheets.size() > 0 )) {
                    input_source = applyAssociatedXSL(input_source,vec_stylesheets,xslprocessor,i_dbg_level);
                }
                ******/

                parser.parse(input_source);
                doc = parser.getDocument();
                //
                // first get the root element
                //
                nod_root = doc.getDocumentElement();


                // SPECIAL CONDITION FOR EVALUATE RESPONSES
                //
                // allow insertion of the xml only if there was no EvaluateRequestQueueID
                // in the transaction or if it is still Pending
                // /IFX/*/*/Routing/To/IDs/ID[@Type='EvaluateRequestQueueID']/text()
                //
                if (CheckXMLTransaction.CheckXMLTransaction(con,nod_root)==false) {
                    log_obj.FmtAndLogMsg("EvaluateRequestQueueID is not in a pending state, ignoring this transaction");
                } else {
	                //   D E T E R M I N E    W H I C H   C O N T R O L L E R   T O   U S E

	                /* Every XML MUST have a transaction ID, ex. LoanAppRq. Pull it out
	                   and invoke a Controller class of the same name to process it.
	                   If the class is not found then use the Default Controller class, which
	                   will simply load the XML like it was done in the past.
	                */

                    String transXPath="/IFX/*/*/Routing/attribute::Transaction";
                    String transactionType="";
                    nd = XPathAPI.selectSingleNode(nod_root,transXPath);
                    if (nd != null && nd.getNodeValue()!=null) transactionType = nd.getNodeValue();

					/* if there is no transaction, it's an error; if there is a list of transactions, use the controller class of the first one */
                    if (transactionType.length()==0) {
                        throw new Exception("Incoming XML must contain a trans type in: /IFX/*/*/Routing/attribute::Transaction");
					}	
					else if (transactionType.indexOf(",") > 0) {
						transactionType = transactionType.substring(0,transactionType.indexOf(","));
                    }


                    /* glennl. CT159572, Guarantee that jobs (for the same App ID) are processed in FIFO order.
                          If other jobs are in the queue for this same app_id that came in before this one and are not yet finished
                       then put this job back on the queue to be processed a min from now (or configured delay time)
                    */

                    if (!otherJobsExistForThisAppID(jobID,nod_root)) {



                           String className=transactionType;

                           String package_name="";


                           /* 159988 - LoanAppRq,LoanAppRs controller class is now in common.jar under webservices/util
                           */
                            if (className.equals("LoanAppRq") || className.equals("LoanAppRs") || 
								className.equals("AppCommentsRq") || className.equals("ContractRq")) {   // LOAD CONTROLLER FROM COMMON.JAR


                              package_name="com.cmsinc.origenate.webservices.utils.";

                              com.cmsinc.origenate.webservices.utils.BaseController controller = null;

                              controller = (com.cmsinc.origenate.webservices.utils.BaseController)Class.forName(package_name+className).newInstance();

                              if (controller==null) throw new Exception("Could not load controller: "+package_name+className+".class");

                              log_obj.FmtAndLogMsg("Controller class: "+package_name+className+".class loaded",i_dbg_level,5);

                             //  I N I T I A L I Z E      C O N T R O L L E R

                          /* We are now not passing any main dependent vars to the controller, pass them individually 
                             controller.initialize(con,nod_root,clob_value,
                                                   log_obj,i_dbg_level,jobID,numRetries,main);
                                                   */

                             controller.initialize(con,nod_root,clob_value,
                                                   log_obj,i_dbg_level,jobID,numRetries,
                                                   main.ini,
                                                   Integer.parseInt(main.ini.getINIVar("encryption.encryption_flg","0"))>0
                                                   ,main.storeXML,sUser,main.ini.getINIVar("mpe.xslt_dir",""),main.routingStateIDs);

                             //   P R O C E S S    X M L
                             controller.runController();

                             

                             //  S U C C E S S F U L     L O A D

                             // Perform cleanup, if needed

                             controller.cleanup();

                             // Delete the row from the posting_queue

                             // jobID is the key to the posting_queue row

                             deletePostingQueueJob(jobID);



                           }   // END COMMON.JAR CONTROLLER

                           else  {     // LOAD LOCAL CONTROLLER


                              package_name="com.cmsinc.origenate.tool.pqp.";

                              //BaseController controller=null;
                              com.cmsinc.origenate.webservices.utils.BaseController controller = null;

                               try {
                                  controller = (com.cmsinc.origenate.webservices.utils.BaseController)Class.forName(package_name+className).newInstance();
                                  //controller = (BaseController)Class.forName(package_name+className).newInstance();
                               }
                               catch (Exception e) { controller=null; } // Controller Class not found

                               if (controller==null) {

                                   controller = new com.cmsinc.origenate.webservices.utils.DefaultController();
                                   className="DefaultController";

                               }

                               log_obj.FmtAndLogMsg("Controller class: "+package_name+className+".class loaded",i_dbg_level,5);

                              //  I N I T I A L I Z E      C O N T R O L L E R

                           /* We are now not passing any main dependent vars to the controller, pass them individually 
                              controller.initialize(con,nod_root,clob_value,
                                                    log_obj,i_dbg_level,jobID,numRetries,main);
                                                    */
                                                        
                             controller.initialize(con,nod_root,clob_value,
                                                   log_obj,i_dbg_level,jobID,numRetries,
                                                   main.ini,
                                                   Integer.parseInt(main.ini.getINIVar("encryption.encryption_flg","0"))>0
                                                   ,main.storeXML,sUser,main.ini.getINIVar("mpe.xslt_dir",""),main.routingStateIDs);

                              //   P R O C E S S    X M L

                                controller.runController();


                              //  S U C C E S S F U L     L O A D

                              // Perform cleanup, if needed

                              controller.cleanup();

                              // Delete the row from the posting_queue

                              // jobID is the key to the posting_queue row

                              deletePostingQueueJob(jobID);



                           }  // END LOCAL CONTROLLER



                    } // OtherJobsExist check




                } // process the XML

            } // there was a clob to process

        }
        catch (Exception e) {
            String tmp=e.toString();
            log_obj.FmtAndLogMsg("Job "+jobID+": "+tmp);
            String errorTxt=tmp.replace('\'',' ');
            if (errorTxt.length()>1000) errorTxt=errorTxt.substring(0,1000);
			
            
			// CL157271 - If its a PreLoad Exception, and number of Retries is not 0, then throw Exception to Main and rerun.
			if ((errorTxt.contains("PreLoadError") || errorTxt.indexOf("Unable to decrypt") > 0) && this.numRetries != 0) {
				log_obj.FmtAndLogMsg("App Rejected: , Time for Retry...");
				throw(e);
			}
            // custom logic to support retries for taf.  it is a hack to use exception handling as retry mechanism
            // but until we have time to implement a true automatic retry design, this will suffice
            else if (errorTxt.indexOf("TAFRs is pausing this job") > 0) {
                
            	int delaySecs = 30;
                if (errorTxt.indexOf("TAFRs is pausing this job") > 0) {
                    log_obj.FmtAndLogMsg("TAFRs transaction is pausing because sequence config did not find correct prerequisites.");
                    try {	
                        delaySecs = Integer.parseInt(errorTxt.substring(errorTxt.indexOf("TAFRs is pausing this job")+26,errorTxt.indexOf("TAFRs is pausing this job")+28));
                    }	
                    catch (Exception e2) {
                        log_obj.FmtAndLogMsg("Job "+jobID+": TAFRs error did not provide number of seconds to delay, defaulting to 30");
                        delaySecs = 30;
                    }
                }
                else {
                    log_obj.FmtAndLogMsg("Job "+jobID+": Decryption error found. Will retry in 30 seconds");
                }

            	
            	log_obj.FmtAndLogMsg("Job "+jobID+": update posting_queue_header with new start date");
            	// setting tries to -1 because increment tries will run after this and set it to 0 so it can be worked on again
            	sql = "UPDATE posting_queue_header SET tries_num = -1, status_id = 0, transaction_dt = sysdate + ?, error_txt = ? WHERE transaction_id = ?";
				ps2 = con.prepareStatement(sql);
				// .000011574 is a second (need to convert from days to sec via 1/24/60/60)
				ps2.setDouble(1,delaySecs*.000011574);
				ps2.setString(2, errorTxt);
				ps2.setLong(3, jobID);
				ps2.execute();
				ps2.close();
            }
            else {
            	//log_obj.FmtAndLogMsg("NO");
            // 1/24/07 ChrisN CL140795 Replaced with SQL using bind variable for Triad performance enhancement
			    log_obj.FmtAndLogMsg("LoanAppRq: , Caught Exception ..." + e.toString());

				sql = "UPDATE POSTING_QUEUE_HEADER SET ERROR_TXT = ? WHERE TRANSACTION_ID = ?";
				ps2 = con.prepareStatement(sql);
				ps2.setString(1, errorTxt);
				ps2.setLong(2, jobID);
				ps2.execute();
				ps2.close();
            }

            // need to reconnect to the database
            if (tmp.indexOf("Broken pipe")>=0 || tmp.indexOf("deadlock")>=0)
               throw (e);
            // otherwise fall thru to process another job because error was already logged
        }
        finally {
		  try{ if(rs != null) rs.close(); }catch(Exception e){e.printStackTrace();}
	      try{ if(ps != null) ps.close(); }catch(Exception e){e.printStackTrace();}
	      try{ if(ps2 != null) ps2.close(); }catch(Exception e){e.printStackTrace();}
          //
          // Set auto commit back on if the XMLDBT.Translator left it off
          //
          try {con.setAutoCommit(true);} catch (Exception e) {}
        }

    } // insertXML()


    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


   private boolean otherJobsExistForThisAppID(long jobID,Node nod_root) throws Exception {

      /* glennl. CT159572  - Guarrentee'ing that jobs for the same app are processed in FIFO order.

      The primary key to the Post queue is transaction_id (called a job_id in the logs). It is a sequence that is increasing as jobs are added to 
      the queue. To simplify the ordering I can do the following.
      When a job is picked up for processing (ie job_id 123) I interrogate the XML for client_app_id. If found, I check the Post_queue table for 
      any jobs that have that client_app_id stored in the new field AND that has a transaction_id LOWER than mine (123). If any found, no matter
      what state they are in (not looking at tries_num) then, put the job back on the queue to be processed 1 min later (not sure what this delay
      should be but I could make it the same as the retries delay. If the retries delay is not specified then It will go back on the queue and be 
      pick up again on the next polling of the queue.
      Pros:
      This absolutely guarantees that all jobs will be processed in the right order. If any previous job was in error and ended up on the exception 
      queue or not then the current job will not be processed until these previous jobs are resolved or deleted.
      Cons:
      Exception queue jobs are eventually handled. (ps. We might need a way to delete a job from the queue 
      from the exception queue screen).
      BUT, If a job doesn't end up in the exception queue (ie. LoanAppRq, in coming app update) then it will sit in the queue until a person 
      uses the queue tool to either retry it or delete it. This could be days.
      Note: When a job is put back on the queue, its tries_num is set back to 0, next start date, and the error_txt is set to indicate that it was 
      put back on the queue awaiting previous jobs to finish.
      Also, this approach will catch the case where multiple jobs for the same app are backed up in the queue (waiting) and we want to make 
      sure that they also get processed in the right order.

      */


      boolean bOthersExistFlg = false;


      String sql="";
      String client_app_id="";
      String requestID="";
      String clientAppIDXPath="/IFX/*/*/Routing/To/IDs/ID[@Type='ApplicationNumber']/text()";
      Query query = new Query(con);
      PreparedStatement ps = null;
      PreparedStatement ps2 = null;
      ResultSet rs = null;
      Node nd;


      try {


            if (main.maxRetries > 0 ) { // retry logic is envoked, if we have reached our max tries then reset numRetries to 0 so we won't try again.
               query.prepareStatement("select nvl(wait_tries_num,0) wait_tries_num from posting_queue_header where transaction_id = ?");                      
               query.setLong(1, jobID);
               query.executePreparedQuery();	  
               query.next();
               if (Integer.parseInt(query.getColValue("wait_tries_num")) >= main.maxRetries) {
                  log_obj.FmtAndLogMsg("JOB: "+jobID+" Max retries reached for this app "+client_app_id+", continuing with last attempt");
                  numRetries=0; 
               }
            }


           // first obtain the client_app_id from the xml and then find its request_id

           nd = XPathAPI.selectSingleNode(nod_root,clientAppIDXPath);
           if (nd != null && nd.getNodeValue()!=null) client_app_id=nd.getNodeValue();

           if (client_app_id.length()==0) return bOthersExistFlg; // if can't find client app id then can't check further so return false

           // get request_id assoc w/client_app_id

           query.prepareStatement("select request_id from credit_request where client_app_id = ?");
           query.setString(1, client_app_id);
           query.executePreparedQuery();	  
           if (!query.next()) // if can't find request_id return false too
                return bOthersExistFlg;
           requestID=query.getColValue("request_id");

           // Update job with client_app_id so other jobs can check it

            sql = "UPDATE POSTING_QUEUE_HEADER SET client_app_id = ? WHERE TRANSACTION_ID = ?";
            ps2 = con.prepareStatement(sql);
            ps2.setString(1, client_app_id);
            ps2.setLong(2, jobID);
            ps2.execute();
            ps2.close();




            // Now check if any other jobs exist with the same client_app_id and a lower jobID

            query.prepareStatement("select transaction_id from posting_queue_header where transaction_id < ? and client_app_id = ? order by transaction_id");                      
            query.setLong(1, jobID);
            query.setString(2, client_app_id);
            query.executePreparedQuery();	  

            if (!query.next()) 
                return bOthersExistFlg; // No other previous job with app id needs to be processed so return false so this job can be processed

            String priorJobID = query.getColValue("transaction_id");

            // others exist before this one so put this job back in the queue by setting tries num back to 0, status_id = 0, and error_txt to a retry message


            int waitMins = 1;    // default to wait for one min in case wait time not supplied on start up script
            if (main.waitTime>0) waitMins=main.waitTime/60000;  // waitTime is optional in main (will be 0), convert back to mins
            // Oracle date math, 10 mins from now is:  sysdate + 10/1440

            // GL. 11/30/2012 CL161665 - option to not check if other jobs exist, if wait time is 0
            if (main.waitTime==0) 
               return bOthersExistFlg; // return false so this job can be processed


            bOthersExistFlg = true;

            query.prepareStatement("select nvl(wait_tries_num,0) wait_tries_num from posting_queue_header where transaction_id = ?");
            query.setLong(1, jobID);
            query.executePreparedQuery();	  
            query.next();
            int waitTries = Integer.parseInt(query.getColValue("wait_tries_num"));
            waitTries++; // need to increase by one before we update row

            String errMsg="This job needs to wait "+waitMins+" mins until a prior job for the same app finishes, Job ID: "+priorJobID+",  AppID: "+client_app_id+",  RID: "+requestID;
            errMsg=errMsg.replace("'"," "); // remove single quotes

            sql = "UPDATE POSTING_QUEUE_HEADER SET tries_num = -1, wait_tries_num = 0, status_id = 0, transaction_dt = sysdate + ? , error_txt = ?  WHERE TRANSACTION_ID = ?";

            log_obj.FmtAndLogMsg("JOB: "+jobID+" Putting job back on post queue to be processed in "+waitMins+" mins because: msg= "+errMsg);

            /**
             * TTP 324955 Security Remediation Fortify Scan
             */
            ps2 = con.prepareStatement(sql);
            
			ps2.setDouble(1, Double.valueOf( waitMins / 1440));// ps2.setBigDecimal(1, BigDecimal.valueOf((double) waitMins / 1440.0));
			ps2.setString(2, errMsg);
            ps2.setLong(3, jobID);
            ps2.execute();
            ps2.close();



      }
      catch (Exception e) {
         log_obj.FmtAndLogMsg("JOB: "+jobID+" Error checking otherJobs, method: otherJobsExistForThisAppID(), so letting this job continue to process, err= "+e.toString());
      }
      finally {
		 try{ if(rs != null) rs.close(); }catch(Exception e){e.printStackTrace();}
	     try{ if(ps != null) ps.close(); }catch(Exception e){e.printStackTrace();}
	     try{ if(ps2 != null) ps2.close(); }catch(Exception e){e.printStackTrace();}
      }

      return bOthersExistFlg;

   } // otherJobsExistForThisAppID()


    /**
     * Increment the tries for the current transaction.
     */
    private void incrementTries (long jobID) throws Exception {
     	String sql = "";
		PreparedStatement ps = null;		
        try {
            //
            // Increment the tries, also set status_id to 3 just incase it errors, it is already at an error state.
            // note: if it does not error, the record is removed so it does not remain in the queue in error state.
            //
            // 1/24/07 ChrisN CL140795 Replaced with SQL using bind variable for Triad performance enhancement
            //SQLUpdate.RunUpdateStatement(con,"UPDATE POSTING_QUEUE_HEADER " +
            //"SET TRIES_NUM = NVL(TRIES_NUM,0)+1, STATUS_ID=3 " +
            //"WHERE TRANSACTION_ID = " + jobID);
						sql = "UPDATE POSTING_QUEUE_HEADER SET TRIES_NUM = NVL(TRIES_NUM,0)+1, STATUS_ID=3 WHERE TRANSACTION_ID = ?";
						ps = con.prepareStatement(sql);
						ps.setLong(1, jobID);
						ps.execute();
						ps.close();
        }
        catch (Exception e) {
         // job no longer there, do nothing
        }
				finally {
					try { if (ps != null) ps.close();} catch (Exception e1) {e1.printStackTrace();}
				}
        return;
    }



    /**
     * Deletes a successful transaction from the posting_queue tables
     */
    private void deletePostingQueueJob(long jobID)  throws Exception {
     		String sql = "";
				PreparedStatement ps = null;

        try {
            // 1/24/07 ChrisN CL140795 Replaced with SQL using bind variable for Triad performance enhancement
            //SQLUpdate.RunUpdateStatement(con,"DELETE POSTING_QUEUE WHERE TRANSACTION_ID = " + jobID );
            //SQLUpdate.RunUpdateStatement(con,"DELETE POSTING_QUEUE_HEADER WHERE TRANSACTION_ID = " + jobID );
						sql = "DELETE POSTING_QUEUE WHERE TRANSACTION_ID = ?";
						ps = con.prepareStatement(sql);
						ps.setLong(1, jobID);
						ps.execute();
						ps.close();

						sql = "DELETE POSTING_QUEUE_EXCEPTION WHERE TRANSACTION_ID = ?";
						ps = con.prepareStatement(sql);
						ps.setLong(1, jobID);
						ps.execute();
						ps.close();

						sql = "DELETE POSTING_QUEUE_HEADER WHERE TRANSACTION_ID = ?";
						ps = con.prepareStatement(sql);
						ps.setLong(1, jobID);
						ps.execute();
						ps.close();
        }
        catch (java.sql.SQLException e) {
            throw new Exception("Caught Exception calling RunUpdateStatement in "+this.getClass()+":"+e.toString());
        }
				finally {
					try { if (ps != null) ps.close();} catch (Exception e1) {e1.printStackTrace();}
				}


        return;
    }


} // ProcessThread


