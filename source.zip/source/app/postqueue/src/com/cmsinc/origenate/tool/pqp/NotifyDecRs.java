package com.cmsinc.origenate.tool.pqp;

import org.w3c.dom.Node;

import com.cmsinc.origenate.event.CommentEvents;
import com.cmsinc.origenate.util.Query;
import com.cmsinc.origenate.util.XPathAPI;


/**
 * <pre>
 *
 * This class is used to receive load notifications from a Back End Lender
 *
 * </pre>
 *
 */
public class NotifyDecRs extends com.cmsinc.origenate.webservices.utils.BaseController {


    public void NotifyDecRs() {};


    /////////////////////////////////////////////////////////////////////////////////////////



    public void runController() throws Exception {



        try {

           getRoutingInfo();  // sets BaseController instance variables if they exist in the xml
                              // transID (ie. LoanAppRq), network (ie. COL),
                              // remoteRefNum, evaluator_id
                              // see method in base class for a complete list


           // All transactions MUST specify a network and evaluator ID

           /*  VALIDATE  NETWORK  AGAINST  EVALUATOR

           Verify that the Network (EIP) is valid for the evaluator.
           The xref_eval_networks table lists all networks that are valid for a given evaluator
           If its not valid then validateEvaluatorNetwork will throw a ValidationException

           network_id and evaluator_id were pulled from the xml by getRoutingInfo()
           */

           validateEvaluatorNetwork(network,evaluator_id);







           //  P R E P R O C E S S I N G   G O E S   H E R E 


           // If you want to inhibit sending a notification then set
           // sendNotification to false



           //  L O A D    X M L   T O    D A T A B A S E

           /* There is no xml to load. All we want to know is if the app we sent
              to the other Origenate system loaded or not and if so, grab the
              app number from the other system and store it in our app ids table
              so we can send subsequent responses to the other Origenate system
              to the right app.
           */

           // loadXML();


           Node nd=null;
           String status="",message="";

           String xpath="/IFX/*/*/LoanAppRs/Decision/attribute::Status/text()";
           nd = XPathAPI.selectSingleNode(nod_root,xpath);
           if (nd != null && nd.getNodeValue()!=null) status = nd.getNodeValue();
           xpath="/IFX/*/*/LoanAppRs/Decision/MessageText/text()";
           nd = XPathAPI.selectSingleNode(nod_root,xpath);
           if (nd != null && nd.getNodeValue()!=null) message = nd.getNodeValue();


           if (status.length()==0)
               log_obj.FmtAndLogMsg("NotifyDecRs: No status tag found",i_dbg_lvl,0);
           else
              if (status.equals("LOADED")) {

                 try {



                     cleanup(); /* will store the app ID from the Back end lender in the
                                 credit_request_app_ids table under eval_14_app_id if
                                 it successfully loaded.
                               */
                     Query query = new Query(con);

                     String evalName="Unknown";
                     String sql = "select evaluator_name_txt from evaluator where evaluator_id = ? ";
                 	 query.prepareStatement(sql);
                	 query.setInt(1, from_evaluator_id);
                	 query.executePreparedQuery();
                     if (query.next()) 
                        evalName=query.getColValue("evaluator_name_txt","null");


                     CommentEvents ce = new CommentEvents(con,log_obj);
                     ce.addComment(Integer.parseInt(requestID),64,"APP LOADED","App received by "+evalName+", Assigned App ID: "+from_evaluator_appid,"SYSTEM","",null);

                     /* GL. 1/10/05 No need to flash icon, annoying
                     SQLUpdate.RunUpdateStatement(con,"UPDATE CREDIT_REQUEST SET COMMENTS_RECEIVED_FLG = 1 WHERE "+
                         "REQUEST_ID = "+requestID);
                      */
                 }
                 catch (java.sql.SQLException e1) {
                     log_obj.FmtAndLogMsg("NotifyDecRs: Load status received, but error processing for jobID:"+jobID+" request_id:"+requestID+" err="+e1.toString());
                     // not serious enough to abort
                 }

              }
              else  { // noload

                 Query query = new Query(con);

                 String evalName="Unknown";
                 String sql = "select evaluator_name_txt from evaluator where evaluator_id = ? ";
             	 query.prepareStatement(sql);
            	 query.setInt(1, from_evaluator_id);
            	 query.executePreparedQuery();
                 if (query.next()) 
                    evalName=query.getColValue("evaluator_name_txt","null");

                 //log_obj.FmtAndLogMsg("NotifyDecRs: NOLoad status received from: "+evalName+" for job "+jobID+" reason: "+message);

                 throw (new Exception("NotifyDecRs: NOLoad status received from: "+evalName+" for job "+jobID+" reason: "+message));   
              }


        }
        catch (Exception e) {


            throw (new Exception("NotifyDecRs: Unexpected error - "+e.toString()));   // throw it back to the caller so they can set the status of 
                         // the job to error

        } // exception



        // if haven't thrown an error by now then the calling PQP will delete the
        // job row from the PQP queue



    }  // runController()






} // NotifyDecRs


