package com.cmsinc.origenate.tool.pqp;

import com.cmsinc.origenate.event.CommentEvents;
import com.cmsinc.origenate.event.JournalEvents;
import com.cmsinc.origenate.util.IniFile;
import com.cmsinc.origenate.util.PostRequest;
import com.cmsinc.origenate.util.Query;
import com.cmsinc.origenate.util.SQLUpdate;
import com.cmsinc.origenate.util.XPathAPI;

import java.io.*;
import java.sql.*;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.Date;

import org.w3c.dom.*;
import sun.misc.BASE64Decoder;
import com.cmsinc.origenate.util.SQLSecurity;
import com.cmsinc.origenate.util.OWASPSecurity;
/**
 * <pre>
 *
 * This class is loaded by InsretPostObject.java to process an incoming XML transaction
 * when no other Controller class for the transaction type is found.
 *
 *
 * If you are implementing a Controller for a particular trans type ( LoanAppRq )
 * then make a copy of this .java file and rename it to LoanAppRq.java. Then change
 * the class name and constructor and add any business logic in runController
 * as required.
 *
 * </pre>
 *
 */
public class TAFRs extends com.cmsinc.origenate.webservices.utils.BaseController {

    public TAFRs() {
    }
    ;


    /////////////////////////////////////////////////////////////////////////////////////////
    public void runController() throws Exception {

        Query query = new Query(con);
        String TAFType = "";
        String strProviderOrderNbr = "";
		//i_dbg_lvl = 5;//hardcode for testing!

        String evaluatorID = "";
        String appseqno = "0";
        String strQueryID = "";

        String auditFields = getAuditFields(Integer.valueOf(requestID));

        /*
        TAFRs: First use - to receive TAF decisions
         */

        try {

            getRoutingInfo();  // sets BaseController instance variables if they exist in the xml
            // transID (ie. LoanAppRq), network (ie. COL),
            // remoteRefNum, evaluator_id, etc
            // see method in base class for a complete list

            // All transactions MUST specify a network and evaluator ID

            /*  VALIDATE  NETWORK  AGAINST  EVALUATOR

            Verify that the Network (EIP) is valid for the evaluator.
            The xref_eval_networks table lists all networks that are valid for a given evaluator
            If its not valid then validateEvaluatorNetwork will throw a ValidationException

            network_id and evaluator_id were pulled from the xml by getRoutingInfo()
             */

            validateEvaluatorNetwork(network, evaluator_id);

            //  P R E P R O C E S S I N G   G O E S   H E R E



            // If you want to inhibit sending a notification then set
            // sendNotification to false

            requestID = source_RID;
            evaluatorID = evaluator_id;
			
				//Kick request back if application if in use, otherwise lock for processing  
			//If in use, re-try logic will kick in if "PreLoadError" is included in exception.
			query.prepareStatement("select user_id from concurrency_control where request_id = ?");
			query.setInt(1,Integer.parseInt(requestID));
			query.executePreparedQuery();
			if (query.next())
				throw new Exception("PreLoadError: Application is in use by lender. TAF response delayed. Utilizing re-try logic...");
								
			String evalHost = ini.getINIVar("evaluate.ini_host","");
			String evalPort = ini.getINIVar("evaluate.ini_port","");
			String evalEnv = ini.getINIVar("evaluate.environment","");			
			
			SQLUpdate sqlUpdate = new SQLUpdate();
			String updateStatement = "INSERT INTO concurrency_control " +
					"	(REQUEST_ID," +
					"	USER_ID, " +
					" 	LOCK_DT, " +
					"	LOCK_TYPE_ID, " +
					"	LOCK_DESC_TXT, " +
					"	EVAL_HOST, " +
					"	EVAL_PORT, " +
					"	EVAL_ENV) " +
					"	VALUES (" +
					"	?," +
					"	'SYSTEM', " +
					"	SYSDATE, " +
					"	1, " +
					"	'Loading TAF Response', " +
					"	?," +
					"	?," +
					"	? )";
					
			try {
				sqlUpdate.SetPreparedUpdateStatement(con, updateStatement);
				sqlUpdate.setInt(1, Integer.parseInt(requestID));
				sqlUpdate.setString(2, evalHost.toUpperCase());
				sqlUpdate.setString(3, evalPort);
				sqlUpdate.setString(4, evalEnv.toUpperCase());
				sqlUpdate.RunPreparedUpdateStatement();
				log_obj.FmtAndLogMsg("RID: " + requestID + " Set application lock for TAFRs");
			} catch (Exception e1) {
				log_obj.FmtAndLogMsg("RID: " + requestID + " Error setting application lock: " + e1.toString());		
				throw new Exception("Reason: Error trying to lock application, please try again later");
			}	

            String sXPath = "/IFX/CreditSvcRs/LoanAppSvcRs/TAFRs/TAFType/text()";
            Node nd = XPathAPI.selectSingleNode(nod_root, sXPath);
            if (nd != null && nd.getNodeValue() != null) {
                TAFType = nd.getNodeValue();
            } else {
                validationErrorOccurred = true;
                errorMsg = "Job " + jobID + ": " + "ERROR: no TAFType found in TAFRs, our RID:" + requestID;
				// calling exception then 
				deleteConcurency(requestID);
                throw new Exception(errorMsg);
            }

            sXPath = "/IFX/CreditSvcRs/LoanAppSvcRs/Collateral/CollateralInfo/TAFResponseHeader/ProviderOrderNbr/text()";
            nd = XPathAPI.selectSingleNode(nod_root, sXPath);
            if (nd != null && nd.getNodeValue() != null) {
                strProviderOrderNbr = nd.getNodeValue();
            } else {
                validationErrorOccurred = true;
                errorMsg = "Job " + jobID + ": " + "ERROR: no ProviderOrderNbr found in TAFResponseHeader, our RID:" + requestID;
				// calling exception then 
				deleteConcurency(requestID);
                throw new Exception(errorMsg);
            }
            sXPath = "/IFX/CreditSvcRs/LoanAppSvcRs/TAFRs/QueryID/text()";
            nd = XPathAPI.selectSingleNode(nod_root, sXPath);
            if (nd != null && nd.getNodeValue() != null) {
                String strTmp = nd.getNodeValue();
                int Idx = strTmp.indexOf('-');
                if (Idx != -1) {
                    strQueryID = strTmp.substring(Idx + 1);
                }
            } else {
                validationErrorOccurred = true;
                errorMsg = "Job " + jobID + ": " + "ERROR: no '/IFX/CreditSvcRs/LoanAppSvcRs/TAFRs/QueryID' found, our RID:" + requestID;
				// calling exception then 
				deleteConcurency(requestID);
                throw new Exception(errorMsg);
            }

            query.prepareStatement("select appseqno from credit_request where request_id = ?");
            query.setInt(1, Integer.parseInt(requestID));
            query.executePreparedQuery();
            
            if (query.next()) {
                appseqno = query.getColValue("appseqno", "0");
            }

            sXPath = "/IFX/CreditSvcRs/LoanAppSvcRs/TAFRs/EventCode/text()";    // Responses with no status are just acknowledgments
            nd = XPathAPI.selectSingleNode(nod_root, sXPath);                   // Only real responses should be loaded into the response tables
            if (nd != null && nd.getNodeValue() != null) {
                // check if there is a sequence of responses configured; if there is, then make sure prerequisites have been satisfied
                Query seqQuery = new Query(con);
                seqQuery.prepareStatement("select title_sequence_flg, appraisal_sequence_flg, flood_sequence_flg from CONFIG_EVAL_TAF_MISC_FIELDS where evaluator_id = ?");
                seqQuery.setInt(1, Integer.parseInt(evaluatorID));
                seqQuery.executePreparedQuery();
                
                String taftypeid = TAFType.substring(0,1).toUpperCase();
                
                boolean b_validsequence = true;
                
                if (seqQuery.next()) {
                    if ((seqQuery.getColValue("title_sequence_flg","0").equals("1") && taftypeid.equals("T")) || (seqQuery.getColValue("appraisal_sequence_flg","0").equals("1") && taftypeid.equals("A")) || (seqQuery.getColValue("flood_sequence_flg","0").equals("1") && taftypeid.equals("F")) ) {
                        log_obj.FmtAndLogMsg("RID: " + requestID + " TAF sequence defined, checking prerequisites");
                        b_validsequence = checkConfigSequence(Integer.parseInt(requestID), Integer.parseInt(evaluatorID), taftypeid);
                        log_obj.FmtAndLogMsg("RID: " + requestID + " should the TAFRs continue: b_validsequence = "+b_validsequence);
                    }   
                }
                
                int pause = 10;  // this controls how long in seconds to delay processing an app that comes in out of sequence
                // if the sequence isn't valid, throw an exception so it stays on the queue, but update the error so we can use it
                // to communicate with the controller class next time.  kind of a hack, but without a dedicated column, this is the best
                // we can do.  note - this exception will be handled by processthread.java which we will have a case for this to make sure
                // the record is massaged appropriately instead of the default update!
                // current requirement is delay 10s, 11s, 12s, 13s, 30s, load regardless of prerequisites
                if (!b_validsequence) {
                    log_obj.FmtAndLogMsg("RID: " + requestID + " TAFRs transaction failed prerequisite checks configured in config_taf_resp_seq.");
                    try {
                        // pull the last error
                        query.prepareStatement("SELECT error_txt FROM posting_queue_header where transaction_id = ?");
                        query.setLong(1, jobID);
                        query.executePreparedQuery();
                        
                        if (query.next()) {
                            // if the last error was a delay because of sequencing, then increment the seconds (so we know which iteration this is)
                            // and throw the exception to be retried later
                            int pauseIndex = query.getColValue("error_txt","").indexOf("TAFRs is pausing this job");
                            if (pauseIndex > 0) {
                                pause = Integer.parseInt(query.getColValue("error_txt").substring(pauseIndex+26,pauseIndex+28))+1;
                            }
                            
                            // the last iteration
                            if (pause == 14)
                                pause = 30;
                                
                        }
                    }
                    catch (Exception e) {
						// calling exception then 
						deleteConcurency(requestID);
                        throw new Exception("Could not determine how to pause this TAFRs transaction, so do not retry; error: " + e.toString());
                    }
                    
                    if (pause != 31) {
                        log_obj.FmtAndLogMsg("RID: " + requestID + " throw custom exception to pause TAFRs for sec = "+pause);
						// calling exception then 
						deleteConcurency(requestID);
                        throw new Exception("RID: " + requestID + " TAFRs is pausing this job "+pause+" seconds because it came in out of sequence.");
                    }   
                    else
                        log_obj.FmtAndLogMsg("RID: " + requestID + " did not pause transaction");
                }   
                //  L O A D     X M L
				log_obj.FmtAndLogMsg("RID: " + requestID + " Before loadXML", i_dbg_lvl, 0);
                loadXML();
                log_obj.FmtAndLogMsg("RID: " + requestID + " After loadXML", i_dbg_lvl, 0);

                //Insert or update the response summary record
				log_obj.FmtAndLogMsg("RID: " + requestID + " Before manageResponseSummaryRecords", i_dbg_lvl, 5);
                manageResponseSummaryRecords(TAFType, evaluatorID, requestID);
				log_obj.FmtAndLogMsg("RID: " + requestID + " After manageResponseSummaryRecords", i_dbg_lvl, 5);

                SQLUpdate tafupdate = new SQLUpdate();
                // Update the TAF Notification flag in the credit request table
                // so the queue will show a flashing icon that aTAF response was received
                try {
					log_obj.FmtAndLogMsg("RID: " + requestID + " " + TAFType + " begin update credit_request setting taf notification id to 2", i_dbg_lvl, 5);
                    if (TAFType.equalsIgnoreCase("APPRAISAL")) {
                        try {                            
                            tafupdate.SetPreparedUpdateStatement(con, "UPDATE CREDIT_REQUEST SET TAF_APPRAISAL_NOTIF_ID = 2 WHERE REQUEST_ID = ?");
                            tafupdate.setInt(1, Integer.valueOf(requestID));
                            tafupdate.RunPreparedUpdateStatement();
                        } catch (java.sql.SQLException e) {
                            log_obj.FmtAndLogMsg("RID: " + requestID + " Can't update CREDIT_REQUEST.TAF_APPRAISAL_NOTIF_ID for request_id:" + requestID + " err=" + e.toString());
                        // not serious enough to abort
                        }
                    } else if (TAFType.equalsIgnoreCase("TITLE")) {
                        try {
                            tafupdate.SetPreparedUpdateStatement(con, "UPDATE CREDIT_REQUEST SET TAF_TITLE_NOTIF_ID = 2 WHERE REQUEST_ID = ?");
                            tafupdate.setInt(1, Integer.valueOf(requestID));
                            tafupdate.RunPreparedUpdateStatement();
                        } catch (java.sql.SQLException e) {
                            log_obj.FmtAndLogMsg("RID: " + requestID + " Can't update CREDIT_REQUEST.TAF_TITLE_NOTIF_ID for request_id:" + requestID + " err=" + e.toString());
                        // not serious enough to abort
                        }
                    } else if (TAFType.equalsIgnoreCase("FLOOD")) {
                        try {
                            tafupdate.SetPreparedUpdateStatement(con, "UPDATE CREDIT_REQUEST SET TAF_FLOOD_NOTIF_ID = 2 WHERE REQUEST_ID = ?");
                            tafupdate.setInt(1, Integer.valueOf(requestID));
                            tafupdate.RunPreparedUpdateStatement();
                        } catch (java.sql.SQLException e) {
                            log_obj.FmtAndLogMsg("RID: " + requestID + " Can't update CREDIT_REQUEST.TAF_FLOOD_NOTIF_ID for request_id:" + requestID + " err=" + e.toString());
                        // not serious enough to abort
                        }
                    }
					log_obj.FmtAndLogMsg("RID: " + requestID + "  " + TAFType + "done update credit_request setting taf notification id to 2", i_dbg_lvl, 5);
                } catch (java.sql.SQLException e) {
                    log_obj.FmtAndLogMsg("RID: " + requestID + " Can't update credit_request.TAF_FLOOD_NOTIF_ID for jobID:" + jobID + " request_id:" + requestID + " err=" + e.toString() + " TAFType=" + TAFType);
                // not serious enough to abort
                }


            } else {
                try {
                    String journalEventTxt = TAFType + " acknowledgment has been received";
                    int reqID = Integer.parseInt(requestID);
                    JournalEvents journalEvents = new JournalEvents(con, null);
                    journalEvents.addJournal(reqID, 44, journalEventTxt, "SYSTEM");
                } catch (Exception e) {
                    log_obj.FmtAndLogMsg("RID: " + requestID + " Can't post journal event for jobID:" + jobID + " request_id:" + requestID + " err=" + e.toString());
                }
            }

        } catch (Exception e) {
			log_obj.FmtAndLogMsg("RID: " + requestID + " Exception processing taf, taf type: [" + TAFType + "]", e);
            // errorMsg is set by loadXML, etc

            // You can check the following booleans to see what type of error
            // occurred. A verification error happens when a column failed
            // a valiadtion like invalid state code, a general error occurs
            // when an unexpected error occurs like a null pointer exception

            // here for your use
            if (validationErrorOccurred || generalErrorOccurred) {
            }

            // FAILED TO LOAD, see if we need to send a notification back to the originator
            // based on EIP

            /*
            The network in a xml doc is the EIP (External Internet Partner) ID.
            If an entry exists in the xref_source_states for a NOLOAD state for this
            EIP then send a notification to this partner by putting an entry on the routing
            queue that specifies an action that will send a response to the response_url.
             */

            // loadXML() sets network,transID, etc.
			log_obj.FmtAndLogMsg("RID: " + requestID + " will send no load notification: [" + sendNotification + "]", i_dbg_lvl, 5);
            if (sendNotification) {
                try {
					log_obj.FmtAndLogMsg("RID: " + requestID + " before sending no load notification", i_dbg_lvl, 5);
                    sendNotification("NOLOAD", network, transID, errorMsg, e.toString(), requestID, remoteRefNum, clientAppID, evaluator_id);
					log_obj.FmtAndLogMsg("RID: " + requestID + " after sending no load notification", i_dbg_lvl, 5);
                } catch (Exception e1) {
                    // don't throw an error, not important enough, just log it
                    log_obj.FmtAndLogMsg("RID: " + requestID + " Error processing NOLOAD Notification: " + e1.toString());
                }
            }


			// calling exception then 
			deleteConcurency(requestID);

            throw (e);   // throw it back to the caller so they can set the status of
        // the job to error

        } // exception

        //   S U C C E S S F U L     L O A D

        //   D O    P O S T    L O A D    P R O C E S S I N G
		log_obj.FmtAndLogMsg("RID: " + requestID + " before storeTAFPDF", i_dbg_lvl, 5);
		try{
			storeTAFPDF(TAFType, evaluatorID, requestID);
		}catch(Exception e2){
			log_obj.FmtAndLogMsg("RID: " + requestID + " after storeTAFPDF" + " "+e2.toString(), i_dbg_lvl, 5);
			// calling exception then 
			deleteConcurency(requestID);
			throw (e2);  
			
		}
		log_obj.FmtAndLogMsg("RID: " + requestID + " after storeTAFPDF", i_dbg_lvl, 5);
        /* Post a journal event for this app to indicate that a decision
        was received from a secondary lender
         */
        String jEventTxt = "";
        String tafRespTable = "";
        
        PreparedStatement psJournal = null;
        ResultSet rsJournal = null;
        
        try{
         String taf_type_txt = "";
         if (TAFType.equalsIgnoreCase("APPRAISAL")) {
             taf_type_txt = "A";
             tafRespTable = "credit_req_APPRAISAL_resp";
         }else if (TAFType.equalsIgnoreCase("TITLE")) {
             taf_type_txt = "T";
             tafRespTable = "credit_req_title_resp";
         }else if (TAFType.equalsIgnoreCase("FLOOD")) {
             taf_type_txt = "F";
             tafRespTable = "credit_req_flood_resp";
         }
		log_obj.FmtAndLogMsg("RID: " + requestID + " begin journal text generation query ", i_dbg_lvl, 5);
        String sqlJournal = "select crtr.response_status_code_txt, crtr.RESPSEQNO, " +
                "cv.vendor_name_txt, ctrs.response_status_code_desc_txt, cstc.service_type_code_desc_txt " +
                "FROM "+ tafRespTable +" crtr, credit_request_home_equity crhe , config_vendor cv, " +
                "config_taf_response_status ctrs, mstr_taf_provider mtp, config_service_type_code cstc " +
                "where crtr.request_id = ? and crtr.evaluator_id = ? and crhe.request_id = ? " +
                "and crhe.collateral_request_id = crtr.collateral_request_id and crhe.home_equity_id = crtr.home_equity_id " +
                "and cv.vendor_id = crtr.vendor_id and cv.evaluator_id = ? " +
                "and ctrs.response_status_code_txt = crtr.response_status_code_txt and ctrs.evaluator_id = ? " +
                "and ctrs.taf_provider_id = mtp.taf_provider_id and cstc.evaluator_id = ? " +
                "and cstc.vendor_id = crtr.vendor_id and cstc.taf_type_txt = '"+ taf_type_txt +"' and cstc.service_type_code_txt = crtr.service_type_code_txt " +
                "order by crtr.RESPSEQNO desc";
        psJournal = con.prepareStatement(sqlJournal);
        psJournal.setInt(1, Integer.valueOf(requestID));
        psJournal.setInt(2, Integer.valueOf(evaluatorID));
        psJournal.setInt(3, Integer.valueOf(requestID));
        psJournal.setInt(4, Integer.valueOf(evaluatorID));
        psJournal.setInt(5, Integer.valueOf(evaluatorID));
        psJournal.setInt(6, Integer.valueOf(evaluatorID));

        rsJournal = psJournal.executeQuery();

        while (rsJournal.next()) {

            jEventTxt += TAFType.toUpperCase() + " Response from ";
            jEventTxt += rsJournal.getString("VENDOR_NAME_TXT");
            jEventTxt += " for ";
            jEventTxt += rsJournal.getString("SERVICE_TYPE_CODE_DESC_TXT");
            jEventTxt += ", ";
            jEventTxt += rsJournal.getString("RESPONSE_STATUS_CODE_TXT");
            jEventTxt += " ";
            jEventTxt += rsJournal.getString("RESPONSE_STATUS_CODE_DESC_TXT");
            break;
        }
        }catch (Exception e){
           jEventTxt += "TAF received: " + evaluatorID;     // Fallback to old string.
           log_obj.FmtAndLogMsg("RID: " + requestID + " Can not get the data for Taf journal query " , e);
        }
        finally {
            try { if (rsJournal != null) rsJournal.close();} catch (Exception e) {e.printStackTrace();}
            try { if (psJournal != null) psJournal.close();} catch (Exception e) {e.printStackTrace();}
        }
        
		log_obj.FmtAndLogMsg("RID: " + requestID + " creating journal and comment entries" , i_dbg_lvl, 5);
        try {

            int reqID = Integer.parseInt(requestID);
            JournalEvents journalEvents = new JournalEvents(con, null);
            journalEvents.addJournal(reqID, 44, jEventTxt, "SYSTEM");
        // 44 - LLReceived, journal_event_id, network is who we received from
        } catch (Exception e) {
            log_obj.FmtAndLogMsg("RID: " + requestID + " Can't post journal event for jobID:" + jobID + " request_id:" + requestID + " err=" + e.toString());
        // not serious enough to abort
        }
		
        try {
            CommentEvents commentEvents = new CommentEvents(con, log_obj);
            commentEvents.addComment(Integer.parseInt(requestID),
                    64, /* misc comment */
                    "TAF received", // 50
                    "Lender application number: " + from_evaluator_appid, // 4000
                    "",// no create user ID
                    "",// no assigned user ID
                    "");  // no due date
        } catch (Exception e) {
            // not serious enough to abort
            log_obj.FmtAndLogMsg("RID: " + requestID + " Can't post comment for jobID:" + jobID + " request_id:" + requestID , e);
        }
		log_obj.FmtAndLogMsg("RID: " + requestID + " done creating journal and comment entries", i_dbg_lvl, 5);

        // TTP 324955 Security Remediation Fortify Scan
        query.prepareStatement("select appseqno from credit_request where request_id = ?");
        query.setInt(1, requestID);
        query.executePreparedQuery();
        if (query.next()) {
            appseqno = query.getColValue("appseqno", "0");
        }
		log_obj.FmtAndLogMsg("RID: " + requestID + " Before update TAF_Inquiry, asn retrieved: " + appseqno, i_dbg_lvl, 5);
        try {
            SQLUpdate.RunUpdateStatement(con, "UPDATE TAF_INQUIRY SET PROVIDERPROPID ='" + strProviderOrderNbr + "' WHERE " +
                    "APPSEQNO = " + appseqno + " and QUERYID = '" + strQueryID + "'");
        } catch (java.sql.SQLException e) {
            log_obj.FmtAndLogMsg("RID: " + requestID + " Can't update TAF_INQUIRY.PROVIDERPROPID for appseqno:" + appseqno + " and QUERYID = " + strQueryID + " err=" + e.toString());
        // not serious enough to abort
        }
        log_obj.FmtAndLogMsg("RID: " + requestID + " After update TAF_Inquiry");


        // see if the originator wants to be notified of successful loads

        if (sendNotification) {
            try {
				log_obj.FmtAndLogMsg("RID: " + requestID + " sendNotification for successful load" , i_dbg_lvl, 5);
                sendNotification("LOAD", network, transID, "Successful", "Successfully loaded", requestID, remoteRefNum, clientAppID, evaluator_id);
				log_obj.FmtAndLogMsg("RID: " + requestID + " sendNotification for successful load complete" , i_dbg_lvl, 5);
            } catch (Exception e1) {
                log_obj.FmtAndLogMsg("RID: " + requestID + " Error processing LOAD Notification: " + e1.toString());
            }
        }

        // if haven't thrown an error by now then the calling PQP will delete the
        // job row from the PQP queue

        // run completion rules
		log_obj.FmtAndLogMsg("RID: " + requestID + " before runCompletionRules", i_dbg_lvl, 5);
        boolean failedCompletionChecks = runCompletionRules();
		log_obj.FmtAndLogMsg("RID: " + requestID + " after runCompletionRules, failedCompletionChecks: ["+ failedCompletionChecks +"]", i_dbg_lvl, 5);
        if (!failedCompletionChecks) {
            // determine whether we need to run ReScore
            ArrayList<String> updatedAuditFields = getUpdatedAuditFields(Integer.valueOf(requestID), auditFields);
            boolean[] callEval = checkConfigurableRedecision(Integer.valueOf(requestID), Integer.valueOf(evaluatorID), updatedAuditFields);


            if (callEval[0] == true) {
                ArrayList<String> requestorIDList = new ArrayList<String>();
                PreparedStatement reqQuery  = null;
                ResultSet reqResultSet = null;
                String str_sql = "";
                try {
                    str_sql = "SELECT requestor_id, requestor_type_id " +
                                    "FROM requestor_header " +
                                    "WHERE request_id = ? AND requestor_id >= 0 " +
                                    "ORDER BY requestor_type_id desc";
                    reqQuery = con.prepareStatement(str_sql);
                    // order by requestor type so that if it is a business, it will be the first record (changing requestor type for id 2 to guarantor instead of cosigner)
                    reqQuery.setInt(1, Integer.valueOf(requestID));
                    reqResultSet = reqQuery.executeQuery();
     
                    while (reqResultSet.next()) {
                        requestorIDList.add(reqResultSet.getString("requestor_id"));
                    } // while more requestors
                } catch (Exception e) {
                   e.printStackTrace();
                }
                finally {
                    try { if (reqResultSet != null) reqResultSet.close();} catch (Exception e) {e.printStackTrace();}
                    try { if (reqQuery != null) reqQuery.close();} catch (Exception e) {e.printStackTrace();}
                }
                
                // use the RoutingQueue to submit a ReScore request
                String scriptID = "6"; // ReScore
                String touchPointID = "1"; // application data changed
                // add entry to evaluate request queue
                Iterator<String> requestorIDListIter = requestorIDList.iterator();

                while (requestorIDListIter.hasNext()) {
                    log_obj.FmtAndLogMsg("RID: " + requestID + " TAFRs: RID=" + requestID + ", Insert to evaluate_request_queue for each requestor...", i_dbg_lvl, 5);
                    StringBuffer erqStringBuf = new StringBuffer();

                    erqStringBuf.append("INSERT INTO evaluate_request_queue (");
                    erqStringBuf.append("evaluate_request_queue_id, request_id, requestor_id, script_id, comment_txt, user_id, requested_dt, touchpoint_id");
                    erqStringBuf.append(") VALUES (");
                    erqStringBuf.append("EVALUATE_REQUEST_QUEUE_SEQ.nextval, ?, ?, " + scriptID + ", ?, ?, SYSDATE, " + touchPointID);
                    erqStringBuf.append(")");

                    PreparedStatement erqps = null;

                    try {
                        erqps = con.prepareStatement(erqStringBuf.toString());
                        erqps.setInt(1, Integer.parseInt(requestID));
                        erqps.setInt(2, Integer.parseInt((String) requestorIDListIter.next()));
                        erqps.setString(3, "Created by LoanAppRq.java");
                        erqps.setString(4, "SYSTEM");
                        erqps.execute();
                        erqps.close();
                    } catch (SQLException e) {
                        try { if (erqps != null) erqps.close();} catch (Exception e1) {e1.printStackTrace();}
						// calling exception then 
						deleteConcurency(requestID);
                        throw (e);
                    } finally {
                        try { if (erqps != null) erqps.close();} catch (Exception e1) {e1.printStackTrace();}
                    }
                }

                // place entry on routing queue so application can be scored by eValuate
                String routingStateID = "13"; // can not access main so default to 13 : main.getNextRoutingStateID();
                String evalURL = "";

                if (routingStateID.equals("13")) {
                    evalURL = ini.getINIVar("urls.eval_app_complete_url", "");
                } else {
                    evalURL = ini.getINIVar("urls.eval_app_complete_url" + routingStateID, "");

                    if (evalURL.length() <= 0) {
                        evalURL = ini.getINIVar("urls.eval_app_complete_url", "");
                        routingStateID = "13";
                    }
                }

                if (evalURL.length() <= 0) {
					// calling exception then 
					deleteConcurency(requestID);
                    throw new Exception("Error retrieving App Complete Evaluation URL from ini file");
                }
				log_obj.FmtAndLogMsg("RID: " + requestID + " in runController insert to routing_queue so app can be scored by evaluate", i_dbg_lvl, 5);
                String addlData = "CF_URL," + evalURL + requestID + "&evaluator_id=" + evaluator_id + "&redecEligFlg=" + (callEval[1] == true ? "1" : "0");
                StringBuffer rqStringBuf = new StringBuffer();

                rqStringBuf.append("INSERT INTO routing_queue(");
                rqStringBuf.append("routing_queue_id, request_id, queue_priority_num, routing_state_id, run_dt, tries_num, additional_data_txt");
                rqStringBuf.append(") VALUES (");
                rqStringBuf.append("ROUTING_QUEUE_SEQ.nextval, ?, 100, ?, SYSDATE, 0, ?)");
                
                //TTP 324955 Security Remediation Fortify Scan
                SQLUpdate sqlup1 = new SQLUpdate();
                sqlup1.SetPreparedUpdateStatement(con, rqStringBuf.toString());
                sqlup1.setInt(1, requestID);
                sqlup1.setInt(2, routingStateID);
                sqlup1.setString(3, addlData);
                sqlup1.RunPreparedUpdateStatement();
            }
        }
    }  // runController()

////////////////////////////////////////////////////////////////////////////////////
    private void storeTAFPDF(String TAFType, String evaluatorID, String xrequestID) throws Exception {

       // IniFile ini = null;  // ini already defined and set in BasController initalize() method
        String inifilename = "";
        String taf_title_dir = "";
        String taf_title_obj = "";
        String taf_appraisal_dir = "";
        String taf_appraisal_obj = "";
        String taf_flood_dir = "";
        String taf_flood_obj = "";
        String TAFData = "";
        String TAF_RESP_TABLE = "";
        String TAF_DOCS_TABLE = "";
        String TAFDocXPath = "";
        String TAFDocNameXPath = "";
        String TAFSeqnoPath = "";
        String docPath = "";
        String dirObjectName = "";
        int OCCURRENCE = 0;
        String sql = "";


        for (int i=1; i<=10; i++) {

                  OCCURRENCE=i;

                  if (TAFType.equalsIgnoreCase("TITLE")) {
                      TAF_RESP_TABLE = "CREDIT_REQ_TITLE_RESP";
                      TAF_DOCS_TABLE = "CREDIT_REQ_TITLE_DOCS";
                      TAFDocXPath = "/IFX/CreditSvcRs/LoanAppSvcRs/Collateral/CollateralInfo/TitleResponseDocs["+i+"]/Document/text()";
                      TAFDocNameXPath = "/IFX/CreditSvcRs/LoanAppSvcRs/Collateral/CollateralInfo/TitleResponseDocs["+i+"]/DocumentName/text()";
                      TAFSeqnoPath = "/IFX/CreditSvcRs/LoanAppSvcRs/Collateral/CollateralInfo/TitleResponse/Seqno/text()";
                      sql = "insert into CREDIT_REQ_TITLE_DOCS ";
                  } else if (TAFType.equalsIgnoreCase("APPRAISAL")) {
                      TAF_RESP_TABLE = "CREDIT_REQ_APPRAISAL_RESP";
                      TAF_DOCS_TABLE = "CREDIT_REQ_APPRAISAL_DOCS";
                      TAFDocXPath = "/IFX/CreditSvcRs/LoanAppSvcRs/Collateral/CollateralInfo/AppraisalResponseDocs["+i+"]/Document/text()";
                      TAFDocNameXPath = "/IFX/CreditSvcRs/LoanAppSvcRs/Collateral/CollateralInfo/AppraisalResponseDocs["+i+"]/DocumentName/text()";
                      TAFSeqnoPath = "/IFX/CreditSvcRs/LoanAppSvcRs/Collateral/CollateralInfo/AppraisalResponse/Seqno/text()";
                      sql = "insert into CREDIT_REQ_APPRAISAL_DOCS ";
                  } else if (TAFType.equalsIgnoreCase("FLOOD")) {
                      TAF_RESP_TABLE = "CREDIT_REQ_FLOOD_RESP";
                      TAF_DOCS_TABLE = "CREDIT_REQ_FLOOD_DOCS";
                      TAFDocXPath = "/IFX/CreditSvcRs/LoanAppSvcRs/Collateral/CollateralInfo/FloodResponseDocs["+i+"]/Document/text()";
                      TAFDocNameXPath = "/IFX/CreditSvcRs/LoanAppSvcRs/Collateral/CollateralInfo/FloodResponseDocs["+i+"]/DocumentName/text()";
                      TAFSeqnoPath = "/IFX/CreditSvcRs/LoanAppSvcRs/Collateral/CollateralInfo/FloodResponse/Seqno/text()";
                      sql = "insert into CREDIT_REQ_FLOOD_DOCS ";
                  }

                  Node nd = null;
                  nd = XPathAPI.selectSingleNode(nod_root, TAFDocXPath);
                  if (nd != null && nd.getNodeValue() != null) {
                      
                      Statement ini_stmt = null;
                      PreparedStatement ini_stmt2 = null;
                      ResultSet ini_rs = null;
                      try {
                          TAFData = nd.getNodeValue();
                          log_obj.FmtAndLogMsg("RID: " + requestID + " in storeTAFPDF for iteration " +i+" TAFData: [" + TAFData +"]", i_dbg_lvl, 5);
                          BASE64Decoder decoder = new BASE64Decoder();
                          /*
                          Big problem: base64 encoding of pdf documents separates lines with
                          cr/lf. However, by the time the tag data gets here they are converted to
                          hex 20 (space). I think this is a side effect of getSingleNode() above.
                          Anyway, I think hex 20 is unique in base64 so that if I convert them back
                          before decoding then we should come out with the same doc.
                           */
                          // TAFData = replace(TAFData, " ", "\r\n"); // too slow
                          TAFData = TAFData.replaceAll(" ", "\r\n");

                          byte buf[] = decoder.decodeBuffer(TAFData);

                          // get relative path to ini file (ini isn't available thru xmldbt)
                          ini_stmt = con.createStatement();
                          ini_rs = null;
						  log_obj.FmtAndLogMsg("RID: " + requestID + " in storeTAFPDF before read ini", i_dbg_lvl, 5);
                          if (ini == null) {  // this should not execute because ini loaded by basecontroller class
                             //163404 - GL. 4/1/2013 - if -D provided on java runtime then use its path to get the origenate.ini file
                             if (System.getProperty("origenate_ini") != null) 
                                inifilename=System.getProperty("origenate_ini");
                             // END- 163404 - GL. 4/1/2013 - if -D provided on java runtime then use its path to get the origenate.ini file
                             else {
                                log_obj.FmtAndLogMsg("WARNING: Reading origenate_ini table in TAFRs");
                                 ini_rs = ini_stmt.executeQuery("SELECT PATH_TXT FROM ORIGENATE_INI");
                                 if (!ini_rs.next()) {
                                     throw new Exception("Query did not retrieve an evaluate client id in " + getClass());
                                 }
                                 inifilename = ini_rs.getString("PATH_TXT");
                             }
                              ini = new IniFile();
                              // get taf environment vars from ini file
                              ini.readINIFile(inifilename);
        
              }    // read inifile only once
                          log_obj.FmtAndLogMsg("RID: " + requestID + " in storeTAFPDF after read ini", i_dbg_lvl, 5);
                          
                          taf_title_dir = ini.getINIVar("taf.taf_title_dir");
                          taf_title_obj = ini.getINIVar("taf.taf_title_obj");
                          taf_appraisal_dir = ini.getINIVar("taf.taf_appraisal_dir");
                          taf_appraisal_obj = ini.getINIVar("taf.taf_appraisal_obj");
                          taf_flood_dir = ini.getINIVar("taf.taf_flood_dir");
                          taf_flood_obj = ini.getINIVar("taf.taf_flood_obj");

                          int requestID = Integer.parseInt(xrequestID);

                          String xhomeEquityID = "";
                          String CollateralNoXPath = "/IFX/CreditSvcRs/LoanAppSvcRs/TAFRs/CollateralNo/text()";
                          nd = null;
                          nd = XPathAPI.selectSingleNode(nod_root, CollateralNoXPath);
                          if (nd != null && nd.getNodeValue() != null) {
                              xhomeEquityID = nd.getNodeValue();
                          }
						  log_obj.FmtAndLogMsg("RID: " + requestID + " in storeTAFPDF getting from xpath CollateralNoXPath, xhomeEquityID [" + xhomeEquityID +"]", i_dbg_lvl, 5);
                          int homeEquityID = Integer.parseInt(xhomeEquityID);

                          ini_rs = null;
                          String s_sql = "SELECT COLLATERAL_REQUEST_ID FROM CREDIT_REQUEST_HOME_EQUITY WHERE REQUEST_ID = ? AND HOME_EQUITY_ID = ?"; 
                          ini_stmt2 = con.prepareStatement(s_sql);
                          ini_stmt2.setInt(1, requestID);
                          ini_stmt2.setInt(2, homeEquityID);
                          ini_rs = ini_stmt2.executeQuery();
                          if (!ini_rs.next()) {
                              throw new Exception("Query did not retrieve a COLLATERAL_REQUEST_ID in " + getClass());
                          }
                          String xCollateralRID = ini_rs.getString("COLLATERAL_REQUEST_ID");
						  log_obj.FmtAndLogMsg("RID: " + requestID + " in storeTAFPDF qry from CREDIT_REQUEST_HOME_EQUITY for xhomeEquityID "+xhomeEquityID+", xCollateralRID [" + xCollateralRID +"]", i_dbg_lvl, 5);
                          int CollateralRID = Integer.parseInt(xCollateralRID);
                          
                          String xSEQNO = "";
                          nd = null;
                          nd = XPathAPI.selectSingleNode(nod_root, TAFSeqnoPath);
                          if (nd != null && nd.getNodeValue() != null) {
                              xSEQNO = nd.getNodeValue();
                          }
                          log_obj.FmtAndLogMsg("RID: " + requestID + " in storeTAFPDF getting from xpath TAFSeqnoPath, xSEQNO [" + xSEQNO +"]", i_dbg_lvl, 5);
                          int SEQNO = Integer.parseInt(xSEQNO);

                          ini_rs = null;
                          
                          /**
                           * OWASP TOP 10 2010 - A1 High SQL Injection
                           *  TTP 324955 Security Remediation Fortify Scan
                           */
                          /*ini_rs = ini_stmt.executeQuery("SELECT RESPSEQNO FROM " + TAF_RESP_TABLE +
                                  " WHERE REQUEST_ID = " + requestID + //1
                                  " AND COLLATERAL_REQUEST_ID =" + CollateralRID + //2
                                  " and HOME_EQUITY_ID = " + homeEquityID + //3
                                  " and SEQNO = " + SEQNO + //4
                                  " AND EVALUATOR_ID = " + evaluatorID + //5
                                  " AND RESPSEQNO = (SELECT MAX(RESPSEQNO) AS RESPSEQNO FROM " + TAF_RESP_TABLE +
                                  " WHERE REQUEST_ID = " + requestID + //6
                                  " AND COLLATERAL_REQUEST_ID =" + CollateralRID + //7
                                  " and HOME_EQUITY_ID = " + homeEquityID + //8
                                  " and SEQNO = " + SEQNO + //9
                                  " and (SUMMARY_RECORD_FLG is null OR SUMMARY_RECORD_FLG <> 1) " +
                                  " AND EVALUATOR_ID = " + evaluatorID +")");*/ //10
                          
                          String ini_sql = "SELECT RESPSEQNO FROM " + SQLSecurity.sanitize(TAF_RESP_TABLE) +
                                  " WHERE REQUEST_ID = ? " + //1
                                  " AND COLLATERAL_REQUEST_ID = ? " + //2
                                  " and HOME_EQUITY_ID = ? " +//3
                                  " and SEQNO = ? " +//4
                                  " AND EVALUATOR_ID = ? " +//5
                                  " AND RESPSEQNO = (SELECT MAX(RESPSEQNO) AS RESPSEQNO FROM " + SQLSecurity.sanitize(TAF_RESP_TABLE) + 
                                  " WHERE REQUEST_ID = ? " +//6
                                  " AND COLLATERAL_REQUEST_ID = ? " +//7
                                  " and HOME_EQUITY_ID = ? " +//8
                                  " and SEQNO = ? " +//9
                                  " and (SUMMARY_RECORD_FLG is null OR SUMMARY_RECORD_FLG <> 1) " +
                                  " AND EVALUATOR_ID = ? )";//10
                          PreparedStatement pstmt1 = con.prepareStatement(ini_sql);
                          pstmt1.setInt(1, requestID);
                          pstmt1.setInt(2, CollateralRID);
                          pstmt1.setInt(3, homeEquityID);
                          pstmt1.setInt(4, SEQNO);
                          pstmt1.setInt(5, Integer.valueOf(evaluatorID));
                          pstmt1.setInt(6, requestID);
                          pstmt1.setInt(7, CollateralRID);
                          pstmt1.setInt(8, homeEquityID);
                          pstmt1.setInt(9, SEQNO);
                          pstmt1.setInt(10, Integer.valueOf(evaluatorID));
                          ini_rs = pstmt1.executeQuery();
                          if (!ini_rs.next()) {
                              throw new Exception("Query did not retrieve a RESPSEQNO in " + getClass());
                          }
                          String xRESPSEQNO = ini_rs.getString("RESPSEQNO");
						  log_obj.FmtAndLogMsg("RID: " + requestID + " in storeTAFPDF after qry to TAF_RESP_TABLE, xRESPSEQNO [" + xRESPSEQNO +"]", i_dbg_lvl, 5);
                          int RESPSEQNO = Integer.parseInt(xRESPSEQNO);
                          
                          String xName = "";
                          nd = null;
                          nd = XPathAPI.selectSingleNode(nod_root, TAFDocNameXPath);
                          if (nd != null && nd.getNodeValue() != null) {
                              xName = nd.getNodeValue();
                          }
						  log_obj.FmtAndLogMsg("RID: " + requestID + " in storeTAFPDF getting from xpath TAFDocNameXPath, xName [" + xName +"]", i_dbg_lvl, 5);
            // back to the old way of naming files
           String fileName = xName + "_" + xrequestID + "_" + xSEQNO + "_" + xRESPSEQNO + "_" + OCCURRENCE + ".pdf";
							
                          if (TAFType.equalsIgnoreCase("TITLE")) {
                              docPath = taf_title_dir + "/" + fileName;
                              dirObjectName = taf_title_obj;
                          } else if (TAFType.equalsIgnoreCase("APPRAISAL")) {
                              docPath = taf_appraisal_dir + "/" + fileName;
                              dirObjectName = taf_appraisal_obj;
                          } else if (TAFType.equalsIgnoreCase("FLOOD")) {
                              docPath = taf_flood_dir + "/" + fileName;
                              dirObjectName = taf_flood_obj;
                          }
						  log_obj.FmtAndLogMsg("RID: " + requestID + " in storeTAFPDF fileName: [" + fileName +"], docPath: ["+docPath+"], dirObjectName: ["+dirObjectName+"]", i_dbg_lvl, 5);
         
                          // write the document to the directory and then update the database to point to it

                          writeBinaryFile(docPath, buf);
                          log_obj.FmtAndLogMsg("RID: " + requestID + " in storeTAFPDF after writeBinaryFile success", i_dbg_lvl, 5);
						  
                          sql = sql + " (request_id, collateral_request_id, home_equity_id, seqno, respseqno, occurrence, evaluator_id, received_dt, document_data, DOCUMENT_NAME_TXT, DOC_ORIGINAL_NAME_TXT, DOC_SIZE) values" +
                          "(?, ?, ?, ?, ?, ?, ?,sysdate,BFILENAME(?, ?), ?, ?, ?)";
						  log_obj.FmtAndLogMsg("RID: " + requestID + " in storeTAFPDF execute db update: " + sql, i_dbg_lvl, 5);

                          PreparedStatement ps = con.prepareStatement(sql);
                          ps.setInt(1, requestID);
                          ps.setInt(2, CollateralRID);
                          ps.setInt(3, homeEquityID);
                          ps.setInt(4, SEQNO);
                          ps.setInt(5, RESPSEQNO);
                          ps.setInt(6, OCCURRENCE);
                          ps.setInt(7, Integer.valueOf(evaluatorID));
                          ps.setString(8, dirObjectName);
                          ps.setString(9, fileName);
                          ps.setString(10, fileName);
                          ps.setString(11, xName);
                          ps.setInt(12, buf.length);
                          ResultSet rs = ps.executeQuery();
						  log_obj.FmtAndLogMsg("RID: " + requestID + " in storeTAFPDF done execute db update: " , i_dbg_lvl, 5);

                          rs.close();
                          ps.close();

                      } catch (Exception e) {
                          throwPostloadError("Failed to load TAF PDF:" + e.toString(), requestID);
						  log_obj.FmtAndLogMsg("Exception processing taf, in storeTAFPDF for iteration" + i, e);
                      }
                      finally {
                          try{ if(ini_rs != null) ini_rs.close(); }catch(Exception e1){e1.printStackTrace();}
                          try{ if(ini_stmt != null) ini_stmt.close(); }catch(Exception e1){e1.printStackTrace();}
                          try{ if(ini_stmt2 != null) ini_stmt2.close(); }catch(Exception e1){e1.printStackTrace();}
                      }
                  }

        } // for each occurrence of docs up to 10



    } // storeTAFPDF

///////////////////////////////////////////////////////////////////////////////////////
    private void writeBinaryFile(String fileName, byte[] buf) throws Exception {


        /** OWASP Top 10 2010 - A4 path manipulation
          * Change to the below code to fix vulnerabilities
          * TTP 324955
          */
        //FileOutputStream OutFile = new FileOutputStream(fileName);
        FileOutputStream OutFile = new FileOutputStream(OWASPSecurity.validationCheck(fileName, OWASPSecurity.DIRANDFILE));
        
        DataOutputStream Data = new DataOutputStream(OutFile);
        Data.write(buf, 0, buf.length);
        Data.flush();
        Data.close();


    } // writeBinaryFile

///////////////////////////////////////////////////////////////////////////////
    private String replace(String target, String removeStr, String replaceWith) {

        if (target.indexOf(removeStr) < 0) {
            return (target);
        }
        int idx = 0, removeLength = removeStr.length(), offset = 0;
        while ((idx = target.indexOf(removeStr, offset)) >= 0) {
            String prefix = "", suffix = "";
            if (idx > 0) {
                prefix = target.substring(0, idx);
            }
            if (idx + removeLength + 1 <= target.length()) {
                suffix = target.substring(idx + removeLength);
            }
            offset = prefix.length() + replaceWith.length();
            target = prefix + replaceWith + suffix;

            if (offset >= target.length()) {
                break;
            }
        } // while
        return (target);

    } // replace

///////////////////////////////////////////////////////////////////////////////
    private void throwPostloadError(String msg, String requestId) throws Exception {


        errorMsg = msg; // this is what will go back on noload notification
		deleteConcurency(requestID);
        throw new Exception(errorMsg);
    }

    private String getAuditFields(int requestId) throws Exception {
        PreparedStatement ps  = null;
        ResultSet rs = null;
        String sql = "";
        String auditFields = "";
        try {
            sql =
                    "SELECT AUDIT_ID " +
                    "FROM CREDIT_REQUEST_AUDIT " +
                    "WHERE REQUEST_ID = ? " +
                    "AND (TABLE_NAME_TXT = 'CREDIT_REQ_APPRAISAL_RESP' OR TABLE_NAME_TXT = 'CREDIT_REQ_FLOOD_RESP' OR TABLE_NAME_TXT = 'CREDIT_REQ_TITLE_RESP')";
            ps = con.prepareStatement(sql);
            ps.setInt(1, requestId);
            rs = ps.executeQuery();
            
            StringBuilder temp_builder = new StringBuilder("");

            while (rs.next()) {
                temp_builder.append(rs.getInt("AUDIT_ID"));
                temp_builder.append(",");
            }
            auditFields = temp_builder.toString();

            if (auditFields.length() > 0) {
                auditFields = auditFields.substring(0, auditFields.length() - 1);
            }
        } catch (Exception e) {
           e.printStackTrace();
        }
        finally {
            try{ if(rs != null) rs.close(); }catch(Exception e1){e1.printStackTrace();}
            try{ if(ps != null) ps.close(); }catch(Exception e1){e1.printStackTrace();}
        }
        return auditFields;
    }

    private ArrayList<String> getUpdatedAuditFields(int requestId, String auditFields) throws Exception {
        PreparedStatement ps  = null;
        ResultSet rs = null;
        String sql = "";
        ArrayList<String> updatedAuditFields = new ArrayList<String>();
        try {
            sql =
                    "SELECT TABLE_NAME_TXT, COLUMN_NAME_TXT " +
                    "FROM CREDIT_REQUEST_AUDIT " +
                    "WHERE REQUEST_ID = ? " +
                    "AND (TABLE_NAME_TXT = 'CREDIT_REQ_APPRAISAL_RESP' OR TABLE_NAME_TXT = 'CREDIT_REQ_FLOOD_RESP' OR TABLE_NAME_TXT = 'CREDIT_REQ_TITLE_RESP')" +
                    (auditFields.length() > 0 ? " AND AUDIT_ID NOT IN(" + auditFields + ")" : "");
            ps = con.prepareStatement(sql);
            ps.setInt(1, requestId);
            rs = ps.executeQuery();        

            while (rs.next()) {
                updatedAuditFields.add(rs.getString("TABLE_NAME_TXT"));
                updatedAuditFields.add(rs.getString("COLUMN_NAME_TXT"));
            }
        } catch (Exception e) {
           e.printStackTrace();
        }
        finally {
            try{ if(rs != null) rs.close(); }catch(Exception e1){e1.printStackTrace();}
            try{ if(ps != null) ps.close(); }catch(Exception e1){e1.printStackTrace();}
        }

        return updatedAuditFields;
    }

    private boolean[] checkConfigurableRedecision(int requestId, int evaluatorId, ArrayList<String> updatedAuditFields) throws Exception {
        // retVal[0] indicates whether eValuate should be called
        // retVal[1] indicates whether this app is eligible for configurable redecision
        boolean[] retVal = {true, false};
        PreparedStatement ps  = null;
        ResultSet rs = null;
        String sql = "";
        int productId = -10; //initialize to dummy value
        int decisionStatusId = -10; //initialize to dummy value
        String taskGroupId  = "";
        try {   
            sql =
                    "SELECT PRODUCT_ID, DECISION_STATUS_ID, TASK_GROUP_ID " +
                    "FROM CREDIT_REQUEST " +
                    "WHERE REQUEST_ID = ? AND EVALUATOR_ID= ?";
            ps = con.prepareStatement(sql);
            ps.setInt(1, requestId);
            ps.setInt(2, evaluatorId);
            rs = ps.executeQuery();
            rs.next();

            productId = rs.getInt("PRODUCT_ID");
            decisionStatusId = rs.getInt("DECISION_STATUS_ID");
            taskGroupId = rs.getString("TASK_GROUP_ID");

        } catch (Exception e) {
           e.printStackTrace();
        }
        finally {
            try{ if(rs != null) rs.close(); }catch(Exception e1){e1.printStackTrace();}
            try{ if(ps != null) ps.close(); }catch(Exception e1){e1.printStackTrace();}
        }

        // Configurable Redecision only applies to apps with a status of APPCOND (1), APPROVE (3)
        // or APPSCOR (102) unless the app is in contracting, in which case the status could also be PENDING (0)
        if (decisionStatusId == 1 || decisionStatusId == 3 || decisionStatusId == 102 || (taskGroupId.compareToIgnoreCase("CONTRACTADMIN") == 0 && decisionStatusId == 0)) {
            if (updatedAuditFields.size() > 0) {
                // check to see if any of the updated audit fields are Configurable Redecision
                // fields but have not been configured to be excluded
                StringBuilder temp_builder1 = new StringBuilder("SELECT UNIQUE(SCREEN_ID) FROM MSTR_REDECISION_FIELDS WHERE PRODUCT_ID = ? AND SCREEN_ID IN(6, 7, 8, 44, 45, 46) AND (");

                for (int i = 0; i < updatedAuditFields.size(); i += 2) {
                    temp_builder1.append("(DB_TABLE_NAME_TXT = ? ");
                    //temp_builder1.append(updatedAuditFields.get(i));
                    temp_builder1.append(" AND DB_COLUMN_NAME_TXT = ?)");
                    //temp_builder1.append(updatedAuditFields.get(i + 1));
                    //temp_builder1.append("')");

                    if (i < updatedAuditFields.size() - 2) {
                        temp_builder1.append(" OR ");
                    }
                }
                sql = temp_builder1.toString();

                sql = sql + ") AND FIELD_ID NOT IN(SELECT FIELD_ID FROM CONFIG_REDECISION_FIELDS WHERE PRODUCT_ID = ? AND SCREEN_ID IN(6, 7, 8, 44, 45, 46) AND EVALUATOR_ID = ?)";
                String auditScreens = "";
               try {
                   /**
                    * OWASP TOP 10 2010 - A1 High SQL Injection
                    * TTP 324955 Security Remediation Fortify Scan
                    */
                    ps = con.prepareStatement(sql);
                     //ps = con.prepareStatement(ESAPI.encoder().encodeForSQL( new OracleCodec(),sql.toString()));
                     
                    ps.setInt(1, productId);
                    int placeCt1 = 2;
                    for (int i = 0; i < updatedAuditFields.size(); i += 2) {
                        ps.setString(placeCt1++, updatedAuditFields.get(i));
                        ps.setString(placeCt1++, updatedAuditFields.get(i + 1));
                    }
                    // new stuff goes here
                    ps.setInt(placeCt1++, productId);
                    ps.setInt(placeCt1++, evaluatorId);
                    rs = ps.executeQuery();                 
                    StringBuilder temp_builder2 = new StringBuilder("");

                    while (rs.next()) {
                        temp_builder2.append(rs.getInt("SCREEN_ID"));
                        temp_builder2.append(",");
                    }
                    auditScreens = temp_builder2.toString();

                } catch (Exception e) {
                   e.printStackTrace();
                }
                finally {
                    try{ if(rs != null) rs.close(); }catch(Exception e1){e1.printStackTrace();}
                    try{ if(ps != null) ps.close(); }catch(Exception e1){e1.printStackTrace();}
                }

                if (auditScreens.length() > 0) {
                    auditScreens = auditScreens.substring(0, auditScreens.length() - 1);
                }

                if (auditScreens.length() > 0) {
                    // if an audit field that has not been configured to be excluded has changed,
                    // we need to check the screen configuration
                    int screenCount = -10; //dummy value to initialize the local variable
                    try {   
                        sql =
                                "SELECT COUNT(1) AS SCREEN_COUNT " +
                                "FROM CONFIG_REDECISION_SCREENS " +
                                "WHERE SCREEN_ID IN(" + auditScreens + ") AND PRODUCT_ID = ? AND EVALUATOR_ID = ?";
                        ps = con.prepareStatement(sql);
                        ps.setInt(1, productId);
                        ps.setInt(2, evaluatorId);
                        rs = ps.executeQuery();
                        rs.next();
                        screenCount = rs.getInt("SCREEN_COUNT");

                    } catch (Exception e) {
                       e.printStackTrace();
                    }
                    finally {
                        try{ if(rs != null) rs.close(); }catch(Exception e1){e1.printStackTrace();}
                        try{ if(ps != null) ps.close(); }catch(Exception e1){e1.printStackTrace();}
                    }

                    if (screenCount > 0) {
                        retVal[1] = true;
                    }
                } else {
                    // if the only audit fields that changed are configured to be excluded, we do
                    // not need to call eValuate
                    retVal[0] = false;
                }
            } else {
                // if none of the audit fields changed, we do not need to call eValuate
                retVal[0] = false;
            }
        }

        return retVal;
    }

    private boolean runCompletionRules() {
        boolean failedCompletionChecks = false;

        // call completion checks and tolerance rules
        String ccURL = ini.getINIVar("urls.contract_completion_check_url", "");

        if (ccURL.length() <= 0) {
            try {
                throwPostloadError("Reason: Completion check URL not defined",requestID);
            } catch (Exception e) {
            } // ignore
        }

		ccURL = ccURL + "&request_id=" + requestID + "&user_id=" + "SYSTEM" + "&evaluator_id=" + evaluator_id+ "&closeSession=true&calledfromexternal=true";
        String response = "";

        try {
			log_obj.FmtAndLogMsg("RID: " + requestID + " in runCompletionRules: call to url for completion rule check", i_dbg_lvl, 5);
            PostRequest postRequest = new PostRequest(log_obj, i_dbg_lvl);
            response = postRequest.post(ccURL, "", 0);
			log_obj.FmtAndLogMsg("RID: " + requestID + " in runCompletionRules: done call to url for completion rule check", i_dbg_lvl, 5);
        } catch (Exception e) {
            log_obj.FmtAndLogMsg("RID: " + requestID + " Failed calling completion check page: " + e.toString());
            // DON'T DELETE CONTRACT DATA
            // now send back a response to the originator listing the completion rules that failed
            errorMsg = "data errors";

            // make the first line of the completion rules that failed indicate that the data was loaded
            String compRules = " ** " + errorMsg + " ** Server error performing completion checks - logged";

            try {
				log_obj.FmtAndLogMsg("RID: " + requestID + " in runCompletionRules: send sendContractNotification", i_dbg_lvl, 5);
                sendContractNotification("LOAD", network, transID, errorMsg, "", requestID, remoteRefNum, clientAppID, evaluator_id, "TAFRs", "COMPLETION_CHECK_FAILED", compRules, "");
				log_obj.FmtAndLogMsg("RID: " + requestID + " in runCompletionRules: done sendContractNotification", i_dbg_lvl, 5);
            } catch (Exception e1) {
                // don't throw an error, not important enough, just log it
                log_obj.FmtAndLogMsg("RID: " + requestID + " Error processing Send Notification: " + e1.toString());
            }

            // update contract status to failed completion rules
            try {
                SQLUpdate.RunUpdateStatement(con, "update credit_request set trans_status_id = 6, trans_status_updated_dt = sysdate where request_id = " + requestID);
            } catch (Exception e1) {
            } // ignore

            return true; // removes it from the post queue no need to keep this transaction
		} finally {
			log_obj.FmtAndLogMsg("RID: " + requestID + " Unlocking app after eValuate call on a TAFRs load. RID="+requestID);
			try {
				SQLUpdate sqlUpd = new SQLUpdate();
				sqlUpd.SetPreparedUpdateStatement(con, "delete from concurrency_control where request_id = ?");
				sqlUpd.setInt(1, Integer.parseInt(requestID));
				sqlUpd.RunPreparedUpdateStatement();
			} 
			catch (Exception e2) {
				log_obj.FmtAndLogMsg("RID: " + requestID + " ERROR Unlocking app after eValuate call on a TAFRs `: " + e2.toString());
			}
        }

        int idx = response.indexOf("<RESPONSE");

        if (idx < 0) {
            log_obj.FmtAndLogMsg("Failed calling completion check page: response empty ");

            // DON'T DELETE CONTRACT DATA
            // now send back a response to the originator listing the completion rules that failed
            errorMsg = "data errors";

            // make the first line of the completion rules that failed indicate that the data was loaded
            String compRules = " ** " + errorMsg + " ** Completion check response empty";

            try {
                sendContractNotification("LOAD", network, transID, errorMsg, "", requestID, remoteRefNum, clientAppID, evaluator_id, "TAFRs", "COMPLETION_CHECK_FAILED", compRules, "");
            } catch (Exception e1) {
                // don't throw an error, not important enough, just log it
                log_obj.FmtAndLogMsg("Error processing Send Notification: " + e1.toString());
            }

            // update contract status to failed completion rules
            try {
                SQLUpdate.RunUpdateStatement(con, "update credit_request set trans_status_id = 6, trans_status_updated_dt = sysdate where request_id = " + requestID);
            } catch (Exception e) {
            } // ignore

            return true; // removes it from the post queue no need to keep this transaction
        } // response empty

        // PROCESS RESPONSE
        // sample
        // <RESPONSE request="7317" contractverif_complete="COMPLETE"
        //  contractverif_compl_pass="PASS" contractverif_compl_rules=""
        //  contractverif_tol_pass="PASS" contractverif_tol_rules=""
        //  contractvalid_complete="INCOMPLETE" contractvalid_compl_pass="FAIL"
        //  contractvalid_compl_rules=" ** Contract Date is missing ** Calculated Amount Financed <> Contract Amount Financed ** Number of Payments x Payment Amount <> Total of Payments" contractvalid_tol_pass="" contractvalid_tol_rules=""/>
        //log_obj.FmtAndLogMsg("completion check response: " + response, i_dbg_lvl, 5);

        String resp = response.substring(idx);
        failedCompletionChecks = (resp.indexOf("contractverif_compl_pass=\"FAIL\"") >= 0 || resp.indexOf("contractvalid_compl_pass=\"FAIL\"") >= 0);

        return failedCompletionChecks;
    }

////////////////////////////////////////////////////////////////////////////////////
    private void manageResponseSummaryRecords(String TAFType, String evaluatorID, String xrequestID) throws Exception {

        IniFile ini = null;
        String inifilename = "";
        String TAFData = "";
        String TAF_RESP_TABLE = "";
        String TAF_DOCS_TABLE = "";
        String TAFDocXPath = "";
        String TAFDocNameXPath = "";
        String TAFSeqnoPath = "";
        String docPath = "";
        String dirObjectName = "";
        boolean isSummaryRecord;
        int OCCURRENCE = 0;


          if (TAFType.equalsIgnoreCase("TITLE")) {
              TAF_RESP_TABLE = "CREDIT_REQ_TITLE_RESP";
              TAFSeqnoPath = "/IFX/CreditSvcRs/LoanAppSvcRs/Collateral/CollateralInfo/TitleResponse/Seqno/text()";
          } else if (TAFType.equalsIgnoreCase("APPRAISAL")) {
              TAF_RESP_TABLE = "CREDIT_REQ_APPRAISAL_RESP";
              TAFSeqnoPath = "/IFX/CreditSvcRs/LoanAppSvcRs/Collateral/CollateralInfo/AppraisalResponse/Seqno/text()";
          } else if (TAFType.equalsIgnoreCase("FLOOD")) {
              TAF_RESP_TABLE = "CREDIT_REQ_FLOOD_RESP";
              TAFSeqnoPath = "/IFX/CreditSvcRs/LoanAppSvcRs/Collateral/CollateralInfo/FloodResponse/Seqno/text()";
          }

          Node nd = null;
          ResultSet rs = null;
          PreparedStatement stmt = null;
          PreparedStatement stmt2 = null;
          try {

              int requestID = Integer.parseInt(xrequestID);
				
			  log_obj.FmtAndLogMsg("RID: " + requestID + " in manageResponseSummaryRecords, checking CollateralNo tag ", i_dbg_lvl, 5);
              String xhomeEquityID = "";
              String CollateralNoXPath = "/IFX/CreditSvcRs/LoanAppSvcRs/TAFRs/CollateralNo/text()";
              nd = null;
              nd = XPathAPI.selectSingleNode(nod_root, CollateralNoXPath);
              if (nd != null && nd.getNodeValue() != null) {
                  xhomeEquityID = nd.getNodeValue();
                  //log_obj.FmtAndLogMsg("homeEquityID= " + xhomeEquityID);
              }
			  log_obj.FmtAndLogMsg("RID: " + requestID + " in manageResponseSummaryRecords, CollateralNo tag value is [" + xhomeEquityID + "]", i_dbg_lvl, 5);
              int homeEquityID = Integer.parseInt(xhomeEquityID);
              
              String s_sql = "SELECT COLLATERAL_REQUEST_ID FROM CREDIT_REQUEST_HOME_EQUITY WHERE REQUEST_ID = ? AND HOME_EQUITY_ID = ?";

              stmt2 = con.prepareStatement(s_sql, ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
              stmt2.setInt(1, requestID);
              stmt2.setInt(2, homeEquityID);
              
              rs = null;
              rs = stmt2.executeQuery();
              if (!rs.next()) {
                  throw new Exception("TAFRs: Query did not retrieve a COLLATERAL_REQUEST_ID in " + getClass());
              }
              String xCollateralRID = rs.getString("COLLATERAL_REQUEST_ID");
			  log_obj.FmtAndLogMsg("RID: " + requestID + " in manageResponseSummaryRecords, queried collateral_request_id from credit_request_home_equity [" + xCollateralRID + "]", i_dbg_lvl, 5);
              int CollateralRID = Integer.parseInt(xCollateralRID);
              
              try { if (rs != null) rs.close(); } catch (Exception e) { e.printStackTrace(); }
              try { if (stmt2 != null) stmt2.close(); } catch (Exception e) { e.printStackTrace(); }
              
              String xSEQNO = "";
                      nd = null;
                      nd = XPathAPI.selectSingleNode(nod_root, TAFSeqnoPath);
                      if (nd != null && nd.getNodeValue() != null) {
                          xSEQNO = nd.getNodeValue();
              }
              log_obj.FmtAndLogMsg("RID: " + requestID + " in manageResponseSummaryRecords, get tag value for seqno for " + TAFType + "[" + xSEQNO + "]", i_dbg_lvl, 5);
              int SEQNO = Integer.parseInt(xSEQNO);

              // The following query is just to get the meta data and the max respseqno value
              rs = null;
              //stmt = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
              
              /**
               * OWASP TOP 10 2010 - A1 High SQL Injection
               *  TTP 324955 Security Remediation Fortify Scan
               */
              /*rs = stmt.executeQuery("SELECT * FROM " + TAF_RESP_TABLE + 
                      " WHERE REQUEST_ID = " + requestID + //1
                      " AND COLLATERAL_REQUEST_ID =" + CollateralRID + //2
                      " and HOME_EQUITY_ID = " + homeEquityID + //3
                      " and SEQNO = " + SEQNO + //4
                      " AND EVALUATOR_ID = " + evaluatorID + //5
                      " AND RESPSEQNO = (SELECT MAX(RESPSEQNO) AS RESPSEQNO FROM " + TAF_RESP_TABLE +
                      " WHERE REQUEST_ID = " + requestID + //6 
                      " AND COLLATERAL_REQUEST_ID =" + CollateralRID +// 7
                      " and HOME_EQUITY_ID = " + homeEquityID + //8
                      " and SEQNO = " + SEQNO + //9
                      " and RESPSEQNO < 100 " +     // For backwards compatibility with the short term solution (385 responses saved with respseqno starts at 100)
                      " AND EVALUATOR_ID = " + evaluatorID +")");*/ //10
              String sqlstr = "SELECT * FROM " + SQLSecurity.sanitize(TAF_RESP_TABLE) +
                      " WHERE REQUEST_ID = ? " + //1
                      " AND COLLATERAL_REQUEST_ID = ? " + //2
                      " and HOME_EQUITY_ID = ? " + //3
                      " and SEQNO = ? " + //4
                      " AND EVALUATOR_ID = ? " + //5
                      " AND RESPSEQNO = (SELECT MAX(RESPSEQNO) AS RESPSEQNO FROM " + SQLSecurity.sanitize(TAF_RESP_TABLE) +
                      " WHERE REQUEST_ID = ? " + //6
                      " AND COLLATERAL_REQUEST_ID = ? " + //7
                      " and HOME_EQUITY_ID = ? " + //8
                      " and SEQNO = ? " + //9
                      " and RESPSEQNO < 100 " +     // For backwards compatibility with the short term solution (385 responses saved with respseqno starts at 100)
                      " AND EVALUATOR_ID = ? )"; //10
              stmt = con.prepareStatement(sqlstr, ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
              stmt.setInt(1, requestID);
              stmt.setInt(2, CollateralRID);
              stmt.setInt(3, homeEquityID);
              stmt.setInt(4, SEQNO);
              stmt.setInt(5, Integer.valueOf(evaluatorID));
              stmt.setInt(6, requestID);
              stmt.setInt(7, CollateralRID);
              stmt.setInt(8, homeEquityID);
              stmt.setInt(9, SEQNO);
              stmt.setInt(10, Integer.valueOf(evaluatorID));
              rs = stmt.executeQuery();
              if (!rs.next()) {
                  throw new Exception("TAFRs: Query did not retrieve a RESPSEQNO in " + getClass());
              }
              
              String xRESPSEQNO = rs.getString("RESPSEQNO");
			  log_obj.FmtAndLogMsg("RID: " + requestID + " in manageResponseSummaryRecords, executed query against "+TAF_RESP_TABLE+", xRESPSEQNO" + xRESPSEQNO, i_dbg_lvl, 5);
              int RESPSEQNO = Integer.parseInt(xRESPSEQNO);
              String respSeqNoPlus1 = "" + (RESPSEQNO + 1);
              
              // Get result set meta data
              ResultSetMetaData rsmd = rs.getMetaData();
              
              String[] columnNames = new String[rsmd.getColumnCount()+1];
              Object[] newResponseValues = new Object[rsmd.getColumnCount()+1];
              Object[] summaryRecordValues = new Object[rsmd.getColumnCount()+1];
              int debugColCount = rsmd.getColumnCount();
              String columnNamesList = "";
              StringBuilder temp_builder = new StringBuilder(""); 
			  log_obj.FmtAndLogMsg("RID: " + requestID + " in manageResponseSummaryRecords, getColumnCount " + debugColCount, i_dbg_lvl, 5);
              //log_obj.FmtAndLogMsg("getColumnCount " + rsmd.getColumnCount());
              // Get the column names and values; column indices start from 1
              for (int i=1; i<columnNames.length; i++) {
                    columnNames[i] = rsmd.getColumnName(i);
                    newResponseValues[i] = rs.getObject(columnNames[i]);
                    // build a column names string to use in the next query
                    temp_builder.append(columnNames[i]);
                    if (i != columnNames.length -1){
                        temp_builder.append(", ");
                    }
              }
              columnNamesList = temp_builder.toString();
              log_obj.FmtAndLogMsg("RID: " + requestID + " in manageResponseSummaryRecords, columnNamesList " + columnNamesList, i_dbg_lvl, 5);
              try { if (rs != null) rs.close(); } catch (Exception e) { e.printStackTrace(); }
              try { if (stmt != null) stmt.close(); } catch (Exception e) { e.printStackTrace(); }
              
              // Here we run another query using the meta data so we do not have to update this code in case a new column
              // is added to the taf response tables in the future. Java does not allow updateable resultset to work with a select * query
              rs = null;
			  stmt = null;
              //stmt = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
              
              /**
               * OWASP TOP 10 2010 - A1 High SQL Injection
               *  TTP 324955 Security Remediation Fortify Scan
               */
              /*rs = stmt.executeQuery("SELECT " + columnNamesList + " FROM " + TAF_RESP_TABLE +
                      " WHERE REQUEST_ID = " + requestID + //1
                      " AND COLLATERAL_REQUEST_ID =" + CollateralRID + //2
                      " and HOME_EQUITY_ID = " + homeEquityID + //3
                      " and SEQNO = " + SEQNO + //4
                      " AND EVALUATOR_ID = " + evaluatorID + //5
                      " AND RESPSEQNO = (SELECT MAX(RESPSEQNO) AS RESPSEQNO FROM " + TAF_RESP_TABLE +
                      " WHERE REQUEST_ID = " + requestID + //6
                      " AND COLLATERAL_REQUEST_ID =" + CollateralRID + //7
                      " and HOME_EQUITY_ID = " + homeEquityID + //8
                      " and SEQNO = " + SEQNO + //9
                      " and RESPSEQNO < 100 " +     // For backwards compatibility with the short term solution (385 responses saved with respseqno starts at 100)
                      " AND EVALUATOR_ID = " + evaluatorID +")");*/ //10
              // don't need to sanitize columnNamesList because it was built using rsmd.getColumnName()
              log_obj.FmtAndLogMsg("RID: " + requestID + " in manageResponseSummaryRecords, sqlstr creating ", i_dbg_lvl, 5);
              sqlstr =  "SELECT " + columnNamesList + " FROM " + SQLSecurity.sanitize(TAF_RESP_TABLE) + 
                      " WHERE REQUEST_ID = ? " + //1
                      " AND COLLATERAL_REQUEST_ID = ? " + //2
                      " and HOME_EQUITY_ID = ? " + //3
                      " and SEQNO = ? " + //4
                      " AND EVALUATOR_ID = ? " + //5
                      " AND RESPSEQNO = (SELECT MAX(RESPSEQNO) AS RESPSEQNO FROM " + SQLSecurity.sanitize(TAF_RESP_TABLE) +
                      " WHERE REQUEST_ID = ? " + //6
                      " AND COLLATERAL_REQUEST_ID = ? " + //7
                      " and HOME_EQUITY_ID =  ? " + //8
                      " and SEQNO =  ? " + //9
                      " and RESPSEQNO < 100 " +     // For backwards compatibility with the short term solution (385 responses saved with respseqno starts at 100)
                      " AND EVALUATOR_ID = ? )"; //10
              log_obj.FmtAndLogMsg("RID: " + requestID + " in manageResponseSummaryRecords, sqlstr is : [" + sqlstr +"]", i_dbg_lvl, 5);
              stmt = con.prepareStatement(sqlstr, ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
              stmt.setInt(1, requestID);
              stmt.setInt(2, CollateralRID);
              stmt.setInt(3, homeEquityID);
              stmt.setInt(4, SEQNO);
              stmt.setInt(5, Integer.valueOf(evaluatorID));
              stmt.setInt(6, requestID);
              stmt.setInt(7, CollateralRID);
              stmt.setInt(8, homeEquityID);
              stmt.setInt(9, SEQNO);
              stmt.setInt(10, Integer.valueOf(evaluatorID));
			  log_obj.FmtAndLogMsg("RID: " + requestID + " in manageResponseSummaryRecords, sqlstr set all bind variables", i_dbg_lvl, 5);
              rs = stmt.executeQuery();
			  log_obj.FmtAndLogMsg("RID: " + requestID + " in manageResponseSummaryRecords, rs execute qry", i_dbg_lvl, 5);
              
              if (!rs.next()) {
                  log_obj.FmtAndLogMsg("RID: " + requestID + " in manageResponseSummaryRecords, rs execute qry", i_dbg_lvl, 5);
                  throw new Exception("TAFRs: Query did not retrieve a RESPSEQNO in COLLATERAL_REQUEST_ID " + getClass());
              }
		    log_obj.FmtAndLogMsg("RID: " + requestID + " in manageResponseSummaryRecords, queried against " + TAF_RESP_TABLE + " ", i_dbg_lvl, 5);
            DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.ms");
            Date date = new Date();

            if (RESPSEQNO == 1){
                  log_obj.FmtAndLogMsg("RID: " + requestID + " in manageResponseSummaryRecords, RESPSEQNO is 1 ...execute if block begin", i_dbg_lvl, 5);
                  rs.moveToInsertRow();
                  for (int i=1; i<columnNames.length; i++) {
                      if (columnNames[i].compareToIgnoreCase("RESPSEQNO") == 0){
                          rs.updateString("RESPSEQNO", respSeqNoPlus1);
                      } else if (columnNames[i].compareToIgnoreCase("RESPONSE_DT") == 0){
                          rs.updateString("RESPONSE_DT", dateFormat.format(date));
                      } else if (columnNames[i].compareToIgnoreCase("SUMMARY_RECORD_FLG") == 0){
                          rs.updateString("SUMMARY_RECORD_FLG", "1");
                      } else {
                          rs.updateObject(columnNames[i], newResponseValues[i]);
                      }
                  }
                  
                  rs.insertRow();
                  isSummaryRecord = false;
				  log_obj.FmtAndLogMsg("RID: " + requestID + " in manageResponseSummaryRecords, RESPSEQNO is 1 ...execute if block done", i_dbg_lvl, 5);
            } else {
				log_obj.FmtAndLogMsg("RID: " + requestID + " in manageResponseSummaryRecords, RESPSEQNO is not 1  ...execute else block begin", i_dbg_lvl, 5);
                //close above stmt and rs prior to re initializing them for the next query
                try { if (rs != null) rs.close(); } catch (Exception e) { e.printStackTrace(); }
                try { if (stmt != null) stmt.close(); } catch (Exception e) { e.printStackTrace(); }
                  // Query to get the latest summary record
                  rs = null;
				  stmt = null;
                  //stmt = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
                
                /**
                   * OWASP TOP 10 2010 - A1 High SQL Injection
                   *  TTP 324955 Security Remediation Fortify Scan
                   */
                  /*rs = stmt.executeQuery("SELECT " + columnNamesList + " FROM " + TAF_RESP_TABLE +
                          " WHERE REQUEST_ID = " + requestID + //1
                          " AND COLLATERAL_REQUEST_ID =" + CollateralRID +//2
                          " and HOME_EQUITY_ID = " + homeEquityID +//3
                          " and SEQNO = " + SEQNO +//4
                          " AND EVALUATOR_ID = " + evaluatorID +//5
                          " AND RESPSEQNO = (SELECT MAX(RESPSEQNO) AS RESPSEQNO FROM " + TAF_RESP_TABLE +
                          " WHERE REQUEST_ID = " + requestID +//6
                          " AND COLLATERAL_REQUEST_ID =" + CollateralRID +//7
                          " and HOME_EQUITY_ID = " + homeEquityID + //8
                          " and SEQNO = " + SEQNO + //9
                          " and SUMMARY_RECORD_FLG = 1" +
                          " AND EVALUATOR_ID = " + evaluatorID +")");*/ //10

                  sqlstr = "SELECT " + columnNamesList + " FROM " + SQLSecurity.sanitize(TAF_RESP_TABLE) +
                          " WHERE REQUEST_ID = ? " + //1
                          " AND COLLATERAL_REQUEST_ID = ? " + //2
                          " and HOME_EQUITY_ID = ? " + //3
                          " and SEQNO = ? " + //4
                          " AND EVALUATOR_ID = ? " + //5
                          " AND RESPSEQNO = (SELECT MAX(RESPSEQNO) AS RESPSEQNO FROM " + SQLSecurity.sanitize(TAF_RESP_TABLE) +
                          " WHERE REQUEST_ID = ? " +//6
                          " AND COLLATERAL_REQUEST_ID = ? " +//7
                          " and HOME_EQUITY_ID = ? " +//8
                          " and SEQNO = ? " +//9
                          " and SUMMARY_RECORD_FLG = 1" +
                          " AND EVALUATOR_ID = ? )"; //10
                  stmt = con.prepareStatement(sqlstr, ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
                  stmt.setInt(1, requestID);
                  stmt.setInt(2, CollateralRID);
                  stmt.setInt(3, homeEquityID);
                  stmt.setInt(4, SEQNO);
                  stmt.setInt(5, Integer.valueOf(evaluatorID));
                  stmt.setInt(6, requestID);
                  stmt.setInt(7, CollateralRID);
                  stmt.setInt(8, homeEquityID);
                  stmt.setInt(9, SEQNO);
                  stmt.setInt(10, Integer.valueOf(evaluatorID));
                  rs = stmt.executeQuery();
				  log_obj.FmtAndLogMsg("RID: " + requestID + " in manageResponseSummaryRecords, RESPSEQNO is not 1  ...execute else block ran query against [" + TAF_RESP_TABLE+ "]", i_dbg_lvl, 5);
                  if (!rs.next()) { //Old apps with responses and no summary record
                      rs.moveToInsertRow();
                      for (int i=1; i<columnNames.length; i++) {
                          if (columnNames[i].compareToIgnoreCase("RESPSEQNO") == 0){
                              rs.updateString("RESPSEQNO", respSeqNoPlus1);
                          } else if (columnNames[i].compareToIgnoreCase("RESPONSE_DT") == 0){
                              rs.updateString("RESPONSE_DT", dateFormat.format(date));
                          } else if (columnNames[i].compareToIgnoreCase("SUMMARY_RECORD_FLG") == 0){
                              rs.updateString("SUMMARY_RECORD_FLG", "1");
                          } else {
                              rs.updateObject(columnNames[i], newResponseValues[i]);
                          }
                      }
                      rs.insertRow();
					  log_obj.FmtAndLogMsg("RID: " + requestID + " in manageResponseSummaryRecords, RESPSEQNO is not 1  ...execute else done", i_dbg_lvl, 5);
                      try { if (rs != null) rs.close(); } catch (Exception e) { e.printStackTrace(); }
                      try { if (stmt != null) stmt.close(); } catch (Exception e) { e.printStackTrace(); }
                      return;
                  }
				  log_obj.FmtAndLogMsg("RID: " + requestID + " in manageResponseSummaryRecords, moving on to iterating through column names array", i_dbg_lvl, 5);
                  for (int i=1; i<columnNames.length; i++) {
                      summaryRecordValues[i] = rs.getObject(columnNames[i]);
                  }

                  String userEntered = rs.getString("USER_ENTERED_FLG");
                  String summaryRecord = rs.getString("SUMMARY_RECORD_FLG");
                  log_obj.FmtAndLogMsg("RID: " + requestID + " in manageResponseSummaryRecords, userEntered (flag): [" +userEntered+ "] and summaryRecord (flag): [" + summaryRecord + "]", i_dbg_lvl, 5);

                  if ((userEntered != null && Integer.parseInt(userEntered) == 1) && (summaryRecord != null && Integer.parseInt(summaryRecord) == 1)){
                      rs.moveToInsertRow();

                      for (int i=1; i<columnNames.length; i++) {
                          //log_obj.FmtAndLogMsg("i: " + i + "\t columnName: " + columnNames[i] + "\t newResponseValue: " + newResponseValues[i]);
						  log_obj.FmtAndLogMsg("RID: " + requestID + " in manageResponseSummaryRecords, updating values columnName : [" +columnNames[i]+ "]", i_dbg_lvl, 5);
                          if (columnNames[i].compareToIgnoreCase("RESPSEQNO") == 0){
                              rs.updateString("RESPSEQNO", respSeqNoPlus1);
                          } else if (columnNames[i].compareToIgnoreCase("RESPONSE_DT") == 0){
                              rs.updateString("RESPONSE_DT", dateFormat.format(date));
                          } else if (columnNames[i].compareToIgnoreCase("USER_ENTERED_FLG") == 0){
                              rs.updateString("USER_ENTERED_FLG", "0");
                          } else if (columnNames[i].compareToIgnoreCase("SUMMARY_RECORD_FLG") == 0){
                              rs.updateString("SUMMARY_RECORD_FLG", "1");
                          } else if (columnNames[i].compareToIgnoreCase("REVIEW_STATUS_ID") == 0){
                              continue;
                          } else {
                              if (newResponseValues[i] != null) {
                                  log_obj.FmtAndLogMsg("RID: " + requestID + " in manageResponseSummaryRecords, updating values newResponseValues : [" + newResponseValues[i] + "]", i_dbg_lvl, 5);
                                  rs.updateObject(columnNames[i], newResponseValues[i]);
                              } else {
                                  log_obj.FmtAndLogMsg("RID: " + requestID + " in manageResponseSummaryRecords, updating values summaryRecordValues : [" + summaryRecordValues[i] + "]", i_dbg_lvl, 5);
                                  rs.updateObject(columnNames[i], summaryRecordValues[i]);
                              }
                          }
                      }
                      rs.insertRow();
					  log_obj.FmtAndLogMsg("RID: " + requestID + " in manageResponseSummaryRecords, done inserting record ", i_dbg_lvl, 5);
                  } else {  //Electronic Summary record
                      for (int i=1; i<columnNames.length; i++) {
                          //log_obj.FmtAndLogMsg("i: " + i + "\t columnName: " + columnNames[i] + "\t newResponseValue: " + newResponseValues[i]);
						  log_obj.FmtAndLogMsg("RID: " + requestID + " in manageResponseSummaryRecords, updating values columnName: [" +columnNames[i]+ "]", i_dbg_lvl, 5);
                          if (columnNames[i].compareToIgnoreCase("RESPONSE_DT") == 0){
                              rs.updateString("RESPONSE_DT", dateFormat.format(date));
                          } else {
                              if (newResponseValues[i] != null && columnNames[i].compareToIgnoreCase("RESPSEQNO") != 0) {
                                  log_obj.FmtAndLogMsg("RID: " + requestID + " in manageResponseSummaryRecords, updating values newResponseValues: [" + newResponseValues[i] + "]", i_dbg_lvl, 5);
                                  rs.updateObject(columnNames[i], newResponseValues[i]);
                              } else {
                                  log_obj.FmtAndLogMsg("RID: " + requestID + " in manageResponseSummaryRecords, updating values summaryRecordValues : [" + summaryRecordValues[i] + "]", i_dbg_lvl, 5);
                                  rs.updateObject(columnNames[i], summaryRecordValues[i]);
                              }
                          }
                      }

                      rs.updateRow();
					  log_obj.FmtAndLogMsg("RID: " + requestID + " in manageResponseSummaryRecords, done updating record ", i_dbg_lvl, 5);
                  }
                  isSummaryRecord=true;
              }
              log_obj.FmtAndLogMsg("RID: " + requestID + " before duplicateChildRecordsResponse, passing values: isSummaryRecord:" + isSummaryRecord + ", evaluatorID:"+ evaluatorID + ", requestID:"+requestID+", homeEquityID:" + homeEquityID + ", CollateralRID:"+ CollateralRID +", SEQNO:"+SEQNO+", RESPSEQNO:" + RESPSEQNO + ", TAF_RESP_TABLE:" + TAF_RESP_TABLE +".", i_dbg_lvl, 5);
              duplicateChildRecordsResponse(isSummaryRecord, evaluatorID, requestID, homeEquityID, CollateralRID, SEQNO, RESPSEQNO, TAF_RESP_TABLE);
              log_obj.FmtAndLogMsg("RID: " + requestID + " after duplicateChildRecordsResponse", i_dbg_lvl, 5);  
              } catch (Exception e) {
                  throwPostloadError("TAFRs: Failed to insert response summary record:" + stack2string(e),requestID);
				  log_obj.FmtAndLogMsg("Exception processing taf in manageResponseSummaryRecords", e);
              }
              finally {
                    try { if (rs != null) rs.close(); } catch (Exception e) { e.printStackTrace(); }
                    try { if (stmt != null) stmt.close(); } catch (Exception e) { e.printStackTrace(); }
                    try { if (stmt2 != null) stmt2.close(); } catch (Exception e) { e.printStackTrace(); }
              }
              
        try { if (rs != null) rs.close(); } catch (Exception e) { e.printStackTrace(); }
        try { if (stmt != null) stmt.close(); } catch (Exception e) { e.printStackTrace(); }
        try { if (stmt2 != null) stmt2.close(); } catch (Exception e) { e.printStackTrace(); }

    } // manageResponseSummaryRecords

    // checkConfigSequence will see if there is a configured order taf responses should be loaded
    // if there is, it will check to see that all prerequisites are satisfied and return a TRUE
    // this tafrs can load; otherwise it will return a FALSE...do not load this transaction
    private boolean checkConfigSequence(int request_id, int evaluator_id, String taftype) throws Exception {
        boolean b_check = true;
        Query seqQuery = new Query(con);
        String providerXPath = "";
        String responseXPath = "";
        String provider_id = "";
        String response_status = "";
        
        
         if (taftype.equals("T")) {
             providerXPath = "/IFX/CreditSvcRs/LoanAppSvcRs/Collateral/CollateralInfo/TitleResponse/Provider/text()";
             responseXPath = "/IFX/CreditSvcRs/LoanAppSvcRs/Collateral/CollateralInfo/TitleResponse/ResponseStatus/text()";
         } else if (taftype.equals("F")) {
             providerXPath = "/IFX/CreditSvcRs/LoanAppSvcRs/Collateral/CollateralInfo/FloodResponse/Provider/text()";
             responseXPath = "/IFX/CreditSvcRs/LoanAppSvcRs/Collateral/CollateralInfo/FloodResponse/ResponseStatus/text()";
         } else if (taftype.equals("A")) {
             providerXPath = "/IFX/CreditSvcRs/LoanAppSvcRs/Collateral/CollateralInfo/AppraisalResponse/Provider/text()";
             responseXPath = "/IFX/CreditSvcRs/LoanAppSvcRs/Collateral/CollateralInfo/AppraisalResponse/ResponseStatus/text()";
         } else
             throw new Exception("TAFRs: checkConfigSequence: TAF type = "+taftype+", is not valid.");
         
         Node nd = null;
         nd = XPathAPI.selectSingleNode(nod_root, providerXPath);
         if (nd != null && nd.getNodeValue() != null) {
             provider_id = nd.getNodeValue();
             
             // this was pulled from tafresponsestatus conversion object...i assume it's relevant
             if(provider_id.contains("'")){
                 provider_id = provider_id.substring(1, provider_id.length()-1);
            }
         } 
        
        try { 
            // check for provider modeled after conversion object tafprovider
            seqQuery.prepareStatement("SELECT taf_provider_id FROM mstr_taf_provider WHERE Upper(provider_name_txt) = ? OR To_Char(taf_provider_id) = ?");
            seqQuery.setString(1, provider_id.toUpperCase());
            seqQuery.setString(2, provider_id.toUpperCase());
            seqQuery.executePreparedQuery();
            
            if(seqQuery.next()) {
                provider_id = seqQuery.getColValue("taf_provider_id","");
            }
            else
                throw new Exception("provider = "+provider_id+", not found in table mstr_taf_provider.");
        }
        catch (Exception e) {
            throw new Exception("TAFRs: checkConfigSequence: could not determine taf_provider_id: " + e);
        }
        
        // response status could be null, so do not error if there is no value
        nd = null;
        nd = XPathAPI.selectSingleNode(nod_root, responseXPath);
        if (nd != null && nd.getNodeValue() != null) {
            response_status = nd.getNodeValue();
        }
        
        log_obj.FmtAndLogMsg("TAFRs: checkConfigSequence: request_id = "+request_id+", taf_provider_id = "+provider_id+", response_status_code_txt = "+response_status+", evaluator_id = "+evaluator_id);
        
        // get this transaction's response code so we can check for it in the configured sequence
        seqQuery.prepareStatement("SELECT response_status_code_txt FROM CONFIG_TAF_RESPONSE_STATUS WHERE evaluator_id = ? AND (UPPER(RESPONSE_STATUS_CODE_DESC_TXT) = ? OR UPPER(RESPONSE_STATUS_CODE_TXT) = ?) AND TAF_PROVIDER_ID = ?");
        seqQuery.setInt(1, evaluator_id);
        seqQuery.setString(2, response_status);
        seqQuery.setString(3, response_status);
        seqQuery.setString(4, provider_id);
        seqQuery.executePreparedQuery();
    
        if (seqQuery.next()) {
            
            // if there is a sequence defined, then read it and do checks for required responses; otherwise just load as normal
            seqQuery.prepareStatement("SELECT mtprs.response_code_txt, ctrs.order_precedence_num "+ 
                                      "FROM CONFIG_TAF_RESP_SEQ ctrs, MSTR_TAF_PROVIDER_RESP_STATUS mtprs "+ 
                                      "WHERE ctrs.evaluator_id = ? " +
                                      "AND ctrs.taf_provider_id = ? "+ 
                                      "AND ctrs.taf_type_txt = ? "+
                                      "AND mtprs.taf_response_id = ctrs.taf_response_id "+
                                      "AND mtprs.taf_type_txt = ctrs.taf_type_txt "+
                                      "AND mtprs.taf_provider_id = ctrs.taf_provider_id "+
                                      "AND ctrs.order_precedence_num < "+
                                      "        (SELECT nvl(ctrs2.order_precedence_num,0) "+
                                      "         FROM CONFIG_TAF_RESP_SEQ ctrs2, MSTR_TAF_PROVIDER_RESP_STATUS mtprs2 "+
                                      "         WHERE ctrs2.taf_provider_id = ? "+ 
                                      "         AND ctrs2.taf_type_txt = ? "+
                                      "         AND ctrs2.taf_response_id = mtprs2.taf_response_id "+
                                      "         AND mtprs2.taf_type_txt = ctrs2.taf_type_txt "+
                                      "         AND mtprs2.taf_provider_id = ctrs2.taf_provider_id "+
                                      "         AND mtprs2.response_code_txt = ?)");
            
            seqQuery.setInt(1, evaluator_id);
            seqQuery.setString(2, provider_id);
            seqQuery.setString(3, taftype);
            seqQuery.setString(4, provider_id);
            seqQuery.setString(5, taftype);
            seqQuery.setString(6, response_status);
            seqQuery.executePreparedQuery();
            
            int i = 0;
            int home_equity_id = 0;
            int collateral_request_id = 0;
            Query query = new Query(con);
            
            // if there are prerequisites, check the appropriate response table to see if they are satisfied 
            while (seqQuery.next()) {
                // if this is the first time through, get key values for use in the response checking sql
                if (i == 0) {
                    try {
                        nd = null;
                        nd = XPathAPI.selectSingleNode(nod_root, "/IFX/CreditSvcRs/LoanAppSvcRs/TAFRs/CollateralNo/text()");
                        if (nd != null && nd.getNodeValue() != null) {
                            home_equity_id = Integer.parseInt(nd.getNodeValue());
                        }
                    }
                    catch (Exception e) {
                        log_obj.FmtAndLogMsg("TAFRs: checkConfigSequence: could not determine home_equity_id from xpath = /IFX/CreditSvcRs/LoanAppSvcRs/TAFRs/CollateralNo/text(): " + e);
                        home_equity_id = 0;
                    }
                    
                    try {
                        query.prepareStatement("SELECT collateral_request_id FROM credit_request_home_equity WHERE request_id = ? AND home_equity_id = ?");
                        query.setInt(1, request_id);
                        query.setInt(2, home_equity_id);
                        query.executePreparedQuery();
                        
                        if (query.next()) {
                            collateral_request_id = Integer.parseInt(query.getColValue("collateral_request_id","0"));
                        }
                    }
                    catch (Exception e) {
                        log_obj.FmtAndLogMsg("TAFRs: checkConfigSequence: could not determine collateral_request_id using home_equity_id = "+home_equity_id+", request_id = "+request_id+": " + e);
                        collateral_request_id = 0;
                    }
                }
                // done getting keys (only done once)
                i++;
                
                // i bother doing this check each time so i can use bind vars and not use metadata (table name) in a var
                if (taftype.equals("T")) {
                    query.prepareStatement("SELECT 1 FROM credit_req_title_resp WHERE request_id = ? AND home_equity_id = ? AND collateral_request_id = ? AND response_status_code_txt = ?");
                } else if (taftype.equals("F")) {
                    query.prepareStatement("SELECT 1 FROM credit_req_flood_resp WHERE request_id = ? AND home_equity_id = ? AND collateral_request_id = ? AND response_status_code_txt = ?");
                } else if (taftype.equals("A")) {
                    query.prepareStatement("SELECT 1 FROM credit_req_appraisal_resp WHERE request_id = ? AND home_equity_id = ? AND collateral_request_id = ? AND response_status_code_txt = ?");
                }
                
                query.setInt(1, request_id);
                query.setInt(2, home_equity_id);
                query.setInt(3, collateral_request_id);
                query.setString(4, seqQuery.getColValue("response_code_txt","thistafresponsewontbefound"));
                query.executePreparedQuery();
                
                // if this prerequisite cannot be found, break out of loop because we cannot continue
                if (!query.next()) {
                    b_check = false;
                    break;
                }   
            } //while loop
            
            return b_check;
        }
        else {
            log_obj.FmtAndLogMsg("TAFRs: checkConfigSequence: could not find a config_taf_response_status row, so TAF sequence checking stopped.");
            return b_check;
        }
            
    }
    
    private void duplicateChildRecordsResponse(boolean isSummaryRecord,String evaluatorID, int requestID, int homeEquityID, int CollateralRID, int SEQNO, int RESPSEQNO, String TAF_RESP_TABLE) throws Exception {

        if (TAF_RESP_TABLE.equalsIgnoreCase("CREDIT_REQ_TITLE_RESP") || TAF_RESP_TABLE.equalsIgnoreCase("CREDIT_REQ_APPRAISAL_RESP")) {
			
            String newRespSeqNo = "1";
            if (isSummaryRecord){ //Get the latest summary record respseqno
                  PreparedStatement summaryStmt = null;
                  ResultSet summaryRs = null;
                  try {
                      //summaryStmt = con.createStatement();
                      //ResultSet summaryRs = null;

                      // Get the latest summary record respseqno
                      
                       /**
                        * OWASP TOP 10 2010 - A1 High SQL Injection
                        *  TTP 324955 Security Remediation Fortify Scan
                        */
                       /*summaryRs = summaryStmt.executeQuery("SELECT MAX(RESPSEQNO) AS RESPSEQNO FROM " + TAF_RESP_TABLE +
                              " WHERE REQUEST_ID = " + requestID +
                              " AND COLLATERAL_REQUEST_ID =" + CollateralRID +
                              " and HOME_EQUITY_ID = " + homeEquityID +
                              " and SEQNO = " + SEQNO +
                              " and SUMMARY_RECORD_FLG = 1" +
                              " AND EVALUATOR_ID = " + evaluatorID );*/
                       /*summaryRs = summaryStmt.executeQuery(ESAPI.encoder().encodeForSQL( new OracleCodec(),"SELECT MAX(RESPSEQNO) AS RESPSEQNO FROM " + TAF_RESP_TABLE +
                              " WHERE REQUEST_ID = " + requestID +
                              " AND COLLATERAL_REQUEST_ID =" + CollateralRID +
                              " and HOME_EQUITY_ID = " + homeEquityID +
                              " and SEQNO = " + SEQNO +
                              " and SUMMARY_RECORD_FLG = 1" +
                              " AND EVALUATOR_ID = " + evaluatorID ));*/
                      String summarySQL = "SELECT MAX(RESPSEQNO) AS RESPSEQNO FROM " + TAF_RESP_TABLE +
                              " WHERE REQUEST_ID = ? " +
                              " AND COLLATERAL_REQUEST_ID = ? " +
                              " and HOME_EQUITY_ID = ? " +
                              " and SEQNO = ? " +
                              " and SUMMARY_RECORD_FLG = 1" +
                              " AND EVALUATOR_ID = ?";
                      summaryStmt = con.prepareStatement(summarySQL);
                      summaryStmt.setInt(1, requestID);
                      summaryStmt.setInt(2, CollateralRID);
                      summaryStmt.setInt(3, homeEquityID);
                      summaryStmt.setInt(4, SEQNO);
                      summaryStmt.setInt(5, Integer.valueOf(evaluatorID));
                      summaryRs = summaryStmt.executeQuery();
                      if (!summaryRs.next()) {
                          throw new Exception("TAFRs: Query did not retrieve a Summary RESPSEQNO in " + getClass());
                      }
                      newRespSeqNo = summaryRs.getString("RESPSEQNO");
					  log_obj.FmtAndLogMsg("RID: " + requestID + " in duplicateChildRecordsResponse (isSummaryRecord) newRespSeqNo:[" +newRespSeqNo+"]", i_dbg_lvl, 5);  
                      //log_obj.FmtAndLogMsg("Summary record RESPSEQNO= " + newRespSeqNo);

                      summaryRs.close();
                      summaryStmt.close();

                    } catch (Exception e) {
                        throwPostloadError("TAFRs: Failed to insert response child record:" + stack2string(e),Integer.toString(requestID));
                    }
                    finally {
                        try { if (summaryRs != null) summaryRs.close();} catch (Exception e1) {e1.printStackTrace();}
                        try { if (summaryStmt != null) summaryStmt.close();} catch (Exception e1) {e1.printStackTrace();}
                    }


            } else {
                newRespSeqNo = "" + (RESPSEQNO + 1);
            }
            int OCCURRENCE = 1;

            ArrayList<String> childTableName = new ArrayList<String>();

            if (TAF_RESP_TABLE.equalsIgnoreCase("CREDIT_REQ_TITLE_RESP")){
                childTableName.add("CREDIT_REQ_TITLE_DEED");
                childTableName.add("CREDIT_REQ_TITLE_MANNER");
                childTableName.add("CREDIT_REQ_TITLE_PARCEL");
                childTableName.add("CREDIT_REQ_TITLE_PHRASE");
            } else {
                childTableName.add("CREDIT_REQ_APPRAISAL_COMP");
            }

            for(String RESP_CHILD_TABLE : childTableName){
				log_obj.FmtAndLogMsg("RID: " + requestID + " in duplicateChildRecordsResponse for each RESP_CHILD_TABLE:[" +RESP_CHILD_TABLE+"]", i_dbg_lvl, 5);
                PreparedStatement stmt = null;
                ResultSet rs = null;
                ResultSet rs1 = null;
                PreparedStatement stmt1 = null;
                try {

                      //stmt = con.createStatement();
                      //ResultSet rs = null;

                      // The following query is just to get the meta data
                     
                      /**
                       * OWASP TOP 10 2010 - A1 High SQL Injection
                       *  TTP 324955 Security Remediation Fortify Scan
                       */
                      /*rs = stmt.executeQuery("SELECT * FROM " + RESP_CHILD_TABLE +
                              " WHERE REQUEST_ID = " + requestID + //1
                              " AND COLLATERAL_REQUEST_ID =" + CollateralRID + //2
                              " and HOME_EQUITY_ID = " + homeEquityID + //3
                              " and SEQNO = " + SEQNO + //4
                              " AND EVALUATOR_ID = " + evaluatorID + //5
                              " AND RESPSEQNO = " + RESPSEQNO);*/ //6

                      String sqlstr1 = "SELECT * FROM " + SQLSecurity.sanitize(RESP_CHILD_TABLE) +
                              " WHERE REQUEST_ID = ? " + //1
                              " AND COLLATERAL_REQUEST_ID = ? " + //2
                              " and HOME_EQUITY_ID = ? " + //3
                              " and SEQNO = ? " + //4
                              " AND EVALUATOR_ID = ? " + //5
                              " AND RESPSEQNO = ? "; //6
                      stmt = con.prepareStatement(sqlstr1);
                      stmt.setInt(1, requestID); 
                      stmt.setInt(2, CollateralRID);
                      stmt.setInt(3, homeEquityID);
                      stmt.setInt(4, SEQNO);
                      stmt.setInt(5, Integer.valueOf(evaluatorID));
                      stmt.setInt(6, RESPSEQNO);
                      rs = stmt.executeQuery();
                      boolean isFirstRun = true;
                      // move out of the while loop for the sake of efficiency
                      String s_sql = "Delete from " + SQLSecurity.sanitize(RESP_CHILD_TABLE) +
                                                    " WHERE REQUEST_ID = ?" +
                                                    " AND COLLATERAL_REQUEST_ID = ?" +
                                                    " and HOME_EQUITY_ID = ?" +
                                                    " and SEQNO = ?" +
                                                    " AND RESPSEQNO = ?" +
                                                    " AND EVALUATOR_ID = ?";
                      PreparedStatement summaryDeleteStmt = null;
                      summaryDeleteStmt = con.prepareStatement(s_sql);
                      while (rs.next()) {
                          try{
							log_obj.FmtAndLogMsg("RID: " + requestID + " in duplicateChildRecordsResponse Begin RESP_CHILD_TABLE= " + RESP_CHILD_TABLE + " OCCURRENCE= " + OCCURRENCE, i_dbg_lvl, 5);
                          if (isSummaryRecord && isFirstRun){
                              //Delete Summary old child records
                              
                              try {
                                  summaryDeleteStmt.setInt(1, requestID);
                                  summaryDeleteStmt.setInt(2, CollateralRID);
                                  summaryDeleteStmt.setInt(3, homeEquityID);
                                  summaryDeleteStmt.setInt(4, SEQNO);
                                  summaryDeleteStmt.setInt(5, Integer.valueOf(newRespSeqNo));
                                  summaryDeleteStmt.setInt(6, Integer.valueOf(evaluatorID));
                                  
                                  summaryDeleteStmt.execute();

                                  summaryDeleteStmt.close();

                                } catch (Exception e) {
                                    throwPostloadError("TAFRs: Failed to delete summary child record:" + stack2string(e),Integer.toString(requestID));
									log_obj.FmtAndLogMsg("Exception processing taf, durring duplicateChildRecordsResponse TAFRs: Failed to delete summary child record", e);
                                }
                                finally {
                                   try { if (summaryDeleteStmt != null) summaryDeleteStmt.close();} catch (Exception e1) {e1.printStackTrace();}
                                }
                                isFirstRun =  false;
                          }

                          // Get result set meta data
                          ResultSetMetaData rsmd = rs.getMetaData();

                          String[] columnNames = new String[rsmd.getColumnCount()+1];
                          Object[] newResponseValues = new Object[rsmd.getColumnCount()+1];
						  int debugColCount1 = rsmd.getColumnCount();

                          String columnNamesList = "";
                          StringBuilder temp_builder = new StringBuilder(columnNamesList);
                          
                          log_obj.FmtAndLogMsg("RID: " + requestID + " in duplicateChildRecordsResponse getColumnCount " + debugColCount1, i_dbg_lvl, 5);

                          // Get the column names and values; column indices start from 1
                          for (int i=1; i<columnNames.length; i++) {
                              columnNames[i] = rsmd.getColumnName(i);
                              newResponseValues[i] = rs.getObject(columnNames[i]);
                              // build a column names string to use in the next query
                              temp_builder.append(columnNames[i]);
                              if (i != columnNames.length -1){
                                  temp_builder.append(", ");
                              }
                          }
                          columnNamesList = temp_builder.toString();
                          log_obj.FmtAndLogMsg("RID: " + requestID + " in duplicateChildRecordsResponse columnNamesList " + columnNamesList, i_dbg_lvl, 5);
                          //stmt1 = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
                          //ResultSet rs1 = null;
                          // Here we run another query using the meta data so we do not have to update this code in case a new column
                          // is added to the taf response child tables in the future. Java does not allow updateable resultset to work with a select * query
                         
                          /**
                           * OWASP TOP 10 2010 - A1 High SQL Injection
                           *  TTP 324955 Security Remediation Fortify Scan
                           */
                          /*rs1 = stmt1.executeQuery("SELECT " + columnNamesList + " FROM " + RESP_CHILD_TABLE +
                                  " WHERE REQUEST_ID = " + requestID +  //1
                                  " AND COLLATERAL_REQUEST_ID =" + CollateralRID + //2
                                  " and HOME_EQUITY_ID = " + homeEquityID + //3
                                  " and SEQNO = " + SEQNO + //4
                                  " AND EVALUATOR_ID = " + evaluatorID + //5
                                  " AND RESPSEQNO = " + RESPSEQNO + //6
                                  " AND OCCURRENCE = " + OCCURRENCE);*/ //7

                          String sqlstr2 = "SELECT " + columnNamesList + " FROM " + SQLSecurity.sanitize(RESP_CHILD_TABLE) +
                                  " WHERE REQUEST_ID = ? "+ //1
                                  " AND COLLATERAL_REQUEST_ID = ? "+ //2
                                  " and HOME_EQUITY_ID = ? " + //3
                                  " and SEQNO = ? " + //4
                                  " AND EVALUATOR_ID = ? " + //5 
                                  " AND RESPSEQNO = ? " + //6
                                  " AND OCCURRENCE = ? "; //7
                          stmt1 = con.prepareStatement(sqlstr2, ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
                          stmt1.setInt(1, requestID);
                          stmt1.setInt(2, CollateralRID);
                          stmt1.setInt(3, homeEquityID);
                          stmt1.setInt(4, SEQNO);
                          stmt1.setInt(5, Integer.valueOf(evaluatorID));
                          stmt1.setInt(6, RESPSEQNO);
                          stmt1.setInt(7, OCCURRENCE);
                          rs1 = stmt1.executeQuery();

                          rs1.moveToInsertRow();

                          for (int i=1; i<columnNames.length; i++) {
                              if (columnNames[i].compareToIgnoreCase("RESPSEQNO") == 0){
                                  rs1.updateString("RESPSEQNO", newRespSeqNo);
                              } else if (columnNames[i].compareToIgnoreCase("OCCURRENCE") == 0){
                                  rs1.updateInt("OCCURRENCE", OCCURRENCE);
                              } else {
                                  rs1.updateObject(columnNames[i], newResponseValues[i]);
                              }
                          }

                          rs1.insertRow();
						 
                          log_obj.FmtAndLogMsg("RID: " + requestID + " in duplicateChildRecordsResponse end RESP_CHILD_TABLE= " + RESP_CHILD_TABLE + " OCCURRENCE= " + OCCURRENCE, i_dbg_lvl, 5);
                          OCCURRENCE++;

                          rs1.close();
                          stmt1.close();

                        } catch (Exception e) {
                            throwPostloadError("TAFRs: Failed to insert response child record:" + stack2string(e),Integer.toString(requestID));
							log_obj.FmtAndLogMsg("Exception processing taf, during duplicateChildRecordsResponse, TAFRs: Failed to insert response child record:", e);
                        }
                        finally {
                          try { if (rs1 != null) rs1.close();} catch (Exception e) {e.printStackTrace();}
                          try { if (stmt1 != null) stmt1.close();} catch (Exception e) {e.printStackTrace();}
                        }
                      }

                      rs.close();
                      stmt.close();

                } catch (Exception e) {
                    throwPostloadError("TAFRs: Failed to insert response child record:" + stack2string(e),Integer.toString(requestID));
					log_obj.FmtAndLogMsg("Exception processing taf, during duplicateChildRecordsResponse, TAFRs: Failed to insert response child record:", e);
                }
                finally {
                  try { if (rs != null) rs.close();} catch (Exception e) {e.printStackTrace();}
                  try { if (stmt != null) stmt.close();} catch (Exception e) {e.printStackTrace();}
                }
                OCCURRENCE = 1;
          }
        }
    } // duplicateChildRecordsResponse

public static String stack2string(Exception e) {
          try {
            StringWriter sw = new StringWriter();
            PrintWriter pw = new PrintWriter(sw);
            e.printStackTrace(pw);
            return "------\r\n" + sw.toString() + "------\r\n";
          }
          catch(Exception e2) {
            return "bad stack2string";
          }
    }
	
	
	
	private void deleteConcurency(String requestID){
			Query query = new Query(con);
			try {

				query.prepareStatement("select user_id from concurrency_control where request_id = ?");
				query.setInt(1,Integer.parseInt(requestID));
				query.executePreparedQuery();
				if (query.next()){
					log_obj.FmtAndLogMsg("The record exist in concurrency_control : RequestId = "+ requestID);
					//since this is failed we need to delete concurrency_control for the specific request_id 

					SQLUpdate sqlUpd = new SQLUpdate();
					sqlUpd.SetPreparedUpdateStatement(con, "delete from concurrency_control where request_id = ?");
					sqlUpd.setInt(1, Integer.parseInt(requestID));
					sqlUpd.RunPreparedUpdateStatement();
				} 
			}
			catch (Exception e2) {
				log_obj.FmtAndLogMsg("RID: " + requestID + " ERROR Unlocking app after eValuate call on a TAFRs `: " + e2.toString());
			}
		}	

} // TAFRs


