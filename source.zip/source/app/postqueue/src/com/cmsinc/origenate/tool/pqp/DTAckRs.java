package com.cmsinc.origenate.tool.pqp;


import org.w3c.dom.Node;

import com.cmsinc.origenate.event.CommentEvents;
import com.cmsinc.origenate.util.Query;
import com.cmsinc.origenate.util.SQLUpdate;
import com.cmsinc.origenate.util.XPathAPI;

/**
 * <pre>
 *
 * This class is loaded by ProcessThread.java to process an incoming XML transaction
 * when no other Controller class for the transaction type is found.
 *
 *
 * If you are implementing a Controller for a particular trans type ( LoanAppRq )
 * then make a copy of this .java file and rename it to LoanAppRq.java. Then change
 * the class name and constructor and add any business logic in runController
 * as required.
 *
 * </pre>
 *
 */
public class DTAckRs extends com.cmsinc.origenate.webservices.utils.BaseController {


    public void DTAckRs() {};


    /////////////////////////////////////////////////////////////////////////////////////////



    public void runController() throws Exception {



        /*
        DESIGN:

        This class is used to process a response from the gateway after it sent an app to DealerTrack for referral to another leander. The first use of this
        was for CarFinance. In this case, Car Finance will accept applications from consumers in their consumer portal. CF will forward the app to Origenate
        to be processed for a decision. Origenate will not decision the app. Instead it will call eValuate to determine what backend-lender should process the app.
        The app will be forwarded to DealerTrack for referral to this backend lender. Origenate does not post to DT directly but rather posts the app to the
        gateway. The gateway styles it to DT format and posts to DT. DT will eaither accept or reject the app (possibly because it failed completion checks). The
        receipt of the app is immediately sent back to the gateway synchronously. For success, DT sends back the dt-app-id which we need to store in origenate
        for future communication with DT. For failure we need to tell Origenate so it can unlock the app and write a comment as to why DT did not accept
        the app. These responses will be sent to origenate from the gateway vi a DTAckRs.

        */



        Query query = new Query(con);
        boolean continueProcessing=true;
        CommentEvents ce = new CommentEvents(con, log_obj);

        try {


           getRoutingInfo();  // sets BaseController instance variables if they exist in the xml
                              // transID (ie. LoanAppRq), network (ie. COL),
                              // remoteRefNum, evaluator_id, etc
                              // see method in base class for a complete list

           /*
           The gateway will have the client_app_id and evaluator_if from the submitted app and re-insert these values into the DTAckRs
           response. So, we should have a request_id by this point. If we do not then we can not process the response and have no
           choice but to just log the error.
           */

           if (requestID.equals("0")) 
                 throw new Exception("ERROR: Received a DTAckRs from the Gateway that did not contain a client_app_id or evaluator_id, can not process request without these");



                 //  No need to load XML, just check for a return error or success



               String error="";
               String errorTag="";
               String errorMsg="Not Avaliable";
               String dt_app_id="";

               Node nd = XPathAPI.selectSingleNode(nod_root,"/IFX/CreditSvcRs/LoanAppSvcRs/DTRs/Error/text()");

               if (nd != null && nd.getNodeValue()!=null) 
                  error = nd.getNodeValue();
               else
                  throw new Exception("ERROR: Received a DTAckRs from the Gateway that did not contain a /IFX/CreditSvcRs/LoanAppSvcRs/DTRs/Error/text(), can not process request, request_id = "+requestID);

                nd = XPathAPI.selectSingleNode(nod_root,"/IFX/CreditSvcRs/LoanAppSvcRs/DTRs/Err_message/text()");
                if (nd != null && nd.getNodeValue()!=null) 
                   errorMsg = nd.getNodeValue();

                nd = XPathAPI.selectSingleNode(nod_root,"/IFX/CreditSvcRs/LoanAppSvcRs/DTRs/Err_tag/text()");
                if (nd != null && nd.getNodeValue()!=null) 
                   errorTag = nd.getNodeValue();

                nd = XPathAPI.selectSingleNode(nod_root,"/IFX/CreditSvcRs/LoanAppSvcRs/DTRs/dt_app_id/text()");
                if (nd != null && nd.getNodeValue()!=null) 
                   dt_app_id = nd.getNodeValue();

                if (error.equals("yes")) {  //  E R R O R  - gateway received an error from DT when trying to post an app to it

                         nd = XPathAPI.selectSingleNode(nod_root,"/IFX/CreditSvcRs/LoanAppSvcRs/DTRs/Err_message/text()");

                         // we need to unlock the app because it was locked when the app went out for referral
                         // we will write a comment documenting the error and set the comments received flag so we get the flashing icon in the MDQ
                         // we do not want to move it from its current task so an analyst can find it


                         SQLUpdate.RunUpdateStatement(con,
                         "delete from concurrency_control where request_id = "+requestID+" and user_id = 'SYSTEM'");

                         String msg="DT Rejected accepting application for referral, reason: "+errorMsg+", element tag: "+errorTag+", dt_app_id: "+dt_app_id;

                         //add a comment so we will know that a comment was trying to be sent when it shouldn't
                         ce.addComment(
                                         Integer.parseInt(requestID.trim()), //request id as an int 
                                         64, //misc id
                                         "Error Referring App", //subject
                                         msg, //comment
                                         "SYSTEM", //SYSTEM USER
                                         "", //no assigned user
                                         "" //no due date
                         );

                         // Update the comments_received_flg in the credit request table
                         // so the queue will show a flashing icon that a comment was received

                         SQLUpdate.RunUpdateStatement(con,"UPDATE CREDIT_REQ_LATEST_COMMENT SET COMMENTS_RECEIVED_FLG = 1 WHERE "+
                             "REQUEST_ID = "+requestID);

                         log_obj.FmtAndLogMsg("DTAckRs error recieved for request ID: "+requestID+", error = "+msg);


                }
                else { //     S U C C E S S

                   // when DT accepts an app for referral it will send back its assigned dt-app_id which we need to store so when
                   // we receive the decision we can find the app.

                   if (dt_app_id.length()==0)
                      throw new Exception("ERROR: Received a success DTAckRs from the Gateway that did not contain a dt_app_id, can not process request without this, request_id: "+requestID);

					// store the dt_app_id in the client_app_ids table

						String asn = null;
				
						// get appseqno from credit_request
			 
						query.prepareStatement("select appseqno from credit_request where request_id = ?");
						query.setInt(1, requestID);
						query.executePreparedQuery();
				
						if (query.next()) { 
							asn = query.getColValue("appseqno",null);
						}
				   				   
                      query.prepareStatement("select request_id from credit_request_app_ids where request_id = ? and name_txt = 'DT_APP_ID'");
                      query.setInt(1,requestID);
                      query.executePreparedQuery();
                      if (query.next()) {
                         SQLUpdate.RunUpdateStatement(con,"update credit_request_app_ids set value_txt = '"+dt_app_id+"', appseqno = "+ asn +" where request_id = "+requestID+" and name_txt = 'DT_APP_ID'");
                      }
                      else {

                        SQLUpdate.RunUpdateStatement(con,"insert into credit_request_app_ids (request_id, name_txt,value_txt,appseqno) values ("+requestID+",'DT_APP_ID','"+dt_app_id+"',"+ asn +")");
                      }

                      // we also want to store the decision ref ID that this app is associated with so we can easily find it when we receive a decision back from DT

                      query.prepareStatement("select decision_ref_id from credit_req_decisions_evaluator where request_id = ? and decision_category_id = 4");
                      query.setInt(1,requestID);
                      query.executePreparedQuery();
                      String decisionRefID="0";
                      if (query.next()) {
                         decisionRefID=query.getColValue("decision_ref_id","0");
                      }
                      query.prepareStatement("select request_id from credit_request_app_ids where request_id = ? and name_txt = 'REFERRAL_DECISION_REF_ID'");
                      query.setInt(1,requestID);
                      query.executePreparedQuery();
                      if (query.next()) {
                         SQLUpdate.RunUpdateStatement(con,"update credit_request_app_ids set value_txt = '"+decisionRefID+"', appseqno = " + asn +" where request_id = "+requestID+" and name_txt = 'REFERRAL_DECISION_REF_ID'");
                      }
                      else {

                        SQLUpdate.RunUpdateStatement(con,"insert into credit_request_app_ids (request_id, name_txt,value_txt,appseqno) values ("+requestID+",'REFERRAL_DECISION_REF_ID','"+decisionRefID+"'," + asn + ")");
                      }




                   ce.addComment(
                                   Integer.parseInt(requestID.trim()), //request id as an int 
                                   64, //misc id
                                   "Referring App", //subject
                                   "DealerTrack assigned dt_app_id: "+dt_app_id, //comment
                                   "SYSTEM", //SYSTEM USER
                                   "", //no assigned user
                                   "" //no due date
                   );

                   log_obj.FmtAndLogMsg("DTAckRs success recieved for request ID: "+requestID);

                }     // end success




        }
        catch (Exception e) {


            // can't send a NOLOAD back because the Gateway doesn't know how to handle a noload


            log_obj.FmtAndLogMsg("DTAckRs ERROR: "+e.toString());

            throw (e);   // throw it back to the caller so they can set the status of
                         // the job to error

        } // exception


             // can't send a LOAD back because the Gateway doesn't know how to handle a load notification


        // if haven't thrown an error by now then the calling PQP will delete the
        // job row from the PQP queue



    }  // runController()

} // DTAckRs


