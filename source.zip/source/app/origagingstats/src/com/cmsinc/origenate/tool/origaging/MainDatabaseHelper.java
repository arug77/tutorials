package com.cmsinc.origenate.tool.origaging;

import java.util.Date;
import java.util.List;
import java.util.LinkedList;
import java.util.logging.Level;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Provides supporting database functionality, i.e., evaluator / originator query 
 * and row version lookup that drives main processing.<br>
 * 
 * Treat this class as "thread-hostile"; it is intended to be used only by
 * the main thread and has not been designed or tested for thread safety.<br>
 * 
 * @since Origenate 6.0 
 */
public class MainDatabaseHelper {
  /**
   * Inner class that stores evaluator and originator data used to to drive app.
   */
  public static class EvaluatorAndOriginatorData {
    public EvaluatorAndOriginatorData(long anEvalId, String anEvalName, long anOrigId, String anOrigName) {
      this.evaluatorId = anEvalId;
      this.evaluatorName = anEvalName;
      this.originatorId = anOrigId;
      this.originatorName = anOrigName;
    }
    
    public long evaluatorId = -1;
    public String evaluatorName = null;
    public long originatorId = -1;
    public String originatorName = null;
  }
  
  /**
   * Query that select all originators (for each evaluator); the returned 
   * data drives this application.
   */
  private static final String EVAL_ORIG_QUERY_SQL = 
    "SELECT ev.EVALUATOR_ID, ev.EVALUATOR_NAME_TXT, eo.ORIGINATOR_ID, eo.ORIGINATOR_NAME_TXT " + 
    "FROM EVALUATOR_ORIGINATOR eo, EVALUATOR ev " +
    "WHERE ev.ACTIVE_FLG = 1 AND eo.ACTIVE_FLG = 1 AND " +
    "      eo.EVALUATOR_ID = ev.EVALUATOR_ID " +
    "ORDER BY ev.EVALUATOR_ID, eo.ORIGINATOR_ID";
  
  /**
   * Query maximum row version from <code>ORIGINATOR_AGING_STATS</code> table.
   */
  private static final String MAX_VERSION_QUERY_SQL = 
    "SELECT MAX(VERSION_OF_ROW_NUM) MAX_ROW_VER FROM ORIGINATOR_AGING_STATS " +
    "WHERE EVALUATOR_ID = ? AND ORIGINATOR_ID = ?";
  
  /**
   * Database connection used by main driver thread to run above queries.
   */
  private Connection conn = null;
  
  /**
   * Prepared statement used to query maximum version for each originator.
   */
  private PreparedStatement stmtQueryMaxRowVersion = null;
  
  /**
   * Indicates that this instance was disposed of.
   */
  private boolean wasDisposedOf = false;

  /**
   * Public ctor for creating an instance of this class.
   * 
   * @param aConn
   *   database connection to be dedicated to the main driver.
   * @throws AppException
   *   if a database error occurs.
   */
  public MainDatabaseHelper(Connection aConn) throws AppException {
    try {
      this.conn = aConn;
      this.wasDisposedOf = false;
      this.stmtQueryMaxRowVersion = this.conn.prepareStatement(MAX_VERSION_QUERY_SQL);
    }
    catch (SQLException ex) {
      throw new AppException("failed to prepare SQL query to get max row version", ex);
    }
  }

  /**
   * Get a list of originators, by evaluator.
   * 
   * @return
   *   a list of <code>EvaluatorAndOriginatorData</code>.
   * @throws AppException
   *   if a database error occurs.
   */
  public List getEvaluatorAndOriginatorData() throws AppException {    
    LinkedList listData = new LinkedList();
    Statement stmtQuery = null;
    ResultSet rs = null;
    long startTime = (new Date()).getTime();
    try {
      stmtQuery = this.conn.createStatement();
      if ((rs = stmtQuery.executeQuery(EVAL_ORIG_QUERY_SQL)) != null) {
        while (rs.next()) {
          EvaluatorAndOriginatorData data = new EvaluatorAndOriginatorData(
            rs.getLong("EVALUATOR_ID"),
            rs.getString("EVALUATOR_NAME_TXT"), 
            rs.getLong("ORIGINATOR_ID"),
            rs.getString("ORIGINATOR_NAME_TXT"));
          listData.add(data);
        }
      }
    }
    catch (SQLException ex) {
      throw new AppException("database error occured during query of EVALUATOR_ORIGINATOR", ex);
    }
    finally {
	  try { if (rs != null) rs.close();} catch (Exception e) {e.printStackTrace();}
      try { if (stmtQuery != null) stmtQuery.close();} catch (Exception e) {e.printStackTrace();}
    }
    
    long endTime = (new Date()).getTime();
    long elapsedTime = (endTime - startTime);
    AppLogger.logger.log(Level.FINEST, Thread.currentThread().getName() + 
      ": queried " + listData.size() + " EVALUATOR_ORIGINATOR rows in " + elapsedTime + " ms");
    return listData;
  }
  
  /**
   * Get maximum row version for originator from <code>ORIGINATOR_AGING_STATS</code> table.
   * 
   * @return
   *   a list of <code>EvaluatorAndOriginatorData</code>.
   * @throws AppException
   *   if a database error occurs.
   */
  public int getMaximumRowVersion(long anEvalId, long anOrigId) throws AppException {
    int maxVersion = 0;
    long startTime = (new Date()).getTime();
    ResultSet rs = null;
    try {
      int idx = 1;
      this.stmtQueryMaxRowVersion.clearParameters();
      this.stmtQueryMaxRowVersion.setLong(idx++, anEvalId);
      this.stmtQueryMaxRowVersion.setLong(idx++, anOrigId);
      rs = this.stmtQueryMaxRowVersion.executeQuery();
      if (rs != null && rs.next()) 
        maxVersion = rs.getInt("MAX_ROW_VER");
    }
    catch (SQLException ex) {
      throw new AppException("database error occured during query of max version of ORIGINATOR_AGING_STATS", ex);
    }
    finally {
      try {
        if (rs != null)
          rs.close();
      }
      catch (SQLException ex) {
        AppLogger.logger.log(Level.WARNING, "failed to cleanup properly by closing result set", ex);
      }
    }
    
    long endTime = (new Date()).getTime();
    long elapsedTime = (endTime - startTime);
    AppLogger.logger.log(Level.FINEST, Thread.currentThread().getName() + 
      ": queried MAX(VERSION_OF_ROW_NUM) = '" + maxVersion + "' from ORIGINATOR_AGING_STATS in " + elapsedTime + " ms");      
    return maxVersion;
  }  
  
  /**
   * Dispose of resources (JDBC statements and connection) held by this instance.
   */
  public void dispose() {
    if (this.wasDisposedOf)
      return;
    this.wasDisposedOf = true;
    
    try {
      if (this.stmtQueryMaxRowVersion != null) {
        this.stmtQueryMaxRowVersion.close();
        this.stmtQueryMaxRowVersion = null;
      }
      if (this.conn != null) {
        this.conn.close();
        this.conn = null;
      }
    }
    catch (SQLException ex) {
      System.err.println("Warning: failed to dispose() properly by closing max row version statement " +
        "or default DB connection, exception = " + ex);
    }
  }
  
  /**
   * Dispose of acquired resources when class is destroyed (if not already disposed).
   * 
   * @see java.lang.Object#finalize()
   */
  protected void finalize() {
    dispose();
  }
}
