/******************************************************************************
 Company: First American CMSI
 Product: Origenate
 Author: Potomac Software, Inc.
 Copyright (c) 2004. All rights reserved.

 Description: Batch application that runs daily, aging credit requedst by originator 
 and saving off the aging statistics for presentation by the WUI. See "start.bat" 
 file to start this process.
******************************************************************************/

package com.cmsinc.origenate.tool.origaging;

import java.util.List;
import java.util.Iterator;
import java.util.logging.Level;

public class OrigAgingStatsApp {
  
  private static final int DEFAULT_THREADPOOL_SIZE = 1;
  
  private static final int DEFAULT_INITIAL_NAP_PER_ORIG = 100;
  
  private static final int DEFAULT_PULSE_CHECK_NAP = 5000;
  
  private static final int DEFAULT_JOIN_WAIT_MILLIS = 100;
  
  private ConfigInfo configInfo = null; 
  
  private AgingStatsQueue queue = null;
  
  private MainDatabaseHelper mainDbHelper = null;

  public static void main(String[] args) {
    Thread.currentThread().setName("mainThread");
    if (args.length == 0)
      usage();

    int exitStatus = 0;
    OrigAgingStatsApp app = null;
    try {
      ConfigInfo configInfo = ConfigInfo.getInstance(args[0]);
      AppLogger.bootstrap(configInfo);
      AppLogger.logger.log(Level.INFO, Thread.currentThread().getName() + 
        ": ==================== APPLICATION STARTED ====================");
      
      app = new OrigAgingStatsApp(configInfo);
      app.go();
    }
    catch (AppException ex) {
      String errorText = "application encountered an error";
      if (AppLogger.logger != null)
        AppLogger.logger.log(Level.SEVERE, errorText, ex);
      System.err.println(errorText + ": " + ex);
      exitStatus = 1;
    }
    finally {
      if (app != null)
        app.dispose();
    }
    
    AppLogger.logger.log(Level.INFO, Thread.currentThread().getName() +
      ": ========== APPLICATION FINISHED (exit status = " + exitStatus + ") ==========");
    System.exit(exitStatus);
  }
    
  private static void usage() {
    System.err.println("Usage: java -classpath <origenate-classpath> " +
      "com.cmsinc.origenate.tool.OrigAgingStatsApp <path-to-config-file>");
    System.exit(1);
  }
  
  private OrigAgingStatsApp(ConfigInfo aConfigInfo) throws AppException {
    this.configInfo = aConfigInfo;
    this.queue = new AgingStatsQueue();
    ConnectionFactory connFactory = ConnectionFactory.getInstance(aConfigInfo);
    this.mainDbHelper = new MainDatabaseHelper(connFactory.getUnboundConnection());
  }
  
  private void go() throws AppException {
    AppLogger.logger.entering(getClass().getName(), "go", Thread.currentThread().getName());
    
    // Create and start a pool of worker threads, then query each
    // originator (and evaluator) and place a message on the queue
    // where the worker threads will read and process the message.
    
    int threadPoolSize = this.configInfo.getThreadPoolSize() <= 0 ? 
      DEFAULT_THREADPOOL_SIZE : this.configInfo.getThreadPoolSize();
    ThreadGroup workerThreadGroup = new ThreadGroup("workerThreadGroup-0");
    Thread[] workerThreads = createWorkerThreadPool(threadPoolSize, workerThreadGroup); 
    int numOriginatorMessages = queryAndQueueOriginators();
    
    AppLogger.logger.log(Level.INFO, Thread.currentThread().getName() + 
      ": created " + threadPoolSize + " worker threads"); 
    AppLogger.logger.log(Level.INFO, Thread.currentThread().getName() + 
     ": processing " + numOriginatorMessages + " distinct originators");     
   
    // Get various timing parameters from configuration, using appropriate
    // defaults if not configured.
    
    int initialNapPerOrig = this.configInfo.getInitialNapPerOriginator() < 0 ?
      DEFAULT_INITIAL_NAP_PER_ORIG : this.configInfo.getInitialNapPerOriginator();
    int pulseCheckNap = this.configInfo.getPulseCheckNap() < 0 ?
      DEFAULT_PULSE_CHECK_NAP : this.configInfo.getPulseCheckNap();
    int joinWaitMillis = this.configInfo.getWorkerThreadJoinWaitMillis() < 0 ?
      DEFAULT_JOIN_WAIT_MILLIS : this.configInfo.getWorkerThreadJoinWaitMillis();

    // Loop (and sleep) until all worker threads have completed.
    
    workerThreadPulseLoop: 
    for (boolean isInitialPulseCheck=true;;isInitialPulseCheck=false) {
      //
      // Tell worker threads to quit when no more messages in queue,
      // then sleep while worker threads complete. We wait much longer
      // the first time, since initially the worker threads will be 
      // busy collecting and storing aging statistics.
      
      this.queue.signalQuit();
      try {
        long napMillis = isInitialPulseCheck ? 
          (initialNapPerOrig * numOriginatorMessages) : pulseCheckNap;
        AppLogger.logger.log(Level.FINEST, Thread.currentThread().getName() + 
          ": waiting " + napMillis + " ms for thread death"); 
        Thread.sleep(napMillis); 
      }
      catch (InterruptedException ex) {
        //
        // If the main thread is interrupted, we quit this method and the main
        // thread terminates; since the worker threads are daemon threads,
        // they will die ungraciously with the main thread (data integrity should
        // be preserved due to transactional versioning in worker threads). So 
        // interrupting this main thread kills the whole app.
        
        AppLogger.logger.log(Level.FINEST, Thread.currentThread().getName() + 
          ": sleep() interrupted!"); 
        break workerThreadPulseLoop;
      }
    
      // If no active threads in worker thread group, all worker threads finished, 
      // we are done. We expect this check to usually terminate this app.
      
      AppLogger.logger.log(Level.FINEST, Thread.currentThread().getName() + 
        ": check active thread count");
      if (workerThreadGroup.activeCount() == 0)
        break workerThreadPulseLoop;
      
      // Fall into "fail-safe" thread death detection code. If thread group reports 
      // some threads active, try to join with each thread ourselves. If a thread 
      // has died, mark it's slot in the thread array as NULL (note if join is 
      // interrupted, whole app dies, as explained above).      
      
      AppLogger.logger.log(Level.FINEST, Thread.currentThread().getName() + 
        ": active thread count non-zero (" + workerThreadGroup.activeCount() + 
        "), try joining with worker threads, join-wait-time = " + joinWaitMillis + " ms");

      for (int i=0; i < workerThreads.length;i++) {
        if (workerThreads[i] != null) {
          try {
            workerThreads[i].join(joinWaitMillis);
            if (!workerThreads[i].isAlive())
              workerThreads[i] = null;
          }
          catch (InterruptedException ex) {
            AppLogger.logger.log(Level.FINEST, Thread.currentThread().getName() + 
              ": join() interrupted!");
            break workerThreadPulseLoop;
          }
        }
      }

      // See if all threads are marked as dead (NULL), if so exit loop.
      
      AppLogger.logger.log(Level.FINEST, Thread.currentThread().getName() + 
        ": count remaining live threads after join");      
      boolean allWorkerThreadsFinished = true;
      for (int i=0; i < workerThreads.length ;i++) {
        if (workerThreads[i] != null)
          allWorkerThreadsFinished = false;
      }
      if (allWorkerThreadsFinished) {
        AppLogger.logger.log(Level.FINEST, Thread.currentThread().getName() + 
          ": joined with all worker threads, done");
        break workerThreadPulseLoop;
      }
    }
    
    AppLogger.logger.exiting(getClass().getName(), "go", Thread.currentThread().getName());    
  }
  
  /**
   * Query for all originators for each evaluator and add a message to the
   * in-memory queue that drives collection and storage of aging stats.
   * 
   * @throws AppException
   *   if a database error occurs.
   */
  private int queryAndQueueOriginators() throws AppException {
    List list = this.mainDbHelper.getEvaluatorAndOriginatorData();
    for (Iterator iter=list.iterator();iter.hasNext();) {
      MainDatabaseHelper.EvaluatorAndOriginatorData origData = 
        (MainDatabaseHelper.EvaluatorAndOriginatorData) iter.next();
      int outputRowVersion = this.mainDbHelper.getMaximumRowVersion(origData.evaluatorId, 
        origData.originatorId) + 1;
      AgingStatsMessage message = new AgingStatsMessage(origData.evaluatorId, 
        origData.originatorId, outputRowVersion);
      this.queue.append(message);
    }
    return list.size();
  }
  
  private Thread[] createWorkerThreadPool(int aPoolSize, ThreadGroup aThreadGroup) {
    Thread[] arrThreads = new Thread[aPoolSize];
    for (int i=0;i < aPoolSize;i++) {
      arrThreads[i] = new AgingStatsWorkerThread(aThreadGroup, "workerThread" + i, this.queue);
      arrThreads[i].start();
    }
    return arrThreads;
  }
  
  /**
   * Dispose of this instance and any resources it is holding (e.g.,
   * prepared statements and database connections).
   */
  private void dispose() {
    if (this.mainDbHelper != null)
      this.mainDbHelper.dispose();
  }
}
