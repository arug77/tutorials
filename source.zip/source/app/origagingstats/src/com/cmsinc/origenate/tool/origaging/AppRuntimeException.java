package com.cmsinc.origenate.tool.origaging;

/**
 * Runtime (non-checked) exception thrown by methods in credit 
 * request aging application. where a checked exception cannot be
 * thrown due to Java method override rules, such as <code>Thread.run</code>.
 * Only use this class in those few special cases, otherwise always use a
 * checked exception such as <code>AppException</code>. 
 * 
 * Treat this class as "thread-safe".
 * 
 * @see AppException
 * @since Origenate 6.0
 */
public class AppRuntimeException extends java.lang.RuntimeException {
  /**
   * Public ctor for creating an instance of this class.
   * 
   * @param aMessage
   *   an error message.
   */
  public AppRuntimeException(Throwable anException) {
  	super(anException);
  }
  
  /**
   * Public ctor for creating an instance of this class.
   * 
   * @param aMessage
   *   an error message.
   */
  public AppRuntimeException(String aMessage) {
  	super(aMessage);
  }
  
  /**
   * Public ctor for creating an instance of this class.
   * 
   * @param aMessage
   *   an error message.
   * @param anException
   *   the causing exception.
   */
  public AppRuntimeException(String aMessage, Throwable anException) {
  	super(aMessage, anException);
  }    
}
