package com.cmsinc.origenate.tool.origaging;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.logging.Level;

import com.cmsinc.origenate.tool.origaging.querybyorig.AgingStatsWorker;

/**
 * Thread that runs <code>AgingStatsWorker</code> code, which queries,
 * collects and stores creidr request aging statistics for an originator.<br>
 * 
 * Treat this class as "thread-hostile"; with the exception of interruption,
 * no other threads should invoke methods of this class.<br>
 * 
 * @since Origenate 6.0 
 */
public class AgingStatsWorkerThread extends Thread {
  
  private AgingStatsQueue queue = null;
  
  public AgingStatsWorkerThread(ThreadGroup aThreadGroup, String aName, AgingStatsQueue aQueue) {
    super(aThreadGroup, aName);
    this.queue = aQueue;
    setDaemon(true);
  }

  public void run() {
    AppLogger.logger.entering(getClass().getName(), "run", super.getName());
    
    Connection conn = null;
  	try {
		  ConnectionFactory connFactory = ConnectionFactory.getInstance(null);
		  conn = connFactory.getUnboundConnection();
	  }
		catch (AppException ex) {
		  throw new AppRuntimeException(ex);
		}
    
		AppRuntimeException exception = null;
    processUtilQuitLoop: while (exception == null) {
      AppLogger.logger.log(Level.FINER, super.getName() + 
	      ": about to check message queue, may wait...");
      
			// Sleep until we have a message in the queue, or there are
		  // no messages and quit was signalled (thread is finished).

			try {  
				synchronized (this.queue) {
					while (this.queue.size() == 0) {
					  if (this.queue.quitWasSignalled())
					    break processUtilQuitLoop;
					  else 
					    this.queue.wait();
					}
				}
			}
			catch (InterruptedException ex) {
			  //
				// Terminate run loop, thread was told to die.
			  
			  AppLogger.logger.exiting(getClass().getName(), "run", 
			    super.getName() + ": interrupted!");
			  break processUtilQuitLoop;
			}
			
			// Pull message off queue.
			
			AppLogger.logger.log(Level.FINER, super.getName() + 
		    ": messages detected on queue, getting a message...");
			AgingStatsMessage queueMsg = this.queue.get();
			if (queueMsg == null)
			  continue;
		  else {
		    AppLogger.logger.log(Level.FINER, super.getName() + 
	        ": got message from queue, evalID=" + queueMsg.getEvaluatorId() + 
	        ", origID=" + queueMsg.getOriginatorId() + 
	        ", rowVer=" + queueMsg.getOutputRowVersion());
		  }
			
			// Dedicate new database connection to worker object (and this thread),
			// the worker will handle all database I/O and transactions. Also, we 
			// assume the connection factory has been initialized by main thread.
			
			try {
			  AppLogger.logger.log(Level.FINER, super.getName() + 
	        ": about to hand off database query, update and commit to worker object ...");
			  AgingStatsWorker worker = new AgingStatsWorker(conn, queueMsg.getEvaluatorId(), 
			    queueMsg.getOriginatorId(), queueMsg.getOutputRowVersion());
			  worker.doWork();
		  }
			catch (AppException ex) {
			  exception = new AppRuntimeException(ex);
			  break processUtilQuitLoop; 
			}
		}                                               // end FOR

		// Out of message processing loop, either because no more messages on queue
		// and quit was signalled, or because the worker object threw an exception.
		// In both cases, we must close the database connection.
		
		try { 
		  conn.close(); 
		 } 
		 catch (SQLException ex) { 
		   AppLogger.logger.log(Level.WARNING, "failed to close connection", ex); 
		 }
    
		if (exception == null) {
			AppLogger.logger.exiting(getClass().getName(), "run", super.getName() + 
			  ": finished normally");
		  return;
		}
		else {
			AppLogger.logger.exiting(getClass().getName(), "run", super.getName() + 
			  ": finished with error (ex = " + exception + ")");
		  throw exception;
		}
  }
}
