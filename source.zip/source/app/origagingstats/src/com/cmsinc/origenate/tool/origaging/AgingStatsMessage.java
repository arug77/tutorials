package com.cmsinc.origenate.tool.origaging;

/**
 * Message passed on aging stats work queue, contains arguments needed to query,
 * collect and store aging stats for an originator<br>
 *
 * Treat this class as "thread-safe".
 *
 * @since Origenate 6.0
 */
public class AgingStatsMessage {
  
  protected long evaluatorId = -1;
  
  protected long originatorId = -1;
  
  protected int outputRowVersion = -1;

	AgingStatsMessage(long anEvalId, long anOrigId, int aRowVersion) {
	  this.evaluatorId = anEvalId;
    this.originatorId = anOrigId;
    this.outputRowVersion = aRowVersion;
	}

	public long getEvaluatorId() {
	  return this.evaluatorId;
	}

	public long getOriginatorId() {
	  return this.originatorId;
	}

	public int getOutputRowVersion() {
		return this.outputRowVersion;
	}
}
