package com.cmsinc.origenate.tool.origaging;

import java.util.List;
import java.util.LinkedList;

/**
 * FIFO queue of incoming requests to generate aging statistics 
 * for an originator.<br>
 *
 * Treat this class as "thread-safe".<br>
 *
 * @since Origenate 6.0
 */
public class AgingStatsQueue {

	private List list = null;
	
	private boolean quitSignalled = false;

	AgingStatsQueue() {
	  this.list = new LinkedList();
	}

	public synchronized void append(AgingStatsMessage aMessage) {
		this.list.add(0, aMessage);
		notifyAll();
	}
	
	public synchronized void signalQuit() {
		this.quitSignalled = true;
		notifyAll();
	}

	public synchronized AgingStatsMessage get() {
		AgingStatsMessage msg = null;
		int size = this.list.size();
		if (size > 0)
			msg = (AgingStatsMessage) this.list.remove(size - 1);
		return msg;
	}

	public synchronized int size() {
		return this.list.size();
	}
	
	public synchronized boolean quitWasSignalled() {
		return this.quitSignalled;
	}
}
