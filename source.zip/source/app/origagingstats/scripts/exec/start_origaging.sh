#!/bin/sh
#
# Start generation of credit request aging statistics by originator
#

INIFILE=/opt/jrun4/servers/dv60/cfusion-ear/cfusion-war/config/origenate.ini
LOGFILE=/opt/origenate/dv60/start_origaging.sh.log

nohup java -classpath $JAVA_HOME/jre/lib/rt.jar:.:../lib/common.jar:../lib/ojdbc6.jar  \
  com.cmsinc.origenate.tool.origaging.OrigAgingStatsApp $INIFILE >> $LOGFILE &
exit 0
