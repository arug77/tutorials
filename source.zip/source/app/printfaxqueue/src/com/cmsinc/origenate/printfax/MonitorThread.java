package com.cmsinc.origenate.printfax;

import java.sql.*;
import java.util.Date;
import java.util.Vector;

import com.cmsinc.origenate.event.JournalEvents;
import com.cmsinc.origenate.util.Alert;
import com.cmsinc.origenate.util.LogMsg;
import com.cmsinc.origenate.util.PostRequest;
import com.cmsinc.origenate.util.Query;
import com.cmsinc.origenate.util.SQLUpdate;
import com.cmsinc.origenate.workflow.AppLockingManager;
import com.cmsinc.origenate.workflow.ApplicationIDs;
import com.cmsinc.origenate.workflow.ApplicationStatusManager;
import com.cmsinc.origenate.workflow.WorkFlowManager;

/**
 * This thread is used to monitor the status of fax jobs
 *
 */
public class MonitorThread extends Thread {

	static final int ADD_JOB = 1;

	static final int REMOVE_JOB = 2;

	static final int GET_FIRST_JOB = 3;

	static final int GET_NEXT_JOB = 4;

	// INSTANCE VARIABLES

	Connection con = null;

	PrintFaxProcessor main = null;

	boolean endThread = false;

	//int threadID = 0;

	//String sConStr, sUser, sPass;

	//LogMsg log_obj = null;

	Query queryTmp;

	Vector jobQueue = null;

	int currIndex = 0;

	WorkFlowManager workFlowManager = null;

	AppLockingManager appLockingManager = null;

	ApplicationStatusManager applicationStatusManager = null;

	// CONSTRUCTOR

	public MonitorThread(PrintFaxProcessor main, String sConStr, String sUser,
			String sPass, int ID, LogMsg log_obj, String central_pro_server_id)
			throws Exception {

		//threadID = ID;
		this.main = main;
		//this.sConStr = sConStr;
		//this.sUser = sUser;
		//this.sPass = sPass;
		//this.log_obj = log_obj;

		// Connect to the Oracle database
		con = DriverManager.getConnection(sConStr, sUser, sPass);

		queryTmp = new Query(con);

		jobQueue = new Vector();

		workFlowManager = new WorkFlowManager(con, log_obj);
		appLockingManager = new AppLockingManager(con, log_obj);
		applicationStatusManager = new ApplicationStatusManager(con, log_obj);

		/*
		 * first find any previous jobs in the printfax_queue table that have an
		 * outstanding [FAXING] status and add them to the queue of jobs to
		 * monitor
		 */

		queryTmp
				.executeQuery("select job_id, rightfax_job_id,rightfax_url_txt,rightfax_user_id,unlock_app_flg,move_to_failed_flg,decode(job_type_txt,'Fax','FAX','Print','BATCH','FAX') as job_type_txt from printfax_queue where status_id = '[FAXING]' or status_id = '[PRINTING]'");

		while (queryTmp.next()) {
			action(ADD_JOB, 0, queryTmp.getColValue("job_id", "0"), queryTmp
					.getColValue("rightfax_job_id", "0"), queryTmp.getColValue(
					"rightfax_url_txt", "none"), queryTmp.getColValue(
					"rightfax_user_id", "none"), queryTmp.getColValue(
					"unlock_app_flg", "0"), queryTmp.getColValue(
					"move_to_failed_flg", "0"), queryTmp.getColValue(
					"job_type_txt", "FAX"));
		}

		currIndex = 0;

	} // end constructor

	//  A C C E S S M E T H O D S F O R J O B Q U E U E

	/////////////////////////////////////////////////////////////////////////////

	public synchronized String action(int action, int index, String jobID,
			String rightFaxJobID, String rightFaxURL, String rightFaxUserID,
			String unlock_app_flg, String move_to_failed_flg,
			String job_type_txt) {

		String ret = "";

		switch (action) {

		case ADD_JOB:

			jobQueue.addElement(jobID + "," + rightFaxJobID + "," + rightFaxURL
					+ "," + rightFaxUserID + "," + unlock_app_flg + ","
					+ move_to_failed_flg + "," + job_type_txt + ",");
			break;

		case REMOVE_JOB:
			jobQueue.set(index, "empty");
			break; // just set to empty
		// so as not to upset the get_next action until
		// a get first is called
		case GET_FIRST_JOB:

			ret = getFirst();

			break;

		case GET_NEXT_JOB:
			currIndex++;
			if (currIndex < jobQueue.size()) {
				ret = (String) jobQueue.get(currIndex);
			} else
				ret = getFirst();
			break;

		}
		return (ret);
	} // action

	////////////////////////////////////////////////////////////////////////////

	String getFirst() {

		// first clear out any unused space
		while (jobQueue.remove("empty"))
			;

		currIndex = 0;

		if (jobQueue.size() > 0)
			return ((String) jobQueue.get(currIndex));

		return ("");

	} // getFirst

	////////////////////////////////////////////////////////////////////////////

	// RUN METHOD - execution continues in its own thread

	public void run() {

		main.log(0, "Monitor thread running...");

		String jobID, rightFaxJobID, tmp, rightFaxURL, response, status, msg, rightFaxUserID, unlock_app_flg, move_to_failed_flg, job_type;

		//GL.
		int timeBetweenRequests = main.querySleep * 1000;
		int queueEmptySleep = main.queryQueueEmptySleep * 1000;
		//GL.

		boolean getFirst = true;

		Query queryTmp = new Query(con);

		RightFaxWrapper rightFax = null;
		String lastURL = "";
		int numTimes = 0;
		String sql = "";
		PreparedStatement ps = null;

		while (!endThread) {

			try {

				if (getFirst) {
					getFirst = false;
					tmp = action(GET_FIRST_JOB, 0, "", "", "", "", "", "", "");
				} else
					tmp = action(GET_NEXT_JOB, 0, "", "", "", "", "", "", "");

				if (tmp.length() == 0) { // none in queue so sleep
					//GL.
					try {
						Thread.sleep(queueEmptySleep);
					} catch (Exception e) {
					}
					//GL.
					continue;
				}

				// came across one that was removed, so go to the next one
				if (tmp.equals("empty")) {
					// these will be removed on the next GETFIRST action
					continue;
				}

				jobID = tmp.substring(0, tmp.indexOf(","));
				tmp = tmp.substring(tmp.indexOf(",") + 1);
				rightFaxJobID = tmp.substring(0, tmp.indexOf(","));
				tmp = tmp.substring(tmp.indexOf(",") + 1);
				rightFaxURL = tmp.substring(0, tmp.indexOf(","));
				tmp = tmp.substring(tmp.indexOf(",") + 1);
				rightFaxUserID = tmp.substring(0, tmp.indexOf(","));
				tmp = tmp.substring(tmp.indexOf(",") + 1);
				unlock_app_flg = tmp.substring(0, tmp.indexOf(","));
				tmp = tmp.substring(tmp.indexOf(",") + 1);
				move_to_failed_flg = tmp.substring(0, tmp.indexOf(","));
				tmp = tmp.substring(tmp.indexOf(",") + 1);
				job_type = tmp.substring(0, tmp.indexOf(","));

				if (!rightFaxURL.equals(lastURL)) {
					rightFax = new RightFaxWrapper(main, rightFaxURL);
					lastURL = rightFaxURL;
				}

				// main.log(0,"Requesting info on:"+rightFaxJobID);

				response = rightFax.queryFaxStatus(rightFaxJobID,
						rightFaxUserID);

				// main.log(0,"RESP:"+response);

				status = response.substring(0, response.indexOf(","));

				msg = response.substring(response.indexOf(",") + 1);

				if (status.equals("6")) { // SUCCESS

					// update doc history and unlock app, etc

					updateJobAsSuccess(jobID, con, unlock_app_flg,
							move_to_failed_flg, job_type);

					// Success, so remove printfax_queue job only if its a fax
					// batch jobs will be removed by the lender print tool

					if (job_type.equals("FAX")) {
						// 1/24/07 ChrisN CL140795 Replaced with SQL using bind variable for Triad performance enhancement
						//SQLUpdate.RunUpdateStatement(con,
						//		"delete from printfax_queue_values where job_id = "
						//				+ jobID);
						//SQLUpdate.RunUpdateStatement(con,
						//		"delete from printfax_queue where job_id = "
						//				+ jobID);
						sql = "delete from printfax_queue_values where job_id = ?";
		        ps = con.prepareStatement(sql);
		        ps.setInt(1, Integer.parseInt(jobID));
		        ps.execute();
		        ps.close();

						sql = "delete from printfax_queue where job_id = ?";
		        ps = con.prepareStatement(sql);
		        ps.setInt(1, Integer.parseInt(jobID));
		        ps.execute();
		        ps.close();
					}

					// remove this job from the queue of jobs to check

					action(REMOVE_JOB, currIndex, "", "", "", "", "", "", "");

					// remove the successful job from the RightFax log
					try {
						RightFaxWrapper rf = new RightFaxWrapper(main,
								rightFaxURL);
						rf.deleteFax(rightFaxJobID);
					} catch (Exception e) {
						main.log(0,
								"ERROR deleteing fax job that was successful: "
										+ e.toString());
					} // no big deal

				} // lost fax job
				else if (status.equals("-99") || // No Information found (not
						// avail yet)
						status.equals("4") || // In conversion ( in process )
						status.equals("8") || // Scheduled to be sent
						status.equals("0") || // Initial processing
						status.equals("5") || // Sending
						status.equals("11") || // Error occurred - retrying
                                                status.equals("-3") || // Error connecting - retrying
						status.equals("3") // Waiting to be sent
				) {

					/*
					 * GL. 11/24/03 Under load RightFax will sometimes return a
					 * status message of 'Deleted' which really means that the
					 * job printed successfully and the job was deleted
					 */

					if (msg.equalsIgnoreCase("deleted")) {

						// update doc history and unlock app, etc

						updateJobAsSuccess(jobID, con, unlock_app_flg,
								move_to_failed_flg, job_type);

						// Success, so remove printfax_queue job only if its a
						// fax
						// batch jobs will be removed by the lender print tool

						if (job_type.equals("FAX")) {
							// 1/24/07 ChrisN CL140795 Replaced with SQL using bind variable for Triad performance enhancement
							//SQLUpdate.RunUpdateStatement(con,
							//		"delete from printfax_queue_values where job_id = "
							//				+ jobID);
							//SQLUpdate.RunUpdateStatement(con,
							//		"delete from printfax_queue where job_id = "
							//				+ jobID);
							sql = "delete from printfax_queue_values where job_id = ?";
			        ps = con.prepareStatement(sql);
			        ps.setInt(1, Integer.parseInt(jobID));
			        ps.execute();
			        ps.close();

							sql = "delete from printfax_queue where job_id = ?";
			        ps = con.prepareStatement(sql);
			        ps.setInt(1, Integer.parseInt(jobID));
			        ps.execute();
			        ps.close();
						}

						// remove this job from the queue of jobs to check

						action(REMOVE_JOB, currIndex, "", "", "", "", "", "",
								"");

						// remove the successful job from the RightFax log
						try {
							RightFaxWrapper rf = new RightFaxWrapper(main,
									rightFaxURL);
							rf.deleteFax(rightFaxJobID);
						} catch (Exception e) {
							// no need to log because RF said it was deleted
						}

					} else {

						/*
						 * Update the message field so if someone is looking at
						 * the printfax queue they can see the current status of
						 * the job
						 */

						if (status.equals("-99"))
							msg = "Submitted - waiting for status";
						if (status.equals("11"))
							msg = "RETRYING - " + msg;

						msg = msg.replace('\'', ' ');
						msg = msg.replace('"', ' ');

						// 1/24/07 ChrisN CL140795 Replaced with SQL using bind variable for Triad performance enhancement
						//SQLUpdate.RunUpdateStatement(con,
						//		"update printfax_queue set " + "error_txt = '"
						//				+ msg + "', FINISHED_DT = SYSDATE "
						//				+ " where job_id = " + jobID);
						sql = "update printfax_queue set error_txt = ?, finished_dt = sysdate where job_id = ?";
						ps = con.prepareStatement(sql);
						ps.setString(1, msg);
						ps.setInt(2, Integer.parseInt(jobID));
						ps.execute();
						ps.close();
					}
				} else { // any other code is assumed to be an error

					msg = status + " - " + msg;
					msg = msg.replace('\'', ' ');
					msg = msg.replace('"', ' ');

					updateJobAsError(jobID, msg, con, unlock_app_flg,
							move_to_failed_flg, job_type);

					// no need to check on this job again

					action(REMOVE_JOB, currIndex, "", "", "", "", "", "", "");

					// remove this error job from the RightFax log
					try {
						RightFaxWrapper rf = new RightFaxWrapper(main,
								rightFaxURL);
						rf.deleteFax(rightFaxJobID);
					} catch (Exception e) {
						main.log(0,
								"ERROR deleteing fax job that was in error: "
										+ e.toString());
					} // no big deal

				}

			} catch (Exception e) {
				String emsg = e.toString();
				if (emsg.indexOf("no protocol") > 0) {
					numTimes++;
					if (numTimes < 10)
						main.log(0, "ERROR checking fax status: " + emsg);
					else if (numTimes == 10)
						main
								.log(
										0,
										"ERROR checking fax status: previous msg reoccurs too many times, will no longer be displayed, pls check into it");
				} else
					main.log(0, "ERROR checking fax status: " + emsg);

			}
			finally {
					try {ps.close(); } catch (Exception e1) {}
			}

			// wait awhile before processing next job in the queue
			// because we don't want to flood the RightFax server
			// with http requests

			try {
				Thread.sleep(timeBetweenRequests);
			} catch (Exception e) {
			}

		} // while not end thread

		try {
			con.close();
		} catch (Exception e1) {
		}

		// fall thru to end thread

	} // end run()

	///////////////////////////////////////////////////////////////////////////////

	public void updateJobAsError(String jobID, String err, Connection con,
			String unlock_app_flg, String add_failed_alert_flg, String job_type) {

		// NOTE: ANY CHGS HERE MUST BE MADE TO THE SAME METHOD IN THE
		// PROCESSTHREAD

		//see if there is a request_id. If there is not, it is a Broadcast fax
		Query queryTmp2 = new Query(con);
		String sql = "";
		PreparedStatement ps = null;
		try {
			sql = "select pq.request_id,cr.evaluator_id,pq.document_id,cr.product_id " +
							"from printfax_queue pq, credit_request cr where pq.job_id = ? and pq.request_id = cr.request_id";
			queryTmp2.prepareStatement(sql);
			queryTmp2.setInt(1, jobID);
			queryTmp2.executePreparedQuery();
		} catch (Exception e) {
			main.log(0, e.toString());
		}

		if (!queryTmp2.next()) {

			// UPDATE THE PRINTFAX QUEUE JOB WITH THE STATUS
			try {
				// 1/24/07 ChrisN CL140795 Replaced with SQL using bind variable for Triad performance enhancement
				//SQLUpdate.RunUpdateStatement(con,
				//		"update printfax_queue set status_id = 'ERROR', error_txt = '"
				//				+ err
				//				+ "',finished_dt = sysdate where job_id = "
				//				+ jobID);
				sql = "update printfax_queue set status_id = 'ERROR', error_txt = ?, finished_dt = sysdate where job_id = ?";
				ps = con.prepareStatement(sql);
				ps.setString(1, err);
				ps.setInt(2, Integer.parseInt(jobID));
				ps.execute();
				ps.close();
			} catch (Exception e) {
				main.log(0, e.toString());
			}
			finally {
					try { if (ps != null) ps.close();} catch (Exception e1) {e1.printStackTrace();}
			}
		} else {

			Query queryTmp = new Query(con);

			boolean errorOccurred = false;
			String request_id = "0";
			String document_id = "0";
			String evaluator_id = "0";
			String product_id = "1"; // INDIRECT AUTO
			String document_name = "Document name not found";
			String fax_number = "0";
			String user_id = "";
			String assigned_user_id = "";
			String originator_id = "";
			try {

				sql = "select pq.fax_number_txt,pq.request_id,cr.evaluator_id,pq.document_id,cr.product_id " +
				"from printfax_queue pq, credit_request cr where pq.job_id = ? and pq.request_id = cr.request_id";

				queryTmp.prepareStatement(sql);
				queryTmp.setInt(1, jobID);
				queryTmp.executePreparedQuery();
				if (queryTmp.next()) {
					request_id = queryTmp.getColValue("request_id", "0");
					evaluator_id = queryTmp.getColValue("evaluator_id", "0");
					product_id = queryTmp.getColValue("product_id", "1");
					document_id = queryTmp.getColValue("document_id", "0");
					fax_number = queryTmp.getColValue("fax_number_txt", "0");
				}

				if (request_id.equals("0"))
					main
							.log(
									0,
									"ERROR: Can't update job to error status, can't find request_id in job row, job ID: "
											+ jobID + ", request_id set to 0");

				sql = "select cd.description_txt from config_documents cd where cd.document_id = ? and evaluator_id = ? ";
				queryTmp.prepareStatement(sql);
				queryTmp.setInt(1, document_id);
				queryTmp.setInt(2, evaluator_id);
				queryTmp.executePreparedQuery();
				if (queryTmp.next()) {
					document_name = queryTmp.getColValue("description_txt",
							"Document name is null");
				} else
					main
							.log(
									0,
									"ERROR: Document ID: "
											+ document_id
											+ " in PF job, not found in config_documents table for job: "
											+ jobID);

				// UPDATE THE PRINTFAX QUEUE JOB WITH THE STATUS

				// 1/24/07 ChrisN CL140795 Replaced with SQL using bind variable for Triad performance enhancement
				//SQLUpdate.RunUpdateStatement(con,
				//		"update printfax_queue set status_id = 'ERROR', error_txt = '"
				//				+ err
				//				+ "',finished_dt = sysdate where job_id = "
				//				+ jobID);
				sql = "update printfax_queue set status_id = 'ERROR', error_txt = ?, finished_dt = sysdate where job_id = ?";
				ps = con.prepareStatement(sql);
				ps.setString(1, err);
				ps.setInt(2, Integer.parseInt(jobID));
				ps.execute();
				ps.close();

				// UPDATE THE DOC HISTORY ROW WITH THE STATUS

				//SQLUpdate
				//		.RunUpdateStatement(
				//				con,
				//				"update credit_req_doc_history "
				//						+ "set status_id = 'ERROR', print_date = sysdate,"
				//						+ "error_txt = '" + err + "'"
				//						+ " where job_id = " + jobID);
				sql = "update credit_req_doc_history set status_id = 'ERROR',  print_date = sysdate, error_txt = ? where job_id = ?";
				ps = con.prepareStatement(sql);
				ps.setString(1, err);
				ps.setInt(2, Integer.parseInt(jobID));
				ps.execute();
				ps.close();

				// POST AN ERROR COMMENT TO THE JOURNAL

				if (job_type.equals("FAX")) {

					try {
						main.postCommentEvent(19, // Fax Message
								request_id, "Fax FAILED", document_name
										+ " Reason:" + err + " Fax:" + fax_number);
					} catch (Exception e) {
						main.log(0, "Can't post comment for jobID:" + jobID
								+ " request_id:" + request_id + " err="
								+ e.toString());
					}
					/*
					 * Post a journal event for this app to indicate that a this
					 * document failed
					 */

					try {

						String msg = "Fax failed: " + document_name;
						int eventID = 42;
						// fax transmittals will be the only fax that has the
						// move_to_failed
						// flag set
						if (add_failed_alert_flg.equals("1")) {
							msg = "Failed: " + document_name;
							eventID = 45; // transmittal
						}
						int reqID = Integer.parseInt(request_id);
						JournalEvents journalEvents = new JournalEvents(con,
								null);
						journalEvents.addJournal(reqID, eventID, msg, "SYSTEM");
					} catch (Exception e) {
						main.log(0, "Can't post journal event for jobID:"
								+ jobID + " request_id:" + request_id + " err="
								+ e.toString());
					}
				} else {

					/*
					 * They want journal entry instead main.postCommentEvent(29, //
					 * Doc Message request_id, "Document Print FAILED",
					 * document_name+" Reason:"+err);
					 */

					/*
					 * Post a journal event for this app to indicate that a this
					 * document failed
					 */

					try {

						int reqID = Integer.parseInt(request_id);
						JournalEvents journalEvents = new JournalEvents(con,
								null);
						// 41-batch print
						journalEvents.addJournal(reqID, 41,
								"Batch print failed: " + document_name,
								"SYSTEM");
					} catch (Exception e) {
						main.log(0, "Can't post journal event for jobID:"
								+ jobID + " request_id:" + request_id + " err="
								+ e.toString());
					}
				}

			} catch (Exception e) {
				main.log(0, "ERROR: Can't update job to error state, job ID: "
						+ jobID + " orig error msg: " + err + " reason: "
						+ e.toString());
				errorOccurred = true;
			}

			if (!errorOccurred) {

				// ADD CODE HERE TO UNLOCK APP AND ADD FAILED ALERT BASED ON
				// FLGS

				if (unlock_app_flg.equals("1")) {
					// unlcok the app
					try {
						appLockingManager.releaseLockOnApp((long) Integer
								.parseInt(request_id));
					} catch (Exception e) {
						// already marked as error so can only log the message
						main.log(0,
								"ERROR: Can't release lock on app for job: "
										+ jobID + " reason: " + e.toString());
					}
				}
				//ALL FAX FAILURES NOW CREATE AN ALERT
				//if (add_failed_alert_flg.equals("1")) {

					Query query = new Query(con);
					// add Failed Transmittal Alert
					try {
						//code to add the assigned userid to the credit request alert table
						sql = "select user_id,evaluator_id from printfax_queue where job_id = ? ";
						query.prepareStatement(sql);
						query.setInt(1, jobID);
						query.executePreparedQuery();

						if (query.next()) {
							user_id = query.getColValue("user_id","");
							evaluator_id = query.getColValue("evaluator_id");
						}
						if(user_id.equalsIgnoreCase("SYSTEM")){
							sql = "select originator_id from credit_request_originator " +
							"where request_id = ? and evaluator_id = ? ";
							query.prepareStatement(sql);
							query.setInt(1, request_id);
							query.setInt(2, evaluator_id);
							query.executePreparedQuery();
							if(query.next()){
								originator_id = query.getColValue("originator_id");
							}
							if(originator_id != null){
								sql = "select assigned_user_id from evaluator_originator " +
								"where originator_id = ? and evaluator_id = ? ";
								query.prepareStatement(sql);
								query.setInt(1, originator_id);
								query.setInt(2, evaluator_id);
								query.executePreparedQuery();
								if(query.next())
									assigned_user_id = query.getColValue("assigned_user_id");
							}
						}
						else{
							assigned_user_id = user_id;
						}

						assigned_user_id = assigned_user_id != null ? assigned_user_id : "";						
						Alert alert = new Alert((int) Integer
								.parseInt(request_id), Alert.getNextSeq_Id(
								(int) Integer.parseInt(request_id), con), 6,
								"open", new Date(), null,
								"Failed Fax Transmittal: jobID-" + jobID
										+ "  document_id-" + document_id
										+ "  document_name-" + document_name
										+ "  job_type-" + job_type, assigned_user_id, con);
						alert.addAlert();
					} catch (Exception e) {
						// already marked as error so can only log the message
						main.log(0,
								"ERROR: Can not add Failed Transmittal Alert for job: "
										+ jobID + " reason: " + e.toString());
					}

				//} ALL FAX FAILURES NOW GET ALERTS

			} // !errorOccurred

			return;
		}
	} // updateJobAsError

	///////////////////////////////////////////////////////////////////////////////

	public void updateJobAsSuccess(String jobID, Connection con,
			String unlock_app_flg, String move_to_failed_flg,
			String job_type_txt) {

		// NOTE: ANY CHGS HERE MUST BE MADE TO THE SAME METHOD IN THE
		// PROCESSTHREAD

		//see if there is a request_id. If there is not, it is a Broadcast fax
		Query queryTmp2 = new Query(con);
		String sql = "";
		PreparedStatement ps = null;
		try {
			sql = "select pq.request_id,cr.evaluator_id,pq.document_id,cr.product_id " +
			"from printfax_queue pq, credit_request cr where pq.job_id = ? and pq.request_id = cr.request_id";
			queryTmp2.prepareStatement(sql);
			queryTmp2.setInt(1, jobID);
			queryTmp2.executePreparedQuery();
		} catch (Exception e) {
			main.log(0, e.toString());
		}

		if (!queryTmp2.next()) {
			try {
				// 1/24/07 ChrisN CL140795 Replaced with SQL using bind variable for Triad performance enhancement
				//SQLUpdate.RunUpdateStatement(con,
				//		"delete from printfax_queue_values where job_id = "
				//				+ jobID);
				//SQLUpdate.RunUpdateStatement(con,
				//		"delete from printfax_queue where job_id = " + jobID);
				sql = "delete from printfax_queue_values where job_id = ?";
        ps = con.prepareStatement(sql);
        ps.setInt(1, Integer.parseInt(jobID));
        ps.execute();
        ps.close();

				sql = "delete from printfax_queue where job_id = ?";
        ps = con.prepareStatement(sql);
        ps.setInt(1, Integer.parseInt(jobID));
        ps.execute();
        ps.close();
			} catch (Exception e) {
				main.log(0, e.toString());
			}
			finally {
					try { if (ps != null) ps.close();} catch (Exception e1) {e1.printStackTrace();}
			}
		} else {

			Query queryTmp = new Query(con);

			boolean errorOccurred = false;
			String request_id = "0";
			String evaluator_id = "0";
			String product_id = "1"; // INDIRECT AUTO
			String document_name = "Document name not found";
			String document_id = "0";
			boolean badJobInfo = false;

			try {

				sql = "select pq.request_id,cr.evaluator_id,pq.document_id,cr.product_id " +
				"from printfax_queue pq, credit_request cr where pq.job_id = ? and pq.request_id = cr.request_id";
				queryTmp.prepareStatement(sql);
				queryTmp.setInt(1, jobID);
				queryTmp.executePreparedQuery();

				if (queryTmp.next()) {
					request_id = queryTmp.getColValue("request_id", "0");
					evaluator_id = queryTmp.getColValue("evaluator_id", "0");
					product_id = queryTmp.getColValue("product_id", "1");
					document_id = queryTmp.getColValue("document_id", "0");
				}

				if (request_id.equals("0")) {
					main
							.log(
									0,
									"ERROR: Can't update job to success status, can't find request_id in job row, job ID: "
											+ jobID + ", request_id set to 0");
					badJobInfo = true;
				}

				sql = "select cd.description_txt from config_documents cd where cd.document_id = ? and evaluator_id = ? ";
				queryTmp.prepareStatement(sql);
				queryTmp.setInt(1, document_id);
				queryTmp.setInt(2, evaluator_id);
				queryTmp.executePreparedQuery();
				if (queryTmp.next()) {
					document_name = queryTmp.getColValue("description_txt",
							"Document name is null");
				} else {
					main
							.log(
									0,
									"ERROR: Document ID: "
											+ document_id
											+ " in PF job, not found in config_documents table for job: "
											+ jobID);
					badJobInfo = true;
				}

				// UPDATE THE PRINTFAX QUEUE JOB WITH THE STATUS

				if (job_type_txt.equals("BATCH")) {

					/*
					 * Batch jobs will update the hist row as PRINTED to
					 * indicate that the doc was printed by RightFax. The user
					 * will use the Lender Print Tool to delete the batch when
					 * they are satisfied that all documents in the batch have
					 * printed.
					 */

					// UPDATE THE PRINTFAX QUEUE JOB WITH THE STATUS
					// 1/24/07 ChrisN CL140795 Replaced with SQL using bind variable for Triad performance enhancement
					//SQLUpdate.RunUpdateStatement(con,
					//		"update printfax_queue set status_id = 'PRINTED', error_txt = NULL"
					//				+ ", finished_dt = sysdate where job_id = "
					//				+ jobID);
					sql = "update printfax_queue set status_id = 'PRINTED', error_txt = NULL, finished_dt = sysdate where job_id = ?";
					ps = con.prepareStatement(sql);
					ps.setInt(1, Integer.parseInt(jobID));
					ps.execute();
					ps.close();

					//SQLUpdate
					//		.RunUpdateStatement(
					//				con,
					//				"update credit_req_doc_history "
					//						+ "set status_id = 'SUCCESS', print_date = sysdate, error_txt = NULL where job_id = "
					//						+ jobID);
					sql = "update credit_req_doc_history set status_id = 'SUCCESS', print_date = sysdate, error_txt = NULL where job_id = ?";
					ps = con.prepareStatement(sql);
					ps.setInt(1, Integer.parseInt(jobID));
					ps.execute();
					ps.close();


					// POST A SUCCESS COMMENT TO THE JOURNAL

					/*
					 * spec wants journal entry instead
					 * main.postCommentEvent(29, // document comment request_id,
					 * "Printed document", document_name);
					 */

					/*
					 * Post a journal event for this app to indicate that a this
					 * document was printed
					 */

					try {

						int reqID = Integer.parseInt(request_id);
						JournalEvents journalEvents = new JournalEvents(con,
								null);
						// 41-batch print
						journalEvents.addJournal(reqID, 41, "Batch print: "
								+ document_name, "SYSTEM");
					} catch (Exception e) {
						main.log(0, "Can't post journal event for jobID:"
								+ jobID + " request_id:" + request_id + " err="
								+ e.toString());
					}

					String response = "", sURL = "";

					/*
					 * Wei Ma 9/14/04 update early disclosure doc to see if
					 * activity 38 can be marked as complete and update Alert
					 * status for early disclosure.
					 */
					if (main.sEarlyDiscURL.length() == 0)
						main
								.log(
										0,
										"contract_completion_check_url in ini file is empty, can't update early disclosure");
					else
						try {
							sURL = main.sEarlyDiscURL + request_id
									+ "&user_id=SYSTEM&evaluator_id="
									+ evaluator_id+ "&closeSession=true";
							main.log(5, "Posting for early disclosure to: "
									+ sURL);
							PostRequest postRequest = new PostRequest();
							response = postRequest.post(sURL, "", 30);// timeout
							// 30
							// secs
							main.log(5,
									"Posting for early disclosure done, response="
											+ response);
						} catch (Exception e) {
							// not serious enough to stop, just log error
							main.log(0, "WARNING: Can not post to: " + sURL
									+ " , error=" + e.toString());
						}

					response = "";
					sURL = "";

					/*
					 * GL. 5/6/04 run completion rules for closing doc to see if
					 * activity 22 - Doc Gen can be marked as complete when the
					 * last doc in a closing package is printed.
					 */
					if (main.sRunRulesURL.length() == 0)
						main
								.log(
										0,
										"contract_completion_check_url in ini file is empty, can't run rules for closing docs");
					else
						try {
							sURL = main.sRunRulesURL + request_id
									+ "&user_id=SYSTEM&evaluator_id="
									+ evaluator_id+ "&closeSession=true";
							main.log(5, "Posting for completion rules to: "
									+ sURL);
							PostRequest postRequest = new PostRequest();
							response = postRequest.post(sURL, "", 30);// timeout
							// 30
							// secs
							main.log(5,
									"Posting for completion rules done, response="
											+ response);
						} catch (Exception e) {
							// not serious enough to stop, just log error
							main.log(0, "WARNING: Can not post to: " + sURL
									+ " for completion rules, error="
									+ e.toString());
						}

				} else {

					// FAX JOB

					// can now remove the job to clean the queue clean

					if (!badJobInfo) {

						// 1/24/07 ChrisN CL140795 Replaced with SQL using bind variable for Triad performance enhancement
						//SQLUpdate.RunUpdateStatement(con,
						//		"delete from printfax_queue_values where job_id = "
						//				+ jobID);

						//SQLUpdate.RunUpdateStatement(con,
						//		"delete from printfax_queue where job_id = "
						//				+ jobID);
						sql = "delete from printfax_queue_values where job_id = ?";
		        ps = con.prepareStatement(sql);
		        ps.setInt(1, Integer.parseInt(jobID));
		        ps.execute();
		        ps.close();

						sql = "delete from printfax_queue where job_id = ?";
		        ps = con.prepareStatement(sql);
		        ps.setInt(1, Integer.parseInt(jobID));
		        ps.execute();
		        ps.close();
					} else {
						// 1/24/07 ChrisN CL140795 Replaced with SQL using bind variable for Triad performance enhancement
						//SQLUpdate
						//		.RunUpdateStatement(
						//				con,
						//				"update printfax_queue set status_id = 'SUCCESSBUT', error_txt = '"
						//						+ "Failed to get request_id data from job row, can't complete status update, see log',finished_dt = sysdate where job_id = "
						//						+ jobID);
						sql = "update printfax_queue set status_id = 'SUCCESSBUT', error_txt = 'Failed to get request_id data from job row, cannot complete status update, see log', finished_dt = sysdate where job_id = ?";
						ps = con.prepareStatement(sql);
						ps.setInt(1, Integer.parseInt(jobID));
						ps.execute();
						ps.close();
					}

					// UPDATE THE DOC HISTORY ROW WITH THE STATUS
          // 1/24/07 ChrisN CL140795 Replaced with SQL using bind variable for Triad performance enhancement
					//SQLUpdate
					//		.RunUpdateStatement(
					//				con,
					//				"update credit_req_doc_history "
					//						+ "set status_id = 'SUCCESS', print_date = sysdate, error_txt = NULL where job_id = "
					//						+ jobID);
					sql = "update credit_req_doc_history set status_id = 'SUCCESS', print_date = sysdate, error_txt = NULL where job_id = ?";
					ps = con.prepareStatement(sql);
					ps.setInt(1, Integer.parseInt(jobID));
					ps.execute();
					ps.close();

					// POST A SUCCESS COMMENT TO THE JOURNAL
					try {
						main.postCommentEvent(19, // Fax Message
								request_id, "Document Faxed Successfully",
								document_name);
					} catch (Exception e) {
						main.log(0, "Can't post comment for jobID:" + jobID
								+ " request_id:" + request_id + " err="
								+ e.toString());
					}
					/*
					 * Post a journal event for this app to indicate that a this
					 * document was faxed
					 */

					try {
						String msg = "Faxed: " + document_name;
						int eventID = 42;
						// fax transmittals will be the only fax that has the
						// move_to_failed
						// flag set
						if (move_to_failed_flg.equals("1")) {
							msg = "Sent: " + document_name;
							eventID = 45; // transmittal
						}
						int reqID = Integer.parseInt(request_id);
						JournalEvents journalEvents = new JournalEvents(con,
								null);
						journalEvents.addJournal(reqID, eventID, msg, "SYSTEM");
					} catch (Exception e) {
						main.log(0, "Can't post journal event for jobID:"
								+ jobID + " request_id:" + request_id + " err="
								+ e.toString());
					}

				} // fax

			} catch (Exception e) {
				main.log(0,
						"ERROR: Can't update job to success state, job ID: "
								+ jobID + " reason: " + e.toString());
				errorOccurred = true;
			}
			finally {
					try { if (ps != null) ps.close();} catch (Exception e1) {e1.printStackTrace();}
			}


			if (!errorOccurred) {

				if (unlock_app_flg.equals("1")) {

					// unlcok the app

					try {
						appLockingManager.releaseLockOnApp((long) Integer
								.parseInt(request_id));
					} catch (Exception e) {
						// already marked as success so can only log the message
						main.log(0,
								"ERROR: Can't release lock on app for job: "
										+ jobID + " reason: " + e.toString());
					}
				}

				// GL & CC. 01/26/04 If this FAX previously failed and has a
				// failed transmittal alert then remove the alert so they
				//can continue processing it
				if (job_type_txt.equals("FAX")) {
					try {
						//Remove the alert
						int seq_id = 0;
						int document_name_index;
						int document_id_index;
						String detail_txt = "";
						String documentId = "";
						Query query = new Query(con);
						sql = "select seq_id as SEQ_ID,DETAIL_TXT from credit_request_alerts where request_id = ? and status_txt = 'open' and detail_txt like 'Failed Fax Transmittal%'";
						query.prepareStatement(sql);
						query.setInt(1, request_id);
						query.executePreparedQuery();
						try {
							while (query.next()) {
								detail_txt = query.getColValue("DETAIL_TXT");
								document_name_index = (int)(detail_txt.indexOf("document_name"));
								document_id_index = (int) (detail_txt.indexOf("document_id"));
								seq_id = (int) Integer.parseInt(query
										.getColValue("SEQ_ID"));
								if(document_id_index != -1){
									documentId = (detail_txt.substring((document_id_index + 12),document_name_index)).trim();
								}

								if(documentId.equalsIgnoreCase(document_id)){
									Alert alert = Alert.getAlert((int) Integer
											.parseInt(request_id), seq_id, con);
									alert.setCLOSE_DT(new Date());
									alert.setSTATUS_TXT("closed");
									alert.updateAlert();
								}
							}
						} catch (Exception e) {
						}
					} catch (Exception e) {
						// already marked as success so can only log the message
						main.log(0,
								"ERROR: Can't remove Failed Transmittal alert from app for job: "
										+ jobID + " reason: " + e.toString());
					}

				}

			} // !errorOccurred

			return;
		}
	} // updateJobAsSuccess

	private void pullBackIfInFailedTask(String request_id, String document_id,
			String evaluator_id) throws Exception {

		// GL. 01/26/04 If this FAX previously failed and is in the
		// failed transmittal task then pull it back out and move it
		// to the previous task group, task_id, and user so they can continue
		// processing it

		Query query = new Query(con);
		String sql = "";
		PreparedStatement ps = null;

		// Only do this if its a transmittal type doc

		sql = "select evaluator_id from config_evaluator_documents "
			+ " where evaluator_id = ? "
			+ " and document_id = ? and (category_id = 'MANUAL_DECISION_TRANSMITTAL' OR category_id = 'AUTO_DECISION_TRANSMITTAL')";
		query.prepareStatement(sql);
		query.setInt(1, evaluator_id);
		query.setInt(2, document_id);
		query.executePreparedQuery();
		if (!query.next())
			return;

		// Its a transmittal, soo now see if the app is in the failed
		// transmittal task

		sql = "select request_id from credit_request where request_id = ? and task_id = ? and "
			+ "task_group_id = ? ";

		query.prepareStatement(sql);
		query.setInt(1, request_id);
		query.setString(2, ApplicationIDs.tsk_failedtransmittal);
		query.setString(3, ApplicationIDs.tsk_grp_system);
		query.executePreparedQuery();

		if (!query.next())
			return;

		// pull it back if previous values are avail

		sql = "select previous_task_id, previous_team_id, previous_user_id, "
			+ "previous_task_group_id from credit_request where request_id = ? ";

		query.prepareStatement(sql);
		query.setInt(1, request_id);
		query.executePreparedQuery();

		query.next();

		String previous_task_id, previous_team_id, previous_user_id, previous_task_group_id;

		previous_task_id = query.getColValue("previous_task_id", "");
		previous_team_id = query.getColValue("previous_team_id", "");
		previous_user_id = query.getColValue("previous_user_id", "");
		previous_task_group_id = query
				.getColValue("previous_task_group_id", "");

		if (previous_task_id.length() == 0)
			throw new Exception("Previous task id is empty");
		if (previous_team_id.length() == 0)
			throw new Exception("Previous team id is empty");
		if (previous_task_group_id.length() == 0)
			throw new Exception("Previous task group is empty");

		// good to go, so pull it back

		if (!workFlowManager.setNewTaskandTaskGroup((long) Integer
				.parseInt(request_id), previous_task_id,
				previous_task_group_id, previous_user_id)) // this will only set
			// audit_update_user_id
			throw new Exception("error recorded in workFlowMgr");

		try {
		// 1/24/07 ChrisN CL140795 Replaced with SQL using bind variable for Triad performance enhancement
		//SQLUpdate.RunUpdateStatement(con, "update credit_request "
		//		+ "set assigned_user_id = '" + previous_user_id
		//		+ "', assigned_team_id = " + previous_team_id
		//		+ " where request_id = " + request_id);
			sql = "update credit_request set assigned_user_id = ?, assigned_team_id = ? where request_id = ?";
			ps = con.prepareStatement(sql);
			ps.setString(1, previous_user_id);
			ps.setInt(2, Integer.parseInt(previous_team_id));
			ps.setInt(3, Integer.parseInt(request_id));
			ps.execute();
			ps.close();
		}
		catch (Exception e) {
		}
		finally {
			try { if (ps != null) ps.close();} catch (Exception e1) {e1.printStackTrace();}
		}

		applicationStatusManager.calcNewApplicationStatus((long) Integer
				.parseInt(request_id), Integer.parseInt(evaluator_id));

	} // pullBackIfInFailedTask

} // MonitorThread

