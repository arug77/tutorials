package com.cmsinc.origenate.printfax;

import java.io.*;

import javax.activation.FileDataSource;

import net.docusign.wsclient.WebserviceCredentials;
import net.docusign.wsclient.APIServiceStub;
import net.docusign.wsclient.ClientConfiguration;

import net.docusign.www.api._3_0.*;

import org.apache.axiom.attachments.ConfigurableDataHandler;
import org.apache.axis2.databinding.types.NonNegativeInteger;
import org.apache.axis2.databinding.types.PositiveInteger;
import org.apache.axis2.AxisFault;


import com.cmsinc.origenate.util.LogMsg;
import com.cmsinc.origenate.util.Query;
import com.cmsinc.origenate.doc.GenJob;
import com.cmsinc.origenate.util.IniFile;
import com.cmsinc.origenate.util.COLEncrypt;
import com.cmsinc.origenate.util.OWASPSecurity;

import java.sql.*;


public class DocuSign  {

   Connection con;
   LogMsg log_obj;
   int i_dbg_level;

   // these are used to determine the Docusign URL to post to, demo or prod. Set in initializeAxis()
   static java.lang.Object critsec = new java.lang.Object();
   static boolean URLestablished = false;
   static StringBuffer docusignURL = new StringBuffer();
          

   private APIServiceStub wsApi;

   public void DocuSign() {}


   /////////////////////////////////////////////////////////////

private void initializeAxis(String evaluator_id) throws Exception {


   Query query = new Query(con);
   String sql="";
   
   //Pwd Encryption
   String sinifile = "";
   IniFile ini = null;
   String iniSql = "SELECT PATH_TXT FROM ORIGENATE_INI";	
				
   query.prepareStatement(iniSql);
   query.executePreparedQuery();
   if(query.next()) {
	sinifile = query.getColValue("PATH_TXT","");
	ini = new IniFile();
	ini.readINIFile(sinifile);
	}

   synchronized (critsec) { // this code must be synchronized because multiple threads might be trying to initialize axis at the same time

      if (!URLestablished) { // get the docusign url on the first call so we don't have to hit the db each time.

         sql="select url_txt from config_esign_vendors where evaluator_id = ? and esign_vendor_id = 1";
         log_obj.FmtAndLogMsg("Establishing Docusign URL...", i_dbg_level,5);
         query.prepareStatement(sql);
         query.setInt(1, Integer.parseInt(evaluator_id));
         query.executePreparedQuery();
         if (!query.next()) throw new Exception("config_esign_vendors row not found for vendor 1, evaluator: "+evaluator_id+", can't get docusign URL"); 
         if (query.getColValue("url_txt")==null) throw new Exception("URL_TXT not set in config_esign_vendors table");
         docusignURL.append(query.getColValue("url_txt"));

         log_obj.FmtAndLogMsg("Docusign URL: "+query.getColValue("url_txt"), i_dbg_level,5);
         URLestablished = true;
      } // get docusign URL


   }  // end sync code



   // first need to adjust axis2.xml and client.properties to include the guid acct ID and user name from the config_esign_vendors table

   sql="select docusign_acct_guid_txt,docusign_user_guid_txt,docusign_password_txt,docusign_email_addr_txt from config_esign_vendors where evaluator_id = ? and esign_vendor_id = 1";
   query.prepareStatement(sql);
   query.setInt(1, Integer.parseInt(evaluator_id));
   query.executePreparedQuery();
   String acctGUID="notavail";
   String userGUID="notavail";
   String password="notavail";
   String emailAddr="notavail";
   if (query.next()) {
      acctGUID=query.getColValue("docusign_acct_guid_txt", "notavail");
      userGUID=query.getColValue("docusign_user_guid_txt", "notavail");
      password=query.getColValue("docusign_password_txt", "notavail");
      emailAddr=query.getColValue("docusign_email_addr_txt", "notavail");
	  
	  password = COLEncrypt.sCfgPwdDecrypt(password);
   }

   // adjust axis2.xml first
   String axis = readFile("conf/axis2.xml");
   axis = axis.substring(0,axis.indexOf("<user>")+6)+userGUID+axis.substring(axis.indexOf("</user>"));
   writeFile("conf/axis2.xml",axis);
   // now write client.properties
   String str="#Do not modify these values as they are replaced by the 'ant configure' command.\n"; 
   str+="axis2.accountId="+acctGUID+"\n";
   str+="axis2.username="+userGUID+"\n";
   str+="axis2.password="+password+"\n";
   str+="user.email="+emailAddr+"\n";

   writeFile("conf/client.properties",str);




   //Reads accountId, username, and password for Docusign webservice.
     ClientConfiguration.getInstance();

     //log_obj.FmtAndLogMsg("initializing wsAPI...", i_dbg_level,5);
     wsApi = new APIServiceStub();
     //log_obj.FmtAndLogMsg("get repository path: "+getAxis2RepositoryLocation(), i_dbg_level,5);
     wsApi.setRepositoryPath(getAxis2RepositoryLocation());
     wsApi.init(docusignURL.toString());

     if (wsApi==null) throw new Exception("wsApi is null");

     //log_obj.FmtAndLogMsg("initializing wsAPI...done", i_dbg_level,5);
}

   //////////////////////////////////////////////////////////////

public boolean voidDocument(Connection conn,LogMsg log_obj,int i_dbg_level,String request_id,
                                          String evaluator_id,String document_id) throws Exception {

   
   this.con=conn;
   this.log_obj=log_obj;
   this.i_dbg_level=i_dbg_level;
   boolean errorOccurred=false;

   String envelopeGUID="";
   String seq_id="";
   String sql="";
   PreparedStatement ps = null;

   try {

   log_obj.FmtAndLogMsg("Starting void DocuSign sign request", i_dbg_level,5);
                   
   Query query = new Query(con);

    initializeAxis(evaluator_id);

    String accountId = WebserviceCredentials.getInstance().getAccountId() ;

    /* Find the envelope GUID in the credit_doc_history table for this document so we can void it */

    sql="select seq_id, docusign_envelope_guid_txt from credit_req_doc_history where request_id = ? and document_id  = ? and docusign_envelope_guid_txt is not null order by seq_id desc";
    query.prepareStatement(sql);
    query.setInt(1, Integer.parseInt(request_id));
    query.setInt(2, Integer.parseInt(document_id));
    query.executePreparedQuery();
    if (!query.next())
       throw new Exception("VoidDocument: Can not find envelope GUID in credit_req_doc_history for RID: "+request_id+", document: "+document_id);

    envelopeGUID=query.getColValue("docusign_envelope_guid_txt");
    seq_id=query.getColValue("seq_id");

    //System.out.println("Voiding envelope...");
    VoidEnvelope voidEnvelope = new VoidEnvelope();
    voidEnvelope.setEnvelopeID(envelopeGUID);
    voidEnvelope.setReason("Cancelled by sender");

    VoidEnvelopeResponse voidEnvelopeResponse = wsApi.voidEnvelope(voidEnvelope); 

    //System.out.println("Returned status for voidEnvelope: "+voidEnvelopeResponse.getVoidEnvelopeResult().getVoidSuccess());

    // status returned is true if void was accepted, false if it was rejected
    errorOccurred = !voidEnvelopeResponse.getVoidEnvelopeResult().getVoidSuccess();

    // update the doc history row to indicate success or failure

    sql = "update credit_req_doc_history set status_id = 'VOIDED', print_date = sysdate where seq_id = ?";
    if (errorOccurred)
       sql = "update credit_req_doc_history set status_id = 'VOID FAILED', print_date = sysdate, error_txt = 'Void request rejected by DocuSign' where seq_id = ?";
    try	{
		ps = con.prepareStatement(sql);
		ps.setInt(1, Integer.parseInt(seq_id));
		ps.execute();
		ps.close();
	} 
	catch (Exception e) {
		e.printStackTrace();
	}
	finally {
		try{ if(ps != null) ps.close(); }catch(Exception e1){e1.printStackTrace();}
	}	
	

   }
   catch (Exception e) {
      errorOccurred=true;
      if (seq_id.length()>0) {
		  String errorText = e.toString().replace('\'',' ');
	      // TTP 324955 Security Fortify Scan
          sql = "update credit_req_doc_history set status_id = 'VOID FAILED', print_date = sysdate, error_txt = ? where seq_id = ?";
          //System.out.println(sql);
          try {
			  ps = con.prepareStatement(sql);
			  ps.setString(1, OWASPSecurity.validationCheck(errorText,OWASPSecurity.SQLPARAMSTRING));
			  ps.setInt(2, Integer.parseInt(seq_id));
			  ps.execute();
			  ps.close();
		  } 
		  catch (Exception e2) {
			 e2.printStackTrace();
		  }
		  finally {
			 try{ if(ps != null) ps.close(); }catch(Exception e1){e1.printStackTrace();}
		  }
      }
   }


    //System.out.println("voidDocument() successfull");

    log_obj.FmtAndLogMsg("End void DocuSign sign request, void status: "+!errorOccurred, i_dbg_level,5);

    return false; // so printfax_queue job can be deleted

} // end voidDocument


public String sendDocument(Connection conn,LogMsg log_obj,int i_dbg_level,String pdfFileName,String request_id,
                                          String evaluator_id,String jobID,String document_id,String templateGUID) throws Exception {

   
   this.con=conn;
   this.log_obj=log_obj;
   this.i_dbg_level=i_dbg_level;

   String envelopeGUID="";

   log_obj.FmtAndLogMsg("Starting sendDocument()", i_dbg_level,5);
                   
   Query query = new Query(con);

    initializeAxis(evaluator_id);

    String accountId = WebserviceCredentials.getInstance().getAccountId() ;


    //
    // Envelope wide information
    //

    // we need to get the subject email text that is embedded in the email sent to the customer.
    // these can be found in the docgen config


    GenJob genJob = new GenJob(con,log_obj);
    Query queryTmp = new Query(con);
    String sql="select subject_txt,subject_query_id,short_email_body_txt from config_esign_delivery where evaluator_id = ? and touchpoint_id = ? and document_id = ? and delivery_method_id = ?";
        queryTmp.prepareStatement(sql);
    queryTmp.setInt(1, Integer.parseInt(evaluator_id));
    queryTmp.setInt(2, Integer.parseInt("55")); // user initiated on-demand touchpoint
    queryTmp.setInt(3, Integer.parseInt(document_id));
    queryTmp.setString(4, "S");
    queryTmp.executePreparedQuery();

    if (!queryTmp.next()) {
        throw new Exception("Document not found in config_esign_delivery table");
    }

    String subject_txt=queryTmp.getColValue("subject_txt","");
    String subject_query_id=queryTmp.getColValue("subject_query_id","");
    String emailBody=queryTmp.getColValue("short_email_body_txt","Please sign");

    // if a query id is specified then execute it to build the subject line
    /****** now getting subject line from printfax_queue, it was set by the UI
    if (subject_query_id.length()>0) {
               query = genJob.buildAndExecuteQuery(con, subject_query_id, request_id, null);
               if (query.next()) subject_txt=query.getColValue(1); // first col is the value of the subject line

    }
    ****************/

    sql="select email_subject_txt from printfax_queue where job_id = ?";
    queryTmp.prepareStatement(sql);
    queryTmp.setInt(1, Integer.parseInt(jobID));
    queryTmp.executePreparedQuery();
    queryTmp.next();
    subject_txt=queryTmp.getColValue("email_subject_txt","");



    if (subject_txt==null || subject_txt.length()==0) 
          throw new Exception("Subject line not defined in config_esign_delivery");


    EnvelopeInformation envelopeInfo = new EnvelopeInformation();
    envelopeInfo.setAccountId(accountId);
    envelopeInfo.setEmailBlurb(emailBody);
    envelopeInfo.setSubject(subject_txt);

    CreateEnvelopeFromTemplates createEnvelopeFromTemplates = new CreateEnvelopeFromTemplates();

    createEnvelopeFromTemplates.setActivateEnvelope(true);
    createEnvelopeFromTemplates.setEnvelopeInformation(envelopeInfo);
    createEnvelopeFromTemplates.setRecipients(handleRecipients(jobID)); // get the list of recipients

    FileDataSource fileDataSource = new FileDataSource(pdfFileName);

    createEnvelopeFromTemplates.setTemplateReferences(handleTemplates(pdfFileName,templateGUID,jobID,evaluator_id,document_id,fileDataSource));

    CreateEnvelopeFromTemplatesResponse sendResponse = wsApi.createEnvelopeFromTemplates(createEnvelopeFromTemplates);

    //assertNotNull(sendResponse);

    ArrayOfRecipientStatus recipientStatuses = sendResponse.getCreateEnvelopeFromTemplatesResult( ).getRecipientStatuses();
    //assertEquals(recipientStatuses.getRecipientStatus().length, 1);
    //assertEquals(RecipientStatusCode._Sent, recipientStatuses.getRecipientStatus()[0].getStatus().getValue());
    //System.out.println("Recipient 1 status: "+recipientStatuses.getRecipientStatus()[0].getStatus().getValue());

    String envelopeId = sendResponse.getCreateEnvelopeFromTemplatesResult( ).getEnvelopeID();
    log_obj.FmtAndLogMsg("EnvelopeID: "+envelopeId, i_dbg_level,5);

    //Check status of Envelope.
    RequestStatus statusRequest = new RequestStatus();
    statusRequest.setEnvelopeID(envelopeId);

    RequestStatusResponse statusResponse = wsApi.requestStatus(statusRequest);


    //System.out.println("EnvelopeID: "+statusResponse.getRequestStatusResult().getEnvelopeID());
    envelopeGUID=statusResponse.getRequestStatusResult().getEnvelopeID();

    //System.out.println("Envelope Status code: "+statusResponse.getRequestStatusResult().getStatus( ).getValue());


    // need to close the file stream so it can be deleted after the envelope is sent
    /* This does not work because the file is still being held by docusign
    InputStream is = fileDataSource.getInputStream();
    try { is.close(); } catch (Exception ex) {}
    OutputStream os = fileDataSource.getOutputStream();
    try { os.close(); } catch (Exception ex) {}
    */

    log_obj.FmtAndLogMsg("sendDocument() successfull", i_dbg_level,5);



    return envelopeGUID;

} // end sendDocument


 protected String getAxis2RepositoryLocation() {
     return (new File("").getAbsolutePath()).concat(File.separator);
 }

private ArrayOfTemplateReference handleTemplates(String pdfFileName,String templateGUID,String jobID,String evaluator_id,String document_id,FileDataSource fileDataSource) throws Exception {

    ArrayOfTemplateReferenceRoleAssignment roleAssignments = new ArrayOfTemplateReferenceRoleAssignment();


     // the list of recipients are in the printfax_queue_recipients table for this job

      Query query = new Query(con);
      String sql="select recipient_id,email_addr_txt,first_name_txt,last_name_txt from printfax_queue_recipients where job_id = ? order by recipient_id";
      query.prepareStatement(sql);
      query.setInt(1, Integer.parseInt(jobID));
      query.executePreparedQuery();

      String roleName="";
      int i=0,j=0;
      char recipientID=' ',lastRecipientID='*';

      while (query.next()) {

          j++;
          TemplateReferenceRoleAssignment roleAssignment = new TemplateReferenceRoleAssignment();
          roleAssignment.setRecipientID(new PositiveInteger(String.valueOf(j)));  // this will match the recipientID in the recipients array from handleRecipients()

          recipientID=query.getColValue("recipient_id").charAt(0);

          if (lastRecipientID != recipientID) i=0;
          i++; // increment recipient id instance so it can be appended to role name for repeaters like Co-Signer1, Co-Signer2, etc

          switch (recipientID) {

          case '0' : roleName="Applicant"; break;
          case '1' : roleName="Co-Applicant"+String.valueOf(i); break;
          case '2' : roleName="Co-Signer"+String.valueOf(i); break;
          case '3' : roleName="Business"; break;
          case '8' : roleName="Guarantor"+String.valueOf(i); break;
                        
          default :
                   throw new Exception("Unsupported recipient_id in printfax_queue_recipients: "+query.getColValue("recipient_id"));
          }

          roleAssignment.setRoleName(roleName);

          roleAssignments.addRoleAssignment(roleAssignment);

      } // recipients

    //
    // load the file
    /* This is used if we are loading a local template
    FileDataSource dataSource = new FileDataSource("docs/test_template.dpd");
    StringBuffer sb = new StringBuffer();
    BufferedReader in = new BufferedReader(new FileReader(dataSource.getFile().getAbsolutePath()) );
    String str;
    while ((str = in.readLine()) != null) {
    sb.append(str);
    }
    in.close();
   ***/

    TemplateReference templateReference = new TemplateReference();

    // used if we are loading a local template from disk
    //templateReference.setTemplateLocation(TemplateLocationCode.SOAP);
    //templateReference.setTemplate(sb.toString());

    templateReference.setTemplateLocation(TemplateLocationCode.Server);
    templateReference.setTemplate(templateGUID);

    // load our document
    Document document = new Document();
    document.setID(new PositiveInteger("1"));

    // need to set the document name
    sql="select description_txt from config_documents where evaluator_id = ? and document_id = ?";
    query.prepareStatement(sql);
    query.setInt(1, Integer.parseInt(evaluator_id));
    query.setInt(2, Integer.parseInt(document_id));
    query.executePreparedQuery();
    query.next(); 
    String docName=query.getColValue("description_txt","Document");
    docName=docName.replace('\'',' '); // remove single quotes
    document.setName(docName);

    //document.setPDFBytes(new ConfigurableDataHandler(new FileDataSource("docs/slowTTY.pdf")));
    document.setPDFBytes(new ConfigurableDataHandler(fileDataSource));
    templateReference.setDocument(document);

    templateReference.setRoleAssignments(roleAssignments);

    ArrayOfTemplateReference result = new ArrayOfTemplateReference();
    result.addTemplateReference(templateReference);
    return result;
} // end  ArrayOfTemplateReference

private ArrayOfRecipient1 handleRecipients(String jobID) throws Exception {

     // the list of recipients are in the printfax_queue_recipients table for this job

      Query query = new Query(con);
      String sql="select recipient_id,email_addr_txt,first_name_txt,last_name_txt from printfax_queue_recipients where job_id = ? order by recipient_id";
      query.prepareStatement(sql);
      query.setInt(1, Integer.parseInt(jobID));
      query.executePreparedQuery();

      ArrayOfRecipient1 recipientArray = new ArrayOfRecipient1();

      int j=0;

      while (query.next()) {

           j++;
           Recipient recipient = new Recipient();
           recipient.setID(new PositiveInteger(String.valueOf(j)));
           //recipient.setEmail(WebserviceCredentials.getInstance().getUserEmail());
           recipient.setEmail(query.getColValue("email_addr_txt"));
           recipient.setRequireIDLookup(false);
           recipient.setType(RecipientTypeCode.Signer);
           recipient.setUserName(query.getColValue("first_name_txt")+" "+query.getColValue("last_name_txt")); // ie. 'Glenn Leyba'

           RecipientSignatureInfo sigInfo = new RecipientSignatureInfo();
           sigInfo.setSignatureName(query.getColValue("first_name_txt")+" "+query.getColValue("last_name_txt")); // ie. 'Glenn Leyba' 
           sigInfo.setSignatureInitials(query.getColValue("first_name_txt").substring(0,1)+query.getColValue("last_name_txt").substring(0,1));  // ie. GL
           sigInfo.setFontStyle(FontStyleCode.BradleyHandITC) ;
           recipient.setSignatureInfo(sigInfo);

           recipientArray.addRecipient(recipient);

      } // while more recipients

     return recipientArray;
} // end ArrayOfRecipient1

  public String readFile(String fileName) throws Exception {

      BufferedReader textFile = null; 

      File file = new File(fileName);
      if (!file.exists()) throw new Exception(fileName+" does not exist");
      long len=file.length();
      char buf[] = new char[(int)len];

      int rc;
      // open file for input
      try {  textFile = new BufferedReader(new InputStreamReader(new FileInputStream(fileName))); }
      catch(FileNotFoundException e) { throw e; }

      rc=textFile.read(buf,0,(int)len);
      textFile.close();
      if (rc!=(int)len) throw new Exception("Error reading file, rc="+rc);

      return(new String(buf));

  } // readFile


  public  void writeFile(String fileName,String str) throws Exception {
      PrintWriter out=null;
      out = new PrintWriter(new FileWriter(fileName));
      out.print(str);
      out.flush();
      out.close();
  }

} // DocuSign

