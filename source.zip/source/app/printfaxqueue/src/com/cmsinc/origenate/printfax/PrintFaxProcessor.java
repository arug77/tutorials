package com.cmsinc.origenate.printfax;

import java.io.File;
import java.sql.*;
import java.util.Enumeration;
import java.util.Vector;

import com.cmsinc.origenate.event.CommentEvents;
import com.cmsinc.origenate.event.JournalEvents;
import com.cmsinc.origenate.util.COLEncrypt;
import com.cmsinc.origenate.util.IniFile;
import com.cmsinc.origenate.util.LogMsg;
import com.cmsinc.origenate.util.OWASPSecurity;

/*
 * PrintFaxProcessor.java
 *
 * Created on July 18, 2002
 *
 * @author Glenn Leyba
 *
 * @version
 *
 * The PrintFaxProcessor works off the printfax_queue table to process jobs
 * destined for CentralPro
 *
 * Currently, only two types of requests are put on the queue: 1) Batch print
 * requests for nightly letters (print only, never fax) and, 2) Fax requests
 * submitted either online by a user using the print/fax icon OR a fax request
 * that was automatically generated as a transmittal to an originator after a
 * decision has been made.
 *
 *
 */
public class PrintFaxProcessor extends Object {

	/*
	 * Version history
	 *
	 * 1.0 - Initial release
	 */

	static String VERSION = "1.2";

	//1.2 - Support for composing pdf docs with itext and creating a single batch file

	//1.1 - added calls to completion check post in monitor thread

	//*********Added TNS Entry value for custom entries to get around firewalls
	//If tnsEntry is not blank in the INI, it will be used instead of host,
	// port and SID
	// info
	String tnsEntry = "";

	//*********Added TNS Entry value for custom entries to get around firewalls


        File eojFile = null; // 162583 - if this file is specified with the -z parm then the presence of this file will cause the pgm to shutdown gracefully


	String sHost = "";

	String sRunRulesURL = "";

	String sEarlyDiscURL = "";

	String sSIDname = "";

	String sUser = "";

	String sPort = "";

	String sPass = "";

	String sIniFile = "";

	String central_pro_input_dir = "";

	String central_pro_output_dir = "";

	String central_pro_error_dir = "";

	String central_pro_forms_dir = "";

	String central_pro_success_dir = "";

	String purge_printfax_queue_older_than_days = "";

	String faxPhoneNumberPrefix = "";


        String historyDocsURL ="";

	String central_pro_server_id = "DEFAULT";

	String central_pro_wait_limit_secs = "30";


	long lSleepSecs = 2;

	//GL.
	int querySleep = 2;

	int queryQueueEmptySleep = 2;

	//GL.
	int maxThreads = 1;

	int runningThreads = 1;

	int i_dbg_level = 0;

	IniFile ini = new IniFile();

	Vector processThreads = null;

	LogMsg log_obj = new LogMsg();

	MonitorThread monitorThread = null;

	CleanupThread cleanupThread = null;

	CommentEvents commentEvents = null;

	JournalEvents journalEvents = null;

        boolean useiTextLibrary = false;

	public PrintFaxProcessor() {
	}

	/////////////////////////////////////////////////////////////////////////////////

	static public void main(String args[]) {

		PrintFaxProcessor pqp = new PrintFaxProcessor();
		try {
			pqp.run(args);
		} catch (Exception e) {
		} // error already reported

		System.exit(0);
	}

	///////////////////////////////////////////////////////////////////////////////////////

	void run(String args[]) throws Exception {

		String /*select = "",*/queueSelect = "";
		Connection con = null;
		boolean allThreadsDisabled = false;
		String pwd;

		log(0, "PrintFaxProcessor initializing..."); // to stderr

		GetArgs(args, log_obj);


		String sConStr = "";

		// sConStr should be something like:
		// "jdbc:oracle:thin:@172.16.17.108:1521:cmsiprod"
		sConStr = "jdbc:oracle:thin:@";
		if (tnsEntry.equals("")) {
			sConStr = sConStr + sHost + ":" + sPort + ":" + sSIDname;
		} else {
			sConStr = sConStr + tnsEntry;
		}

		pwd = COLEncrypt.sDecrypt(sPass);

		//
		// This loop will force the program to continue retrying connecting to
		// the db
		// if an exception occurs from here down into the main loop
		//
                PreparedStatement ps = null;

		while (true) {

			try {





				// Load Oracle driver
				DriverManager
						.registerDriver(new oracle.jdbc.OracleDriver());

				log(0, "Connecting to database: " + sConStr);

				// Connect to the Oracle database
				con = DriverManager.getConnection(sConStr, sUser, pwd);

				// log file is opened in GetArgs

				commentEvents = new CommentEvents(con, log_obj);
				journalEvents = new JournalEvents(con, null);

				//   D E L E T E O L D J O B S

				// can't delete old jobs because of batch jobs
				     // GL. 06/20/2014 TTP324723 - we want to re-enable this based on the ini setting.
				deleteOldJobs(con);

				
				// GET CENTRAL PRO SERVER PARMS
				String sql =
					"SELECT input_dir_txt, output_dir_txt, error_dir_txt, success_dir_txt " +
					"FROM config_central_pro_servers " + 
					"WHERE central_pro_server_id = ? AND active_flg = 1";
				ps = con.prepareStatement(sql);
				
				ps.setString(1, "DEFAULT");
				ps.execute();
				
				ResultSet rs = ps.getResultSet();
				
				if (!rs.next()) {
					log(0, "Doc Prep Server: " + central_pro_server_id
							+ " not found in config_central_pro_servers table");
				} else {
					central_pro_input_dir = rs.getString("input_dir_txt");
					log(0, "PDFComposer input_dir = " + central_pro_input_dir); // to
					// log
					// file
					central_pro_output_dir = rs.getString("output_dir_txt");
					log(0, "PDFComposer output_dir = " + central_pro_output_dir); // to
					// log
					// file

                                        /* GL. 12/5/07 We need to calculate the location of the forms dir. It is not specified in config_central_pro_servers table.
                                        We can calculate it by taking the output dir and replacing the last token with 'forms'.
                                        ie. if the output dir is c:\development\output
                                        Then the result would be c:\development\forms
                                        */
                                        central_pro_forms_dir = central_pro_output_dir.substring(0,central_pro_output_dir.lastIndexOf(File.separator));
                                        central_pro_forms_dir += File.separator+"forms"+File.separator;
					log(0, "PDFComposer forms_dir = " + central_pro_forms_dir);


					central_pro_error_dir = rs.getString("error_dir_txt");
					log(0, "PDFComposer error_dir = " + central_pro_error_dir); // to
					// log
					// file
					central_pro_success_dir = rs.getString("success_dir_txt");
					log(0, "PDFComposer success_dir = "
							+ central_pro_success_dir); // to log file
					central_pro_input_dir += File.separator;
					central_pro_output_dir += File.separator;
					central_pro_error_dir += File.separator;
					central_pro_success_dir += File.separator;
				}
				
				rs.close();
				ps.close();
				
				log(0, "PrintFaxProcessor running for Doc Prep Server: "
						+ central_pro_server_id); // to log file

				//  S T A R T M O N I T O R T H R E A D

				//  monitors that status of fax jobs that have not yet completed
				// from
				//  a previous run

				log(0, "Creating threads..."); // to log file

				monitorThread = new MonitorThread(this, sConStr, sUser, pwd, 0,
						log_obj, central_pro_server_id);
				monitorThread.start();

				//  S T A R T C L E A N U P T H R E A D

				//  deletes files from JetForm output dir that do not match up
				//  with a job in the printfax_queue. Happens when a lender
				//  deletes a batch from the printfax_queue with the lender_print
				// tool
				//  but the files owned by jetform still exist

				cleanupThread = new CleanupThread(this, sConStr, sUser, pwd, 0,
						log_obj, central_pro_output_dir);
				cleanupThread.start();

				//  S T A R T P R O C E S S T H R E A D S

				processThreads = new Vector();
				for (int i = 0; i < maxThreads; i++) {
					ProcessThread pt = new ProcessThread(this, sConStr, sUser,
							pwd, i + 1, log_obj, monitorThread);
					processThreads.addElement(pt);
					pt.start();
				}
				runningThreads = maxThreads;

				//  D E F I N E Q U E U E S E L E C T

				//Query printfaxQueue = new Query(con);        
                                // 151351 - glennl 1/15/2010 - multiple server ids are not supported anymore and have not been tested. Hence,
                                // if the calling code does not pass a central_id then we will assume default. Otherwise, if they did not set the
                                // the central_id then this query would not pick them up and they would sit in limbo. 

				queueSelect = "select job_id,status_id,rightfax_job_id,rightfax_url_txt,rightfax_user_id from printfax_queue "
						+ "where (status_id = 'SUBMITTED' or status_id = 'RETRY') and "
						+ " job_id > 0 and when_to_process_dt <= sysdate "
//						+ " and central_pro_server_id = ? "
						+ "order by job_type_txt,status_id,priority_num desc,job_id";
				ps = con.prepareStatement(queueSelect);
  //      			ps.setString(1, central_pro_server_id);
				
				//  M A I N L O O P - until killed or major error


				while (true) {

                                        if (eojFile!=null && eojFile.exists()) {
                                           log(0,"Gracefull shutdown detected, shutting down...");
                                           break;
                                        }

					ps.executeQuery();
					rs = ps.getResultSet();
					
					boolean allThreadsBusy = true;
					ProcessThread processThread = null;
					String job_id, status_id, rightfax_job_id, rightfax_url_txt, rightfax_user_id;

					while (rs.next()) {
						job_id = rs.getString("job_id") == null ? "0" : rs.getString("job_id");

						log(5, "Processing job: " + job_id);
						
						status_id = rs.getString("status_id") == null ? "" : rs.getString("status_id");

						/*
						 * If the status is RETRY and this was a fax job then we
						 * need the following to delete the previous fax job in
						 * the RightFax server before starting a new one
						 */
						rightfax_job_id = rs.getString("rightfax_job_id") == null ? "" : rs.getString("rightfax_job_id");
						rightfax_url_txt = rs.getString("rightfax_url_txt") == null ? "" : rs.getString("rightfax_url_txt");
						rightfax_user_id = rs.getString("rightfax_user_id") == null ? "" : rs.getString("rightfax_user_id");

						if (status_id.equals("RETRY"))
							if (rightfax_job_id.length() > 0
									&& rightfax_url_txt.length() > 0
									&& rightfax_user_id.length() > 0) {

								deleteRightFaxJob(job_id, rightfax_job_id,
										rightfax_url_txt, rightfax_user_id);
							}

						// find free thread to process this job

						allThreadsBusy = true;
						allThreadsDisabled = true;

						while (allThreadsBusy) {

							for (Enumeration e = processThreads.elements(); e
									.hasMoreElements();) {

								processThread = (ProcessThread) e.nextElement();

								if (processThread.busy) {
									if (!processThread.errorOccurred)
										allThreadsDisabled = false;
								} else {
									// thread not busy so assign it this Job ID
									allThreadsBusy = false;
									allThreadsDisabled = false;
									processThread.busy = true;
									processThread.jobID = job_id;
									processThread.workToDo = true;
									break;
								}

							} // for

							if (allThreadsDisabled)
								break; // all threads disabled

							if (allThreadsBusy) {
								// sleep for 1/5 sec before checking if any are
								// free
								try {
									Thread.sleep(200);
								} catch (Exception e) {
								}
                                                                if (eojFile!=null && eojFile.exists()) {
                                                                   //log(0,"Gracefull shutdown detected, shutting down...");
                                                                   break;
                                                                }
							}

						} // while allThreadsBusy

						if (allThreadsDisabled) {
							log(0,
									"All threads are disabled, can't assign work, reinitializing...");
							break;
						}

                                                if (eojFile!=null && eojFile.exists()) {
                                                   log(0,"Gracefull shutdown detected, shutting down...");
                                                   break;
                                                }

					} // while more jobs to process, rs.next()

					rs.close();
					// GL. need to leave this open because it is reused until the loop finishes, 141699 
                                        // ps.close();

					
					if (allThreadsDisabled)
						break; // shutdown

					// sleep for polling period

					try {
						Thread.sleep(lSleepSecs * 1000);
					} catch (Exception e) {
					}

					// wake up and check the queue for work to do

                                        if (eojFile!=null && eojFile.exists()) {
                                           log(0,"Gracefull shutdown detected, shutting down...");
                                           break;
                                        }

				} // while true polling loop that checks the queue for jobs

			} catch (Exception e) {
				log(0, "Major error occurred: " + e.toString());
			       log(0, "Reinitializing processor...");
			} finally {

                               try { ps.close(); } catch (Exception gl) {} // see comment above 141699

				try { if (con != null) con.close();} catch (Exception e1) {e1.printStackTrace();}
				con = null;


			} // finally



                        // shut down process threads
                        try {

                                monitorThread.endThread = true;
                                cleanupThread.endThread = true;

                                for (Enumeration e = processThreads.elements(); e.hasMoreElements();) {
                                        ProcessThread processThread = (ProcessThread) e.nextElement(); 
                                        processThread.endThread = true;
                                } // for

                                // wait for threads to end gracefully
                                int maxWait = 0;
                                log(0, "Waiting on threads to end...");
                                while (maxWait < 30) { // give up in 30 seconds
                                        if (threadCount(false) <= 0)
                                                break;
                                        try {
                                                Thread.sleep(1000);
                                        } catch (Exception e) {
                                        }
                                        maxWait++;
                                }

                        } catch (Exception e2) {
                        }




			// major error occurred, like pipe broken error, so re-establish
			// connection
			// in 10 seconds

                        if (eojFile!=null && eojFile.exists()) {
                           //log(0,"Gracefull shutdown detected, shutting down...");
                           break;
                        }
                        else
			try {
                           log(0,"Sleeping for 10 seconds, before retrying db open");
				Thread.sleep(10000);
			} catch (Exception e) {
			}

		} // while reopening database after error


		log(0, "PrintFaxProcessor exiting.");

                if (eojFile!=null && eojFile.exists()) {
                   eojFile.delete();
                   log(0,"Gracefull shutdown detected, exiting program now");
                }

	} // run //

	// /////////////////////////////////////////////////////////////////////////////////

	private void GetArgs(String args[], LogMsg log_obj) {
		int ix;

		if (args.length > 0) {

			for (ix = 0; ix < args.length; ++ix) {

				if ((args[ix].charAt(0) != '-') && (args[ix].length() > 1)) {
					ShowUsage();
				}

				switch (args[ix].charAt(1)) {

				case 'i':
					sIniFile = args[ix].substring(2);
					log(0, "IniFile is '" + sIniFile + "'");
					try {
						//
						// Read host, user, sid and password from ini file
						//
						ini.readINIFile(sIniFile);

						String logFile = ini.getINIVar(
								"logs.printfax_queue_log_file", "");
						if (logFile.length() > 0) {
							log_obj.openLogFile(logFile);
						}

						log(0, "PrintFaxProcessor version " + VERSION
								+ " initializing...");

						if (ini.getINIVar("database.TNSEntry") == null
								|| ini.getINIVar("database.TNSEntry").trim()
										.equals("")) {

							sHost = ini.getINIVar("database.host", "");
							log(0, "Host is '" + sHost + "'");

							sPort = ini.getINIVar("database.port", "");
							log(0, "Port is '" + sPort + "'");

							sSIDname = ini.getINIVar("database.sid", "");
							log(0, "Database (SID name) is '" + sSIDname + "'");

						} else {

							tnsEntry = ini.getINIVar("database.TNSEntry");
							log(0, "Using TNS Entry '" + tnsEntry);

						}

                                                historyDocsURL  = ini.getINIVar("historydocs.history_docs_url", "");
                                                if (historyDocsURL.length() > 0)
                                                   log(0, "History Docs URL: " + historyDocsURL);

						sUser = ini.getINIVar("database.user", "");
						log(0, "Set User:" + sUser);

						sPass = ini.getINIVar("database.password", "");
						log(0, "Set Password:" + sPass);

						purge_printfax_queue_older_than_days = ini.getINIVar(
								"general.purge_printfax_queue_older_than_days",
								"");
						log(0, "purge_printfax_queue_older_than_days is '"
								+ purge_printfax_queue_older_than_days + "'");

						central_pro_wait_limit_secs = ini.getINIVar(
								"general.central_pro_wait_limit_secs", "30");
						log(0, "central_pro_wait_limit_secs is "
								+ central_pro_wait_limit_secs);

						// get the URL to check if all closing docs have printed
						// Same as eConRunRules url, but different fuse
						sRunRulesURL = ini.getINIVar(
								"urls.contract_completion_check_url", "");
						if (sRunRulesURL.indexOf("eConRunRules") > 0)
							sRunRulesURL = sRunRulesURL.substring(0,
									sRunRulesURL.indexOf("eConRunRules"))
									+ "RunActivityRules&activity_id=22&request_id=";

						log(0, "run rules URL: " + sRunRulesURL);

						// get the URL to check if Early Disclosure Doc have
						// printed
						// Same as eConRunRules url, but different fuse
						sEarlyDiscURL = ini.getINIVar(
								"urls.contract_completion_check_url", "");
						if (sEarlyDiscURL.indexOf("eConRunRules") > 0)
							sEarlyDiscURL = sEarlyDiscURL.substring(0,
									sEarlyDiscURL.indexOf("eConRunRules"))
									+ "fuseEarlyDisc&activity_id=38&request_id=";

						log(0, "early disclosure URL: " + sEarlyDiscURL);

					} catch (Exception e) {
						log(0, "Caught exception reading ini file '" + sIniFile
								+ "':" + e.toString());
					}
					break;

				case 's': // sleep seconds
					try {
						lSleepSecs = Long.valueOf(args[ix].substring(2))
								.longValue();
						log(0, "Sleep seconds set at " + lSleepSecs);

					} catch (Exception e) {
						log(0, "Unable to convert parameter: " + args[ix]);
					}
					break;

				case 't': // threads
					try {
						maxThreads = Integer.parseInt(args[ix].substring(2));
						log(0, "Threads: " + maxThreads);

					} catch (Exception e) {
						log(0, "Unable to convert parameter: " + args[ix]);
					}
					break;

				//GL.
				case 'l': // use iText library to compose PDF documents
                                        useiTextLibrary=true;
                                        log(0, "iText library will be used to compose PDF documents instead of the PDFComposer (this setting is ignored if CentralPro is used) ");
                                        break;


				case 'r': // threads
					try {
						querySleep = Integer.parseInt(args[ix].substring(2));
						log(0, "Between queries to RightFax seconds: "
								+ querySleep);

					} catch (Exception e) {
						log(0, "Unable to convert parameter: " + args[ix]);
					}
					break;
				case 'q': // threads
					try {
						queryQueueEmptySleep = Integer.parseInt(args[ix]
								.substring(2));
						log(0, "When query queue empty sleep: "
								+ queryQueueEmptySleep);

					} catch (Exception e) {
						log(0, "Unable to convert parameter: " + args[ix]);
					}
					break;

				//GL.


                                case 'z':
                                	
                                /** OWASP Top 10 2010 - A4 path manipluation
                                  * Change to the below code to fix vulnerabilities
                                  * TTP 324955
                                  */	
                                //eojFile = new File(args[ix].substring(2));
                                try
                                {
                                  eojFile = new File(OWASPSecurity.validationCheck(args[ix].substring(2), OWASPSecurity.DIRANDFILE));
                                }
                                catch(Exception e)
                                {
                                	e.printStackTrace();
                                }  
                                log(0,"End of job file is '" + args[ix].substring(2) + "'");
                                break;

				case 'p': // phone number prefix for fax numbers ie. 1
					faxPhoneNumberPrefix = args[ix].substring(2);
					log(0, "Fax phone number prefix: " + faxPhoneNumberPrefix);
					break;

				case 'd': // turn debug on
					i_dbg_level = 5;
					log(0, "debugging turned on");
					break;

				case 'c':
					central_pro_server_id = args[ix].substring(2);
					log(0, "Doc Prep Server: " + central_pro_server_id);
					break;           


				default:
					log(0, "Unknown parameter: " + args[ix]);
					ShowUsage();
					break;
				}
			}
			if ((((sHost.length() == 0) || (sPort.length() == 0) || (sSIDname
					.length() == 0)) && (tnsEntry == null || tnsEntry.length() == 0))
					|| (sUser.length() == 0)
					|| (purge_printfax_queue_older_than_days.length() == 0)
					|| (lSleepSecs <= 0)) {
				log(0, "Parameter host:" + sHost);
				log(0, "Parameter port:" + sPort);
				log(0, "Parameter user:" + sUser);
				log(0, "Parameter sid:" + sSIDname);
				log(0, "Parameter sleep seconds:" + lSleepSecs);
				log(0, "Parameter purge_printfax_queue_older_than_days:"
						+ purge_printfax_queue_older_than_days);
				log(
						0,
						"Error: One of the above parameters supplied on the command line and/or ini file are in invalid.");
				ShowUsage();
			}
		} else {
			ShowUsage();
		}

	} // getArgs

	////////////////////////////////////////////////////////////////////////////////////

	// GL.
	private void ShowUsage() {
		System.out.println("");
		System.out
				.println("Usage: java PrintFaxProcessor -c<central_pro_server_id> -z<eoj_file_name> -t<num_threads> -i<inifile> -s<SleepSeconds> -d");
		System.out.println("---------------------");
		System.out.println("-i - INI file to use for configuration");
		System.out
				.println("-s - Seconds to sleep before polling db [default is 2]");
		System.out.println("-d - sets debug messages on.  (Default is off)");
		System.out.println("-c - Central Pro Server ID  (default is DEFAULT)");
		System.out.println("-z - filename and path of eoj file");
		System.out.println("-t - numthreads");
		System.out
				.println("-p - phone number prefix for fax numbers (eg. 1 for long distance)");
		System.out
				.println("-r - seconds to sleep between status queries to rightfax [default is 2]");
		System.out
				.println("-q - seconds to sleep when status queue is empty [default is 2]");
		System.out.println("-l - if -l is specified then use iText library to compose PDF documents instead of PDFComposer");
		System.out
				.println("java PrintFaxProcessor -d -cDEFAULT -ic:/development/origenatebin/origenate.ini -s2 -t2 -zc:/development/printfaxqueue/eoj");
		System.exit(1);
	}

	// GL.

	///////////////////////////////////////////////////////////////////////////////////////

	public boolean eojFileExists() {

		if (eojFile != null && eojFile.exists()) {
			eojFile.delete();
			log(0, "EOJ file found, shutting down...");
			return (true);
		}
		return (false);
	}

	////////////////////////////////////////////////////////////////////

	public synchronized void log(int level, String msg) {

		log_obj.FmtAndLogMsg(central_pro_server_id + ": " + msg, i_dbg_level,
				level);

	}

	////////////////////////////////////////////////////////////////////

	public synchronized void postCommentEvent(int arg_comment_event_id,
			String request_id, String arg_comment_subject_txt,
			String arg_comment_txt) {
		//if not a broadcast fax, add a comment, otherwise add to log
		//broadcast faxes will have a request_id of 0
		if (!request_id.equals("0")) {
			try {
				commentEvents.addComment(Integer.parseInt(request_id),
						arg_comment_event_id, arg_comment_subject_txt, // 50
						arg_comment_txt, // 4000
						"",// no create user ID
						"",// no assigned user ID
						""); // no due date
			} catch (Exception e) {
				log(0, "Post Comment Event ERROR: " + e.toString());
			}
		} else {
			log(0, "Brodcast Fax (request_id = 0): comment_event_id="
					+ arg_comment_event_id + ", comment_subject_txt="
					+ arg_comment_subject_txt + ",comment_txt="
					+ arg_comment_txt);
		}

	} // postCommentEvent

	public synchronized void postJournalEvent(String request_id,
			int arg_journal_event_id, String arg_journal_subject_txt,
			String arg_journal_txt) {
		//if not a broadcast fax, add a journal entry, otherwise add to log
		//broadcast faxes will have a request_id of 0
		if (!request_id.equals("0")) {
			try {
				journalEvents.addJournal(Integer.parseInt(request_id),
						arg_journal_event_id, arg_journal_subject_txt,
						arg_journal_txt);
			} catch (Exception e) {
				log(0, "Fax Error: journal_event_id=" + arg_journal_event_id
						+ ", journal_subject_txt=" + arg_journal_subject_txt
						+ ",journal_txt=" + arg_journal_txt + ", Error: "
						+ e.toString());
			}
		} else {
			log(0, "Brodcast Fax (request_id = 0): journal_event_id="
					+ arg_journal_event_id + ", journal_subject_txt="
					+ arg_journal_subject_txt + ",journal_txt="
					+ arg_journal_txt);
		}

	} // postJournalEvent

	public synchronized int threadCount(boolean decreaseCount) {
		if (decreaseCount)
			runningThreads--;
		return (runningThreads);
	}

	/////////////////////////////////////////////////////////////////////////////

	public void deleteOldJobs(Connection con) throws Exception {

		// delete any jobs that are older than inifile specified days that have
		// been processed

		//Query deletePrintFaxQueue = new Query(con);
		int cnt = 0;
		boolean errorOccurred = false;
		   if (purge_printfax_queue_older_than_days.length() ==0) {
                   // not set to delete old rows, so log a message and return
                   log(0, "Origenate ini file setting not set for general.purge_printfax_queue_older_than_days, so skip trying to delete old jobs  ");
                   return;
                }
    	String sql = 
				"SELECT job_id " +
				"FROM printfax_queue " +
				"WHERE finished_dt < sysdate - ?";
    	PreparedStatement ps1 = con.prepareStatement(sql);
    	PreparedStatement ps = null;
    	
		ps1.setInt(1, Integer.valueOf(purge_printfax_queue_older_than_days).intValue());
		ps1.execute();
		
		ResultSet deletePrintFaxQueue = ps1.getResultSet();
    	
		while (deletePrintFaxQueue.next()) {
			errorOccurred = false;
			try {
				// 1/24/07 ChrisN CL140795 Replaced with SQL using bind variable for Triad performance enhancement
				//SQLUpdate.RunUpdateStatement(con,
				//		"delete from printfax_queue_values where job_id = "
				//				+ deletePrintFaxQueue.getColValue("job_id"));
				//SQLUpdate.RunUpdateStatement(con,
				//		"delete from printfax_queue where job_id = "
				//				+ deletePrintFaxQueue.getColValue("job_id"));

				sql = "delete from printfax_queue_values where job_id = ?";
        		ps = con.prepareStatement(sql);
        		//ps.setInt(1, Integer.parseInt(deletePrintFaxQueue.getColValue("job_id")));
        		ps.setInt(1, deletePrintFaxQueue.getInt("job_id"));
        		ps.execute();
        		ps.close();

				sql = "delete from printfax_queue_recipients where job_id = ?";
                ps = con.prepareStatement(sql);
                //ps.setInt(1, Integer.parseInt(deletePrintFaxQueue.getColValue("job_id")));
                ps.setInt(1, deletePrintFaxQueue.getInt("job_id"));
                ps.execute();
                ps.close();
                sql = "delete from printfax_queue_attachments where job_id = ?";
                ps = con.prepareStatement(sql);
                //ps.setInt(1, Integer.parseInt(deletePrintFaxQueue.getColValue("job_id")));
                 ps.setInt(1, deletePrintFaxQueue.getInt("job_id"));
                 ps.execute();
                 ps.close();
				
				sql = "delete from printfax_queue where job_id = ?";
        		ps = con.prepareStatement(sql);
        		//ps.setInt(1, Integer.parseInt(deletePrintFaxQueue.getColValue("job_id")));
        		ps.setInt(1, deletePrintFaxQueue.getInt("job_id"));
        		ps.execute();
        		ps.close();

			} catch (Exception e) {
				errorOccurred = true;
				log(0, "Error purging old jobs, job_id= "+deletePrintFaxQueue.getInt("job_id")+" error=" + e.toString());
			}
			finally {
          		try {ps.close();} catch (Exception e1) {}
			}

			if (!errorOccurred)
				cnt++;

		} // deleting old jobs

		deletePrintFaxQueue.close();
		ps1.close();
		
		if (cnt > 0)
			log(0, "Deleted " + cnt
					+ " old jobs from printfax_queue table (older than "
					+ purge_printfax_queue_older_than_days + " days)");

	} // deleteOldJobs

	/////////////////////////////////////////////////////////////////////////////

	void deleteRightFaxJob(String job_id, String rightfax_job_id,
			String rightfax_url_txt, String rightfax_user_id) throws Exception {

		try {

			RightFaxWrapper rightFax = new RightFaxWrapper(this,
					rightfax_url_txt);

			String response = rightFax.deleteFax(rightfax_job_id);

			log(0, "Retrying Fax Job ID:" + job_id
					+ " removed old job from RightFax: " + rightfax_job_id
					+ " status = " + response);

		} catch (Exception e) {
			log(0, "ERROR deleting RightFax Job: " + rightfax_job_id + "  "
					+ e.toString());
		} // no big deal if couldn't do it

	} // deleteRightFaxJob





} // end class PrintFaxProcessor
