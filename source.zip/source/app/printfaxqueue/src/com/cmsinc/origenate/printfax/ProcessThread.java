package com.cmsinc.origenate.printfax;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.io.Writer;
import java.net.HttpURLConnection;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;
import com.cmsinc.origenate.util.OWASPSecurity;
import sun.misc.BASE64Encoder;
import com.cmsinc.origenate.util.process.StringUtils;

import com.cmsinc.origenate.doc.ConcatPDFs;
import com.cmsinc.origenate.doc.GenJob;
import com.cmsinc.origenate.event.JournalEvents;
import com.cmsinc.origenate.mail.TextEmail;
import com.cmsinc.origenate.util.Alert;
import com.cmsinc.origenate.util.LogMsg;
import com.cmsinc.origenate.util.PostRequest;
import com.cmsinc.origenate.util.Query;
import com.cmsinc.origenate.util.SQLUpdate;
import com.cmsinc.origenate.workflow.AppLockingManager;
import com.cmsinc.origenate.workflow.ApplicationIDs;
import com.cmsinc.origenate.workflow.ApplicationStatusManager;
import com.cmsinc.origenate.workflow.WorkFlowManager;
import com.sun.net.ssl.HttpsURLConnection;


/**
 *
 *
 */
public class ProcessThread extends Thread {

	// INSTANCE VARIABLES

	Connection con = null;

        static java.lang.Object critsec = new java.lang.Object();

	PrintFaxProcessor main = null;

	String jobID;

	boolean busy = false;

	boolean workToDo = false;

	boolean errorOccurred = false;

	boolean endThread = false;

	String errorMessage = null;

	int threadID = 0;

	String sConStr, sUser, sPass;

	LogMsg log_obj = null;

	Query printfaxQueue;

	Query queryTmp;

	Query printfaxQueueValues;

	GenJob genJob = null;

	MonitorThread monitorThread;

	WorkFlowManager workFlowManager = null;

	AppLockingManager appLockingManager = null;

	ApplicationStatusManager applicationStatusManager = null;

	// CONSTRUCTOR

	public ProcessThread(PrintFaxProcessor main, String sConStr, String sUser,
			String sPass, int ID, LogMsg log_obj, MonitorThread monitorThread)
			throws Exception {

		threadID = ID;
		this.main = main;
		this.sConStr = sConStr;
		this.sUser = sUser;
		this.sPass = sPass;
		this.log_obj = log_obj;
		this.monitorThread = monitorThread;

		// Connect to the Oracle database
		con = DriverManager.getConnection(sConStr, sUser, sPass);

		printfaxQueue = new Query(con);
		printfaxQueueValues = new Query(con);
		queryTmp = new Query(con);
		genJob = new GenJob(con, log_obj);
		workFlowManager = new WorkFlowManager(con, log_obj);
		appLockingManager = new AppLockingManager(con, log_obj);
		applicationStatusManager = new ApplicationStatusManager(con, log_obj);

	} // end constructor

	/////////////////////////////////////////////////////////////////////////////

	// RUN METHOD - execution continues in its own thread

	public void run() {

		main.log(0, "Thread" + threadID + " running...");

		while (!endThread) {

			if (!workToDo) {
				// sleep for 1/5 sec before checking if any are free
				try {
					Thread.sleep(200);
				} catch (Exception e) {
				}
				continue;
			}

			busy = true;
			workToDo = false;

			int tryCount = 0;
			boolean tryAgain = true;
			String unlock_app_flg = null;
			String move_to_failed_flg = null;
			String job_type_txt = null;
			String evaluatorName = "UNKNOWN";
			String sql = "";
			PreparedStatement ps = null;
                        String use_doc_hist_seq_id =null;
                        boolean concatFilesInBatch = false; // will only be true for nightly letter batches that have this option set.
                                                                            // This is like asp mode except all the individual files are rolled up into a concatenated PDF

			while (tryAgain) {

				tryAgain = false;

				// try twice if a broken pipe occurred

				try {

					main.log(5, "Thread" + threadID + ": Job " + jobID
							+ " start");

					errorOccurred = false;

					// Set the status to indicate what step its in

					// 1/24/07 ChrisN CL140795 Replaced with SQL using bind variable for Triad performance enhancement

					//SQLUpdate
					//		.RunUpdateStatement(
					//				con,
					//				"update credit_req_doc_history "
					//						+ "set status_id = 'PROCESSING' where job_id = "
					//						+ jobID);
					// END USERS JUST SEE PROCESSING, UNTIL COMPLETE

					sql = "update printfax_queue set status_id = '[GENJOB]' where job_id = ?";
					ps = con.prepareStatement(sql);
					ps.setInt(1, Integer.parseInt(jobID));
					ps.execute();
					ps.close();

					sql = "update credit_req_doc_history set status_id = 'PROCESSING' where job_id = ?";
					ps = con.prepareStatement(sql);
					ps.setInt(1, Integer.parseInt(jobID));
					ps.execute();
					ps.close();

					String queueSelect = "select job_type_txt,evaluator_id,request_id,document_id,"
							+ "package_id,user_id,copies_num,fax_number_txt,recipient_txt,"
							+ "comments_txt, job_name_txt, fax_server_id, unlock_app_flg, move_to_failed_flg,submit_reason_id,batch_job_id "
							+ ",use_doc_hist_seq_id,nvl(batch_concat_flg,0) as batch_concat_flg "
                            + ", email_address_txt, email_subject_txt, coversheet_name_txt,sort_by_txt from printfax_queue "
							+ "where job_id = ?";
							//+ jobID;


					printfaxQueue.prepareStatement(queueSelect);

                                        printfaxQueue.setInt(1, jobID);
					printfaxQueue.executePreparedQuery();

					// The job name is important, it references a job in Central
					// Pro's
					// job table which defines how to process the job and which
					// printer
					// to use. We will default it to NONE if its null so central
					// will
					// match on the DEFAULT job description
					/*
					 * IMPORTANT: WE ARE NO LONGER USING CENTRAL PRO. SO
					 * JOB_NAME NOW REPRESENTS A RIGHTFAX PRINTER NAME WHEN THE
					 * JOB_TYPE IS 'PRINT'. WHEN THE JOB_TYPE IS 'ASP' THEN WE
					 * ARE SIMPLY COMPOSING THE DOCUMENT AND STORING IT IN A
					 * DIRECTORY TO BE PROCESSED VIA A BROWSER USING THE LENDER
					 * PRINT TOOL.
					 *
					 */


					if (!printfaxQueue.next())
						throw new Exception("Job not found: " + jobID);

					job_type_txt = printfaxQueue
							.getColValue("job_type_txt", "").toUpperCase();
					String evaluator_id = printfaxQueue.getColValue(
							"evaluator_id", "-99"); // -99 to force an error
					String request_id = printfaxQueue.getColValue("request_id",
							"");
					String document_id = printfaxQueue.getColValue(
							"document_id", "");
					String package_id = printfaxQueue.getColValue("package_id",
							"");
					String user_id = printfaxQueue.getColValue("user_id",
							"notavail");
					String copies_num = printfaxQueue.getColValue("copies_num",
							"1");
					String fax_number_txt = printfaxQueue.getColValue(
							"fax_number_txt", "");
					String recipient_txt = printfaxQueue.getColValue(
							"recipient_txt", "");
					String comments_txt = printfaxQueue.getColValue(
							"comments_txt", "");
					String job_name_txt = printfaxQueue.getColValue(
							"job_name_txt", "DEFAULT").toUpperCase();
					String fax_server_id = printfaxQueue.getColValue(
							"fax_server_id", "").toUpperCase();
					String submit_reason_id = printfaxQueue.getColValue(
							"submit_reason_id", "0");
					String batch_job_id = printfaxQueue.getColValue(
							"batch_job_id", "");
					unlock_app_flg = printfaxQueue.getColValue(
							"unlock_app_flg", "0");
					move_to_failed_flg = printfaxQueue.getColValue(
							"move_to_failed_flg", "0");
					use_doc_hist_seq_id = printfaxQueue.getColValue(
							"use_doc_hist_seq_id", "0");
					String sortByVal = printfaxQueue.getColValue(
							"sort_by_txt", "");

                                        if (printfaxQueue.getColValue("batch_concat_flg","0").equals("1")) concatFilesInBatch=true; 

                                        String email_address_txt=printfaxQueue.getColValue("email_address_txt", "");
                                        String email_subject_txt=printfaxQueue.getColValue("email_subject_txt", "");
                                        String coversheet_name_txt=printfaxQueue.getColValue("coversheet_name_txt", "");

					String faxServerURL = "";
					String faxServerUserID = "";

					String doc_type_id = "PDF";
					String formName = "";

					if (document_id.length() > 0) {
						// determine if this file is to be composed with the
						// PDFComposer.
						// PDFComposer supplants Central Pro and uses Adobe
						// Acrobat to
						// compose files
                                                // doc type ids: PDF or TEXT go to the Composer
                                                // doc type id: CENTRAL PRO goes to Central Pro
						//TTP 324955 Security Remediation Fortify Scan
						queryTmp
								.prepareStatement("select doc_type_id,form_name_txt from config_documents where document_id = "
										+ "?"
										+ " and evaluator_id = "
										+ "?");
						queryTmp.setInt(1, document_id);
						queryTmp.setInt(2, evaluator_id);
						queryTmp.executePreparedQuery();
						if (queryTmp.next()) {
							doc_type_id = queryTmp.getColValue("doc_type_id","PDF"); 
							formName = queryTmp.getColValue("form_name_txt",""); 

									
						}
					}

					String msg = "JOB:" + jobID + " " + job_type_txt
							+ " request_id=" + request_id + " document_id="
							+ document_id;
					msg += " package_id=" + package_id + " user=" + user_id
							+ " copies=" + copies_num + " job name="
							+ job_name_txt + " evalID=" + evaluator_id+" doc hist ID="+use_doc_hist_seq_id;

					if (!doc_type_id.equals("PDF")
					   && !doc_type_id.equals("CENTRAL PRO")
                                           && !doc_type_id.equals("TEXT")) {
						errorOccurred = true; // will not disable this thread,
						// just skip this job
						String err = "Only doc types of PDF, CENTRAL PRO and TEXT are supported at this time, doc type requested was: "
								+ doc_type_id;
						msg = "Thead: " + threadID + " ERROR processing job:"
								+ jobID + " error: " + err;
						main.log(0,"Thread: "+threadID+" "+msg);

						err = err.replace('\'', ' ');
						err = err.replace('"', ' ');

						updateJobAsError(jobID, err, con, unlock_app_flg,
								move_to_failed_flg, job_type_txt, batch_job_id);

					}

					String formType = "pdf";

					Hashtable runtimeValues = new Hashtable();

					runtimeValues.put("user_id", user_id); // the user who
					// submitted the
					// request
					runtimeValues.put("recipient", recipient_txt);
					runtimeValues.put("comments", comments_txt);
					runtimeValues.put("fax_number", fax_number_txt);
					runtimeValues.put("num_copies", copies_num);

					main.log(5, "Thread: "+threadID+" "+msg);

					// now get any prompt values that may go with this job

					String select = "select field_id,value_txt "
							+ "from printfax_queue_values " + "where job_id = ?  and document_id = ?";
							//+ jobID + " and document_id = " + document_id;

					printfaxQueueValues.prepareStatement(select);
                                        printfaxQueueValues.setInt(1, jobID);
                                        printfaxQueueValues.setInt(2, document_id);
					printfaxQueueValues.executePreparedQuery();


					Hashtable promptedValues = new Hashtable();
					while (printfaxQueueValues.next())
						promptedValues.put(printfaxQueueValues
								.getColValue("field_id"), printfaxQueueValues
								.getColValue("value_txt", ""));

					String tmpFileName = "";
					boolean aspMode = true;
					String printerName = job_name_txt;
					// if the nightly letters pgm overrides the printer name
					// then it is stored here

					// GL. always get the evaluator name print or fax
					// TTP 324955 Security Remediation Fortify Scan
					queryTmp.prepareStatement("select evaluator_name_txt from evaluator where evaluator_id = ?");
					queryTmp.setInt(1, evaluator_id);
					queryTmp.executePreparedQuery();
					if (queryTmp.next())
						evaluatorName = queryTmp.getColValue(
								"evaluator_name_txt", "unknown");
					

					/*
					 * RightFax will be controlling billing and calling rules
					 * based on the user ID sent to RF. We will be using the
					 * evaluator name as the user ID since the billing is
					 * controlled at the evaluator level. To make it a valid
					 * name we will upshift, truncate to 20 chars, and replace
					 * spaces with underscore.
					 */

					evaluatorName = evaluatorName.toUpperCase();
					evaluatorName = evaluatorName.replace(' ', '_');
					if (evaluatorName.length() > 20)
						evaluatorName = evaluatorName.substring(0, 20);

					// GL.

					// tmpFileName=jobID+"."+createTempFileName();

					// jobID is a sequence and guaranteed to be unique

					if (job_type_txt.equals("ESIGNVOID"))  {

                                                try {


                                                   DocuSign ds = new DocuSign();

                                                   errorOccurred = ds.voidDocument(con,main.log_obj,main.i_dbg_level,request_id,evaluator_id,document_id);
                                                                                          

                                                   if (errorOccurred) {


                                                      throw new Exception("Void request rejected by DocuSign");
                                                   }
                                                   else {
                                                      main.log(5, "Thread: "+threadID+", request_id: "+request_id+"  DocuSign void eSign request sent successfully");

                                                      updateJobAsSuccess(jobID, con, "0","0",
                                                              job_type_txt,
                                                              "0",false);

                                                   }



                                                } catch (Exception e) {

                                                        String errStr = "Error voiding eSign request for document "+document_id+", ERROR: "+e.toString();
                                                        errStr = errStr.replace('\'', ' ');
                                                        errStr = errStr.replace('"', ' ');

                                                        main.log(5, "Thread: "+threadID+" "+errStr);
                                                        errorOccurred=true;

                                                        unlock_app_flg="0";
                                                        move_to_failed_flg="0";
                                                        updateJobAsError(jobID, errStr, con, unlock_app_flg,
                                                                        move_to_failed_flg, job_type_txt, "-1");

                                                }

                                                busy = false; 

                                                continue;

                                          } // voidDocument



					// DETERMINE TMP FILE NAME FOR COMPOSED DOCUMENT
					
					
					
					if (job_type_txt.equals("EMAIL"))  {
						tmpFileName = "email_" + jobID;
                                        }
					else	
                                        if (job_type_txt.equals("ESIGN"))  {
                                                tmpFileName = "esign_" + jobID;
                                        }
                                        else	
					if (job_type_txt.equals("FAX")) {
						tmpFileName = "fax_" + jobID;
						// still using pdf to rightfax
						// formType="tif";

						// get the evaluator name for faxes

						queryTmp
								.prepareStatement("select evaluator_name_txt from evaluator where evaluator_id = ? ");
						queryTmp.setInt(1,evaluator_id);
						queryTmp.executePreparedQuery();
						if (queryTmp.next())
							evaluatorName = queryTmp.getColValue(
									"evaluator_name_txt", "unknown");

						/*
						 * RightFax will be controlling billing and calling
						 * rules based on the user ID sent to RF. We will be
						 * using the evaluator name as the user ID since the
						 * billing is controlled at the evaluator level. To make
						 * it a valid name we will upshift, truncate to 20
						 * chars, and replace spaces with underscore.
						 */

						evaluatorName = evaluatorName.toUpperCase();
						evaluatorName = evaluatorName.replace(' ', '_');
						if (evaluatorName.length() > 20)
							evaluatorName = evaluatorName.substring(0, 20);

					} else
					// nightly letters are always in a batch
					if (batch_job_id.length() > 0) {

						// preface the file name with the type of letter
						String prefix="unknown";
						if (submit_reason_id.equals("5")) prefix="decline";
						if (submit_reason_id.equals("6")) prefix="counter";
						if (submit_reason_id.equals("7")) prefix="welcome";
						if (submit_reason_id.equals("8")) prefix="expired";
						if (submit_reason_id.equals("18")) prefix="withdraw";
						if (submit_reason_id.equals("9")) prefix="firstpayment";
						if (submit_reason_id.equals("10")) prefix="batch";
						if (submit_reason_id.equals("12")) prefix="closing";
						if (submit_reason_id.equals("14")) prefix="disclosure";
						if (submit_reason_id.equals("19")) prefix="initial";
						if (submit_reason_id.equals("20")) prefix="followup1";
						if (submit_reason_id.equals("21")) prefix="followup2";
						if (submit_reason_id.equals("22")) prefix="missinginfo";
						if (submit_reason_id.equals("26")) prefix="risk";
						if (submit_reason_id.equals("29")) prefix="notification";

						// Craig wants the product ID embedded in the file name as well
						// TTP 324955 Security Remediation Fortify Scan
						queryTmp.prepareStatement("select product_id from credit_request where request_id = ?");
						queryTmp.setInt(1, request_id);
						queryTmp.executePreparedQuery();
						String product_id = "0";
						if (queryTmp.next()) product_id = queryTmp.getColValue("product_id","0");

						//nestorw 12/14/11 156775 add the concatenated pdf code to the file name if it exists
						queryTmp.prepareStatement("select concatenated_pdf_code_txt from config_documents" +
								" where evaluator_id = ? and document_id = ?" );
						queryTmp.setInt(1, evaluator_id);
						queryTmp.setInt(2, document_id);
						queryTmp.executePreparedQuery();
						String concatCode = "";
						if (queryTmp.next()) concatCode = queryTmp.getColValue("concatenated_pdf_code_txt");
                        if((concatCode != null) && (!concatCode.equals(""))){
                        	concatCode = "_concatCode_" + concatCode;  
                        }else{
                        	concatCode = "";
                        }
						
						tmpFileName = prefix+"_eval_" + evaluator_id + "_batch_"
								+ batch_job_id + "_job_" + jobID+"_product_"+product_id + concatCode;
						// in asp mode batches are simply saved to a directory
						// so the
						// lender-print-tool can pull them to a browser and
						// print them (and then delete the batch)
						// If the job type is print, then each file is passed to
						// RightFax to
						// be printed to a printer attached to RightFax (the
						// lender print tool
						// is still used to delete the batch after the user has
						// determied that the
						// batch successfully printed)

						if (job_type_txt.equals("PRINT"))
							aspMode = false;

						job_type_txt = "BATCH";
					} else
						// Must be a print job for Central pro to handle
						tmpFileName = "print_" + jobID;

					//CL157372 append sort text to the beggining of the file name (if there is a value set for the sort text)
					if(sortByVal.length() > 0)
					{
						tmpFileName = sortByVal + "_" + tmpFileName;
					}
					/*
					 * 2/13/03 THIS HAS BEEN BACKED OUT BECAUSE A FIX TO
					 * RIGHTFAX WAS FOUND
					 *
					 * Always create a PDF unless its a fax. When the input file
					 * starts with fax_ the composer will use a special print
					 * driver to output the file in TIF format. This was done to
					 * overcome a problem in RightFax where it does not
					 * interpret carriage returns properly. It puts a box char
					 * at the end of each line. So we are asking the composer to
					 * convert to TIF and then fax that.
					 */

					String jobFileName;
					String errorFileName;
					String errorFileNameDat;
					String successFileName;
					String outputFileName;
					String formFileName=main.central_pro_forms_dir+formName; 

					/*
					 * GL. 12/20/04 We are now supporting a text merge
					 * capability. The doc type will be TEXT and the form will
					 * be a text file with tags [[fieldname]]. We still want to
					 * create a std fdf file and the Composer will check its
					 * contents to see if it references a .txt form. If so, it
					 * will merge the data itself instead of calling adobe.
					 *
					 */

					if (doc_type_id.equals("PDF") || doc_type_id.equals("TEXT")) {
						if (doc_type_id.equals("PDF"))
							outputFileName = main.central_pro_output_dir
									+ tmpFileName + ".pdf";
						else
							outputFileName = main.central_pro_output_dir
									+ tmpFileName + ".txt";
						jobFileName = main.central_pro_input_dir + tmpFileName
								+ ".fdf";
						errorFileName = main.central_pro_error_dir
								+ tmpFileName + ".err";
						errorFileNameDat = main.central_pro_error_dir
								+ tmpFileName + ".fdf";
						successFileName = main.central_pro_success_dir
								+ tmpFileName + ".fdf";
					} else { // must be CENTRAL PRO
						outputFileName = main.central_pro_output_dir
								+ tmpFileName + ".pdf";
						jobFileName = main.central_pro_input_dir + tmpFileName
								+ ".dat";
						errorFileName = main.central_pro_error_dir
								+ tmpFileName + ".err";
						errorFileNameDat = main.central_pro_error_dir
								+ tmpFileName + ".dat";
						successFileName = main.central_pro_success_dir
								+ tmpFileName + ".dat";
					}

					String faxCoverSheet = "";

					// if an error occurs the PDF Composer will put the .dat
					// file and a .err file
					// in the error dir

					/**  
					* OWASP TOP 10 2010 - A4 Path Manipulation
					* Changes to the below code to fix vulnerabilities
					* TTp 324955
					*/
					/*File outputFile = new File(outputFileName);
					File errorFile = new File(errorFileName);
					File errorFileDat = new File(errorFileNameDat);
					File successFile = new File(successFileName);*/
					File outputFile = new File(OWASPSecurity.validationCheck(outputFileName, OWASPSecurity.FILENAME));
					File errorFile = new File(OWASPSecurity.validationCheck(errorFileName, OWASPSecurity.FILENAME));
					File errorFileDat = new File(OWASPSecurity.validationCheck(errorFileNameDat, OWASPSecurity.FILENAME));
					File successFile = new File(OWASPSecurity.validationCheck(successFileName, OWASPSecurity.FILENAME));

					String jobFile = null;
					String jobFilePDF = null;
                                        boolean printedWithCentralPro=false;
                                        boolean saveCopy=false;

					try {


						/*
						 * GET THE URL FOR THE FAX SERVER, AND THE COVER SHEET
						 * TO BE USED
						 *
						 * If this is a fax request and the fax server was not
						 * specified on the request then get the default fax
						 * server for this evaluator from the
						 * xref_prod_eval_servers table.
						 *
						 *
						 * If batches are printing using RightFax then process
						 * the same logic to determine the RightFax Server to
						 * use. Batches are never printed with RightFax in ASP
						 * mode.
						 *
						 */

						if (job_type_txt.equals("FAX")
						|| (job_type_txt.equals("BATCH") && !aspMode)) {



							// FIRST GET THE COVER SHEET FILE NAME IF ONE EXISTS
							queryTmp
									.prepareStatement("select cd.form_name_txt from config_evaluator_documents ce, config_documents cd where ce.category_id = 'FAX_COVER_SHEET' and ce.evaluator_id = ? and ce.document_id = cd.document_id and ce.evaluator_id = cd.evaluator_id");
							queryTmp.setInt(1,Integer.parseInt(evaluator_id));
							queryTmp.executePreparedQuery();
							if (queryTmp.next())
								faxCoverSheet = queryTmp
										.getColValue("form_name_txt");
							else { // no specific def for this eval so use
								// system definition
								queryTmp
										.executeQuery("select cd.form_name_txt from config_evaluator_documents ce, config_documents cd where ce.category_id = 'FAX_COVER_SHEET' and ce.evaluator_id = -1 and ce.document_id = cd.document_id and ce.evaluator_id = cd.evaluator_id");
								if (queryTmp.next())
									faxCoverSheet = queryTmp
											.getColValue("form_name_txt");

								// if didn't find one then not serious enough to
								// throw an error
							}

							// DOCGEN: if a fax coversheet name was explicity
							// specified then use it instead of getting it from
							// config_evaluator_documents.
							// this will happen when a docgen config table
							// (config_fax_delivery) is used to populate
							// the printfax queue table.
							
							if (coversheet_name_txt.length()>0) faxCoverSheet=coversheet_name_txt;
							
							// If a fax server was not specified on the job then
							// find one

							if (fax_server_id.length() == 0) {
								// TTP 324955 Security Remediation Fortify Scan
								queryTmp
										.prepareStatement("select fax_server_id from xref_prod_eval_servers where product_id = 1 and evaluator_id = ?");
								queryTmp.setInt(1, evaluator_id);
								queryTmp.executePreparedQuery();
								if (!queryTmp.next()) { // no specific def for
									// this eval so use
									// system definition
									queryTmp
											.executeQuery("select fax_server_id from xref_prod_eval_servers where product_id = 1 and evaluator_id = -1");
									if (!queryTmp.next()) {
										if (job_type_txt.equals("FAX"))
											throw new Exception(
													" ERROR: Can't fax app: "
															+ request_id
															+ " because evaluator "
															+ evaluator_id
															+ " has no entry in xref_prod_eval_servers and system default not defined");
										else
											throw new Exception(
													" ERROR: Can't Print app: "
															+ request_id
															+ " because evaluator "
															+ evaluator_id
															+ " has no entry in xref_prod_eval_servers and system default not defined");
									}
								}

								fax_server_id = queryTmp
										.getColValue("fax_server_id");
							}

							// NOW GET THE URL FOR THE SPECIFIED FAX SERVER
							// TTP 324955 Security Remediation Fortify Scan
							queryTmp
									.prepareStatement("select url_txt,fax_server_user_id from config_fax_servers where fax_server_id = ?");
							queryTmp.setString(1, fax_server_id);
							queryTmp.executePreparedQuery();
							if (!queryTmp.next()) { // no specific printer for
								// this eval so use system
								// definition
								throw new Exception(
										" CONFIG_FAX_SERVERS row not found for: "
												+ fax_server_id);
							}

							faxServerURL = queryTmp.getColValue("url_txt");
							faxServerUserID = queryTmp
									.getColValue("fax_server_user_id");

							/*
							 * If batch printing and a printer name has not been
							 * specified or is set to DEFAULT then use the
							 * xref_prod_eval_servers table to find the default
							 * printer name (stored in job_name_txt)
							 */

							if (job_type_txt.equals("BATCH"))
								if (printerName.length() == 0
										|| printerName.equals("DEFAULT")) {

									queryTmp
											.prepareStatement("select job_name_txt from xref_prod_eval_servers where product_id = 1 and evaluator_id = ? ");
									queryTmp.setInt(1,evaluator_id);
									queryTmp.executePreparedQuery();
									if (!queryTmp.next()) { // no specific def
										// for this eval so
										// use system
										// definition
										queryTmp
												.executeQuery("select job_name_txt from xref_prod_eval_servers where product_id = 1 and evaluator_id = -1");
										if (!queryTmp.next()) {
											throw new Exception(
													" ERROR: Can't Print app: "
															+ request_id
															+ " because evaluator "
															+ evaluator_id
															+ " has no entry in xref_prod_eval_servers and system default not defined");
										}
									}

									printerName = queryTmp
											.getColValue("job_name_txt");
								}

						} // FAX or batches printing thru RightFax




                                                // CALLING GENJOB TO CREATE THE JOBFILE FOR THE PDFCOMPOSER OR CENTRALPRO



                                                queryTmp.prepareStatement("select nvl(save_images_flg,0) as save_images_flg from config_documents where evaluator_id = ? and document_id = ?");
                                                queryTmp.setInt(1,evaluator_id);
                                                queryTmp.setInt(2,document_id);
                                                queryTmp.executePreparedQuery();

                                                if (queryTmp.next())
                                                   if (queryTmp.getColValue("save_images_flg","0").equals("1")) 
                                                       saveCopy=true;




                                                job_name_txt="CMSI -aspPDF";
                                                String genJobOutputFileName=outputFileName;







						if (job_type_txt.equals("BATCH") && !aspMode && doc_type_id.equals("CENTRAL PRO")) {
                                                  /*
                                                  job_name_txt is used by genjob only if we
                                                  are using Central Pro. GenJob queries the
                                                  doc type and if it is CENTRAL PRO then
                                                  it will use job_name_txt to help build the
                                                  ^job line at the beginning of the data file.

                                                  Non-asp batch jobs will print thru central pro
                                                  if the doc type is CENTRAL PRO, so remove the
                                                  -aspPDF option to prevent a PDF from being
                                                  generated and set the output file name
                                                  to the name of a printer to be printed on
                                                  */
                                                   job_name_txt="CMSI";
                                                   genJobOutputFileName=printerName;
                                                   printedWithCentralPro=true;

                                                }
						// printing

						// CALL GENJOB TO CREATE THE DATA FILE TO BE SUBMITTED
						// TO CENTRAL PRO or the PDF Composer

						//added evaluator_id to hashtable for broadcast fax
						runtimeValues.put("evaluator_id", evaluator_id);


						main.log(5, "Thread: "+threadID+" "+"Calling GenJob, job_name_txt=" + job_name_txt+", job_type_txt="+job_type_txt+",outputFile="+genJobOutputFileName+
                                                          ", RID="+request_id+", doc_id="+document_id+
                                                          ", form type="+formType);

                                                if (!use_doc_hist_seq_id.equals("0")) // 140893 hist seq id is non zero then it points to a doc history row to get the file to be printed
                                                   jobFile="";
                                                else   {

        						  jobFile = genJob.genJobFile(job_name_txt,
        								((job_type_txt.equals("FAX") || job_type_txt.equals("BATCH") || job_type_txt.equals("EMAIL")) ? GenJob.OUTPUT_TO_FILE : GenJob.OUTPUT_TO_PRINTER),
        										genJobOutputFileName, request_id,
        										document_id, formType, runtimeValues,
        										promptedValues, Integer.parseInt(copies_num));
                                                      if (printedWithCentralPro && saveCopy) {
                                                          job_name_txt="CMSI -aspPDF";
                                                          genJobOutputFileName=outputFileName;
        						  jobFilePDF = genJob.genJobFile(job_name_txt,
        								((job_type_txt.equals("FAX") || job_type_txt.equals("BATCH") || job_type_txt.equals("EMAIL")) ? GenJob.OUTPUT_TO_FILE : GenJob.OUTPUT_TO_PRINTER),
        										genJobOutputFileName, request_id,
        										document_id, formType, runtimeValues,
        										promptedValues, Integer.parseInt(copies_num));
                                                      }
                                                }


					} catch (Exception e1) {
						errorOccurred = true; // will not disable this thread,
						// just skip this job
						String err = "GenJob - " + e1.toString();
						msg = "Thead: " + threadID + " ERROR processing job:"
								+ jobID + " error: " + err;
						main.log(0, "Thread: "+threadID+" "+msg);

						err = err.replace('\'', ' ');
						err = err.replace('"', ' ');

						updateJobAsError(jobID, err, con, unlock_app_flg,
								move_to_failed_flg, job_type_txt, batch_job_id);

					}

					if (!errorOccurred) {


                                               
                                                if (!use_doc_hist_seq_id.equals("0")) { // 140893 hist seq id is non zero then it points to a doc history row to get the file to be printed

                                                   //  getHistoryDoc() will create an output file, success file , or error file

                                                   getHistoryDoc(con,use_doc_hist_seq_id,outputFileName,successFileName,errorFileName);



                                                }
                                                else {

                                                          // THIS SECTION OF CODE IS REPLICATED BELOW IF WE ARE PRINTING WITH CP AND
                                                          // WE NEED TO SAVE A COPY

                						// submit the job to the PDF Composer for processing by
                						// dropping the job file into
                						// the Composer's input directory

                						writeFile(jobFileName, jobFile);

                						main.log(5, "Thread: "+threadID+" "+"GenJob file: " + jobFileName);
                						main.log(5, "Thread: "+threadID+" "+"Contents:" + jobFile);

                						// Once the Composer creates the PDF from the job file
                						// it will deposit it in
                						// the output dir.

                						// Set the status to indicate what step its in

                						// 1/24/07 ChrisN CL140795 Replaced with SQL using bind variable for Triad performance enhancement
                						//SQLUpdate.RunUpdateStatement(con,
                						//		"update printfax_queue set status_id = '[COMPOSING]' where job_id = "
                						//				+ jobID);
                						sql = "update printfax_queue set status_id = '[COMPOSING]' where job_id = ?";
                						ps = con.prepareStatement(sql);
                						ps.setInt(1, Integer.parseInt(jobID));
                						ps.execute();
                						ps.close();

                						main.log(5, "Thread: "+threadID+" "+"Job:" + jobID
                								+ " submitted for document composure");

                						// Wait for Central to convert it to a faxable file and
                						// drop it in the output dir or the error dir

                						// Wait until the success file or error file appears

                						long maxWait = System.currentTimeMillis()
                								+ ((long) Integer
                										.parseInt(main.central_pro_wait_limit_secs) * 1000);



                                                                /* GL. 12/5/07 Enhancement
                                                                We now have the option to Compose PDF documents with the iText library
                                                                instead of the PDFComposer. The itext library will be used if the -l parm was specified
                                                                on the command line of the startup script.
                                                                */

                                                                if ((main.useiTextLibrary && (doc_type_id.equals("PDF") || doc_type_id.equals("TEXT")))
                                                                	||
                                                                	(job_type_txt.equals("EMAIL") &&  doc_type_id.equals("TEXT"))
                                                                    ) {

                                                                    // the ConcatPDFs class is in common.jar (origenate/doc)
                                                                    // It uses itext.jar to concatenate PDFs.
                                                                   // The class has been enhanced to composePDFs using the itext library as well

                                                                    main.log(5, "Thread: "+threadID+" "+"Composing document with iText...");

                                                                    ConcatPDFs cpdf = new ConcatPDFs(false);
                                                                    if (doc_type_id.equals("PDF")) {
																		cpdf.setBarcodeFields(con, document_id, evaluator_id);
                                                                        cpdf.composePDF(jobFileName,outputFileName,errorFileName,errorFileNameDat,successFileName,formFileName);
                                                                    } else
                                                                        cpdf.composeText(jobFileName,outputFileName,errorFileName,errorFileNameDat,successFileName,formFileName);

                                                                    // the result of this call will be the same as what is expected below in the while loop, that is, a success file or error file will be written

                                                                    /* 155280 - gl. 9/20/11 - sometimes the outputfile will be zero length bytes, probly a threading issue with itext,
                                                                    We found that if we retry it usually regens the file fine. So, if the file is empty try again.
                                                                    */
                                                                    if (successFile.exists() && outputFile.length()==0 && doc_type_id.equals("PDF")) { //156808 only apply to pdf files
                                                                          main.log(5, "Thread: "+threadID+" "+"Output file "+outputFileName+" is zero length, retrying");
                                                                          try {successFile.delete(); } catch (Exception ex) { } //must delete so it doesn't think it succeeded on the next try
                                                                          try {Thread.sleep(1000);}
                                                                           catch (Exception e) {} // 1 sec 
                                                                          if (doc_type_id.equals("PDF")) 
                                                                              cpdf.composePDF(jobFileName,outputFileName,errorFileName,errorFileNameDat,successFileName,formFileName);
                                                                          else
                                                                              cpdf.composeText(jobFileName,outputFileName,errorFileName,errorFileNameDat,successFileName,formFileName);
                                                                          if (successFile.exists()) 
                                                                             if (outputFile.length()==0)
                                                                                main.log(5, "Thread: "+threadID+" "+"ERROR: Second retry still created a zero length file");
                                                                             else
                                                                                main.log(5, "Thread: "+threadID+" "+"Retry worked, length is :"+outputFile.length()+", continuing");
                                                                    }

                                                                }
                                                                else {
                                                                       main.log(5, "Thread: "+threadID+" "+"Waiting on document composition...");

                         						while (!endThread && !successFile.exists()
                         								&& !errorFile.exists()
                         								&& System.currentTimeMillis() < maxWait) {

                         							try {Thread.sleep(500);}
                         							 catch (Exception e) {} // 1/2 sec 

                         						} // end while waiting for outfile
                                                                }



                                                } // create file with composer or central pro



						if (!endThread) // just back out and leave status as
							// CENTRAL
							if (!successFile.exists() && !errorFile.exists()) {
								// update the status to indicate that its timed
								// out

								String err = "Thread: "+threadID+" "+"Timeout waiting on document composition";
								main.log(5, err);

								updateJobAsError(jobID, err, con,
										unlock_app_flg, move_to_failed_flg,
										job_type_txt, batch_job_id);

								errorOccurred = true;
							} else if (errorFile.exists()) {

								errorOccurred = true;

								String errStr = "";
								try {
									errStr = readFile(errorFileName);
								} catch (Exception e1) {
									errStr = "Error reading error file:"
											+ errorFileName + "   "
											+ e1.toString();
								}
								if (errStr.length() > 300)
									errStr = errStr.substring(0, 299);
								errStr = errStr.replace('\'', ' ');
								errStr = errStr.replace('"', ' ');

								main.log(5, "Thread: "+threadID+" "+"Error file found, contents:"
										+ errStr);

								updateJobAsError(jobID, errStr, con,
										unlock_app_flg, move_to_failed_flg,
										job_type_txt, batch_job_id);

								// clean up error files after capturing error
								// msg
								try {
									errorFile.delete();
								} catch (Exception ex) {
								}
								try {
									errorFileDat.delete();
								} catch (Exception ex) {
								}
							}

						if (!errorOccurred && !endThread) {

							//  S U C C E S S

							// remove the success file (was the orig.dat file
							// saved in the backup dir)
							try {
								successFile.delete();
							} catch (Exception ex) {
							}

                                                        // 140893 - before we can save a copy. If we are printing with Central Pro and this document has been
                                                        // configued to save then ask CP to generate a PDF on disk. We need to do this because if we are printing with CP
                                                        // then it does not save a copy to disk.


                                                        if (printedWithCentralPro && saveCopy) {

                                                           // submit the job to Central Pro again by
                                                           // dropping the job file into
                                                           // the Composer's input directory to create a pdf

                                                           writeFile(jobFileName, jobFilePDF);

                                                           main.log(5, "Thread: "+threadID+" "+"GenJob file: " + jobFileName);
                                                           main.log(5, "Thread: "+threadID+" "+"Contents:" + jobFilePDF);

                                                           // Once the Composer creates the PDF from the job file
                                                           // it will deposit it in
                                                           // the output dir.

                                                           // Set the status to indicate what step its in


                                                           main.log(5, "Thread: "+threadID+" "+"Saving an additional copy to be save as doc history for JobID:" + jobID
                                                                           + " submitted for document composure");

                                                           // Wait for Central to convert it to a faxable file and
                                                           // drop it in the output dir or the error dir

                                                           // Wait until the success file or error file appears

                                                           long maxWait = System.currentTimeMillis()
                                                                           + ((long) Integer
                                                                                           .parseInt(main.central_pro_wait_limit_secs) * 1000);

                                                           main.log(5, "Thread: "+threadID+" "+"Waiting on document composition...");

                                                           while (!endThread && !successFile.exists()
                                                                           && !errorFile.exists()
                                                                           && System.currentTimeMillis() < maxWait) {

                                                                   try {
                                                                           Thread.sleep(500);
                                                                   } catch (Exception e) {
                                                                   } // 1/2 sec

                                                           } // end while waiting for outfile


                                                           // We are assuming that it worked if the original file was printed. If it did not work then we will get a msg in the log
                                                           // when we try to save this copy below. This is not serious enough to stop since we printed the original doc
                                                           // successfully

                                                           try {errorFile.delete(); }  catch (Exception ex) {} 
                                                           try {errorFileDat.delete(); }  catch (Exception ex) {} 
                                                           try {successFile.delete(); }  catch (Exception ex) {} 

                                                        } // getting PDF file when printing with Central Pro and we need to save a copy



                                                        // 140893 save a copy of the output file

                                                        saveCopyOfImage(con,evaluator_id,document_id,request_id,outputFileName,jobID);


                                                        // If the printfax_queue.batch_concat_flg was set and we are processing a batch then we need to append this file
                                                        // to the common batch file

                                                        if (concatFilesInBatch && !batch_job_id.equals("0") && batch_job_id.length()>0) {
                                                          // concat files in a batch will not be set in ASP mode because in ASP mode we
                                                          // always want to create individual files to be retrieved by the browser


                                                           conactFile(outputFileName,batch_job_id,submit_reason_id);


                                                        }






                                                        if (job_type_txt.equals("ESIGN")) {


                                                            /* We are to send this PDF to the customer for signing. Find out which vendor we are using for this document
                                                            and then call the appropriate method to process the request.
                                                            */
                                                           Query query = new Query(con);
                                                           sql="select docusign_template_guid_txt,esign_vendor_id from config_documents where evaluator_id = ? and document_id = ?";
                                                           query.prepareStatement(sql);
                                                           query.setInt(1, Integer.parseInt(evaluator_id));
                                                           query.setInt(2, Integer.parseInt(document_id));
                                                           query.executePreparedQuery();
                                                            if (!query.next()) {
                                                               errorOccurred=true;
                                                               updateJobAsError(jobID, "Can not find esign vendor ID for this document, document not found", con, "0",
                                                                               "0", "ESIGN", "0");
                                                            }
                                                            else {


                                                              if (query.getColValue("esign_vendor_id","0").equals("1")) { // DocuSign is first eSign Vendor

                                                                main.log(5, "Thread: "+threadID+" "+"Submitting eSign request to DocuSign for output file: "
                                                                           + outputFileName);
                                                        	
                                                                errorOccurred = sendDocumentToDocuSign(con,outputFileName,
                                                                            request_id,evaluator_id,jobID,document_id,
                                                                            submit_reason_id,query.getColValue("docusign_template_guid_txt",""));
                                                              }
                                                              else {
                                                                 errorOccurred=true;
                                                                 updateJobAsError(jobID, "Unsupported eSign Vendor ID: "+query.getColValue("esign_vendor_id","0"), con, "0",
                                                                                 "0", "ESIGN", "0");
                                                              }

                                                              try {outputFile.delete(); }  catch (Exception ex) {} 

                                                           } // found esign vendor id

                                                        }
                                                        else
                                                        if (job_type_txt.equals("EMAIL")) {

                        									main.log(5, "Thread: "+threadID+" "+"Submitting email for output file: "
                        											+ outputFileName);

                                                        	
                                                            errorOccurred = sendEmail(con,outputFileName,email_address_txt,
                                                                            email_subject_txt,request_id,evaluator_id,main.ini.getINIVar("smtp.host",""),
                                                                            main.ini.getINIVar("smtp.port",""),
                                                                            submit_reason_id,job_name_txt);

                                                        }
                                                        else
                                                           //   F A X O R B A T C H P R I N T
                                                           //   F A X O R B A T C H P R I N T
                                                           //   F A X O R B A T C H P R I N T
                                                           //   F A X O R B A T C H P R I N T
							if (job_type_txt.equals("FAX")
							  || (job_type_txt.equals("BATCH") && !aspMode && !batch_job_id.equals("0"))
                                                          ) { 

                                                              if (printedWithCentralPro) {

                                                                 // CentralPro printed the file

                                                                 errorOccurred=false;
                                                                 // 140893 - if outputFile was a pyproduct of printing then delete it
                                                                 try {outputFile.delete(); }  catch (Exception ex) {} 
                                                                 
                                                              }
                                                              else 
                                                               if (concatFilesInBatch) {
                                                                  // no longer need the output file
                                                                  try {outputFile.delete();} catch (Exception ex) {}
                                                               }
                                                               else {

								if (job_type_txt.equals("FAX"))
									main.log(5, "Thread: "+threadID+" "+"Submitting fax output file: "
											+ outputFileName);
								else
									main.log(5,
											"Thread: "+threadID+" "+"Submitting doc for printing, output file: "
													+ outputFileName);

								/*
								 * faxFile() will submit the outputFile to
								 * RightFax for faxing. The status of the job
								 * will be set to [FAXING]. The MonitorThread
								 * will monitor the status of the fax to see
								 * when it has been faxed so this thread can be
								 * free to start work on another job.
								 */

								errorOccurred = faxFile(faxServerURL,
										faxServerUserID, fax_number_txt,
										recipient_txt, outputFileName,
										comments_txt, faxCoverSheet,
										unlock_app_flg, move_to_failed_flg,
										job_type_txt, printerName,
										evaluatorName);
                                                              }

								// delete ouputFile since we copied its contents
								// to RightFax
								// batch documents will be cleaned up by the
								// cleanup thread
								// after the batch is printed
								if (job_type_txt.equals("FAX"))
									try {
										outputFile.delete();
									} catch (Exception ex) {
									}

							}  // end fax or print via rightfax

							/*
							 *
							 * FAX and BATCH PRINT JOBS ARE SET TO SUCCESSFUL BY
							 * THE MONITOR THEAD, NOT HERE THE MONITOR WILL
							 * EVENTUALLY REMOVE THE PRINTFAX_QUEUE ROW.
							 *
							 * HOWEVER, IF THIS IS AN ASP BATCH THEN SET THE JOB
							 * AS SUCCESSFUL SO THE LENDER PRINT TOOL CAN
							 * PROCESS IT.
							 *
							 */

							if (!errorOccurred && concatFilesInBatch) batch_job_id = "0"; // this will cause the job row to be deleted. If we are concatenating
                                                        // files then we are not in asp mode

							if (!errorOccurred
							    && (printedWithCentralPro  
							        || concatFilesInBatch  
							        || (job_type_txt.equals("BATCH") && aspMode) 
							        || (job_type_txt.equals("BATCH") && batch_job_id != null && batch_job_id.equals("0"))
							        || (job_type_txt.equals("EMAIL"))
							        || (job_type_txt.equals("ESIGN"))
							        )
								) {
									updateJobAsSuccess(jobID, con, unlock_app_flg,
										move_to_failed_flg, job_type_txt,
										batch_job_id,printedWithCentralPro);

								} // no error (printing or batch)

						} // no error from Central

					} // no error

					main
							.log(5, "Thread" + threadID + ": Job " + jobID
									+ " end");

					// reset error flag so this thread is free to process
					// another job

					errorOccurred = false;

				} catch (Exception e) {

					// serious error, disable thread if max retries reached

					String tmp = e.toString();

					// retry 5 times and then give up

					if (tryCount < 5
							&& (tmp.indexOf("Broken pipe") >= 0 || tmp
									.indexOf("deadlock") >= 0)) {

						// re-establish the connection and try one more time
						try {
							con.close();
						} catch (Exception e9) {
						}
						if (tmp.indexOf("Broken pipe") >= 0)
							main
									.log(
											0,
											"Thread"
													+ threadID
													+ ": Broken pipe detected, re-establishing connection for Job ID: "
													+ jobID);
						else
							main
									.log(
											0,
											"Thread"
													+ threadID
													+ ": Deadlock detected, re-establishing connection for Job ID: "
													+ jobID);
						try {
							Thread.sleep(1000);
						} catch (Exception et) {
						} // sleep a second to let condition clear
						try {
							con = DriverManager.getConnection(sConStr, sUser,
									sPass);
							printfaxQueue = new Query(con);
							printfaxQueueValues = new Query(con);
							GenJob genJob = new GenJob(con, log_obj);
						} catch (Exception e1) {
							con = null;
						}
						if (con != null) {
							tryAgain = true;
							tryCount++;
						} else {
							errorOccurred = true;
							errorMessage = "Thread:"
									+ threadID
									+ " DISABLED, unrecoverable error processing Job ID: "
									+ jobID + "  " + tmp;
							main.log(0, "Thread: "+threadID+" "+errorMessage);
						}
					} else {
						// Disable this thread, can't continue
						errorOccurred = true;
						errorMessage = "Thread:"
								+ threadID
								+ " DISABLED, unrecoverable error processing Job ID: "
								+ jobID + "  " + tmp;
						main.log(0, "Thread: "+threadID+" "+errorMessage);
					}

					if (errorOccurred) {

						if (tmp.length() > 300)
							tmp = tmp.substring(0, 299);
						tmp = tmp.replace('\'', ' ');
						tmp = tmp.replace('"', ' ');

						updateJobAsError(jobID, tmp, con, unlock_app_flg,
								move_to_failed_flg, job_type_txt, "-1");

					}

				} // catch
				finally {
					try {ps.close(); } catch (Exception e1) {}
				}
			} // while tryagain

			// finshed with this job so reset flags and wait for more work to do

			// once the errorOccurred flag is set then this thread will not be
			// given
			// any new work until the error has been examined by the caller. The
			// caller
			// will then reset the busy flag after processing the error message.

			if (!errorOccurred)
				busy = false;

		} // while not end thread

		try {
			con.close();
		} catch (Exception e1) {
		}

		main.threadCount(true); // decrease thread count

		// fall thru to end thread

	} // end run()



       // ////////////////////////////////////////////////////////////////////////

        boolean sendDocumentToDocuSign(Connection con, String outputFileName,
                                     String request_id, String evaluator_id,String jobID, String document_id,
                                     String submit_reason_id,String templateGUID) throws Exception {

           boolean errorOccurred=false;
           String from="";
           main.log(5, "Thread: "+threadID+", request_id: "+request_id+"  sending DocuSign eSign request");
           Vector list = new Vector();
           list.add(outputFileName); 

           Query query = new Query(con);
           String sql="";
           PreparedStatement ps = null;

           try {


              DocuSign ds = new DocuSign();
			  
              String envelopeGUID = ds.sendDocument(con,main.log_obj,main.i_dbg_level,outputFileName,request_id,evaluator_id,jobID,document_id,templateGUID);

              // update doc history with the GUID for later reference if we want to void the request

              sql="update credit_req_doc_history set docusign_envelope_guid_txt = '"+envelopeGUID+"', status_id = 'SENT' where job_id = ?";
              ps = con.prepareStatement(sql);
              ps.setInt(1, Integer.parseInt(jobID));
              ps.execute();
              try { if (ps != null) ps.close();} catch (Exception e) {e.printStackTrace();}


              main.log(5, "Thread: "+threadID+", request_id: "+request_id+"  DocuSign eSign request sent successfully");

           } catch (Exception e) {

                   String errStr = "Error submitting eSign request for document "+document_id+", ERROR: "+e.toString();
                   errStr = errStr.replace('\'', ' ');
                   errStr = errStr.replace('"', ' ');

                   main.log(5, "Thread: "+threadID+" "+errStr);
                   errorOccurred=true;

                   String unlock_app_flg="0";
                   String move_to_failed_flg="0";
                   updateJobAsError(jobID, errStr, con, unlock_app_flg,
                                   move_to_failed_flg, "ESIGN", "-1");

                   return (true); // errorOccurred
           }
           finally{ // clean up any files that have been left over
                  try { if (ps != null) ps.close();} catch (Exception e) {e.printStackTrace();} 
                  String fileName=""; 
              for (Enumeration k = list.elements(); k.hasMoreElements();) {
                  fileName=(String)k.nextElement();
                  try {
                                  File file = new File(fileName);
                                  file.delete();
                  }
                  catch (Exception e1) {
                      main.log(5, "Thread: "+threadID+" Can not delete eSign file: "+fileName+", reason: "+e1.toString());
                  }

               }// for


           } // finally


           return false; // no error occurred


        } // sendESign

           ///////////////////////////////////////////////////////////////////////////

       boolean sendEmail(Connection con, String outputFileName,String emailAddress, String emailSubject,
                                    String request_id, String evaluator_id,String smtpHost, String smtpPort,
                                    String submit_reason_id,String job_name_txt) throws Exception {

          boolean errorOccurred=false;
          String from="";
          main.log(5, "Thread: "+threadID+", request_id: "+request_id+"  sending email from: "+from+", to: "+emailAddress+", subject: "+emailSubject+", smtp host: "+smtpHost+", smtpPort: "+smtpPort);
          Vector list = new Vector();
          list.add(outputFileName); // let the calling rtn clean it up and possibly save a copy

          try {
			
			synchronized(critsec){
				String body=readFileNoLineFeeds(outputFileName); // read the body text file but maintain the linefeeds
				// need to get the FROM email address from the evaulator table
				Query query = new Query(con);
				String sql="select email_address_txt from evaluator_address where evaluator_id = ? and address_type_id = 0";
				query.prepareStatement(sql);
				query.setInt(1, Integer.parseInt(evaluator_id));
				query.executePreparedQuery();
				if (query.next()) from=query.getColValue("email_address_txt", "");
				if (from.length()==0) throw new Exception("Can not send email because lender's email address (to populate from field in email) is not specified in evaulator_address table.");
				
				
				TextEmail e = new TextEmail(smtpHost, Integer.parseInt(smtpPort));
				e.setSubject(emailSubject);
				e.setFrom(from);
				e.addRecipient(emailAddress);
				
				e.setBodyPart(body);
				
				// see if attachments need to be included
				
				
				sql="select document_id,doc_type_id,taf_type_id from printfax_queue_attachments where job_id = ?";
				query.prepareStatement(sql);
				query.setInt(1, Integer.parseInt(jobID));
				query.executePreparedQuery();
				
				String docID="";
				String docTypeID="";
				String TAFTypeID="";
				
				String fileName="";
				while(query.next()) {
					docID=query.getColValue("document_id","");
					docTypeID=query.getColValue("doc_type_id","");
					TAFTypeID=query.getColValue("taf_type_id","");
					// the above fields are mutually exclusive, meaning that only one of these fields should be populated
					// depending on the type of document that we should attach
					
					if (docID.length()>0) { // attach a sys generated document
						
						attachSysGeneratedDocument(e,con,list,docID,request_id,evaluator_id,submit_reason_id,job_name_txt);
						
					} // document is to be sys generated and attached
					
					
					if (docTypeID.length()>0) { // attach a previously scanned tif image
						
						attachImage(e,con,list,docTypeID,request_id,evaluator_id);
						
					} // attach the latest document image that was previously captured
					
					
					if (TAFTypeID.length()>0) {

						attachTAFDocument(e,con,list,TAFTypeID,request_id,evaluator_id);
						
						
					} // attach the latest TAF document of this type
					
					
					
				} // while more attachments
				
				
				
				
				e.addPartsToEmail();
				// TTP 324955 Security Remediation Fortify Scan
				SQLUpdate sqlup1 = new SQLUpdate();
				sqlup1.SetPreparedUpdateStatement(con,
						"update printfax_queue set status_id = '[EMAILING]' where job_id = ?");
				sqlup1.setInt(1, jobID);
				sqlup1.RunPreparedUpdateStatement();

				main.log(5, "Thread: "+threadID+" , sending email (START) from: "+from+", to: "+emailAddress+", subject: "+emailSubject+", smtp host: "+smtpHost+", smtpPort: "+smtpPort);
				e.send();					
				main.log(5, "Thread: "+threadID+" , sending email (DONE) from: "+from+", to: "+emailAddress+", subject: "+emailSubject+", smtp host: "+smtpHost+", smtpPort: "+smtpPort);
				
				
				main.log(5, "Thread: "+threadID+" , Submitted email from: "+from+", to: "+emailAddress+", subject: "+emailSubject+", smtp host: "+smtpHost+", smtpPort: "+smtpPort);
			}
          } catch (Exception e) {

                  String errStr = "Error submitting to email  from: "+from+", to: "+emailAddress+", subject: "+emailSubject+", smtp host: "+smtpHost+", smtpPort: "+smtpPort+", ERROR: "+ e.toString();
                  errStr = errStr.replace('\'', ' ');
                  errStr = errStr.replace('"', ' ');

                  main.log(5, "Thread: "+threadID+" "+errStr);
                  errorOccurred=true;

                  String unlock_app_flg="0";
                  String move_to_failed_flg="0";
                  updateJobAsError(jobID, errStr, con, unlock_app_flg,
                                  move_to_failed_flg, "EMAIL", "-1");

                  return (true); // errorOccurred
          }
          finally{ // clean up any files that have been left over
        	  synchronized(critsec){
        	 String fileName=""; 
    	     for (Enumeration k = list.elements(); k.hasMoreElements();) {
    	         fileName=(String)k.nextElement();
    	         try {
				 File file = new File(fileName);
				 file.delete();
    	         }
    	         catch (Exception e1) {
                     main.log(5, "Thread: "+threadID+" Can not delete email file: "+fileName+", reason: "+e1.toString());
    	         }
    	         
    	      }// for
				}
        	  
          } // finally


          return errorOccurred;

       } // end sendemail

       
       
       ////////////////////////////////////////////////////////////////////////
       
       public void attachTAFDocument(TextEmail email,Connection con,Vector fileNameList,String taf_type,String request_id,String evaluator_id) throws Exception {
      	 
      	 
           main.log(5, "Thread: "+threadID+", request_id: "+request_id+"  adding TAF document of type: "+taf_type);

      	 String fileName="";
      	 String TAFDocsURL=main.ini.getINIVar("historydocs.history_docs_url","");
      	 if (TAFDocsURL.length()==0) throw new Exception("historydocs.history_docs_url not specified in Origenate.ini file");
      	 // use the history_docs_url and modify it for the TAFDocs servlet
      	 
      	 TAFDocsURL=TAFDocsURL.substring(0,TAFDocsURL.indexOf("HistoryDocs"))+"TAFDocs?action=get&request_id="+request_id+"&evaluator_id="+evaluator_id;

      	 Query query = new Query(con);

 		String sql="";
 		
      	 
      	 // find the latest TAF doc type from the appropriate table so we can hit the TAFDocs servlet to get it
      	 
      	 String tableName="";
      	 
      	 if (taf_type.equals("T")) tableName="credit_req_title_docs";
      	 if (taf_type.equals("A")) tableName="credit_req_appraisal_docs";
      	 if (taf_type.equals("F")) tableName="credit_req_flood_docs";
      	
      	 if (tableName.length()==0) throw new Exception("Trying to attach a TAF document to email but taf type is not recognized, TAF type passed in="+taf_type);
      		 
      		sql="SELECT collateral_request_id,home_equity_id,seqno,respseqno,occurrence from ";
      		sql+=tableName+" where request_id = ? order by received_dt desc";
  		    query.prepareStatement(sql);
  	        query.setInt(1, Integer.parseInt(request_id));
  	        query.executePreparedQuery();
  	        
  	        if (!query.next()) {
  	            main.log(5, "Thread: "+threadID+", request_id: "+request_id+"   document of this type: "+taf_type+" found, attachment not added");
  	             String docType="";
	  	       	 if (taf_type.equals("T")) docType="Latest Title document";
	  	       	 if (taf_type.equals("A")) docType="Latest Appraisal document";
	  	       	 if (taf_type.equals("F")) docType="Latest Flood document";
  	            String msg="Could not attach document to email because none exists, document type: "+docType;
				try {
					main.postCommentEvent(80, // email
							 request_id,
							 "Attachment not found"
							 , msg);
									
				} catch (Exception e) {
				}
  	        	return; // no docs found
  	        }
  	        
  	        String collateral_request_id=query.getColValue("collateral_request_id", "");
  	        String home_equity_id=query.getColValue("home_equity_id", "");
  	        String seqno=query.getColValue("seqno", "");
  	        String respseqno=query.getColValue("respseqno", "");
  	        String occurrence=query.getColValue("occurrence", "");
		    String outputFileName="";
		    String sURL="";
  	        
	        sURL=TAFDocsURL+"&collateral_request_id="+collateral_request_id;
	        sURL=sURL+"&home_equity_id="+home_equity_id;
	        sURL=sURL+"&seqno="+seqno;
	        sURL=sURL+"&respseqno="+respseqno;
	        sURL=sURL+"&occurrence="+occurrence;
	        sURL=sURL+"&taf="+taf_type;
	        sURL=sURL+"&docgen=true";

		    String docDesc="";
	      	 if (taf_type.equals("T")) docDesc="Title_document";
	      	 if (taf_type.equals("A")) docDesc="Appraisal_document";
	      	 if (taf_type.equals("F")) docDesc="Flood_document";
		    
		    docDesc+="_"+request_id; // make the output file name the name of the document appended with request_id to be unique
			docDesc = main.central_pro_output_dir+docDesc;

            main.log(5, "Thread: "+threadID+", request_id: "+request_id+"  calling TAFDocs servlet, url="+sURL+"...");
	        outputFileName=getDocumentFromServlet(sURL,docDesc); // this will retrieve the file using the TAFDocs servlet and store it on disk
	        main.log(5, "Thread: "+threadID+", request_id: "+request_id+"  calling TAFDocs servlet, url="+sURL+"...Done");
	        fileNameList.add(outputFileName);
			email.addAttachmentPart(outputFileName);
  		        
  	        	
      	 
      	 
      	 return;
      	 
       } // attachTAFDocumentImage

       
       
       ////////////////////////////////////////////////////////////////////////
       
       public void attachSysGeneratedDocument(TextEmail email,Connection con,Vector fileNameList,String docID,String request_id,String evaluator_id,String submit_reason_id, String job_name_txt) throws Exception {
      	 
      	 
           main.log(5, "Thread: "+threadID+", request_id: "+request_id+"  adding sys gen document attachment, doc ID : "+docID);
        	 Query query = new Query(con);
        	 String sql="";

      	 String fileName="";
      	 String webDocsURL=main.ini.getINIVar("historydocs.history_docs_url","");
      	 if (webDocsURL.length()==0) throw new Exception("historydocs.history_docs_url not specified in Origenate.ini file");
      	 // use the history_docs_url and modify it for the edocs servlet
      	 
      	 
      	 // we need to get the sequence ID from the credit_req_doc_history table
      	 
      	 
      	 
			SQLUpdate.RunUpdateStatement(
					con,
					"insert into credit_req_doc_history (request_id,evaluator_id,create_dt,document_id,"
							+ "job_type_txt,status_id,user_id,copies_num,job_id,central_pro_server_id,"
							+ "job_name_txt,submit_reason_id,batch_job_id) values ("
							+ request_id
							+ ","
							+ evaluator_id
							+ ",sysdate,"
							+ docID
							+ ",'Email (attach)','SUBMITTED','SYSTEM',1,"
							+ jobID
							+ ",'DEFAULT"
							+ "','"
							+ job_name_txt
							+ "',"
							+ submit_reason_id
							+ ",0)");

      	 
      	 
      	 
      	 sql="select max(seq_id) as seq_id from credit_req_doc_history where request_id = ? and document_id = ? and job_id = ?";
		    query.prepareStatement(sql);
  	        query.setInt(1, Integer.parseInt(request_id));
  	        query.setInt(2, Integer.parseInt(docID));
  	        query.setInt(3, Integer.parseInt(jobID));
  	        query.executePreparedQuery();
  	       if (!query.next()) { // there should be a history req for this doc
  	    	   String msg="Thread: "+threadID+", request_id: "+request_id+"  credit_req_doc_history row not found for doc ID : "+docID;
  	           main.log(5, msg);
  	    	   throw new Exception(msg);
  	       }
  	       
  	       String seq_id = query.getColValue("seq_id","0");
      	 
  	       webDocsURL=webDocsURL.substring(0,webDocsURL.indexOf("HistoryDocs"))+"WebDocs?action=get&doc_hist_seq_id=0&user_id=SYSTEM&fax_number=&recipient=&comments=&request_id="+request_id+"&evaluator_id="+evaluator_id+"&document_id="+docID+"&num_fields=0&sequence_id="+seq_id;
  	        

  	        // WE need to get the doc description to help compose the file name
  	        
  	      	 sql="select description_txt from config_documents where evaluator_id = ? and document_id = ?";
 		    query.prepareStatement(sql);
   	        query.setInt(1, Integer.parseInt(evaluator_id));
   	        query.setInt(2, Integer.parseInt(docID));
   	        query.executePreparedQuery();
   	        query.next();
			String    docDesc=query.getColValue("description_txt","notitle");
		    docDesc=docDesc.replace(" ","_");
		    docDesc+="_"+request_id; // make the output file name the name of the document appended with request_id to be unique
			docDesc = main.central_pro_output_dir+docDesc;
			String outputFileName="";
            main.log(5, "Thread: "+threadID+", request_id: "+request_id+"  calling WebDocs servlet for doc ID: "+docID+" ...");
	        outputFileName=getDocumentFromServlet(webDocsURL,docDesc); // this will retrieve the file using the webdocs servlet and store it on disk in docDesc+ext
            main.log(5, "Thread: "+threadID+", request_id: "+request_id+"  calling WebDocs servlet for doc ID: "+docID+" ...Done");
	        fileNameList.add(outputFileName);
			email.addAttachmentPart(outputFileName);
  		        
      	 return;
      	 
       } // attachSysGeneratedDocument


     ////////////////////////////////////////////////////////////////////////
       
     public void attachImage(TextEmail email,Connection con,Vector fileNameList,String docTypeID,String request_id,String evaluator_id) throws Exception {
    	 
    	 
         main.log(5, "Thread: "+threadID+", request_id: "+request_id+"  adding image attachment (possible multiple pages) for doc type: "+docTypeID);

    	 String fileName="";
    	 String eDocsURL=main.ini.getINIVar("historydocs.history_docs_url","");
    	 if (eDocsURL.length()==0) throw new Exception("historydocs.history_docs_url not specified in Origenate.ini file");
    	 // use the history_docs_url and modify it for the edocs servlet
    	 
    	 eDocsURL=eDocsURL.substring(0,eDocsURL.indexOf("HistoryDocs"))+"eDocs?action=get&filename=";

    	 Query query = new Query(con);
    	 
    		String sql="SELECT imaging_input_dir_txt,imaging_output_dir_txt,imaging_recycle_dir_txt,nvl(manage_images_by_init_dt_flg,0) as init_flg ";
    		sql+=" from evaluator where evaluator_id = ?";
		    query.prepareStatement(sql);
	        query.setInt(1, Integer.parseInt(evaluator_id));
	        query.executePreparedQuery();
	        query.next();
	        String outputDir=query.getColValue("imaging_output_dir_txt","");
            outputDir = StringUtils.expandEnvironmentVariables(outputDir);
	        outputDir=outputDir.replace("\\","/");
	        eDocsURL+=outputDir+"/";
	        String sURL="";

    	 // get the latest doc of this type from the credit_req_contr_docs table
    	 
    	 // MUST GET ALL PAGES OF THIS DOC TYPE!!!
    	 // to do this first find the latest row of this doc type, get its version number. Then
    	 // re-execute the query to get all pages of this doc type
    	 
	        sql="select file_name_txt,version_num from credit_req_contr_docs where request_id = ? and doc_type_id = ? order by received_dt desc";
		    query.prepareStatement(sql);
	        query.setInt(1, Integer.parseInt(request_id));
	        query.setInt(2, Integer.parseInt(docTypeID));
	        query.executePreparedQuery();
	        
	        if (!query.next()) { 
	            main.log(5, "Thread: "+threadID+", request_id: "+request_id+"  no images found of this type: "+docTypeID+", attachment not added");
 	             String docType="";
 		        sql="select description_txt from mstr_contract_doc_types where doc_type_id = ?";
 			    query.prepareStatement(sql);
 		        query.setInt(1, Integer.parseInt(docTypeID));
 		        query.executePreparedQuery();
 		        if (query.next()) docType=query.getColValue(1);
 		        
  	            String msg="Could not attach document to email because none exists, document type: "+docType;
				try {
					main.postCommentEvent(80, // email
							 request_id,
							 "Attachment not found"
							 , msg);
									
				} catch (Exception e) {
				}
	        	return; // no docs found
	        }
	        String version=query.getColValue("version_num", "1");
	        
	        // re-execute the query to get all pages for this version
	        
		     sql="select file_name_txt,page_num,document_desc_txt from credit_req_contr_docs where request_id = ? and doc_type_id = ? and version_num = ? order by page_num";
			    query.prepareStatement(sql);
		        query.setInt(1, Integer.parseInt(request_id));
		        query.setInt(2, Integer.parseInt(docTypeID));
		        query.setInt(3, Integer.parseInt(version));
		        query.executePreparedQuery();
	        
		    String page="";
		    String response="";
		    String docDesc="";
		    String outputFileName="";
	        while(query.next()) { // for each page num
		        fileName=query.getColValue("file_name_txt","");
			    page=query.getColValue("page_num","1");    
			    docDesc=query.getColValue("document_desc_txt","notitle");
			    docDesc=docDesc.replace(" ","_");
			    if (!page.equals("1")) docDesc+="_pg"+page;
			    docDesc+="_"+request_id; // make the output file name the name of the document appended with request_id to be unique
				docDesc = main.central_pro_output_dir+docDesc;
		        if (fileName.length()==0){ 
		            main.log(5, "Thread: "+threadID+", request_id: "+request_id+"  fileName is blank for page: "+page+", version: "+version);
		        	continue; //doc not specified
		        }
		        sURL=eDocsURL+fileName;
	            main.log(5, "Thread: "+threadID+", request_id: "+request_id+"  calling eDocs servlet for: "+docDesc+", page "+page+"...");
		        outputFileName=getDocumentFromServlet(sURL,docDesc); // this will retrieve the file using the eDocs servlet and store it on disk
	            main.log(5, "Thread: "+threadID+", request_id: "+request_id+"  calling eDocs servlet for: "+docDesc+", page "+page+"...Done");
		        fileNameList.add(outputFileName);
				email.addAttachmentPart(outputFileName);
		        
	        	
	        } // while more image pages
    	 
    	 
    	 return;
    	 
     } // attachImage

       
       
	// ///////////////////////////////////////////////////////////////////////

	boolean faxFile(String faxServerURL, String faxServerUserID,
			String faxNumber, String recipient, String fileName,
			String comments, String faxCoverSheet, String unlock_app_flg,
			String move_to_failed_flg, String job_type_txt, String printerName,
			String evaluatorName) throws Exception {

		RightFaxWrapper rightFax = new RightFaxWrapper(main, faxServerURL);
		String rightFaxJobID = null;
		String sql = "";
		PreparedStatement ps = null;

		try {

			// Startup parm of -p1 will prefix a 1 to all fax numbers (required
			// if sending
			// fax long distance). Origenate can only store phone numbers with
			// area codes.

			rightFaxJobID = rightFax.submitFax(faxServerUserID,
					main.faxPhoneNumberPrefix + faxNumber, recipient, fileName,
					comments, faxCoverSheet, job_type_txt, printerName,
					evaluatorName);
		} catch (Exception e) {

			String errStr = "Error submitting to RightFax: " + e.toString();
			errStr = errStr.replace('\'', ' ');
			errStr = errStr.replace('"', ' ');

			main.log(5, "Thread: "+threadID+" "+errStr);

			updateJobAsError(jobID, errStr, con, unlock_app_flg,
					move_to_failed_flg, job_type_txt, "-1");

			return (true); // errorOccurred
		}

		// update the database with the assigned job ID

		String userID = evaluatorName;

		// 1/24/07 ChrisN CL140795 Replaced with SQL using bind variable for Triad performance enhancement
		//SQLUpdate.RunUpdateStatement(con, "update printfax_queue set "
		//		+ "rightfax_job_id = '" + rightFaxJobID
		//		+ "', rightfax_url_txt = '" + faxServerURL
		//		+ "', rightfax_user_id = '" + userID + "' "
		//		+ " where job_id = " + jobID);

		try {
			sql = "update printfax_queue set rightfax_job_id = ?, rightfax_url_txt = ?, rightfax_user_id = ? where job_id = ?";
			ps = con.prepareStatement(sql);
			ps.setString(1, rightFaxJobID);
			ps.setString(2, faxServerURL) ;
			ps.setString(3, userID);
			ps.setInt(4, Integer.parseInt(jobID));
			ps.execute();
			ps.close();

			if (job_type_txt.equals("FAX")) {
				// 1/24/07 ChrisN CL140795 Replaced with SQL using bind variable for Triad performance enhancement
				//SQLUpdate.RunUpdateStatement(con,
				//		"update printfax_queue set status_id = '[FAXING]' where job_id = "
				//				+ jobID);
				sql = "update printfax_queue set status_id = '[FAXING]' where job_id = ?";
				ps = con.prepareStatement(sql);
				ps.setInt(1, Integer.parseInt(jobID));
				ps.execute();
				ps.close();
			}
			else {
				// 1/24/07 ChrisN CL140795 Replaced with SQL using bind variable for Triad performance enhancement
				//SQLUpdate.RunUpdateStatement(con,
				//		"update printfax_queue set status_id = '[PRINTING]' where job_id = "
				//				+ jobID);
				sql = "update printfax_queue set status_id = '[PRINTING]' where job_id = ?";
				ps = con.prepareStatement(sql);
				ps.setInt(1, Integer.parseInt(jobID));
				ps.execute();
				ps.close();
			}
		}
		catch (Exception e) {
		}
		finally {
			try { if (ps != null) ps.close();} catch (Exception e) {e.printStackTrace();}
		}

		// add this job to the monitorThread list of jobs to monitor while
		// we return to process another job

		monitorThread.action(MonitorThread.ADD_JOB, 0, jobID, rightFaxJobID,
				faxServerURL, userID, unlock_app_flg, move_to_failed_flg,
				job_type_txt);

		return (false); // no error
	}

	///////////////////////////////////////////////////////////////////////

	public String createTempFileName() {

		SimpleDateFormat timeFormatter, dateFormatter;
		// hours:mins:secs.milliseconds
		timeFormatter = new SimpleDateFormat("HH.mm.ss.SSS");
		dateFormatter = new SimpleDateFormat("MMddyyyy.");
		// Generate a unique file name based on the current time of the format
		// 11042000.04.13.11.932 11/04/2000 04:13:11 932 millsecs

		java.util.Date dt = new java.util.Date(System.currentTimeMillis());
		String fileName = dateFormatter.format(dt) + timeFormatter.format(dt);
		return (fileName);

	} // createTempFileName

	///////////////////////////////////////////////////////////////////////////////////////

	public void writeFile(String fileName, String str) throws Exception {
		PrintWriter out = null;
		try {
			
			/**  
			* OWASP TOP 10 2010 - A4 Path Manipulation
			* Changes to the below code to fix vulnerabilities
			* TTP 324955
			*/
			//out = new PrintWriter(new FileWriter(fileName));
			out = new PrintWriter(new FileWriter(OWASPSecurity.validationCheck(fileName, OWASPSecurity.FILENAME)));
			
			out.print(str);
			out.flush();
			out.close();
		} catch (Exception e) {
			throw e;
		}
	} // writeFile

	//////////////////////////////////////////////////////////////////////////

	public String readFile(String source) throws Exception {

		BufferedReader sourceFile = null;
		String sourceRecord = null, ret = "";

		boolean done = false;

		// open file for input
		try {
			
			/**  
			* OWASP TOP 10 2010 - A4 Path Manipulation
			* Changes to the below code to fix vulnerabilities
			* TTP 324955
			*/
			//sourceFile = new BufferedReader(new InputStreamReader(new FileInputStream(source)));
			sourceFile = new BufferedReader(new InputStreamReader(new FileInputStream(OWASPSecurity.validationCheck(source, OWASPSecurity.DIRANDFILE))));
				 
		} catch (Exception e) {
			throw e;
		}

		// read first record
		try {
			sourceRecord = sourceFile.readLine();
		} catch (Exception e) {
			sourceFile.close();
			throw e;
		}

		ret = sourceRecord;
        StringBuffer temp_buffer = new StringBuffer(ret);

		while (!done && sourceRecord != null) {

			// read next line of source dataset
			try {
				sourceRecord = sourceFile.readLine();
			} catch (Exception e) {
				done = true;
			}
			if (!done && sourceRecord != null)
				temp_buffer.append(sourceRecord);

		} // while more records
        ret = temp_buffer.toString();

		sourceFile.close();
		if (ret == null)
			ret = "";
		return (ret);

	} // readFile
	
	//////////////////////////////////////////////////////////////////////
	
	  public static String readFileNoLineFeeds(String fileName) throws Exception {

	      BufferedReader textFile = null; 

	      /**  
	      * OWASP TOP 10 2010 - A4 Path Manipulation
	      * Changes to the below code to fix vulnerabilities
	      * TTP 324955
	      */
	      // File file = new File(fileName);
	      File file = new File(OWASPSecurity.validationCheck(fileName, OWASPSecurity.FILENAME));
	      
	      if (!file.exists()) throw new Exception(fileName+" does not exist");
	      long len=file.length();
	      char buf[] = new char[(int)len];

	      int rc;
	      // open file for input
	      
	      /**  
	      * OWASP TOP 10 2010 - A4 Path Manipulation
	      * Changes to the below code to fix vulnerabilities
	      * TTP 324955
	      */
	     // try {  textFile = new BufferedReader(new InputStreamReader(new FileInputStream(fileName)));
	      try {  textFile = new BufferedReader(new InputStreamReader(new FileInputStream(OWASPSecurity.validationCheck(fileName, OWASPSecurity.FILENAME))));
	      
	      }
	      catch(FileNotFoundException e) { throw e; }

	      rc=textFile.read(buf,0,(int)len);
	      textFile.close();
	      if (rc!=(int)len) throw new Exception("Error reading file, rc="+rc);

	      return(new String(buf));

	  } // readFileNoLineFeeds



	///////////////////////////////////////////////////////////////////////////////

	public void updateJobAsError(String jobID, String err, Connection con,
			String unlock_app_flg, String add_failed_alert_flg,
			String job_type_txt, String batch_job_id) {

		// NOTE: ANY CHGS HERE MUST BE MADE TO THE SAME METHOD IN THE
		// MONITORTHREAD

		//see if there is a request_id. If there is not, it is a Broadcast fax

		String sql = "";
		PreparedStatement ps = null;
		Query queryTmp2 = new Query(con);
		try {
			queryTmp2
					.executeQuery("select pq.request_id,cr.evaluator_id,pq.document_id,cr.product_id from printfax_queue pq, credit_request cr where pq.job_id = "
							+ jobID + " and pq.request_id = cr.request_id");
		} catch (Exception e) {
			main.log(0, "Thread: "+threadID+" "+e.toString());
		}

		if (!queryTmp2.next()) {
			// UPDATE THE PRINTFAX QUEUE JOB WITH THE STATUS
			try {
				// 1/24/07 ChrisN CL140795 Replaced with SQL using bind variable for Triad performance enhancement
				//SQLUpdate.RunUpdateStatement(con,
				//		"update printfax_queue set status_id = 'ERROR', error_txt = '"
				//				+ err
				//				+ "',finished_dt = sysdate where job_id = "
				//				+ jobID);
				sql = "update printfax_queue set status_id = 'ERROR', error_txt = ?, finished_dt = sysdate where job_id = ?";
				ps = con.prepareStatement(sql);
				
				/** OWASP Top 10 2010 - A4 Access Control Database
				  * Change to the below code to fix vulnerabilities
				  * TTP 324955
				  */
				//ps.setString(1, err);
				ps.setString(1, OWASPSecurity.validationCheck(err, OWASPSecurity.SQLPARAMSTRING));
				
				ps.setInt(2, Integer.parseInt(jobID));
				ps.execute();
				ps.close();
			} catch (Exception e) {
				main.log(0, "Thread: "+threadID+" "+e.toString());
			}
			finally {
					try { if (ps != null) ps.close();} catch (Exception e1) {e1.printStackTrace();}
			}
		} else {

			Query queryTmp = new Query(con);

			boolean errorOccurred = false;
			String request_id = "0";
			String document_id = "0";
			String evaluator_id = "0";
			String product_id = "1"; // INDIRECT AUTO
			String document_name = "Document name not found";
			String fax_number = "0";
			String user_id = "";
			String assigned_user_id = "";
			String originator_id = "";

			// err can be a max of 300 chars to fit in the error_txt column

			// take the last 300 chars, cause thats where the meat of the err is
			// also remove single quotes

			if (err.length() > 300)
				err = err.substring(err.length() - 300);

			err = err.replace('\'', ' ');
			err = err.replace('"', ' ');

			try {

				queryTmp
						.executeQuery("select pq.fax_number_txt,pq.request_id,cr.evaluator_id,pq.document_id,cr.product_id from printfax_queue pq, credit_request cr where pq.job_id = "
								+ jobID + " and pq.request_id = cr.request_id");

				if (queryTmp.next()) {
					request_id = queryTmp.getColValue("request_id", "0");
					evaluator_id = queryTmp.getColValue("evaluator_id", "0");
					product_id = queryTmp.getColValue("product_id", "1");
					document_id = queryTmp.getColValue("document_id", "0");
					fax_number = queryTmp.getColValue("fax_number_txt", "0");
				}

				if (request_id.equals("0"))
					main
							.log(
									0,
									"ERROR: Can't update job to error status, can't find request_id in job row, job ID: "
											+ jobID + ", request_id set to 0");

				//TTP 324955 Security Remediation Fortify Scan
				queryTmp
						.prepareStatement("select cd.description_txt from config_documents cd where cd.document_id = ?"
								+ " and cd.evaluator_id = ?");
				queryTmp.setInt(1, document_id);
				queryTmp.setInt(2, evaluator_id);
				queryTmp.executePreparedQuery();
				if (queryTmp.next()) {
					document_name = queryTmp.getColValue("description_txt",
							"Document name is null");
				} else
					main
							.log(
									0,
									"ERROR: Document ID: "
											+ document_id
											+ " in PF job, not found in config_documents table for job: "
											+ jobID);

				// UPDATE THE PRINTFAX QUEUE JOB WITH THE STATUS

				// 1/24/07 ChrisN CL140795 Replaced with SQL using bind variable for Triad performance enhancement
				//SQLUpdate.RunUpdateStatement(con,
				//		"update printfax_queue set status_id = 'ERROR', error_txt = '"
				//				+ err
				//				+ "',finished_dt = sysdate where job_id = "
				//				+ jobID);
				sql = "update printfax_queue set status_id = 'ERROR', error_txt = ?, finished_dt = sysdate where job_id = ?";
				ps = con.prepareStatement(sql);
				
				/** OWASP Top 10 2010 - A4 Access Control Database
				  * Change to the below code to fix vulnerabilities
				  * TTP 324955
				  */
				//ps.setString(1, err);
				ps.setString(1, OWASPSecurity.validationCheck(err, OWASPSecurity.SQLPARAMSTRING));
				
				ps.setInt(2, Integer.parseInt(jobID));
				ps.execute();
				try { if (ps != null) ps.close();} catch (Exception e1) {e1.printStackTrace();}

				// UPDATE THE DOC HISTORY ROW WITH THE STATUS

				// 1/24/07 ChrisN CL140795 Replaced with SQL using bind variable for Triad performance enhancement
				//SQLUpdate
				//		.RunUpdateStatement(
				//				con,
				//				"update credit_req_doc_history "
				//						+ "set status_id = 'ERROR', print_date = sysdate,"
				//						+ "error_txt = '" + err + "'"
				//						+ " where job_id = " + jobID);
				sql = "update credit_req_doc_history set status_id = 'ERROR',  print_date = sysdate, error_txt = ? where job_id = ?";
				ps = con.prepareStatement(sql);
				
				/** OWASP Top 10 2010 - A4 Access Control Database
				  * Change to the below code to fix vulnerabilities
				  * TTP 324955
				  */
				//ps.setString(1, err);
				ps.setString(1, OWASPSecurity.validationCheck(err, OWASPSecurity.SQLPARAMSTRING));
				
				ps.setInt(2, Integer.parseInt(jobID));
				ps.execute();
				try { if (ps != null) ps.close();} catch (Exception e1) {e1.printStackTrace();}

				// POST AN ERROR COMMENT TO THE JOURNAL

				if (job_type_txt.equals("EMAIL")) {
					try {
						main.postCommentEvent(80, // email
								 request_id,
								 "Email FAILED"
								 , document_name
										+ " Reason:" + err );
					} catch (Exception e) {
						main.log(0, "Thread: "+threadID+" "+"Can't post comment for jobID:" + jobID
								+ " request_id:" + request_id + " err="
								+ e.toString());
					}
				} // email

				if (job_type_txt.equals("ESIGN")) {
					try {
						main.postCommentEvent(85, // esign
								 request_id,
								 "eSign Request FAILED"
								 , document_name
										+ " Reason:" + err );
					} catch (Exception e) {
						main.log(0, "Thread: "+threadID+" "+"Can't post comment for jobID:" + jobID
								+ " request_id:" + request_id + " err="
								+ e.toString());
					}
				} // esign

				if (job_type_txt.equals("ESIGNVOID")) {
					try {
						main.postCommentEvent(85, // esign
								 request_id,
								 "eSign Void Request FAILED"
								 , document_name
										+ " Reason:" + err );
					} catch (Exception e) {
						main.log(0, "Thread: "+threadID+" "+"Can't post comment for jobID:" + jobID
								+ " request_id:" + request_id + " err="
								+ e.toString());
					}
				} // esignvoid
					
					
					if (job_type_txt.equals("FAX"))
						try {
							main.postCommentEvent((job_type_txt.equals("FAX")) ? 19
									: 29, request_id,
									((job_type_txt.equals("FAX")) ? "Fax FAILED"
											: "Print FAILED"), document_name
											+ " Reason:" + err + " Fax:" + fax_number);
						} catch (Exception e) {
							main.log(0, "Thread: "+threadID+" "+"Can't post comment for jobID:" + jobID
									+ " request_id:" + request_id + " err="
									+ e.toString());
						}
						
						if (job_type_txt.equals("EMAIL")) {
							/*
							 * Post a journal event for this app to indicate that a this
							 * document failed
							 */

							try {

								int reqID = Integer.parseInt(request_id);
								JournalEvents journalEvents = new JournalEvents(con,
										null);
								// 91-email
								journalEvents.addJournal(reqID, 91, "Email failed: "
										+ document_name, "SYSTEM");
							} catch (Exception e) {
								main.log(0, "Thread: "+threadID+" "+"Can't post journal event for jobID:"
										+ jobID + " request_id:" + request_id + " err="
										+ e.toString());
							}
						}
						else
                                                   if (job_type_txt.equals("ESIGN")) {
                                                           /*
                                                            * Post a journal event for this app to indicate that a this
                                                            * document failed
                                                            */

                                                           try {

                                                                   int reqID = Integer.parseInt(request_id);
                                                                   JournalEvents journalEvents = new JournalEvents(con,
                                                                                   null);
                                                                   // 91-email
                                                                   journalEvents.addJournal(reqID, 105, "eSigning failed: "
                                                                                   + document_name, "SYSTEM");
                                                           } catch (Exception e) {
                                                                   main.log(0, "Thread: "+threadID+" "+"Can't post journal event for jobID:"
                                                                                   + jobID + " request_id:" + request_id + " err="
                                                                                   + e.toString());
                                                           }
                                                   }
                                                   else
                                                      if (job_type_txt.equals("ESIGNVOID")) {
                                                              /*
                                                               * Post a journal event for this app to indicate that a this
                                                               * document failed
                                                               */

                                                              try {

                                                                      int reqID = Integer.parseInt(request_id);
                                                                      JournalEvents journalEvents = new JournalEvents(con,
                                                                                      null);
                                                                      // 91-email
                                                                      journalEvents.addJournal(reqID, 105, "eSigning failed: "
                                                                                      + document_name, "SYSTEM");
                                                              } catch (Exception e) {
                                                                      main.log(0, "Thread: "+threadID+" "+"Can't post journal event for jobID:"
                                                                                      + jobID + " request_id:" + request_id + " err="
                                                                                      + e.toString());
                                                              }
                                                      }
                                                      else
				if (job_type_txt.equals("FAX")) {
					/*
					 * Post a journal event for this app to indicate that a this
					 * document failed
					 */

					try {

						int reqID = Integer.parseInt(request_id);
						JournalEvents journalEvents = new JournalEvents(con,
								null);
						// 42-faxed
						journalEvents.addJournal(reqID, 42, "Fax failed: "
								+ document_name, "SYSTEM");
					} catch (Exception e) {
						main.log(0, "Thread: "+threadID+" "+"Can't post journal event for jobID:"
								+ jobID + " request_id:" + request_id + " err="
								+ e.toString());
					}
				} else if (job_type_txt.equals("Print")
						|| (job_type_txt.equals("BATCH")
								&& batch_job_id != null && batch_job_id
								.equals("0"))) {
					try {
						main.postCommentEvent((job_type_txt.equals("FAX")) ? 19
								: 29, request_id,
								((job_type_txt.equals("FAX")) ? "Fax FAILED"
										: "Print FAILED"), document_name
										+ " Reason:" + err);
					} catch (Exception e) {
						main.log(0, "Thread: "+threadID+" "+"Can't post comment for jobID:" + jobID
								+ " request_id:" + request_id + " err="
								+ e.toString());
					}
					try {

						int reqID = Integer.parseInt(request_id);
						JournalEvents journalEvents = new JournalEvents(con,
								null);
						journalEvents.addJournal(reqID, 41,
								"Print to Queue failed: " + document_name,
								"SYSTEM");
					} catch (Exception e) {
						main.log(0, "Thread: "+threadID+" "+"Can't post journal event for jobID:"
								+ jobID + " request_id:" + request_id + " err="
								+ e.toString());
					}
				} else {
					/*
					 * Post a journal event for this app to indicate that a this
					 * document failed
					 */

					try {

						int reqID = Integer.parseInt(request_id);
						JournalEvents journalEvents = new JournalEvents(con,
								null);
						// 41-batch print
						journalEvents.addJournal(reqID, 41,
								"Batch print failed: " + document_name,
								"SYSTEM");
					} catch (Exception e) {
						main.log(0, "Thread: "+threadID+" "+"Can't post journal event for jobID:"
								+ jobID + " request_id:" + request_id + " err="
								+ e.toString());
					}
				}

			} catch (Exception e) {
				main.log(0, "Thread: "+threadID+" "+"ERROR: Can't update job to error state, job ID: "
						+ jobID + " orig error msg: " + err + " reason: "
						+ e.toString());
				errorOccurred = true;
			}
			finally {
                           try { if (ps != null) ps.close();} catch (Exception e1) {e1.printStackTrace();}
			}

			if (!errorOccurred) {

				// ADD CODE HERE TO UNLOCK APP AND ADD FAILED ALERT BASED ON
				// FLGS

				if (unlock_app_flg.equals("1")) {
					// unlcok the app
					try {
						appLockingManager.releaseLockOnApp((long) Integer
								.parseInt(request_id));
					} catch (Exception e) {
						// already marked as error so can only log the message
						main.log(0,
								"Thread: "+threadID+" "+"ERROR: Can't release lock on app for job: "
										+ jobID + " reason: " + e.toString());
					}
				}

				if (add_failed_alert_flg.equals("1")) {

					Query query = new Query(con);
					// add Failed Transmittal Alert
					try {
						//code to add the assigned userid to the credit request alert table
						query.executeQuery("select user_id,evaluator_id from printfax_queue where job_id = " + jobID);

						if (query.next()) {
							user_id = query.getColValue("user_id"," ");
							evaluator_id = query.getColValue("evaluator_id");
						}
						if(user_id.equalsIgnoreCase("SYSTEM")){
							query.executeQuery("select originator_id from credit_request_originator where request_id = " + Integer.parseInt(request_id) + "and evaluator_id = " + Integer.parseInt(evaluator_id));
							if(query.next()){
								originator_id = query.getColValue("originator_id");
							}
							if(originator_id != null){
								query.executeQuery("select assigned_user_id from evaluator_originator where originator_id = " + Integer.parseInt(originator_id) + "and evaluator_id = " + Integer.parseInt(evaluator_id));
								if(query.next())
									assigned_user_id = query.getColValue("assigned_user_id","SYSTEM");
							}
						}
						else{
							assigned_user_id = user_id;
						}
						assigned_user_id = assigned_user_id != null ? assigned_user_id : "";
						//add the alert
						Alert alert = new Alert((int) Integer
								.parseInt(request_id), Alert.getNextSeq_Id(
								(int) Integer.parseInt(request_id), con), 6,
								"open", new Date(), null,
								"Failed Transmittal: jobID-" + jobID
										+ "  document_id-" + document_id
										+ "  document_name-" + document_name
										+ "  job_type_txt-" + job_type_txt, assigned_user_id, con);
						alert.addAlert();
					} catch (Exception e) {
						// already marked as error so can only log the message
						main.log(0,
								"Thread: "+threadID+" "+"ERROR: Can not add Failed Transmittal Alert for job: "
										+ jobID + " reason: " + e.toString());
					}

				}

			} // !errorOccurred



                        if (job_type_txt.equals("ESIGNVOID")) { // delete the job because needs to be resubmitted by user, comments were written

                          try {
                              sql = "delete from printfax_queue where job_id = ?";
                              ps = con.prepareStatement(sql);
                              ps.setInt(1, Integer.parseInt(jobID));
                              ps.execute();
                              try { if (ps != null) ps.close();} catch (Exception e1) {e1.printStackTrace();}
                          } catch (Exception ex) {}

                        }

			return;

		}
	}// updateJobAsError

	///////////////////////////////////////////////////////////////////////////////

	public void updateJobAsSuccess(String jobID, Connection con,
			String unlock_app_flg, String move_to_failed_flg,
			String job_type_txt, String batch_job_id,boolean printedWithCentralPro) {
		// NOTE: ANY CHGS HERE MUST BE MADE TO THE SAME METHOD IN THE
		// MONITORTHREAD

		//see if there is a request_id. If there is not, it is a Broadcast fax
		String sql = "";
		PreparedStatement ps = null;

		Query queryTmp2 = new Query(con);
		try {
			queryTmp2
					.executeQuery("select pq.request_id,cr.evaluator_id,pq.document_id,cr.product_id from printfax_queue pq, credit_request cr where pq.job_id = "
							+ jobID + " and pq.request_id = cr.request_id");
		} catch (Exception e) {
			main.log(0, "Thread: "+threadID+" "+e.toString());
		}

		if (!queryTmp2.next()) {
			try {
				// 1/24/07 ChrisN CL140795 Replaced with SQL using bind variable for Triad performance enhancement
				//SQLUpdate.RunUpdateStatement(con,
				//		"delete from printfax_queue_values where job_id = "
				//				+ jobID);
				//SQLUpdate.RunUpdateStatement(con,
				//		"delete from printfax_queue where job_id = " + jobID);

				sql = "delete from printfax_queue_values where job_id = ?";
        ps = con.prepareStatement(sql);
        ps.setInt(1, Integer.parseInt(jobID));
        ps.execute();
        ps.close();

		sql = "delete from printfax_queue_attachments where job_id = ?";
        ps = con.prepareStatement(sql);
        ps.setInt(1, Integer.parseInt(jobID));
        ps.execute();
        ps.close();
        

                sql = "delete from printfax_queue_recipients where job_id = ?";
        ps = con.prepareStatement(sql);
        ps.setInt(1, Integer.parseInt(jobID));
        ps.execute();
        ps.close();

				sql = "delete from printfax_queue where job_id = ?";
        ps = con.prepareStatement(sql);
        ps.setInt(1, Integer.parseInt(jobID));
        ps.execute();
        ps.close();

			} catch (Exception e) {
				main.log(0, "Thread: "+threadID+" "+e.toString());
			}
			finally {
					try {ps.close(); } catch (Exception e1) {}
			}
		} else {

			Query queryTmp = new Query(con);

			boolean errorOccurred = false;
			String request_id = "0";
			String evaluator_id = "0";
			String product_id = "1"; // INDIRECT AUTO
			String document_name = "Document name not found";
			String document_id = "0";
			boolean badJobInfo = false;

			try {

				queryTmp
						.prepareStatement("select pq.request_id,cr.evaluator_id,pq.document_id,cr.product_id from printfax_queue pq, credit_request cr where pq.job_id = ? and pq.request_id = cr.request_id");
				queryTmp.setInt(1, Integer.parseInt(jobID));
				queryTmp.executePreparedQuery();
				if (queryTmp.next()) {
					request_id = queryTmp.getColValue("request_id", "0");
					evaluator_id = queryTmp.getColValue("evaluator_id", "0");
					product_id = queryTmp.getColValue("product_id", "1");
					document_id = queryTmp.getColValue("document_id", "0");
				}

				if (request_id.equals("0")) {
					main
							.log(
									0,
									"ERROR: Can't update job to success status, can't find request_id in job row, job ID: "
											+ jobID + ", request_id set to 0");
					badJobInfo = true;
				}

				queryTmp
						.prepareStatement("select cd.description_txt from config_documents cd where cd.document_id = ? "
								+ " and cd.evaluator_id = ? ");
				queryTmp.setInt(1,Integer.parseInt(document_id));
				queryTmp.setInt(2,Integer.parseInt(evaluator_id));
				queryTmp.executePreparedQuery();
				if (queryTmp.next()) {
					document_name = queryTmp.getColValue("description_txt",
							"Document name is null");
				} else {
					main
							.log(
									0,
									"ERROR: Document ID: "
											+ document_id
											+ " in PF job, not found in config_documents table for job: "
											+ jobID);
					badJobInfo = true;
				}

				// UPDATE THE DOC HISTORY ROW WITH THE STATUS

                                if (printedWithCentralPro) {

                                   /*
                                   This does the same thing as the monitor thread if a batch
                                   was printed with RightFax
                                   */

                                   /*
                                    * Batch jobs will update the hist row as PRINTED to
                                    * indicate that the doc was printed by RightFax. The user
                                    * will use the Lender Print Tool to delete the batch when
                                    * they are satisfied that all documents in the batch have
                                    * printed.
                                    */

                                   // 1/24/07 ChrisN CL140795 Replaced with SQL using bind variable for Triad performance enhancement
                                   // UPDATE THE PRINTFAX QUEUE JOB WITH THE STATUS
                                   //SQLUpdate.RunUpdateStatement(con,
                                   //                "update printfax_queue set status_id = 'PRINTED', error_txt = NULL"
                                   //                                + ", finished_dt = sysdate where job_id = "
                                   //                                + jobID);

                                   //SQLUpdate
                                   //                .RunUpdateStatement(
                                   //                                con,
                                   //                                "update credit_req_doc_history "
                                   //                                                + "set status_id = 'SUCCESS', print_date = sysdate, error_txt = NULL where job_id = "
                                   //                                                + jobID);

																	sql = "update printfax_queue set status_id = 'PRINTED', error_txt = NULL, finished_dt = sysdate where job_id = ?";
																	ps = con.prepareStatement(sql);
																	ps.setInt(1, Integer.parseInt(jobID));
																	ps.execute();
																	ps.close();

																	sql = "update credit_req_doc_history set status_id = 'SUCCESS', print_date = sysdate, error_txt = NULL where job_id = ?";
																	ps = con.prepareStatement(sql);
																	ps.setInt(1, Integer.parseInt(jobID));
																	ps.execute();
																	ps.close();

                                   /*
                                    * Post a journal event for this app to indicate that a this
                                    * document was printed
                                    */

                                   try {

                                           int reqID = Integer.parseInt(request_id);
                                           JournalEvents journalEvents = new JournalEvents(con,
                                                           null);
                   						if (job_type_txt.equals("EMAIL")) 
                							journalEvents.addJournal(reqID, 91, "Emailed: "
                									+ document_name, "SYSTEM");
                						else

                                           // 41-batch print
                                           journalEvents.addJournal(reqID, 41, "Batch print: "
                                                           + document_name, "SYSTEM");
                                   } catch (Exception e) {
                                           main.log(0, "Thread: "+threadID+" "+"Can't post journal event for jobID:"
                                                           + jobID + " request_id:" + request_id + " err="
                                                           + e.toString());
                                   }


                                   String response = "", sURL = "";

                                   /*
                                    * Wei Ma 9/14/04 update early disclosure doc to see if
                                    * activity 38 can be marked as complete and update Alert
                                    * status for early disclosure.
                                    */
                                   if (main.sEarlyDiscURL.length() == 0)
                                           main
                                                           .log(
                                                                           0,
                                                                           "contract_completion_check_url in ini file is empty, can't update early disclosure");
                                   else
                                           try {
                                                   sURL = main.sEarlyDiscURL + request_id
                                                                   + "&user_id=SYSTEM&evaluator_id="
                                                                   + evaluator_id+ "&closeSession=true";
                                                   main.log(5, "Thread: "+threadID+" "+"Posting for early disclosure to: "
                                                                   + sURL);
                                                   PostRequest postRequest = new PostRequest();
                                                   response = postRequest.post(sURL, "", 30);// timeout
                                                   // 30
                                                   // secs
                                                   main.log(5,
                                                                   "Thread: "+threadID+" "+"Posting for early disclosure done, response="
                                                                                   + response);
                                           } catch (Exception e) {
                                                   // not serious enough to stop, just log error
                                                   main.log(0, "Thread: "+threadID+" "+"WARNING: Can not post to: " + sURL
                                                                   + " , error=" + e.toString());
                                           }

                                   response = "";
                                   sURL = "";

                                   /*
                                    * GL. 5/6/04 run completion rules for closing doc to see if
                                    * activity 22 - Doc Gen can be marked as complete when the
                                    * last doc in a closing package is printed.
                                    */
                                   if (main.sRunRulesURL.length() == 0)
                                           main
                                                           .log(
                                                                           0,
                                                                           "contract_completion_check_url in ini file is empty, can't run rules for closing docs");
                                   else
                                           try {
                                                   sURL = main.sRunRulesURL + request_id
                                                                   + "&user_id=SYSTEM&evaluator_id="
                                                                   + evaluator_id+ "&closeSession=true";
                                                   main.log(5, "Thread: "+threadID+" "+"Posting for completion rules to: "
                                                                   + sURL);
                                                   PostRequest postRequest = new PostRequest();
                                                   response = postRequest.post(sURL, "", 30);// timeout
                                                   // 30
                                                   // secs
                                                   main.log(5,
                                                                   "Thread: "+threadID+" "+"Posting for completion rules done, response="
                                                                                   + response);
                                           } catch (Exception e) {
                                                   // not serious enough to stop, just log error
                                                   main.log(0, "Thread: "+threadID+" "+"WARNING: Can not post to: " + sURL
                                                                   + " for completion rules, error="
                                                                   + e.toString());
                                           }




                                }
                                else
                                   /*
                                    * Batch jobs will update the hist row as GENERATED to indicate
                                    * that the doc was generated and is waiting for the Batch
                                    * Lender Tool to pull it to the lender site to be printed. At
                                    * that point the hist will be set to SUCCESS and a comment
                                    * posted. The nightletters on the next nights run checks for
                                    * GENERATED or SUCCESS to prevent it from reprocessing this
                                    * document
                                    */

				if (job_type_txt.equals("BATCH")
						&& (batch_job_id == null || !batch_job_id.equals("0"))) {

					// UPDATE THE PRINTFAX QUEUE JOB WITH THE STATUS

					// 1/24/07 ChrisN CL140795 Replaced with SQL using bind variable for Triad performance enhancement
					//SQLUpdate.RunUpdateStatement(con,
					//		"update printfax_queue set status_id = 'READY', error_txt = NULL"
					//				+ ", finished_dt = sysdate where job_id = "
					//				+ jobID);

					//SQLUpdate
					//		.RunUpdateStatement(
					//				con,
					//				"update credit_req_doc_history "
					//						+ "set status_id = 'GENERATED', print_date = sysdate, error_txt = NULL where job_id = "
					//						+ jobID);

					sql = "update printfax_queue set status_id = 'READY', error_txt = NULL, finished_dt = sysdate where job_id = ?";
					ps = con.prepareStatement(sql);
					ps.setInt(1, Integer.parseInt(jobID));
					ps.execute();
					ps.close();

					sql = "update credit_req_doc_history set status_id = 'GENERATED', print_date = sysdate, error_txt = NULL where job_id = ?";
					ps = con.prepareStatement(sql);
					ps.setInt(1, Integer.parseInt(jobID));
					ps.execute();
					ps.close();

					/*
					 * Post a journal event for this app to indicate that a this
					 * document was printed
					 */

					try {

						int reqID = Integer.parseInt(request_id);
						JournalEvents journalEvents = new JournalEvents(con,
								null);
						// 41-batch print
						if (job_type_txt.equals("EMAIL")) 
							journalEvents.addJournal(reqID, 91, "Emailed: "
									+ document_name, "SYSTEM");
						else
							journalEvents.addJournal(reqID, 41, "Batch print: "
								+ document_name, "SYSTEM");
					} catch (Exception e) {
						main.log(0, "Thread: "+threadID+" "+"Can't post journal event for jobID:"
								+ jobID + " request_id:" + request_id + " err="
								+ e.toString());
					}

					/*
					 * DON'T WORRY ABOUT CHECKING IF THE CLOSING DOC ACTIVITY IS
					 * COMPLETE HERE BECAUSE IT WILL BE CHECKED BY THE LENDER
					 * PRINT BATCH TOOL
					 */

					String response = "", sURL = "";
					/*
					 * Wei Ma 9/14/04 update early disclosure doc to see if
					 * activity 38 can be marked as complete and update Alert
					 * status for early disclosure.
					 */
					if (main.sEarlyDiscURL.length() == 0)
						main
								.log(
										0,
										"contract_completion_check_url in ini file is empty, can't update early disclosure");
					else
						try {
							sURL = main.sEarlyDiscURL + request_id
									+ "&user_id=SYSTEM&evaluator_id="
									+ evaluator_id+ "&closeSession=true";
							main.log(5, "Thread: "+threadID+" "+"Posting for early disclosure to: "
									+ sURL);
							PostRequest postRequest = new PostRequest();
							response = postRequest.post(sURL, "", 30);// timeout
							// 30
							// secs
							//main.log(5,"Thread: "+threadID+" "+"Posting for early disclosure done, response="+ response);  
									
											
						} catch (Exception e) {
							// not serious enough to stop, just log error
							main.log(0, "Thread: "+threadID+" "+"WARNING: Can not post to: " + sURL
									+ " , error=" + e.toString());
						}

				} else if (job_type_txt.equals("BATCH") && batch_job_id != null
						&& batch_job_id.equals("0")) {
					// UPDATE THE PRINTFAX QUEUE JOB WITH THE STATUS
					try {
						// 1/24/07 ChrisN CL140795 Replaced with SQL using bind variable for Triad performance enhancement
						//SQLUpdate.RunUpdateStatement(con,
						//		"delete from printfax_queue_values where job_id = "
						//				+ jobID);
						//SQLUpdate.RunUpdateStatement(con,
						//		"delete from printfax_queue where job_id = "
						//				+ jobID);
						//SQLUpdate
						//		.RunUpdateStatement(
						//				con,
						//				"update credit_req_doc_history "
						//						+ "set status_id = 'SUCCESS', print_date = sysdate, error_txt = NULL where job_id = "
						//						+ jobID);
						sql = "delete from printfax_queue_values where job_id = ?";
		        ps = con.prepareStatement(sql);
		        ps.setInt(1, Integer.parseInt(jobID));
		        ps.execute();
		        ps.close();
		        
				sql = "delete from printfax_queue_attachments where job_id = ?";
		        ps = con.prepareStatement(sql);
		        ps.setInt(1, Integer.parseInt(jobID));
		        ps.execute();
		        ps.close();


                                sql = "delete from printfax_queue_recipients where job_id = ?";
                        ps = con.prepareStatement(sql);
                        ps.setInt(1, Integer.parseInt(jobID));
                        ps.execute();
                        ps.close();

						sql = "delete from printfax_queue where job_id = ?";
		        ps = con.prepareStatement(sql);
		        ps.setInt(1, Integer.parseInt(jobID));
		        ps.execute();
		        ps.close();

						sql = "update credit_req_doc_history set status_id = 'SUCCESS', print_date = sysdate, error_txt = NULL where job_id = ?";
		        ps = con.prepareStatement(sql);
		        ps.setInt(1, Integer.parseInt(jobID));
		        ps.execute();
		        ps.close();
					} catch (Exception e) {
						main.log(0, "Thread: "+threadID+" "+e.toString());
					}
          finally {
						try { if (ps != null) ps.close();} catch (Exception e1) {e1.printStackTrace();}
    			}

					/*
					 * Post a journal event for this app to indicate that a this
					 * document was printed
					 */

					try {

						int reqID = Integer.parseInt(request_id);
						JournalEvents journalEvents = new JournalEvents(con,
								null);
						if (job_type_txt.equals("EMAIL")) 
							journalEvents.addJournal(reqID, 91, "Emailed: "
									+ document_name, "SYSTEM");
						else
                                                   if (job_type_txt.equals("ESIGN")) 
                                                           journalEvents.addJournal(reqID, 105,
                                                                           document_name+" sent for signing", "SYSTEM");
                                                   else
                                                      if (job_type_txt.equals("ESIGNVOID")) 
                                                              journalEvents.addJournal(reqID, 105,
                                                                              document_name+" sign request voided", "SYSTEM");
                                                      else
							journalEvents.addJournal(reqID, 41, "Processed successfully: "
								+ document_name, "SYSTEM");
					} catch (Exception e) {
						main.log(0, "Thread: "+threadID+" "+"Can't post journal event for jobID:"
								+ jobID + " request_id:" + request_id + " err="
								+ e.toString());
					}
				} else {

					// FAX

					// can now remove the job to clean the queue clean

					if (!badJobInfo) {

						// 1/24/07 ChrisN CL140795 Replaced with SQL using bind variable for Triad performance enhancement
						//SQLUpdate.RunUpdateStatement(con,
						//		"delete from printfax_queue_values where job_id = "
						//				+ jobID);

						//SQLUpdate.RunUpdateStatement(con,
						//		"delete from printfax_queue where job_id = "
						//				+ jobID);

						sql = "delete from printfax_queue_values where job_id = ?";
		        ps = con.prepareStatement(sql);
		        ps.setInt(1, Integer.parseInt(jobID));
		        ps.execute();
		        ps.close();
		        
				sql = "delete from printfax_queue_attachments where job_id = ?";
		        ps = con.prepareStatement(sql);
		        ps.setInt(1, Integer.parseInt(jobID));
		        ps.execute();
		        ps.close();


                               sql = "delete from printfax_queue_recipients where job_id = ?";
                       ps = con.prepareStatement(sql);
                       ps.setInt(1, Integer.parseInt(jobID));
                       ps.execute();
                       ps.close();

						sql = "delete from printfax_queue where job_id = ?";
		        ps = con.prepareStatement(sql);
		        ps.setInt(1, Integer.parseInt(jobID));
		        ps.execute();
		        ps.close();
					} else {
						//SQLUpdate
						//		.RunUpdateStatement(
						//				con,
						//				"update printfax_queue set status_id = 'SUCCESSBUT', error_txt = '"
						//						+ "Failed to get request_id data from job row, can't complete status update, see log',finished_dt = sysdate where job_id = "
						//						+ jobID);
							sql = "update printfax_queue set status_id = 'SUCCESSBUT', error_txt = 'Failed to get request_id data from job row, cannot complete status update, see log', finished_dt = sysdate where job_id = ?";
							ps = con.prepareStatement(sql);
							ps.setInt(1, Integer.parseInt(jobID));
							ps.execute();
							ps.close();
					}

					// 1/24/07 ChrisN CL140795 Replaced with SQL using bind variable for Triad performance enhancement
					//SQLUpdate
					//		.RunUpdateStatement(
					//				con,
					//				"update credit_req_doc_history "
					//						+ "set status_id = 'SUCCESS', print_date = sysdate, error_txt = NULL where job_id = "
					//						+ jobID);
					sql = "update credit_req_doc_history set status_id = 'SUCCESS', print_date = sysdate, error_txt = NULL where job_id = ?";
					if (job_type_txt.equals("ESIGN")) 
                                           sql = "update credit_req_doc_history set status_id = 'SENT', print_date = sysdate, error_txt = NULL where job_id = ?";
					if (job_type_txt.equals("ESIGNVOID")) 
                                           sql = "update credit_req_doc_history set status_id = 'VOIDED', print_date = sysdate, error_txt = NULL where job_id = ?";

					ps = con.prepareStatement(sql);
					ps.setInt(1, Integer.parseInt(jobID));
					ps.execute();
					ps.close();

					// POST A SUCCESS COMMENT 
					if (job_type_txt.equals("ESIGN")) {
						try {
							main
									.postCommentEvent(85, // esign event
											request_id,
											"eSign request sent",
											document_name);
						} catch (Exception e) {
							main.log(0, "Thread: "+threadID+" "+"Can't post comment for jobID:" + jobID
									+ " request_id:" + request_id + " err="
									+ e.toString());
						}
						
					}
					else	
                                           if (job_type_txt.equals("ESIGNVOID")) {
                                                   try {
                                                           main
                                                                           .postCommentEvent(85, // esign event
                                                                                           request_id,
                                                                                           "eSign request voided",
                                                                                           document_name);
                                                   } catch (Exception e) {
                                                           main.log(0, "Thread: "+threadID+" "+"Can't post comment for jobID:" + jobID
                                                                           + " request_id:" + request_id + " err="
                                                                           + e.toString());
                                                   }

                                           }
                                           else	
					if (job_type_txt.equals("EMAIL")) {
						try {
							main
									.postCommentEvent(80, // email event
											request_id,
											"Email successful",
											document_name);
						} catch (Exception e) {
							main.log(0, "Thread: "+threadID+" "+"Can't post comment for jobID:" + jobID
									+ " request_id:" + request_id + " err="
									+ e.toString());
						}
						
					}
					else	
					if (job_type_txt.equals("FAX"))
						try {
							main
									.postCommentEvent(
											(job_type_txt.equals("FAX")) ? 19
													: 29,
											request_id,
											((job_type_txt.equals("FAX")) ? "Fax successful"
													: "Print successful"),
											document_name);
						} catch (Exception e) {
							main.log(0, "Thread: "+threadID+" "+"Can't post comment for jobID:" + jobID
									+ " request_id:" + request_id + " err="
									+ e.toString());
						}

					/*
					 * Post a journal event for this app to indicate that a this
					 * document was faxed
					 */

					try {

						int reqID = Integer.parseInt(request_id);
						JournalEvents journalEvents = new JournalEvents(con,
								null);
						if (job_type_txt.equals("ESIGN")) 
							journalEvents.addJournal(reqID, 105,
									 document_name+" sent for signing", "SYSTEM");
						else
                                                   if (job_type_txt.equals("ESIGNVOID")) 
                                                           journalEvents.addJournal(reqID, 105,
                                                                            document_name+" sign request voided", "SYSTEM");
                                                   else
						if (job_type_txt.equals("EMAIL")) 
							journalEvents.addJournal(reqID, 91, "Emailed: "
									+ document_name, "SYSTEM");
						else
						// 42-faxed
						journalEvents.addJournal(reqID, 42, "Faxed: "
								+ document_name, "SYSTEM");
					} catch (Exception e) {
						main.log(0, "Thread: "+threadID+" "+"Can't post journal event for jobID:"
								+ jobID + " request_id:" + request_id + " err="
								+ e.toString());
					}
				} // fax

			} catch (Exception e) {
				main.log(0,
						"Thread: "+threadID+" "+"ERROR: Can't update job to success state, job ID: "
								+ jobID + " reason: " + e.toString());
				errorOccurred = true;
			}
			finally {
					try { if (ps != null) ps.close();} catch (Exception e1) {e1.printStackTrace();}
			}

			if (!errorOccurred) {

				if (unlock_app_flg.equals("1")) {

					// unlock the app

					try {
						appLockingManager.releaseLockOnApp((long) Integer
								.parseInt(request_id));
					} catch (Exception e) {
						// already marked as success so can only log the message
						main.log(0,
								"Thread: "+threadID+" "+"ERROR: Can't release lock on app for job: "
										+ jobID + " reason: " + e.toString());
					}
				}

				// GL & CC. 01/26/04 If this FAX previously failed and has a
				// failed transmittal alert then remove the alert so they
				//can continue processing it
				if (job_type_txt.equals("FAX")) {
					try {
						//Remove the alert
						int seq_id = 0;
						Query query = new Query(con);
						// TTP 324955 Security Remediation Fortify Scan
						query
								.prepareStatement("select max(seq_id) as SEQ_ID from credit_request_alerts where request_id = ?"
										+ " and status_txt = 'open' and detail_txt like 'Failed Fax Transmittal%'");
						query.setInt(1, request_id);
						query.executePreparedQuery();

						try {
							while (query.next()) {
								seq_id = (int) Integer.parseInt(query
										.getColValue("SEQ_ID"));
							}
						} catch (Exception e) {

						}
						Alert alert = Alert.getAlert((int) Integer
								.parseInt(request_id), seq_id, con);
						alert.setCLOSE_DT(new Date());
						alert.setSTATUS_TXT("closed");
						alert.updateAllAlert();
					} catch (Exception e) {
						// already marked as success so can only log the message
						main.log(0,
								"Thread: "+threadID+" "+"ERROR: Can't remove Failed Transmittal alert from app for job: "
										+ jobID + " reason: " + e.toString());
					}

				}

			} // !errorOccurred

			return;
		}
	}// updateJobAsSuccess

	private void pullBackIfInFailedTask(String request_id, String document_id,
			String evaluator_id) throws Exception {

		// GL. 01/26/04 If this FAX previously failed and is in the
		// failed transmittal task then pull it back out and move it
		// to the previous task group, task_id, and user so they can continue
		// processing it

		Query query = new Query(con);
		String sql = "";
		PreparedStatement ps = null;

		// Only do this if its a transmittal type doc

		query
				.executeQuery("select evaluator_id from config_evaluator_documents "
						+ "where evaluator_id = "
						+ evaluator_id
						+ " and "
						+ "document_id = "
						+ document_id
						+ " and (category_id = 'MANUAL_DECISION_TRANSMITTAL' OR category_id = 'AUTO_DECISION_TRANSMITTAL')");
		if (!query.next())
			return;

		// Its a transmittal, soo now see if the app is in the failed
		// transmittal task

		query
				.executeQuery("select request_id from credit_request where request_id = "
						+ request_id
						+ " and task_id = '"
						+ ApplicationIDs.tsk_failedtransmittal
						+ "' and "
						+ "task_group_id = '"
						+ ApplicationIDs.tsk_grp_system
						+ "'");

		if (!query.next())
			return;

		// pull it back if previous values are avail

		query
				.executeQuery("select previous_task_id, previous_team_id, previous_user_id, "
						+ "previous_task_group_id from credit_request where request_id = "
						+ request_id);

		query.next();

		String previous_task_id, previous_team_id, previous_user_id, previous_task_group_id;

		previous_task_id = query.getColValue("previous_task_id", "");
		previous_team_id = query.getColValue("previous_team_id", "");
		previous_user_id = query.getColValue("previous_user_id", "");
		previous_task_group_id = query
				.getColValue("previous_task_group_id", "");

		if (previous_task_id.length() == 0)
			throw new Exception("Previous task id is empty");
		if (previous_team_id.length() == 0)
			throw new Exception("Previous team id is empty");
		if (previous_task_group_id.length() == 0)
			throw new Exception("Previous task group is empty");

		// good to go, so pull it back

		if (!workFlowManager.setNewTaskandTaskGroup((long) Integer
				.parseInt(request_id), previous_task_id,
				previous_task_group_id, previous_user_id)) // this will only set
			// audit_update_user_id
			throw new Exception("error recorded in workFlowMgr");

		try {
			// 1/24/07 ChrisN CL140795 Replaced with SQL using bind variable for Triad performance enhancement
			//SQLUpdate.RunUpdateStatement(con, "update credit_request "
			//		+ "set assigned_user_id = '" + previous_user_id
			//		+ "', assigned_team_id = " + previous_team_id
			//		+ " where request_id = " + request_id);

			sql = "update credit_request set assigned_user_id = ?, assigned_team_id = ? where request_id = ?";
			ps = con.prepareStatement(sql);
			ps.setString(1, previous_user_id);
			ps.setInt(2, Integer.parseInt(previous_team_id));
			ps.setInt(3, Integer.parseInt(request_id));
			ps.execute();
			ps.close();
		}
		catch (Exception e) {
		}
		finally {
			try {ps.close(); } catch (Exception e1) {}
		}

		applicationStatusManager.calcNewApplicationStatus((long) Integer
				.parseInt(request_id), Integer.parseInt(evaluator_id));

	} // pullBackIfInFailedTask


        ///////////////////////////////////////////////////////////////////////////////////////


        public void  saveCopyOfImage(Connection con,String evaluator_id,String document_id,String request_id,String outputFileName,String jobID) {

           String seq_id="0";
           String contentType="pdf";
           byte data[] = null;

           // If this document is configured to save copies then call the historyDocs servlet to do so

           Query query = new Query(con);

           try {

              
              query.prepareStatement("select nvl(save_images_flg,0) as save_images_flg, form_name_txt from config_documents where evaluator_id = ? and document_id = ?");
              query.setInt(1,evaluator_id);
              query.setInt(2,document_id);
              query.executePreparedQuery();

              if (!query.next()) return;

              if (query.getColValue("save_images_flg","0").equals("0")) return; // not configured to save a copy

              if (query.getColValue("form_name_txt",".pdf").endsWith(".txt")) contentType="txt";

              // need to get the seq_id of the history doc row that this image relates to so that the hsit servlet can update it
              // with a pointer to the image row that will be created in credit_req_doc_hist_imgs. We can use the
              // jobID of this print job to find it


              query.prepareStatement("select seq_id from credit_req_doc_history where job_id = ?");
              query.setInt(1,jobID);
              query.executePreparedQuery();

              if (!query.next()) throw new Exception("Could not find credit_req_doc_history row with this job_id: "+jobID);

              seq_id=query.getColValue("seq_id","0");

              // get the content to be saved

              data = readBinaryFile(outputFileName);



              if (main.historyDocsURL.length() == 0) throw new Exception("history-docs-url not specified on command line with -h parameter");


              String URLparms = "action=put&request_id="+request_id+"&evaluator_id="+evaluator_id+"&doc_hist_seq_id="+seq_id+
                 "&content_type="+contentType+"&document_id="+document_id;

              BASE64Encoder encoder = new BASE64Encoder();
              String body = encoder.encode(data);

              URLparms+="&content="+body;

              PostRequest postRequest = new PostRequest();
              String response = postRequest.post(main.historyDocsURL,URLparms,180); // 3 min timeout


              //writeLog(INFOMSG, "history docs servlet response="+response);
              if (response.indexOf("sequence_id=") < 0) throw new Exception(response); // error returned

              String sequence_id = response.substring(response.indexOf("sequence_id=")+12,response.indexOf("end"));

              // update the history row with the sequence number of the row that was created in credit_req_doc_hist_imgs


			  //TTP 324955 Security Remediation Fortify Scan
              SQLUpdate sqlup = new SQLUpdate();
              sqlup.SetPreparedUpdateStatement(con, "update credit_req_doc_history set hist_imgs_seq_id = ? where request_id = ? and seq_id = ?");
              sqlup.setInt(1, sequence_id);
              sqlup.setInt(2, request_id);
              sqlup.setInt(3, seq_id);
              sqlup.RunPreparedUpdateStatement();

           }
           catch (Exception e) {
              // log problem but do not stop processing just because we could not save the image
              // we do not want to abort the original webdocs call. Usually, the error will be related to a config problem.
              main.log(0,
                      "Thread: "+threadID+" "+"Could not save a copy of requested document for history purposes, error = "+e.toString());
           }


        } // saveCopyOfImage


    ///////////////////////////////////////////////////////////////////////////////////////

      public byte[] readBinaryFile(String fileName) throws Exception {

    	  /**  
    	  * OWASP TOP 10 2010 - A4 Path Manipulation
    	  * Changes to the below code to fix vulnerabilities
    	  * TTP 324955
    	  */
          // File fileIn=new File(fileName);
    	  File fileIn=new File(OWASPSecurity.validationCheck(fileName, OWASPSecurity.FILENAME));

          long len=fileIn.length();

          byte buf[] = new byte[(int)len];
          int numread=0;

          FileInputStream fileInputStream = new FileInputStream(fileIn);

          numread=fileInputStream.read(buf);

          fileInputStream.close();
          //System.gc();

          if (numread!=(int)len) throw new Exception("Error reading file, rc="+numread+" len="+len);

          return(buf);

      } // readBinaryFile


      ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

      public void  getHistoryDoc(Connection con,String doc_hist_seq_id,String outputFileName,String successFileName,String errorFileName) throws Exception {

        // this method will act like the PDFComposer in that it will create an output file, success file, or error file. 
        // However, it will use the HistoryDocs servlet to get the contents to be written to the output file

      try {

         Query query = new Query(con);
         String select = "select request_id,evaluator_id,hist_imgs_seq_id from credit_req_doc_history where seq_id = ?";
         query.prepareStatement(select);
         query.setInt(1,doc_hist_seq_id);
         query.executePreparedQuery();

         if (!query.next()) throw new Exception("Doc history row not found for seq_id="+doc_hist_seq_id);

         String sequence_id = query.getColValue("hist_imgs_seq_id","");
         if (sequence_id.length()==0) throw new Exception("Doc history row found for seq_id, but pointer to hist_imgs row in credit_req_doc_hist_imgs is null, ="+doc_hist_seq_id);
         String request_id = query.getColValue("request_id","");

         if (main.historyDocsURL.length() == 0) throw new Exception("historydocs.history_docs_url not specified in origenate.ini file");


         String urlStr = main.historyDocsURL+"?action=get&request_id="+request_id+"&sequence_id="+sequence_id;


            HttpURLConnection httpConn = null;
            HttpsURLConnection httpsConn = null;


                    // used when reading response from History docs as binary data ( pdf or tif )
                    byte bufData1[] = null;
                    byte bufData2[] = null;
                    boolean usingBuf1 = true;
                    String inputLine, responseData = "";
                    StringBuffer temp_buffer = new StringBuffer("");
                    boolean textFileReturned=false;

                    URL url = new URL(urlStr);

                    String scheme = url.getProtocol();

                    boolean https = (url.getProtocol().toLowerCase().equals("https"));

                    if (https) {
                            // set the protocol handler for https
                            System.setProperty("java.protocol.handler.pkgs",
                                            "com.sun.net.ssl.internal.www.protocol");
                            httpsConn = (HttpsURLConnection) url.openConnection();
                            httpsConn.setDoOutput(true);
                            httpsConn.setDoInput(true);
                            httpsConn.setUseCaches(false);
                            if (urlStr.indexOf("?") > 0)
                                    httpsConn.setRequestMethod("GET");
                            else
                                    httpsConn.setRequestMethod("POST");
                    } else {
                            httpConn = (HttpURLConnection) url.openConnection();
                            httpConn.setDoOutput(true);
                            httpConn.setDoInput(true);
                            httpConn.setUseCaches(false);
                            if (urlStr.indexOf("?") > 0) {
                                    httpConn.setRequestMethod("GET");
                                    //writeLog(INFOMSG,"Setting method to http GET");
                            } else
                                    httpConn.setRequestMethod("POST");
                    }

                    /*
                     * for (Enumeration e = headers.keys (); e.hasMoreElements (); ) {
                     * Object key = e.nextElement (); httpConn.setRequestProperty
                     * ((String)key,(String)headers.get(key)); }
                     */

                    Writer out = null;

                    out = new OutputStreamWriter((https) ? httpsConn.getOutputStream()
                                    : httpConn.getOutputStream(), "UTF8");

                    out.write("", 0, 0); // no content to write
                    out.flush();
                    out.close(); // ESSENTIAL!

                    /* read response, should be a PDF file */

                    String contentType;

                    if (https)
                            contentType = httpsConn.getContentType();
                    else
                            contentType = httpConn.getContentType();

                    //writeLog(INFOMSG,"Content type returned: "+contentType);


                    InputStream ins = (https) ? httpsConn.getInputStream() : httpConn
                                    .getInputStream();

                    String contentTypeExt="pdf";

                    boolean errorReturned=false;

                    //writeLog(INFOMSG, "Reading response from: " + urlStr);

                    if (contentType.toLowerCase().endsWith("html") || contentType.toLowerCase().endsWith("plain")) { // error or text file returned

                       if (contentType.toLowerCase().endsWith("html")) errorReturned=true; // html is an error being returned from HistoryDocs

                       if (contentType.toLowerCase().endsWith("plain")) contentTypeExt="txt";

                            // read the text response
                       BufferedReader in = null;
                       try {
                               in = new BufferedReader(new InputStreamReader(
                                                               ins));
                               while ((inputLine = in.readLine()) != null)
                                               temp_buffer.append(inputLine);
                                     responseData = temp_buffer.toString();
                               in.close();
                               ins.close();
                       } catch (Exception ex) {
                               throw ex;
                       } finally {
                               try{in.close();} catch(Exception ex){}
                               try{ins.close();} catch(Exception ex){}
                       }
                             textFileReturned=true;


                            if (errorReturned) throw new Exception(responseData);

                    } else { // binary pdf or tif data passed back

                            if (contentType.toLowerCase().endsWith("tiff")) contentTypeExt="tif";

                            BufferedInputStream in = new BufferedInputStream(ins);
                            int buflen = 16384; // read in 16k chunks
                            String data = "";
                            byte buf[] = new byte[buflen];
                            int numbytes = 0, numread;

                            while ((numread = in.read(buf, 0, buflen)) != -1) {
                                    // move read buffer to aggregate response data

                                    // first, increase size of bufData array to accomodate
                                    // appending buf

                                    numbytes += numread;

                                    if (bufData1 == null) { // first time
                                            bufData1 = new byte[numread];
                                            System.arraycopy(buf, 0, bufData1, 0, numread);
                                            usingBuf1 = true;
                                    } else if (usingBuf1) {
                                            usingBuf1 = false;
                                            bufData2 = new byte[numbytes];
                                            System.arraycopy(bufData1, 0, bufData2, 0,
                                                            bufData1.length);
                                            System.arraycopy(buf, 0, bufData2, bufData1.length,
                                                            numread);
                                    } else {
                                            usingBuf1 = true;
                                            bufData1 = new byte[numbytes];
                                            System.arraycopy(bufData2, 0, bufData1, 0,
                                                            bufData2.length);
                                            System.arraycopy(buf, 0, bufData1, bufData2.length,
                                                            numread);
                                    }

                            }

                            //writeLog(INFOMSG,"numbytes "+numbytes);

                            in.close();
                            ins.close();

                    }  // binary data sent

                    if (https)
                            httpsConn.disconnect();
                    else
                            httpConn.disconnect();

                   // write the content to the output file

                    if (textFileReturned)
                       writeBinaryFile(outputFileName,responseData.getBytes());
                    else
                       if (usingBuf1)
                          writeBinaryFile(outputFileName,bufData1);
                       else
                          writeBinaryFile(outputFileName,bufData2);

                  // now write success file

                  writeStringToFile(successFileName,"success");

            } catch (Exception e) { // Unexpected error

                    String msg = "Failed to get content for doc history row: "+doc_hist_seq_id+", err= "+e.toString();
                    writeStringToFile(errorFileName,msg);
            } finally {
               // any cleanup  here
            }


      } // getHistoryDoc()


      ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

      public String  getDocumentFromServlet(String urlStr,String outputFileName) throws Exception {

        // this method will act like the PDFComposer in that it will create an output file, success file, or error file. 
        // However, it will use the HistoryDocs servlet to get the contents to be written to the output file

    	String returnFileName=outputFileName;  
      try {




            HttpURLConnection httpConn = null;
            HttpsURLConnection httpsConn = null;


                    // used when reading response from History docs as binary data ( pdf or tif )
                    byte bufData1[] = null;
                    byte bufData2[] = null;
                    boolean usingBuf1 = true;
                    String inputLine, responseData = "";
                    StringBuffer temp_buffer = new StringBuffer("");
                    boolean textFileReturned=false;

                    URL url = new URL(urlStr);

                    String scheme = url.getProtocol();

                    boolean https = (url.getProtocol().toLowerCase().equals("https"));

                    if (https) {
                            // set the protocol handler for https
                            System.setProperty("java.protocol.handler.pkgs",
                                            "com.sun.net.ssl.internal.www.protocol");
                            httpsConn = (HttpsURLConnection) url.openConnection();
                            httpsConn.setDoOutput(true);
                            httpsConn.setDoInput(true);
                            httpsConn.setUseCaches(false);
                            if (urlStr.indexOf("?") > 0)
                                    httpsConn.setRequestMethod("GET");
                            else
                                    httpsConn.setRequestMethod("POST");
                    } else {
                            httpConn = (HttpURLConnection) url.openConnection();
                            httpConn.setDoOutput(true);
                            httpConn.setDoInput(true);
                            httpConn.setUseCaches(false);
                            if (urlStr.indexOf("?") > 0) {
                                    httpConn.setRequestMethod("GET");
                                    //writeLog(INFOMSG,"Setting method to http GET");
                            } else
                                    httpConn.setRequestMethod("POST");
                    }

                    /*
                     * for (Enumeration e = headers.keys (); e.hasMoreElements (); ) {
                     * Object key = e.nextElement (); httpConn.setRequestProperty
                     * ((String)key,(String)headers.get(key)); }
                     */

                    Writer out = null;

                    out = new OutputStreamWriter((https) ? httpsConn.getOutputStream()
                                    : httpConn.getOutputStream(), "UTF8");

                    out.write("", 0, 0); // no content to write
                    out.flush();
                    out.close(); // ESSENTIAL!

                    /* read response, should be a PDF file */

                    String contentType;

                    if (https)
                            contentType = httpsConn.getContentType();
                    else
                            contentType = httpConn.getContentType();

                    //writeLog(INFOMSG,"Content type returned: "+contentType);


                    InputStream ins = (https) ? httpsConn.getInputStream() : httpConn
                                    .getInputStream();

                    String contentTypeExt="pdf";

                    boolean errorReturned=false;

                    //writeLog(INFOMSG, "Reading response from: " + urlStr);

                    if (contentType.toLowerCase().endsWith("html") || contentType.toLowerCase().endsWith("plain")) { // error or text file returned

                       if (contentType.toLowerCase().endsWith("html")) errorReturned=true; // html is an error being returned from HistoryDocs

                       if (contentType.toLowerCase().endsWith("plain")) contentTypeExt="txt";

                            // read the text response
                       BufferedReader in = null;
                       try {
                               in = new BufferedReader(new InputStreamReader(
                                                               ins));
                               while ((inputLine = in.readLine()) != null)
                                               temp_buffer.append(inputLine);
                               responseData = temp_buffer.toString();
                               in.close();
                               ins.close();
                       } catch (Exception ex) {
                               throw ex;
                       } finally {
                               try{in.close();} catch(Exception ex){}
                               try{ins.close();} catch(Exception ex){}
                       }
                            textFileReturned=true;

                            if (errorReturned) throw new Exception(responseData);

                    } else { // binary pdf or tif data passed back

                            if (contentType.toLowerCase().endsWith("tiff")) contentTypeExt="tif";

                            BufferedInputStream in = new BufferedInputStream(ins);
                            int buflen = 16384; // read in 16k chunks
                            String data = "";
                            byte buf[] = new byte[buflen];
                            int numbytes = 0, numread;

                            while ((numread = in.read(buf, 0, buflen)) != -1) {
                                    // move read buffer to aggregate response data

                                    // first, increase size of bufData array to accomodate
                                    // appending buf

                                    numbytes += numread;

                                    if (bufData1 == null) { // first time
                                            bufData1 = new byte[numread];
                                            System.arraycopy(buf, 0, bufData1, 0, numread);
                                            usingBuf1 = true;
                                    } else if (usingBuf1) {
                                            usingBuf1 = false;
                                            bufData2 = new byte[numbytes];
                                            System.arraycopy(bufData1, 0, bufData2, 0,
                                                            bufData1.length);
                                            System.arraycopy(buf, 0, bufData2, bufData1.length,
                                                            numread);
                                    } else {
                                            usingBuf1 = true;
                                            bufData1 = new byte[numbytes];
                                            System.arraycopy(bufData2, 0, bufData1, 0,
                                                            bufData2.length);
                                            System.arraycopy(buf, 0, bufData1, bufData2.length,
                                                            numread);
                                    }

                            }

                            //writeLog(INFOMSG,"numbytes "+numbytes);

                            in.close();
                            ins.close();

                    }  // binary data sent

                    if (https)
                            httpsConn.disconnect();
                    else
                            httpConn.disconnect();

                   // write the content to the output file
                    
                    outputFileName+="."+contentTypeExt;
                    returnFileName=outputFileName;

                    if (textFileReturned)
                       writeBinaryFile(outputFileName,responseData.getBytes());
                    else
                       if (usingBuf1)
                          writeBinaryFile(outputFileName,bufData1);
                       else
                          writeBinaryFile(outputFileName,bufData2);


            } catch (Exception e) { // Unexpected error

                    String msg = "Failed to get eDocs Image, err= "+e.toString();
                    throw new Exception(msg);
            } finally {
               // any cleanup  here
            }
            
            return(returnFileName);


      } // getEDocsImage()

      
/////////////////////////////////////////////////////

   public void writeStringToFile(String fileName,String str) throws Exception {
       PrintWriter out=null;
       
       /**  
       * OWASP TOP 10 2010 - A4 Path Manipulation
       * Changes to the below code to fix vulnerabilities
       * TTP 324955
       */
       //out = new PrintWriter(new FileWriter(fileName));
       out = new PrintWriter(new FileWriter(OWASPSecurity.validationCheck(fileName, OWASPSecurity.FILENAME)));
       
       out.print(str);
       out.flush();
       out.close();
   }

///////////////////////////////////////////////////////////////////////////////////////

  private void writeBinaryFile(String fileName,byte [] buf) throws Exception {

	  /**  
	  * OWASP TOP 10 2010 - A4 Path Manipulation
	  * Changes to the below code to fix vulnerabilities
	  */
      //FileOutputStream OutFile = new FileOutputStream(fileName);
	  FileOutputStream OutFile = new FileOutputStream(OWASPSecurity.validationCheck(fileName, OWASPSecurity.FILENAME));
	  
     DataOutputStream Data = new DataOutputStream(OutFile );
     Data.write(buf,0,buf.length);
     Data.flush();
     Data.close();


  } // writeBinaryFile



  public void conactFile(String outputFileName,String batch_job_id,String submit_reason_id) throws Exception {

     // the only time we want to concat to a batch file is if the batch file ID is non zero and
     // the reason ID is one of the valid batch reasons
     /*
     Decline - 5
        Counter - 6
        Expired - 8
        Welcome - 7
        Withdraw - 18
        */

     synchronized (critsec) { // this code must be synchronized because multiple threads might be trying to append to the same batch file at the same time


     String batchFileName = "";

     try {

           byte data[] = null;

           if (batch_job_id.length()==0 || batch_job_id.equals("0")) return;

           String batchType="";
           if (submit_reason_id.equals("5")) batchType="decline";
           if (submit_reason_id.equals("6")) batchType="counter";
           if (submit_reason_id.equals("8")) batchType="expired";
           if (submit_reason_id.equals("7")) batchType="welcome";
           if (submit_reason_id.equals("18")) batchType="withdraw";

           if (batchType.length()==0) return;

           SimpleDateFormat dateFormatter;
           dateFormatter = new SimpleDateFormat("MMddyyyy");
           java.util.Date dt = new java.util.Date(System.currentTimeMillis());

           // central_pro_output_dir is trailing with a file.separator
           batchFileName = main.central_pro_output_dir+batchType+"_"+batch_job_id+"_"+dateFormatter.format(dt)+".pdf";
           String batchFileNameTmp = batchFileName+".tmp";

           main.log(5, "Thread: "+threadID+" "+"Appending "+outputFileName+"  to  "+batchFileName);
           
           /**  
           * OWASP TOP 10 2010 - A4 Path Manipulation
           * Changes to the below code to fix vulnerabilities
           * TTP 324955
           */
           //File batchFile = new File(batchFileName);
           File batchFile = new File(OWASPSecurity.validationCheck(batchFileName, OWASPSecurity.FILENAME));

           if (!batchFile.exists()) { // if this is the first file to be added to the concatenated batch file then just copy it to the batch file
              // note: the original file will be deleted by the calling code

              data = readBinaryFile(outputFileName);
              writeBinaryFile(batchFileName,data);

           }  
           else { // append this file to the end of the batch file

                 ConcatPDFs cpdf = new ConcatPDFs(false);
                                               // start file        append file          result file
                 cpdf.concatPDFFiles(batchFileName,outputFileName, batchFileNameTmp);


                 batchFile.delete(); // need to delete the orig batch file before renaming the tmp version
                 renameFile(batchFileNameTmp,batchFileName);


           }
     }
     catch (Exception e) {
        main.log(0,"Thread: "+threadID+" "+"ERROR concatenating file:"+outputFileName+"   to   "+batchFileName+", err="+e.toString());
     }


     } // sync

     return;


  }  // concatFile()


  public void renameFile(String fromFileName,String toFileName) throws Exception {
	 
	  /**  
	  * OWASP TOP 10 2010 - A4 Path Manipulation
	  * Changes to the below code to fix vulnerabilities
	  * TTP 324955
	  */
      /* File fromFile = new File(fromFileName);
         File toFile = new File(toFileName);*/
	   File fromFile = new File(OWASPSecurity.validationCheck(fromFileName, OWASPSecurity.FILENAME));
	   File toFile = new File(OWASPSecurity.validationCheck(toFileName, OWASPSecurity.FILENAME));

     if (!fromFile.renameTo(toFile)) throw new Exception("Unknow error renaming file: "+fromFileName+"  to  "+toFileName);
  }





} // ProcessThread

