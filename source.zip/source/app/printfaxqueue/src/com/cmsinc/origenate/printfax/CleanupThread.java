package com.cmsinc.origenate.printfax;

import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import com.cmsinc.origenate.util.LogMsg;
import com.cmsinc.origenate.util.Query;
import com.cmsinc.origenate.util.OWASPSecurity;
/**
 * This thread is used to monitor the status of fax jobs
 *  
 */
public class CleanupThread extends Thread {

	// INSTANCE VARIABLES

	Connection con = null;

	PrintFaxProcessor main = null;

	boolean endThread = false;

	//int threadID = 0;

	//String sConStr, sUser, sPass;

	//LogMsg log_obj = null;

	String central_pro_output_dir = "";

	// CONSTRUCTOR

	public CleanupThread(PrintFaxProcessor main, String sConStr, String sUser,
			String sPass, int ID, LogMsg log_obj, String central_pro_output_dir)
			throws Exception {

		//threadID = ID;
		this.main = main;
		//this.sConStr = sConStr;
		//this.sUser = sUser;
		//this.sPass = sPass;
		//this.log_obj = log_obj;
		this.central_pro_output_dir = central_pro_output_dir;

		// Connect to the Oracle database
		con = DriverManager.getConnection(sConStr, sUser, sPass);

	} // end constructor

	////////////////////////////////////////////////////////////////////////////

	// RUN METHOD - execution continues in its own thread

	public void run() {

		main.log(0, "Cleanup thread running...");

		Query queryTmp = new Query(con);
		File outputDir; //  File object that describes output-dir
		File fileList[] = null; // array of file objects returned by fileList()

		/**		
		 * OWASP TOP 10 2010 - A4 Path Manipulation
	     * Changes to the below code to fix vulnerabilities
	     * TTP 324955
		 **/		
		//outputDir = new File(central_pro_output_dir);
		outputDir=null;
		try
		{
		outputDir = new File(OWASPSecurity.validationCheck(central_pro_output_dir, OWASPSecurity.DIRANDFILE));
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		String fileName = "", jobID = "";


                /* GL. 8/13/2010 Before we start our loop delete all outstanding esign files that were locked by Docusign during the previous run.
                */

                fileList = outputDir.listFiles();
                for (int i = fileList.length; i != 0; i--) {
                   if (!fileList[i - 1].isFile()) continue;
                   fileName = fileList[i - 1].getName().toLowerCase();
                   if (fileName.startsWith("esign_")) 
                           fileList[i - 1].delete();
                } // for


		while (!endThread) {

			try {

				fileList = outputDir.listFiles();

				// for each file found in the output dir if it represents a
				// file that was part of a batch then the file name will contain
				// the job id. If the job id no longer exists in the
				// printfax_queue
				// table then remove the file because the user deleted the row
				// and
				// we want to get rid of the file that was associated with it.

				for (int i = fileList.length; i != 0; i--) {

					if (endThread)
						break;

					if (fileList[i - 1].isFile()) {

						fileName = fileList[i - 1].getName().toLowerCase();
						if (fileName.indexOf("_job_") > 0) {
							jobID = fileName.substring(fileName
									.indexOf("_job_") + 5, fileName
									.indexOf("_product")); // filename now ends with product_id
							String sql = "select job_id from printfax_queue where job_id = ? ";
							queryTmp.prepareStatement(sql);
							queryTmp.setInt(1, jobID);
							queryTmp.executePreparedQuery();
							if (!queryTmp.next()) {
								// job no longer exists so delete the file
								String batch_id = fileName.substring(fileName
										.indexOf("_batch_") + 7, fileName
										.indexOf("_job"));
								if (!batch_id.equals("0")) {
									fileList[i - 1].delete();
									main.log(0, "Cleanup: deleted file: "
											+ fileName);
								}
							}

						}

					} // is file
				} // for

			} catch (Exception e) {
				main.log(0, "Cleanup Thread serious error: " + e.toString());
			}

			// sleep for 60 seconds and try again

			if (!endThread)
				try {
					Thread.sleep(60000);
				} catch (Exception e) {
				}

		} // while not end thread

		try {
			con.close();
		} catch (Exception e1) {
		}

		// fall thru to end thread

	} // end run()

} // CleanupThread

