
package com.cmsinc.origenate.printfax;

import java.net.MalformedURLException;
import java.net.UnknownHostException;
import java.io.IOException;
import java.util.*;
import java.io.*;
import RightFAX.*;
import sun.misc.BASE64Encoder;
import java.net.URLEncoder;

import com.cmsinc.origenate.util.OWASPSecurity;

public class RightFaxWrapper {

    String rightFaxURL=null;
    PrintFaxProcessor main=null;

    public RightFaxWrapper(PrintFaxProcessor main,String rightFaxURL) {

        this.main=main;
        this.rightFaxURL=rightFaxURL;

    }


    ///////////////////////////////////////////////////////////////////


    public String submitFax(String rightFaxUserID,String faxNumber,
                            String recipient,String fileName,String comments,
                            String faxCoverSheet,String job_type_txt,String printerName,
                            String evaluatorName) throws Exception {


        main.log(5,"RightFax info: (URL) "+rightFaxURL+" (userID) "+rightFaxUserID+
                 " (fax #) "+faxNumber+" (recipient) "+recipient+" (cover) "+faxCoverSheet+
                 " (file) "+fileName+" (comments) "+comments+" (job_type) "+job_type_txt+" (printer) "+printerName+
                 " (evalname userID) "+evaluatorName);

        //Create a outbound fax object

        RFaxSubmit obFS = new RFaxSubmit();
        //Set the URL of the RightFAX server
        obFS.setTargetURL(rightFaxURL);


        //obFS.setDebug(true); // dumps low level xml set to server by rightfax api

       //Set the information on who is sending the fax
       // use the simplist form which simply takes a valid RightFax User ID
       // We are assuming that we will always have a CMSI user defined!

        /* Enhancement: RightFax will be controlling billing and calling rules based on the
           user ID sent to RF. We will be using the evaluator name as the
           user ID since the billing is controlled at the evaluator level.
           To make it a valid name we will upshift, truncate to 20 chars,
           and replace spaces with underscore.

           Printing will use the std user ID in the Fax server setup.
        */


       if (job_type_txt.equals("FAX"))  {
          // url encoding these did not help, so the name can not have special chars
          // in it like &
          obFS.m_FaxDocument.setSenderInfo(evaluatorName);
       }
       else {
          //GL. always submit jobs under the evaluator name
          //obFS.m_FaxDocument.setSenderInfo(rightFaxUserID);
          obFS.m_FaxDocument.setSenderInfo(evaluatorName);
          //GL.
       }



       // use the simplist form of addRecipient
       // obFS.m_FaxDocument.addRecipient ("(413)521-3886");

       /*
       Full version of addRecipient includes the following:

         sID - an identifier (15 character max) for this message and recipient. 
               Should be unique for each message and recipient. 
               Used to identify documents when querying. 
               If left blank, one will be generated. - OPTIONAL
         sFaxNum - fax number to send the message to. - REQUIRED
         sIncFile - file (on fax server) to include with each recipient.
         sName - name of the person to receive the fax - OPTIONAL
         sCompany - company fax is being sent to - OPTIONAL
         sAltFaxNum - alernate fax number to try if the primary one fails - OPTIONAL
         sPhone - phone number of person to receive the fax. - OPTIONAL
         sCoverSheet - name of the cover page to use (file on fax server) - OPTIONAL
         sNotifyName - identifier of the Notification channel to use. - OPTIONAL (must have success and fail templates to use name).
         sNotifySuccessTemplate - teplate file to use when doing Notifications of succes. - OPTIONAL (must have fail template to use fail template)
         sNotifyFailureTemplate - teplate file to use when doing Notifications of failure. - OPTIONAL (must have success template to use fail template)
         sDefIncFile - file (on fax server) to include with each recipient.

       */

       short numCopies=1;

       Long lval= Long.valueOf(System.currentTimeMillis());
       String sID=lval.toString();

       if (sID.length()>15) sID=sID.substring(sID.length()-15); // get trailing 15 chars (more unique)


       recipient=URLEncoder.encode(recipient);

       if (job_type_txt.equals("FAX"))
          obFS.m_FaxDocument.addRecipient (sID, // sID - "" means let RightFax assign
                                           faxNumber,     // sFaxNum
                                           "",             // sIncFile 
                                           recipient,  // sName 
                                           "",             // sCompany
                                           "",             // sAltFaxNum 
                                           "",             // sPhone 
                                           faxCoverSheet,  // sCoverSheet
                                           "",             // sNotifyName
                                           "",             // sNotifySuccessTemplat
                                           "",             // sNotifyFailureTemplat
                                           ""              // sDefIncFile
                                           );
       else // USING RIGHTFAX TO PRINT
          obFS.m_FaxDocument.addRecipient_printer (sID, // sID - "" means let RightFax assign 
                                                   printerName,
                                                   numCopies);
       

       // Set the body text

       // test
       // obFS.m_FaxDocument.setBody ( "Here is some body text", "TXT", -1, -1, -1, "Arial", -1, -1); 


       byte buf[] = readBinaryFile(fileName); 

       BASE64Encoder encoder = new BASE64Encoder();

       String body = encoder.encode(buf);

       String fileExt=(fileName.substring(fileName.length()-3)).toUpperCase();

       // RF needs to know the type of data being passed so take the remaining three
       // chars of the ext. Should be PDF or TIF


       /*
       GL. RightFax 9.0 added an additional parm to setBody() which specifies the font size.
       In order to still have one code base I created a new class called RightFaxCalls
       that encapsulates the setBody() call so we can compile with either the 8.0 or
       9.0 jar file. I embedded the new class (for each version) in each jar file using the
       following steps. This only needs to be done once to create an 8.0 or 9.0 version
       of the rightfax.jar file.

       For 8.0
       Rename RightFaxCalls.java.8.0 to RightFaxCalls.java
       Copy the rightfax 80 jar file to the JDK's lib\jre\ext dir. 
       javac RightFaxCalls.java
       Copy the resulting class file to the dir where the other rightfax class files are
       ie) \development\RightFax\classes
       cd to \development\rightfax
       jar -cvf rightfax.jar classes\*.class
       you can now check this in as an 8.0 version of the jar file.

       The same steps can be done for the 9.0 version.


       Then at runtime, we can simply use either jar file without
       having to create two different versions of the PrintFaxProcessor.

       */

       //obFS.m_FaxDocument.setBody (body, fileExt, -1, -1, -1, "Arial", -1, -1); 
       RightFaxCalls rfc = new RightFaxCalls();

       rfc.setBody(obFS,body,fileExt,"Arial");


       obFS.m_FaxDocument.setBodyEncoding(RFDoc.ENCODING_BASE64);



       //Set the cover text
       // GL. 01/27/04 Need to url encode comments to prevent failure to load XML DOM
       // error because RF sends requests as an XML document
       comments=URLEncoder.encode(comments);
       obFS.m_FaxDocument.setCoverText (comments);


      //Add attachments, we are not using attachments
      //  obFS.addAttachment (fileName);

      //Send the document, and get back the results.
       Vector obRetList = null;



       //main.log(5,"Posted XML to RF:"+obFS.getXML());

       obRetList = obFS.submit();

       // get the result of the submission
       int nSize = obRetList.size();

       if (nSize<=0) throw new Exception("submitFax returned no results");
       if (nSize>1) main.log(0,"Warning: Submit fax returned more than one result: ("+nSize+"), using first result");

       RFStatus obStat = (RFStatus)(obRetList.get(0));

       int status=obStat.getStatusCode();

       if (status!=1) {
         // error occurred
         throw new Exception(status+" - "+obStat.getStatusMsg());
       }


       // return(obStat.getID()); // return the job id assigned by rightfax

       return(sID); // return the job id that we assigned above

    } // end submitFax


    //////////////////////////////////////////////////////////////////////////////////


    public String queryFaxStatus(String faxID,String rightFaxUserID) throws Exception {


       //main.log(0,"Info: Checking fax status for job: "+faxID);

       //Create a RFaxQuery object

       RFaxQuery obQ = new RFaxQuery();

       //obQ.setDebug(true);  // dumps low level xml set to server by rightfax api

       //Set the URL of the RightFAX server

       obQ.setTargetURL (rightFaxURL);


       //Criteria for one query.

       //obQ.addQuery (faxID);
       obQ.addQuery (faxID, null, null, "", rightFaxUserID, "");
       
       //Send the query, and get back the results
       Vector obQRetList = null;

       //main.log(5,"QUERY XML:"+obQ.getXML());

       //System.out.println("submitting query");

       obQRetList = obQ.submit();

       //System.out.println("processing response");
       
       /*********************  debug
       int nSize2 = obQRetList.size();
       for (int i = 0; i < nSize2; i++) {
         RFStatus obStat = (RFStatus)(obQRetList.get(i));
         System.out.println((i+1) + "-");
         System.out.println("\tID: " + obStat.getID());
         System.out.println("\tStatusCode: " + obStat.getStatusCode());
         System.out.println("\tStatusMessage: " + obStat.getStatusMsg());
       }
       **********************/


       // get the result of the submission
       int nSize = obQRetList.size();

       if (nSize<=0) throw new Exception("RFaxQuery returned no results");
       if (nSize>1) main.log(0,"Warning: Query fax returned more than one result: ("+nSize+"), using first result");

       /*
       if (nSize>1) {

          System.out.println("RFaxQuery returned more then one result: ("+nSize+")");
          for (int i = 0; i < nSize; i++) {
            RFStatus obStat = (RFStatus)(obQRetList.get(i));
            System.out.println("Result: "+(i+1));
            System.out.println("\tID: " + obStat.getID());
            System.out.println("\tStatusCode: " + obStat.getStatusCode());
            System.out.println("\tStatusMessage: " + obStat.getStatusMsg());
          }
       }
       */


       // always return the first one
       RFStatus obStat = (RFStatus)(obQRetList.get(0));

       return(obStat.getStatusCode()+","+obStat.getStatusMsg());

    } // end queryFaxStatus


    ///////////////////////////////////////////////////////////////////////


    public String deleteFax(String faxID) throws Exception {

      //Create a RFaxAction object

      RFaxAction obA = new RFaxAction();
      //Set the URL of the RightFAX server
      obA.setTargetURL (rightFaxURL);

      //Create a delete action
      if (!obA.addDeleteAction(faxID)) 
         throw new Exception("Add Delete Action Failed");

      //Send the action requests, and get back the results
      Vector obARetList = null;

      obARetList = obA.submit();

      //Output the results

      // get the result of the submission

      int nSize = obARetList.size();

      if (nSize<=0) throw new Exception("RFaxQuery returned no results");
      if (nSize>1) main.log(0,"Warning: Delete fax returned more than one result: ("+nSize+"), using first result");

      RFStatus obStat = (RFStatus)(obARetList.get(0));

      return(obStat.getStatusCode()+","+obStat.getStatusMsg());

    } // deleteFax


///////////////////////////////////////////////////////////////////////////////////////

  public byte[] readBinaryFile(String fileName) throws Exception {
	  
	  /**		
       * OWASP TOP 10 2010 - A4 Path Manipulation
	   * Changes to the below code to fix vulnerabilities
     * TTP 324955
	   **/
      //File fileIn=new File(fileName);
	  File fileIn=new File(OWASPSecurity.validationCheck(fileName, OWASPSecurity.DIRANDFILE));

      long len=fileIn.length();

      byte buf[] = new byte[(int)len];
      int numread=0;

      FileInputStream fileInputStream = new FileInputStream(fileIn);

      numread=fileInputStream.read(buf);

      fileInputStream.close();
      //System.gc();

      if (numread!=(int)len) throw new Exception("Error reading file, rc="+numread+" len="+len);

      return(buf);

  } // readBinaryFile



} // RightFaxWrapper
