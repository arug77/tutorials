
PATH=$PATH:$JAVA_HOME/bin;            export PATH

java -classpath .:../lib/common.jar:../lib/classes111.jar:../lib/mail.jar:../lib/activation.jar  com.cmsinc.origenate.printfax.PrintFaxProcessor  -p1 -cDEFAULT -i/opt/jrun4/servers/qs42/cfusion-ear/cfusion-war/config/origenate.ini -s2 -t1 -e/opt/origenate/qs42/printfaxqueue/eoj >>err.out >>err.out &  
