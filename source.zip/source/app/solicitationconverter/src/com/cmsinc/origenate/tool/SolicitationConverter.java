
package com.cmsinc.origenate.tool;

/*
Glenn Leyba 8/5/2015
SolicitationConverter:    TTP 337819

ONE TIME USAGE! SHOULD NOT BE RUN A SECOND TIME.

Used to decrypt old partial_ssn_txt_enc column (renamed to id_txt_enc) in config_solicitation_list using the original ssn_key
and re-encrypt it using the new id_key. Also create, and new hash value to be stored in id_txt_hash.


      Usage:
      SolicitationConverter INIFile 
      Where:
      INIFile: location of origenate.ini file
      java SolicitationConverter /opt/origenate.ini 

*/


import com.cmsinc.origenate.crypto.*;

import java.sql.*;
import java.util.*;
import java.io.*;

import com.cmsinc.origenate.crypto.*;
import com.cmsinc.origenate.util.Query;
import com.cmsinc.origenate.util.RecordData;
import com.cmsinc.origenate.util.LogMsg;
import com.cmsinc.origenate.util.IniFile;
import com.cmsinc.origenate.util.COLEncrypt;
import com.cmsinc.origenate.util.DBConnection;
import com.cmsinc.origenate.util.SQLSecurity;
import com.cmsinc.origenate.util.SQLUpdate;

import java.sql.DriverManager;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;


public class SolicitationConverter {

   String sIniFile="";
    String caseSensitive = "";
    String sURL = "";
    String sHost = "";
    String sSIDname = "";
    String sUser = "";
    String sPort = "";
    String sPass = "";
    String sTNSEntry = "";
    LogMsg log_obj = null;
    boolean bDecrypt = false;
    IniFile ini= new IniFile();
    int i_dbg_level=0;
    Connection con = null;
    String tableName = "config_solicitation_list";
    String columnName = "";
    String logFile="";
	String Evaluator_ID = "";
    String userName = "";
    String keyName = "";
    String numThreads="";
	String startRequestId = "0";
	String endRequestId = "0";
    int iNumThreads = 0;
	int successCnt=0;
	int skippedCnt=0;
	int errorCnt = 0;
	int totalFoundCnt = 0;
	static long start=0,end=0,elapsed=0;
    Vector processThreads=null;

    static java.lang.Object critsec = new java.lang.Object();
	
	private static HashMap<String,Integer> creditReqAuditIds = new HashMap<String,Integer>();

    public SolicitationConverter() {
        log_obj = new LogMsg();
        log_obj.setLogID("SolicitationConverter: ");
    }

    /////////////////////////////////////////////////////////////////////////////////


    public static void main (String args[]) {

        SolicitationConverter tc = new SolicitationConverter();
		start = new java.util.Date().getTime();
        try {
          tc.run(args);
        }
        catch (Exception e) {} // error already reported

        System.exit(0);
    }


    private void getDBConnection()  throws Exception {
	try {
	    DBConnection DBConnect = new DBConnection();
	    if (sTNSEntry.length() == 0) {
		con = DBConnect.getConnection(sHost, sSIDname, sUser, sPass, logFile, sPort, sTNSEntry);
	    } else {
		// use tns entry if available
		con = DBConnect.getConnectionTNS(sTNSEntry, sUser, sPass, logFile);
	    }
	} catch (Exception e) {
           log_obj.FmtAndLogMsg("Error connecting to database: " + e.toString());
           throw e;
	}
    }


    ////////////////////////////////////////////////////////////////////////////////

    void run(String args[]) throws Exception {

       try {

        String sConStr = "";

        GetArgs(args,log_obj);

	getDBConnection();

        log_obj.FmtAndLogMsg("SolicitationConverter running against config_solicitation_list table...");


        Crypto crypto =  CryptoFactory.getCrypto();
        String encryptionUser="origenate_"+sUser.toLowerCase();

              // initialize crypto object
		try {
			log_obj.FmtAndLogMsg("Initializing crypto...");
			crypto.encryptString(encryptionUser,"ssn","212715432");
			log_obj.FmtAndLogMsg("Initializing crypto...Done");
		} catch(Exception e){
                   log_obj.FmtAndLogMsg("Crypto initialization failed, error: "+e.toString());
                   throw e;
                }

          String sql="select evaluator_id,solicitation_id,nvl(id_txt_enc,'') id_txt_enc, nvl(id_txt_hash,'') id_txt_hash from config_solicitation_list";
          String evaluator_id = "",solicitation_id="",id_enc="",id_hash="",id_enc_decrypted="";

          Query query = new Query(con);
          query.executeQuery(sql);

          trigger_alter(con, "DISABLE");

          con.setAutoCommit(false);  // we are starting a transaction so that if any error occurs we back out all chgs, see the finally clause

          log_obj.FmtAndLogMsg("Processing rows...");
          while(query.next()) {  // query object is not part of transaction because its results are already in memory and the cursor has been closed
             // if a hash value exists then this row has already been converted
             totalFoundCnt++;
             evaluator_id=query.getColValue("evaluator_id","");
             solicitation_id=query.getColValue("solicitation_id","");
             id_enc=query.getColValue("id_txt_enc","");
             id_hash=query.getColValue("id_txt_hash","");
             if (id_enc.length()==0 || id_hash.length()>0) {
                skippedCnt++;   // id_enc length will be zero if they were not using encryption for id's, in this case the id_txt column will hold the unencrypted ssn
                // if enc has a value but no hash yet, then the enc was encrypted with the ssn key, so we need to re-encrypt with the id key
                continue; // no value to convert or already converted
             }

             id_enc_decrypted=crypto.decryptString(encryptionUser,"ssn",id_enc);   // the orig value was encrypted with the ssn key
             //we now need to re-encrypt it with the id_key
             // and also create a hash for it
             id_hash=crypto.generateMAC(encryptionUser,id_enc_decrypted);
             id_enc=crypto.encryptString(encryptionUser,"id",id_enc_decrypted);
             // now update the config table with the newly encrypted values from the id_key


             SQLUpdate sqlup1 = new SQLUpdate();
             sqlup1.SetPreparedUpdateStatement(con,
                             "update config_solicitation_list set id_txt_hash = ?, id_txt_enc = ? where evaluator_id = ? and solicitation_id = ?");
             sqlup1.setString(1, id_hash);
             sqlup1.setString(2, id_enc);
             sqlup1.setInt(3, evaluator_id);
             sqlup1.setInt(4, solicitation_id);
             sqlup1.RunPreparedUpdateStatement();


              successCnt++;
              log_obj.FmtAndLogMsg("Converted "+successCnt);
          }   // for each config row




        }
       catch (Exception e) {
          errorCnt++;
          log_obj.FmtAndLogMsg("Unexpected Error: "+e.toString());
       }
        finally {
           if (errorCnt==0) 
              con.commit();
           else
              con.rollback();
           con.setAutoCommit(true);
           try { trigger_alter(con, "ENABLE"); con.close();} catch (Exception e1) {}
        }

        end = new java.util.Date().getTime();
		elapsed = end - start;
                log_obj.FmtAndLogMsg("Conversion Finished For: "+tableName);
		log_obj.FmtAndLogMsg("Total Elapsed Time: "+((int)(elapsed/(60*60*1000F)) % 24)+ " Hr. "+((int)(elapsed/(60*1000F)) % 60)+" min. "+((int)(elapsed/1000F) % 60)+" sec.");
		log_obj.FmtAndLogMsg("Total Rows Found to convert: "+totalFoundCnt);
                 log_obj.FmtAndLogMsg("Total found: "+totalFoundCnt+", Converted "+successCnt+", Skipped: "+skippedCnt);


    } // run()


    //////////////////////////////////////////////////////////////////////////////////////


    private void ShowUsage() {
        log_obj.FmtAndLogMsg("Usage:");
        log_obj.FmtAndLogMsg("SolicitationConverter INIFile");
        log_obj.FmtAndLogMsg("Example: java SolicitationConverter  /opt/origenate.ini ");
        System.exit(1);
    }


    ////////////////////////////////////////////////////////////////////////////////




    private void GetArgs(String args[],LogMsg log_obj) throws Exception {
        int ix;

        if (args.length != 1)
           ShowUsage();  // will cause an exit of pgm


              sIniFile = args[0];
				 
              log_obj.FmtAndLogMsg("IniFile is '" + sIniFile + "'");
              try {
                  //
                  // Read host, user, sid and password from ini file
                  //
                  ini.readINIFile(sIniFile);

                  sHost = ini.getINIVar("database.host");

                  sUser = ini.getINIVar("database.user");

                  sPort = ini.getINIVar("database.port");

                  sPass = ini.getINIVar("database.password");
                //  sPass = COLEncrypt.sDecrypt(sPass);

                  sSIDname = ini.getINIVar("database.sid");

                  log_obj.FmtAndLogMsg("Database (SID name) is '" + sSIDname + "'");

                  sTNSEntry = ini.getINIVar("database.TNSEntry", "");
				  
				  caseSensitive = ini.getINIVar("general.pswrd_case_sensitive_check","");


              }
              catch (Exception e) {
                  log_obj.FmtAndLogMsg("Caught exception reading ini file '" + sIniFile + "':"+e.toString());
                  throw e;
              }


    } // getArgs


    //////////////////////////////////////////////////////////////////////////////////////

	private void trigger_alter(Connection con, String flag) throws Exception
	{
		Query query = new Query(con);
		int i = 0;
		Statement trgStmt = con.createStatement();
		String selectSql = "select table_owner, trigger_name from user_triggers";
		query.executeQuery(selectSql);
		 while(query.next()) {
            i = i+1;
            String table_owner = query.getColValue("table_owner");
			String trigger_name = query.getColValue("trigger_name");
			try{
				String triggerSql = "ALTER TRIGGER " + SQLSecurity.sanitize(table_owner) + "." + SQLSecurity.sanitize(trigger_name) + " "+ SQLSecurity.sanitizeFunction(flag)  ;
					/**
				 * OWASP TOP 10 2010 - A1 Critical SQL Injection
				 *  TTP 324955 Security Remediation Fortify Scan
				 */
				trgStmt.addBatch(SQLSecurity.basicSanitize(triggerSql));
			}
			catch (SQLException se){
				log_obj.FmtAndLogMsg("Class " + this.getClass() + "; " + se.toString());
			}
		}
		trgStmt.executeBatch();
		log_obj.FmtAndLogMsg("All triggers have been " + flag+ "D");
	}

	

} // SolicitationConverter