#!/bin/sh
#
# Process Soliciattion Converter
#


INIFILE=$ORCONFIG/origenate.ini
LOGFILE=$ORLOGS/solicitationconverter.log

nohup java -classpath .:../lib/evidl.jar:../lib/common.jar:../lib/crypto.jar:../lib/ojdbc6.jar:../lib/opencsv-3.8.jar com.cmsinc.origenate.tool.SolicitationConverter $INIFILE 
exit 0
