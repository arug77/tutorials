/*
 * HEAlerts.java
 *
 * Created on July 21, 2004
 *
 * @author Wei Ma
 *
 * @version
 *
 * Searches for HE apps that need TAF alerts
 *
 */

package com.cmsinc.origenate.tool;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.cmsinc.origenate.util.Alert;
import com.cmsinc.origenate.util.DBConnection;
import com.cmsinc.origenate.util.IniFile;
import com.cmsinc.origenate.util.LogMsg;
import com.cmsinc.origenate.util.SQLSecurity;
import com.cmsinc.origenate.util.SQLUtils;
import java.util.ArrayList;
import java.util.Arrays;

public class HEAlerts {
	private java.sql.Connection con;

	private String s_log_file = "";

	private String sHost = "";

	private String sSIDname = "";

	private String sUser = "";

	private String sPass = "";

	private String sPort = "";

	private String sTNSEntry = "";

	private String sIniFile = "";

	private String evaluatorList = "";

	private String date_str = "";

	private IniFile ini = new IniFile();

	private LogMsg log = new LogMsg();

	private Date check_dt;

	public HEAlerts() {
	}

	/** ************************************************************ */
	/* Main method to call HE Alerts process */
	/** ************************************************************ */
	public static void main(String args[]) throws Exception {
		HEAlerts ha = new HEAlerts();
		ha.getArgs(args);

		//insert taf alerts to table
		ha.createTafAlerts("credit_req_title_order",
						"credit_req_title_resp", 1);
		ha.createTafAlerts("credit_req_appraisal_order",
				"credit_req_appraisal_resp", 2);
		ha.createTafAlerts("credit_req_flood_order",
						"credit_req_flood_resp", 3);
		//early disclosure alerts
		ha.createEarlyDiscAlerts();

		ha.closeConnection();
	}

	private void getArgs(String args[]) {
		if (args.length > 0) {
			for (int ix = 0; ix < args.length; ix++) {
				if ((args[ix].charAt(0) != '-') && (args[ix].length() > 1))
					showUsage();
				switch (args[ix].charAt(1)) {
				case 'i': // ini file
					sIniFile = args[ix].substring(2);
					try {
						//
						// Read host, user, sid and password from ini file
						//
						ini.readINIFile(sIniFile);
						s_log_file = ini.getINIVar(
								"logs.he_alerts_log_file", "");
						if (s_log_file.length() > 0) {
							log.openLogFile(s_log_file);
						}
						sHost = ini.getINIVar("database.host", "");
						sPort = ini.getINIVar("database.port", "");
						sUser = ini.getINIVar("database.user", "");
						sPass = ini.getINIVar("database.password", "");
						sSIDname = ini.getINIVar("database.sid", "");
						sTNSEntry = ini.getINIVar("database.TNSEntry", "");

					} catch (Exception e) {
						log.FmtAndLogMsg("Caught exception reading ini file '"
								+ sIniFile + "':" + e.toString(), e);
					}
					break;
				case 'e': // evaluator list
					evaluatorList = args[ix].substring(2);
					break;
				case 'd': // date
					date_str = args[ix].substring(2);
					break;
				default:
					log.FmtAndLogMsg("Unknown parameter: " + args[ix]);
					showUsage();
					break;
				}
			}

			if ((sHost.length() == 0 || sUser.length() == 0
					|| sSIDname.length() == 0 || sPort.length() == 0) && sTNSEntry.length() == 0) {
				log
						.FmtAndLogMsg("Host,User,Pwd,SID,Port or TNS Entry not specified in INI file");
				showUsage();
			}

			if (date_str.length() > 0) {
				try {
					check_dt = Date.valueOf(date_str);
				} catch (Exception e) {
					log.FmtAndLogMsg(date_str + " is invalid date format", e);
					showUsage();
				}
			} else
				check_dt = null;

			try {
				DBConnection DBConnect = new DBConnection();

				log.FmtAndLogMsg(sTNSEntry);

				if (sTNSEntry.length() == 0) {
					con = DBConnect.getConnection(sHost, sSIDname, sUser, sPass, s_log_file, sPort,"");
				} else {
					// use tns entry if available
					con = DBConnect.getConnectionTNS(sTNSEntry, sUser,  sPass, s_log_file);
				}
			} catch (Exception e) {
				log.FmtAndLogMsg("Error connecting to database: "
						+ e.toString(), e);
			}

		} else
			showUsage();
	}

	private void showUsage() {
		System.out.println("");
		System.out
				.println("Usage: java HEAlerts -i<inifile> -e<evalID list> -d<date> ");
		System.out.println("---------------------");
		System.out.println("-i - required: INI file to use for configuration");
		System.out
				.println("-e - optional: evaluator ID list separated by commas (-e10,12,15, default is for all evaluators)");
		System.out
				.println("-d - optional: date TAF followup date should be checking against, in the format of yyyy-mm-dd, default is sysdate");
		System.out
				.println("example: java HEAlerts -ic:/development/origenatebin/origenate.ini -e23 -d2004-08-20");
		System.exit(1);
	}

	private void createTafAlerts(String order_tab_name, String resp_tab_name,
			int alert_type_id) {
		PreparedStatement ps = null, ps1 = null, ps2 = null, ps3 = null, ps4 = null;
		ResultSet rs = null, rs1 = null, rs2 = null, rs3 = null, rs4 = null;
		;
		String sql = "", sql2 = "", sql4 = "";
		String[] evaluators_in_list = null;
		try {
			

			con.setAutoCommit(false);
			try{
				sql = " select request_id, evaluator_id, vendor_id, audit_updated_user_id from "
					+ SQLSecurity.sanitize(order_tab_name) + " o ";
			} catch (SQLException se){
				log.FmtAndLogMsg("Class " + this.getClass() + "; " + se.toString());
				throw new SQLException("Class HEAlerts; Method createTafAlerts; Invalid table name in variable order_tab_name: " + order_tab_name );
			}
			if (check_dt != null)
				sql += " where o.followup_dt < ?";
			else
				sql += " where o.followup_dt < sysdate";
			//add placeholders to the IN clause
			if (!evaluatorList.isEmpty()){
				sql += " and " + SQLUtils.inClauseHelper(evaluatorList,"evaluator_id");//sql += " and evaluator_id in (" + evaluatorList + ")";
			}

			try {
				sql += " and o.request_id not in (select request_id from "
					+ SQLSecurity.sanitize(resp_tab_name)
					+ " r where r.request_id = o.request_id) and o.request_id not in (select request_id from credit_request_alerts a where a.request_id=o.request_id and a.status_txt='open' and a.alert_type_id =? )";
			} catch (SQLException se){
				log.FmtAndLogMsg("Class " + this.getClass() + "; " + se.toString());
				throw new SQLException("Class HEAlerts; Method createTafAlerts; Invalid table name in variable resp_tab_name: " + resp_tab_name );
			}
			/**
			 * OWASP TOP 10 2010 - A1 High SQL Injection
			 *  TTP 324955 Security Remediation Fortify Scan
			 */
			//Prepare statement to execute
			ps = con.prepareStatement(sql);
			//ps = con.prepareStatement(ESAPI.encoder().encodeForSQL( new OracleCodec(),sql.toString()));
			int placect = 1;
			if (check_dt != null) {
				ps.setDate(placect++, check_dt);
			}
			if (!evaluatorList.isEmpty()){
				ArrayList<String> evaluatorListArr = new ArrayList<String>(Arrays.asList(evaluatorList.split("\\s*,\\s*")));
				for(int i = 0; i< evaluatorListArr.size();i++){
					ps.setInt(placect++,Integer.parseInt(evaluatorListArr.get(i)));
				}
			}
			ps.setInt(placect++, alert_type_id);

			//Execute statement
			rs = ps.executeQuery();

			//Get values of taf alerts
			while (rs.next()) {

				int req_id = rs.getInt("request_id");
				int eval_id = rs.getInt("evaluator_id");
				int vendor_id = rs.getInt("vendor_id");
				String user_id = rs.getString("audit_updated_user_id");

				sql2 = "select vendor_name_txt from config_vendor where evaluator_id = ? and vendor_id = ?";
				ps2 = con.prepareStatement(sql2);
				ps2.setInt(1, eval_id);
				ps2.setInt(2, vendor_id);
				rs2 = ps2.executeQuery();

				String vendor_name = "";
				if (rs2.next())
					vendor_name = rs2.getString("vendor_name_txt");

				int new_seq_id = 1;
				try {
					new_seq_id = Alert.getNextSeq_Id(req_id, con);
				} catch (Exception e) {
					throw new SQLException(e.toString(), e);
				}
				if (new_seq_id == 0) {
					new_seq_id++;
					//the old code seemed to have a sequence starting with 1,
					// so I am keeping it that way
					//cc
				}

				Alert alert = new Alert(req_id, new_seq_id, alert_type_id,
						"open", new java.util.Date(), null, "Firm "
								+ vendor_name, user_id, con);
				try {
					alert.addAlert();
				} catch (Exception e) {
					throw new SQLException(e.toString(), e);
				}

				sql4 = "insert into credit_request_taf_alerts(request_id,seq_id,evaluator_id,vendor_id) values (?,?,?,?)";
				ps4 = con.prepareStatement(sql4);
				ps4.setInt(1, req_id);
				ps4.setInt(2, new_seq_id);
				ps4.setInt(3, eval_id);
				ps4.setInt(4, vendor_id);
				ps4.executeUpdate();

			}

			//Commit transaction
			con.commit();
			con.setAutoCommit(true);
		} catch (SQLException ex) {
			//Roll back changes
			try {
				con.rollback();
			} catch (SQLException e2) {
			}
			//Record error
			log.FmtAndLogMsg(ex.toString(), ex);
			//Stop process
			System.exit(0);
		} finally {// release resources
			try {
				if (rs != null)
					rs.close();
				if (rs1 != null)
					rs1.close();
				if (rs2 != null)
					rs2.close();
				if (rs3 != null)
					rs3.close();
				if (rs4 != null)
					rs4.close();
				if (ps != null)
					ps.close();
				if (ps1 != null)
					ps1.close();
				if (ps2 != null)
					ps2.close();
				if (ps3 != null)
					ps3.close();
				if (ps4 != null)
					ps4.close();
			} catch (SQLException e3) {
			}
		}

	}

	private void createEarlyDiscAlerts() {

		PreparedStatement ps = null;
		ResultSet rs = null;
		String[] evaluators_in_list = null;

		try {
			con.setAutoCommit(false);
			/*
			 * Select all apps that are not at the DONE task that have an Early
			 * Disclosure Activity status of Incomplete
			 */
			String sql = "select cr.request_id, evaluator_id from credit_request cr, credit_request_activity cra where cr.request_id=cra.request_id and cr.task_id !='DONE' and cra.activity_id=38 and cra.activity_status_id=1";
			//add placeholders to the IN clause
			if (!evaluatorList.isEmpty()){
				sql += " and cr.evaluator_id in (";
				evaluators_in_list = evaluatorList.split(" *, *");
				StringBuilder sb = new StringBuilder();
				for(int c=0; c < evaluators_in_list.length;c++){
					sb.append("?");
					if(c+1 < evaluators_in_list.length )
						sb.append(" , ");
					else
						sb.append(" )");
				}
				sql += sb.toString();
				sql += ")";
			}
			ps = con.prepareStatement(sql);
			int placect = 1;
			if(evaluators_in_list != null){
				for(String token:evaluators_in_list){
					ps.setInt(placect++, Integer.valueOf(token));
				}
			}

			/**
			 * OWASP TOP 10 2010 - A1 High SQL Injection
			 *  Modfifed the code to fix SQL Injection vulnerabilities
			 */
			rs = ps.executeQuery();
			//rs = st.executeQuery(ESAPI.encoder().encodeForSQL( new OracleCodec(),sql.toString()));

			while (rs.next()) {
				int req_id = rs.getInt("request_id");
				/*
				 * check for expiration first, if not expiration, check for
				 * warning
				 */
				if (!checkEarlyDiscAlerts(req_id, "EARLY_DISC_EXP_DATE", 5))
					checkEarlyDiscAlerts(req_id, "EARLY_DISC_WARN_DATE", 4);
			}

			//Commit transaction
			con.commit();
			con.setAutoCommit(true);
		} catch (SQLException ex) {
			//Roll back changes
			try {
				con.rollback();
			} catch (SQLException e2) {
			}
			//Record error
			log.FmtAndLogMsg(ex.toString(), ex);
			try{ if(rs != null) rs.close(); }catch(Exception e1){e1.printStackTrace();}
		    try{ if(ps != null) ps.close(); }catch(Exception e1){e1.printStackTrace();}
			//Stop process
			System.exit(0);
		} finally {// release resources
		    try{ if(rs != null) rs.close(); }catch(Exception e1){e1.printStackTrace();}
		    try{ if(ps != null) ps.close(); }catch(Exception e1){e1.printStackTrace();}
		}

	}

	private boolean checkEarlyDiscAlerts(int req_id, String date_field,
			int alert_type) {

		PreparedStatement ps = null, ps1 = null, ps2 = null, ps3 = null;
		Statement st = null;
		ResultSet rs = null, rs1 = null, rs2 = null, rs3 = null;
		String sql = "", sql2 = "", sql4 = "";
		String doc_desc_list = "Doc not printed:";
		int new_seq_id = 1, r = 0;

		try {

			sql = " select cr.request_id, cr.evaluator_id from credit_request cr where cr.request_id=?";
			sql += " and cr.request_id not in (select request_id from credit_request_alerts a where a.request_id=cr.request_id and a.status_txt='open' and a.alert_type_id =? )";
			if (check_dt != null)
				sql += " and cr." + date_field + "< ?";
			else
				sql += " and cr." + date_field + "< sysdate";

			//Prepare statement to execute
			ps = con.prepareStatement(sql);
            ps.setInt(1, req_id);
			if (check_dt != null) {
				ps.setInt(2, alert_type);
				ps.setDate(3, check_dt);
			} else
				ps.setInt(2, alert_type);

			rs = ps.executeQuery();

			// insert a row to alert table
			while (rs.next()) {

				new_seq_id = 1;
				try {
					new_seq_id = Alert.getNextSeq_Id(req_id, con);
				} catch (Exception e) {
					throw new SQLException(e.toString(), e);
				}
				if (new_seq_id == 0) {
					new_seq_id++;
					//the old code seemed to have a sequence starting with 1,
					// so I am keeping it that way
					//cc
				}

				sql2 = "select cd.document_id, cd.description_txt from credit_req_doc_history crdh, config_documents cd where crdh.document_id = cd.document_id and crdh.evaluator_id = cd.evaluator_id and crdh.request_id = ? and crdh.status_id not in ('SUCCESS','WAIVED') and cd.EARLY_DISCLOSURE_FLG =1";
				ps2 = con.prepareStatement(sql2);
				ps2.setInt(1, req_id);
				rs2 = ps2.executeQuery();
                StringBuilder temp_builder = new StringBuilder(doc_desc_list);

				while (rs2.next()) {
                    temp_builder.append(rs2.getString("description_txt"));
                    temp_builder.append(", ");
				}
                doc_desc_list = temp_builder.toString();
				if (doc_desc_list.length() > 128)
					doc_desc_list = doc_desc_list.substring(0, 127);

				Alert alert = new Alert(req_id, new_seq_id, alert_type, "open",
						new java.util.Date(), null, doc_desc_list, con);
				try {
					alert.addAlert();
				} catch (Exception e) {
					throw new SQLException(e.toString(), e);
				}

				if (alert_type == 5 && r == 1) {
				    try{if(rs2 !=null) rs2.close();} catch(Exception ex) {ex.printStackTrace();}
		            try{if(ps2 !=null) ps2.close();} catch(Exception ex) {ex.printStackTrace();}
					// close warning alert if expiration
					sql4 = "update credit_request_alerts set status_txt='closed' where alert_type_id= 4 and status_txt='open' and request_id=?";
					ps2 = con.prepareStatement(sql4);
    				ps2.setInt(1, req_id);
                    ps2.execute();
					/*
					sql4 = "update credit_request_alerts set status_txt='closed' where alert_type_id= 4 and status_txt='open' and request_id="
							+ req_id;
					st = con.createStatement();
					st.executeUpdate(sql4);
					*/
				}
			}
		} catch (SQLException ex) {
			//Roll back changes
			try {
				con.rollback();
			} catch (SQLException e2) {
			}
			//Record error
			log.FmtAndLogMsg(ex.toString(), ex);
			//Stop process
			System.exit(0);
		} finally {// release resources
			try {
				if (rs != null)
					rs.close();
				if (rs1 != null)
					rs1.close();
				if (rs2 != null)
					rs2.close();
				if (rs3 != null)
					rs3.close();
				if (ps != null)
					ps.close();
				if (ps1 != null)
					ps1.close();
				if (ps2 != null)
					ps2.close();
				if (ps3 != null)
					ps3.close();
				if (st != null)
					st.close();
			} catch (SQLException e3) {
			}
		}

		return (r == 1);
	}

	private void closeConnection() {
		try {
			if (con != null)
				con.close();
		} catch (SQLException e) {
		}
		con = null;
	}
}