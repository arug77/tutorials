#!/bin/sh
#
# Process Expired offer
#


INIFILE=/opt/jrun4/servers/qs42/cfusion-ear/cfusion-war/config/origenate.ini
LOGFILE=/opt/origenate/qs42/healerts.log

nohup java -classpath .:../lib/common.jar:../lib/ojdbc6.jar com.cmsinc.origenate.tool.HEAlerts $INIFILE $1 >> $LOGFILE &
exit 0
