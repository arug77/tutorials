/**
 * ApplicationDelete.java
 * Date: 01/16/2012
 * Author: Mike Swain
 *
 * This program gets the Application Delete Query for the Evaluator ID command line argument
 * and runs it to get the applications to delete completely from the system. The Application
 * Delete Query is expected to return at least the REQUEST_ID and CLIENT_APP_ID and have only
 * EVALUATOR_ID as a wildcard field in the WHERE clause. Any apps that are returned by the
 * query are deleted.
 */

package com.cmsinc.origenate.applicationdelete;

import java.sql.*;
import java.io.*;

import com.cmsinc.origenate.doc.GenJob;
import com.cmsinc.origenate.util.COLEncrypt;
import com.cmsinc.origenate.util.IniFile;
import com.cmsinc.origenate.util.LogMsg;
import com.cmsinc.origenate.util.OWASPSecurity;
import com.cmsinc.origenate.util.Query;
import com.cmsinc.origenate.util.SQLSecurity;
import com.cmsinc.origenate.util.SQLUpdate;
import java.util.ArrayList;

import org.apache.commons.lang.StringUtils;

public class ApplicationDelete {
	static String VERSION = "1.0";

	String evaluatorID = "";
	LogMsg log_obj = new LogMsg();;
	String delQuery = "";
	String queryID = "";
	String sHost = "";
	String sSIDname = "";
	String sUser = "";
	String sEvalUser = "";
	String sPass = "";
	String sEvalPass = "";
	String sPort = "";
	String sTNSEntry = "";
	String sIniFile = "";
	int i_dbg_level = 0;
	IniFile ini = new IniFile();
	String logFile = "";
	ArrayList<Character> table_chars;
	public static void main(String[] args) {
		ApplicationDelete adt = new ApplicationDelete();
		try {
			adt.run(args);
		}
		catch (Exception e) {
		}

		System.exit(0);
	}

	public ApplicationDelete() {
	}
	private void create_char_table(){
		table_chars = new ArrayList<Character>();
		for(int i = (int) 'a'; i <= (int) 'z'; i++)
			table_chars.add(Character.valueOf((char) i));
		for(int i = (int) 'A'; i <= (int) 'Z'; i++)
			table_chars.add(Character.valueOf((char) i));
		table_chars.add(Character.valueOf('@'));
		table_chars.add(Character.valueOf('#'));
		table_chars.add(Character.valueOf('$'));
		table_chars.add(Character.valueOf('_'));
	}

	private int deleteApps(Connection con, Connection con1) throws Exception {
		Query query = null;
		Query evalQuery = null, tmpevalQuery = null, delevalQuery = null, fileevalQuery = null, origTableQuery = null;
		PreparedStatement stmt1 = null;
		ResultSet rset1 = null;
		ArrayList tableList = new ArrayList();
		/*ArrayList viewList = new ArrayList();
		ArrayList appseqnoList = new ArrayList();*/

		// This is a list of all of the tables that aren't returned
		// by the origTableSQL query, but still need to be deleted
		ArrayList<String> origTableList = new ArrayList<String>();
		origTableList.add("VG_BOOKING_TRANS");
		origTableList.add("ROUTING_QUEUE");
		origTableList.add("POSTING_QUEUE_EXCEPTION");
		// Add more if necessary

		// Get the appseqno
		String seqnoSQL = "select distinct(APPSEQNO) from REQUESTOR where REQUEST_ID = ?";
		String tableSQL = "select distinct(TABLE_NAME) from USER_TAB_COLUMNS where COLUMN_NAME = 'APPSEQNO' and TABLE_NAME in (SELECT OBJECT_NAME from USER_OBJECTS where OBJECT_TYPE = 'TABLE')order by TABLE_NAME ASC";
		String viewSQL = "select distinct(VIEW_NAME) from USER_VIEWS";
		String fileSQL = "select distinct(PATH) from EVAPP_FILES WHERE APPSEQNO = ?"; //TTP 324955 Security Remediation Fortify Scan
		String origTableSQL = "select distinct level, table_name from (	select p.table_name, p.constraint_name pk, r.r_constraint_name fk from user_constraints p, user_constraints r where p.table_name = r.table_name and p.constraint_type in ('P','U','R') and r.constraint_type ='R' and r.constraint_name not in ('CR_CRDE_LATEST_FINAL_REF_ID_FK','CR_CRDE_LATEST_REF_ID_FK','PORTAL_COMMENT_FK') )  start with table_name = 'CREDIT_REQUEST' connect by prior pk = fk order by level desc, decode(table_name,'EVALUATE_CACHE',2,'EVALUATE_SHARE',3,'CREDIT_REQUEST_AUDIT',1,0) asc";
		String table_name = "";

		//get a list of eValute tables to delete data off of.

		try {
			tmpevalQuery = new Query(con1);
			tmpevalQuery.prepareStatement(tableSQL);
			tmpevalQuery.executePreparedQuery();
		}
		catch (Exception e) {
			log(0, "ApplicationDelete: Exception getting eValuate Table names : " + e.toString(), e);
			//throw new Exception("ApplicationDelete: Exception getting eValaute Table names : " + e.toString());
		}


		// Get list of Origenate tables
		try {
			origTableQuery = new Query(con);
			origTableQuery.prepareStatement(origTableSQL);
			origTableQuery.executePreparedQuery();
		}
		catch (Exception e) {
			log(0, "ApplicationDelete: Exception getting origenate Table names : " + e.toString(), e);
			throw new Exception("ApplicationDelete: Exception getting origenate Table names : " + e.toString(), e);
		}

		while(tmpevalQuery.next()) {
			try {
				table_name = tmpevalQuery.getColValue("TABLE_NAME","");
				tableList.add(table_name);
			}
			catch (Exception e) {
				log(0, "ApplicationDelete: Exception getting eValuate Table names : " + e.toString(), e);
				throw new Exception("ApplicationDelete: Exception getting eValaute Table names : " + e.toString(), e);
			}
		}



		// Get the App Deletion Query
		String sql =
			"select cdq.query_id, cdq.query_txt from config_doc_queries cdq, evaluator e " +
			"where e.evaluator_id = cdq.evaluator_id and e.app_delete_query_id = cdq.query_id " +
			"and cdq.when_to_use_flg = 6 " + // Check that it is an app delete query
			"and e.evaluator_id = ? ";

		try {
			query = new Query(con);
			query.prepareStatement(sql);
			query.setInt(1, Integer.parseInt(evaluatorID));
			query.executePreparedQuery();
		}
		catch(Exception e) {
			log(0, "ApplicationDelete: Exception getting Application Delete Query: " + e.toString(), e);
			throw new Exception("ApplicationDelete: Exception getting Application Delete Query: " + e.toString(), e);
		}

		if(query.next()) {
			delQuery = query.getColValue("query_txt","");
			queryID = query.getColValue("query_id","");
		}

		// If nothing configured
		if(delQuery.length() == 0) {
			log(0, "ApplicationDelete: No application delete query configured for Evaluator ID " + evaluatorID);
			return 0;
		}

		// Build and execute the App Deletion selection query
		GenJob genJob = new GenJob(con, log_obj);
		query = buildAndExecuteQuery(genJob, con, delQuery, queryID, evaluatorID);
		// Now we have list of request_id's to delete

		String request_id = "", app_id = "", appseqno = "", filepath = "" ;

		boolean success = true;

		// Count of apps successfully deleted
		int count = 0;

		// Will be running one app at a time, so don't want to commit to any
		// changes until all tables are deleted for an app.
		con.setAutoCommit(false);

		while(query.next()) {
			success = true;

			try {
				request_id = query.getColValue("request_id","");
				app_id = query.getColValue("client_app_id","");
			}
			catch (Exception e) {
				// This exception should be caught the first time through this loop
				log(0, "ApplicationDelete: Application Delete Query must have request_id and client_app_id columns: " + e.toString(), e);
				throw new Exception("ApplicationDelete: Application Delete Query must have request_id and client_app_id columns: " + e.toString(), e);
			}
			//check for related appseqnos to delete evaluate data
			if(request_id.length() > 0 && !request_id.isEmpty()){
				try {
					evalQuery = new Query(con);
					evalQuery.prepareStatement(seqnoSQL);
					evalQuery.setInt(1, Integer.parseInt(request_id));
					evalQuery.executePreparedQuery();
				}
				catch (Exception e) {

					log(0, "ApplicationDelete: Appseqno Query must have request_id : " + e.toString(), e);

				}

				while(evalQuery.next()) {
					try {
						appseqno = evalQuery.getColValue("appseqno","");
						System.out.println("Appseqno : "+appseqno);
						//appseqnoList.add(new String(appseqno));
					}
					catch (Exception e) {

					log(0, "ApplicationDelete: Exception getting Appseqno : " + e.toString(), e);

					}

					if(appseqno.length() > 0 && !appseqno.isEmpty()){
					//delete all eValuate files if they exist before deleting appseqnos
						try {
							fileevalQuery = new Query(con1);
							//TTP 324955 Security Remediation Fortify Scan
							fileevalQuery.prepareStatement(fileSQL);
							fileevalQuery.setInt(1, appseqno);
							fileevalQuery.executePreparedQuery();
						}
						catch (Exception e) {

							log(0, "ApplicationDelete: error querying file paths : " + e.toString(), e);

						}
						while(fileevalQuery.next()) {
							try {
								filepath = fileevalQuery.getColValue("path","");
								System.out.println("path : "+filepath);

							}
							catch (Exception e) {

								log(0, "ApplicationDelete: Exception getting file path : " + e.toString(), e);

							}

							try{

								/**
						         * OWASP TOP 10 2010 - A4 Path Manipulation
							     * Changes to the below code to fix vulnerabilities
							     * TTP 324955 Security Remediation Fortify Scan
							     **/
						        //File f1 = new File(filepath);
								File f1 = new File(OWASPSecurity.validationCheck(filepath, OWASPSecurity.DIRANDFILE));

							       	boolean exists = f1.exists();
							       	if(exists){
							       		boolean status = f1.delete();
							       		if(!status)
											log(0, "ApplicationDelete: Error deleting file : " + filepath);
										else
											log(0, "File: " + filepath + " successfully deleted");
									}
									else
										log(0, "ApplicationDelete: File: " + filepath + " doesn't exist");

							    }
							    catch (Exception e)
							    {
							        log(0, "ApplicationDelete: Error deleting file : " + filepath + e.toString(), e);
							        e.printStackTrace();
    							}
						}

					for(int i = 0; i < tableList.size(); i++)
					{
					
						table_name = (String) tableList.get(i);
						String delSQL = "";
						try{
							delSQL = "delete from "+ SQLSecurity.sanitize(table_name) +" where appseqno = ?";
						} catch (SQLException se){
							log(0, "ApplicationDelete: Invalid characters in table name. Skipping delete");
						}
						try {

							/**
                             * TTP 324955 Security Remediation Fortify Scan
                             */
							 stmt1 = con1.prepareStatement(delSQL);
							 stmt1.setInt(1, Integer.valueOf(appseqno));

							 rset1 = stmt1.executeQuery();
							 rset1.close();
						     stmt1.close();
							 //System.out.println("One row deleted");
						}
						catch (Exception e) {
							log(0, "ApplicationDelete: Exception deleting eValuate table : " + e.toString(), e);
							System.out.println(" Erroring SQL : "+delSQL);
							//throw new Exception("ApplicationDelete: Exception deleting eValaute table : " + e.toString()); //don't throw, continue to next app.
						}
						finally {
						   try{ if(rset1 != null) rset1.close(); }catch(Exception e1){e1.printStackTrace();}
						   try{ if(stmt1 != null) stmt1.close(); }catch(Exception e1){e1.printStackTrace();}
						}
					}
				}
				con1.commit();
			}
		}


//end evaluate delete tables - continue with origenate delete
			success = true;
			String origDeleteQuery = "";
			String origTableName = "";
			PreparedStatement stmt = null;
			try {
				stmt = con.prepareStatement("update credit_request set " +
						"portal_comment_id = null, latest_final_dec_ref_id = null, " +
						"latest_dec_ref_id = null where request_id = ?");
				stmt.setInt(1, Integer.valueOf(request_id));
				stmt.execute();
				stmt.close();

				origTableQuery.reset();
				while(origTableQuery.next()) {
					origTableName = origTableQuery.getColValue("table_name");

					
					try{
						origDeleteQuery = buildDeleteStatement(SQLSecurity.sanitize(origTableName));
					} catch (SQLException se){
						log(0, "ApplicationDelete: Invalid characters in origTableName. Skipping delete");
					}

					stmt = con.prepareStatement(origDeleteQuery);

					stmt.setInt(1, Integer.valueOf(request_id));
					stmt.execute();
					stmt.close();
					
				}
				// Loop over extra tables
				for(String s : origTableList) {
					origTableName = s;

					origDeleteQuery = buildDeleteStatement(SQLSecurity.sanitize(origTableName));

					try {
						stmt = con.prepareStatement(origDeleteQuery);
						stmt.setInt(1, Integer.valueOf(request_id));
						stmt.execute();
						stmt.close();
					} catch (Exception e) {
						// If the data doesn't get deleted from these tables,
						// we don't want to throw an exception. Just a
						// warning is okay since there may be other constraints.
						log(0, "ApplicationDelete: Exception on query: " + origDeleteQuery.replace("?",request_id) + " - Continuing processing");
						try{ if(stmt != null) stmt.close(); }catch(Exception e1){e1.printStackTrace();}
					}
				}
			}
			catch(Exception e) {
				log(0, "ApplicationDelete: Exception deleting Application " + app_id + ", Request ID " + request_id + ": " + e.toString(), e);
				log(0, "ApplicationDelete: Exception on query: " + origDeleteQuery.replace("?",request_id));
				// Don't want to stop the whole process, so just skip this individual app
				success = false;
				try{ if(stmt != null) stmt.close(); }catch(Exception e1){e1.printStackTrace();}
			}
			finally {
			    try{ if(stmt != null) stmt.close(); }catch(Exception e1){e1.printStackTrace();}
			}
			if(success) {
				con.commit();

				// record event to EVENT table, log, and increment count of apps deleted
				Query tmpQuery = new Query(con);
				try {
					tmpQuery.executeQuery("select event_id_seq.nextval as event_id from dual");
					tmpQuery.next();
					String eventID=tmpQuery.getColValue("event_id","0");
					//TTP 324955 Security Remediation Fortify Scan
					SQLUpdate sqlup = new SQLUpdate();
					sqlup.SetPreparedUpdateStatement(con,
						"insert into event (event_id,event_type_id,event_dt,evaluator_id,user_id,additional_desc_txt) values (?,4,sysdate,?,'SYSTEM',?)");
					sqlup.setInt(1, eventID);
					sqlup.setInt(2, evaluatorID);
					sqlup.setString(3, "Application "+app_id+" Deleted using Application Delete Query");
					sqlup.RunPreparedUpdateStatement();
				}
				catch (Exception e) {
					log(0, "ApplicationDelete: can not insert event for delete of Request ID " + request_id +": "+e.toString(), e);
				}

				log(0, "ApplicationDelete: Application " + app_id + ", Request ID " + request_id + " Deleted");

				count++;
			}
			else {
				con.rollback();
			}
		}

		return count;
	}

	private String buildDeleteStatement(String origTableName) {
		String origDeleteQuery = "delete from " + origTableName;
		if(origTableName.equals("CREDIT_REQ_DECISION_REASONS") ||
			origTableName.equals("CREDIT_REQ_DECISION_STIP") ||
			origTableName.equals("CREDIT_REQ_DECISIONS_PTIDTI") ||
			origTableName.equals("CREDIT_REQ_DECISIONS_MESSAGE") ||
			origTableName.equals("CREDIT_REQ_FIELD_REASONS") ||
			origTableName.equals("ALTERNATIVE_PRICING") ) {
			origDeleteQuery += " where decision_ref_id in (select decision_ref_id from " +
				"credit_req_decisions_evaluator where request_id = ?)";
		}
		else if(origTableName.equals("PRINTFAX_QUEUE_ATTACHMENTS") ||
				origTableName.equals("PRINTFAX_QUEUE_RECIPIENTS") ||
				origTableName.equals("PRINTFAX_QUEUE_VALUES") ) {
			origDeleteQuery += " where job_id in (select job_id from printfax_queue " +
				"where request_id = ?)";
		}
		else if(origTableName.equals("EVENT")) {
			origDeleteQuery += " where client_app_id in (select client_app_id " +
				"from credit_request where request_id = ?)";
		}
		else {
			origDeleteQuery += " where request_id = ?";
		}
		return origDeleteQuery;
	}

	// Based off of code from GenJob. It doesn't seem like this method would be used much in there in the future,
	// so I'm just putting it by itself here to be used by this program only. Takes evaluator_id rather than request_id.
	private Query buildAndExecuteQuery(GenJob genJob, Connection con, String sql, String query_id, String evaluator_id) throws Exception {
		Query query = new Query(con);
		Query querySQLParms = new Query(con);

		if(evaluator_id == null || evaluator_id.trim().equals("")) {
			return null;
		}

		querySQLParms.prepareStatement("select parm_name_txt,source_id,source_txt from config_doc_query_parms where query_id = ? and evaluator_id = ? ");
		querySQLParms.setInt(1, Integer.parseInt(query_id));
		querySQLParms.setInt(2, Integer.parseInt(evaluator_id));
		querySQLParms.executePreparedQuery();

		int source_id;
		String parm, sourceValue;
		ArrayList<Integer> parmCt = new ArrayList<Integer>();
		while(querySQLParms.next()) {
			source_id = Integer.parseInt(querySQLParms.getColValue("source_id"));

			switch (source_id) {
			// Only want to support evaluator_id
			case 4: {
				sourceValue = querySQLParms.getColValue("source_txt", "notavail");
				if(!sourceValue.equalsIgnoreCase("evaluator_id")) {
					log(0, "ApplicationDelete: Source " + sourceValue + " not supported in Application Delete Query");
					throw new Exception("ApplicationDelete: Source " + sourceValue + " not supported in Application Delete Query");
				}
				parm = querySQLParms.getColValue("parm_name_txt");
				if(sql.indexOf(parm) < 0) {
					log(0, "ApplicationDelete: Parameter " + parm + " not found in Application Delete Query");
					throw new Exception("ApplicationDelete: Parameter " + parm + " not found in Application Delete Query");
				}
				sql = genJob.replace(sql, parm, " ? ", true, parmCt);
			}
			break;
			default:
				log(0, "ApplicationDelete: Source ID " + source_id + " not supported in Application Delete Query");
				throw new Exception("ApplicationDelete: Source ID " + source_id + " not supported in Application Delete Query");
			} // end switch
		}

		//TTP 324955 Security Remediation Fortify Scan
		query.prepareStatement(SQLSecurity.basicSanitize(sql));
		for(int c = 0; c < parmCt.get(0); c++){
			query.setInt(c + 1, evaluator_id);
		}
		query.executePreparedQuery();

		return query;
	}

	public void run(String[] args) throws Exception {
		Connection con = null;
		Connection evalcon = null;

		log(0, "AppDelete initializing...");

		GetArgs(args, log_obj);

		String sConStr = "jdbc:oracle:thin:@";
		if (sTNSEntry.length() == 0) {
			sConStr = sConStr + sHost + ":" + sPort + ":" + sSIDname;
		}
		else {
			sConStr = sConStr + sTNSEntry;
			log(0, "Using TNS Entry");
		}

		try {
			// Load Oracle driver
			DriverManager.registerDriver(new oracle.jdbc.OracleDriver());

			log(0, "Connecting to database: " + sConStr);

			// Connect to the Oracle database
			con = DriverManager.getConnection(sConStr, sUser, sPass);
			evalcon = DriverManager.getConnection(sConStr, sEvalUser, sEvalPass);
		}
		catch (Exception e) {
			log(0, "Error connecting to database: " + e.toString(), e);
			throw e;
		}

		int count = 0;
		try {
			count = deleteApps(con, evalcon);
		}
		catch (Exception e) {
			log(0, "Error in AppDelete: " + e.toString(), e);
			//throw e;
		}

		try {
			con.close();
			evalcon.close();
		}
		catch (Exception e1){}

		log(0, "ApplicationDelete: " + count + " Applications Deleted");
		log(0, "ApplicationDelete exiting...");
	}

	private void GetArgs(String args[], LogMsg log_obj) throws Exception {
		if(args.length > 0) {
			for(int i = 0; i < args.length; i++) {
				if((args[i].charAt(0) != '-') && (args[i].length() > 1)) {
					ShowUsage();
				}

				switch(args[i].charAt(1)) {

				case 'i':
					sIniFile = args[i].substring(2);
					log(0, "IniFile is '" + sIniFile + "'");
					try {
						// Read host, user, sid and password from ini file
						ini.readINIFile(sIniFile);

						logFile = ini.getINIVar("logs.application_delete_log_file", "");
						if(logFile.length() > 0) {
							log_obj.openLogFile(logFile);
						}

						log(0, "ApplicationDelete version " + VERSION + " initializing...");

						sHost = ini.getINIVar("database.host", "");
						log(0, "Host is '" + sHost + "'");

						sPort = ini.getINIVar("database.port", "");
						log(0, "Port is '" + sPort + "'");

						sUser = ini.getINIVar("database.user", "");
						log(0, "User is '" + sUser + "'");

						sPass = ini.getINIVar("database.password", "");
						sPass = COLEncrypt.sDecrypt(sPass);

						sEvalUser = ini.getINIVar("database.eval_user", "");

						sEvalPass = ini.getINIVar("database.eval_password", "");
						sEvalPass = COLEncrypt.sDecrypt(sEvalPass);

						sSIDname = ini.getINIVar("database.sid", "");
						log(0, "Database (SID name) is '" + sSIDname + "'");

						sTNSEntry = ini.getINIVar("database.TNSEntry", "");
						log(0, "TNS Entry is '" + sTNSEntry + "'");
					}
					catch(Exception e){
						log(0, "Caught exception reading ini file '" + sIniFile + "': " + e.toString(), e);
						throw e;
					}
					
					if(StringUtils.isEmpty(sPass) || StringUtils.isEmpty(sEvalPass)){
					    log(0, "Database password is empty after decryption");
					    throw new Exception("Database password is empty after decryption");
					}
					
					break;

				// Not much logging. We'll leave this flag out
				/*case 'd': //turn debug on
					i_dbg_level = 5;
					log(0, "debugging turned on");
					break;*/

				case 'e': //evaluator id
					evaluatorID = args[i].substring(2);
					log(0, "Evaluator ID: " + evaluatorID);
					break;

				default:
					log(0, "Unknown parameter: " + args[i]);
					ShowUsage();
					break;
				} // end case
			} // end for loop

			//edits
			if ((sHost.length() == 0) || (sUser.length() == 0)
					|| (sSIDname.length() == 0) || (sPort.length() == 0)) {
				log(0, "Host,User,Pwd,SID or Port not specified in INI file");
				ShowUsage();
			}
			if (evaluatorID.length() == 0) {
				log(0, "-e parm is required");
				ShowUsage();
			}
		} // end if
		else {
			ShowUsage();
		}
	}

	private void ShowUsage() {
		System.out.println();
		System.out.println("Usage: java ApplicationDelete -i<inifile> -e<evaluator id>");
		System.out.println("---------------------");
		System.out.println("-i - required: INI file to use for configuration");
		System.out.println("-e - required: evaluator id");
		System.exit(1);
	}

	private void log(int level, String msg) {
		log_obj.FmtAndLogMsg(msg, i_dbg_level, level);
	}

	private void log(int level, String msg, Throwable throwable) {
		log_obj.FmtAndLogMsg(msg, throwable, i_dbg_level, level);
	}
}