/* Filename: IsBusinessDay.java
 * Version: 
 * Creation Date: October 5, 2005
 * Author: Gautam Anand
 * Copyright (c) 2002. All rights reserved
 * Description: Refer Clientele #134000
 * This program would make a call to evaluate using EvaluateFacade Object and find if
 * the day is a business day or not. The program is using exit codes in order to
 * return the results with the following assumptions:
 * exit code -1 = command-line args are missing or incorrect date format
 * exit code  0 = date is not a holiday
 * exit code  1 = data is a holiday
 * exit code  2 = error with evaluate return values
 */

package com.cmsinc.origenate.isbusinessday;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Vector;

import com.cmsinc.origenate.util.DBConnection;
import com.cmsinc.origenate.util.EvaluateApp;
import com.cmsinc.origenate.util.EvaluateFacade;
import com.cmsinc.origenate.util.IniFile;
import com.cmsinc.origenate.util.LogMsg;

public class IsBusinessDay {

	private static String s_iniFile; // ini filename
	private static IniFile ini = new IniFile();
	private static LogMsg log = new LogMsg(); // log
	private static Connection con; // db settings
	private static String s_eval_env=""; 
	private static String s_eval_host = "";
	private static String s_eval_ver = "";
	private static String s_eval_port = "";
	private static String s_eval_facade_log = "";
	private static String evaluate_client_id;
	private static String s_eff_dt="";
	private static String date;
	private static String str_Date;
	private static String s_retvalue;
	private static Vector cmdargs = new Vector(10,10);
	private static String request_id = "IsBusinessDay";
	public static void main(String[] args) {

		String s_log_file = "";
		if (args.length > 0) {
			for (int i = 0; i < args.length; ++i) {
				if ((args[i].charAt(0) != '-') && (args[i].length() > 1)) {
					showUsageAndExit();
				}
				cmdargs.add(Character.valueOf(args[i].charAt(1)));				
				switch (args[i].charAt(1)) {
				case 'i':
					s_iniFile = args[i].substring(2);
					try {
						ini.readINIFile(s_iniFile);
						s_log_file = ini.getINIVar("logs.IsBusinessDay_log_file",
								"");
						if (s_log_file.length() > 0) {
							log.openLogFile(s_log_file);
						}
					} catch (Exception e) {
						log.FmtAndLogMsg("Caught exception reading ini file '"
								+ s_iniFile + "':" + e.toString(), e);
					}
					log.FmtAndLogMsg("\r");
					log.FmtAndLogMsg("Starting IsBusinessDay Tool");
					log.FmtAndLogMsg("\r");
					log.FmtAndLogMsg("iniFile name: " + s_iniFile);
					break;
				case 'e':
					evaluate_client_id = args[i].substring(2);
					log.FmtAndLogMsg("Evaluate Client ID: " + evaluate_client_id);
					break;
				case 'd':
					date = args[i].substring(2);
					log.FmtAndLogMsg("Date to be checked for holiday/business: " + date );
					break;
				default:
					log.FmtAndLogMsg("Unknown parameter: " + args[i]);
					showUsageAndExit();
					break;
				}
			}
		}
		
		 /* Check if the required command line args are present*/
		try {
			log.FmtAndLogMsg("********Calling checkCmdLineArgs Method********");
			checkCmdLineArgs();
		} catch (Exception e) {
			log.FmtAndLogMsg("Error in checkCmdLineArgs method of : "
					+ e.toString(), e);
		}
		log.FmtAndLogMsg("********checkCmdLineArgs Method Completed********");

		
		/*checking the date format*/
		try {
			log.FmtAndLogMsg("********Calling checkDateStr Method********");
			checkDateStr(date);
			str_Date = date;
		} catch (Exception e) {
			log.FmtAndLogMsg("Error in checkDateStr method of : "
					+ e.toString(), e);
		}
		log.FmtAndLogMsg("********checkDateStr Method Completed********");

		
		/* Creating a DB Connection */

		try {
			log.FmtAndLogMsg("********Calling getDBConnection Method********");
			getDBConnection(s_log_file);
		} catch (Exception e) {
			log.FmtAndLogMsg("Error in getDBConnection method of : "
					+ e.toString(), e);
		}
		log.FmtAndLogMsg("********getDBConnection Method Completed********");


		/* Retreiving evaluate env vars */

		try {
			log.FmtAndLogMsg("********Calling getEvalEnvVars Method********");
			getEvalEnvVars();
		} catch (Exception e) {
			log.FmtAndLogMsg("Error in getEvalEnvVars method of : "
					+ e.toString(), e);
		}
		log.FmtAndLogMsg("********getEvalEnvVars Method Completed********");

		
		IsBusinessDay day = new IsBusinessDay();
		try {
			day.getHolidayCalendar();
		} catch (Exception e) {

			e.printStackTrace();
		}
	}

	/*Method to inform that expected values are missing on the command line*/

	public static void showUsageAndExit() {
		System.out
				.println("Usage: java com.cmsinc.origenate.isbusinessday.IsBusinessDay");
		System.out
				.println("-i<ini file>");
		System.out
				.println("------------------------------------------------------------------------------");
		System.out.println("Parameter	Data Type	Required/Optional			Description");
		System.out.println("  -i 		 String			Required		ini file name including the location");
		System.out.println("  -e 		 String			Required		Evaluator Client ID");
		System.out.println("  -d		 String			Required		Date to be checked for holiday");
		System.exit(-1);
	}

	/*Report an error in a method*/

	public static void recordError(String methodName, Exception err)
			throws Exception {
		try {
			log.FmtAndLogMsg("Error occured in " + methodName + " method of : "
					+ err.toString(), err);
			throw new Exception("Error occured in " + methodName
					+ " method of : " + err.toString(), err);
		} catch (Exception e) {
			log
					.FmtAndLogMsg("Error in reportError method of : "
							+ e.toString(), e);
		}

	}

	/*checks if the command line args are present*/
	
	public static void checkCmdLineArgs() {
		if(cmdargs.contains(Character.valueOf('i')) && cmdargs.contains(Character.valueOf('e'))
				&& cmdargs.contains(Character.valueOf('d'))) {
			log.FmtAndLogMsg("Required Command Line Parameters Present");
		}
		else {
			log.FmtAndLogMsg("Required Command Line Parameters Missing");
			log.FmtAndLogMsg("Calling showUsageAndExit() method to exit");
			showUsageAndExit();
		}
	}

	/*Method to get evaluate environment parameters*/
	
	public static void getEvalEnvVars() throws Exception{

		// get evaluate environment vars from ini file
	    s_eval_env = ini.getINIVar("evaluate.environment");
	    log.FmtAndLogMsg("evalenv : " + s_eval_env);
	    s_eval_host = ini.getINIVar("evaluate.ini_host");
	    log.FmtAndLogMsg("evalhost : " + s_eval_host);
	    s_eval_ver = ini.getINIVar("evaluate.version");
	    log.FmtAndLogMsg("evalver : " + s_eval_ver);
	    s_eval_port = ini.getINIVar("evaluate.ini_port");
	    log.FmtAndLogMsg("evalport : " + s_eval_port);
	    s_eval_facade_log = ini.getINIVar("logs.evaluate_facade_log_file");
	    log.FmtAndLogMsg("evalfacadelog : " + s_eval_facade_log);
	    if (s_eval_port.equalsIgnoreCase("")) {
	      throw new Exception("Error in getEvalEnvVars method no port is defined ");
	    }
		
	}

	
	/*get DB connection*/

	public static void getDBConnection(String s_log_file) throws Exception {

		try {
			// Get ini file values for DB connection

			String s_dbhost = ini.getINIVar("database.host").trim();
			log.FmtAndLogMsg("dbHost : " + s_dbhost);

			String s_dbport = ini.getINIVar("database.port").trim();
			log.FmtAndLogMsg("dbPort : " + s_dbport);

			String s_dbsid = ini.getINIVar("database.sid").trim();
			log.FmtAndLogMsg("dbSID : " + s_dbsid);

			String s_dbuser = ini.getINIVar("database.user").trim();
			log.FmtAndLogMsg("dbUser : " + s_dbuser);

			String s_dbpassword = ini.getINIVar("database.password").trim();

			String sTNSEntry = ini.getINIVar("database.TNSEntry", "");
			log.FmtAndLogMsg("TNS Entry : " + sTNSEntry);
						
			DBConnection DBConnect = new DBConnection();

			if (sTNSEntry.length() == 0) {
				// Get DB connection
				con = DBConnect.getConnection(s_dbhost, s_dbsid, s_dbuser,
						s_dbpassword, s_log_file, s_dbport,"");
			} else {
				// use tns entry if available
				con = DBConnect.getConnectionTNS(sTNSEntry, s_dbuser,  s_dbpassword, s_log_file);
			}
		} catch (Exception e) {
			recordError("getDBConnection", e);
		}
	} // end getDBConnection method
	
	

	/*Initialize evaluate facade calls*/

	 public String getHolidayCalendar()  throws Exception  {
	   
	   PreparedStatement ps = null;
	   ResultSet rs = null;
	   EvaluateFacade ev = null;
	   String str_enddt = "";
	   String[] chgTables = new String[0];
	   String s_result = "";   
	   log.FmtAndLogMsg("Inside getHolidayCalendar Method");
	   try {
	      
        //initialize evaluate facade
		ev = new EvaluateFacade(s_eval_facade_log,request_id,s_iniFile);
	
         if (s_eval_port.equalsIgnoreCase("")) {
             throw new Exception("Error in getHolidayCalendar method; no port is defined ");
           }

	     int i_eval_port = (Integer.valueOf(s_eval_port)).intValue();
	     log.FmtAndLogMsg("int evalport : " + i_eval_port);
	     
	     // initialize evaluate call
	     log.FmtAndLogMsg("intializing evaluate call");
	     try {
		     ev.Initialize(s_eval_env, s_eval_ver, s_eval_host,i_eval_port);
		     log.FmtAndLogMsg("initialization complete");
	     }
	     catch(Exception e) {
	    	 log.FmtAndLogMsg("Error in Evaluate Initialise", e);
	    	 System.exit(2);
	     }
	     

	     //Get effective date
         s_eff_dt = getEffectiveDt();
         
         //create eval app
	     EvaluateApp ap = new EvaluateApp();
	     ap.EvalAppNo = Integer.valueOf(0);
	     ap.AppSeqNo = Integer.valueOf(0);
	
	     //Call evaluate to get elapsed time

         log.FmtAndLogMsg("Evaluator Client Id: " + evaluate_client_id);
         log.FmtAndLogMsg("Effective Date: " + s_eff_dt);
    	 log.FmtAndLogMsg("Date Entered: " + str_Date);
    	 log.FmtAndLogMsg("End Date: " + str_enddt);
    	 
	     try {
	    	 s_result = ev.Evaluate("Expr!IsBusinessDay",evaluate_client_id,s_eff_dt,"ORIG_BUSHOUR_TABLE_SET",chgTables,str_Date,str_enddt,ap);	    	 

	    	 if(s_result.equals("0"))
		    	 s_retvalue = "false";
		     else if(s_result.equals("1"))
		    	 s_retvalue = "true";
		     else
		    	 log.FmtAndLogMsg("Error in Evaluate.");
	     }
	     catch(Exception e) {
	    	 log.FmtAndLogMsg("Error in Evaluate", e);
	    	 recordError("getHolidayCalendar",e);
	    	 System.exit(2);
	     }

	     log.FmtAndLogMsg("Is " + str_Date + " a holiday ?" +  s_retvalue);
	     
	     if(s_retvalue.equalsIgnoreCase("true")) {
	    	 log.FmtAndLogMsg("Returned True");
	    	 System.out.println("returned true");
	    	 System.exit(1);
	     }
	     else if(s_retvalue.equalsIgnoreCase("false")) {
	    	 log.FmtAndLogMsg("Returned False");
	    	 System.out.println("returned false");
	    	 System.exit(0);
	     }
	     
	   } catch (Exception ex) {
	     if (ev != null) ev = null;
	  
		 try{ if(rs != null) rs.close(); }catch(Exception e1){e1.printStackTrace();}
		 try{ if(ps != null) ps.close(); }catch(Exception e1){e1.printStackTrace();}
	     recordError("getHolidayCalendar",ex);
	   } finally {
	     try {
	       //Need to close log file
	       //ev.closeLogFile();
		   try{ if(ev != null) ev.closeLogFile(); }catch(Exception e1){e1.printStackTrace();}
	       if (ev != null) ev = null;
		   try{ if(rs != null) rs.close(); }catch(Exception e1){e1.printStackTrace();}
		   try{ if(ps != null) ps.close(); }catch(Exception e1){e1.printStackTrace();}
		   try{ if(con != null) con.close(); }catch(Exception e1){e1.printStackTrace();}
	     } catch (Exception e) {
	       recordError("getHolidayCalendar",e);
	     }
	   }
	   return  s_retvalue;
	 }

	/*Method to get effective date.*/

	public static String getEffectiveDt() {
		Calendar cal = new GregorianCalendar(); // create a Calendar object
		String year = ""; // year
		String month = ""; // month
		String day = ""; // day
		String date = "";
		try {

			// get date to append to the filename.
			year = (Integer.toString(cal.get(Calendar.YEAR))).trim(); // 2002
			month = (Integer.toString((cal.get(Calendar.MONTH)) + 1)).trim(); // 0=Jan,
			// 1=Feb,
			// ...
			if (month.length() < 2) {
				month = "0".concat(month);
			}
			day = (Integer.toString(cal.get(Calendar.DAY_OF_MONTH))).trim(); // 1...
			if (day.length() < 2) {
				day = "0".concat(day);
			}
			System.out.println("Current Month: " + month);
			System.out.println("Current Year: " + year);
			System.out.println("Current Day: " + day);
			date = month + "/" + day + "/" + year;
		} catch (Exception e) {
			try {
				recordError("getEffectiveDt", e);
			} catch (Exception ex) {
				log.FmtAndLogMsg("Error in getEffectiveDt method of : "
						+ ex.toString(), ex);
			}
		} // end catch
		return date;

		} 
 
	 /*Formatting Date entered on command-line*/

	 public static void checkDateStr(String s_date) {
		 try { 
             String theDate = s_date; 
             Date dd;
             SimpleDateFormat df = new SimpleDateFormat("mm/dd/yyyy");
             dd = df.parse(theDate);         
             System.out.println("DateGiven:  "+ df.format(dd)); 
        }catch(ParseException pe) { 
             System.out.println("Date Format incorrect; Format - mm/dd/yyyy");
    	     log.FmtAndLogMsg("Date Format incorrect; Format - mm/dd/yyyy", pe);
	         System.exit(-1);
      } //catch
   } //checkDataStr method
} // main class