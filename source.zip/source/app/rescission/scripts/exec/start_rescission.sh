#!/bin/sh
#
# Process Rescission period
#


INIFILE=/opt/jrun4/servers/qs50/cfusion-ear/cfusion-war/config/origenate.ini
LOGFILE=/opt/origenate/qs50/rescission.log

nohup java -classpath .:../lib/common.jar:../lib/classes111.jar com.cmsinc.origenate.tool.Rescission $INIFILE $1 >> $LOGFILE &
exit 0
