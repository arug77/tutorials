/****************************************************************************************************************
   Company: First American CMSI
    Product: Origenate
    Author: Akash Pandya
    Copyright (c) 2002. All rights reserved

    Description: Check for rescission period ended
    Requirements: This process takes 1 or 2 argument. The first one must be ini file location, and if passed, the second argument must be evaluator id. 
			If the arguments are more then 2, then only first 2 will be used.

*******************************************************************************************************************/
package com.cmsinc.origenate.tool;


import com.cmsinc.origenate.util.DBConnection;
import com.cmsinc.origenate.workflow.ApplicationIDs;
import com.cmsinc.origenate.workflow.ApplicationStatusManager;
import com.cmsinc.origenate.util.IniFile;
import com.cmsinc.origenate.event.CommentEvents;
import com.cmsinc.origenate.event.JournalEvents;


import java.util.*;
import com.cmsinc.origenate.util.LogMsg;
import java.sql.ResultSet;
import java.sql.PreparedStatement;
import java.sql.Timestamp;
import java.text.*;


public class Rescission {

  //Set debugger
  private static boolean b_debugger = true;
  private static CommentEvents commEvent;
  private static JournalEvents journalEvent;


  private static java.sql.Connection con;
  private static LogMsg log = new LogMsg();
  private static  String s_log_file = "";
  private static String iniFileNm = "c:\\development\\origenatebin\\origenate.ini";
  
  private static Integer evaluatorId = null;


  /***************************************************************/
   /*              Main method to call Rescission process      */
   /***************************************************************/
   
  public static void main(String argv[]) throws Exception {
	if (argv.length > 0) {
		iniFileNm = argv[0].trim();
			if(argv.length > 1){
				  try{
					evaluatorId = Integer.valueOf(argv[1]);
				  }catch (Exception e){
		    		// can not convert evaluator id into number, use all evaluators
					evaluatorId = null;
					log.FmtAndLogMsg("*** Rescission process:  Can not convert evaluator_id into number, using all evaluators. ****");
				  }
			}
	}		
    updateRescission();
  }


  /***************************************************************/
  /* Create Rescission object and get DB connection         */
  /***************************************************************/
  private static void getDBConnection(String s_iniFile) throws Exception {

    try {
      //Get ini file values for DB connection
      IniFile ini = new IniFile();
      ini.readINIFile(s_iniFile);
      String s_host = ini.getINIVar("database.host");
      String s_port = ini.getINIVar("database.port");
      String s_sid = ini.getINIVar("database.sid");
      String s_user = ini.getINIVar("database.user");
      String s_password = ini.getINIVar("database.password");
      String sTNSEntry = ini.getINIVar("database.TNSEntry");
      s_log_file = ini.getINIVar("logs.rescission_log_file");

      DBConnection DBConnect = new DBConnection();
      log.openLogFile(s_log_file);
      //Get DB connection
      if (sTNSEntry == null) {
    	  con = DBConnect.getConnection(s_host, s_sid, s_user, s_password, s_log_file, s_port,"");
      } else {
    	  // use tns entry if available
    	  con = DBConnect.getConnectionTNS(sTNSEntry, s_user,  s_password, s_log_file);
      }
    } catch (Exception e) {
      recordError(e, "getDBConnection");
    }
  }

  /***************************************************************/
  /*                    Reocord error                            */
  /***************************************************************/
  private static void recordError(Exception err, String classStr) throws Exception  {
    try {
      if (b_debugger)
        err.printStackTrace();
      log.FmtAndLogMsg("Error in " + classStr + " method of : " + err.toString());
      throw new Exception("Error in " + classStr + " method of : " + err.toString());
    } catch (Exception e) {
      log.FmtAndLogMsg("Error in recordError method of : " + e.toString());
    }
  }



    /***************************************************************/
    /*    Check  Rescission  period                                */
    /***************************************************************/
    private static void updateRescission() throws Exception {

      PreparedStatement ps = null;
      ResultSet rs = null;
      String sql = "";
      ApplicationStatusManager appManager = null;
      int evalID, appStateId, actStateId;
      long requestID;

      //Get current date and time
      Timestamp sysDate = new java.sql.Timestamp(System.currentTimeMillis());

       try {

        //Get db connection; if it is closed
        getDBConnection(iniFileNm);

       //Create comment obj
       commEvent = new CommentEvents(con,s_log_file);

       //Create comment obj
        journalEvent = new JournalEvents(con,s_log_file);


        log.FmtAndLogMsg("*** Rescission process started successfully. ****");

        //Set auto commit false
        con.setAutoCommit(false);
		sql = "select request_id, EVALUATOR_ID, ACTUAL_RESCISSION_END_DT  from CREDIT_REQ_CONTRACT WHERE ";
		if(evaluatorId != null) {
			sql += "EVALUATOR_ID = ? AND ACTUAL_RESCISSION_END_DT IS NOT NULL AND to_char(ACTUAL_RESCISSION_END_DT, 'YYYY/MM/DD') < to_char(sysdate, 'YYYY/MM/DD')";
			ps = con.prepareStatement(sql);	
			ps.setInt(1, evaluatorId);
		}else{
			sql += "ACTUAL_RESCISSION_END_DT IS NOT NULL AND to_char(ACTUAL_RESCISSION_END_DT, 'YYYY/MM/DD') < to_char(sysdate, 'YYYY/MM/DD')";
			ps = con.prepareStatement(sql);	
		}

        //Execute statement
        rs = ps.executeQuery();


        log.FmtAndLogMsg("Fetching CRC records...");

        //Get values of rescission end date

        while (rs.next()) {

            requestID = rs.getLong("request_id");
            evalID = rs.getInt("EVALUATOR_ID");
            Long l_requestID = Long.valueOf(requestID);

              //Create Appstatus object
              appManager = new ApplicationStatusManager(con,log);

              //Get application status
              appStateId = appManager.getApplicationStatus(requestID,evalID);
              //Get activity status
              actStateId = appManager.getActivityStatus(requestID,ApplicationIDs.tsk_grp_contractadmin,ApplicationIDs.act_resc);

              //Check is this app status is app_penrescbk and  rescission activity id is incomplete
              if (appStateId ==  ApplicationIDs.app_penrescbk &&  actStateId == ApplicationIDs.act_status_incomplete) {

                //Update application status and activity status
                appManager.setApplicationStatus(requestID,evalID,ApplicationIDs.app_penbk);
                appManager.setActivityStatus(requestID,ApplicationIDs.tsk_grp_contractadmin,ApplicationIDs.act_resc,ApplicationIDs.act_status_complete,ApplicationIDs.sysuser,-1);

                //Create string comment
                String strComment = "Rescission period ended";

                //Log rescission end request
                log.FmtAndLogMsg(" Request id : " + l_requestID.toString() + ", " + strComment );

                //Add comment entry
                addComment(requestID, sysDate, ApplicationIDs.sysuser, strComment);

                //Add journal entry
                addJournal(requestID, ApplicationIDs.sysuser);

              }
                      
        } //Main While

        // close stmt
		 try{ if(rs != null) rs.close(); }catch(Exception e1){e1.printStackTrace();}
		 try{ if(ps != null) ps.close(); }catch(Exception e1){e1.printStackTrace();}

        //Commit transaction
        con.commit();
        log.FmtAndLogMsg("*** Rescission process completed successfully. ****");

       } catch (Exception ex) {
        //Roll back changes
        con.rollback();
        con.close();
        //Record error
        recordError(ex, "updateRescission");
        log.FmtAndLogMsg("*** All rescission updates are rollback from last run. Please contact Administrator. ***");
		try{ if(rs != null) rs.close(); }catch(Exception e1){e1.printStackTrace();}
		try{ if(ps != null) ps.close(); }catch(Exception e1){e1.printStackTrace();}
        try{ if(con != null) con.close(); }catch(Exception e1){e1.printStackTrace();}
        //Stop process
        System.exit(0);
      } finally {//Close connection and release resources
          try{ if(rs != null) rs.close(); }catch(Exception e1){e1.printStackTrace();}
		  try{ if(ps != null) ps.close(); }catch(Exception e1){e1.printStackTrace();}
          try{ if(con != null) con.close(); }catch(Exception e1){e1.printStackTrace();}
          if (commEvent != null) commEvent = null;
          if (journalEvent != null) journalEvent = null;
          if (appManager != null) appManager = null;
      }
    }




   /***************************************************************/
  /*               Add comments                                  */
  /***************************************************************/
    private static void addComment(long request_id, Timestamp sysDate, String user_id, String rescDesc) throws Exception  {
      try {
        //Add comment
        commEvent.addComment(Long.valueOf(request_id).intValue(),66,"Rescission end",rescDesc,user_id, null, "");
      } catch (Exception ex) {
        try {
          con.rollback();
          recordError(ex, "addComment");
          log.FmtAndLogMsg("*** All rescission updates are rollback from last run. Please contact Administrator. ***");
          con.close();
        } finally {
          try {
            if (commEvent != null) commEvent = null;
            if (journalEvent != null) journalEvent = null;
            if (con != null) con.close();
            System.exit(0);
          } catch (Exception e) {
            recordError(e, "addComment");
            log.FmtAndLogMsg("*** All rescission updates are rollback from last run. Please contact Administrator. ***");
          }
        }
      }
    }


  /***************************************************************/
  /*               Add journals                                 */
  /***************************************************************/
    private static void addJournal(long request_id,  String user_id) throws Exception  {
      try {
        //Add journal
        journalEvent.addJournal(Long.valueOf(request_id).intValue(),73,"Rescission end",user_id);
      } catch (Exception ex) {
        try {
          con.rollback();
          recordError(ex, "addJournal");
          log.FmtAndLogMsg("*** All rescission updates are rollback from last run. Please contact Administrator. ***");
          con.close();
        } finally {
          try {
            if (commEvent != null) commEvent = null;
            if (journalEvent != null) journalEvent = null;
            if (con != null) con.close();
            System.exit(0);
          } catch (Exception e) {
            recordError(e, "addJournal");
            log.FmtAndLogMsg("*** All rescission updates are rollback from last run. Please contact Administrator. ***");
          }
        }
      }
    }


  /***************************************************************/
  /*               Date formatter                                */
 /***************************************************************/
  public static String getDateTimeStr(Timestamp stamp, String formatString) {

      if (stamp==null) return "";
      String dateStr = null;
      Locale curLocale = Locale.getDefault();
      java.util.Date date = (java.util.Date)stamp;

      if(curLocale.equals(Locale.US))
      {
         SimpleDateFormat formatter = new SimpleDateFormat(formatString, curLocale);
         dateStr = formatter.format(date);
      }else
      {
          DateFormat formatter = DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.MEDIUM, curLocale);
          dateStr = formatter.format(date);
      }

      return dateStr;
    }

}