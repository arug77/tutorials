#!/bin/sh
#
# sample call to early disclosure
#

echo "java -classpath .:../lib/common.jar:../lib/ojdbc6.jar com.cmsinc.origenate.tool.earlydisclosure add_arguments_here"
java -classpath .:../lib/common.jar:../lib/ojdbc6.jar com.cmsinc.origenate.tool.earlyDisclosure add_arguments_here

