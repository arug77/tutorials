/*
 * earlyDisclosure.java
 *
 * Created 11/09/10 by B. Snyder
 *
 * early disclosure data export
 9.	Create a new scheduled process called Early Disclosure Data Export.  Within the script, support an optional Redirection parameter. When the process is run:
a.	Identify all applications initiated in the last 90 days.
b.	Execute the Booking When-to-Use Query for all CONFIG_MPE records that have an Output Type of Early Disclosure Export. 
For each application for which the query is satisfied, create a LaserPro data file. 
Creation of the LaserPro file is assumed to be similar to the Export Document Data function currently supported. 
The XML will be produced, the configured stylesheet applied, and a file created for each application. 
For ASP lenders, each file will be FTP'd to the secured FTP server. (It is assumed the same XML transactions available to the current LaserPro extract will be available to the Disclosure extract.)
c.	Record the Disclosure Date = System date and time of  export
d.	Record the Disclosed APR = EVAPP_INTERFACE.DISCLOSED_APR set by the eValuate configuration
e.	Record the Disclosed Interest Rate = EVAPP_INTERFACE.DISCLOSED_INTRATE set by the eValuate configuration
f.	In the new fees table, capture and store all fees with an amount not equal to null and HUD Line value not equal to null. 
Capture fees from the CREDIT_REQ_CONTRA_FINANCED_FEES table if records exist, else capture the fees from the CREDIT_REQUEST_FINANCED_FEES table 
The CREDIT_REQ_CONTRA_FINANCED_FEES table maintains the fees displayed on the Closing Preparation screen, whereas the CREDIT_REQUEST_FINANCED_FEES table maintains the fees displayed on the Finance and Decision screens.
NOTE: Each time the Early Disclosure export is run, delete the fee-related records with previously disclosed values and create new records with the new disclosed values. This will ensure there are no records carried over from the previous export.
g.	Create a Journal entry to record the creation of the Early Disclosure data file.
h.	Clear the EVAPP_INTERFACE.DISCLOSURE.FLG value for each application for which a data file was created.
i.	If the optional Redirection parameter is set to true, initiate a Task/Team/User (T/T/U) call to the eValuate configuration if the application is not in use. Include an indicator so that the eValuate configuration is aware that the T/T/U call is being initiated by the Export Disclosure Data process.
Note: Applications in use when this process is run will still export the data but a T/T/U call will not be initiated.  After business hours, the Reset Application process can be run prior to the Disclosure Data Export process. This will ensure applications are not in use when the export process is run. 
j.Add a command line product parameter that will allow the scheduled process to only review applications based on the product parameter. For example, if the parameter is set to DHEQ, then only look at DHEQ applications initiated in the last 90 days. If multiple products are required, the scheduled process can be run multiple times. If the parameter is left blank, run for all products. The introduction of the product parameter was intended to optimize process performance.
 */

package com.cmsinc.origenate.tool;

import java.sql.*;
import java.io.*;
import java.net.*;

import com.cmsinc.origenate.cp.DisclosureDataExportManager;
import com.cmsinc.origenate.util.DBConnection;
import com.cmsinc.origenate.util.IniFile;
import com.cmsinc.origenate.util.Query;
import com.cmsinc.origenate.util.PostRequest;

public class earlyDisclosure {

	public static void main (String args[]) {
		
		String sHost = "";
		String sSIDname = "";
		String sUser = "";
		String sPass = "";
		String sPort = "";
		String sTNSEntry = "";
		String sIniFile = "";
		int evaluator_id = -1;
		boolean b_logging = false;
		int log_level = 0;
		int product_id = -1;
		int redirect = 0;
		int days = 90;
		int i;
		IniFile ini = new IniFile();
		
		Connection conn = null;

/////////////////////////////////////// get args /////////////////////////////////////////
		if(args.length >= 1) {
			for(i=0;i<args.length;++i) {
				if ((args[i].charAt(0) != '-') && (args[i].length() > 1)){
                    showUsage();
                }
				switch (args[i].charAt(1)) {
					case 'i':
						sIniFile = args[i].substring(2);
						try {
							ini.readINIFile(sIniFile);

							sHost = ini.getINIVar("database.host", "");
							sPort = ini.getINIVar("database.port", "");
							sUser = ini.getINIVar("database.user", "");
							sPass = ini.getINIVar("database.password", "");
							sSIDname = ini.getINIVar("database.sid", "");
							sTNSEntry = ini.getINIVar("database.TNSEntry", "");
							try {
								log_level = Integer.parseInt(ini.getINIVar("debug.debug_level","0"));
							}
							catch (Exception ex) {
								System.out.println("Caught exception reading ini file '"+ sIniFile + "' value for debug.genx_debug_lvl:" + ex.toString());
								ex.printStackTrace();
								log_level = 0;
							}

						} catch (Exception e) {
							System.out.println("Caught exception reading ini file '"+ sIniFile + "':" + e.toString());
							e.printStackTrace();
						}
						break;
					case 'l':
						try {
	                    	if(Integer.parseInt(args[i].substring(2)) == 1)
	                    		b_logging = true;
						}
						catch (Exception e) {
							System.out.println("Exception: Could not determine logging value; defaulting to 0.  see usage");
						}
	                    break;	
					case 'e':
						try {
							// get evaluator
	                    	evaluator_id = Integer.parseInt(args[i].substring(2));
						}
						catch (Exception e) {
							System.out.println("Exception: Could not determine integer value of evaluator.  see usage");
						}
	                    break;
					case 'p':
	                    product_id = Integer.parseInt(args[i].substring(2));
	                    break;
					case 'r':
	                    redirect = Integer.parseInt(args[i].substring(2));
	                    break;
					case 'd':
	                    days = Integer.parseInt(args[i].substring(2));
	                    break;	
					default:
                    	System.out.println("Unknown argument.  see usage");
	                    showUsage();
    	                break;
				}
			}

			try {
				// make db connection
				DBConnection DBConnect = new DBConnection();

				if (sTNSEntry.length() == 0) {
					conn = DBConnect.getConnection(sHost, sSIDname, sUser, sPass, null, sPort,"");
				} else {
					// use tns entry if available
					conn = DBConnect.getConnectionTNS(sTNSEntry, sUser,  sPass, null);
				}
			}
			catch(Exception e) {
	        	System.out.println("Exception: could not create a connection with db information in supplied ini file.  see usage");
	        	e.printStackTrace();
				showUsage();
	      	}

			if (evaluator_id == -1) {
				System.out.println("Evaluator not supplied.  see usage");
				showUsage();
			}
			
			if (!b_logging)
				log_level = 0;
		}
		else {
			showUsage();
		}
//////////////////////////////////// end get args ////////////////////////////////////////

		Query lockQuery = new Query(conn);
		
		// use selection query to identify all apps and call send disclosure
		Query selectionQuery = new Query(conn);

		String selectStatement = "SELECT cr.request_id, cr.evaluator_id, cr.product_id " +
								 "FROM credit_request cr " +
								 "WHERE cr.initiation_dt > (sysdate - ?) " +
								 "AND cr.evaluator_id = ? ";
								 
		if (product_id != -1) {
			selectStatement += "AND product_id = ? ";
		}
			
		if (b_logging) {
			System.out.println("Selection query = "+selectStatement);
		}	
								 
		try {
			selectionQuery.prepareStatement(selectStatement);
			selectionQuery.setInt(1, days);
			selectionQuery.setInt(2, evaluator_id);
			if (product_id != -1) {
				selectionQuery.setInt(3, product_id);
			}	
			selectionQuery.executePreparedQuery();
		} catch (Exception e1) {
			String error = "Error running selection query: " + e1.toString();
			e1.printStackTrace();
			System.exit(1);
		}

		DisclosureDataExportManager ddem = null;
		
		try {
			// this object will do the actual sending of the laserpro transactions and the logging of pertinent info
			ddem = new DisclosureDataExportManager(conn);
		} catch (Exception e2) {
			String error = "Error constructing DisclosureDataExportManager: " + e2.toString();
			e2.printStackTrace();
			System.exit(1);
		}
		
		String ccURL = ini.getINIVar("urls.eval_app_complete_url","");
		String response = "";
		if(ccURL.length() <= 0){
			System.out.println("urls.eval_app_complete_url was not found in the ini file; cannot make TTU evaluate calls!");					
        }
		
		Integer request_id = null;
		
		// loop through all eligible apps and export disclosure info
		while(selectionQuery.next()) {
			try {
				request_id = Integer.valueOf(selectionQuery.getColValue("request_id"));
			} catch (Exception e) {
               	System.out.println("Error, could not read request_id from selection query: "+e.toString());
               	e.printStackTrace();
				System.exit(1);
            }	
			
			if (b_logging) {
				System.out.println("exporting request_id="+request_id);
			}	
			
			try {
				ddem.sendDisclosureDataExportIfEnabled(request_id, Integer.valueOf(selectionQuery.getColValue("evaluator_id")), Integer.valueOf(selectionQuery.getColValue("product_id")), "SYSTEM");
			} catch (Exception e) {
               	System.out.println("Error calling sendDisclosureDataExportIfEnabled: "+e.toString());
               	e.printStackTrace();
            }	
			
			if (redirect == 1) {
				try {
					lockQuery.prepareStatement("SELECT 1 FROM concurrency_control WHERE request_id = ?");
					lockQuery.setInt(1, request_id);
					lockQuery.executePreparedQuery();
					
					// only call ttu if this app is not locked
					if (lockQuery.next() == false && ccURL.length() > 0) {
					
						// create url to call evaluate via coldfusion page
						ccURL=ccURL.substring(0,ccURL.indexOf("fuse_action="));
						ccURL = ccURL + "fuse_action=fuseEarlyDiscTTU&user_id=SYSTEM&request_id="+request_id+"&evaluator_id="+selectionQuery.getColValue("evaluator_id")+ "&closeSession=true";
						try{
			            	PostRequest postRequest = new PostRequest();
			              	response = postRequest.post(ccURL,"",60); // 60 sec timeout
			              	if (b_logging && log_level >= 5) {
								System.out.println("post response = "+response);
							}	
			            }
			            catch (Exception e) {
			               	System.out.println("Error posting to eValuate fuse=fuseEarlyDiscTTU: "+e.toString());
			               	e.printStackTrace();
			            }	
					}    
					else {
						if (b_logging) {
							System.out.println("request_id="+request_id+", was locked so ttu call not made");
						}	
					}     
					
				} catch (Exception e1) {
					System.out.println("Error running lock query on request_id = "+request_id+": " + e1.toString());
					e1.printStackTrace();
				}
			} //if (redirect)
		} //end while
	}
	///////////////////////////////// USAGE ///////////////////////////////////////////////
	public static void showUsage() {
		System.out.println("Usage:");
        System.out.println("earlyDisclosure -i<ini file> -l<logging> -e<evaluator> -r<redirection> -p<product> -d<days>");
        System.out.println("------------------------------------------------------------------------------");
		System.out.println("ini - (REQUIRED) path to origenate.ini file to use for configuration");
		System.out.println("logging - (OPTIONAL) 1 to log, 0 to not log.  defaults to 0.  log level will be determined by origenate.ini");
		System.out.println("evaluator id - (REQUIRED) Origenate's numeric id of evaluator to export (see evaluator table).");
		System.out.println("redirection - (OPTIONAL) 1 to run a taskteamuser evaluate call after running this process.  defaults to 0");
		System.out.println("product id - (OPTIONAL) Origenate's numeric id of product for applications to export (see mstr_product table)");
		System.out.println("days - (OPTIONAL) Number of days old an app can be to still qualify for export.  defaults to 90");
        System.exit(1);
	}
	///////////////////////////////////// END USAGE ///////////////////////////////////////////////
}

