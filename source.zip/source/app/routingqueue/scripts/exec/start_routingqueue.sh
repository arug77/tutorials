#!/bin/sh
#
# Starts the Routing Queue Processor
#

LOGFILE=$BASE/log/RoutingQueueProcessor.log
INIFILE=$ORCONFIG/$ENVTYPE.ini
HOSTNAME=`hostname`


echo `date +"%Y/%m/%d %T"` Running RoutingQueueProcessor -i$INIFILE -uhttp://$HOSTNAME/routingprocessor/default.cfm -s10 $1 >> $LOGFILE
nohup java -cp $CLASSPATH:/opt/origenate/$ENV/apps/lib/activation.jar:/opt/origenate/$ENV/apps/lib/mail.jar com.cmsinc.origenate.tool.rqp.RoutingQueueProcessor -n10 -i$INIFILE -uhttp://$HOSTNAME/routingprocessor/default.cfm -s2 $1 >> $LOGFILE &
exit 0
