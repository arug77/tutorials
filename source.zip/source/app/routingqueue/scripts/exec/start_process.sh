#!/bin/ksh
#
#  JAVA Process 
#
#  Author:  Craig Nauman 07/20/2005
#
##############################
#### Environment Variables
export vEnv=$1
export vRoutingStates=$2
export vLog=$ORLOGS/RoutingQueueProcessor$3.log


java com.cmsinc.origenate.tool.rqp.RoutingQueueProcessor -u"$vEnv" -t$vRoutingStates -n5 -i$ORCONFIG/origenate.ini -s2  >> $vLog 2>>$vLog &
