package com.cmsinc.origenate.tool.rqp;

import java.sql.*;
import java.util.*;
import java.io.File;

import com.cmsinc.origenate.util.COLEncrypt;
import com.cmsinc.origenate.util.IniFile;
import com.cmsinc.origenate.util.LogMsg;
import com.cmsinc.origenate.crypto.*;
import com.cmsinc.origenate.util.OWASPSecurity;


/*
 * RoutingQueueProcessor.java
 *
 * Created on June 14, 2000, 1:43 PM
 *
 * Converted to use oracle.jdbc 
 * and logged all errors to System.out instead of System.err
 * August 7th, 2000
 *
 *
 * @author  marca
 * @version
 *
 *
 * Changed by: Glenn Leyba 08/28/2001
 * Added new routing action: callBureauXML, to send CredCo bureau requests
 * via XML to the evaluate gateway.
 *
 *
 */
public class RoutingQueueProcessor {

    //String sDecURL = "";
    String sURL = "";
    String sHost = "";
    String sSIDname = "";
    String sPort = "";
    String sUser = "";
    String sPass = "";
    String sTNSEntry = "";
    String sIniFile = "";
    String sRoutingStateInClause="";
    String sMaxTriesList = "";
    String sWaitTimeList = "";
    ArrayList<String> routingStateList = new ArrayList<String>();
    ArrayList<String> maxTriesList = new ArrayList<String>();
    ArrayList<String> waitTimeList = new ArrayList<String>();
    String s_evaluate_url = "";
    String s_default_network = "";
	boolean encryption_flg = false;
    long lSleepSecs;
    final int I_DEF_BATCH_SIZE=20;
    final int I_DEF_TRIES=5;
    int iBatchSize = I_DEF_BATCH_SIZE;
    int iTries = 1; // ONLY TRYING ONCE NOW BECAUSE BEING USED TO INDICATE THAT ITS IN PROCESS
    int i_dbg_level=0;
    IniFile ini= null;
    LogMsg log_obj = null;
    int maxThreads=1;
    Vector processThreads=null;
    int runningThreads;
    int i_timeout_sec;

    File eojFile = null; // 162583 - if this file is specified with the -z parm then the presence of this file will cause the pgm to shutdown gracefully
    int jobCount=0; // the first 3 jobs, will wait 10 secs before assigning a new job so as not to overrun eValuate on startup


    public RoutingQueueProcessor() {
        ini= new IniFile();
        log_obj = new LogMsg();
        log_obj.setLogID("MAIN: ");
    }

    /////////////////////////////////////////////////////////////////////////////////


    public static void main (String args[]) {

        RoutingQueueProcessor rqp = new RoutingQueueProcessor();

        try {
          rqp.run(args);
        }
        catch (Exception e) {} // error already reported

        System.exit(0);
    }


    ////////////////////////////////////////////////////////////////////////////////


    void run(String args[]) throws Exception {

        log_obj.FmtAndLogMsg("RoutingQueueProcessor running...");

        GetArgs(args,log_obj);

        boolean allThreadsBusy=true;
        boolean allThreadsDisabled=true;
        Connection con = null;

        // sConStr should be something like:
        // "jdbc:oracle:thin:@172.16.17.108:1521:cmsiprod"
        StringBuffer temp_buffer1 = new StringBuffer("jdbc:oracle:thin:@");

        if (sTNSEntry.length() == 0) {
        	temp_buffer1.append(sHost + ":" + sPort + ":" + sSIDname);
        } else {
            temp_buffer1.append(sTNSEntry);
        	log_obj.FmtAndLogMsg("Using TNS Entry");
        }
        String sConStr = temp_buffer1.toString();

        // Load Oracle driver
        try {
        DriverManager.registerDriver (new oracle.jdbc.OracleDriver());
        }
        catch (Exception e) {
            log_obj.FmtAndLogMsg(e.toString());
            return;
        }


        //
        // This loop will force the program to continue retrying connecting to the db
        // if an exception occurs from here down into the main loop
        //
        while (true) { // until killed


            //  S T A R T     P R O C E S S    T H R E A D S

            log_obj.FmtAndLogMsg("Creating process threads...");
            processThreads = new Vector();
            runningThreads=0;
            for (int i=0; i<maxThreads; i++) {

                ProcessThread pt=null;
                try {pt = new ProcessThread(this,sConStr,sUser,sPass, encryption_flg,i+1,i_dbg_level,s_default_network,s_evaluate_url,ini,i_timeout_sec);}
                catch (Exception e) {
                    log_obj.FmtAndLogMsg("Error starting thread "+(i+1)+", error="+e.toString());
                    pt=null;
                }
                if (pt!=null) {
                   processThreads.addElement(pt);
                   pt.start(); // they will wait until they are given work to do
                   runningThreads++;
                }
                
                // Sleep for 1/5 second before starting next thread
                // Staggering thread startup to prevent contention
                Thread.sleep(200);
            }

            log_obj.FmtAndLogMsg(runningThreads+" threads running...");

            if (runningThreads==0) break;




            try {

                // Connect to the Oracle database
                con = DriverManager.getConnection (sConStr,sUser,sPass);

                log_obj.FmtAndLogMsg("Checking Routing Queue Table",i_dbg_level,5);


                    String s_select_fields;

                //
                // main loop runs forever
                //
                while (true) {


                        if (eojFile!=null && eojFile.exists()) {
                           log_obj.FmtAndLogMsg("Gracefull shutdown detected, shutting down...");
                           break;
                        }


                	String s_sql = "";
                	if (sRoutingStateInClause.length() > 0 && sMaxTriesList.length() > 0){	
					    PreparedStatement ps = null;
						try{
							s_sql = "update routing_queue set max_tries_num = ? where routing_state_id = ? " + 
                				"and (max_tries_num is null or max_tries_num != ?)";
							ps = con.prepareStatement(s_sql);
							for(int i = 0; i < routingStateList.size(); i++) {
									ps.setInt(1, Integer.parseInt(maxTriesList.get(i)));
									ps.setInt(2, Integer.parseInt(routingStateList.get(i)));
									ps.setInt(3, Integer.parseInt(maxTriesList.get(i)));
									ps.execute();
					        }
						} catch (Exception e) {
							throw e;
						} finally {
							try{ if(ps != null) ps.close(); }catch(Exception e){e.printStackTrace();}
						}
                	}

                	s_select_fields = "SELECT REQUEST_ID, ROUTING_STATE_TXT, TRIES_NUM, ROUTING_QUEUE.ROUTING_STATE_ID, ADDITIONAL_DATA_TXT, ROUTING_QUEUE_ID ";
                    s_sql = s_select_fields + " FROM ROUTING_QUEUE, MSTR_ROUTING_STATE WHERE ";
                    StringBuilder temp_buffer2 = new StringBuilder(s_sql);

                    temp_buffer2.append(" ROUTING_QUEUE.ROUTING_STATE_ID = MSTR_ROUTING_STATE.ROUTING_STATE_ID ");
                    temp_buffer2.append(" AND RUN_DT <= SYSDATE ");

                    String[] in_clause_tokens = null;
                    boolean maxtriesnotzero = false;
                    if (sRoutingStateInClause.length() > 0 && sMaxTriesList.length() == 0) {
                        temp_buffer2.append(" and routing_queue.routing_state_id in (");
                        // append placeholders instead of using dynamic sql
                        StringBuilder sqlbuilder = new StringBuilder();
                        in_clause_tokens = sRoutingStateInClause.split(" *, *"); 
                        for(String token : in_clause_tokens){
                            sqlbuilder.append("?, ");
                        }
                        sqlbuilder.deleteCharAt(sqlbuilder.length() - 2); // get rid of last comma
                        temp_buffer2.append(sqlbuilder.toString() + ") and tries_num = 0 ");
                    } else if (sRoutingStateInClause.length() > 0 && sMaxTriesList.length() > 0){
                        maxtriesnotzero = true;	
                        temp_buffer2.append(" and (routing_queue.status_txt is null " +
                    			"OR routing_queue.status_txt = 'ERROR') and (");
                    	for(int i = 0; i < routingStateList.size(); i++) {
                    		if(i > 0) temp_buffer2.append(" or ");
                            temp_buffer2.append(" (routing_queue.routing_state_id = ? " +
                    			" and routing_queue.tries_num < ?) ");
                    	}
                        temp_buffer2.append(") ");
                    } else {
                        temp_buffer2.append(" AND TRIES_NUM = 0 ");
                    }
                    temp_buffer2.append(" ORDER BY QUEUE_PRIORITY_NUM DESC, ROUTING_QUEUE_ID ASC");
                    s_sql = temp_buffer2.toString();
                    
                    /**
                     * OWASP TOP 10 2010 - A1 High SQL Injection
                     * TTP 324955 Security Remediation Fortify Scan
                     */
                    PreparedStatement ps = con.prepareStatement(s_sql);
                    //PreparedStatement ps = con.prepareStatement(ESAPI.encoder().encodeForSQL( new OracleCodec(),s_sql.toString()));	
                    int placeholder_count = 1;
                    if (in_clause_tokens != null){
                        for(String token : in_clause_tokens){
                            ps.setString(placeholder_count++, token);
                        }
                    }
                    else if(maxtriesnotzero){
                        for(int i = 0; i < routingStateList.size(); i++) {
                            ps.setInt(placeholder_count++, Integer.valueOf(routingStateList.get(i)));
                            ps.setInt(placeholder_count++, Integer.valueOf(maxTriesList.get(i)));
                        }
                    }

                    ResultSet rs = null;					
        			try
					{
						/* original
						String s_sql = s_select_fields + "FROM ROUTING_QUEUE, MSTR_ROUTING_STATE " +
								"WHERE ROUTING_QUEUE.ROUTING_STATE_ID = MSTR_ROUTING_STATE.ROUTING_STATE_ID " +
								"AND RUN_DT <= SYSDATE AND TRIES_NUM <" + iTries + " "+
								"AND ROUTING_QUEUE.ROUTING_STATE_ID <> 2 " + // Routing state id of 2 is WAIT, so don't even pull it
								"ORDER BY QUEUE_PRIORITY_NUM DESC, ROUTING_QUEUE_ID ASC";
						  */

						ps.execute();
						
						rs = ps.getResultSet();

						//log_obj.FmtAndLogMsg("Queue query found: "+query.getRowCount());

						if (!rs.next()) {
							//
							// If there were no records in the last query then sleep
							//
							   Thread.sleep(lSleepSecs * 1000);
							   if (eojFile!=null && eojFile.exists()) {
								  log_obj.FmtAndLogMsg("Gracefull shutdown detected, shutting down...");
								  break;
							   }
						}
						else  {// process jobs found

                                                        boolean jobAlreadyInProcess=false;
							do {

                                                                jobAlreadyInProcess=false;

								String jobID=rs.getString("routing_queue_id") == null ? "0" : rs.getString("routing_queue_id");
								String requestID=rs.getString("request_id") == null ? "0" : rs.getString("request_id");
								String routingStateID=rs.getString("routing_state_txt") == null ? "0" : rs.getString("routing_state_txt");
								String additionalData=rs.getString("additional_data_txt") == null ? "" : rs.getString("additional_data_txt");
								String routingState=rs.getString("routing_state_id") == null ? "0" : rs.getString("routing_state_id");
								String triesNum =rs.getString("tries_num") == null ? "0" : rs.getString("tries_num");

								
								// find a free thread to process this job

								allThreadsBusy=true;
								allThreadsDisabled=true;
								ProcessThread processThread;

								while (allThreadsBusy) {

									//log_obj.FmtAndLogMsg("Trying to assign job:"+jobID+" action="+routingStateID+", parms="+additionalData,i_dbg_level,5);
									
									// Encryption Dummy Block start
									// This block is redundant. But as we are getting NAE Session encryption error while performing from multi threaded environment.
									// It turned out, that before calling encryption operation from thread, if we call them outside, then it creates NAE session and after that it can be called without error from threads
									// so , we are just encryption dummy string to create NAE session.
									// After figured out NAE session error from multithreaded environment. This step actually not needed
									if(encryption_flg) {
										Crypto crypto =  CryptoFactory.getCrypto();
										String encryptionUser = "origenate_"+sUser;
										try {
											crypto.encryptString(encryptionUser.toLowerCase(),"clob","tempValue");
											log_obj.FmtAndLogMsg("Encryption Session Created",i_dbg_level,5);
										} catch(Exception e) { log_obj.FmtAndLogMsg("Error in Creating Encryption Session: "+e.toString(),i_dbg_level,5);}
									} // Encryption dummy block end
									
									for (Enumeration e = processThreads.elements(); e.hasMoreElements (); ) {

										processThread=(ProcessThread)e.nextElement ();

										if (processThread.busy) {
											if (!processThread.errorOccurred) {
											  //  log_obj.FmtAndLogMsg("Thread:"+processThread.threadID+" is busy",i_dbg_level,5);
												allThreadsDisabled=false;
											}
										}
										else {
											// thread not busy so assign it this Job ID

                                                                                        // update the queue so that this job doesn't get selected again

                                                                                   /* glennl 170556 3/13/2014 - We want to be able to run multiple RQPs on different app servers, in case one goes down the other will continue 
                                                                                   processing jobs. To keep two instances from trying to work the same job we are
                                                                                   checking if the tries_num has chgd since we read the table. If it has, then the number of rows updated will be 0 and we can
                                                                                   assume that another instance is working it.
                                                                                   */
                                                                                        if (incrementTries(con,jobID,triesNum)==0) { // method returns number of rows updated.
                                                                                           log_obj.FmtAndLogMsg("Job:"+jobID+" skipped, another process is working it",i_dbg_level,0);
                                                                                           jobAlreadyInProcess=true;
                                                                                           break;
                                                                                        }
											jobCount++;
											allThreadsBusy=false;
											allThreadsDisabled=false;
											processThread.busy=true;
											processThread.jobID=jobID;
											processThread.requestID=requestID;
											processThread.routingStateID=routingStateID;
											processThread.additionalData=additionalData;
											processThread.routingState=routingState;

											// log_obj.FmtAndLogMsg("Job:"+jobID+" assigned to thread: "+processThread.threadID,i_dbg_level,5);



											// setting workToDo will cause this thread to process this job
											processThread.workToDo=true;
											break;
										}

									}  // for - checking for a free thread

                                                                        if (jobAlreadyInProcess) break; //170566 gl.

									if (allThreadsDisabled) break; // all threads disabled

									if (allThreadsBusy)  {
										// sleep for 1/5 sec before checking if any are free
										try {Thread.sleep(200);} catch (Exception e) {}
										if (eojFile!=null && eojFile.exists()) {     // 162583 - gracefull shutdown
									  //     log_obj.FmtAndLogMsg("Gracefull shutdown detected, shutting down...");
										   break;
										}
									}

	 
								} // while allThreadsBusy

                                                                /* glennl. 3/12/2014 170556 
                                                                If multiple RQP's are running on different servers they could have picked up the job before this instance could service it.
                                                                If this is the case we need to skip this job and check the next job.
                                                                */
                                                                if (jobAlreadyInProcess) continue;

								if (allThreadsDisabled)
									throw new Exception("All threads are disabled, can't assign work, restarting");



								if (eojFile!=null && eojFile.exists()) {
								   log_obj.FmtAndLogMsg("Gracefull shutdown detected, shutting down...");
								   break;
								}


								// 162583:
								// the first 3 jobs, will wait 10 secs before assigning a new job so as not to overrun eValuate on startup
								if (jobCount<=3) {
								   log_obj.FmtAndLogMsg("Sleeping 10 seconds before assigning next job...(only applies to first 3 jobs upon startup)");
								   try {Thread.sleep(10000);} catch (Exception e) {}
								   if (eojFile!=null && eojFile.exists()) {
									  log_obj.FmtAndLogMsg("Gracefull shutdown detected, shutting down...");
									  break;
								   }
								}

							} while (rs.next()); // for each job


						} // processed jobs found in queue
                    }
                    catch(Exception e){
					   throw e;
                    }
                    finally{
					  try{ if(rs != null) rs.close(); }catch(Exception e1){e1.printStackTrace();} 
                      try{ if(ps != null) ps.close(); }catch(Exception e2){e2.printStackTrace();}
                   }		
                   if (eojFile!=null && eojFile.exists()) {
                       log_obj.FmtAndLogMsg("Gracefull shutdown detected, shutting down...");
                       break;
                    }


                } // while true, search queue for jobs


            }
            catch (Exception e) {
                log_obj.FmtAndLogMsg("Severe Error: "+e.toString()+"   Reconnecting to database in 5 seconds");
            }
            finally {
                try { con.close();} catch (Exception e1) {}
            }

            // need to start all over but first clean up running threads


            // tell all threads to terminate themselves gracefully

            for (Enumeration e = processThreads.elements(); e.hasMoreElements (); ) {
              ProcessThread processThread=(ProcessThread)e.nextElement ();
              processThread.endThread=true;
            }  // for

            // wait for threads to end gracefully
            int maxWait=0;
            log_obj.FmtAndLogMsg("Waiting on threads to end...");
            while(maxWait<30) { // give up in 30 seconds
               if (threadCount(false)<=0) break;
               try {Thread.sleep(1000);} catch (Exception e) {}
               maxWait++;
            }



            // Database error, need to reconnect


            if (eojFile!=null && eojFile.exists()) {
               log_obj.FmtAndLogMsg("Gracefull shutdown detected, shutting down...");
               break;
            }
            else
            try {
                log_obj.FmtAndLogMsg("Sleeping for 5 seconds, before retrying db open",i_dbg_level,5);
                Thread.sleep(5000);
                log_obj.FmtAndLogMsg("Awake..",i_dbg_level,5);
            }
            catch (Exception e) {
                log_obj.FmtAndLogMsg("Warning: Sleep was forced awake");
            }

        } // while(true)


        if (eojFile!=null && eojFile.exists()) {
           eojFile.delete();
           log_obj.FmtAndLogMsg("Gracefull shutdown detected, exiting program now");
        }

    }  // run


    ////////////////////////////////////////////////////////////////////////////////

    private void GetArgs(String args[],LogMsg log_obj) {
        int ix;

        if (args.length > 0) {
            for (ix = 0; ix < args.length; ++ix) {
                if ((args[ix].charAt(0) != '-') && (args[ix].length() > 1)){
                    ShowUsage();
                }

                switch (args[ix].charAt(1)) {
                    case 'i':
                    sIniFile = args[ix].substring(2);
                    log_obj.FmtAndLogMsg("IniFile is '" + sIniFile + "'");
                    try {
                        //
                        // Read host, user, sid and password from ini file
                        //
                        ini.readINIFile(sIniFile);


                        sHost = ini.getINIVar("database.host");
                        log_obj.FmtAndLogMsg("Host is '" + sHost + "'");

                        sUser = ini.getINIVar("database.user");
                        log_obj.FmtAndLogMsg("Schema User"+sUser);

                        sPort = ini.getINIVar("database.port");
                        log_obj.FmtAndLogMsg("Port is '" + sPort + "'");

                        sPass = ini.getINIVar("database.password");
                        log_obj.FmtAndLogMsg("Set Password");
                        sPass = COLEncrypt.sDecrypt(sPass);
						
						if(Integer.parseInt(ini.getINIVar("encryption.encryption_flg","0")) == 1) {
							encryption_flg = true;
						}
						log_obj.FmtAndLogMsg("Encryption Flag: "+encryption_flg);

                        sTNSEntry = ini.getINIVar("database.TNSEntry", "");
                        log_obj.FmtAndLogMsg("TNS entry is '" + sTNSEntry + "'");
                        
                        sSIDname = ini.getINIVar("database.sid");
                        log_obj.FmtAndLogMsg("Database (SID name) is '" + sSIDname + "'");

                        s_default_network = ini.getINIVar("general.default_network");
                        log_obj.FmtAndLogMsg("Default network is '" + s_default_network + "'");

                        s_evaluate_url = ini.getINIVar("urls.evaluate_url");
                        log_obj.FmtAndLogMsg("Evaluate URL is '" + s_evaluate_url + "'");

                        i_timeout_sec = new Integer(ini.getINIVar("general.evaluate_trans_timeout")).intValue();
                        log_obj.FmtAndLogMsg("evaluate tran timeout is '" + i_timeout_sec + "'");



                    }
                    catch (Exception e) {
                        log_obj.FmtAndLogMsg("Caught exception reading ini file '" + sIniFile + "':"+e.toString());
                    }
                    break;

                    case 'u':
                    sURL = args[ix].substring(2);
                    log_obj.FmtAndLogMsg("URL is '" + sURL + "'");
                    break;

                    case 'z':
                    	
                    /** OWASP Top 10 2010 - A4 path manipluation
                      * Change to the below code to fix vulnerabilities
                      * TTP 324955
                      */
                    //eojFile = new File(args[ix].substring(2));
                    try
                    {
                    eojFile = new File(OWASPSecurity.validationCheck(args[ix].substring(2), OWASPSecurity.DIRANDFILE));
                    }
                    catch(Exception e)
                    {
                        e.printStackTrace();
                    }
                    log_obj.FmtAndLogMsg("End of job file is '" + args[ix].substring(2) + "'");
                    break;


                    case 's':
                    try {
                        lSleepSecs = Long.valueOf(args[ix].substring(2)).longValue();
                        log_obj.FmtAndLogMsg("Sleep seconds set at " + lSleepSecs);

                    }
                    catch (Exception e) {
                        log_obj.FmtAndLogMsg("Unable to convert parameter: " + args[ix]);
                    }
                    break;

                    case 'b':
                    try {
                        iBatchSize = Long.valueOf(args[ix].substring(2)).intValue();//Long.valueOf(args[ix].substring(2)).longValue();
                        log_obj.FmtAndLogMsg("Batch Size " + iBatchSize);

                    }
                    catch (Exception e) {
                        log_obj.FmtAndLogMsg("Unable to convert parameter: " + args[ix]);
                    }
                    break;

                    case 't':
                    sRoutingStateInClause = args[ix].substring(2);
                    log_obj.FmtAndLogMsg("Looking for routing states: " + sRoutingStateInClause);
                    break;
                    
                    case 'm':
                    sMaxTriesList = args[ix].substring(2);
                    log_obj.FmtAndLogMsg("Max tries list (corresponds to routing states): " + sMaxTriesList);
                    break;
                    
                    case 'w':
                    sWaitTimeList = args[ix].substring(2);
                    log_obj.FmtAndLogMsg("Wait time list (corresponds to routing states): " + sWaitTimeList);
                    break;
                    
                    case 'n':
                    try {
                        maxThreads = Integer.parseInt(args[ix].substring(2));
                    }
                    catch (Exception e) {
                        maxThreads=1;
                    }
                    log_obj.FmtAndLogMsg("Num threads = " + maxThreads);
                    break;

                    case 'D':
                    log_obj.FmtAndLogMsg("Running with debugs on");
                    i_dbg_level = 5;
                    break;

                   case 'd':
                   log_obj.FmtAndLogMsg("Running with debugs on");
                   i_dbg_level = 5;
                   break;

                    default:
                    log_obj.FmtAndLogMsg("Unknown parameter: " + args[ix]);
                    ShowUsage();
                    break;
                }
            }
            if ((sHost.length()==0) || (sPort.length()==0) || (sUser.length()==0) || (sSIDname.length()==0) || (lSleepSecs <= 0) || (iTries <=0)) {
                log_obj.FmtAndLogMsg("Parameter host:"+sHost);
                log_obj.FmtAndLogMsg("Parameter port:"+sPort);
                log_obj.FmtAndLogMsg("Parameter user:"+sUser);
                log_obj.FmtAndLogMsg("Parameter sid:"+sSIDname);
                log_obj.FmtAndLogMsg("Parameter URL:"+sURL);
                log_obj.FmtAndLogMsg("Parameter sleep seconds:"+lSleepSecs);
                log_obj.FmtAndLogMsg("Parameter batch size:"+iBatchSize);
                log_obj.FmtAndLogMsg("Parameter tries:"+iTries);
                log_obj.FmtAndLogMsg("Error: One of the above parameters supplied on the commandline and/or ini file are in invalid.");
                ShowUsage();
            }
            
            // If the Routing State List is set and either the Max Tries List
            // or Wait Time List are set, then check to make sure all are set
            // and are of the same length.
            if(sRoutingStateInClause.length() > 0 && 
            	(sMaxTriesList.length() > 0 || sWaitTimeList.length() > 0)) {
            	Collections.addAll(routingStateList, sRoutingStateInClause.replaceAll("\\s","").split(","));
            	
            	if(sMaxTriesList.length() > 0) {
            		Collections.addAll(maxTriesList, sMaxTriesList.replaceAll("\\s","").split(","));
            	} else {
            		log_obj.FmtAndLogMsg("Error: Routing State List and Wait Time are set, but Max Tries is missing.");
            		ShowUsage();
            	}
            	
            	if(sWaitTimeList.length() > 0) {
            		Collections.addAll(waitTimeList, sWaitTimeList.replaceAll("\\s","").split(","));
            	} else {
            		log_obj.FmtAndLogMsg("Error: Routing State List and Max Tries are set, but Wait Time is missing.");
            		ShowUsage();
            	}
            	
            	if(routingStateList.size() != maxTriesList.size() || 
            		routingStateList.size() != waitTimeList.size()) {
            		log_obj.FmtAndLogMsg("Error: Routing State, Max Tries, and Wait Time lists must contain the same number of elements.");
            		ShowUsage();
            	}
            }
        }
        else {
            ShowUsage();
        }


    } // get args

    ////////////////////////////////////////////////////////////////////////////////

    private void ShowUsage() {
        System.out.println("");
        System.out.println("Usage: RoutingQueueProcessor  -d<Database> -h<DBHost> -p<DBpasswd> -U<DBUser> -n<numthreads> -s<SleepSeconds> -t<routingstate list>  [-D]");
        System.out.println("---------------------");
        System.out.println("sIniFile - INI file to use for configuration");
        System.out.println("SleepSeconds - Seconds to sleep before polling db");
        System.out.println("-D - sets debug messages on.  [Default is off]");
        System.out.println("-t - [optional] list of routing states to look for separated by commas ie) -r9 or -r9,11,12");
        System.exit(1);
    }





    /////////////////////////////////////////////////////////////////

    public synchronized int threadCount(boolean decreaseCount) {
        if (decreaseCount)
            runningThreads--;
        return(runningThreads);
    }

    /////////////////////////////////////////////////////////////////////////////////////////


    /**
     * Increment the tries for the current transaction.
     */
    private int incrementTries (Connection con,String jobID, String triesNum) throws Exception {
    	PreparedStatement ps = null;
    	String sql = "";
        int rowsUpdated=0;
        try {
            // 1/23/07 ChrisN CL140795 Replaced with SQL using bind variable for Triad performance enhancement
            //SQLUpdate.RunUpdateStatement(con,"UPDATE ROUTING_QUEUE " +
            //"SET TRIES_NUM = TRIES_NUM + 1 " +
            //"WHERE ROUTING_QUEUE_ID = "+jobID);

           /* glennl 170556 3/13/2014 - We want to be able to run multiple RQPs on different app servers, in case one goes down the other will continue 
           processing jobs. To keep each instance from possibly trying to work job that is already grabbed by a previous instance we are
           checking if the tries_num has chgd since we read the table. If it has, then the number of rows updated will be 0 and we can
           assume that another instance is working it.
           */
            sql = "UPDATE ROUTING_QUEUE SET TRIES_NUM = TRIES_NUM + 1, STATUS_TXT = 'PROCESSING' WHERE ROUTING_QUEUE_ID = ? AND TRIES_NUM = ?";
        	//Prepare statement to execute
        	ps = con.prepareStatement(sql);

        	//Set param values
        	ps.setInt(1, Integer.parseInt(jobID));
        	ps.setInt(2, Integer.parseInt(triesNum));

        	//Execute statement
        	rowsUpdated=ps.executeUpdate();
			ps.close();
        }
        catch (java.sql.SQLException e) {
            throw new Exception("Error: Unable to open a statement to increment tries:"+e.toString());
        }
		finally {
          try{if(ps !=null) ps.close();} catch(Exception ex) {ex.printStackTrace();}
		}
        return rowsUpdated;
    }


} // end class RoutingQueueProcessor
