/*
 * PostEventIfEmail.java
 *
 * Created on September 24, 2002, 1:55 PM
 */

package com.cmsinc.origenate.tool.rqp;

import com.cmsinc.origenate.util.GlobalVars;
import com.cmsinc.origenate.util.LogMsg;
import java.sql.*;
 

/** 
 *
 * @author  Marc Amick
 * @version 
 */
public class PostEventIfEmail {

    public static void PostEventIfEmail(GlobalVars send_vars,LogMsg log_obj, Connection con,String s_xml, int i_dbg_level) throws Exception {


        // Don't do anything in origenate for this yet


    } // post email event  
}