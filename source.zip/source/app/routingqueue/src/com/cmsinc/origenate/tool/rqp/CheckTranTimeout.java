/*
 * CheckTranTimeout
 *
 * Created on November 14, 2002, 2:45 PM
 */

package com.cmsinc.origenate.tool.rqp;

import java.sql.*;
import java.util.StringTokenizer;
import com.cmsinc.origenate.util.LogMsg;
//import com.cmsinc.origenate.util.SQLUpdate;
import com.cmsinc.origenate.util.EvaluateTransaction;
/**
 *
 * @author  marca
 * @version
 */
public class CheckTranTimeout {



//    public void CheckTranTimeout() {};

    //
    // Check For Evaluate Transaction Timeout
    //
    public void checkTranTimeOut(LogMsg log_obj, int i_dbg_lvl, long l_request_id, String s_additional_data, String s_key, Connection con) throws Exception{
        try {
            StringTokenizer st_data = new StringTokenizer(s_additional_data,",");
            String s_name;
            String s_value="-1";
            String s_erq_id=null;
            while (st_data.hasMoreTokens()) {
                s_name = st_data.nextToken();
                if (st_data.hasMoreTokens()) {
                    s_value = st_data.nextToken();
                }
                if (s_name.compareToIgnoreCase("ERQ_ID")==0) {
                    s_erq_id = s_value;
                }
            }
            
            if ((s_erq_id !=null) && (s_erq_id.length() > 0)) {
                EvaluateTransaction.UpdateEvaluateTransactionStatus(con,log_obj,i_dbg_lvl,"3","The transaction has timed out.","Transaction timed out by routing queue",false,s_erq_id,false);
            }
            else {
                throw new Exception("The variable ERQ_ID was not specified in the additional data for this routing queue item!");
            }
            
        }
        catch (Exception e) {
            throw new Exception("Exception caught in CheckTranTimeOut:"+e.toString());
        }
        
        return ;

    }  // end CheckTranTimeOut()

}