package com.cmsinc.origenate.tool.rqp;

//import java.io.*;
//import java.net.*;
//import java.util.StringTokenizer;
//import java.sql.*;
//
//import org.xml.sax.InputSource;
//import org.apache.xerces.parsers.DOMParser;
//import org.apache.xml.serialize.OutputFormat;
//import org.apache.xml.serialize.Serializer;
//import org.apache.xml.serialize.XMLSerializer;
//import org.w3c.dom.*;
//
//import com.cmsinc.origenate.util.LogMsg;
//import com.cmsinc.origenate.util.PostRequest;
//import com.cmsinc.origenate.util.GlobalVars;
//import com.cmsinc.origenate.util.XPathAPI;
//import com.cmsinc.origenate.util.IniFile;
//import com.cmsinc.origenate.util.SQLUpdate;
//
//import com.cmsinc.origenate.xmldbt.GenX;
//import com.cmsinc.origenate.xmldbt.SimpleXMLReceiver;
//


/**
 * <pre>
 *
 * This class is loaded by RQTools.sendXML() to control the generation and posting
 * of a XML transaction when no other Controller class for the transaction type is found.
 * 
 *
 * If you are implementing a Controller for a particular trans type ( LoanAppRs )
 * then make a copy of this .java file and rename it to LoanAppRs.java. Then change
 * the class name and constructor and add any business logic around the main flow
 * as required.
 *
 * </pre>
 *
 */
public class DefaultController extends BaseController implements ControllerInterface {



    //public void DefaultController() {};



    /////////////////////////////////////////////////////////////////////////////////////////



    public void runController() throws Exception {

        // if it doesn't throw an exception then it succeeded



        String s_xml="",s_url="";



        //  B U I L D    T H E    X M L   F R O M    T H E    D A T A B A S E

        s_xml=buildXML();



        //   D E T E R M I N E   URL   D E S T I N A T I O N

        /*
        The URL to post to was put in the Additional_data column on the routing_queue.
        Its value is stored in the COL_DESTINATION parm. This parm was named COL_
        because normally we post to a Credit-Online gateway. If the value of the URL
        is EVALUATE_URL then the requestor is asking to use the evaluate url specified
        in the origenate.ini file under urls.evaluate_url.

        */

        s_url=getURL();


        //  P O S T   T H E    X M L 

        String response=postXML(s_url,s_xml);



        //  C H E C K     R E S P O N S E





        //   S U C C E S S 


    }  // runController()



} // DefaultController


