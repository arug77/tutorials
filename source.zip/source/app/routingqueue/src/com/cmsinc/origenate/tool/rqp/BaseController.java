package com.cmsinc.origenate.tool.rqp;

import java.net.URLEncoder;
import java.sql.Connection;

import com.cmsinc.origenate.util.GlobalVars;
import com.cmsinc.origenate.util.IniFile;
import com.cmsinc.origenate.util.LogMsg;
import com.cmsinc.origenate.util.PostRequest;
import com.cmsinc.origenate.util.PostUtils;
import com.cmsinc.origenate.util.Query;
import com.cmsinc.origenate.xmldbt.GenX;



/**
 * <pre>
 *
 *  This is the BaseController class that all Controller classes should extend.
 *
 *  DefaultController.java is the default class that extends this class to
 *  process transactions when a class with the trans name can not be found.
 *  It performs default process like the old RQP. 
 *
 *  NotifyDecRs.java is a class that extended this class as an example
 *  of how to create Controller classes for a particular trans type. 
 *
 *
 * </pre>
 *
 */
public class BaseController implements ControllerInterface {

	Connection con;
	int i_dbg_level;
	LogMsg log_obj;
	String s_transaction;
	String styleSheet;
	GlobalVars send_vars;
	//long l_request_id;
	String s_key;
	GenX genx;
	String s_evaluate_url; // gotten from origenate.ini urls.evaluate_url
	IniFile iniFile;



	//    public void BaseController() {};



	public void initialize(Connection con,String s_transaction,String styleSheet,
			GlobalVars send_vars,long l_request_id,String s_key,
			LogMsg log_obj,int i_dbg_level,GenX genx,
			String s_evaluate_url,IniFile ini) throws Exception { 

		this.con=con;
		this.s_transaction=s_transaction;
		this.styleSheet=styleSheet;
		this.send_vars=send_vars;
		//this.l_request_id=l_request_id;
		this.s_key=s_key;
		this.log_obj=log_obj;
		this.genx=genx;
		this.i_dbg_level=i_dbg_level;
		this.s_evaluate_url=s_evaluate_url;
		this.iniFile = ini;

	}



	/////////////////////////////////////////////////////////////////////////////////////////



	public void runController() throws Exception {

		// This method MUST be overriden by the extending class

		log_obj.FmtAndLogMsg("runController() has not been overriden in a extending class, no action taken");

	}  // runController()


	///////////////////////////////////////////////////////////////////////////////////////


	public String buildXML() throws Exception {

		// if it doesn't throw an exception then it succeeded


		String s_xml="";

		log_obj.FmtAndLogMsg("Building xml for trans type: "+s_transaction,i_dbg_level,5);

		//  B U I L D    T H E    X M L   F R O M    T H E    D A T A B A S E


		long l_start = System.currentTimeMillis();

		try {s_xml = genx.sGetXMLorThrow(s_transaction,styleSheet);}
		catch (Exception e) {
			throw new Exception("Error building XML:"+e.toString());
		}

		log_obj.FmtAndLogMsg("Built XML in milliseconds "+ (System.currentTimeMillis()-l_start),i_dbg_level,5 );


		//if (i_dbg_level > 4) { // log the built xml if debug level is high enough

		//    log_obj.FmtAndLogMsg("XML Set to: "+s_xml,i_dbg_level,5);
		//}


		return(s_xml);


	}  // buildXML()



	///////////////////////////////////////////////////////////////////////////////////////

	public String getURL() throws Exception {

		//   D E T E R M I N E   URL   D E S T I N A T I O N

		/*
        The URL to post to was put in the Additional_data column on the routing_queue.
        Its value is stored in the COL_DESTINATION parm. This parm was named COL_
        because normally we post to a Credit-Online gateway. If the value of the URL
        is EVALUATE_URL then the requestor is asking to use the evaluate url specified
        in the origenate.ini file under urls.evaluate_url.

		 */



		String s_url = send_vars.sGetVarValue("COL_DESTINATION");

		if (s_url.compareToIgnoreCase("EVALUATE_URL")==0) {
			s_url = s_evaluate_url;
		}

		log_obj.FmtAndLogMsg("Determined posting URL of: "+s_url,i_dbg_level,5);

		return(s_url);
	}


	///////////////////////////////////////////////////////////////////////////////////////

	public String postXML(String s_url,String s_xml) throws Exception {


		boolean useOutboundPost = false;
		String postConfigId = send_vars.sGetVarValue("POST_CONFIG_ID");
		String evaluatorId = send_vars.sGetVarValue("EVALUATOR_ID");

		Query query = new Query(con);
		
		if(evaluatorId != null) {
			query.prepareStatement("select use_outbound_post_flg "
					+ "from evaluator "
					+ "where evaluator_id = ?");
			query.setInt(1, evaluatorId);
			query.executePreparedQuery();
			if(query.next()) {
				useOutboundPost = query.getColValue("use_outbound_post_flg", "0").equals("1");
			}
		}
		
		//  P O S T   T H E    X M L 
		if(!useOutboundPost || postConfigId == null || postConfigId.equals("")) {

			log_obj.FmtAndLogMsg("Posting to: "+s_url,i_dbg_level,5);

			PostRequest postRequest = new PostRequest(log_obj,i_dbg_level);

			/* GL. 05/24/04 If we are posting to our own postreceiver then
	           we need to make it look like a form post
			 */

			// 7/13/2012 gl. postreceive servlet or cfm pg and colservlet
			if (s_url.toLowerCase().indexOf("postreceive")>=0 || s_url.toLowerCase().indexOf("colservlet")>=0) {
				s_xml="XML="+URLEncoder.encode(s_xml,"UTF-8");
			}

			String response=null;
			try{
				response=postRequest.post(s_url,s_xml,60); // 60 second timeout
			}
			catch(Exception e){
				throw new Exception("Error posting to:"+s_url+"  error="+e.toString());
			}

			log_obj.FmtAndLogMsg("Response: "+response,i_dbg_level,5);
			
			// As of this writing the only response we are expecting is an err_status=0
	        // If we don't get it then we are assuming the receiver rejected the post
	        if (response.indexOf("err_status=0") < 0){
	            throw new Exception(s_url + " rejected post, response=" + response);
	        }

			return response;
		} else {
			String requestId = send_vars.sGetVarValue("REQUEST_ID", "-1");
			String sourceDesc = null;

			query.prepareStatement("select cs.source_desc_txt "
					+ "from credit_request cr, config_sources cs "
					+ "where cr.request_id = ? "
					+ "and cr.source_id = cs.source_id "
					+ "and cr.evaluator_id = cs.evaluator_id "
					+ "and cs.active_flg = 1");
			query.setInt(1, requestId);
			query.executePreparedQuery();
			if(query.next()) {
				sourceDesc = query.getColValue("source_desc_txt");
			}

			PostUtils postUtils = new PostUtils(iniFile);
			String response = postUtils.post(s_xml, evaluatorId, postConfigId, sourceDesc);

			log_obj.FmtAndLogMsg("Response: " + response, i_dbg_level, 5);

			return response;
		}

	}  // postXML()


	/**
	 * Sets the iniFile
	 * @param ini the iniFile to set
	 */
	public void setIniFile(IniFile ini) {
		this.iniFile = ini;
	}
} // BaseController


