package com.cmsinc.origenate.tool.rqp;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.FilenameFilter;
import java.io.PrintWriter;
import java.sql.Clob;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

import org.apache.commons.net.ftp.FTP;
import org.apache.commons.net.ftp.FTPClient;
import org.apache.xerces.parsers.DOMParser;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.xml.sax.InputSource;

import com.cmsinc.origenate.ae.copyapp.CopyApp;
import com.cmsinc.origenate.cp.mpe.Mpe;
import com.cmsinc.origenate.crypto.Crypto;
import com.cmsinc.origenate.crypto.CryptoFactory;
import com.cmsinc.origenate.doc.external.ExternalDoc;
import com.cmsinc.origenate.doc.external.ExternalDocFactory;
import com.cmsinc.origenate.doc.external.SmartDoc;
import com.cmsinc.origenate.event.CommentEvents;
import com.cmsinc.origenate.event.JournalEvents;
import com.cmsinc.origenate.housingcounselor.process.HousingCounselorManager;
import com.cmsinc.origenate.mail.SendDocument;
import com.cmsinc.origenate.util.COLEncrypt;
import com.cmsinc.origenate.util.ConnectionFactory;
import com.cmsinc.origenate.util.GlobalVars;
import com.cmsinc.origenate.util.IniFile;
import com.cmsinc.origenate.util.LogMsg;
import com.cmsinc.origenate.util.OWASPSecurity;
import com.cmsinc.origenate.util.PostRequest;
import com.cmsinc.origenate.util.Query;
import com.cmsinc.origenate.util.SQLSecurity;
import com.cmsinc.origenate.util.SQLUpdate;
import com.cmsinc.origenate.util.XPathAPI;
import com.cmsinc.origenate.xmldbt.GenX;
import com.cmsinc.origenate.xmldbt.SimpleXMLReceiver;
import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.Session;

/*
 * RQTools.java
 *
 * Created on June 17, 2002, 12:30 PM
 */


/**
 *
 * @author  edm
 * @version
 */
public class RQTools extends Object {
    Connection con;
    LogMsg log_obj;
    int i_dbg_level;
    String s_default_network = "";
    GenX genx;
    String s_evaluate_url = "";
    IniFile ini;
	boolean encryption_flg = false;
	String schemaUser = "";

    /** Creates new RQTools */
    public RQTools(Connection con, LogMsg log_obj, int i_dbg_level, String s_default_network, String s_evaluate_url, IniFile ini, String schemaUser, boolean encryption_flg) {
        this.i_dbg_level = i_dbg_level;
        this.con = con;
        this.log_obj = log_obj;
        this.s_default_network = s_default_network;
        this.s_evaluate_url = s_evaluate_url;
        genx = new GenX(con,i_dbg_level);
        this.ini = ini;
		this.schemaUser = schemaUser.toLowerCase();
		this.encryption_flg = encryption_flg;
    }

    ///////////////////////////////////////////////////////////////////////////////////

    public void sendXML (LogMsg log_obj, long l_request_id, String s_additional_data, String s_key, Connection con) throws Exception{

        String s_transaction;

        GlobalVars send_vars;

        //
        // throw an exception if a request_id was not passed in additional_data
        //
        if (s_additional_data.indexOf("REQUEST_ID,")<0) {
            throw new Exception("Exception REQUEST_ID not passed for send app on request id "+l_request_id);
        }

        int idx=s_additional_data.indexOf("REQUEST_ID,");
        String sRID=s_additional_data.substring(idx+11,
               s_additional_data.indexOf(",",idx+11));


        log_obj.FmtAndLogMsg("SEND_XML for RID: "+sRID+"...",i_dbg_level,0);

        send_vars = new GlobalVars(log_obj,i_dbg_level);


        try {
            //
            // Loop through the additional data names and values and set global variables
            //
            SetGlobalVars(s_additional_data, send_vars);

            s_transaction = send_vars.sGetVarValue("TRANSACTION_TYPE");

            //
            // manually set the default network that was pulled from the ini file
            //
            send_vars.SetVar("DEFAULT_NETWORK",s_default_network);
            genx.bSetAllParams(send_vars);

			//setting encryption parameters, so all this fields get decrypted when we send / perform operation on xml.
			genx.setEncryptionParms(schemaUser,"ssn,bank,trade,drivers");

            String stylesheet=send_vars.sGetVarValue("STYLESHEET");
            // stylesheet will be null if one was not specified

            if (i_dbg_level>=1) {
              log_obj.FmtAndLogMsg("[RQP Generating XML and optionally applying XSL]", i_dbg_level,1);
            }


            /*
            Load a Controlling class that manages the generation and posting of
            a particular trans type. A Controlling class might be LoanAppRs.class (for instance),
            which needs to do special processing around the generation and posting of the
            XML. Like, setting the decision status to 'transmitted' if a LoanAppRs was
            sent successfully.

            s_transaction can be for instance: LoanAppRs, but it can also be
            multiple trans types. eg. LoanAppRs,LoanAppRq. If this is the case
            then assume that the first trans type is the Controller class to be used.
            */


            BaseController controller=null;

            String className=s_transaction;

            if (className.indexOf(',')>0) {
              // multiple trans types so use first
              className=className.substring(0,className.indexOf(','));

            }

            try {
            controller = (BaseController)Class.forName(className).newInstance();
            }
            catch (Exception e) {
                controller=null;
                //log_obj.FmtAndLogMsg("Controller class: "+className+".class not found, error="+e.toString());
            } // Controller Class not found

            if (controller==null) {

                controller = new DefaultController();

                className="DefaultController";

            }



            log_obj.FmtAndLogMsg("Controller class: "+className+".class loaded",i_dbg_level,5);




            //  I N I T I A L I Z E      C O N T R O L L E R


            controller.initialize(con,s_transaction,stylesheet,send_vars,
                                  l_request_id,s_key,
                                  log_obj,i_dbg_level,
                                  genx,s_evaluate_url,ini);

            //   P R O C E S S    X M L

            controller.runController();


            // SUCCESS
        }
        catch(Exception e){
            throw new Exception("Error processing job:"+s_key+" error = "+e.toString());
        }

        log_obj.FmtAndLogMsg("SEND_XML for RID: "+sRID+" DONE",i_dbg_level,0);

        return;

    }  // end sendXML()


    //////////////////////////////////////////////////////////////////////////////////////

    public void SendDecision (LogMsg log_obj, long l_request_id, String s_additional_data, String s_key, Connection con) throws Exception {
        String s_xml_dec="";
        String s_name;
        String s_value;
        StringTokenizer st_data = new StringTokenizer(s_additional_data,",");
        GlobalVars send_vars;

        //
        // throw an exception if a decision ref id or request_id was not passed in additional_data
        //
        if (s_additional_data.indexOf("DECISION_REF_ID,")<0) {
            throw new Exception("Exception DECISION_REF_ID not passed for send decision on request id "+l_request_id);
        }
        if (s_additional_data.indexOf("REQUEST_ID,")<0) {
            throw new Exception("Exception REQUEST_ID not passed for send decision on request id "+l_request_id);
        }

        send_vars = new GlobalVars(log_obj,i_dbg_level);


        try {
            //
            // Loop through the additional data names and values and set global variables
            //
            while (st_data.hasMoreTokens()) {
                s_name = st_data.nextToken();
                if (st_data.hasMoreTokens()) {
                    s_value = st_data.nextToken();
                    send_vars.SetVar(s_name,s_value);
                }
            }

            GrabXMLFields(l_request_id,send_vars,con,log_obj);
            //
            // manually set the default network that was pulled from the ini file
            //
            send_vars.SetVar("DEFAULT_NETWORK",s_default_network);
            genx.bSetAllParams(send_vars);

			//setting encryption parameters, so all this fields get decrypted when we send / perform operation on xml.
			genx.setEncryptionParms(schemaUser,"ssn,bank,trade,drivers");

            s_xml_dec = genx.sGetXMLorThrow("LoanAppRs");
            log_obj.FmtAndLogMsg("Decision XML Set to:"+s_xml_dec,i_dbg_level,5);

        }
        catch(Exception e){
            throw new Exception("Error: Building XML or XML parameters:"+e.toString());
        }

        //
        // now post it
        //
        try {
            PostIt(send_vars,log_obj,con, s_xml_dec,l_request_id,s_key);
        }
        catch(Exception e){
            throw new Exception("Caught exception during post:"+e.toString());
        }

        return;

    } // sendDecision()


    /* 156578 - glennl 1/19/12 - When an app is manually approved by an analyst the bel_select_on_appr_flg in
    the config_product_settings table will control if a call to evaluate is necessary to see if the app should be
    referred to a back end lender (see underwriting/act_savedecisionapprove.cfm, act_decpopups.cfm, default.cfm in uw). This is done as the very last step of the decisioning process since the calls to evaluate might conflict with other threads in origenate that are making calls while the app is being returned to the queue.  The call was moved to the end of the decision because it was sometimes bumping heads with other transactions.  (primarily autobooking).
    */

    public void sendToBEL(LogMsg log_obj, long l_request_id, String s_additional_data, String s_key, Connection con) throws Exception {

       Query query = new Query(con);
       GlobalVars send_vars = new GlobalVars(log_obj, i_dbg_level);
       String[] tokens = s_additional_data.split(",");

       for (int i = 0; i < tokens.length; i += 2) {
               send_vars.SetVar(tokens[i], tokens[i + 1]);
       }

       // addtional data should include the following variables
       String requestID = send_vars.sGetVarValue("REQUEST_ID");
       String evaluatorID = send_vars.sGetVarValue("EVALUATOR_ID");


       try {


             log_obj.FmtAndLogMsg("SEND_TO_BEL -  checking if we should foward to another backend lender for approval,  request_id:"+requestID);

             // we need to save off the current be lender evaluator ID so that after we call evaluate to see if a new one is assigned

             query.prepareStatement("select nvl(cr.backend_evaluator_id,0) be_evaluator_id from credit_request cr where cr.request_id = ? ");
             query.setInt(1,requestID);
             query.executePreparedQuery();
             String saved_be_evaluator_id="0";
             if (query.next()) {
                saved_be_evaluator_id=query.getColValue("be_evaluator_id","0");
             }


             // call evaluate to see if we need to send it to another lender. The call will set the backend_evaluator_id in the CR to the next
             // lender if any. If it changes then send it

             // use the eval_app_complete url and adjust it slightly to call a diff fuse
             // eval_app_complete_url = http://localhost:8300/origenate/evaluation/default.cfm?fuse_action=app_complete&request_id=
             // change it to:
             // eval_app_complete_url = http://localhost:8300/origenate/evaluation/default.cfm?fuse_action=send_app_to_be_lender&request_id=


             String ccURL = ini.getINIVar("urls.eval_app_complete_url","");


             if(ccURL.length() <= 0){
                throw new Exception("urls.eval_app_complete_url not defined in origenate.ini");
             }

             // strip off old fuse_action

             ccURL=ccURL.substring(0,ccURL.indexOf("fuse_action="));

             ccURL = ccURL + "fuse_action=select_next_be_lender&user_id=SYSTEM&request_id="+requestID+"&evaluator_id="+evaluatorID+ "&closeSession=true";

             try{
               PostRequest postRequest = new PostRequest(log_obj, i_dbg_level);
               postRequest.post(ccURL,"",60); // 60 sec timeout
             }
             catch (Exception e) {
                throw new Exception("Error in eValuate fuse=select_next_be_lender, error="+e.toString());
             }

             // CALL TO EVALUATE TO SELECT NEXT BEL SUCCEEDED, NOW SEE IF THE
             // BEL SELECTED HAS CHANGED AND IF SO REDIRECT THE APP


             // If the be evaluator has changed then we need to send it to the next BE lender

             query.prepareStatement("select nvl(cr.backend_evaluator_id,0) be_evaluator_id from credit_request cr where cr.request_id = ? ");
             query.setInt(1,requestID);
             query.executePreparedQuery();
             String next_be_evaluator_id="0";
             if (query.next()) {
                next_be_evaluator_id=query.getColValue("be_evaluator_id","0");
             }

             // next_be_evaluator_id="10"; // debug

             if (!saved_be_evaluator_id.equals(next_be_evaluator_id)) {

                log_obj.FmtAndLogMsg("INFO: Sending app to back-end-lender: "+next_be_evaluator_id+" request_id: "+requestID);

                // need to send this app back to another be lender

                // use the eval_app_complete url and adjust it slightly to call a diff fuse
                // eval_app_complete_url = http://localhost:8300/origenate/evaluation/default.cfm?fuse_action=app_complete&request_id=
                // change it to:
                // eval_app_complete_url = http://localhost:8300/origenate/evaluation/default.cfm?fuse_action=send_app_to_be_lender&request_id=


                  ccURL = ini.getINIVar("urls.eval_app_complete_url","");

                   // strip off old fuse_action

                   ccURL=ccURL.substring(0,ccURL.indexOf("fuse_action="));

                   ccURL = ccURL + "fuse_action=send_app_to_be_lender&user_id=SYSTEM&request_id="+requestID+"&evaluator_id="+evaluatorID+"&be_evaluator_id="+next_be_evaluator_id+"&calledby=RQP"+ "&closeSession=true";

                   try{
                     PostRequest postRequest = new PostRequest(log_obj, i_dbg_level);
                     postRequest.post(ccURL,"",60); // 60 sec timeout
                   }
                   catch (Exception e) {
                      throw new Exception("Error in eValuate fuse=send_app_to_be_lender, error="+e.toString());
                   }

                   log_obj.FmtAndLogMsg("INFO: processing complete - submitted app to next backend lender: "+next_be_evaluator_id);

             }  // end - be evaluator has changed
             else
               log_obj.FmtAndLogMsg("INFO: No more backend lenders found, NOT redirecting app, request_id:"+requestID);


       }
       catch (Exception e) {
              log_obj.FmtAndLogMsg("Error trying to redirect app to another back-end-lender,  request_id:"+requestID+" err="+e.toString());
              throw e;
          }

       return;

    } // sendToBEL()


    public void sendEmail(LogMsg log_obj, long l_request_id, String s_additional_data, String s_key, Connection con) throws Exception {
    	PreparedStatement ps1 = null, ps2 = null;
		ResultSet rs1 = null, rs2 = null;
		GlobalVars send_vars = new GlobalVars(log_obj, i_dbg_level);
		CommentEvents commentEventInst = new CommentEvents(con, log_obj);
		String s_sql, s_subject, s_email_to;
		String[] tokens = s_additional_data.split(",");

		for (int i = 0; i < tokens.length; i += 2) {
			send_vars.SetVar(tokens[i], tokens[i + 1]);
		}

		// addtional data should include the following variables
		String s_concurrence = send_vars.sGetVarValue("CONCURRENCE");
		String s_user_id = send_vars.sGetVarValue("USER_ID").toUpperCase();
		String s_webdocs_url = send_vars.sGetVarValue("WEBDOCS_URL");
		String s_email_from = send_vars.sGetVarValue("EMAIL_FROM");
		String s_host = send_vars.sGetVarValue("HOST");
		String s_email_type = send_vars.sGetVarValue("EMAIL_TYPE");
		int i_evaluator_id = Integer.parseInt(send_vars.sGetVarValue("EVALUATOR_ID"));
		int i_document_id = Integer.parseInt(send_vars.sGetVarValue("DOCUMENT_ID"));
		int i_product_id = Integer.parseInt(send_vars.sGetVarValue("PRODUCT_ID"));
		int i_decision_ref_id = Integer.parseInt(send_vars.sGetVarValue("DECISION_REF_ID"));
		int i_port = Integer.parseInt(send_vars.sGetVarValue("PORT"));

        // get subject
    	s_sql =
    		"SELECT	email_subject_txt " +
    		"FROM	config_eval_doc_email_subjects " +
    		"WHERE	evaluator_id = ? " +
    		"AND	category_id = ? " +
    		"AND	document_id = ?";

    	ps1 = con.prepareStatement(s_sql);
    	ps1.setInt(1, i_evaluator_id);
    	ps1.setString(2, OWASPSecurity.validationCheck(s_email_type.toUpperCase(),OWASPSecurity.SQLPARAMSTRING) + "_DECISION_EMAIL");
    	ps1.setInt(3, i_document_id);
    	ps1.execute();
    	rs1 = ps1.getResultSet();

    	if (rs1.next()) {
    		s_subject = rs1.getString("email_subject_txt");
    	} else {
    		s_subject = "";
    	}

    	rs1.close();
    	ps1.close();

		// get email entities
		s_sql =
			"SELECT	email_entity_type_id " +
			"FROM	config_product_dec_emails " +
			"WHERE	evaluator_id = ? " +
			"AND	product_id = ? " +
			"AND	decision_id = ( " +
			"	SELECT	decision_id " +
			"	FROM	credit_req_decisions_evaluator " +
			"	WHERE	decision_ref_id = ?) " +
			"AND	active_flg = 1 ";

		if (s_concurrence.compareToIgnoreCase("true") == 0) {
			s_sql = s_sql + "AND send_on_concurrence_flg = 1";
		} else if (s_concurrence.compareToIgnoreCase("never") == 0) {
			s_sql = s_sql + "AND send_on_concurrence_flg = 99";
		}

    	ps1 = con.prepareStatement(s_sql);
    	ps1.setInt(1, i_evaluator_id);
    	ps1.setInt(2, i_product_id);
    	ps1.setInt(3, i_decision_ref_id);
    	ps1.execute();
    	rs1 = ps1.getResultSet();

    	// send email to each email entity
    	while (rs1.next()) {
    		// get sql string to run
    		s_sql =
    			"SELECT 'SELECT ' || db_column_txt || ' AS email_address_txt FROM ' || db_table_txt || ' WHERE ' || where_clause_txt AS qry_txt " +
    			"FROM mstr_email_entity " +
    			"WHERE email_entity_type_id = ?";

    		ps2 = con.prepareStatement(s_sql);
    		ps2.setInt(1, rs1.getInt("email_entity_type_id"));
    		ps2.execute();
    		rs2 = ps2.getResultSet();

    		// if no sql to determine send-to email address skip to next email entity type
    		if (!rs2.next()) {
    			rs2.close();
    			ps2.close();
    			log_obj.FmtAndLogMsg("SQL to determine send-to email address is not configured--Skipping to next e-mail entity.");
    			continue;
    		}

    		s_sql = rs2.getString(1);
    		rs2.close();
    		ps2.close();

			//store the order of tokens in ArrayList,r for request id ,e for evaluator id,u for user id
			String[] token = s_sql.split(" ");
			ArrayList<String> temp = new ArrayList<String>();
			for(int i = 0; i< token.length; i++) {
			if(token[i].trim().contains("[request_id]")) {
				temp.add("r");
				}
			if(token[i].trim().contains("[evaluator_id]")) {
			temp.add("e");
				}
			if(token[i].trim().contains("[user_id]")) {
				temp.add("u");
				}
			}

    		// replace all tokens with placeholder '?'
    		s_sql = s_sql.replaceAll("\\[request_id\\]", "?");
    		s_sql = s_sql.replaceAll("\\[evaluator_id\\]", "?");
    		s_sql = s_sql.replaceAll("\\[user_id\\]", "?");
            // TTP 324955 Security Remediation Fortify Scan
            try{
                ps2 = con.prepareStatement(SQLSecurity.basicSanitize(s_sql.toString()));
            } catch (SQLException se){
                log_obj.FmtAndLogMsg("Class " + this.getClass() + "; " + se.toString());
            }

			/**
            * OWASP TOP 10 2010 - A4 ACCESS CONTROL DATABASE
            * Changes to the below code to fix vulnerabilities
            **/
            for(int i = 0,j=1;i<temp.size(); i++,j++) {
                if(temp.get(i).equals("r")) {
                    ///OWASP Security TTP 324955 False Positive
                    ps2.setLong(j, l_request_id);

                } else if (temp.get(i).equals("e")) {
                    ps2.setInt(j, i_evaluator_id);
                } else if (temp.get(i).equals("u")) {
                    ps2.setString(j, OWASPSecurity.validationCheck(s_user_id,OWASPSecurity.SQLPARAMSTRING));
                    }
                }

    		// get the to address


    		ps2.execute();
    		rs2 = ps2.getResultSet();

    		// if no send-to email address skip to next email entity type
    		if (!rs2.next()) {
    			rs2.close();
    			ps2.close();
    			log_obj.FmtAndLogMsg("Send-to email address is not configured--Skipping to next e-mail entity.");
    			continue;
    		}

    		s_email_to = rs2.getString("email_address_txt");

    		if (s_email_to != null && s_email_to.length() > 0) {
    			String s_full_webdocs_url = s_webdocs_url + "?action=get&user_id=" + s_user_id + "&fax_number=&recipient=&comments=&request_id=" + l_request_id + "&evaluator_id=" + i_evaluator_id + "&document_id=" + i_document_id + "&num_fields=0";
    			long l_starttime, l_sendtime;

    			log_obj.FmtAndLogMsg("Start Send " + s_email_type + " Decision Email : full url- " + s_full_webdocs_url + ", emailTo-" + s_email_to + ", emailFrom-" + s_email_from + ", subject-" + s_subject + ", host-" + s_host + ", port-" + i_port);
    	 		l_starttime = System.currentTimeMillis();

    	 		try {
    	 			// send the email
	    			SendDocument.sendDocument(s_full_webdocs_url, s_email_to, s_email_from, s_subject, s_host, i_port);

	    			commentEventInst.addComment((int)l_request_id, 64, s_email_type + " Decision Email", "Email was sent", s_user_id, "", "");
	        		l_sendtime = System.currentTimeMillis() - l_starttime;
	        		log_obj.FmtAndLogMsg("End Send Email - Execution Time: " + l_sendtime + " ms");
    	 		}
    	 		catch (Exception e) {
    	 			// error while sending email
					commentEventInst.addComment((int)l_request_id, 64, s_email_type + " Decision Email ERROR", s_email_type + " Decision Email was not sent because of error: " + e.getMessage(), s_user_id, "", "");
					log_obj.FmtAndLogMsg(l_request_id + " " + s_email_type + " Decision Email was not sent because of error: " + e.getMessage());
        			throw new Exception("Error sending " + s_email_type + " decision email.  Make sure there is a valid FROM address, TO address, and SMTP Server - " + e.getMessage());
    	 		}
    	 		finally {
    	 			rs2.close();
    	 			ps2.close();
    	 		}
    		} else {
    			log_obj.FmtAndLogMsg("The email was not sent because there was no send-to e-mail address available.");
    			commentEventInst.addComment((int)l_request_id, 64, s_email_type + " Decision Email", "The email was not sent because there was no send-to e-mail address available.", s_user_id, "", "");
    		}
    	}

    	rs1.close();
    	ps1.close();
    } // sendEmail()

    public void sendApp (LogMsg log_obj, long l_request_id, String s_additional_data, String s_key, Connection con) throws Exception{

        String s_xml_dec="";
        String s_name;
        String s_value;

        StringTokenizer st_data = new StringTokenizer(s_additional_data,",");
        GlobalVars send_vars;

        //
        // throw an exception if a request_id was not passed in additional_data
        //
        if (s_additional_data.indexOf("REQUEST_ID,")<0) {
            throw new Exception("Exception REQUEST_ID not passed for send app on request id "+l_request_id);
        }

        send_vars = new GlobalVars(log_obj,i_dbg_level);

        try {
            //
            // Loop through the additional data names and values and set global variables
            //
            while (st_data.hasMoreTokens()) {
                s_name = st_data.nextToken();
                if (st_data.hasMoreTokens()) {
                    s_value = st_data.nextToken();
                    send_vars.SetVar(s_name,s_value);
                }
            }

            GrabXMLFields(l_request_id,send_vars,con,log_obj);
            //
            // manually set the default network that was pulled from the ini file
            //
            send_vars.SetVar("DEFAULT_NETWORK",s_default_network);
            genx.bSetAllParams(send_vars);

			//setting encryption parameters, so all this fields get decrypted when we send / perform operation on xml.
			genx.setEncryptionParms(schemaUser,"ssn,bank,trade,drivers");

            s_xml_dec = genx.sGetXMLorThrow("LoanAppRq");
            //System.out.println(s_xml_dec);
            log_obj.FmtAndLogMsg("Application XML Set to: "+s_xml_dec,i_dbg_level,5);

        }
        catch(Exception e){
            throw new Exception("Error: Building XML or XML parameters:"+e.toString());
        }

        //
        // now post it
        //
        try {
            PostIt(send_vars,log_obj,con, s_xml_dec,l_request_id,s_key);
        }
        catch(Exception e){
            throw new Exception("Caught exception during post:"+e.toString());
        }

        return;

    }  // end sendApp()



    public void callBureauXML (LogMsg log_obj, long l_request_id, String s_additional_data, String s_key, Connection con) throws Exception{

        String s_xml_dec="";
        String s_name;
        String s_value;

        StringTokenizer st_data = new StringTokenizer(s_additional_data,",");
        GlobalVars send_vars;

        //
        // throw an exception if a request_id was not passed in additional_data
        //
        if (s_additional_data.indexOf("REQUEST_ID,")<0) {
            throw new Exception("Exception REQUEST_ID not passed for send app on request id "+l_request_id);
        }

        send_vars = new GlobalVars(log_obj,i_dbg_level);

        try {
            //
            // Loop through the additional data names and values and set global variables
            //
            while (st_data.hasMoreTokens()) {
                s_name = st_data.nextToken();
                if (st_data.hasMoreTokens()) {
                    s_value = st_data.nextToken();
                    send_vars.SetVar(s_name,s_value);
                }
            }

            GrabXMLFields(l_request_id,send_vars,con,log_obj);
            //
            // manually set the default network that was pulled from the ini file
            //
            send_vars.SetVar("DEFAULT_NETWORK",s_default_network);
            genx.bSetAllParams(send_vars);

			//setting encryption parameters, so all this fields get decrypted when we send / perform operation on xml.
			genx.setEncryptionParms(schemaUser,"ssn,bank,trade,drivers");

            s_xml_dec = genx.sGetXMLorThrow("BureauAppRq,LoanAppRq");
            //System.out.println(s_xml_dec);
            log_obj.FmtAndLogMsg("Bureau request XML Set to: "+s_xml_dec,i_dbg_level,5);

        }
        catch(Exception e){
            throw new Exception("Error: Building XML or XML parameters:"+e.toString());
        }

        //
        // now post it
        //
        try {
            PostIt(send_vars,log_obj,con, s_xml_dec,l_request_id,s_key);
        }
        catch(Exception e){
            throw new Exception("Caught exception during post:"+e.toString());
        }

        return;

    }  // end callBureauXML()
    
    private void SetGlobalVars(String additionalData, GlobalVars send_vars) throws Exception {
    	Map<String, String> varsMap = getParamsFromAdditionalData(additionalData);
    	for(Map.Entry<String, String> var : varsMap.entrySet()) {
    		String value = var.getValue();
    		if(value != null) {
    			value = value.replace('|', ',');
    		}
    		send_vars.SetVar(var.getKey(), value);
    	}
    }

	//IMPORTANT: this method is a duplicate of a static method in source.ear.common.src.com.cmsinc.origenate.util.GlobalVars.java
    private void SetGlobalVars(StringTokenizer st_data, GlobalVars send_vars) throws Exception {
        String s_name;
        String s_value;
        while (st_data.hasMoreTokens()) {
            s_name = st_data.nextToken();
            if (st_data.hasMoreTokens()) {
                s_value = st_data.nextToken();
                if (s_value != null) {
                    try {
                        s_value = s_value.replace('|',',');
                    }
                    catch (Exception e) {
                        throw new Exception("Caught exception replacing pipe delimiter:"+e.toString());
                    }
                }
                send_vars.SetVar(s_name,s_value);
            }
        }

    }

    /////////////////////////////////////////////////////////////////////////////////////

	/**
	 * Looks for a url in the additional data string for posting a standard evaluate transaction to the URL provided.
	 *
	 * @param log_obj
	 * @param l_request_id
	 * @param s_additional_data
	 * @param s_key
	 * @param con
	 * @param i_timeout_sec
	 *
	 */
    public void evaluateScoring(LogMsg log_obj, long l_request_id, String s_additional_data, String s_key, Connection con, int i_timeout_sec) throws Exception{

        /*
        All we need to do is pull the CF_URL token and hit the CF page to do the work.
        If it responds with err_status=0 then it succeeded. If not then look for
        <err_message>...</err_message> to get the error message that should be thrown
        */

        StringTokenizer t = new StringTokenizer(s_additional_data,",");
        String token,lastToken="";
        String cf_url="";

        while (t.hasMoreTokens()) {
            token = t.nextToken();
            if (lastToken.equals("CF_URL")) {
               cf_url=token;
            }

            lastToken=token;
        } // while

        if (cf_url.length()==0)
            throw new Exception("CF_URL not specified in additional data");
        else
		    cf_url = cf_url + "&closeSession=true";
        //encode spaces
        cf_url = cf_url.replace(" ", "%20");
        String response="";
        String errmsg="";
        boolean errorOccurred=false;
        /*
        GL. For eValuate failover if we get an error on the first try then it means that the primary instance has gone down
        and the evaluatefacade has switched over to the secondary instance for subsequent calls. So, on the second try it should work. If it
        fails on the second try then there is probly only one instance or both are down.
        */
        /* GL. 10/1/09 No longer doing retries because it can cause hangs in evaluate under certain circumstances */
        for (int i = 0; i< 2; i++) {
              errorOccurred=false;
              try {
                 // GL 01/13/04 Need to time calls to eValuate
              log_obj.FmtAndLogMsg("Calling with request_id: "+l_request_id+" url="+cf_url,i_dbg_level,0);
              PostRequest postRequest = new PostRequest(log_obj,i_dbg_level);
              response=postRequest.post(cf_url,"",i_timeout_sec);// Get time out sec from INI file
              log_obj.FmtAndLogMsg("Calling with request_id: "+l_request_id+"...done",i_dbg_level,0);

              log_obj.FmtAndLogMsg("Response from '"+cf_url+"' was '"+response+"'",i_dbg_level,5);
              }
              catch (Exception e) {
                  errorOccurred=true;
                  errmsg="Error posting to:"+cf_url+"  "+e.toString();
              }


              if (!errorOccurred && response.indexOf("err_status=0")<0) {
                 // error processing page, err msg is in tag <err_message>..</err_message>
                 String err="Unknown";
                 if (response.indexOf("<err_message>")>=0) {
                     try {
                     err=response.substring(response.indexOf("<err_message>")+13);
                     err=err.substring(0,err.indexOf("</err_message>"));
                     }
                     catch (Exception e) {err="Unknown";}
                 }
                 errmsg=err;
                 errorOccurred=true;
              } // error returned from CF

              if (!errorOccurred) break; // success on first or second try


              /* GL. 10/1/09 No longer doing retries because it can cause hangs in evaluate under certain circumstances */
              if (errorOccurred) {
                 log_obj.FmtAndLogMsg("Error occurred on first try, request_id: "+l_request_id+", no longer retrying; just returning error, error was: "+errmsg,i_dbg_level,0);
                 break;
              }

              // errorOccurred, if its the first try then it will try again, if its the second then the loop will break normally

              if (i==0)  {
                 log_obj.FmtAndLogMsg("Error occurred on first try, request_id: "+l_request_id+", retrying after sleep time of 2 secs, error was: "+errmsg,i_dbg_level,0);
                 try {Thread.sleep(2000);} catch (Exception e) {}
              }
              else
                 log_obj.FmtAndLogMsg("Error occurred on second try, request_id: "+l_request_id+", giving up, error was: "+errmsg,i_dbg_level,0);
        } // for

        if (errorOccurred) throw new Exception(errmsg);


        // SUCCESS, CF PAGE CALLED WORKFLOW TO MOVE IT ON AND UNLOCKED THE APP

        return;

    }  // end evaluateScoring()


    ////////////////////////////////////////////////////////////////////////////////////


    public void buildXMLToDB (LogMsg log_obj, long l_request_id, String s_additional_data, String s_key, Connection con) throws Exception{

        String s_xml="";
        String s_transaction;

        GlobalVars send_vars;

        //
        // throw an exception if a request_id was not passed in additional_data
        //
        if (s_additional_data.indexOf("REQUEST_ID,")<0) {
            throw new Exception("Exception REQUEST_ID not passed for send app on request id "+l_request_id);
        }

        send_vars = new GlobalVars(log_obj,i_dbg_level);

        try {
            //
            // Loop through the additional data names and values and set global variables
            //
            SetGlobalVars(s_additional_data, send_vars);

            s_transaction = send_vars.sGetVarValue("TRANSACTION_TYPE");
            //
            // manually set the default network that was pulled from the ini file
            //
            send_vars.SetVar("DEFAULT_NETWORK",s_default_network);
            genx.bSetAllParams(send_vars);
            String stylesheet=send_vars.sGetVarValue("STYLESHEET");

			//setting encryption parameters, so all this fields get decrypted when we send / perform operation on xml.
			genx.setEncryptionParms(schemaUser,"ssn,bank,trade,drivers");

            // stylesheet will be null if one was not specified
            s_xml = genx.sGetXMLorThrow(s_transaction,stylesheet);

            //System.out.println(s_xml_dec);
            log_obj.FmtAndLogMsg("XML Set to: "+s_xml,i_dbg_level,5);

        }
        catch(Exception e){
            throw new Exception("Error: Building XML or XML parameters:"+e.toString());
        }
        //
        // now post it
        //
        try {
            SimpleXMLReceiver xml_rcv;

            try {
                xml_rcv = new SimpleXMLReceiver( con, log_obj,i_dbg_level);
                xml_rcv.setIniFile(ini); // to access inifile from DecisionEngine
            }
            catch (Exception e) {
                throw new Exception("Caught exception getting ini and/or xml_rcv object in BuildXMLToDB:"+e.toString());
            }
            //
            // Insert the xml
            //
            boolean b_good_xml = xml_rcv.bInsertXML("/IFX/*/*/Routing/attribute::Transaction",s_xml);
            if (b_good_xml==false) {
                //
                // a problem occured
                //
                throw new Exception("Unable to process xml to db in BuildXMLToDB");
            }

        }
        catch(Exception e){
            throw new Exception("Caught exception during BuildXMLToDB:"+e.toString());
        }

        return;

    }  // end


    private void GrabXMLFields(long l_request_id, GlobalVars send_vars, Connection con, LogMsg log_obj) throws Exception {
        String s_value;
        ResultSet rs=null;
        PreparedStatement stmt=null;
        Node nd;
        java.sql.Clob clob_value;

        try {
			String s_sql = "SELECT XML_TXT " +
							"FROM CREDIT_REQUEST_XML " +
							"WHERE REQUEST_ID = ? " +
							"AND TRANSACTION_TYPE_ID = 'LoanAppRq' ORDER BY received_dt DESC";

            stmt = con.prepareStatement(s_sql);

            /**
            * OWASP TOP 10 2010 - A4 ACCESS CONTROL DATABASE
            * Changes to the below code to fix vulnerabilities
            **/
            //OWASP Security False Positive TTP 324955
            stmt.setLong(1, l_request_id);

            DOMParser parser = new DOMParser();
            Document doc;
            Node nod_root;
            InputSource x;

            rs = stmt.executeQuery();

            //
            // go to first record
            //
            if (rs.next()) {

                try {
                    //
                    // get the value_txt clob, this will hold the XML
                    //
                    clob_value = (java.sql.Clob) rs.getObject("XML_TXT");

                    //
                    // parse the file using xerces
                    //
                    x = new InputSource(clob_value.getCharacterStream());
                }
                catch (Exception e) {
                    throw new Exception("Caught exception Grabbing XML clob: "+e.toString());
                }

                try {
                    parser.parse(x);
                    doc = parser.getDocument();
                    //
                    // get the root element
                    //
                    nod_root = doc.getDocumentElement();

                }
                catch (Exception e) {
                    throw new Exception("Caught exception Grabbing XML document's root element: "+e.toString());
                }


                if (nod_root== null) {
                    //
                    // we technically should not throw an exception here. But
                    // we are throwing this exception temporarily since promax apps
                    // are the only ones doing this, and we should always have xml
                    // for these apps.  This should be replaced with a warning message.
                    //
                    throw new Exception("App had no XML!");
                }
                else {
                    try {
                        //
                        // Check the document to see if there is a responseurl supplied.
                        // if there is then use it as the destination, otherwise; use the
                        // OriginationUrl
                        //
                        int ix;
                        int iy;
                        String[][] s_xml_vars = new String [][]{
                        {"DESTINATION","/IFX/CreditSvcRq/LoanAppSvcRq/Routing/From/IDs/ID[@Type='ResponseURL']/text()","/IFX/CreditSvcRq/LoanAppSvcRq/Routing/From/IDs/ID[@Type='OriginationURL']/text()"},
                        {"NETWORK","/IFX/CreditSvcRq/LoanAppSvcRq/Routing/From/IDs/ID[@Type='Network']/text()",null},
                        {"COL_DESTINATION","/IFX/CreditSvcRq/LoanAppSvcRq/Routing/From/IDs/ID[@Type='COLGateway']/text()",null}
                        };
                        final int I_XML_VARNAME = 0;
                        final int I_XML_VALUE_START = 1;
                        final int I_XML_VALUE_STOP = 2;

                        //
                        // loop through each var and don't do anything if it allready exists
                        // in the send_vars globals object.  If it does not exist in send_vars,
                        // then attempt to get it from the XML.  The array defines
                        // two places to get the value from the xml, try to get it from the first if
                        // that comes back with nothing then attempt to get it from the second location.
                        //
                        for (ix=0;ix<s_xml_vars.length;ix++) {
                            log_obj.FmtAndLogMsg("On Variable "+s_xml_vars[ix][I_XML_VARNAME],i_dbg_level,5);
                            if (send_vars.bVarExists(s_xml_vars[ix][I_XML_VARNAME]) == false) {
                                //
                                // variable did not already exist in send_vars global var
                                // so attempt to get it from the xml (there are 2 places
                                // to get it from the XML, so loop through them)
                                //
                                for (iy=I_XML_VALUE_START;iy<=I_XML_VALUE_STOP;iy++) {
                                    log_obj.FmtAndLogMsg("On Xpath["+iy+ "] "+s_xml_vars[ix][iy],i_dbg_level,5);
                                    if (s_xml_vars[ix][iy]!=null) {
                                        //
                                        // attempt to pull from xml if an xpath was
                                        // defined (xpath is not null)
                                        //
                                        s_value = null;
                                        nd = XPathAPI.selectSingleNode(nod_root,s_xml_vars[ix][iy]);
                                        if (nd != null) {
                                            s_value = nd.getNodeValue();
                                        }
                                        if (s_value==null) {
                                            s_value = "";
                                        }
                                        log_obj.FmtAndLogMsg("Value is "+s_value,i_dbg_level,5);
                                        send_vars.SetVar(s_xml_vars[ix][I_XML_VARNAME],s_value);
                                        if (s_value.length()>0) {
                                            //
                                            // if we found a value then break out
                                            // of iy loop
                                            //
                                            iy=I_XML_VALUE_STOP+1;
                                        }
                                    } // if
                                } // for
                            } // if
                        } // for
                    }
                    catch (Exception e) {
                        throw new Exception("Caught exception Grabbing XML fields: "+e.toString());
                    }
                }

            }  //if
        }
        catch (Exception e) {
            throw new Exception("Caught exception working with query: "+e.toString());
        }
        finally {
			try { if (rs != null) rs.close(); } catch (Exception e) { e.printStackTrace(); }
			try { if (stmt != null) stmt.close(); } catch (Exception e) { e.printStackTrace(); }
        }
    } // GrabXMLFields()

    private void PostIt(GlobalVars send_vars,LogMsg log_obj, Connection con,String s_xml, long l_request_id,String s_key) throws Exception {
        PostRequest postRequest = new PostRequest(log_obj,i_dbg_level);

        String response=null;
        boolean skipPost=false;

        log_obj.FmtAndLogMsg("Send Vars is:"+send_vars.toString());

        try{
            /* GL. If this is an email post for a decision timeout that
            has since received a decision then ignore the post and delete the
            timeout routing entry.
             */
            skipPost=decisionReceivedBeforeTimeout(send_vars,log_obj,con);

            if (skipPost)
            response="err_status=0";
            else {
			    /**  The reason ? is used instead of & is in the ADDITIONAL_DATA_TXT Column of ROUTING_QUEUE table for COL_DESTIONATION
				 *  the value for example is http://localhost/dev/origenate/postreceive/default.cfm
				 */
                response=postRequest.post(sGetCOLDestination(send_vars)+ "?closeSession=true",s_xml,60);
			}
            try{
                if (response.indexOf("err_status=0")>=0){

                    // GL. 11/02/01 Post an event if this is for a mobile device email

                    PostEventIfEmail.PostEventIfEmail(send_vars,log_obj,con,s_xml,i_dbg_level);

                }
                else{
                    log_obj.FmtAndLogMsg("Error during Application Post to: "+sGetCOLDestination(send_vars)+" resp:" + response);
                }
            }
            catch(Exception e){
                throw new Exception("Caught exception during delete from routing queue" + e.toString());
            }
        }
        catch(Exception e){
            throw new Exception("Caught exception during application post" + e.toString());
        }
    }

    private boolean decisionReceivedBeforeTimeout(GlobalVars send_vars,LogMsg log_obj, Connection con) throws Exception {

        /* GL. Check the global vars to see if this is a TIMEOUT response for a decision.
        If a decision has not been received within the timeout period then an email is sent to
        a mobile device. If this is one of those types of transactions, first see if a decision
        has actuall come in in which case we don't want to send a timeout email, so return
        true ( to skip the post).
         */

        boolean skipPost=false;

        String value=send_vars.sGetVarValue("TRANSACTION_TYPE");
        String request_id, decision_id;
        if (value==null) return(false);
        if (value.indexOf("EmailHeaderRs")<0) return(false);
        value=send_vars.sGetVarValue("PURPOSE"); if (value==null) return(false);
        if (value.indexOf("TIMEOUT")<0) return(false);
        request_id=send_vars.sGetVarValue("REQUEST_ID");
        decision_id=send_vars.sGetVarValue("DECISION_REF_ID");
        if (request_id==null || decision_id==null) return(false);



        ResultSet rs = null;
        String status=null;
		String s_sql =  "SELECT med.DECISION_TXT " +
            "FROM credit_req_decisions_evaluator d, mstr_evaluator_decision med " +
            "WHERE d.request_id = ? and d.decision_ref_id = ?" +
            " and d.decision_id = med.decision_id";
		PreparedStatement stmt = null;


        try {
            stmt = con.prepareStatement(s_sql);
			stmt.setInt(1, Integer.valueOf(request_id));
			stmt.setInt(2, Integer.valueOf(decision_id));
            rs = stmt.executeQuery();

            if (rs.next()) {
                status = rs.getString("DECISION_TXT");
                if (status!=null) {
                    status=status.trim().toUpperCase();
                    if (!status.equals("PENDING") && !status.equals("FAXED"))
                    skipPost=true;
                }
            }
        }
        catch (Exception e) {
            throw new Exception("Caught exception checking decision: "+e.toString());
        }
        finally {
			try { if (rs != null) rs.close(); } catch (Exception e) { e.printStackTrace(); }
			try { if (stmt != null) stmt.close(); } catch (Exception e) { e.printStackTrace(); }
        }
        return(skipPost);

    } // decisionReceivedBeforeTimeout()

    private String sGetCOLDestination(GlobalVars send_vars) {
        String s_url = send_vars.sGetVarValue("COL_DESTINATION");
        if (s_url.compareToIgnoreCase("EVALUATE_URL")==0) {
            s_url = s_evaluate_url;
        }
        return s_url;
    }


    //////////////////////////////////////////////////////////////////////////////////


    public void runMPE(LogMsg log_obj, long l_request_id, String s_additional_data, String s_key, Connection con) throws Exception{

        String s_name = "";
        String s_value = "";
        String mpe_type="";
        String mpe_id ="";
        String mpe_subtype="";
        String mpe_filenm="";
        String mpe_temp_dir = "";
        String mpe_output_dir = "";
        String mpe_xslt_dir = "";
		String ach_interface_id = "-1";
        int live_mpe_inter = -1;

				String sql = "";
				PreparedStatement ps = null;


        /* update the status of this job to show that it is in progress */
        if (s_additional_data.startsWith("MPE_STATUS,")) {
            s_additional_data="MPE_STATUS,In process...,"+s_additional_data.substring(s_additional_data.indexOf(",",11)+1);
        }
        else { // first time running this job so add the status keyword
            s_additional_data="MPE_STATUS,In process...,"+s_additional_data;
        }

		//For live interface check
        if (s_additional_data.indexOf("LIVE_INTERFACE,")>=0) //If live interface passed in means this is live mpe interface
             live_mpe_inter=1;

        //For live interface check for dir
       if  (live_mpe_inter == 1) {
         mpe_temp_dir = ini.getINIVar("mpe.temp_dir");
         mpe_output_dir = ini.getINIVar("mpe.output_dir");
         mpe_xslt_dir = ini.getINIVar("mpe.xslt_dir");

         s_additional_data="TEMPDIR,"+mpe_temp_dir+File.separator+","+s_additional_data ;
         s_additional_data="OUTPUTDIR,"+mpe_output_dir+File.separator+","+s_additional_data;
         s_additional_data="XSLTDIR,"+mpe_xslt_dir+File.separator+","+s_additional_data;
       }

      // log_obj.FmtAndLogMsg("run mpe - live " +live_mpe_inter );
       log_obj.FmtAndLogMsg("run mpe - add data " +s_additional_data );


        // 1/24/07 ChrisN CL140795 Replaced with SQL using bind variable for Triad performance enhancement
        //SQLUpdate.RunUpdateStatement(con,"UPDATE ROUTING_QUEUE SET ADDITIONAL_DATA_TXT = '"+s_additional_data+"' WHERE ROUTING_QUEUE_ID = " + s_key);
        try {
					sql = "UPDATE ROUTING_QUEUE SET ADDITIONAL_DATA_TXT = ? WHERE ROUTING_QUEUE_ID = ?";
					ps = con.prepareStatement(sql);

					/**
                    * OWASP TOP 10 2010 - A4 ACCESS CONTROL DATABASE
                    * Changes to the below code to fix vulnerabilities
                    * TTP 324955
                    **/
                    ps.setString(1, OWASPSecurity.validationCheck(s_additional_data, OWASPSecurity.SQLPARAMSTRING));
                    //OWASP Security False Positive
                    ps.setInt(2, Integer.parseInt(s_key));
                    ps.execute();
                    ps.close();
				}
				catch (Exception e) {
				}
				finally {
					try { if (ps != null) ps.close();} catch (Exception e1) {e1.printStackTrace();}
				}


        StringTokenizer st_data = new StringTokenizer(s_additional_data,",");
        GlobalVars gvars;


        gvars = new GlobalVars(log_obj,i_dbg_level);



        //
        // Loop through the additional data names and values and set global variables
        //
        while (st_data.hasMoreTokens()) {
            s_name = st_data.nextToken();
            if (st_data.hasMoreTokens()) {
                s_value = st_data.nextToken();
                gvars.SetVar(s_name,s_value);
            }
            //log_obj.FmtAndLogMsg("run mpe data : " +s_name + "," + s_value );
        }

        boolean applyStyleSheet=true;
        boolean rerun=gvars.sGetVarValue("RERUN").equals("yes");


        String mpe_log_file = ini.getINIVar("mpe.log_file");
        String mpe_debug_level = ini.getINIVar("mpe.debug_level");

        LogMsg mpe_log_obj = new LogMsg();
        mpe_log_obj.openLogFile(mpe_log_file);

        String response="";

        try {

        // get the mpe type
        int i = s_additional_data.indexOf("MPE_TYPE,");
        if (i>0) {
           mpe_type = s_additional_data.substring(i+9,s_additional_data.indexOf(",",i+9));
         } else {
           throw new Exception("MPE Type not specified");
        }



         i = s_additional_data.indexOf("MPE_ID,");
        if (i>0) {
          mpe_id = s_additional_data.substring(i+7,s_additional_data.indexOf(",",i+7));
        } else {
          throw new Exception("MPE ID not specified");
        }


         i = s_additional_data.indexOf("MPE_SUBTYPE_ID,");
        if (i>0) {
           mpe_subtype = s_additional_data.substring(i+15,s_additional_data.indexOf(",",i+15));
         }

        // get the ach interface id
        i = s_additional_data.indexOf("ACH_INTERFACE_ID,");
        if (i>0) {
           ach_interface_id = s_additional_data.substring(i+17,s_additional_data.indexOf(",",i+17));
         }


        i = s_additional_data.indexOf("FILE_NAME_TXT,");
        if (i>0) {
          if (live_mpe_inter == -1) {
          mpe_filenm = s_additional_data.substring(i+14);
          } else {
          mpe_filenm = s_additional_data.substring(i+14,s_additional_data.indexOf(",",i+14));
          }
        } else {
          throw new Exception("File Name not specified");
        }

        log_obj.FmtAndLogMsg("run mpe - add data eval id : " +gvars.sGetVarValue("EVALUATOR_ID") );

		log_obj.FmtAndLogMsg("In RQTools - runMPE- Encryption(true/false): " +encryption_flg+"  UserName: "+ schemaUser);
        Mpe mpe= new Mpe(con,mpe_log_obj,gvars.sGetVarValue("TEMPDIR"),gvars.sGetVarValue("OUTPUTDIR"),
                Integer.parseInt(mpe_debug_level),
            applyStyleSheet,gvars.sGetVarValue("XSLTDIR"),false,gvars.sGetVarValue("USER_ID"),s_key, encryption_flg, schemaUser); // true=batchMode
            // BATCH MODE WILL WRITE TO NORMAL LOG FILE

		if(mpe_type.equals("SST") && mpe_subtype.equals("PSH")) {
        	mpe.setini(ini);
        }

        //For live interface check for dir
        if  (live_mpe_inter == 1) {
            response=mpe.generateMpeFile(gvars.sGetVarValue("EVALUATOR_ID"),rerun,"","",mpe_type,mpe_id,mpe_subtype,mpe_filenm,ach_interface_id,""+l_request_id);
        } else {
           response=mpe.generateMpeFile(gvars.sGetVarValue("EVALUATOR_ID"),rerun,gvars.sGetVarValue("STARTDATE"),gvars.sGetVarValue("ENDDATE"),mpe_type,mpe_id,mpe_subtype,mpe_filenm,ach_interface_id);
        }

        }
        catch (Exception e) {
            response=e.toString();
            response=response.replace(',',' ');
            response=response.replace('\'',' ');
            s_additional_data="MPE_STATUS,Error="+response+","+s_additional_data.substring(s_additional_data.indexOf(",",11)+1);
            // 1/24/07 ChrisN CL140795 Replaced with SQL using bind variable for Triad performance enhancement
            //SQLUpdate.RunUpdateStatement(con,"UPDATE ROUTING_QUEUE SET ADDITIONAL_DATA_TXT = '"+s_additional_data+"' WHERE ROUTING_QUEUE_ID = " + s_key);
		        try {
							sql = "UPDATE ROUTING_QUEUE SET ADDITIONAL_DATA_TXT = ? WHERE ROUTING_QUEUE_ID = ?";
							ps = con.prepareStatement(sql);

							/**
							* OWASP TOP 10 2010 - A4 ACCESS CONTROL DATABASE
							* Changes to the below code to fix vulnerabilities
							**/
							/*ps.setString(1, s_additional_data);
							ps.setInt(2, Integer.parseInt(s_key));*/
							ps.setString(1, OWASPSecurity.validationCheck(s_additional_data,OWASPSecurity.SQLPARAMSTRING));
							ps.setInt(2, Integer.parseInt(s_key));//fortify false positive
							ps.execute();
							ps.close();
						}
						catch (Exception e1) {
						}
						finally {
							try { if (ps != null) ps.close();} catch (Exception e2) {e2.printStackTrace();}
						}

            throw new Exception("Caught exception running MPE: "+e.toString());
        }
        finally {
           mpe_log_obj.closeLogFile(); // we always need to close the log file
        }

        // success
        response=response.replace(',',' ');
        response=response.replace('\'',' ');

        s_additional_data="MPE_STATUS,"+response+","+s_additional_data.substring(s_additional_data.indexOf(",",11)+1);

        // 1/24/07 ChrisN CL140795 Replaced with SQL using bind variable for Triad performance enhancement
        //SQLUpdate.RunUpdateStatement(con,"UPDATE ROUTING_QUEUE SET ADDITIONAL_DATA_TXT = '"+s_additional_data+"' WHERE ROUTING_QUEUE_ID = " + s_key);
        try {
					sql = "UPDATE ROUTING_QUEUE SET ADDITIONAL_DATA_TXT = ? WHERE ROUTING_QUEUE_ID = ?";
					ps = con.prepareStatement(sql);

					/**
					* OWASP TOP 10 2010 - A4 ACCESS CONTROL DATABASE
					* Changes to the below code to fix vulnerabilities
					**/
					/*ps.setString(1, s_additional_data);
					ps.setInt(2, Integer.parseInt(s_key));*/
					ps.setString(1, OWASPSecurity.validationCheck(s_additional_data,OWASPSecurity.SQLPARAMSTRING));
					ps.setInt(2, Integer.parseInt(s_key));//fortify false positive

					ps.execute();
					ps.close();
				}
				catch (Exception e) {
				}
				finally {
					try { if (ps != null) ps.close();} catch (Exception e1) {e1.printStackTrace();}
				}

        return;

    }  // end runMPE()



    //////////////////////////////////////////////////////////////////////////////////

    public void genMPEDataForApp(LogMsg log_obj, long l_request_id, String s_additional_data, String s_key, Connection con) throws Exception{

        String request_id = Long.toString(l_request_id);
        String evaluator_id = "0";
        String product_id = "0";
        String mpe_type = "MPE";
        String payoff_id = "1";
        String mpe_id = "";
        String mpe_subtype = "";
        int live_mpe_inter = -1;
		String task_group = "";
		String startDate = "NONE";
		String endDate = "NONE";

        // get product_id and evaluator_id for this request_id

        Query queryTmp = new Query(con);

        queryTmp.prepareStatement("select evaluator_id, product_id, client_app_id from credit_request where request_id = ?");
        queryTmp.setInt(1,request_id);
        queryTmp.executePreparedQuery();
        if (queryTmp.next()){
           evaluator_id = queryTmp.getColValue("evaluator_id","0");
           product_id = queryTmp.getColValue("product_id","0");
        }

        // pull out mpe_id, mpe_subtype,mpe type and payoff id from additional data
        if (s_additional_data.indexOf("LIVE_INTERFACE,")>=0) //If live interface passed in means this is live mpe interface
             live_mpe_inter=1;




         if (s_additional_data.indexOf("MPE_ID,")>=0)
           mpe_id=s_additional_data.substring(s_additional_data.indexOf("MPE_ID,")+7,
                                                s_additional_data.indexOf(",",s_additional_data.indexOf("MPE_ID,")+7));
        else {
	       log_obj.FmtAndLogMsg("Error during MPE data generation : No MPE_ID defined.");
		   return;
	    }


       if (s_additional_data.indexOf("MPE_SUBTYPE_ID,")>=0)
            mpe_subtype=s_additional_data.substring(s_additional_data.indexOf("MPE_SUBTYPE_ID,")+15,
                                                 s_additional_data.indexOf(",",s_additional_data.indexOf("MPE_SUBTYPE_ID,")+15));



        if (s_additional_data.indexOf("MPE_TYPE,")>=0)
          mpe_type=s_additional_data.substring(s_additional_data.indexOf("MPE_TYPE,")+9,
                                                s_additional_data.indexOf(",",s_additional_data.indexOf("MPE_TYPE,")+9));

        // Use startDate and endDate for GL MPE fields
        if (s_additional_data.indexOf("OFFSET_FLG,")>=0) {
        	if(s_additional_data.indexOf(",",s_additional_data.indexOf("OFFSET_FLG,")+11) >= 0) {
        		startDate=s_additional_data.substring(s_additional_data.indexOf("OFFSET_FLG,")+11,
                             s_additional_data.indexOf(",",s_additional_data.indexOf("OFFSET_FLG,")+11));
        	} else {
        		startDate=s_additional_data.substring(s_additional_data.indexOf("OFFSET_FLG,")+11);
        	}
        }
        if (s_additional_data.indexOf("CHECK_VOID_FLG,")>=0) {
        	if(s_additional_data.indexOf(",",s_additional_data.indexOf("CHECK_VOID_FLG,")+15) >= 0) {
        		endDate=s_additional_data.substring(s_additional_data.indexOf("CHECK_VOID_FLG,")+15,
                           s_additional_data.indexOf(",",s_additional_data.indexOf("CHECK_VOID_FLG,")+15));
        	} else {
        		endDate=s_additional_data.substring(s_additional_data.indexOf("CHECK_VOID_FLG,")+15);
        	}
        }
		if (s_additional_data.indexOf("SEQ_NUM,")>=0) {
        	if(s_additional_data.indexOf(",",s_additional_data.indexOf("SEQ_NUM,")+8) >= 0) {
        		task_group=s_additional_data.substring(s_additional_data.indexOf("SEQ_NUM,")+8,
                           s_additional_data.indexOf(",",s_additional_data.indexOf("SEQ_NUM,")+8));
        	} else {
        		task_group=s_additional_data.substring(s_additional_data.indexOf("SEQ_NUM,")+8);
        	}
        }

        String user_id="SYSTEM";
        //Check for live interface
        if (live_mpe_inter == -1 ) {
	        if (s_additional_data.indexOf("PAYOFF_ID,")>=0) {
	        	if(s_additional_data.indexOf(",", s_additional_data.indexOf("PAYOFF_ID,")+10) >= 0) {
	        		payoff_id=s_additional_data.substring(s_additional_data.indexOf("PAYOFF_ID,")+10,
	        				s_additional_data.indexOf(",", s_additional_data.indexOf("PAYOFF_ID,")+10));
	        	} else {
	        		payoff_id=s_additional_data.substring(s_additional_data.indexOf("PAYOFF_ID,")+10);
	        	}
	        }
       } else {//For live interface
         if (s_additional_data.indexOf("PAYOFF_ID,")>=0)
           payoff_id=s_additional_data.substring(s_additional_data.indexOf("PAYOFF_ID,")+10,
                                           s_additional_data.indexOf(",",s_additional_data.indexOf("PAYOFF_ID,")+10));

         if (s_additional_data.indexOf("USER_ID,")>=0)
             user_id=s_additional_data.substring(s_additional_data.indexOf("USER_ID,")+8,
                                                   s_additional_data.indexOf(",",s_additional_data.indexOf("USER_ID,")+9));


       }


       queryTmp.prepareStatement("select evaluator_id, product_id, client_app_id from credit_request where request_id = ?");
       queryTmp.setInt(1,request_id);
       queryTmp.executePreparedQuery();
       if (queryTmp.next()){
          evaluator_id = queryTmp.getColValue("evaluator_id","0");
          product_id = queryTmp.getColValue("product_id","0");
       }


        boolean applyStyleSheet=true;

        String mpe_log_file = ini.getINIVar("mpe.log_file");
        String mpe_temp_dir = ini.getINIVar("mpe.temp_dir");
        mpe_temp_dir+=File.separator;
        String mpe_output_dir = ini.getINIVar("mpe.output_dir");
        mpe_output_dir+=File.separator;
        String mpe_xslt_dir = ini.getINIVar("mpe.xslt_dir");
        mpe_xslt_dir+=File.separator;
        String mpe_debug_level = ini.getINIVar("mpe.debug_level");


        LogMsg mpe_log_obj = new LogMsg();
        mpe_log_obj.openLogFile(mpe_log_file);
		log_obj.FmtAndLogMsg("In RQTools -  genMPEDataForApp- Encryption(true/false): " +encryption_flg+"  UserName: "+ schemaUser);
        Mpe mpe= new Mpe(con,
                         mpe_log_obj,
                         mpe_temp_dir,
                         mpe_output_dir,
                         Integer.parseInt(mpe_debug_level),
                         applyStyleSheet,
                         mpe_xslt_dir,
                         false, // batch mode
                         user_id, // user ID
                         s_key, encryption_flg, schemaUser);

		mpe.setini(ini);
        String response="";

        try {
        response=mpe.genMpeDataForApp(request_id,
                                      product_id,
                                      evaluator_id,
                                      false, // rerun
                                     startDate,  // start date
                                     endDate, // END DATE
                                     mpe_type,
                                     payoff_id,
                                     mpe_id ,
                                     mpe_subtype,
									 task_group
                                     ); // end date

			if(!response.equalsIgnoreCase("success")){
				throw new Exception("Error generating Mpe Data for App for mpe type: " + mpe_type + " request_id " + request_id + " error: " + response);
			}

        }
        catch (Exception e) {
           /*
           We always want to remove the RQP entry for this job even if it errors
           because the error msg is written to the credit_req_contr_mpe table.
           The only exception is if this rtn throws an unexpected error before the
           crcm row was created.

           */
            throw e;
        }
        finally {
           mpe_log_obj.closeLogFile(); // we always need to close the log file
        }


        log_obj.FmtAndLogMsg("getmpe - call runmpe " +s_additional_data  + ",live_mpe_inter" +live_mpe_inter );

        // For live interface generate mpe file
       if (live_mpe_inter == 1 ) {

           // GL. 3/31/10 CT152034  only write the file to disk if the output type is 'write to disk' (mpe_output_id == 1)
          queryTmp.prepareStatement("select mpe_output_id from config_mpe where evaluator_id = ? and mpe_id = ? and mpe_output_id = 1");
          queryTmp.setInt(1,evaluator_id);
          queryTmp.setInt(2,mpe_id);
          queryTmp.executePreparedQuery();
          if (queryTmp.next()){   // only write the file to disk if the output type is 'write to disk' (mpe_output_id == 1)
             runMPE(log_obj, l_request_id, s_additional_data,  s_key,  con);
          }




       }


        return;

    }  // end genMPEDataForApp()


    public void genExternalDoc(LogMsg log_obj, long l_request_id, String s_additional_data, Connection con) throws Exception {
    	String user_id = "SYSTEM";
    	String task_group = "";
    	String doc_set_id = "";
    	boolean updateActivityFlg = false;
    	boolean fax = false;
    	String faxNumber = "", faxRecipient = "", faxComment = "";

    	// Get the Doc Set ID
    	if(s_additional_data.indexOf("DOC_SET_ID,") >= 0) {
    		int idxStart = s_additional_data.indexOf("DOC_SET_ID,")+11;
    		int idxEnd = s_additional_data.indexOf(",", idxStart);
    		if(idxEnd >= 0) {
	    		doc_set_id = s_additional_data.substring(idxStart,idxEnd);
    		}
    		else {
    			doc_set_id = s_additional_data.substring(idxStart);
    		}
    	} else {
    		throw new Exception("Error during ExternalDoc gen: No DOC_SET_ID defined. Please check config.");
    	}

    	// Get the User ID
    	if(s_additional_data.indexOf("USER_ID,") >= 0) {
    		int idxStart = s_additional_data.indexOf("USER_ID,")+8;
    		int idxEnd = s_additional_data.indexOf(",", idxStart);
    		if(idxEnd >= 0) {
    			user_id = s_additional_data.substring(idxStart,idxEnd);
    		} else {
    			user_id = s_additional_data.substring(idxStart);
    		}
        }

    	// Determine whether or not to update the activity
        if(s_additional_data.indexOf("UPDATE_ACTIVITY,")>=0){
        	int idxStart = s_additional_data.indexOf("UPDATE_ACTIVITY,")+16;
        	int idxEnd = s_additional_data.indexOf(",", idxStart);
        	String boolStr = "";
        	if(idxEnd >= 0) {
        		boolStr = s_additional_data.substring(idxStart,idxEnd);
        	} else {
        		boolStr = s_additional_data.substring(idxStart);
        	}

        	if(boolStr.compareToIgnoreCase("t") >= 0){
        		updateActivityFlg = true;
        	}
        }

        // Get the task group (this just gets put into the XML so that it's available for the stylesheet)
        if(s_additional_data.indexOf("TASK_GROUP,")>=0){
        	int idxStart = s_additional_data.indexOf("TASK_GROUP,")+11;
        	int idxEnd = s_additional_data.indexOf(",", idxStart);
        	if(idxEnd >= 0) {
        		task_group = s_additional_data.substring(idxStart,idxEnd);
        	} else {
        		task_group = s_additional_data.substring(idxStart);
        	}
        }

        if(s_additional_data.indexOf("FAX,")>=0){
        	int idxStart = s_additional_data.indexOf("FAX,")+4;
        	int idxEnd = s_additional_data.indexOf(",", idxStart);
        	String boolStr = "";
        	if(idxEnd >= 0) {
        		boolStr = s_additional_data.substring(idxStart,idxEnd);
        	} else {
        		boolStr = s_additional_data.substring(idxStart);
        	}

        	if(boolStr.compareToIgnoreCase("t") >= 0) {
        		fax = true;
        	}
        }

        if(fax) {
        	if(s_additional_data.indexOf("FAX_NUMBER,")>=0){
            	int idxStart = s_additional_data.indexOf("FAX_NUMBER,")+11;
            	int idxEnd = s_additional_data.indexOf(",", idxStart);
            	if(idxEnd >= 0) {
            		faxNumber = s_additional_data.substring(idxStart,idxEnd);
            	} else {
            		faxNumber = s_additional_data.substring(idxStart);
            	}
            }

        	if(s_additional_data.indexOf("FAX_RECIPIENT,")>=0){
            	int idxStart = s_additional_data.indexOf("FAX_RECIPIENT,")+14;
            	int idxEnd = s_additional_data.indexOf(",", idxStart);
            	if(idxEnd >= 0) {
            		faxRecipient = s_additional_data.substring(idxStart,idxEnd);
            	} else {
            		faxRecipient = s_additional_data.substring(idxStart);
            	}
            }

        	if(s_additional_data.indexOf("FAX_COMMENT,")>=0){
            	int idxStart = s_additional_data.indexOf("FAX_COMMENT,")+12;
            	int idxEnd = s_additional_data.indexOf(",", idxStart);
            	if(idxEnd >= 0) {
            		faxComment = s_additional_data.substring(idxStart,idxEnd);
            	} else {
            		faxComment = s_additional_data.substring(idxStart);
            	}
            }

        	if(faxNumber.equals("") || faxRecipient.equals("")) {
        		throw new Exception("Error during ExternalDoc gen: Fax requested but required fields FAX_NUMBER and/or FAX_RECIPIENT are not provided");
        	}
        }

        // Call ExternalDoc to generate the doc
        ExternalDoc extDoc = null;
        ArrayList<String> seqNums = null;
        try {
	        extDoc = ExternalDocFactory.getExternalDoc(l_request_id, user_id,
	        		con, doc_set_id);
	        extDoc.setTaskGroup(task_group);
	        extDoc.setUpdateActivity(updateActivityFlg);
	        if(fax) {
	        	extDoc.setJobType("Fax");
	        }

			if(extDoc.getDocProvider().equals(ExternalDoc.SMARTDOCS)) {
	        	SmartDoc smartDoc = (SmartDoc) extDoc;
	        	seqNums = smartDoc.generateExternalDoc((List<String>)null);
	        } else {
	        	seqNums = new ArrayList<String>(1);
	        	seqNums.add(extDoc.generateExternalDoc());
	        }
        } catch (Exception e) {
        	throw e;
        }

        if(fax && extDoc != null && seqNums != null && seqNums.size() > 0) {
        	try {
        		for(String seqNum : seqNums) {
        			extDoc.faxGeneratedDoc(seqNum, faxNumber, faxRecipient, faxComment);
        		}
        	} catch(Exception e) {
        		throw new Exception("Exception faxing generated report: " + e.getMessage());
        	}
        }
   }


   /////////////////////////////////////////////////////////////////////////

   public void appTransfer(LogMsg log_obj, String s_additional_data, String s_key, Connection con) throws Exception{

     String att_exe_path = "";


     try{

       att_exe_path = ini.getINIVar("att.rwpath");
       //s_additional_data = att_exe_path+File.separator+s_additional_data ;
       //TEST
       //s_additional_data = "/opt/origenate/dv70/apps/att/ATT EXPORT USERNAME=eval_dv70 PASSWORD=eval_dv70 ARCHIVENAME=TRTEST1_10182005_19:03:08 EVALUATORNAME=37 APPNOFROM=1413 APPNOTHROUGH=1413 MAXNOAPPS= DATEFROM= DATETHROUGH= ANALYSTUSER= APPSTATUS= DECSTATUS= TASKID='' CONFIG=/opt/origenate/dv70/apps/att/ATT.ini";

       log_obj.FmtAndLogMsg("starting att");

       Runtime rt = Runtime.getRuntime();

       log_obj.FmtAndLogMsg("begin exec of att");


       StringTokenizer st_data = new StringTokenizer(s_additional_data," ");
       String s_name[] = new String[(st_data.countTokens())];
       String cmd = "";
       int i = 0;

       //Set array of name=value pairs
       while (st_data.hasMoreTokens()) {
          s_name[i] = st_data.nextToken();
          if(s_name[i].startsWith("PASSWORD")) {  //e.g PASSWORD=eval_dv70
			String pwd = s_name[i].substring(9);
			String encryptPwdFlg = "0";
			String encryptionUser = "0";
			//Pwd encryption - read origenate.ini for encrypt_password_flg and encryption user
			try {
				encryptPwdFlg = ini.getINIVar("encryption.encrypt_password_flg","0");
				encryptionUser = "origenate_"+ ini.getINIVar("database.user","");
				encryptionUser = encryptionUser.toLowerCase();
			} catch(Exception e) { e.printStackTrace(); }

			//we are not using the colencrypt.sDecrypt method because the pwd if not encrypted is just plain text
			// e.g from ini [att] section looks like this :
			// evuser=eval_dv85b
			// evpassword=eval_dv85b

			if(encryptPwdFlg.equals("1")) {
				if(pwd != null && !pwd.equals("")) {
					try {
						//Initializes Crypto object
						Crypto crypto = CryptoFactory.getCrypto();
						// Decrypts password
						pwd = crypto.decryptString(encryptionUser,"password",pwd);
					} catch (Exception ef) { System.out.println(" Exception occured while performing decryption: "+ef.toString()); }
				}
			}
			s_name[i] = "PASSWORD=" + pwd;
			//log_obj.FmtAndLogMsg("s_name[i] : " + s_name[i]);
		  }
          i++;
       }

       //Build command line for use in exec
       att_exe_path = ini.getINIVar("att.rwpath");
       cmd = att_exe_path+File.separator+"runATT.sh ";
       StringBuilder temp_builder = new StringBuilder(cmd);
       for(int j=1; j < s_name.length; j++){
          // To avoid Command Injection, need to scrub out all of the following:
		  // ; | || && < > >>
		  String strArg = s_name[j].replaceAll("[;|><]+", "").replace("&&", "");
          temp_builder.append(strArg + " ");
       }
       cmd = temp_builder.toString();

       /**
        * OWASP TOP 10 - 2010 A1 Command Injection
        * Changes to the below code to fix Vulnerabilites
        */

       //Fork unix process and run att
      // String args[] = {"/bin/sh","-c", cmd};

       final String firstArgument = "/bin/sh"; //false positive no need to encode
       final String secondArgument = "-c";//false positive no need to encode

       String args[] = {firstArgument,secondArgument, OWASPSecurity.validationCheck(cmd,OWASPSecurity.DIRANDFILE)};

       rt.exec(args);

       log_obj.FmtAndLogMsg("Command: " + cmd);
       log_obj.FmtAndLogMsg("end exec of att");

     }
     catch(Exception e){

       log_obj.FmtAndLogMsg("error executing att");

     }

     return;

   } // end appTransfer

   /////////////////////////////////////////////////////////////////////////

   public void regenLetters(LogMsg log_obj, String s_additional_data, String jobID, Connection con) throws Exception{


     try{

       //TEST
       //s_additional_data = "LETTER_TYPE,WELCOME_LETTER,OUTPUT_TYPE,1,START_DATE,12/14/2007,END_DATE,12/14/2007,EVALUATOR_ID,52"



       StringTokenizer st_data = new StringTokenizer(s_additional_data,",");
       String s_name[] = new String[(st_data.countTokens())];
       String s_value[] = new String[(st_data.countTokens())];

       int i = 0;

       //Set array of name=value pairs
       while (st_data.hasMoreTokens()) {
          s_name[i] = st_data.nextToken();
          s_value[i] = st_data.nextToken();
          i++;
       }

       /* Name value pair Index:

       0 - LETTER TYPE
       1 - OUTPUT TYPE
       2 - START DATE
       3 - END DATE
       4 - EVALUATOR ID

       */
       String letterType=s_value[0];
       String outputType=s_value[1];  // 1 - Printer, 2- Concatenated PDF file, 3 - ASP batch mode
//     String startDate=s_value[2];
//     String endDate=s_value[3];
       String evaluator_id=s_value[4];


       Query queryTmp = new Query(con);

       queryTmp.executeQuery("SELECT NEXT_JOB_ID.NEXTVAL AS next_job_id FROM DUAL");

       queryTmp.next();

       String batch_job_id=queryTmp.getColValue("next_job_id");

       log_obj.FmtAndLogMsg("LETTER_REGEN: Batch ID: "+batch_job_id+", Processing letter regen request for letter type: "+s_value[0]+", between "+s_value[2]+" and "+s_value[3]);

       Query query = new Query(con);


       /* Possible Letter type values and their associated submit_reason_id in the doc history table

       6 - COUNTER_OFFER_LETTER
       5 - DECLINE_LETTER
       8 - EXPIRED_OFFER_LETTER
       9 - FIRST_PAYMENT_LETTER
       7 - WELCOME_LETTER
       18 - WITHDRAW_LETTER
       */

       String reason="";
       if (letterType.equals("COUNTER_OFFER_LETTER")) reason="6";
       if (letterType.equals("DECLINE_LETTER")) reason="5";
       if (letterType.equals("EXPIRED_OFFER_LETTER")) reason="8";
       // not supported yet     if (letterType.equals("FIRST_PAYMENT_LETTER")) reason="9";
       if (letterType.equals("WELCOME_LETTER")) reason="7";
       if (letterType.equals("WITHDRAW_LETTER")) reason="18";

       if (reason.length()==0) throw new Exception("Unsupported letter type request: "+letterType);

       /* Find all letters that were previously printed for a given letter type by seraching the doc history table */

       // don't want duplicate requests within the same time period
       // also making sure batch job id is not null because we only want to select docs that were printed with the nightly letters-printfax_processor, not textletters pgm, textletters will set this value to null

       String select="select distinct request_id, document_id,job_name_txt from credit_req_doc_history where evaluator_id = ? and submit_reason_id = ? and print_date >= to_date(?,'MM/DD/YYYY') and print_date <= to_date(? ,'MM/DD/YYYY-HH24:MI:SS') and batch_job_id is not NULL and job_type_txt != 'TEXTLETTERS' order by request_id, document_id";
       //TTP 324955 Security Remediation Fortify Scan
       query.prepareStatement(select);
       query.setInt(1,evaluator_id);   // evaluator
       query.setInt(2,reason);
       query.setString(3, s_value[2]);
       query.setString(4, s_value[3] + "-23:59:59");
       query.executePreparedQuery();
       log_obj.FmtAndLogMsg("LETTER_REGEN: Query returned "+query.getRowCount()+" rows, evaluator = "+evaluator_id+", reason_id = "+reason+", query = "+select);

       // for each document found put an entry on the printfax queue to regen the letter only if the app is still in the desired state

       String request_id="";
       String document_id="";
       String last_request_id="";
       String last_document_id="";
       String client_app_id="";
       String decision_status_id="";
       String booking_status_id="";
       String app_status_id="";
       String job_name_txt="";

       int checkedcount=0;
       int printedcount=0;
       boolean passed;

       while (query.next()){

                request_id = query.getColValue("request_id","0");
                document_id = query.getColValue("document_id","0");

                if (request_id.equals(last_request_id) && document_id.equals(last_document_id)) {
                     log_obj.FmtAndLogMsg("LETTER_REGEN: "+letterType+", Duplicate request IGNORED for app: "+client_app_id+", RID: "+request_id+", doc ID: "+document_id,i_dbg_level,0);
                     continue; // already submitted
                }
                last_request_id = request_id;
                last_document_id = document_id;


                job_name_txt = query.getColValue("job_name_txt","DEFAULT");


                queryTmp.prepareStatement("select client_app_id, decision_status_id,app_status_id,booking_status_id from credit_request where request_id = ? ");
                queryTmp.setInt(1,request_id);
                queryTmp.executePreparedQuery();
                queryTmp.next();
                client_app_id = queryTmp.getColValue("client_app_id","0");
                decision_status_id = queryTmp.getColValue("decision_status_id","0");
                booking_status_id = queryTmp.getColValue("booking_status_id","0");
                app_status_id = queryTmp.getColValue("app_status_id","0");
                checkedcount++;

                // now see if the app is still in the desired state

                passed=false;

                if (letterType.equals("DECLINE_LETTER")) {  // must still be declined
                   if (decision_status_id.equals("2") || decision_status_id.equals("103")) // decline or decscor
                      passed=true;
                }
                if (letterType.equals("COUNTER_OFFER_LETTER")) {  // must still be appcond
                   if (decision_status_id.equals("1"))
                      passed=true;
                }
                if (letterType.equals("EXPIRED_OFFER_LETTER")) {  // must still be expired
                   if (app_status_id.equals("20"))
                      passed=true;
                }
                if (letterType.equals("WELCOME_LETTER")) {  // must still be approved, appcond, or appscr and booked or bookedex
                   if ( (decision_status_id.equals("3") || decision_status_id.equals("102") || decision_status_id.equals("1")) &&
                        (booking_status_id.equals("2") || booking_status_id.equals("3"))
                      )
                      passed=true;
                }
                if (letterType.equals("WITHDRAW_LETTER")) {  // must still be WITHDRAWN
                   if (app_status_id.equals("19"))
                      passed=true;
                }


                if (!passed)
                   log_obj.FmtAndLogMsg("LETTER_REGEN: "+letterType+", resubmitting request for app: "+client_app_id+", RID: "+request_id+", doc ID: "+document_id+", IGNORED because app is no longer in the state for this letter type, decision state: "+decision_status_id ,i_dbg_level,0);
                else {

                   log_obj.FmtAndLogMsg("LETTER_REGEN: "+letterType+", resubmitting request for app: "+client_app_id+", RID: "+request_id+", doc ID: "+document_id ,i_dbg_level,0);

                   printedcount++;

                   // put an entry on the printfax queue to regen this letter

                   // insert a job into the printfax_queue to print this document

                    queryTmp.executeQuery("SELECT NEXT_JOB_ID.NEXTVAL AS next_job_id FROM DUAL");

                    queryTmp.next();

                    String next_job_id=queryTmp.getColValue("next_job_id");



                    // if we are running in ASP mode then docs are retrieved via a browser
                    // for printing, if we are running in LOCAL mode then we are printing
                    // docs via the RightFax Print server

                    String job_type_txt="Print";
                    if (outputType.equals("3")) job_type_txt="ASP";

                    String batchConcatFlg="0";
                    //if (outputType.equals("2")) batchConcatFlg="1"; //output should be one file containing all PDFs
                    // gl. 8/11/09 no longer concating files because on large batches java runs out of memory
                    if (outputType.equals("2")) batchConcatFlg="0"; //output should be one file containing all PDFs

                    // job_name_txt: comment from nightly letter pgm.
                    // if the command line parm -pPrinterName was supplied then store it in job
                    // name txt only if we are in LOCAL mode
                    // USE WHAT WAS SET ON THE ORIG DOC HIST ROW

                    //TTP 324955 Security Remediation Fortify Scan
                    SQLUpdate sqlup = new SQLUpdate();
                    sqlup.SetPreparedUpdateStatement(con,
                    "INSERT INTO printfax_queue ("+
                      "JOB_ID,"+
                      "PRIORITY_NUM,"+
                      "JOB_TYPE_TXT,"+
                      "EVALUATOR_ID,"+
                      "STATUS_ID,"+
                      "CREATE_DT,"+
                      "WHEN_TO_PROCESS_DT,"+
                      "REQUEST_ID,"+
                      "DOCUMENT_ID,"+
                      "USER_ID,"+
                      "COPIES_NUM,"+
                      "CENTRAL_PRO_SERVER_ID,"+
                      "JOB_NAME_TXT,"+ // this is really the printer name now
                      "submit_reason_id,batch_job_id,batch_concat_flg ) values (? ,50,"+
                      "?,"+
                      "?, 'SUBMITTED', sysdate,"+
                      "sysdate,"+
                      "?"+
                      ",? ,'SYSTEM',1,'DEFAULT', ?, ?, ?, ?)");
                      sqlup.setInt(1, next_job_id);
                      sqlup.setString(2, job_type_txt);
                      sqlup.setInt(3, evaluator_id);
                      sqlup.setInt(4, request_id);
                      sqlup.setInt(5, document_id);
                      sqlup.setString(6, job_name_txt);
                      sqlup.setInt(7, reason);
                      sqlup.setInt(8, batch_job_id);
                      sqlup.setInt(9, batchConcatFlg);
                      // add a row to the credit_req_doc_history for this submission
                      sqlup.RunPreparedUpdateStatement();

                      sqlup.SetPreparedUpdateStatement(con,
                            "insert into credit_req_doc_history (request_id,evaluator_id,create_dt,document_id,"+
                        "job_type_txt,status_id,user_id,copies_num,job_id,central_pro_server_id,"+
                        "job_name_txt,submit_reason_id,batch_job_id) values ("+
                        "?, ?, sysdate,"+
                        "?, ?,'SUBMITTED','SYSTEM',1,"+
                        "?, 'DEFAULT', ?, ?, ?)");

                      sqlup.setInt(1, request_id);
                      sqlup.setInt(2, evaluator_id);
                      sqlup.setInt(3, document_id);
                      sqlup.setString(4, job_type_txt);
                      sqlup.setInt(5, next_job_id);
                      sqlup.setString(6, job_name_txt);
                      sqlup.setInt(7, reason);
                      sqlup.setInt(8, batch_job_id);
                      sqlup.RunPreparedUpdateStatement();

                      queryTmp.prepareStatement("select description_txt from config_documents where evaluator_id = ? and document_id= ?");
                      queryTmp.setInt(1,evaluator_id);
                      queryTmp.setInt(2,document_id);
                      queryTmp.executePreparedQuery();
                      queryTmp.next();
                      String docName = queryTmp.getColValue("description_txt","N/A");

                      int reqID = Integer.parseInt(request_id);
                      JournalEvents journal = new JournalEvents(con, null);
                      journal.addJournal(reqID, 86, "Letter regen request for: "+letterType+", "+docName+",  submitted", "SYSTEM"); // 86 - Letter regen

                } // resubmit print request

       } // for each letter previously generated

       log_obj.FmtAndLogMsg("LETTER_REGEN: DONE processing letter regen request for letter type: "+s_value[0]+", between "+s_value[2]+" and "+s_value[3]+", "+printedcount+" letters submitted for regeneration, "+(checkedcount-printedcount)+" requests rejected because app not in qualifying state");

     }
     catch(Exception e){

       throw new Exception("Error processing job:"+jobID+" LETTER_REGEN: ERROR running Letter Regen: "+e.toString());

     }

     return;

   } // end regenLetters
   
	public void deleteApp(LogMsg log_obj, String s_additional_data, String jobID, Connection con) throws Exception {
	   String requestId = "", transactionTypeId = "", tableName = "", userId = "";
	   
	   String[] parmNames = {"REQUEST_ID", "TRANSACTION_TYPE_ID", "TABLE_NAME", "USER_ID"};
	   Map<String, String> parms = getParamsFromAdditionalData(s_additional_data);
	   String missingParam = checkRequiredParams(parms, parmNames);
	   if(!missingParam.equals("")) {
		   log_obj.FmtAndLogMsg("Error during Delete App: No "+missingParam+" defined.");
    	   throw new Exception("Error during Delete App: No "+missingParam+" defined.");
	   }
	   
	   requestId = parms.get("REQUEST_ID");
	   transactionTypeId = parms.get("TRANSACTION_TYPE_ID");
	   tableName = parms.get("TABLE_NAME");
	   userId = parms.get("USER_ID");
	   
	   if(requestId.equals("")) {
		   log_obj.FmtAndLogMsg("Error during Delete App: REQUEST_ID is blank.");
    	   throw new Exception("Error during Delete App: REQUEST_ID is blank.");
	   } else if(transactionTypeId.equals("")) {
		   log_obj.FmtAndLogMsg("Error during Delete App: TRANSACTION_TYPE_ID is blank.");
    	   throw new Exception("Error during Delete App: TRANSACTION_TYPE_ID is blank.");
	   } else if(tableName.equals("")) {
		   log_obj.FmtAndLogMsg("Error during Delete App: TABLE_NAME is blank.");
    	   throw new Exception("Error during Delete App: TABLE_NAME is blank.");
	   } else if(userId.equals("")) {
		   log_obj.FmtAndLogMsg("Error during Delete App: USER_ID is blank.");
    	   throw new Exception("Error during Delete App: USER_ID is blank.");
	   }
	   
	   String clientAppId = "", evaluatorId = "";
	   
	   Query query = new Query(con);
	   query.prepareStatement("select client_app_id, evaluator_id from credit_request where request_id = ?");
	   query.setInt(1, requestId);
	   query.executePreparedQuery();
	   if(query.next()) {
		   clientAppId = query.getColValue("client_app_id", "");
		   evaluatorId = query.getColValue("evaluator_id", "");
	   }
	   
	   // Delete the app
	   CopyApp copyApp = new CopyApp(log_obj, con);
	   copyApp.delete(requestId, transactionTypeId, tableName, "");
	   
	   String eventId = "";
	   query.prepareStatement("select event_id_seq.nextval as event_id from dual");
	   query.executePreparedQuery();
	   if(query.next()) {
		   eventId = query.getColValue("event_id", "");
	   } else {
		   throw new Exception("Could not get Event ID to record Deleted App Event. Application was successfully deleted.");
	   }
	   
	   // Create record of event
	   SQLUpdate update = new SQLUpdate();
	   update.SetPreparedUpdateStatement(con, "insert into event(event_id, event_type_id, event_dt, evaluator_id, user_id, additional_desc_txt) "
	   		+ "values (?, 4, sysdate, ?, ?, ?)");
	   update.setString(1, eventId);
	   update.setInt(2, evaluatorId);
	   update.setString(3, userId);
	   update.setString(4, "Application " + clientAppId + " Deleted");
	   update.RunPreparedUpdateStatement();
	}

   public void ftpFile(LogMsg log_obj, String s_additional_data, String jobID, Connection con) throws Exception{
	   String mode="",binary="",fileLocation="",newFileName="",deleteFile="";
	   String hostName="",userName="",password = "",certPath="";
	   String cleanup="",cleanupDir="",cleanupDays="",cleanupFilter="";

	   // Get Parms from s_additional_data
	   String[] parmNames = {"MODE","BINARY","FILE_LOCATION","NEW_FILE_NAME","DELETE_FILE",
			   "HOST_NAME","USER_NAME","PASSWORD","CERT_PATH",
			   "CLEANUP","CLEANUP_DIR","CLEANUP_DAYS","CLEANUP_FILTER"};
	   Map<String, String> parms = getParamsFromAdditionalData(s_additional_data);
	   String missingParam = checkRequiredParams(parms, parmNames);
	   if(!missingParam.equals("")) {
		   log_obj.FmtAndLogMsg("Error during FTP File: No "+missingParam+" defined.");
    	   throw new Exception("Error during FTP File: No "+missingParam+" defined.");
	   }

	   mode = parms.get("MODE");
	   binary = parms.get("BINARY");
	   fileLocation = parms.get("FILE_LOCATION");
	   newFileName = parms.get("NEW_FILE_NAME");
	   deleteFile = parms.get("DELETE_FILE");
	   hostName = parms.get("HOST_NAME");
	   userName = parms.get("USER_NAME");
	   password = parms.get("PASSWORD");
	   certPath = parms.get("CERT_PATH");
	   cleanup = parms.get("CLEANUP");
	   cleanupDir = parms.get("CLEANUP_DIR");
	   cleanupDays = parms.get("CLEANUP_DAYS");
	   cleanupFilter = parms.get("CLEANUP_FILTER");
	   // End Get Parms

	   String newDirectory = "";
	   String fileName = fileLocation.substring(fileLocation.lastIndexOf(File.separator)+1);
	   if(!newFileName.equals("NONE") && !newFileName.equals("")) {
		   // Cover all file separator cases
		   if(newFileName.contains("/")) {
			   newDirectory = newFileName.substring(0, newFileName.lastIndexOf("/"));
			   newFileName = newFileName.substring(newFileName.lastIndexOf("/")+1);
		   } else if(newFileName.contains("\\")) {
			   newDirectory = newFileName.substring(0, newFileName.lastIndexOf("\\"));
			   newFileName = newFileName.substring(newFileName.lastIndexOf("\\")+1);
		   } else if(newFileName.contains(File.separator)) {
			   newDirectory = newFileName.substring(0, newFileName.lastIndexOf(File.separator));
			   newFileName = newFileName.substring(newFileName.lastIndexOf(File.separator)+1);
		   }
		   fileName = newFileName;
	   }

	   String port = "";
	   if(hostName.indexOf(":") != -1) {
		   port = hostName.substring(hostName.lastIndexOf(":")+1);
		   hostName = hostName.substring(0, hostName.lastIndexOf(":"));
		   try {
			   Integer.valueOf(port);
		   } catch (Exception e) {
			   log_obj.FmtAndLogMsg("Invalid port: "+port+". Using default port");
			   port = "";
		   }
	   }

	   FileInputStream fis;
	   try {
		   fis = new FileInputStream(OWASPSecurity.validationCheck(fileLocation,OWASPSecurity.DIRANDFILE));
	   } catch (FileNotFoundException e) {
		   throw new FileNotFoundException(fileLocation + " does not exist.");
	   }

	   try {
		   Crypto crypto = CryptoFactory.getCrypto();
		   String passwordDecrypted = password;
		   log_obj.FmtAndLogMsg("Encryption flag: " + encryption_flg);
		   // If encryption is on and we're actually going to be using
		   // the password, then decrypt it.
		   if(encryption_flg &&
				(mode.equalsIgnoreCase("FTP") ||
					(mode.equalsIgnoreCase("SFTP") && certPath.equals("NONE")))) {
			   try {
				   passwordDecrypted = crypto.decryptString("origenate", "password", password);
			   } catch (Exception e) {
				   throw new Exception("Error decrypting password for FTP: " + e.toString());
			   }
		   }

		   if(mode.equalsIgnoreCase("FTP")) {
			   port = port.equals("")?"21":port;
			   FTPClient client = null;
			   try {
				   client = new FTPClient();
				   client.connect(hostName, Integer.valueOf(port));
				   if(!client.login(userName, passwordDecrypted)) {
					   throw new Exception("Could not log in as user " + userName +
							   ". Password may be invalid.");
				   }
				   if(!client.setFileType((binary.equals("0")?FTP.ASCII_FILE_TYPE:FTP.BINARY_FILE_TYPE))) {
					   throw new Exception("Could not set the file transfer type.");
				   }
				   client.enterLocalPassiveMode();
				   if(!newDirectory.equals("")) {
					   if(!client.changeWorkingDirectory(newDirectory)) {
						   throw new Exception("COuld not set working directory to " +
								   newDirectory);
					   }
				   }
				   if(!client.storeFile(fileName, fis)) {
					   throw new Exception("Could not store file " + fileName +
							   " from " + fileLocation + ".");
				   }
				   log_obj.FmtAndLogMsg("Successfully transferred file " + fileName + " via FTP.");
			   } catch (Exception e) {
				   throw new Exception("Error during FTP: " + e.toString());
			   } finally {
				   try{client.disconnect();}catch(Exception e){}
			   }
		   } else if(mode.equalsIgnoreCase("SFTP")) {
			   Session session = null;
			   ChannelSftp schannel = null;
			   port = port.equals("")?"22":port;

			   try {
				   JSch jsch = new JSch();
				   if(!certPath.equals("NONE")) {
					   if(!(new File(OWASPSecurity.validationCheck(certPath,OWASPSecurity.DIRANDFILE)).exists())) {
						   throw new FileNotFoundException(certPath + " does not exist.");
					   }

					   jsch.addIdentity(certPath);
					   session = jsch.getSession(userName, hostName, Integer.valueOf(port));
				   } else {
					   session = jsch.getSession(userName, hostName, Integer.valueOf(port));
					   session.setPassword(passwordDecrypted);
				   }
				   session.setConfig("StrictHostKeyChecking", "no");
				   session.connect();
				   Channel channel = session.openChannel("sftp");
				   channel.connect();
				   schannel = (ChannelSftp) channel;
				   if(!newDirectory.equals("")) {
					   schannel.cd(newDirectory);
				   }
				   schannel.put(fis, fileName);
				   log_obj.FmtAndLogMsg("Successfully transferred file " + fileName + " via SFTP.");
			   } catch (Exception e) {
				   throw new Exception("Error during SFTP: " + e.toString());
			   } finally {
				   try {
					   schannel.exit();
					   session.disconnect();
				   }
				   catch (Exception e){}
			   }
		   } else {
			   throw new Exception("Invalid mode: " + mode);
		   }

		   if(deleteFile.equals("1")) {
			   File file = new File(OWASPSecurity.validationCheck(fileLocation,OWASPSecurity.DIRANDFILE));
			   if(!file.delete()) {
				   log_obj.FmtAndLogMsg("Unable to delete file after FTP: " + fileLocation);
			   }
		   }

		   if(cleanup.equals("1")) {
			   try {
				   cleanupFiles(cleanupDays, cleanupDir, cleanupFilter);
			   } catch (Exception e) {
				   throw new Exception("Error cleanup up files: " + e.toString());
			   }
		   }

		   if(parms.containsKey("CHECKPARTNER")) {
			   log_obj.FmtAndLogMsg("Calling CheckPartner update.");
			   updateCheckPartner(con, parms, log_obj);
			   log_obj.FmtAndLogMsg("DONE Calling CheckPartner update.");
		   }
	   } catch (Exception e) {
		   throw new Exception("FTP File Exception: " + e.toString());
	   } finally {
		   try {fis.close();}catch(Exception e){}
	   }
   }

   // This is a helper method for ftpFile. It is called if the CLEANUP parm is set to 1
   public void cleanupFiles(String cleanupDays, String localfile_path, final String nameFilter) throws Exception {

		int numOfDays = Integer.parseInt(cleanupDays);
		if (numOfDays >= 0) {
			// get list of all files in local dir
			File localDirFiles = new File(OWASPSecurity.validationCheck(localfile_path,OWASPSecurity.DIRANDFILE));
			String[] localFiles = localDirFiles.list();

			FilenameFilter filter = new FilenameFilter() {
		        public boolean accept(File localDirFiles, String name) {
		            return name.startsWith(nameFilter);
		        }
		    };
		    localFiles = localDirFiles.list(filter);


			for (int i = 0; i < localFiles.length; i++) {
				File backupFile = new File(localDirFiles.getAbsolutePath() + File.separator
						+ localFiles[i]);
				Date lastModified = new Date(backupFile.lastModified());
				GregorianCalendar gc = new GregorianCalendar();
				gc.add(Calendar.DATE, 0 - numOfDays);
				java.util.Date cleanupDate = gc.getTime();
				if (cleanupDate.after(lastModified)) {
					log_obj.FmtAndLogMsg("Deleted file " + localFiles[i] + ": "
							+ backupFile.delete());
				}
				backupFile = null;
			}
			localDirFiles = null;
		} else {
			log_obj.FmtAndLogMsg("Not deleting any files since cleanupDays = "
					+ cleanupDays);
		}
		log_obj.FmtAndLogMsg("Ended cleanup of files");
	}

    public void checkPartner(LogMsg log_obj, long requestId, String s_additional_data, String jobID, Connection con) throws Exception{
	    PreparedStatement pstmt = null;
	    ResultSet rs = null;
        try {
	       String mpeId="",mpeTypeId="",mpeSubtypeId="",payoffId="";
		   String ftpFileServer="",ftpUser="",ftpPassword="",ftpTypeId="";
		   String ftpPasswordFile="", mpeFileName="";
		   String userId = "", checkAction="";

		   // Get Parms from s_additional_data
		   String[] parmNames = {"MPE_ID","MPE_TYPE_ID","MPE_SUBTYPE_ID","PAYOFF_ID",
				   "FTP_FILE_SERVER_TXT", "FTP_USER_TXT", "FTP_PASSWORD_TXT", "FTP_TYPE_ID",
				   "FTP_PASSWORDKEY_PATH_TXT","MPE_FILE_NAME_TXT","USER_ID","CHECK_ACTION"};
		   Map<String, String> parms = getParamsFromAdditionalData(s_additional_data);
		   String missingParam = checkRequiredParams(parms, parmNames);
		   if(!missingParam.equals("")) {
			   log_obj.FmtAndLogMsg("Error during CheckPartner: No "+missingParam+" defined.");
			   throw new Exception("Error during CheckPartner: No "+missingParam+" defined.");
		   }

		   mpeId = parms.get("MPE_ID");
		   mpeTypeId = parms.get("MPE_TYPE_ID");
		   mpeSubtypeId = parms.get("MPE_SUBTYPE_ID");
		   payoffId = parms.get("PAYOFF_ID");
		   mpeFileName = parms.get("MPE_FILE_NAME_TXT");
		   ftpFileServer = parms.get("FTP_FILE_SERVER_TXT");
		   ftpUser = parms.get("FTP_USER_TXT");
		   ftpPassword = parms.get("FTP_PASSWORD_TXT");
		   ftpTypeId = parms.get("FTP_TYPE_ID");
		   ftpPasswordFile = parms.get("FTP_PASSWORDKEY_PATH_TXT");
		   userId = parms.get("USER_ID");
		   checkAction = parms.get("CHECK_ACTION");

		   String additionalDataForMpe = "MPE_ID," + mpeId;
		   additionalDataForMpe += ",MPE_SUBTYPE_ID," + mpeSubtypeId;
		   additionalDataForMpe += ",MPE_TYPE," + mpeTypeId;
		   additionalDataForMpe += ",PAYOFF_ID," + payoffId;

		   genMPEDataForApp(log_obj, requestId, additionalDataForMpe, jobID, con);
		   // Pwd Encryption -  If encryption is turned on the pwd stored in db is encrypted
		   /*if(encryption_flg) {
			   Crypto crypto = CryptoFactory.getCrypto();
			   ftpPassword = crypto.encryptString("origenate", "password", ftpPassword);
		   }*/

		   String mpeStatus = "", mpeError = "", seqNum = "";
		   Clob mpeClob = null;
		   String s_xml = "";
		   pstmt = con.prepareStatement("select status_txt, error_txt, mpe_data_clob, seq_num " +
		   		"from credit_request_payoff_mpe where request_id = ? " +
		   		"and payoff_id = ? " +
		   		"and seq_num = get_max_payoff_seq_num(request_id,payoff_id)");
		   /**
           * OWASP TOP 10 2010 - A4 ACCESS CONTROL DATABASE
           * Changes to the below code to fix vulnerabilities
           **/
           //OWASP Security TTP 324955 False Positive
           pstmt.setLong(1, requestId);

		   pstmt.setInt(2, Integer.parseInt(payoffId));
		   rs = pstmt.executeQuery();
		   if(rs.next()) {
			   mpeStatus = rs.getString("status_txt");
			   mpeError = rs.getString("error_txt");
			   seqNum = rs.getString("seq_num");
			   if(seqNum == null) seqNum = "1";
			   if(mpeStatus == null) mpeStatus = "";
			   if(mpeError == null) mpeError = "";
			   mpeClob = rs.getClob("mpe_data_clob");
			   if(mpeClob != null) {
				   s_xml = mpeClob.getSubString(1, (int)mpeClob.length());
			   }
		   } else {
			   throw new Exception("Error generating MPE: No Payoff MPE record found");
		   }
		   try{rs.close();}catch(Exception e){}
		   try{pstmt.close();}catch(Exception e){}

		   if(mpeStatus.equalsIgnoreCase("ERROR") || !mpeError.equals("")) {
			   throw new Exception("Error generating MPE: " + mpeError);
		   }

		   String originatorCode = "", checkNumber = "";
		   String clientAppId = "", evaluatorId = "", evaluatorName = "";
		   String dateStr = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new java.util.Date());
		   Query query = new Query(con);
		   query.prepareStatement("select cr.client_app_id, crc.originator_code_txt, crp.check_no_txt, " +
			"e.evaluator_name_txt, e.evaluator_id " +
			"from credit_request cr, credit_request_closing crc, credit_request_payoff crp, " +
			"evaluator e " +
			"where cr.request_id = ? " +
			"and cr.request_id = crc.request_id (+) " +
			"and cr.request_id = crp.request_id (+) " +
			"and crp.payoff_id (+) = ? " +
			"and cr.evaluator_id = e.evaluator_id");
		   query.setLong(1, requestId);
		   query.setInt(2, payoffId);
		   query.executePreparedQuery();
		   if(query.next()) {
			   clientAppId = query.getColValue("client_app_id", "");
			   evaluatorId = query.getColValue("evaluator_id", "");
			   evaluatorName = query.getColValue("evaluator_name_txt", "");
			   originatorCode = query.getColValue("originator_code_txt", "");
			   checkNumber = query.getColValue("check_no_txt", "");
			   if(originatorCode.length() > 3) {
				   originatorCode = originatorCode.substring(originatorCode.length() - 3);
			   }
		   }
		   String mpeOutDir = ini.getINIVar("mpe.output_dir");
		   Hashtable<String, String> vars = new Hashtable<String, String>();
		   vars.put("MPE_TYPE", mpeTypeId);
		   vars.put("MPE_OUT_DIR", mpeOutDir);
		   vars.put("CLOSING_BRANCH", originatorCode);
		   vars.put("CHECK_NUMBER", checkNumber);
		   vars.put("CURRDATE", dateStr);
		   vars.put("CLIENT_APP_ID", clientAppId);
		   vars.put("EVALUATOR_ID", evaluatorId);
		   vars.put("EVALUATOR_NAME", evaluatorName);
		   String fileName = Mpe.parseFileName(mpeFileName, vars);
		   if(encryption_flg && !s_xml.equals("")) {
			   Crypto crypto = CryptoFactory.getCrypto();
			   s_xml = crypto.decryptString("origenate", "clob", s_xml);
		   }
		   //File file = new File(fileName);
		   //file.getParentFile().mkdirs();
		   PrintWriter outFile = new PrintWriter(
				   new BufferedWriter(new FileWriter(OWASPSecurity.validationCheck(fileName,OWASPSecurity.DIRANDFILE), false)));
		   outFile.print(s_xml);
		   outFile.close();

		   String additionalDataForFtp = "MODE," + (ftpTypeId.equals("0")?"FTP":"SFTP");
		   additionalDataForFtp += ",BINARY,1";
		   additionalDataForFtp += ",FILE_LOCATION," + fileName;
		   additionalDataForFtp += ",NEW_FILE_NAME,NONE";
		   additionalDataForFtp += ",DELETE_FILE,1";
		   additionalDataForFtp += ",HOST_NAME," + ftpFileServer;
		   additionalDataForFtp += ",USER_NAME," + ftpUser;
		   if(ftpTypeId.equals("0") ||
				   (!ftpTypeId.equals("0") && ftpPasswordFile.equals(""))) {
			   additionalDataForFtp += ",PASSWORD," + ftpPassword;
			   additionalDataForFtp += ",CERT_PATH,NONE";
		   } else {
			   additionalDataForFtp += ",PASSWORD,NONE";
			   additionalDataForFtp += ",CERT_PATH," + ftpPasswordFile;
		   }
		   additionalDataForFtp += ",CLEANUP,0,CLEANUP_DIR,NONE,CLEANUP_DAYS,NONE,CLEANUP_FILTER,NONE";
		   additionalDataForFtp += ",CHECKPARTNER,1,PAYOFF_ID,"+payoffId+",SEQ_NUM,"+seqNum+
		   ",USER_ID,"+userId+",CHECK_ACTION,"+checkAction+",REQUEST_ID,"+requestId+
		   ",JOB_ID,"+jobID+",EVALUATOR_ID,"+evaluatorId;

		   SQLUpdate update = new SQLUpdate();
		   update.SetPreparedUpdateStatement(con, "insert into routing_queue " +
					"(request_id, queue_priority_num, routing_state_id, " +
					"run_dt, tries_num, additional_data_txt, routing_queue_id, routing_state_subtype_txt) " +
					"values (?, 0, 35, sysdate, 0, ?, routing_queue_seq.nextval, ?)");
		   update.setLong(1, requestId);
		   update.setString(2, additionalDataForFtp);
		   update.setString(3, "From CheckPartner");
		   update.RunPreparedUpdateStatement();
	   } catch(Exception e) {
		   throw e;
	   } finally {
		   try{if(rs != null)rs.close();}catch(Exception e){}
		   try{if(pstmt != null)rs.close();}catch(Exception e){}
	   }
	}

    public void updateCheckPartner(Connection con,
    		Map<String, String> parms, LogMsg log) throws Exception {
    	String[] requiredParams = {"CHECKPARTNER","PAYOFF_ID",
    			"SEQ_NUM","USER_ID","CHECK_ACTION","REQUEST_ID",
    			"JOB_ID","EVALUATOR_ID"};
    	String missingParm = checkRequiredParams(parms, requiredParams);
    	if(!missingParm.equals("")) {
    		throw new Exception("Could not update CheckPartner history. Missing parameter " + missingParm);
    	}

    	String checkPartner = parms.get("CHECKPARTNER");
    	String payoffId = parms.get("PAYOFF_ID");
    	String seqNum = parms.get("SEQ_NUM");
    	String userId = parms.get("USER_ID");
    	String checkAction = parms.get("CHECK_ACTION");
    	String requestId = parms.get("REQUEST_ID");
    	String jobId = parms.get("JOB_ID");
    	String evaluatorId = parms.get("EVALUATOR_ID");

    	if(checkPartner.equals("1")) {
    		log.FmtAndLogMsg("Updating CheckPartner Payoff record");
	    	String sql = "update credit_request_payoff set ";
	    	if(checkAction.equalsIgnoreCase("generate")) {
	    		sql += "check_issued_dt = sysdate, " +
	    				"check_request_user_id = ? ";
	    	} else if(checkAction.equalsIgnoreCase("void")) {
	    		sql += "check_void_dt = sysdate, " +
	    				"check_void_user_id = ? ";
	    	}
	    	sql += "where request_id = ? " +
	    			"and payoff_id = ?";
	    	SQLUpdate update = new SQLUpdate();
	    	update.SetPreparedUpdateStatement(con, sql);
	    	update.setString(1, userId);
	    	update.setInt(2, requestId);
	    	update.setInt(3, payoffId);
	    	update.RunPreparedUpdateStatement();

	    	if(checkAction.equalsIgnoreCase("generate")) {
	    		sql = "update credit_request " +
	    				"set funding_dt = sysdate " +
	    				"where request_id = ?";
	    		update.SetPreparedUpdateStatement(con, sql);
	    		update.setInt(1, requestId);
	    		update.RunPreparedUpdateStatement();
	    	}

	    	sql = "update credit_request_payoff_mpe " +
	    			"set status_txt = ?, " +
	    			"moved_to_mpe_dt = sysdate " +
	    			"where request_id = ? " +
	    			"and payoff_id = ? " +
	    			"and seq_num = ?";
	    	update.SetPreparedUpdateStatement(con, sql);
	    	update.setString(1, "MOVED_TO_MPE_FILE");
	    	update.setInt(2, requestId);
	    	update.setInt(3, payoffId);
	    	update.setInt(4, seqNum);
	    	update.RunPreparedUpdateStatement();

	    	// Try to generate GL record(s) if configured
	    	generateGLRecordForCheck(requestId, payoffId, checkAction, jobId, evaluatorId, userId);
    	}
    }

    public void generateGLRecordForCheck(String requestId,
		String payoffId, String checkAction,
		String jobId, String evaluatorId,
		String userId) throws Exception {

    	String mpeId = Mpe.GetMpeId(con, evaluatorId, "GL");

		if(mpeId.equals("")) {
			log_obj.FmtAndLogMsg("INFO: No GL MPE configuration found for Request ID " + requestId +
					" for Payoff ID " + payoffId + ". No GL record will be recorded.");
			return;
		}

    	Map<String, String> mpeConfig = Mpe.GetMpeConfig(con, evaluatorId, mpeId, "GL");

    	if(Mpe.PassesWtu(con, log_obj, requestId, mpeConfig.get("WTU_BOOKING_QUERY_ID"), userId)) {
			String mpeSubtypeId = mpeConfig.get("MPE_SUBTYPE_ID");
			String mpeTypeId = mpeConfig.get("MPE_TYPE_ID");

			String paymentOptionId = "";
			Query query = new Query(con);
			query.prepareStatement("select get_payment_option_id(request_id, payoff_type_id) as payment_option_id from credit_request_payoff " +
					"where request_id = ? and payoff_id = ?");
			query.setInt(1, requestId);
			query.setInt(2, payoffId);
			query.executePreparedQuery();
			if(query.next()) {
				paymentOptionId = query.getColValue("payment_option_id", "-1");
			}

			boolean offsetAtBooking = false;
			String checkVoidDebitAcct = "", checkVoidDebitCostCenter = "";
			String checkVoidCreditAcct = "", checkVoidCreditCostCenter = "";
			query.prepareStatement("select " +
					"cpdd.ch_void_debit_a_txt, cpdd.ch_void_debit_cc_txt, " +
					"cpdd.ch_void_credit_a_txt, cpdd.ch_void_credit_cc_txt, " +
					"cpdd.offset_at_booking_flg " +
				"from credit_request_payoff crp, config_payoff_disburs_details cpdd, credit_request cr " +
				"where crp.request_id = ? " +
				"and crp.payoff_id = ? " +
				"and crp.request_id = cr.request_id " +
				"and crp.evaluator_id = cpdd.evaluator_id " +
				"and cr.product_id = cpdd.product_id " +
				"and crp.payoff_type_id = cpdd.payoff_type_id " +
				"and crp.detail_fund_meth_id = cpdd.funding_method_id " +
				"and cpdd.payment_option_id " + (paymentOptionId.equals("")?"is null":"= ?"));
			query.setInt(1, requestId);
			query.setInt(2, payoffId);
			if(!paymentOptionId.equals("")) {
				query.setInt(3, paymentOptionId);
			}
			query.executePreparedQuery();
			if(query.next()) {
				offsetAtBooking = query.getColValue("offset_at_booking_flg", "0").equals("1");
				checkVoidDebitAcct = query.getColValue("ch_void_debit_a_txt", "");
				checkVoidDebitCostCenter = query.getColValue("ch_void_debit_cc_txt", "");
				checkVoidCreditAcct = query.getColValue("ch_void_credit_a_txt", "");
				checkVoidCreditCostCenter = query.getColValue("ch_void_credit_cc_txt", "");
			}

			String additionalDataForMpe = "MPE_ID," + mpeId;
			additionalDataForMpe += ",MPE_SUBTYPE_ID," + mpeSubtypeId;
			additionalDataForMpe += ",MPE_TYPE," + mpeTypeId;
			additionalDataForMpe += ",PAYOFF_ID," + payoffId;
			additionalDataForMpe += ",CHECK_VOID_FLG,"+(checkAction.equalsIgnoreCase("void")?"1":"0");
			additionalDataForMpe += ",OFFSET_FLG,"; // Offset flag value will be appended later

			if(checkAction.equalsIgnoreCase("generate")) { // If configured, create offset GL record
				if(offsetAtBooking) {
					genMPEDataForApp(log_obj, Long.parseLong(requestId), additionalDataForMpe+"1", jobId, con);
				}
			} else if(checkAction.equalsIgnoreCase("void")) { // Copy fields from config to payoff record
				SQLUpdate update = new SQLUpdate();
				update.SetPreparedUpdateStatement(con,
						"update credit_request_payoff set " +
						"ch_void_debit_a_txt   = ?, " +
						"ch_void_debit_cc_txt  = ?, " +
						"ch_void_credit_a_txt  = ?, " +
						"ch_void_credit_cc_txt = ? " +
						"where request_id = ? " +
						"and payoff_id = ?");
				int updateIdx = 1;
				update.setString(updateIdx++, checkVoidDebitAcct);
				update.setString(updateIdx++, checkVoidDebitCostCenter);
				update.setString(updateIdx++, checkVoidCreditAcct);
				update.setString(updateIdx++, checkVoidCreditCostCenter);
				update.setInt(updateIdx++, requestId);
				update.setInt(updateIdx++, payoffId);
				update.RunPreparedUpdateStatement();

				// If an offset record exists for this payoff, and it hasn't already
				// been moved to the file, then delete it.
				updateIdx = 1;
				update.SetPreparedUpdateStatement(con,
						"delete from credit_request_gl_mpe " +
						"where request_id = ? " +
						"and payoff_id = ? " +
						"and offset_flg = 1 " +
						"and status_txt = 'GENERATED' " +
						"and mpe_id = ?");
				update.setInt(updateIdx++, requestId);
				update.setInt(updateIdx++, payoffId);
				update.setInt(updateIdx++, mpeId);
				update.RunPreparedUpdateStatement();
			}

			// create GL record
			genMPEDataForApp(log_obj, Long.parseLong(requestId), additionalDataForMpe+"0", jobId, con);

    	} else {
    		log_obj.FmtAndLogMsg("INFO: GL MPE configuration found for Request ID " + requestId +
					" for Payoff ID " + payoffId + " did not pass WTU. No GL record will be recorded.");
    	}
    }

    public void generalLedger(LogMsg log_obj, long requestId, String s_additional_data, String jobID, Connection con) throws Exception{
		String[] parmNames = {"MPE_ID","MPE_TYPE","MPE_SUBTYPE_ID"};
		Map<String, String> parms = getParamsFromAdditionalData(s_additional_data);
		String missingParam = checkRequiredParams(parms, parmNames);
		if(!missingParam.equals("")) {
			log_obj.FmtAndLogMsg("Error during GeneralLedger: No "+missingParam+" defined.");
			throw new Exception("Error during GeneralLedger: No "+missingParam+" defined.");
		}

    	String additionalDataForMpe = "MPE_ID," + parms.get("MPE_ID") +
								",MPE_SUBTYPE_ID," + parms.get("MPE_SUBTYPE_ID") +
								",MPE_TYPE," + parms.get("MPE_TYPE") +
								",OFFSET_FLG,0" +
								",CHECK_VOID_FLG,0" +
								",PAYOFF_ID,"; // the payoff id will be filled in later

		// Select payoff records with funding method of General Ledger
    	String sql = "select payoff_id " +
    			"from credit_request_payoff " +
    			"where request_id = ? " +
    			"and detail_fund_meth_id = 3 " +
    			"order by payoff_id asc";
    	Query query = new Query(con);
    	query.prepareStatement(sql);
    	query.setLong(1, requestId);
    	query.executePreparedQuery();
    	while(query.next()) { // Generate MPE data for each GL payoff record
    		genMPEDataForApp(log_obj, requestId,
    				(additionalDataForMpe + query.getColValue("payoff_id", "")),
    				jobID, con);
    	}
    }

	/**
	 * Queries the HUD Housing Counselor Web Service for housing counselors near
	 * the current applicant address for the a requests and persists the results
	 * to the Origenate database.
	 */
	public void processHousingCounselors(LogMsg log_obj, long requestId,
			String s_additional_data, String jobID, Connection con, IniFile ini)
			throws Exception {

        String host = ini.getINIVar("database.host");
        String sid = ini.getINIVar("database.sid");
        String user = ini.getINIVar("database.user");
        String password = ini.getINIVar("database.password");
        String port = ini.getINIVar("database.port");
        String connection = "jdbc:oracle:thin:@" + host + ":" + port + ":" + sid;
        password = COLEncrypt.sDecrypt(password);
        ConnectionFactory.initializeWithDbInfo(connection,user,password);

		String[] parmNames = { "EVALUATOR_ID" };
		Map<String, String> parms = getParamsFromAdditionalData(s_additional_data);
		String missingParam = checkRequiredParams(parms, parmNames);
		if (!missingParam.equals("")) {
			log_obj.FmtAndLogMsg("Error during processHousingCounselors: No "
					+ missingParam + " defined.");
			throw new Exception("Error during processHousingCounselors: No "
					+ missingParam + " defined.");
		}

		int evaluatorId = Integer.valueOf(parms.get("EVALUATOR_ID"));
		HousingCounselorManager mgr = new HousingCounselorManager(con, log_obj);
		mgr.processHousingCounselors(evaluatorId, requestId);
	}

	//IMPORTANT: this method is a duplicate of a static method in source.ear.common.src.com.cmsinc.origenate.util.GlobalVars.java
    public Map<String, String> getParamsFromAdditionalData(String additionalData) {
    	if(additionalData == null) return null;
    	else if(additionalData.equals("")) return new HashMap<String,String>();

    	Map<String, String> params = new HashMap<String, String>();
		String[] paramList = additionalData.split(",");
		for(int i = 0; i < paramList.length; i = i + 2) {
			String key = paramList[i];
			String value = "";
			// if the last value is blank, it will not be in the array.
			// so check to make sure that getting (i+1) will not put
			// us past the end of the array.
			if((i + 1) < paramList.length) {
				value = paramList[i + 1];
			}
			params.put(key, value);
		}
		return params;
    }

    public String checkRequiredParams(Map<String, String> params, String[] requiredParams) {
    	for(int i = 0; i < requiredParams.length; i++) {
    		if(!params.containsKey(requiredParams[i])) {
    			return requiredParams[i];
    		}
    	}
    	return "";
    }
} //RQTools
