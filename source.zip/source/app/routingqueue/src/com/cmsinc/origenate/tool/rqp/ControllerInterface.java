package com.cmsinc.origenate.tool.rqp;

//import java.io.*;


/**
 * <pre>
 *
 * This interface is implemented by the Controller base class.
 *
 * </pre>
 *
 */
public interface ControllerInterface {


    public void runController() throws Exception;


} // ControllerInterface


