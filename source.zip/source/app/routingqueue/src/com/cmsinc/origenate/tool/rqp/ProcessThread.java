package com.cmsinc.origenate.tool.rqp;

/*
import java.io.*;
import java.awt.*;
import java.text.SimpleDateFormat;
import com.cmsinc.origenate.util.SQLUpdate;
import java.util.*;
import com.cmsinc.origenate.util.SQLUpdate;
import com.cmsinc.origenate.util.Query;
import com.cmsinc.origenate.xmldbt.Translator;
import com.cmsinc.origenate.xmldbt.ValidationException;
import com.cmsinc.origenate.xmldbt.RecordInsert;
import org.apache.xerces.parsers.DOMParser;
import org.w3c.dom.*;
import org.xml.sax.InputSource;
import org.apache.xalan.xslt.XSLTInputSource;
import org.apache.xalan.xslt.XSLTResultTarget;
import org.apache.xalan.xslt.XSLTProcessor;
import org.apache.xalan.xslt.XSLTResultTarget;
import org.apache.xalan.xslt.StylesheetSpec;
import org.apache.xerces.dom.DocumentImpl;
import com.cmsinc.origenate.util.XPathAPI;
import java.io.*;
import java.net.*;
import oracle.jdbc.OracleResultSet;
import com.cmsinc.origenate.util.SQLUpdate;
import java.util.Vector;
import com.cmsinc.origenate.util.PostRequest;
import com.cmsinc.origenate.util.COLEncrypt;
*/

import java.sql.*;
import java.util.Calendar;
import com.cmsinc.origenate.util.IniFile;
import com.cmsinc.origenate.util.LogMsg;

/**
 *
 *
 */
public class ProcessThread extends Thread  {


    // INSTANCE VARIABLES

    //BaseController controller=null;
    int threadID=0;
    RoutingQueueProcessor main;
    boolean busy=false;
    IniFile ini= null;
    boolean workToDo=false;
    Connection con=null;
    boolean endThread=false;
    int i_dbg_level=0;
    RQTools rqt;
    CheckTranTimeout checkEvalTimeout=null;

    // set by main before waking up thread to do work
    String jobID;
    String requestID;
    String routingStateID;
    String additionalData;
    String routingState;

    LogMsg log_obj = null;
    String s_default_network="";
    String s_evaluate_url="";
    boolean errorOccurred=false; // set to true if this thread is disabled because
                                 // of an unrecoverable error. Can't just let thread
                                 // end because main will reference a thread that
                                 // doesn't exist
    String errorMessage="";

    String sConStr,sUser,sPass;
	boolean encryption_flg = false;
    int i_timeout_sec;

    // CONSTRUCTOR

    public ProcessThread(RoutingQueueProcessor main,String sConStr,String sUser,String sPass, boolean encryption_flg,int ID,int i_dbg_level,
                         String s_default_network,String s_evaluate_url,IniFile ini, int i_timeout_sec) throws Exception {

       threadID=ID;
       this.main=main;
       this.sConStr=sConStr;
       this.sUser=sUser;
	   this.sPass=sPass;
       this.encryption_flg = encryption_flg;
	   this.i_dbg_level=i_dbg_level;
       this.s_default_network=s_default_network;
       this.s_evaluate_url=s_evaluate_url;
       this.ini=ini;
       this.i_timeout_sec = i_timeout_sec;

       log_obj = new LogMsg();
       log_obj.setLogID("THREAD "+threadID+": ");

       // Connect to the Oracle database
       con = DriverManager.getConnection (sConStr,sUser,sPass);
       
       rqt = new RQTools(con,log_obj,i_dbg_level,s_default_network,s_evaluate_url,ini, sUser, encryption_flg);

       checkEvalTimeout = new CheckTranTimeout();

    } // end constructor


/////////////////////////////////////////////////////////////////////////////

    // RUN METHOD - execution continues in its own thread

    public void run() {

        errorOccurred=false;
        errorMessage="";

        log_obj.FmtAndLogMsg(" running...");

        while (!endThread) {

          if (!workToDo) {
              // sleep for 1/5 sec before checking if any are free
              try {Thread.sleep(200);} catch (Exception e) {}
              continue;
          }

          // wake up to process a job

          busy=true;
          workToDo=false;


          int tryCount=0;
          boolean tryAgain=true;

          // jobID set by main before setting workToDo to true

          while(tryAgain) {

             tryAgain=false;

             // try twice if a broken pipe occurred

             try {

                errorOccurred=false;

                long l_start_time = System.currentTimeMillis();
                log_obj.FmtAndLogMsg("JOB: "+jobID+" STARTED: "+routingStateID,i_dbg_level,5);
				log_obj.FmtAndLogMsg("JOB: "+jobID+" ADDITIONAL_DATA: "+additionalData,i_dbg_level,1);

                processJob();  // this is where all the work is done


                log_obj.FmtAndLogMsg("JOB: "+jobID+" ENDED: "+routingStateID+",  PROCESSING TIME:"+(System.currentTimeMillis()-l_start_time)+" ms",i_dbg_level,5);


                // reset error flag so this thread is free to process another job

                errorOccurred=false;

             }
             catch (Exception e) {

                 // serious error, disable thread if max retries reached

                 String tmp=e.toString();

                 // retry 5 times and then give up

                 if (tryCount < 5 && (tmp.indexOf("Broken pipe")>=0 ||
                                      tmp.indexOf("deadlock")>=0 ||
                                      tmp.indexOf("Connection timed out")>=0 ||
                                      tmp.indexOf("Closed Connection")>=0
                                      )) {

                     // re-establish the connection and try one more time
                     try {con.close();} catch (Exception e9) {}
                     log_obj.FmtAndLogMsg("Lost connection, re-establishing connection and retrying job");
                     try {Thread.sleep(1000);} catch (Exception et) {} // sleep a second to let condition clear
                     try {con = DriverManager.getConnection (sConStr,sUser,sPass);
                     }
                     catch (Exception e1) {con=null; }
                     if (con!=null) {

                       rqt = new RQTools(con,log_obj,i_dbg_level,s_default_network,s_evaluate_url,ini, sUser, encryption_flg);

                       tryAgain=true;
                       tryCount++;
                     }
                     else {
                         errorOccurred=true;
                         errorMessage="DISABLED, unrecoverable error: "+tmp;
                         log_obj.FmtAndLogMsg(errorMessage);
                     }
                 }
                 else {
                    // Disable this thread, can't continue
                    errorOccurred=true;
                    errorMessage="DISABLED, unrecoverable error: "+tmp;
                    log_obj.FmtAndLogMsg(errorMessage);
                 }


             } // catch


          } // while tryagain


          // finished with this job so reset flags and wait for more work to do

          // once the errorOccurred flag is set then this thread will not be given
          // any new work until the error has been examined by the caller. The caller
          // will then reset the busy flag after processing the error message.

          if (!errorOccurred) busy=false;


        } // while not end thread




        try {if (con != null) con.close();} catch (Exception e1) {e1.printStackTrace();}

        log_obj.FmtAndLogMsg(" ended gracefully");

        main.threadCount(true); // decrease thread count

      // fall thru to end thread

    } // end run()




    ///////////////////////////////////////////////////////////////////////////////////////


    private void processJob() throws Exception {


        long   l_requestID;
        boolean error=false;
		String sql = "";
		PreparedStatement ps = null;
        try {


         l_requestID=Long.parseLong(requestID);

         if (routingStateID.compareToIgnoreCase("Send_Decision")==0)
             rqt.SendDecision (log_obj, l_requestID,additionalData, jobID, con);
         else
         if (routingStateID.compareToIgnoreCase("Send_app")==0)
             rqt.sendApp (log_obj, l_requestID,additionalData, jobID, con);
         else
         if (routingStateID.compareToIgnoreCase("Send_XML")==0)
             rqt.sendXML (log_obj, l_requestID,additionalData, jobID, con);
         else
         if (routingStateID.compareToIgnoreCase("call_bureau_xml")==0)
             rqt.callBureauXML (log_obj, l_requestID,additionalData, jobID, con);
         else
         if (routingStateID.compareToIgnoreCase("build_xml_to_db")==0)
             rqt.buildXMLToDB (log_obj, l_requestID,additionalData, jobID, con);
         else
         if (routingStateID.compareToIgnoreCase("eval_scoring")==0 || routingStateID.compareToIgnoreCase("EVAL_FLUSH_APP") == 0)
             rqt.evaluateScoring(log_obj,l_requestID,additionalData,jobID, con, i_timeout_sec);
         else
         if (routingStateID.compareToIgnoreCase("mpe_data")==0)
            // gen mpe data for a single app when it is booked
             rqt.genMPEDataForApp(log_obj,l_requestID,additionalData,jobID,con);
         else
         if (routingStateID.compareToIgnoreCase("mpe_chk")==0)
            // gen mpe data for a single app when it is booked
             rqt.genMPEDataForApp(log_obj,l_requestID,additionalData,jobID,con);
         else
         if (routingStateID.compareToIgnoreCase("mpe_ach")==0)
            // gen mpe data for a single app when it is booked
             rqt.genMPEDataForApp(log_obj,l_requestID,additionalData,jobID,con);
         else
         if (routingStateID.compareToIgnoreCase("mpe_sst")==0)
            // gen mpe data for a single app when it is booked
             rqt.genMPEDataForApp(log_obj,l_requestID,additionalData,jobID,con);
         else
         if (routingStateID.compareToIgnoreCase("extdocs")==0)
            // gen external document for a single app
             rqt.genExternalDoc(log_obj,l_requestID,additionalData,con);
         else
         if (routingStateID.compareToIgnoreCase("mpe_gl")==0)
            // gen gl data for a single app when it is booked
             rqt.generalLedger(log_obj,l_requestID,additionalData,jobID,con);
         else
         if (routingStateID.compareToIgnoreCase("run_mpe")==0)
             // gen mpe file from previously processed mpe apps above
              rqt.runMPE(log_obj,l_requestID,additionalData,jobID,con);
         else
         if (routingStateID.compareToIgnoreCase("mpe_live")==0)
            // gen mpe file for live mpe inerface
            rqt.genMPEDataForApp(log_obj,l_requestID,additionalData,jobID,con);
         else
         if (routingStateID.compareToIgnoreCase("trans_timeout")==0)
             checkEvalTimeout.checkTranTimeOut (log_obj, i_dbg_level,l_requestID,additionalData, jobID, con);
         else
         if (routingStateID.compareToIgnoreCase("app_transfer")==0)
             rqt.appTransfer (log_obj, additionalData, jobID, con);
         else
         if (routingStateID.compareToIgnoreCase("SEND_EMAIL") == 0)
             rqt.sendEmail(log_obj, l_requestID, additionalData, jobID, con);
         else
         if (routingStateID.compareToIgnoreCase("letter_regen") == 0)
             rqt.regenLetters(log_obj,additionalData, jobID, con);
		 else
         if (routingStateID.compareToIgnoreCase("DOCEXTRACT") == 0)
             // gen mpe data for a single app when it is booked
             rqt.genMPEDataForApp(log_obj,l_requestID,additionalData,jobID,con);
         else
         if (routingStateID.compareToIgnoreCase("send_to_bel") == 0) // 156758 - send to BEL upon approval
             rqt.sendToBEL(log_obj,l_requestID,additionalData,jobID,con);
         else
         if (routingStateID.compareToIgnoreCase("FTP_FILE") == 0)
             rqt.ftpFile(log_obj, additionalData, jobID, con);
         else 
         if (routingStateID.compareToIgnoreCase("CHECK_PARTNER") == 0)
             rqt.checkPartner(log_obj, l_requestID, additionalData, jobID, con);
         else 
         if (routingStateID.compareToIgnoreCase("HOUSING_COUNSEL") == 0)
             rqt.processHousingCounselors(log_obj, l_requestID, additionalData, jobID, con, ini);
         else
             if (routingStateID.compareToIgnoreCase("DELETE_APP") == 0)
                 rqt.deleteApp(log_obj, additionalData, jobID, con);
         else
            throw new Exception("Unrecognized routing action specified (routing_state_id):"+routingStateID);

        }
         catch (Exception e) {
             error=true;
             log_obj.FmtAndLogMsg("ERROR PROCESSING JOB: "+jobID+" error=",e);
             
             String errorTxt=e.toString().replace('\'',' ');
             if (errorTxt.length()>1000) errorTxt=errorTxt.substring(0,1000);

             // 1/24/07 ChrisN CL140795 Replaced with SQL using bind variable for Triad performance enhancement
             //SQLUpdate.RunUpdateStatement(con,"UPDATE ROUTING_QUEUE " +
             //"SET ERROR_TXT = '"+errorTxt+"' "+
             //"WHERE ROUTING_QUEUE_ID = " + jobID);
                            try { 
								sql = "update ROUTING_QUEUE SET ERROR_TXT = ?, status_txt = 'ERROR' ";
								if(main.sRoutingStateInClause.length() > 0 && main.sMaxTriesList.length() > 0) {
									sql += ", run_dt = ? ";
								}
								sql+=" where ROUTING_QUEUE_ID = ?";
								ps = con.prepareStatement(sql);
								ps.setString(1, errorTxt);
								if(main.sRoutingStateInClause.length() > 0 && main.sMaxTriesList.length() > 0) {
									int i = 0;
									for(i = 0; i < main.routingStateList.size(); i++) {
										if(main.routingStateList.get(i).equals(routingState)) break;
									}
									PreparedStatement ps2 = null;
									ResultSet rs2 = null;
									Long timestamp = new java.util.Date().getTime();
									try {
										ps2 = con.prepareStatement("select sysdate from dual");
										rs2 = ps2.executeQuery();
										if(rs2.next()) {
											if(rs2.getTimestamp(1) != null) 
												timestamp = rs2.getTimestamp(1).getTime();
										}
									} catch (Exception ex) {
										log_obj.FmtAndLogMsg("Exception getting time from database. Using time on server.");
									} 
									finally {
										try { if (rs2 != null) rs2.close(); } catch (Exception ex) { ex.printStackTrace(); }
										try { if (ps2 != null) ps2.close(); } catch (Exception ex) { ex.printStackTrace(); }
									}
									Calendar c = Calendar.getInstance();
									c.setTimeInMillis(timestamp);
									log_obj.FmtAndLogMsg("Current Time: " + c.getTime());
									c.add(Calendar.SECOND, Integer.parseInt(main.waitTimeList.get(i)));
									log_obj.FmtAndLogMsg("Wait time (in seconds): " + main.waitTimeList.get(i));
									log_obj.FmtAndLogMsg("Retry Time: " + c.getTime());
									java.sql.Timestamp rerunTime = new java.sql.Timestamp(c.getTimeInMillis());
									ps.setTimestamp(2, rerunTime);
									
									/** OWASP Top 10 2010 - A4 Access Control Database
									  * Change to the below code to fix vulnerabilities
                                      * TTP 324955
									  */
									//fortify false positive
									ps.setInt(3, Integer.parseInt(jobID));
									
								} else {
									
									//ps.setInt(2, Integer.parseInt(jobID));
									ps.setInt(2, Integer.parseInt(jobID));
									
								}
								ps.execute();
								ps.close();
							} catch (Exception e1) {
								e1.printStackTrace();
							} finally {
								try{ if(ps != null) ps.close(); }catch(Exception e2){e2.printStackTrace();}
							}


         }

           //log_obj.FmtAndLogMsg("process complete " + routingStateID);
         // if success then delete job from routing queue

         try {
			if (!error) {
				 // 1/24/07 ChrisN CL140795 Replaced with SQL using bind variable for Triad performance enhancement
				 //SQLUpdate.RunUpdateStatement(con,"DELETE FROM ROUTING_QUEUE WHERE ROUTING_QUEUE_ID = " + jobID);
				 sql = "delete from ROUTING_QUEUE where ROUTING_QUEUE_ID = ?";
				 ps = con.prepareStatement(sql);

				 /** OWASP Top 10 2010 - A4 Access Control Database
				  * Change to the below code to fix vulnerabilities
				  * TTP 324955
				  */
				 //fortify false positive
				 ps.setInt(1, Integer.parseInt(jobID));

				 ps.execute();
				 ps.close();
			 }
        }
        catch (Exception e) {
        }
        finally {
           try { if (ps != null) ps.close(); } catch (Exception ex) { ex.printStackTrace(); }
        }
    } // processJob()





    ////////////////////////////////////////////////////////////////////////////////




    /**
     * Deletes a successful transaction from the posting_queue tables
     */
    /*
    private void deletePostingQueueJob(long jobID)  throws Exception {
				String sql = "";
				PreparedStatement ps = null;

        try {
            // 1/24/07 ChrisN CL140795 Replaced with SQL using bind variable for Triad performance enhancement
            //SQLUpdate.RunUpdateStatement(con,"DELETE POSTING_QUEUE WHERE TRANSACTION_ID = " + jobID );
            //SQLUpdate.RunUpdateStatement(con,"DELETE POSTING_QUEUE_HEADER WHERE TRANSACTION_ID = " + jobID );

						sql = "delete POSTING_QUEUE WHERE TRANSACTION_ID = ?";
						ps = con.prepareStatement(sql);
						ps.setLong(1, jobID);
						ps.execute();
						ps.close();

						sql = "delete POSTING_QUEUE_HEADER WHERE TRANSACTION_ID = ?";
						ps = con.prepareStatement(sql);
						ps.setLong(1, jobID);
						ps.execute();
						ps.close();
        }
        catch (java.sql.SQLException e) {
            throw new Exception("Caught Exception calling RunUpdateStatement in "+this.getClass()+":"+e.toString());
        }
				finally {
					try {ps.close(); } catch (Exception e1) {}
				}


        return;
    }
    */


} // ProcessThread


