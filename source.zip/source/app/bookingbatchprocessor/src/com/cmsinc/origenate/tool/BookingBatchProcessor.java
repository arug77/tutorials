package com.cmsinc.origenate.tool;

import org.apache.commons.io.FileUtils;
import java.io.*;
import java.util.*;

import com.cmsinc.origenate.booking.Booking;
import com.cmsinc.origenate.util.DBConnection;
import com.cmsinc.origenate.util.IniFile;
import com.cmsinc.origenate.util.LogMsg;
import com.cmsinc.origenate.workflow.ApplicationStatusManager;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import com.cmsinc.origenate.util.OWASPSecurity;

/**
 * @author miker
 *
 */

public class BookingBatchProcessor {

	private static LogMsg log = new LogMsg();
	
	private static File batchFile;
	private static List<String> list;
	
	private static final String REQUESTID 		= "request_id";
	private static final String EVALUATORID 	= "evaluator_id";
	private static final String BOOKSTATUSTYPE 	= "book_status_type";
	
	private static DateFormat df = DateFormat.getDateInstance();
	private static Date d;
	
	private static Connection con = null;
	private static IniFile ini = new IniFile();
	
	private static Booking b = null;
	
	/**
	 * @param args
	 */
	public static void main(String[] args) throws Exception {
		
		if (args.length != 3){
			displayUsage();
			System.exit(0);
		}
		
		String iniFile 		= args[0];
		String batchFile 	= args[1];
		String logFile 		= args[2];

		System.out.println(iniFile);
		
		setConnection(iniFile);
		
		try{
			log.openLogFile(logFile);
		}catch(Exception e){
			closeConnection(con);
			System.out.print("Logging initialization failed. Could not open LOGFILE. Booking aborted.\n\r" + e.getMessage());
			e.printStackTrace();
			displayUsage();
			System.exit(0);
		}

		b = new Booking(con,log,ini);
		
		d = new Date(System.currentTimeMillis());
		log.FmtAndLogMsg("Starting Booking Application at " + df.format(d));
		
		// read in the booking batch file line by line
		BookingBatchProcessor bp = new BookingBatchProcessor();

        /**		
	     * OWASP TOP 10 2010 - A4 Path Manipulation
	     * Changes to the below code to fix vulnerabilities
	     * TTP 324955
	     **/	
		//bp.setBatchFile(new File(batchFile));
		//bp.setBatchFile(new File(Encode.forJava(batchFile)));	
		bp.setBatchFile(new File(OWASPSecurity.validationCheck(batchFile,OWASPSecurity.DIRANDFILE)));	
		try{
			list = bp.readFileToList();
		}catch (Exception e){
			closeConnection(con);
			System.out.print("Logging initialization failed.  Could not open APPLICATION LIST FILE.  Booking aborted./n/r" + e.getMessage());
			e.printStackTrace();
			displayUsage();
			System.exit(0);
		}
		
		//  next process the list of requests
		bp.processRequests(list);
		
		closeConnection(con);
	}

	/**
	 * @param f
	 */
	private void setBatchFile(File f){
		batchFile = f;
	}
	
	/**
	 * @return
	 * @throws Exception
	 */
	@SuppressWarnings("unchecked")
	private List<String> readFileToList() throws Exception{
		return FileUtils.readLines(batchFile);
	}
	
	/**
	 * retrieve the evaluator id for this request
	 * @param request_id
	 * @return
	 * @throws SQLException
	 */
	private Integer getEvaluatorId(Long request_id) throws SQLException{
		Integer retVal = Integer.valueOf(0);
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
		    ps = con.prepareStatement("select evaluator_id from credit_request where request_id = ?");
		    ps.setLong(1, request_id);
		
		    rs = ps.executeQuery();
		
		    if (rs.next()) retVal = rs.getInt(EVALUATORID);
		}
		catch (Exception e) {
		   e.printStackTrace();
		}
        finally {
		   try{ if(rs != null) rs.close(); }catch(Exception e1){e1.printStackTrace();}
		   try{ if(ps != null) ps.close(); }catch(Exception e1){e1.printStackTrace();}
		}			
		
		return retVal;
	}
	
	/**
	 * run through the list provided and book each application by its request id.
	 * @param list
	 */
	private void processRequests(List<String> list) throws Exception{
		
		HashMap<String,String> h;
		Integer evaluatorId = 0;
		
		ApplicationStatusManager appStatusMgr;
		appStatusMgr = new ApplicationStatusManager(con,log);
		
		for (String item : list){
			// pull the request id and evaluator id form the string
			h = parseLine(item);
			
			String request_id 		= h.get(REQUESTID);
			//String book_status_type = h.get(BOOKSTATUSTYPE);
			
			// now BOOK the requests
			// ==========================================================================
			try{
				Long rid = Long.parseLong(request_id);
				// if the evaluator id is not set, set it, and keep it.
				if (evaluatorId.equals(0)) evaluatorId = getEvaluatorId(rid);
				
				Integer appStatus = appStatusMgr.getApplicationStatus(rid, evaluatorId); 

				System.out.print("Booking Request ID: " + rid + "  Evaluator:" + evaluatorId + " ----> ");

				// the app must be in PENBK or PENCLOSING to proceed
				if (appStatus != 17 && appStatus != 22){
					Exception e = new Exception("Application must be in PENBK or PENCLOSING status to be booked.");
					throw(e);
				}
				
				b.setProduct(rid);
				Integer prodId = b.getProductId(); 
				b.setProgramActivity(rid, evaluatorId, prodId);

				// if there are any triggered tolerance rules, kick out of this app. 
				if (b.hasTriggeredToleranceRules(rid)){
					Exception e = new Exception("Application must not have any triggered tolerance rules that have not been waived.");
					throw(e);
				}
				
				// application must have Contract activity to be booked, otherwise, kick out of this app. 
				if (!b.hasCPActivity(rid)){
					Exception e = new Exception("Application must have Contract Activity to be booked.");
					throw(e);
				}

				// if there are incomplete booking activities, kick out of this app. 
				if (b.hasIncompleteBookingActivities(rid, evaluatorId)){
					Exception e = new Exception("Application must not have any incomplete booking activities.");
					throw(e);
				}
				
				// if there are open comments or tickler items, kick out of this app. 
				if (b.hasOpenComments(rid)){
					Exception e = new Exception("Application must not have any open comments or tickler items.");
					throw(e);
				}
				
				int bookType = 2; //default to BOOKED
				if (b.hasBookingActivityExceptions(rid, evaluatorId) ||
					b.hasCPActivity(rid) ||
					b.hasTriggeredToleranceRules(rid)){
					bookType = 3;  // change to BOOKEX
				}
				
				System.out.println("updating status to " + bookType);
				
				b.bookApplication(rid, evaluatorId, bookType, "EXTERNAL");
				
			}catch(Exception e){
				System.out.println("Failed: " + e.getMessage());
				log.FmtAndLogMsg("Booking failed for request ID " + request_id);
				log.FmtAndLogMsg(e.getMessage(), e);
			}
			
			// ==========================================================================
		}
	}
	
	/**
	 * break down the line in the batch file to the necessary components for processing. 
	 * @param s
	 * @return
	 */
	private HashMap<String,String> parseLine(String s){
		HashMap<String,String> h = new HashMap<String,String>();
		
		// format for the String is as follows:
		// request_id,evaluator_id
		StringTokenizer st = new StringTokenizer(s,",");
		String token;
		int cnt = 0;
		while (st.hasMoreTokens()){
			
			token = st.nextToken(",").trim();
			
			switch(cnt){
				case 0: 
					h.put(REQUESTID, token); 
					break;
				case 1: 
					h.put(BOOKSTATUSTYPE, token);
					break;
			}
			cnt += 1;
		}
		
		return h;
	}
	
	/**
	 * set the connection from the ini file parameters
	 * @param ini
	 * @throws Exception
	 */
	private static void setConnection(String inifile) throws Exception {
		//IniFile ini = new IniFile();
		String dbhost="", dbport="", dbsid="", dbuser="", dbpwd="", sTNSEntry="";
			
        try {
			//
			// Read host, user, sid and password from ini file
			//
			ini.readINIFile(inifile);
			
			dbhost = ini.getINIVar("database.host", "");
			dbport = ini.getINIVar("database.port", "");
			dbuser = ini.getINIVar("database.user", "");
			dbpwd = ini.getINIVar("database.password", "");
			dbsid = ini.getINIVar("database.sid", "");
			sTNSEntry = ini.getINIVar("database.TNSEntry", "");

		} catch (Exception e) {
			System.out.println("Caught exception reading ini file '"+ inifile + "':" + e.toString());
			e.printStackTrace();
		}

			
		try {
			if (sTNSEntry.length() == 0) {
				con = setConnection(dbhost, dbsid, dbuser, dbpwd, dbport,"");
			} else {
				// use tns entry if available
				DBConnection DBConnect = new DBConnection();
				con = DBConnect.getConnectionTNS(sTNSEntry, dbuser,  dbpwd, null);
			}
		}	
		catch(Exception e) {
        	System.out.println("Exception: supplied db information could not create a connection.  see usage");
        	System.out.println(dbuser + "/" + dbpwd + "@" + dbhost + ":" + dbport + ":" + dbsid );
        	e.printStackTrace();
        	throw(e);
      	}   
	}	

	
	/**
	 * @param dbhost
	 * @param dbport
	 * @param dbsid
	 * @param dbuser
	 * @param dbpwd
	 * @return
	 * @throws Exception
	 */
	private static Connection setConnection(String dbhost, String dbsid, String dbuser, String dbpwd, String dbport,String tnsEntry) throws Exception {
		Connection _con = null;
			
		try {
			DBConnection DBConnect = new DBConnection();

			_con = DBConnect.getConnection(dbhost, dbsid, dbuser, dbpwd, null, dbport,tnsEntry);
		}	
		catch(Exception e) {
        	System.out.println("Exception: supplied db information could not create a connection.  see usage");
        	e.printStackTrace();
        	throw(e);
      	}   
		
		return _con;
	}	
	
	/**
	 * closes the existing connection if one exists
	 */
	private static void closeConnection(Connection _con){
		try{
			_con.close();
		}catch(Exception e){
			// do nothing;
		}
	}
	
	private static void displayUsage(){
		System.out.println("CMSI Booking Application usage: java Booking <inifile> <batchfile> <logfile>");
	}

}
