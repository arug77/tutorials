#!/bin/sh
#
# sample call to Booking Batch Processor
#

echo "java -classpath .:../lib/common.jar:../lib/ojdbc6.jar:../lib/commons-io-1.3.1.jar:../lib/xercesImpl-2.10.0.jar:../lib/xml-apis-2.10.0.jar:../lib/xalan-2.7.1.jar:../lib/evidl.jar com.cmsinc.origenate.tool.BookingBatchProcessor inifile batchfile logfile"
java -classpath .:../lib/common.jar:../lib/ojdbc6.jar:../lib/commons-io-1.3.1.jar:../lib/xercesImpl-2.10.0.jar:../lib/xml-apis-2.10.0.jar:../lib/xalan-2.7.1.jar:../lib/evidl.jar com.cmsinc.origenate.tool.BookingBatchProcessor add_arguments_here

