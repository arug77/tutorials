/*
 * AppraisalAlerts.java
 * 
 * Created on October 08, 2013
 * 
 * @author saimak
 * 
 * @version
 * 
 * Searches for apps with missing appraisal receipt date
 *  
 */

package com.cmsinc.origenate.tool;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.cmsinc.origenate.util.Alert;
import com.cmsinc.origenate.util.DBConnection;
import com.cmsinc.origenate.util.IniFile;
import com.cmsinc.origenate.util.LogMsg;
import com.cmsinc.origenate.util.SQLUtils;
import java.util.ArrayList;
import java.util.Arrays;


public class AppraisalAlerts {
	private java.sql.Connection con;

	private String s_log_file = "";

	private String sHost = "";

	private String sSIDname = "";

	private String sUser = "";

	private String sPass = "";

	private String sPort = "";

	private String sTNSEntry = "";
	
	private String sIniFile = "";

	private String evaluatorList = "";

	private String date_str = "";

	private IniFile ini = new IniFile();

	private LogMsg log = new LogMsg();

	//unused field -- there should be no date because the purpose is to find "apps with missing appraisal receipt date"
	//private Date check_dt;

	public AppraisalAlerts() {
	}

	/** ************************************************************ */
	/* Main method to call Appraisal Response Alerts process */
	/** ************************************************************ */
	public static void main(String args[]) throws Exception {
		AppraisalAlerts ara = new AppraisalAlerts();
		ara.getArgs(args);

		//insert appraisal response alerts to table
		
		ara.createAlerts();
		
		ara.closeConnection();
	}

	private void getArgs(String args[]) {
		if (args.length > 0) {
			for (int ix = 0; ix < args.length; ix++) {
				if ((args[ix].charAt(0) != '-') && (args[ix].length() > 1))
					showUsage();
				switch (args[ix].charAt(1)) {
				case 'i': // ini file
					sIniFile = args[ix].substring(2);
					try {
						//
						// Read host, user, sid and password from ini file
						//
						ini.readINIFile(sIniFile);
						s_log_file = ini.getINIVar(
								"logs.appraisal_alerts_log_file", "");
						if (s_log_file.length() > 0) {
							log.openLogFile(s_log_file);
						}
						sHost = ini.getINIVar("database.host", "");
						sPort = ini.getINIVar("database.port", "");
						sUser = ini.getINIVar("database.user", "");
						sPass = ini.getINIVar("database.password", "");
						sSIDname = ini.getINIVar("database.sid", "");
						sTNSEntry = ini.getINIVar("database.TNSEntry", "");

					} catch (Exception e) {
						log.FmtAndLogMsg("Caught exception reading ini file '"
								+ sIniFile + "':" + e.toString(), e);
					}
					break;
				case 'e': // evaluator list
					evaluatorList = args[ix].substring(2);
					break;
				default:
					log.FmtAndLogMsg("Unknown parameter: " + args[ix]);
					showUsage();
					break;
				}
			}

			if ((sHost.length() == 0 || sUser.length() == 0
					|| sSIDname.length() == 0 || sPort.length() == 0) && sTNSEntry.length() == 0) {
				log
						.FmtAndLogMsg("Host,User,Pwd,SID,Port or TNS Entry not specified in INI file");
				showUsage();
			}

			
			try {
				DBConnection DBConnect = new DBConnection();

				log.FmtAndLogMsg(sTNSEntry);
				
				if (sTNSEntry.length() == 0) {
					con = DBConnect.getConnection(sHost, sSIDname, sUser, sPass, s_log_file, sPort, "");
				} else {
					// use tns entry if available
					con = DBConnect.getConnectionTNS(sTNSEntry, sUser,  sPass, s_log_file);
				}
			} catch (Exception e) {
				log.FmtAndLogMsg("Error connecting to database: "
						+ e.toString(), e);
			}

		} else
			showUsage();
	}

	private void showUsage() {
		System.out.println("");
		System.out
				.println("Usage: java AppraisalAlerts -i<inifile> -e<evalID list> ");
		System.out.println("---------------------");
		System.out.println("-i - required: INI file to use for configuration");
		System.out
				.println("-e - optional: evaluator ID list separated by commas (-e10,12,15, default is for all evaluators)");
		System.out
				.println("example: java AppraisalAlerts -ic:/development/origenatebin/origenate.ini -e23");
		System.exit(1);
	}

	private void createAlerts() {
		PreparedStatement ps = null;
		ResultSet rs = null;
		;
		String sql = "";

		try {
									
			sql = "SELECT crar.request_id " +
				" FROM  CREDIT_REQ_APPRAISAL_RESP crar, EVAPP_INTERFACE evapp" +
				" WHERE crar.respseqno IN (SELECT max(resp.respseqno) respseqno " +
									" FROM CREDIT_REQ_APPRAISAL_RESP resp, CREDIT_REQUEST_HOME_EQUITY crhe " +
									" WHERE resp.request_id = crar.request_id " +
									" AND crhe.request_id = resp.request_id " +
									" AND crhe.INCLUDE_IN_LTV_FLG = 1 " +
									" AND resp.home_equity_id = crhe.home_equity_id " +
									" AND resp.collateral_request_id = crhe.collateral_request_id " +
									" AND resp.EVALUATOR_ID = crar.evaluator_id " +
									" AND resp.seqno = (SELECT max(appresp.seqno) seqno " + 
													" FROM CREDIT_REQ_APPRAISAL_RESP appresp, CREDIT_REQUEST_HOME_EQUITY he " +
													" WHERE appresp.request_id = crar.request_id " +
													" AND he.request_id = appresp.request_id " +
													" AND he.INCLUDE_IN_LTV_FLG = 1 " +
													" AND appresp.home_equity_id = he.home_equity_id " +
													" AND appresp.collateral_request_id = he.collateral_request_id " +
													" AND appresp.EVALUATOR_ID = crar.evaluator_id )) " +
				" AND crar.seqno = (SELECT max(creqappresp.seqno) seqno " +
							" FROM CREDIT_REQ_APPRAISAL_RESP creqappresp, CREDIT_REQUEST_HOME_EQUITY heq" +
							" WHERE creqappresp.request_id = crar.request_id  " +
							" AND heq.request_id = creqappresp.request_id " +
							" AND heq.INCLUDE_IN_LTV_FLG = 1 " +
							" AND creqappresp.home_equity_id = heq.home_equity_id " +
							" AND creqappresp.collateral_request_id = heq.collateral_request_id " +
							" AND creqappresp.EVALUATOR_ID = crar.evaluator_id ) " +
				" AND crar.rev_acc_flg = 1 and crar.exp_borr_receipt_dt is null " + 
				" AND evapp.appseqno = (SELECT appseqno FROM credit_request WHERE request_id = crar.request_id ) " +
				" AND (nvl(evapp.hoepa,0) = 1 OR nvl(evapp.hpml_flg,0) = 1) ";
			
			// exclude those apps that already have the alert in credit_request_alert			
			sql += " and crar.request_id not in (select al.request_id from credit_request_alerts al " + 
					" where al.request_id = crar.request_id and al.status_txt='open' and al.alert_type_id = 10 ) ";
			
			
			if (evaluatorList != ""){
				sql +=  " AND " + SQLUtils.inClauseHelper(evaluatorList,"crar.evaluator_id"); //sql += " and crar.evaluator_id in (" + evaluatorList + ")";
			}
				
			
					

			//Prepare statement to execute
			
			/**
             * TTP 324955 Security Remediation Fortify Scan
             */
			ps = con.prepareStatement(sql);
			int indx = 1;
			if (evaluatorList != ""){
				ArrayList<String> evaluatorListArr = new ArrayList<String>(Arrays.asList(evaluatorList.split("\\s*,\\s*")));
				for(int i = 0; i< evaluatorListArr.size();i++){
					ps.setString(indx++, evaluatorListArr.get(i));
				}
			}
			//Execute statement
			rs = ps.executeQuery();

			//Get values of taf alerts
			int cnt = 0;
			while (rs.next()) {
				cnt++;
				int req_id = rs.getInt("request_id");				 
				String user_id = "SYSTEM";
				//int alert_type_id = 10;
				
				int new_seq_id = 1;
				try {
					new_seq_id = Alert.getNextSeq_Id(req_id, con);
				} catch (Exception e) {
					throw new SQLException(e.toString());
				}
				if (new_seq_id == 0) {
					new_seq_id++;
					//the old code seemed to have a sequence starting with 1,
					// so I am keeping it that way
					//cc
				}

				Alert alert = new Alert(req_id, new_seq_id, 10,
						"open", new java.util.Date(), null, "Appraisal Receipt Date Missing", user_id, con);
				try {
					log.FmtAndLogMsg("Appraisal Receipt Date Missing for RID " + req_id + "..Adding alert type 10 BEGIN...");
					alert.addAlert();
					log.FmtAndLogMsg("Alert type 10 added for RID " + req_id + "..END.");
				} catch (Exception e) {
					throw new SQLException(e.toString());
				}

				
			}
				if(cnt <= 0)
					log.FmtAndLogMsg("No alerts found for Appraisal Receipt Date Missing.");
			try { rs.close();} catch(Exception exp) { exp.printStackTrace();}
			try { ps.close();} catch(Exception exp) { exp.printStackTrace();}			

		} catch (SQLException ex) {
			//Roll back changes
			try {
				con.rollback();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
			//Record error
			log.FmtAndLogMsg(ex.toString(), ex);
			
		} finally {// release resources
			
				if (rs != null) { try { rs.close();} catch(Exception e) { e.printStackTrace();} }
				if (ps != null) { try { ps.close();} catch(Exception e) { e.printStackTrace();} }
				if (con != null) { try { con.close();} catch(Exception e) { e.printStackTrace();} }	
			
		}

	}

	

	
	private void closeConnection() {
		try {
			if (con != null)
				con.close();
		} catch (SQLException e) {
		}
		con = null;
	}
}