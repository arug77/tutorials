/**
 * ProcessThread for LetterExtract
 * 
 * This program processes each letter extract touchpoint for the
 * LetterExtract standalone program. It gets the documents that
 * pass selection criteria and WTU queries for the touchpoint
 * and generates XML transactions for the documents. The XML
 * is then passed back to LetterExtract main code for processing.
 * 
 * Author: Mike Swain
 * Date: 1/3/2012
 * Version: 1.1
 */

package com.cmsinc.origenate.letterextract;

import java.sql.Connection;
import java.sql.DriverManager;
import java.util.ArrayList;

import com.cmsinc.origenate.doc.DocGen;
import com.cmsinc.origenate.doc.GenJob;
import com.cmsinc.origenate.event.CommentEvents;
import com.cmsinc.origenate.event.JournalEvents;
import com.cmsinc.origenate.util.LogMsg;
import com.cmsinc.origenate.util.Query;
import com.cmsinc.origenate.util.SQLSecurity;
import com.cmsinc.origenate.util.SQLUpdate;
import com.cmsinc.origenate.xmldbt.GenX;

public class ProcessThread extends Thread {
	
	Connection con = null;
	LetterExtract main = null;
	//String errorMessage = null;
	Integer touchpointID = null;
	String touchpointDesc = null;
	String letterID = null;
	String letterFileTypeID = null;
	//String sConStr, sPass;
	String sUser;
	String queryID = null;
	//LogMsg log_obj = null;
	GenJob genJob = null;
	GenX genx = null;
	JournalEvents journal = null;
	CommentEvents comment = null;
	int transactionCount = 0;
	String xml = "";
	
	public ProcessThread(LetterExtract main, String sConStr, String sUser, String sPass, 
			Integer touchpointID, String touchpointDesc, LogMsg log_obj, String queryID,
			String letterFileTypeID) throws Exception {
		
		this.touchpointID = touchpointID;
		this.touchpointDesc = touchpointDesc;
		this.main = main;
		//this.sConStr = sConStr;
		this.sUser = sUser;
		//this.sPass = sPass;
		//this.log_obj = log_obj;
		this.queryID = queryID;
		this.letterFileTypeID = letterFileTypeID;
		
		// Connect to the Oracle database
		con = DriverManager.getConnection(sConStr, sUser, sPass);
		
		genJob = new GenJob(con, log_obj);
		genx = new GenX(con, log_obj, main.i_dbg_level);
	}
	
	public void run() {
		
		// If no transactions need to be generated, then there is nothing to do.
		// The main class will just generate the header after each
		// thread returns from here and be done.
		if(main.xmlTrans.equals("")) {
			return;
		}
		
		transactionCount = 0;
		xml = "";
		
		try {
			main.log(0, touchpointDesc + " thread running...");
			
			processTouchpoint(touchpointID);
		} catch (Exception e) {
			main.log(0, touchpointDesc + " error: " + e.toString(), e);
		}
		
		main.log(0, touchpointDesc + ": " + transactionCount + " letters processed.");
		
		try {
			if(con != null) {
				con.close();
			}
		} catch (Exception e1) {
			e1.printStackTrace();
		}
		
		// Append to full XML and add to total transaction count
		main.appendToXML(xml);
		main.updateTransactionCount(transactionCount);

		main.log(0, touchpointDesc + " thread exited.");

		main.threadCount(true); // decrease thread count
		
	}
	
	private void processTouchpoint(Integer touchpointID) throws Exception {
		/* Touchpoints IDs:
		*	64 - WELCOME_LETTER
		*	65 - DECLINE_LETTER
		*	66 - FIRST_PAYMENT_LETTER
		*	67 - COUNTER_OFFER_LETTER
		*	68 - WITHDRAW_LETTER
		*	69 - EXPIRED_OFFER_LETTER
		*	70 - CLOSING_DOCUMENT
		*	71 - EARLY_DISCLOSURE_DOCUMENT
		*	72 - INITIAL
		*	73 - MISSING_INFO
		*	74 - FOLLOW_UP_1
		*	75 - FOLLOW_UP_2
		*	76 - RISK_BASED_PRICING_LETTER
		*	77 - ON_DEMAND_USER_INITIATED
		*	78 - GEN_NOTIFICATION_LETTER_1
		*   92 - GEN_NOTIFICATION_LETTER_2
		*	93 - GEN_NOTIFICATION_LETTER_3
		*	94 - GEN_NOTIFICATION_LETTER_4
		*	95 - GEN_NOTIFICATION_LETTER_5
		*	96 - GEN_NOTIFICATION_LETTER_6
		*   97 - GEN_NOTIFICATION_LETTER_7
		*	98 - GEN_NOTIFICATION_LETTER_8
		*	99 - GEN_NOTIFICATION_LETTER_9
		*	100 - GEN_NOTIFICATION_LETTER_10
		*/
		
		String submit_reason_id;
		String touchpoint = touchpointID.toString();
		
		// Populate the letterID using the touchpoint list above
		submit_reason_id = setLetterID(touchpointID);
		
		String evaluatorCheck = "";
		if(main.evaluatorID.length() > 0) {
			evaluatorCheck = " cr.evaluator_id = " + main.evaluatorID + " and ";
		} else {
			throw new Exception("EvaluatorID must be set in main.");
		}
		
		if(letterID.equals("EARLY_DISCLOSURE_DOCUMENT")) {
			evaluatorCheck += " e.evaluator_id = cps.evaluator_id and ";
		}
		
		String select;
		
		DocGen docGen = new DocGen(main.sIniFile);
		
		String doc_id_list = docGen.getListOfTouchpointDocuments(con, touchpoint, main.evaluatorID);
		
		// If there are no documents at this touchpoint, then we can exit
		if(doc_id_list.length() == 0) return;
		
		Query query = new Query(con);
		
		String request_id, document_id, evaluator_id, seq_id, letter_id, letter_desc;
		
		String[] docIdArray = doc_id_list.split(",");
		int docIdCount = docIdArray.length;
		
		// FIRST HALF - Process based on application selection query
		// We don't want to do this part for the On Demand letters,
		// since they do not use the application selection query
		if(!letterID.equals("ON_DEMAND_USER_INITIATED")) {
		    boolean printOnceFlg = getPrintOnceFlg(con, touchpointID);
		    //TTP 324955 Security Remediation Fortify Scan
		    ArrayList<String> params = new ArrayList<String>();
			select = docGen.buildSelect(con, letterID, doc_id_list, main.evaluatorID, submit_reason_id, queryID, main.log_obj, main.i_dbg_level, printOnceFlg, params );		
			main.log(0, letterID + " <<APP SELECTION QUERY>>: " + select + "\n");
			//
			query.prepareStatement(select);
			int placeCt = 1;
			for(int i = 0; i < params.size(); i++){
				String v = params.get(i);
				if(v.startsWith("'")){
				  query.setString(placeCt++, v.substring(1,v.length() - 1)); // no need for OWASP validation since Query does that by default
				}
				else if(v.contains(".")){
					query.setFloat(placeCt++, Float.valueOf(v));
				}
				else{
				  query.setLong(placeCt++, Long.valueOf(v)); //in case the numeric is long, it is better not to lose precision
				}
			}
			query.executePreparedQuery();
			
			Query letterIdQuery;
			
			while(query.next()) {
				request_id = query.getColValue("request_id");
				evaluator_id = query.getColValue("evaluator_id");
				
				for(int i = 0; i < docIdCount; i++) {
					document_id = docIdArray[i].trim();
					
					String failureMsg = "";
					
					if(genJob.doesDocumentPassWhenToUseCriteria(document_id, request_id)) {
						letterIdQuery = new Query(con);
						letterIdQuery.prepareStatement(
								"SELECT cd.letter_id, clt.letter_desc_txt " + 
								"FROM config_documents cd, config_letter_type clt, config_touchpoint_documents ctd " + 
								"WHERE cd.document_id = ? " + 
								"AND cd.evaluator_id = ? " + 
								"AND cd.letter_file_type_id = ? " + 
								"AND cd.document_id = ctd.document_id " + 
								"AND cd.evaluator_id = ctd.evaluator_id " + 
								"AND ctd.touchpoint_id = ? " + 
								"AND ctd.delivery_method_id = 'L' " + 
								"AND cd.evaluator_id = clt.evaluator_id " + 
								"AND cd.letter_file_type_id = clt.letter_file_type_id " + 
								"AND cd.letter_id = clt.letter_id ");
						letterIdQuery.setInt(1, Integer.valueOf(document_id));
						letterIdQuery.setInt(2, Integer.valueOf(evaluator_id));
						letterIdQuery.setInt(3, Integer.valueOf(letterFileTypeID));
						letterIdQuery.setInt(4, touchpointID);
						letterIdQuery.executePreparedQuery();
						
						letter_id = "";
						letter_desc = "";
						if(letterIdQuery.next()) {
							letter_id = letterIdQuery.getColValue("letter_id","");
							letter_desc = letterIdQuery.getColValue("letter_desc_txt","");
						} else {
							// The doc is not configured for this Letter File Type,
							// so move on to the next doc at this touchpoint
							continue;
						}
						
						String s_xml = "";
						
						try {
							main.log(0,"RID="+request_id+", DOCID="+document_id+", Extracting XML from database...");
							s_xml = getXMLStr(request_id,evaluator_id,genx);
							// replace non-printable chars in the xml...genx encodes ascii char so match &#25; for example
							s_xml = s_xml.replaceAll("&#[0-3][0-9];","");
							// remove the xml version/encoding type declaration
							s_xml = s_xml.replaceFirst("<\\?xml.*\\?>[\\n\\r]*", "");
							// put the letter_id into the IFX tag
							s_xml = s_xml.replaceAll("<IFX>","<IFX Type=\"" + letter_id + "\" Description=\"" + letter_desc + "\">");
							main.log(0,"RID="+request_id+", DOCID="+document_id+", Done Extracting XML from database...");
							xml = xml.concat(s_xml);
							transactionCount++;
						} catch (Exception e) {
							failureMsg = "Exception getting XML: " + e.toString();
							if(failureMsg.length() >= 300) {
								failureMsg = failureMsg.substring(0,297)+"...";
							}
						}
						
						// ADD CREDIT_REQ_DOC_HISTORY RECORD
						String sql = "INSERT INTO credit_req_doc_history (" + 
							"request_id, create_dt, document_id, status_id, error_txt, user_id, " + 
							"print_date, submit_reason_id, evaluator_id, job_type_txt) VALUES (" + 
							"?, sysdate, ?, ?, ?, 'SYSTEM', sysdate, ?, ?, 'Letter Extract') ";
						
						SQLUpdate sqlUpdate = new SQLUpdate();
						sqlUpdate.SetPreparedUpdateStatement(con, sql);
						sqlUpdate.setInt(1, Integer.valueOf(request_id));
						sqlUpdate.setInt(2, Integer.valueOf(document_id));
						sqlUpdate.setString(3, failureMsg.length()>0?"ERROR":"SUCCESS");
						sqlUpdate.setString(4, failureMsg);
						sqlUpdate.setInt(5, Integer.valueOf(submit_reason_id));
						sqlUpdate.setInt(6, Integer.valueOf(evaluator_id));
						sqlUpdate.RunPreparedUpdateStatement();
						
						journal = new JournalEvents(con, null);
						if(failureMsg.length() > 0) {
							journal.addJournal(Integer.parseInt(request_id), 107, "Error adding DocID="+document_id+" to letter extract.", "SYSTEM");
						} else {
							journal.addJournal(Integer.parseInt(request_id), 107, "Successfully added DocID="+document_id+" to letter extract.", "SYSTEM");
						}
						
						comment = new CommentEvents(con, main.log_obj);
						if(failureMsg.length() > 0) {
							comment.addComment(Integer.parseInt(request_id), 89, "Letter Extract (Data) Error", "Error adding DocID="+document_id+" to letter extract.", "SYSTEM", "", "");
						} else {
							comment.addComment(Integer.parseInt(request_id), 89, "Letter Extract (Data) Success", "Successfully added DocID="+document_id+" to letter extract.", "SYSTEM", "", "");
						}
						
						main.log(0, "Inserted CREDIT_REQ_DOC_HISTORY for RID="+request_id+
								", DOCID="+document_id+", STATUS="+(failureMsg.length()>0?"ERROR":"SUCCESS"));
					}
				}
			}
		}
		
		// SECOND HALF - Process stubs from credit_req_doc_history
		submit_reason_id = "30";
		Query qryrevalwtu = new Query(con);
		ArrayList<String> docs = new ArrayList<String>();
		String revalWtu = "";
		select = 
			"SELECT DISTINCT crdh.seq_id, crdh.document_id, cr.request_id, cr.evaluator_id, " + 
			"cd.letter_id, clt.letter_desc_txt " +  
			"FROM credit_request cr, credit_req_doc_history crdh, config_documents cd, " +  
			"config_letter_type clt " +  
			"WHERE cr.evaluator_id = ? " + 
  			"AND cr.request_id = crdh.request_id " +  
  			"AND crdh.document_id = cd.document_id " + 
  			"AND crdh.evaluator_id = cd.evaluator_id " + 
  			"AND crdh.document_id IN (" + SQLSecurity.listToPlaceholders(doc_id_list, docs) +
				") " +  
			"AND crdh.evaluator_id = cr.evaluator_id " + 
			"AND cd.letter_file_type_id = ? " + 
  			"AND crdh.status_id = 'INPROCESS' " + 
  			"AND crdh.submit_reason_id = ? " + 
  			"AND cr.evaluator_id = clt.evaluator_id " + 
  			"AND cd.letter_file_type_id = clt.letter_file_type_id " + 
  			"AND cd.letter_id = clt.letter_id ";
		
		main.log(0, letterID + " <<DOC HISTORY QUERY>>: " + select + "\n");
		query.prepareStatement(select);
		query.setInt(1, main.evaluatorID);
		int placeCt = 2;
		for(String param:docs){
			if(param.startsWith("'")){
			  query.setString(placeCt++, param.substring(1,param.length() - 1)); // no need for OWASP validation since Query does that by default
			}
			else{ 
			  query.setInt(placeCt++, Integer.valueOf(param));
			}
		}
		query.setInt(placeCt++, letterFileTypeID);
		query.setInt(placeCt++, submit_reason_id);
		query.executePreparedQuery();
		//query.executeQuery(select);
		
		boolean passesWtu = true;
		
		while(query.next()) {
			request_id = query.getColValue("request_id");
			evaluator_id = query.getColValue("evaluator_id");
			document_id = query.getColValue("document_id");
			seq_id = query.getColValue("seq_id");
			letter_id = query.getColValue("letter_id");
			letter_desc = query.getColValue("letter_desc_txt");
			String failureMsg = "";
			main.log(0,"docid = " + document_id + "touchpointid = " + touchpointID + "evalid = " + evaluator_id);
			String s_xml = "";
		
			qryrevalwtu.prepareStatement(
					"SELECT revalidate_wtu_flg FROM config_touchpoint_documents " +
					"WHERE document_id = ? " + 
					"AND evaluator_id = ? " + 
					"AND touchpoint_id = ? " +
					"AND delivery_method_id = 'L'");			
			qryrevalwtu.setInt(1, Integer.valueOf(document_id));
			qryrevalwtu.setInt(2, Integer.valueOf(evaluator_id));
			qryrevalwtu.setInt(3, touchpointID);
			qryrevalwtu.executePreparedQuery();
			
			while(qryrevalwtu.next()) {
				revalWtu = qryrevalwtu.getColValue("revalidate_wtu_flg", "0");
			}
			
			if(revalWtu.equals("1")) {			
				passesWtu = genJob.doesDocumentPassWhenToUseCriteria(document_id, request_id);
			} 
			
			main.log(0,"docid = " + document_id + "touchpointid = " + touchpointID + "evalid  = " + main.evaluatorID + " revalWtu = " + revalWtu + " passesWtu = " + passesWtu);
						

			if(passesWtu){
				try {
					main.log(0,"RID="+request_id+", DOCID="+document_id+", Extracting XML from database...");
					s_xml = getXMLStr(request_id,evaluator_id,genx);
					// replace non-printable chars in the xml...genx encodes ascii char so match &#25; for example
					s_xml = s_xml.replaceAll("&#[0-3][0-9];","");
					// remove the xml version/encoding type declaration
					s_xml = s_xml.replaceFirst("<\\?xml.*\\?>[\\n\\r]*", "");
					// put the letter_id into the IFX tag
					s_xml = s_xml.replaceAll("<IFX>","<IFX Type=\"" + letter_id + "\" Description=\"" + letter_desc + "\">");
					main.log(0,"RID="+request_id+", DOCID="+document_id+", Done Extracting XML from database...");
					xml = xml.concat(s_xml);
					transactionCount++;
				} catch (Exception e) {
					failureMsg = "Exception getting XML: " + e.toString();
					if(failureMsg.length() >= 300) {
						failureMsg = failureMsg.substring(0,297)+"...";
					}
				}
			
				String sql = "UPDATE credit_req_doc_history SET " +
						"status_id = ?, error_txt = ?, print_date = sysdate " + 
						"where seq_id = ? ";
				
				SQLUpdate sqlUpdate = new SQLUpdate();
				sqlUpdate.SetPreparedUpdateStatement(con, sql);
				sqlUpdate.setString(1, failureMsg.length()>0?"ERROR":"SUCCESS");
				sqlUpdate.setString(2, failureMsg);
				sqlUpdate.setInt(3, Integer.parseInt(seq_id));
				sqlUpdate.RunPreparedUpdateStatement();
				
				journal = new JournalEvents(con, null);
				if(failureMsg.length() > 0) {
					journal.addJournal(Integer.parseInt(request_id), 107, "Error adding DocID="+document_id+" to letter extract.", "SYSTEM");
				} else {
					journal.addJournal(Integer.parseInt(request_id), 107, "Successfully added DocID="+document_id+" to letter extract.", "SYSTEM");
				}
				
				comment = new CommentEvents(con, main.log_obj);
				if(failureMsg.length() > 0) {
					comment.addComment(Integer.parseInt(request_id), 89, "Letter Extract (Data) Error", "Error adding DocID="+document_id+" to letter extract.", "SYSTEM", "", "");
				} else {
					comment.addComment(Integer.parseInt(request_id), 89, "Letter Extract (Data) Success", "Successfully added DocID="+document_id+" to letter extract.", "SYSTEM", "", "");
				}
				
				main.log(0, "Updated CREDIT_REQ_DOC_HISTORY for RID="+request_id+
						", DOCID="+document_id+", STATUS="+(failureMsg.length()>0?"ERROR":"SUCCESS"));
			} else { // if doc does not pass reeval of WTU
			
				String sql = "UPDATE credit_req_doc_history SET " +
						"status_id = ?, error_txt = ?, print_date = sysdate " + 
						"where seq_id = ? ";
				
				SQLUpdate sqlUpdate = new SQLUpdate();
				sqlUpdate.SetPreparedUpdateStatement(con, sql);
				sqlUpdate.setString(1, "SYSTEM CANCELLED");
				sqlUpdate.setString(2, "System Cancelled");
				sqlUpdate.setInt(3, Integer.parseInt(seq_id));
				sqlUpdate.RunPreparedUpdateStatement();
				
				journal = new JournalEvents(con, null);
				journal.addJournal(Integer.parseInt(request_id), 107, "Cancel adding DocID="+document_id+" to letter extract by System.", "SYSTEM");
			} 
		}
	}
	/**
	 * Gets PrintOnceFlag
	 * @param con
	 * @param touchpointID
	 * @return boolean printOnceFlg value
	 * @throws Exception
	 */
	private boolean getPrintOnceFlg(Connection con,int touchpointID) {
		boolean printOnceFlg = true;
		try {
			Query queryTmp = new Query(con);
			 // Get the printOnce Flg for this touchpoint			
			String sql="select process_once_flg from config_touchpoint_documents where touchpoint_id = ? ";
			queryTmp.prepareStatement(sql);
			queryTmp.setInt(1, touchpointID);
			queryTmp.executePreparedQuery();
			while (queryTmp.next()) {
			   printOnceFlg= queryTmp.getColValue("process_once_flg", "1").equals("1");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return printOnceFlg;
	}
	
	/**
	 * Gets XML transactions for the app
	 * @param request_id
	 * @param evaluator_id
	 * @param genx Already instantiated GenX object
	 * @return string containing xml transactions
	 * @throws Exception
	 */
	private String getXMLStr (String request_id, String evaluator_id, GenX genx)  throws Exception {
	    String decision_ref_id = "";
	    String s_xml = "";

	    try {
			genx.ResetParams();
			genx.bSetParam("REQUEST_ID",request_id);

			// If a final decision has been made then include it in the xml
			decision_ref_id = getDecRefID(request_id,evaluator_id);

			if (decision_ref_id.length()>0) {
				genx.bSetParam("DECISION_REF_ID",decision_ref_id);
			}

			if(main.encryption_flg) {
				int ssn_flg = 0, bank_flg = 0, drivers_flg = 0;
				
				//Find Encryption flag from config_encryption table
				Query tmpQuery = new Query(con);
				String sql = "select ssn_flg,bank_flg,drivers_flg from config_encryption where evaluator_id = ?";
				tmpQuery.prepareStatement(sql);
				tmpQuery.setInt(1, evaluator_id);
				tmpQuery.executePreparedQuery();
				if (tmpQuery.next()) {
					ssn_flg= Integer.parseInt(tmpQuery.getColValue("ssn_flg", "0"));
					bank_flg= Integer.parseInt(tmpQuery.getColValue("bank_flg", "0"));
					drivers_flg= Integer.parseInt(tmpQuery.getColValue("drivers_flg", "0"));
				}

				String decryptionFields = "";

				//Check encryption fields from table and add them into decryptionFields so XML is totally decrypted,
				if (ssn_flg == 1) {
					if(decryptionFields.equals("")) {
						decryptionFields = decryptionFields +"ssn";
					} else {
						decryptionFields = decryptionFields +",ssn";
					}
				}
				if (bank_flg == 1) {
					if(decryptionFields.equals("")) {
						decryptionFields = decryptionFields +"bank";
					} else {
						decryptionFields = decryptionFields +",bank";
					}
				}
				if (drivers_flg == 1) {
					if(decryptionFields.equals("")) {
						decryptionFields = decryptionFields +"drivers";
					} else {
						decryptionFields = decryptionFields +",drivers";
					}
				}

				main.log(5,"decryptionFields: "+decryptionFields);

				//setting Encryption Parameters
				genx.setEncryptionParms(sUser.toLowerCase(),decryptionFields);
			}

			s_xml = genx.sGetXMLorThrow(main.xmlTrans,genx.build_type_xml);
			main.log(5,"Done extracting XML from database");
		} catch (Exception e) {
			throw e;
		}

		return s_xml;
	}
	/**
	 * Gets the latest dec_ref_id for the app if exists
	 * @param request_id
	 * @param evaluator_id
	 * @return decision ref id if exists, otherwise empty string
	 * @throws Exception
	 */
	private String getDecRefID(String request_id, String evaluator_id)  throws Exception{
		String requestor_id="", slct="";
		String decision_ref_id = ""; // default to none
		Query tmpQuery = new Query(con);
		
		try {
			// If a final decision has been made then include it in the xml
			String sql = "select requestor_id from requestor_header where request_id = ? " +
				"and (requestor_type_id = 0 OR requestor_type_id = 3)";
			tmpQuery.prepareStatement(sql);
			tmpQuery.setInt(1, request_id);
			tmpQuery.executePreparedQuery();
			if (tmpQuery.next()) {
				requestor_id=tmpQuery.getColValue("requestor_id","0");
				slct=
					" SELECT max(decision_ref_id) dec_ref_id"+
					"      FROM   credit_req_decisions_evaluator"+
					"      WHERE  evaluator_id = ? "+
					"      AND    request_id  = ? "+
					"      AND    (((decision_id  =  3 "+   					// approve
					"                      OR decision_id =  2"+				// decline
					"                      OR decision_id  =  1"+				// conditional
					"                      OR decision_id  =  0)"+				// pending
					"                      AND  decision_category_id = 2)"+		// analyst
					"      OR    ((decision_id  =  102"+						// app scor
					"                      OR decision_id  =  103)"+			// dec scor
					"                      AND decision_category_id = 1"+
					"                      AND requestor_id        =  ? ))";
				tmpQuery.prepareStatement(slct);
				tmpQuery.setInt(1, evaluator_id);
				tmpQuery.setInt(2, request_id);
				tmpQuery.setInt(3, requestor_id);
				tmpQuery.executePreparedQuery();
				if (tmpQuery.next()) {
					decision_ref_id=tmpQuery.getColValue("dec_ref_id","");
				}
			}
		} catch (Exception e) {
			throw e;
		}
		
		return decision_ref_id;
	}
	
	/**
	 * Sets the letterID instance variable
	 * @param touchpointID The touchpoint id as an Integer
	 * @return submit_reason_id
	 * @throws Exception If touchpoint id does not match any
	 * of the letters
	 */
	private String setLetterID(Integer touchpointID) throws Exception {
		if(touchpointID.equals(64)) {
			letterID = "WELCOME_LETTER";
			return "7";
		}
		else if(touchpointID.equals(65)) {
			letterID = "DECLINE_LETTER";
			return "5";
		}
		else if(touchpointID.equals(66)) {
			letterID = "FIRST_PAYMENT_LETTER";
			return "9";
		}
		else if(touchpointID.equals(67)) {
			letterID = "COUNTER_OFFER_LETTER";
			return "6";
		}
		else if(touchpointID.equals(68)) {
			letterID = "WITHDRAW_LETTER";
			return "18";
		}
		else if(touchpointID.equals(69)) {
			letterID = "EXPIRED_OFFER_LETTER";
			return "8";
		}
		else if(touchpointID.equals(70)) {
			letterID = "CLOSING_DOCUMENT";
			return "12";
		}
		else if(touchpointID.equals(71)) {
			letterID = "EARLY_DISCLOSURE_DOCUMENT";
			return "14";
		}
		else if(touchpointID.equals(72)) {
			letterID = "INITIAL";
			return "19";
		}
		else if(touchpointID.equals(73)) {
			letterID = "MISSING_INFO";
			return "22";
		}
		else if(touchpointID.equals(74)) {
			letterID = "FOLLOW_UP_1";
			return "20";
		}
		else if(touchpointID.equals(75)) {
			letterID = "FOLLOW_UP_2";
			return "21";
		}
		else if(touchpointID.equals(76)) {
			letterID = "RISK_BASED_PRICING_LETTER";
			return "26";
		}
		else if(touchpointID.equals(77)) {
			letterID = "ON_DEMAND_USER_INITIATED";
			return "30";
		}
		else if(touchpointID.equals(78)) {
			letterID = "GEN_NOTIFICATION_LETTER_1";
			return "29";
		}
		else if(touchpointID.equals(80)) {
			letterID = "GEN_NOTIFICATION_LETTER_MANUAL_REDIRECTION";
			return "29";
		}
		else if(touchpointID.equals(81)) {
			letterID = "GEN_NOTIFICATION_LETTER_SYSTEM_REDIRECTION";
			return "29";
		}
		else if(touchpointID.equals(92)) {
			letterID = "GEN_NOTIFICATION_LETTER_2";
			return "29";
		}
		else if(touchpointID.equals(93)) {
			letterID = "GEN_NOTIFICATION_LETTER_3";
			return "29";
		}
		else if(touchpointID.equals(94)) {
			letterID = "GEN_NOTIFICATION_LETTER_4";
			return "29";
		}
		else if(touchpointID.equals(95)) {
			letterID = "GEN_NOTIFICATION_LETTER_5";
			return "29";
		}
		else if(touchpointID.equals(96)) {
			letterID = "GEN_NOTIFICATION_LETTER_6";
			return "29";
		}
		else if(touchpointID.equals(97)) {
			letterID = "GEN_NOTIFICATION_LETTER_7";
			return "29";
		}
		else if(touchpointID.equals(98)) {
			letterID = "GEN_NOTIFICATION_LETTER_8";
			return "29";
		}
		else if(touchpointID.equals(99)) {
			letterID = "GEN_NOTIFICATION_LETTER_9";
			return "29";
		}
		else if(touchpointID.equals(100)) {
			letterID = "GEN_NOTIFICATION_LETTER_10";
			return "29";
		}
		else {
			throw new Exception("Touchpoint ID " + touchpointID + " is invalid.");
		}
	}
}
