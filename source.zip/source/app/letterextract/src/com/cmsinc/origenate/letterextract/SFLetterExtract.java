/**
 * SFLetterExtract standalone program
 * 
 * This program will produce the nightly letter jobs based upon queries defined in ECM:
 *     Query 54 - Decline letter 
 *     Query 35 - Unable to ObtainPO letter
 *
 * After getting the application information for each type of letter, one large XML
 * file is created and styled using the configured stylesheet for the Letter
 * File Type ID. We write the final XML to the output directory.
 * 
 * Parameters:
 *      i - The location of the origenate.ini. This is loaded into iniFile 
 *      o - Sets the location of the output directory
 *      d - To turn up the debugging
 */

package com.cmsinc.origenate.letterextract;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.sql.Connection;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Hashtable;
import org.apache.commons.lang3.StringUtils;


import com.cmsinc.origenate.cp.mpe.ApplyXSLListener;
import com.cmsinc.origenate.doc.GenJob;
import com.cmsinc.origenate.event.CommentEvents;
import com.cmsinc.origenate.event.JournalEvents;
import com.cmsinc.origenate.util.DBConnection;
import com.cmsinc.origenate.util.IniFile;
import com.cmsinc.origenate.util.LogMsg;
import com.cmsinc.origenate.util.Query;
import com.cmsinc.origenate.util.SQLUpdate;
import com.cmsinc.origenate.xmldbt.GenX;
import com.cmsinc.origenate.xmldbt.TransformerUtils;
import com.cmsinc.origenate.util.OWASPSecurity;

public class SFLetterExtract {

    // Constants for both letter types
    private static final int STATE_FARM_EVALUATOR = 148;
    private static final String DECLINE_LETTER_QUERY_NUMBER = "54";
    private static final String DECLINE_LETTER_FILE_TYPE_ID = "1";
    private static final String DECLINE_LETTER_SUBMIT_REASON = "5";
    private static final String DECLINE_LETTER_DOC_ID = "12131";
    private static final String DECLINE_LETTER_TOUCHPOINT = "65";
    private static final String UNABLE_TO_OBTAIN_PO_QUERY_NUMBER = "35";
    private static final String UNABLE_TO_OBTAIN_PO_FILE_TYPE_ID = "2";
    private static final String UNABLE_TO_OBTAIN_PO_SUBMIT_REASON = "29";
    private static final String UNABLE_TO_OBTAIN_PO_DOC_ID = "12151";
    private static final String UNABLE_TO_OBTAIN_PO_TOUCHPOINT = "80";

    private Connection connection;
    private String decryptionFields = "";
    private boolean encryption_flg = false;
    private int i_dbg_level = 0;
    private IniFile iniFile = new IniFile();
    private String letterDescText = "";
    private String letterFileTypeDesc = "";
    private String letterID = "";
    private String letterStylesheet = "";
    private String letterXMLTrans = "";
    private String logFile = "";
    private LogMsg log_obj = new LogMsg();
    private String outputDirectory = "";
    private int transactionCount = 0;

    /**
     * Default constructor.
     */
    public SFLetterExtract() {
    }

    /**
     * Main method, calls run().
     * 
     * @param args
     *            Arguments passed into the program.
     */
    public static void main(String[] args) {
        SFLetterExtract sfLetterExtract = new SFLetterExtract();

        if (sfLetterExtract.run(args)) {
            System.exit(0);
        } else {
            System.exit(1);
        }
    }

    /**
     * Runs the LetterExtract job.
     * 
     * @param args
     *            Input Arguments
     * @return True if no errors were encountered; otherwise false.
     */
    public boolean run(String[] args) {
        boolean successfulExecution = true;

        try {
            setPropertiesFromArgs(args);
            log_obj.FmtAndLogMsg("SFLetterExtract initializing...");

            // produce DeclineLetter
            produceLetter(DECLINE_LETTER_QUERY_NUMBER, DECLINE_LETTER_FILE_TYPE_ID, DECLINE_LETTER_SUBMIT_REASON, DECLINE_LETTER_DOC_ID, DECLINE_LETTER_TOUCHPOINT);

            // produce UnableToObtainPOLetter
            produceLetter(UNABLE_TO_OBTAIN_PO_QUERY_NUMBER, UNABLE_TO_OBTAIN_PO_FILE_TYPE_ID, UNABLE_TO_OBTAIN_PO_SUBMIT_REASON, UNABLE_TO_OBTAIN_PO_DOC_ID, UNABLE_TO_OBTAIN_PO_TOUCHPOINT);
        } catch (Exception e) {
            if (log_obj != null) {
                log_obj.FmtAndLogMsg("Job Failure. ", e);
            }
            successfulExecution = false;
        } finally {
            // If we have an open database connection close it before we exit.
            try {
                if (connection != null) {
                    connection.close();
                }
            } catch (Exception e) {
                log_obj.FmtAndLogMsg("Failure closing database connection: " + e.toString());
            }
        }

        if (log_obj != null) {
            log_obj.FmtAndLogMsg("LetterExtract complete. Exiting.");
        }
        return successfulExecution;
    }

    /**
     * Reads the input arguments.
     * 
     * @param args
     *            Input Arguments: 
     *              i - The location of the origenate.ini. This is loaded into iniFile 
     *              o - Sets the location of the output directory
     *              d - To turn up the debugging
     * @throws Exception
     *             Throws an exception if the argument passed was not valid.
     */
    protected void setPropertiesFromArgs(String args[]) throws Exception {
        checkArgsLength(args);
        for (String argument : args) {
            if (argument.charAt(0) != '-') {
                showUsage();
            }

            switch (argument.charAt(1)) {
            case 'i':
                String sIniFile = argument.substring(2);
                try {
                    setupINIFile(sIniFile);
                    setEncryptionFlag();
                } catch (Exception e) {
                    if (log_obj != null) {
                        // There is a chance the log_obj never got created because the ini couldn't be read
                        log_obj.FmtAndLogMsg("Caught exception reading ini file '" + sIniFile + "': " + e.toString(), e);
                        throw e;
                    }
                }
                break;
            case 'd': // turn debug on
                i_dbg_level = 5;
                log_obj.FmtAndLogMsg("debugging turned on");
                break;
            case 'o': // output directory
                setOutputDirectory(argument);
                break;
            default:
                showUsage();
                throw new RuntimeException("Command provided not recognized");
            }
        }
    }

    /**
     * Set up the IniFile for use based off the input argument from the user.
     * 
     * @param sIniFile
     *            Path to the IniFile.
     * @throws Exception
     *             Throws an exception if the iniFile could not be read.
     */
    protected void setupINIFile(String sIniFile) throws Exception {
        // Read host, user, sid and password from ini file
        iniFile.readINIFile(sIniFile);

        logFile = iniFile.getINIVar("logs.letter_extract_log_file", "");
        if (!StringUtils.isEmpty(logFile)) {
            log_obj.openLogFile(logFile);
        }
        log_obj.FmtAndLogMsg("IniFile is '" + sIniFile + "'");
        log_obj.FmtAndLogMsg("LetterExtract initializing...");
    }

    /**
     * Sets the encryptionFlag variable based off the content of the iniFile.
     */
    protected void setEncryptionFlag() {
        encryption_flg = iniFile.getINIVar("encryption.encryption_flg", "").equals("1");
        log_obj.FmtAndLogMsg("Encryption (true/false) is '" + encryption_flg + "'");
    }

    /**
     * Sets the outputDirectory for the letters generated.
     * 
     * @param argument
     *            The directory where the letters will be generated.
     */
    protected void setOutputDirectory(String argument) {
        outputDirectory = argument.substring(2);
        outputDirectory += File.separator;
        log_obj.FmtAndLogMsg("Output Dir: " + outputDirectory);
    }

    /**
     * This program requires 2 input parameters at the least.
     */
    protected void checkArgsLength(String[] args) {
        if (args.length < 2) {
            log_obj.FmtAndLogMsg("Inadequate number of arguments provided.");
            showUsage();
            throw new RuntimeException("Less than two arguments provided");
        }
    }

    /**
     * Sets the log object. This is mainly used for testing purposes.
     * 
     * @param log
     *            The log object to set the instance variable to.
     */
    protected void setLogObj(LogMsg log) {
        log_obj = log;
    }

    /**
     * Inform users of the input options required to execute this program. Called after an error is thrown during argument load.
     */
    protected void showUsage() {
        System.out.println();
        System.out.println("Usage: java SFLetterExtract -i<inifile> -o<path to output directory> [-d]");
        System.out.println("-------------------------------------------------------------------------");
        System.out.println("-i - required: INI file to use for configuration");
        System.out.println("-o - required: path to the output directory (-o/opt/origenate/or_statefarm/data/letterextract)");
        System.out.println("-d - optional: turns debug messages on. (Default is off)");
    }

    /**
     * Produces the letters, can work with multiple types of letters, just needs the IDs passed in. This will create genJob/genx objects and then pass
     * them in to the overloaded produceLetter().
     * 
     * @param queryNumber
     *            Query number for the letter to be produced.
     * @param fileType_id
     *            ID of the fileType whose information needs to be set.
     * @param submit_reason_id
     *            Submit reason ID.
     * @param document_id
     *            Document ID.
     * @param touchpoint_id
     *            Touchpoint ID.
     * @throws Exception
     *             An exception will be thrown to caller if something went wrong.
     */
    protected void produceLetter(String queryNumber, String fileType_id, String submit_reason_id, String document_id, String touchpoint_id) throws Exception {
        getDatabaseConnection();
        GenJob genJob = new GenJob(connection, logFile);
        GenX genx = new GenX(connection, log_obj, i_dbg_level);
        produceLetter(genJob, genx, queryNumber, fileType_id, submit_reason_id, document_id, touchpoint_id);
    }

    /**
     * Produces the letters, can work with multiple types of letters. This method requires the genJob/genx objects to be passed in.
     * 
     * @param genJob
     *            Can pass in a genJob instance directly.
     * @param genx
     *            Can pass in a genx instance directly.
     * @param queryNumber
     *            Query number for the letter to be produced.
     * @param fileType_id
     *            ID of the fileType whose information needs to be set.
     * @param submit_reason_id
     *            Submit reason ID.
     * @param document_id
     *            Document ID.
     * @param touchpoint_id
     *            Touchpoint ID.
     * @throws Exception
     *             An exception will be thrown to caller if something went wrong.
     */
    protected void produceLetter(GenJob genJob, GenX genx, String queryNumber, String fileType_id, String submit_reason_id, String document_id, String touchpoint_id) throws Exception {
        setLetterInformationForFileType(fileType_id);
        getDatabaseConnection();

        log_obj.FmtAndLogMsg("Starting to produce letters for touchpoint " + touchpoint_id);

        Hashtable<String, String> runtimeValues = new Hashtable<String, String>();
        runtimeValues.put("evaluator_id", Integer.toString(STATE_FARM_EVALUATOR));

        transactionCount = 0;
        String xml = "";
        // Call genJob.buildAndExecuteQuery to get the requestIDs of the apps that need to have letters generated
        Query query = genJob.buildAndExecuteQuery(connection, queryNumber, null, runtimeValues, null);
        log_obj.FmtAndLogMsg("Letter Selection Query returned " + query.getRowCount() + " applications");
        while (query.next()) {
            String request_id = query.getColValue("request_id");
            String failureMsg = "";

            // Extract XML from database
            try {
                log_obj.FmtAndLogMsg("RID=" + request_id + " Extracting XML from database...");
                String requestXML = getXMLStr(request_id, genx);
                log_obj.FmtAndLogMsg("RID= " + request_id + " Done Extracting XML from database...");
                xml = xml.concat(requestXML);

                // Insert record into credit_req_doc_history
                addDocHistoryRecord(Integer.parseInt(request_id), Integer.parseInt(document_id), failureMsg, Integer.parseInt(submit_reason_id));

                transactionCount++;
            } catch (Exception e) {
                failureMsg = "Exception getting XML: " + e.toString();
                if (failureMsg.length() >= 300) {
                    failureMsg = failureMsg.substring(0, 297) + "...";
                }
            }
        }

        // The 'Second Half' section from ProcessThread
        String processedStubsXML = processStubs(touchpoint_id, document_id, fileType_id, genx);
        xml.concat(processedStubsXML);

        produceLetterOutputFile(xml, fileType_id);
        log_obj.FmtAndLogMsg(letterFileTypeDesc + ": " + transactionCount + " letters processed.");
    }

    /**
     * Checks to see if the database connection has been initialized.
     * 
     * @throws RuntimeException
     *             Error getting database connection.
     */
    protected void getDatabaseConnection() {
        try {
            if ((connection == null) || (connection.isClosed())) {
                DBConnection dbConnect = new DBConnection();
                connection = dbConnect.getConnection(iniFile.getINIVar("database.host", ""), iniFile.getINIVar("database.sid", ""), iniFile.getINIVar("database.user", ""), iniFile.getINIVar("database.password", ""), iniFile.getINIVar("logs.solicitation_data_load_log_file", ""),
                        iniFile.getINIVar("database.port", ""), iniFile.getINIVar("database.TNSEntry", ""));
            }
        } catch (Exception e) {
            throw new RuntimeException("Error getting database connection", e);
        }
    }

    /**
     * Apply the XSL Transformation on the XML.
     * 
     * @param s_xml
     *            XML.
     * @param s_xsl
     *            XSL Stylesheet.
     * @return Styled string.
     * @throws Exception
     *             Throws an exception if something goes wrong with the transformation.
     */
    protected String sApplyXSL(String s_xml, String s_xsl) throws Exception {
        String s_ret = null;

        ApplyXSLListener listener = new ApplyXSLListener();
        try {
            s_ret = TransformerUtils.toString(s_xml, s_xsl);
        } catch (Exception e) {
            String s_msg = listener.getMessage();
            if (s_msg == null) {
                s_msg = "";
            }
            throw new Exception(e.toString() + " listener msg:" + s_msg, e);
        }
        return s_ret;
    }

    /**
     * This will set class level letter variables for the fileTypeID passed in. If no data is found for fileTypeID, or the stylesheet is not active a
     * RuntimeException will be thrown.
     * 
     * @param args
     *            fileTypeID - ID of the fileType whose information needs to be set.
     */
    protected void setLetterInformationForFileType(String fileTypeID) {
        String sql = "SELECT clft.active_flg, clft.letter_file_type_txt, clft.stylesheet_txt, clft.xml_trans, clt.letter_desc_txt, clt.letter_id " +
                "FROM config_letter_file_type  clft, config_letter_type clt " + 
                "WHERE clft.evaluator_id = ? AND clft.letter_file_type_id = ? " +
                "AND clft.evaluator_id = clt.evaluator_id  AND  clft.letter_file_type_id = clt.letter_file_type_id";

        try {
            getDatabaseConnection();
            Query query = new Query(connection);
            query.prepareStatement(sql);
            query.setInt(1, STATE_FARM_EVALUATOR);
            query.setInt(2, Integer.valueOf(fileTypeID));
            query.executePreparedQuery();

            if (query.next()) {
                HashMap<String, String> fileTypeInfo = new HashMap<String, String>();
                String active = query.getColValue("active_flg");
                if (!active.equals("1")) {
                    String errorMsg = "Letter File Type ID " + fileTypeID + " is not active for Evaluator ID " + Integer.toString(STATE_FARM_EVALUATOR);
                    throw new RuntimeException(errorMsg);
                }

                letterDescText = query.getColValue("letter_desc_txt");
                letterFileTypeDesc = query.getColValue("letter_file_type_txt");
                letterID = query.getColValue("letter_id");
                letterStylesheet = query.getColValue("stylesheet_txt");
                letterXMLTrans = query.getColValue("xml_trans");
                letterXMLTrans = letterXMLTrans.replaceAll("\\|", ",");

                if (log_obj.isDebuggingEnabled(i_dbg_level, 5)) {
                    log_obj.FmtAndLogMsg("LetterExtract letter_desc_txt: " + letterDescText);
                    log_obj.FmtAndLogMsg("LetterExtract letter_file_type_id: " + fileTypeID);
                    log_obj.FmtAndLogMsg("LetterExtract letter_file_type_txt: " + letterFileTypeDesc);
                    log_obj.FmtAndLogMsg("LetterExtract stylesheet_txt: " + letterStylesheet);
                    log_obj.FmtAndLogMsg("LetterExtract xml_txt: " + letterXMLTrans);
                }
            } else {
                letterDescText = "";
                letterFileTypeDesc = "";
                letterID = "";
                letterStylesheet = "";
                letterXMLTrans = "";
                throw new RuntimeException("No Stylesheet information found for letter_file_type_id " + fileTypeID);
            }
        } catch (Exception e) {
            throw new RuntimeException("Error executing setLetterInformationForFileType query", e);
        }
    }

    /**
     * Processes the stubs for this touchpoint. This is what writes "Successfully added DocID=__" to the journal
     * 
     * @param touchpointID
     *            Touchpoint ID.
     * @param document_id
     *            Document ID.
     * @param letterFileTypeID
     *            Letter File Type ID.
     * @param genx
     *            GenX object.
     * @return The XML of the documents as a string.
     * @throws Exception
     */
    protected String processStubs(String touchpointID, String document_id, String letterFileTypeID, GenX genx) throws Exception {
        String combinedXML = "";
        ArrayList<String> docs = new ArrayList<String>();
        String revalWtu = "0";
        String select = 
            "SELECT DISTINCT crdh.seq_id, crdh.document_id, cr.request_id, " + 
            "cd.letter_id, clt.letter_desc_txt " +  
            "FROM credit_request cr, credit_req_doc_history crdh, config_documents cd, " +  
            "config_letter_type clt " +  
            "WHERE cr.evaluator_id = ? " +
            "AND cr.request_id = crdh.request_id " +
            "AND crdh.document_id = cd.document_id " +
            "AND crdh.evaluator_id = cd.evaluator_id " +
            "AND crdh.document_id IN (" + document_id +
                ") " +
            "AND crdh.evaluator_id = cr.evaluator_id " + 
            "AND cd.letter_file_type_id = ? " + 
            "AND crdh.status_id = 'INPROCESS' " + 
            "AND crdh.submit_reason_id = 30 " + 
            "AND cr.evaluator_id = clt.evaluator_id " + 
            "AND cd.letter_file_type_id = clt.letter_file_type_id " + 
            "AND cd.letter_id = clt.letter_id ";

        log_obj.FmtAndLogMsg(letterID + " <<DOC HISTORY QUERY>>: " + select + "\n");
        Query query = new Query(connection);
        query.prepareStatement(select);
        query.setInt(1, STATE_FARM_EVALUATOR);
        int placeCt = 2;
        for (String param : docs) {
            if (param.startsWith("'")) {
                query.setString(placeCt++, param.substring(1, param.length() - 1)); // no need for OWASP validation since Query does that by default
            } else {
                query.setInt(placeCt++, Integer.valueOf(param));
            }
        }
        query.setInt(placeCt++, letterFileTypeID);
        query.executePreparedQuery();
        // query.executeQuery(select);

        boolean passesWtu = true;
        String request_id;
        String seq_id;
        String letter_id;
        String letter_desc;

        while (query.next()) {
            request_id = query.getColValue("request_id");
            document_id = query.getColValue("document_id");
            seq_id = query.getColValue("seq_id");
            letter_id = query.getColValue("letter_id");
            letter_desc = query.getColValue("letter_desc_txt");
            String failureMsg = "";
            log_obj.FmtAndLogMsg("docid = " + document_id + "touchpointid = " + touchpointID + "evalid = " + STATE_FARM_EVALUATOR);
            String s_xml = "";

            log_obj.FmtAndLogMsg("docid = " + document_id + "touchpointid = " + touchpointID + "evalid  = " + STATE_FARM_EVALUATOR + " revalWtu = " + revalWtu + " passesWtu = " + passesWtu);

            if (passesWtu) {
                try {
                    log_obj.FmtAndLogMsg("RID=" + request_id + ", DOCID=" + document_id + ", Extracting XML from database...");
                    s_xml = getXMLStr(request_id, genx);
                    // replace non-printable chars in the xml...genx encodes ascii char so match &#25; for example
                    s_xml = s_xml.replaceAll("&#[0-3][0-9];", "");
                    // remove the xml version/encoding type declaration
                    s_xml = s_xml.replaceFirst("<\\?xml.*\\?>[\\n\\r]*", "");
                    // put the letter_id into the IFX tag
                    s_xml = s_xml.replaceAll("<IFX>", "<IFX Type=\"" + letter_id + "\" Description=\"" + letter_desc + "\">");
                    log_obj.FmtAndLogMsg("RID=" + request_id + ", DOCID=" + document_id + ", Done Extracting XML from database...");
                    combinedXML = combinedXML.concat(s_xml);
                    transactionCount++;
                } catch (Exception e) {
                    failureMsg = "Exception getting XML: " + e.toString();
                    if (failureMsg.length() >= 300) {
                        failureMsg = failureMsg.substring(0, 297) + "...";
                    }
                }

                String sql = "UPDATE credit_req_doc_history SET " +
                        "status_id = ?, error_txt = ?, print_date = sysdate " + 
                        "where seq_id = ? ";

                SQLUpdate sqlUpdate = new SQLUpdate();
                sqlUpdate.SetPreparedUpdateStatement(connection, sql);
                sqlUpdate.setString(1, failureMsg.length() > 0 ? "ERROR" : "SUCCESS");
                sqlUpdate.setString(2, failureMsg);
                sqlUpdate.setInt(3, Integer.parseInt(seq_id));
                sqlUpdate.RunPreparedUpdateStatement();

                // Adding Journal Entry
                JournalEvents journal = new JournalEvents(connection, null);
                String journalTxt;
                if (failureMsg.length() > 0) {
                    journalTxt = "Error adding DocID=" + document_id + " to letter extract.";
                } else {
                    journalTxt = "Successfully added DocID=" + document_id + " to letter extract.";
                }
                journal.addJournal(Integer.parseInt(request_id), 107, journalTxt, "SYSTEM");

                // Adding Comments Entry
                CommentEvents comment = new CommentEvents(connection, log_obj);
                String commentHeader = "";
                String commentTxt = "";
                if (failureMsg.length() > 0) {
                    commentHeader = "Letter Extract (Data) Error";
                    commentTxt = "Error adding DocID=" + document_id + " to letter extract.";
                } else {
                    commentHeader = "Letter Extract (Data) Success";
                    commentTxt = "Successfully added DocID=" + document_id + " to letter extract.";
                }
                comment.addComment(Integer.parseInt(request_id), 89, commentHeader, commentTxt, "SYSTEM", "", "");

                log_obj.FmtAndLogMsg("Updated CREDIT_REQ_DOC_HISTORY for RID=" + request_id + ", DOCID=" + document_id + ", STATUS=" + (failureMsg.length() > 0 ? "ERROR" : "SUCCESS"));
            } else { // if doc does not pass reeval of WTU

                String sql = "UPDATE credit_req_doc_history SET " + "status_id = ?, error_txt = ?, print_date = sysdate " + "where seq_id = ? ";

                SQLUpdate sqlUpdate = new SQLUpdate();
                sqlUpdate.SetPreparedUpdateStatement(connection, sql);
                sqlUpdate.setString(1, "SYSTEM CANCELLED");
                sqlUpdate.setString(2, "System Cancelled");
                sqlUpdate.setInt(3, Integer.parseInt(seq_id));
                sqlUpdate.RunPreparedUpdateStatement();

                JournalEvents journal = new JournalEvents(connection, null);
                journal.addJournal(Integer.parseInt(request_id), 107, "Cancel adding DocID=" + document_id + " to letter extract by System.", "SYSTEM");
            }
        }
        return combinedXML;
    }

    /**
     * Adds a record to the Doc_History table that this document has been generated.
     * 
     * @param request_id
     *            Request ID.
     * @param document_id
     *            Document ID.
     * @param failureMsg
     *            The failure message, if exists.
     * @param submit_reason_id
     *            Submit Reason ID.
     */
    protected void addDocHistoryRecord(int request_id, int document_id, String failureMsg, int submit_reason_id) {
        String sql = "INSERT INTO credit_req_doc_history (" + 
                "request_id, create_dt, document_id, status_id, error_txt, user_id, " + 
                "print_date, submit_reason_id, evaluator_id, job_type_txt) VALUES (" + 
                "?, sysdate, ?, ?, ?, 'SYSTEM', sysdate, ?, ?, 'Letter Extract') ";

        try {
            getDatabaseConnection();
            SQLUpdate sqlUpdate = new SQLUpdate();
            sqlUpdate.SetPreparedUpdateStatement(connection, sql);
            sqlUpdate.setInt(1, request_id);
            sqlUpdate.setInt(2, Integer.valueOf(document_id));
            sqlUpdate.setString(3, failureMsg.length() > 0 ? "ERROR" : "SUCCESS");
            sqlUpdate.setString(4, failureMsg);
            sqlUpdate.setInt(5, Integer.valueOf(submit_reason_id));
            sqlUpdate.setInt(6, STATE_FARM_EVALUATOR);
            sqlUpdate.RunPreparedUpdateStatement();

            // Adding Journal Entry
            JournalEvents journal = new JournalEvents(connection, null);
            String journalTxt;
            if (failureMsg.length() > 0) {
                journalTxt = "Error adding DocID=" + document_id + " to letter extract.";
            } else {
                journalTxt = "Successfully added DocID=" + document_id + " to letter extract.";
            }
            journal.addJournal(request_id, 107, journalTxt, "SYSTEM");

            // Adding Comment Entry
            CommentEvents comment = new CommentEvents(connection, log_obj);
            String commentHeader = "";
            String commentTxt = "";
            if (failureMsg.length() > 0) {
                commentHeader = "Letter Extract (Data) Error";
                commentTxt = "Error adding DocID=" + document_id + " to letter extract.";
            } else {
                commentHeader = "Letter Extract (Data) Success";
                commentTxt = "Successfully added DocID=" + document_id + " to letter extract.";
            }
            comment.addComment(request_id, 89, commentHeader, commentTxt, "SYSTEM", "", "");
        } catch (Exception e) {
            throw new RuntimeException("Error executing addDocHistoryRecord query", e);
        }
        log_obj.FmtAndLogMsg("Inserted CREDIT_REQ_DOC_HISTORY for RID=" + request_id + ", DOCID=" + document_id + ", STATUS=" + (failureMsg.length() > 0 ? "ERROR" : "SUCCESS"));
    }

    /**
     * This will return a comma delimited list of decryption fields If no records are found, or the stylesheet is not active a RuntimeException will
     * be thrown.
     * 
     * @return A map with the following information for the fileTypeID passed in letterFileTypeDesc - LETTER_FILE_TYPE_TEXT styleSheet - Fully path to
     *         stylesheet.
     */
    protected String getDecryptionFields() {
        if (StringUtils.isBlank(decryptionFields)) {
            String sql = "select ssn_flg,bank_flg,drivers_flg from config_encryption where evaluator_id = ?";

            int ssn_flg = 0;
            int bank_flg = 0;
            int drivers_flg = 0;

            try {
                getDatabaseConnection();
                Query query = new Query(connection);
                query.prepareStatement(sql);
                query.setInt(1, STATE_FARM_EVALUATOR);
                query.executePreparedQuery();

                if (query.next()) {
                    ssn_flg = Integer.parseInt(query.getColValue("ssn_flg", "0"));
                    bank_flg = Integer.parseInt(query.getColValue("bank_flg", "0"));
                    drivers_flg = Integer.parseInt(query.getColValue("drivers_flg", "0"));
                } else {
                    throw new RuntimeException("Decryption fields not found for evaluator " + Integer.toString(STATE_FARM_EVALUATOR));
                }

            } catch (Exception e) {
                throw new RuntimeException("Error executing getDecryptionFields query");
            }

            // Check encryption fields from table and add them into decryptionFields so XML is totally decrypted,
            if (ssn_flg == 1) {
                decryptionFields = decryptionFields + "ssn";
            }
            if (bank_flg == 1) {
                if (StringUtils.isBlank(decryptionFields)) {
                    decryptionFields = decryptionFields + "bank";
                } else {
                    decryptionFields = decryptionFields + ",bank";
                }
            }
            if (drivers_flg == 1) {
                if (StringUtils.isBlank(decryptionFields)) {
                    decryptionFields = decryptionFields + "drivers";
                } else {
                    decryptionFields = decryptionFields + ",drivers";
                }
            }
        }

        if (log_obj.isDebuggingEnabled(i_dbg_level, 5)) {
            log_obj.FmtAndLogMsg("decryptionFields: " + decryptionFields);
        }

        return decryptionFields;
    }

    /**
     * Gets XML transactions for the app.
     * 
     * @param request_id
     *            Request ID.
     * @param genx
     *            A genx object.
     * @return String containing xml transactions.
     * @throws Exception
     *             Throws an exception if there is an issue running genx.getXMLorThrow().
     */
    protected String getXMLStr(String request_id, GenX genx) throws Exception {
        String decision_ref_id = "";
        String s_xml = "";

        try {
            genx.ResetParams();
            genx.bSetParam("REQUEST_ID", request_id);

            // If a final decision has been made then include it in the xml
            decision_ref_id = getDecRefID(request_id, Integer.toString(STATE_FARM_EVALUATOR));

            if (decision_ref_id.length() > 0) {
                genx.bSetParam("DECISION_REF_ID", decision_ref_id);
            }

            if (encryption_flg) {
                String decryptionFields = getDecryptionFields();
                genx.setEncryptionParms((iniFile.getINIVar("database.user", "")).toLowerCase(), decryptionFields);
            }

            s_xml = genx.sGetXMLorThrow(letterXMLTrans, genx.build_type_xml);

            // replace non-printable chars in the xml...genx encodes ascii char so match &#25; for example
            s_xml = s_xml.replaceAll("&#[0-3][0-9];", "");
            // remove the xml version/encoding type declaration
            s_xml = s_xml.replaceFirst("<\\?xml.*\\?>[\\n\\r]*", "");
            // put the letter_id into the IFX tag
            s_xml = s_xml.replaceAll("<IFX>", "<IFX Type=\"" + letterID + "\" Description=\"" + letterDescText + "\">");
            if (log_obj.isDebuggingEnabled(i_dbg_level, 5)) {
                log_obj.FmtAndLogMsg("Done extracting XML from database");
            }
        } catch (Exception e) {
            throw e;
        }
        return s_xml;
    }

    /**
     * Gets the latest dec_ref_id for the app if exists.
     * 
     * @param request_id
     *            Request ID.
     * @param evaluator_id
     *            Evaluator ID.
     * @return Decision ref id if exists, otherwise empty string.
     * @throws Exception
     *             Throws an exception if there was an issue executing the query.
     */
    protected String getDecRefID(String request_id, String evaluator_id) throws Exception {
        String decision_ref_id = ""; // default to none
        String sql = "";
        Query query = new Query(connection);

        try {
            // If a final decision has been made then include it in the xml
            sql=    "SELECT MAX(crde.decision_ref_id) dec_ref_id " +
                    "FROM credit_req_decisions_evaluator crde " +
                    "WHERE crde.evaluator_id = ? " +
                    "AND crde.request_id = ? " +
                    "AND (((crde.decision_id IN (0,1,2,3)) AND crde.decision_category_id = 2) " +
                        "OR ((crde.decision_id IN (102,103)) AND crde.decision_category_id = 1 " +
                            "AND crde.requestor_id = (select rh.requestor_id from requestor_header rh where rh.request_id = crde.request_id and (rh.requestor_type_id in (0,3)))))";
            query.prepareStatement(sql);
            query.setInt(1, evaluator_id);
            query.setInt(2, request_id);
            query.executePreparedQuery();
            if (query.next()) {
                decision_ref_id = query.getColValue("dec_ref_id", "");
            }
        } catch (Exception e) {
            throw e;
        }

        return decision_ref_id;
    }

    /**
     * Applies the letter stylesheet to the XML for identified the RequestIds and writes the output file.
     * 
     * @param xml
     *            XML containing the RequestId information to be included in the output file.
     * @param letterFileTypeID
     *            FileTypeID of the letter to be outputted.
     * @throws Exception
     *             Throws an exception if there was an issue with applying the XSL.
     */
    protected void produceLetterOutputFile(String xml, String letterFileTypeID) throws Exception {
        String header = "<?xml version=\"1.0\" encoding=\"ISO-8859-1\"?><CMSI><HeaderInfo>" + 
                "<LetterFileTypeId>"+letterFileTypeID+"</LetterFileTypeId>" + 
                "<LetterFileType>"+letterFileTypeDesc+"</LetterFileType>" + 
                "<LetterCount>"+transactionCount+"</LetterCount>" + 
                "</HeaderInfo><Apps>";
        xml = (header.concat(xml)).concat("</Apps></CMSI>");
        String styledXML = xml; // Giving this a default value of what xml was. If we left this blank by default, there is a chance we print an empty string into the PrintWriter.

        // Apply stylesheet to xml if configured
        if (StringUtils.isNotEmpty(letterStylesheet)) {
            log_obj.FmtAndLogMsg("Letter Extract: Applying stylesheet..." + letterStylesheet);
            try {
                styledXML = sApplyXSL(xml, letterStylesheet);
                log_obj.FmtAndLogMsg("Letter Extract: Done Applying stylesheet..." + letterStylesheet);
            } catch (Exception e) {
                log_obj.FmtAndLogMsg("Letter Extract: Exception Applying stylesheet: " + e.toString(), e);
            }
        } else {
            log_obj.FmtAndLogMsg("Letter Extract: No stylesheet configured. Skipping styling XML.");
        }

        String saveFileName = outputDirectory + letterFileTypeDesc + "_" + new SimpleDateFormat("yyyyMMddHHmmss").format(new Date()) + ".txt";
        log_obj.FmtAndLogMsg("Saving XML to output directory: " + saveFileName);
        saveXMLToOutputDir(saveFileName, styledXML);
        log_obj.FmtAndLogMsg("Done saving XML to output directory.");
    }

    /**
     * Writes out the styled XML to the output directory.
     * 
     * @param saveFileName
     *            Directory to save to.
     * @param styledXML
     *            The styled XML as a string.
     * @throws Exception
     *             Throws an exception if there was an issue with saving to file.
     */
    protected void saveXMLToOutputDir(String saveFileName, String styledXML) throws Exception {
        PrintWriter saveFile = new PrintWriter(new BufferedWriter(new FileWriter(OWASPSecurity.validationCheck(saveFileName, OWASPSecurity.DIRANDFILE), false)));
        saveFile.print(styledXML);
        saveFile.flush();
        saveFile.close();
    }
}