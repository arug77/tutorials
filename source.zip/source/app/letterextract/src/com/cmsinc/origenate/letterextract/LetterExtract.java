/**
 * LetterExtract standalone program
 * 
 * For the passed in Letter File Type ID, this program runs through each
 * of the Letter Extract touchpoints and gets documents (letters) assigned
 * to those touchpoints. If the document has been submitted for processing,
 * then it will be included in the letter extract. So for each touchpoint,
 * we find letters at that touchpoint that are to be included and whose
 * apps pass the selection criteria for the touchpoint. We then check the
 * WTU queries for each of the documents as a final check for whether they
 * should be included. We then generate XML transactions using GenX based
 * on the configured transactions for the Letter File Type ID.
 * After getting all letters for all touchpoints, we create one large XML
 * file and style it if there is a configured stylesheet for the Letter
 * File Type ID. We write the final XML to the output directory.
 * 
 * Parameters:
 * INI File
 * Evaluator ID
 * Letter File Type ID
 * Output Directory (without the final / at the end of the path)
 * Debug Flag (Optional)
 * 
 * Author: Mike Swain
 * Date: 1/3/2012
 * Version: 1.2
 * 
 * Modification History:
 * 1. 03/16/2012 - Mike Swain
 * Changing the logic in how we select apps for inclusion in the letter file.
 * We are now running the selection criteria independent of the documents the
 * user selected as submitted for processing. Any apps selected are run through
 * their WTU query. If they pass, they are included. Next, we select all documents
 * that the user selected for inclusion. Those are included regardless of
 * whether they pass the selection criteria or WTU query.
 * 2. 11/14/2013 - Mike Swain
 * The touchpoint threads were not filtering the letters by the letter file
 * type. This was causing letters from a file to be included in files for
 * which they were not configured. Since the doc history prevents letters from
 * being generated multiple times, once they were included in the wrong file
 * they were not being put into the correct file.
 * 3. 11/14/2013 - Mike Swain (code change by Chris Kurbiel)
 * Changed the letter file type id startup parameter to be a comma separated
 * list. The Letter Extract will process each letter file type id provided
 * in the list and generate a file for each as if they had been passed in
 * separately.
 */

package com.cmsinc.origenate.letterextract;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Enumeration;
import java.util.StringTokenizer;
import java.util.Vector;


import com.cmsinc.origenate.cp.mpe.ApplyXSLListener;
import com.cmsinc.origenate.util.COLEncrypt;
import com.cmsinc.origenate.util.IniFile;
import com.cmsinc.origenate.util.LogMsg;
import com.cmsinc.origenate.util.Query;
import com.cmsinc.origenate.xmldbt.TransformerUtils;
import com.cmsinc.origenate.util.OWASPSecurity;

public class LetterExtract {

	static String VERSION = "1.2";
	
	String sHost = "";
	String sSIDname = "";
	String sUser = "";
	String sPass = "";
	String sPort = "";
	String sTNSEntry = "";
	String sIniFile = "";
	String saveDir = "";
	int runningThreads = 0;
	int i_dbg_level = 0;
	IniFile ini = new IniFile();
	Vector<ProcessThread> processThreads = null;
	LogMsg log_obj = new LogMsg();
	String evaluatorID = "";
	String letterIdList = "";
	String letterFileTypeDesc = "";
	String stylesheet = "";
	String xmlTrans = "";
	String queryID = "";
	boolean encryption_flg = false;
	
	String xml = "";
	int transactionCount = 0;
	
	public LetterExtract() {
	}
	
	
	public static void main(String[] args) {
		LetterExtract le = new LetterExtract();
		try {
			le.run(args);
		} catch(Exception e) {
			e.printStackTrace();
		}
		
		System.exit(0);
	}
	
	public synchronized void log(int level, String msg) {
		log_obj.FmtAndLogMsg(msg, i_dbg_level, level);
	}
	
	public synchronized void log(int level, String msg, Throwable throwable) {
		log_obj.FmtAndLogMsg(msg, throwable, i_dbg_level, level);
	}
	
	public synchronized int threadCount(boolean decreaseCount) {
		if(decreaseCount) {
			runningThreads--;
		}
		return runningThreads;
	}
	
	public synchronized void appendToXML(String touchpointXML) {
		xml = xml.concat(touchpointXML);
	}
	
	public synchronized int getTransactionCount() {
		return transactionCount;
	}
	
	public synchronized void updateTransactionCount(int inc) {
		transactionCount += inc;
	}
	
	public void run(String[] args) throws Exception {
		Connection con = null;
		
		log(0, "LetterExtract initializing...");
		
		GetArgs(args, log_obj);
		
		String sConStr = "jdbc:oracle:thin:@";
		if (sTNSEntry.length() == 0) {
			sConStr = sConStr + sHost + ":" + sPort + ":" + sSIDname;
		} else {
			sConStr = sConStr + sTNSEntry;
			log(0, "Using TNS Entry");
		}
		
		try {
			// Load Oracle driver
			DriverManager.registerDriver(new oracle.jdbc.OracleDriver());
			
			log(0, "Connecting to database: " + sConStr);
			
			sPass = COLEncrypt.sDecrypt(sPass);
			
			// Connect to the Oracle database
			con = DriverManager.getConnection(sConStr, sUser, sPass);
		} catch (Exception e) {
			log(0, "Error connecting to database: " + e.toString(), e);
			throw e;
		}
		
		log(0, "LetterExtract: Starting letter threads...");
		
		StringTokenizer t = new StringTokenizer(letterIdList, ",");
		String letterFileTypeID;
		
		while (t.hasMoreTokens()) {
			letterFileTypeID = t.nextToken().toUpperCase();
			runningThreads = 0;
			transactionCount = 0;
			xml = "";
			processThreads = new Vector<ProcessThread>();
			
			String sql = "select xml_trans, stylesheet_txt, letter_file_type_txt, " +
				"active_flg from config_letter_file_type " + 
				"where evaluator_id = ? and letter_file_type_id = ? ";
			try {
				Query tempQuery = new Query(con);
				tempQuery.prepareStatement(sql);
				tempQuery.setInt(1, Integer.valueOf(evaluatorID));
				tempQuery.setInt(2, Integer.valueOf(letterFileTypeID));
				tempQuery.executePreparedQuery();
				
				if(tempQuery.next()) {
					String active = tempQuery.getColValue("active_flg","");
					if(!active.equals("1")) {
						String errorMsg = "Letter File Type ID " + letterFileTypeID + 
											" is not active for Evaluator ID " +
											evaluatorID + ".";
						log(0, errorMsg);
						throw new Exception(errorMsg);
					}
					letterFileTypeDesc = tempQuery.getColValue("letter_file_type_txt","");
					stylesheet = tempQuery.getColValue("stylesheet_txt", "");
					xmlTrans = tempQuery.getColValue("xml_trans", "");
					xmlTrans = xmlTrans.replaceAll("\\|", ",");
					log(5, "LetterExtract Stylesheet: " + stylesheet);
					log(5, "LetterExtract XML Transactions to generate: " + xmlTrans);
				} else {
					throw new Exception("Evaluator ID does not match Letter File Type ID.");
				}
			} catch (Exception e) {
				log(0, "LetterExtract: Error parsing Evaluator ID and Letter File Type ID parameters. Error: " + e.toString(), e);
				throw e;
			}
			
			String deliveryMethod = "L";
			// Get the Letter Extract touchpoints from the DB
			Query query = new Query(con);
			sql = "select distinct(ctd.touchpoint_id) touchpoint_id , mt.touchpoint_desc_txt from config_touchpoint_documents ctd, mstr_touchpoints mt "+ 
					" where ctd.touchpoint_id in (64,65,66,67,68,69,70,71,72,73,74,75,76,77,78,80,81,92,93,94,95,96,97,98,99,100) and ctd.delivery_method_id = ? and ctd.evaluator_id = ? and mt.touchpoint_id = ctd.touchpoint_id ";
			query.prepareStatement(sql);
			query.setString(1,deliveryMethod);
			query.setInt(2, Integer.valueOf(evaluatorID));			
			query.executePreparedQuery();
			while(query.next()) {
				// Create the thread but don't start running it yet
				Integer touchpoint_id = Integer.valueOf(query.getColValue("touchpoint_id", ""));
				String touchpoint_desc_txt = query.getColValue("touchpoint_desc_txt", "");
				ProcessThread pt = new ProcessThread(this, sConStr, sUser, sPass, 
							touchpoint_id, touchpoint_desc_txt, log_obj, queryID, letterFileTypeID);
				processThreads.addElement(pt);
				runningThreads++;
			}
			
			// Letter File Type ID and Evaluator ID are valid, so we'll start
			
			ProcessThread pt;
			
			// Start each thread now
			for(Enumeration<ProcessThread> e = processThreads.elements(); e.hasMoreElements();) {
				pt = e.nextElement();
				pt.start();
			}
			
			// Wait for all threads to finish. They should update this class when done.
			
			// Wait for threads to end
			while(true) {
				if(threadCount(false) <= 0) {
					break;
				}
				
				// sleep 3 seconds
				try {
					Thread.sleep(3000);
				} catch (Exception e){
					e.printStackTrace();
				}
			}
			
			// Now that they are all done, we need to generate the header and then
			// style the entire thing. Then save to disk.
			
			String header = "<?xml version=\"1.0\" encoding=\"ISO-8859-1\"?><CMSI><HeaderInfo>" + 
					"<LetterFileTypeId>"+letterFileTypeID+"</LetterFileTypeId>" + 
					"<LetterFileType>"+letterFileTypeDesc+"</LetterFileType>" + 
					"<LetterCount>"+transactionCount+"</LetterCount>" + 
					"</HeaderInfo><Apps>";
			xml = (header.concat(xml)).concat("</Apps></CMSI>");
			
			// Apply stylesheet to xml if configured
			if(stylesheet.length() > 0) {
				log(0,"Letter Extract: Applying stylesheet..."+stylesheet);
				try {
					xml=sApplyXSL(xml,stylesheet);
					log(0,"Letter Extract: Done Applying stylesheet..."+stylesheet);
				} catch(Exception e) {
					log(0, "Letter Extract: Exception Applying stylesheet: "+e.toString(), e);
				}
			} else {
				log(0,"Letter Extract: No stylesheet configured. Skipping styling XML.");
			}
			
			String saveFileName=saveDir+letterFileTypeDesc+"_"+new SimpleDateFormat("yyyyMMddHHmmss").format(new Date())+".txt";
	        log(0,"Saving XML to output directory: "+saveFileName);
	        PrintWriter saveFile = null;
	        
	        /**		
	         * OWASP TOP 10 2010 - A4 Path Manipulation
		     * Changes to the below code to fix vulnerabilities
		     * TTP 324955
		     **/
	        //saveFile = new PrintWriter(new BufferedWriter(new FileWriter(saveFileName,false)));
	        //saveFile = new PrintWriter(new BufferedWriter(new FileWriter(Encode.forJava(saveFileName),false)));
	        saveFile = new PrintWriter(new BufferedWriter(new FileWriter(OWASPSecurity.validationCheck(saveFileName, OWASPSecurity.DIRANDFILE),false)));
	        saveFile.print(xml);
	        saveFile.flush();
	        saveFile.close();
	        log(0,"Done saving XML to output directory.");
		}
		// Done
		try {
			if(con != null) {
				con.close();
			}
		} catch (Exception e1){
			e1.printStackTrace();
		}
		
		log(0, "LetterExtract (Data) exiting.");
	}
	
	private void GetArgs(String args[], LogMsg log_obj) {
		if(args.length > 0) {
			for(int i = 0; i < args.length; i++) {
				if((args[i].charAt(0) != '-') && (args[i].length() > 1)) {
					ShowUsage();
				}
				
				switch(args[i].charAt(1)) {
				
				case 'i':
					sIniFile = args[i].substring(2);
					log(0, "IniFile is '" + sIniFile + "'");
					try {
						// Read host, user, sid and password from ini file
						ini.readINIFile(sIniFile);
						
						String logFile = ini.getINIVar("logs.letter_extract_log_file", "");
						if(logFile.length() > 0) {
							log_obj.openLogFile(logFile);
						}
						
						log(0, "LetterExtract version " + VERSION + " initializing...");
						
						sHost = ini.getINIVar("database.host", "");
						log(0, "Host is '" + sHost + "'");
						
						sPort = ini.getINIVar("database.port", "");
						log(0, "Port is '" + sPort + "'");
						
						sUser = ini.getINIVar("database.user", "");
						log(0, "User is '" + sUser + "'");

						sPass = ini.getINIVar("database.password", "");
						// log(0,"Password:"+sPass);

						sSIDname = ini.getINIVar("database.sid", "");
						log(0, "Database (SID name) is '" + sSIDname + "'");

						sTNSEntry = ini.getINIVar("database.TNSEntry", "");
						log(0, "TNS Entry is '" + sTNSEntry + "'");
						
						encryption_flg = ini.getINIVar("encryption.encryption_flg","").equals("1");
						log(0, "Encryption (true/false) is '" + encryption_flg + "'");
					} catch(Exception e) {
						log(0, "Caught exception reading ini file '" + sIniFile + "': " + e.toString(), e);
					}
					break;
					
				case 'd': //turn debug on
					i_dbg_level = 5;
					log(0, "debugging turned on");
					break;
					
				case 'e': //evaluator id
					evaluatorID = args[i].substring(2);
					log(0, "Evaluator ID: " + evaluatorID);
					break;
					
				case 'l': //letter file type id
					letterIdList = args[i].substring(2);
					log(0, "Letter File Type IDs: " + letterIdList);
					break;
					
				case 'o': //output directory
					saveDir = args[i].substring(2);
					saveDir += File.separator;
					log(0, "Output Dir: " + saveDir);
					break;
					
				case 'q': //query id
					queryID = args[i].substring(2);
					log(0, "Query ID: " + queryID);
					break;
					
				default:
					log(0, "Unknown parameter: " + args[i]);
					ShowUsage();
					break;
				} // end case
			} // end for loop
			
			//edits
			if ((sHost.length() == 0) || (sUser.length() == 0)
					|| (sSIDname.length() == 0) || (sPort.length() == 0)) {
				log(0, "Host,User,Pwd,SID or Port not specified in INI file");
				ShowUsage();
			}
			if (letterIdList.length() == 0) {
				log(0, "-l parm is required");
				ShowUsage();
			}
			if (evaluatorID.length() == 0) {
				log(0, "-e parm is required");
				ShowUsage();
			}
			if (saveDir.length() == 0) {
				log(0, "-o parm is required");
				ShowUsage();
			}
		} // end if
		else {
			ShowUsage();
		}
	}
	
	private void ShowUsage() {
		System.out.println();
		System.out.println("Usage: java LetterExtract -i<inifile> -e<evaluator id> -l<letter file type id> -o<path to output directory> [-q<query id>] [-d]");
		System.out.println("---------------------");
		System.out.println("-i - required: INI file to use for configuration");
		System.out.println("-e - required: evaluator id");
		System.out.println("-l - required: letter file type id list separated by commas (-l1,2,3,4)");
		System.out.println("-o - required: path to the output directory (-o/opt/origenate/or_example87/data/letterextract)");
		System.out.println("-q - optional: query id for General Notification Letter selection (Default is 0)");
		System.out.println("-d - optional: turns debug messages on. (Default is off)");
		System.exit(1);
	}
	
	public String sApplyXSL(String s_xml, String s_xsl) throws Exception {
		String s_ret=null;

		ApplyXSLListener listener = new ApplyXSLListener();
		try {
			s_ret = TransformerUtils.toString(s_xml,s_xsl);
		} catch (Exception e) {
			String s_msg = listener.getMessage();
			if (s_msg==null) s_msg="";
			throw new Exception (e.toString()+" listener msg:"+s_msg, e);
		}
		
		return s_ret;
	} // sApplyXSL
	
}
