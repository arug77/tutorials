
PATH=$PATH:$JAVA_HOME/bin;            export PATH

nohup java -classpath .:../lib/commons-lang-2.1.jar:../lib/ojdbc6.jar:../lib/common.jar:../lib/classes111.jar:../lib/crypto.jar:../lib/xercesImpl-2.10.0.jar:../lib/bsf-2.4.0.jar:../lib/xmlsec-1.4.4.jar:../lib/xalan.jar:../lib/xml-apis-2.10.0.jar:../lib/js-1.6R7.jar com.cmsinc.origenate.letterextract.LetterExtract  -iC:\JRun4\servers\cfusion\cfusion-ear\cfusion-war\config\origenate.ini -e65 -l1 -oC:\opt\origenate\or_dev87\data\letterextract\output >>err.out >>err.out & 
