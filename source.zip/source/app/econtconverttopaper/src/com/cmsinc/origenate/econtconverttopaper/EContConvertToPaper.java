/**
 * EContConvertToPaper.java
 * Date: 04/16/2012
 * Author: Mike Swain
 *
 * This program gets all applications with an electronic contract
 * type that meet the following criteria:
 * Is currently assigned an eError contract status and is assigned to
 * a task in the CONTRACTADMIN task group and the number of days between
 * the current system date and the date the status was assigned is equal
 * to or greater than the eError Delay Days parameter in the Company tool
 * OR
 * Is assigned eReturn and the days between the current date and the date
 * the status was assigned is equal to or greater than the eReturn Delay
 * Days parameter in the Company tool.
 * The days between the system date and the date the status was assigned
 * is floored. So 2.6 days is seen as 2 full days, not 3. The flooring
 * doesn't affect the logic, since if the delays days is 2, then 2.6 >= 2
 * and floor(2.6) >= 2 are both true.
 * For each app selected, we attempt to convert the app to paper by doing
 * the following steps:
 * 1. Set the Cancel flag to "L" for lender
 * 2. Change the contract type from electronic to paper
 * 3. Enable the Contract Info screen. This is done by step (2)
 * 4. Lookup the "Delete eContract When Converted to Paper" flag. If the
 * 	flag is set, delete all contract and insurance data
 * 5. Update the booking status as follows:
 * 	a. If the booking status is not PENLOG and the app was previously logged,
 * 		set the booking status to PENLOG
 * 	b. If the booking status is not PENLOG and the app wasn't previously logged,
 * 		assign a PENBKD booking status
 * 6. Write a Convert to Paper Journal entry
 * 7. Write a Convert to Paper System Comment
 * 8. Generate and post an XML transcation to the eContract source informing
 * 	the dealer of the eContract cancellation
 * 9. Check the -c input parameter. If set, initiate a Task/Team/User call
 * 	and redirect the application if applicable
 * These steps are essentially copying the steps taken within Origenate
 * when a user selects to Convert an app to Paper via the Contract Manager
 * in the UI
 */

package com.cmsinc.origenate.econtconverttopaper;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import com.cmsinc.origenate.event.CommentEvents;
import com.cmsinc.origenate.event.JournalEvents;
import com.cmsinc.origenate.util.COLEncrypt;
import com.cmsinc.origenate.util.IniFile;
import com.cmsinc.origenate.util.LogMsg;
import com.cmsinc.origenate.util.PostRequest;
import com.cmsinc.origenate.util.Query;
import com.cmsinc.origenate.util.SQLUpdate;
import com.cmsinc.origenate.workflow.ApplicationStatusManager;
import com.cmsinc.origenate.util.SQLSecurity;

public class EContConvertToPaper {
	private static String VERSION = "1.0";

	private String evaluatorID = "";
	private LogMsg log_obj = new LogMsg();;
	private String sHost = "";
	private String sSIDname = "";
	private String sUser = "";
	private String sPass = "";
	private String sPort = "";
	private String sTNSEntry = "";
	private String sIniFile = "";
	private int i_dbg_level = 0;
	private IniFile ini = new IniFile();
	private String logFile = "";
	private CommentEvents comment = null;
	private JournalEvents journal = null;
	private boolean redirect = false;

	private int convertApps(Connection con) throws Exception {

		int eErrorDelayDays = -1, eReturnDelayDays = -1;

		SQLUpdate update;
		Query query = new Query(con);
		String sql = "select eerror_delay_days_num, ereturn_delay_days_num " +
				"from evaluator where evaluator_id = ? ";
		query.prepareStatement(sql);
		query.setInt(1, evaluatorID);
		query.executePreparedQuery();
		if(query.next()) {
			eErrorDelayDays = Integer.valueOf(query.getColValue("eerror_delay_days_num","-1"));
			eReturnDelayDays = Integer.valueOf(query.getColValue("ereturn_delay_days_num","-1"));
		} else {
			throw new Exception("Evaluator ID " + evaluatorID + " is not valid");
		}

		if(eErrorDelayDays == -1 || eReturnDelayDays == -1) {
			throw new Exception("eError Delay Days and eReturn Delay days must be configured");
		}

		sql = "SELECT distinct cr.request_id, cr.client_app_id, cr.originator_refnum_txt, cr.appseqno " +
			"FROM credit_request cr, credit_request_activity cra " +
			"WHERE cr.request_id = cra.request_id (+) " +
			"AND cr.econtract_flg = 1 " +
			"AND (" +
			// Check for eError
			"(cr.trans_status_id = 6 AND cra.task_group_id = 'CONTRACTADMIN' AND floor(SYSDATE - cr.trans_status_updated_dt) >= ?) " +
			"OR " +
			// Check for eReturn
			"(cr.trans_status_id = 11 AND floor(SYSDATE - cr.trans_status_updated_dt) >= ?)) ";
		query = new Query(con);
		query.prepareStatement(sql);
		query.setInt(1, eErrorDelayDays);
		query.setInt(2, eReturnDelayDays);
		query.executePreparedQuery();

		String requestID = "", appID = "", originatorRefnum = "", appseqno = "";
		String delConvertPaperFlg = "";
		Query query2 = null;
		comment = new CommentEvents(con, log_obj);
		journal = new JournalEvents(con, null);
		int count = 0;
		Query tableQuery = null;


		// Convert each application. If there is an exception somewhere
		// in this process, stop processing the application and move
		// on to the next app. Do not stop the entire process.
		while(query.next()) {
			requestID = query.getColValue("request_id","");
			appID = query.getColValue("client_app_id","");
			originatorRefnum = query.getColValue("originator_refnum_txt","");
			appseqno = query.getColValue("appseqno","");

			log(0, "ECCTP: Processing Request ID: " + requestID + ", App ID: " + appID);

			try {

				//-------------------------------------------------------------
				// Set the Cancel flag to "L" for lender
				// Change the contract type from electronic to paper
				// Enable the contract info screen
				log(0, "ECCTP: BEGIN - Updating Application to eContract");
				sql = "update credit_request " +
					"set ecancel_txt = 'L', convert_to_paper_flg = 1, convert_to_paper_user_id = 'SYSTEM', " +
					"convert_to_paper_date = sysdate, econtract_flg = 0 " +
					"where request_id = ? ";
				update = new SQLUpdate();
				update.SetPreparedUpdateStatement(con, sql);
				update.setInt(1, requestID);
				update.RunPreparedUpdateStatement();
				log(0, "ECCTP: END - Updating Application to eContract");
				//-------------------------------------------------------------


				//-------------------------------------------------------------
				// Perform a lookup against the "Delete eContract When Converted to Paper" flag
				// If set, delete the contract and insurance data
				log(0, "ECCTP: BEGIN - Deleting contract data");
				sql = "select nvl(del_cp_convert_to_paper_flg,0) delConvertPaperFlg " +
					"from evaluator where evaluator_id = ? ";
				query2 = new Query(con);
				query2.prepareStatement(sql);
				query2.setInt(1, evaluatorID);
				query2.executePreparedQuery();
				query2.next();
				delConvertPaperFlg = query2.getColValue("delConvertPaperFlg","0");
				if(delConvertPaperFlg.equals("1")) {
					String baseTable = "CREDIT_REQ_CONTRACT";
					if(tableQuery == null) {
						tableQuery = initDeleteApp(con, baseTable);
					}
					if(!deleteApp(con, tableQuery, Integer.valueOf(requestID), con.getAutoCommit())) {
						throw new Exception("Error in deleting Request ID " + requestID);
					}
					// Create stub record for contract
					if(appseqno == null) appseqno ="";
					sql = "insert into credit_req_contract (request_id, evaluator_id, appseqno) values (?, ?, ?) ";
					update = new SQLUpdate();
					update.SetPreparedUpdateStatement(con, sql);
					update.setInt(1, requestID);
					update.setInt(2, evaluatorID);
					update.setString(3, appseqno);
					update.RunPreparedUpdateStatement();
				} else {
					log(0, "ECCTP: Delete contract data not configured");
				}
				log(0, "ECCTP: END - Deleting contract data");
				//-------------------------------------------------------------


				//-------------------------------------------------------------
				// Update the booking status as follows:
				// If the booking status is not PENLOG and the app was previously logged,
				// set the booking status to PENLOG
				// If the booking status is not PENLOG and the app wasn't previously logged,
				// assign a PENBKD booking status
				log(0, "ECCTP: BEGIN - Update app booking status");
				try {
					sql = "SELECT 1 " +
						"FROM	credit_request cr, credit_request_activity cra " +
						"WHERE	cr.request_id = ? " +
						"AND cr.request_id = cra.request_id " +
			      		"AND cr.app_status_id != 16 " +
						"AND    cra.task_group_id = 'CONTRACTADMIN' " +
						"AND    cra.activity_id =  10 ";
					query2 = new Query(con);
					query2.prepareStatement(sql);
					query2.setInt(1, requestID);
					query2.executePreparedQuery();
					int appStatusVal;
					if(query2.next()) {
						appStatusVal = 16; // PENLOG
					} else {
						appStatusVal = 17; // PENBKD
					}
					ApplicationStatusManager appStatus = new ApplicationStatusManager(con, log_obj);
					appStatus.setApplicationStatus(Long.valueOf(requestID),
							Integer.valueOf(evaluatorID), appStatusVal);
				} catch (Exception e) {
					throw new Exception("Error in setting application status for Request ID " + requestID + "; Exception: " + e.toString(), e);
				}
				log(0, "ECCTP: END - Update app booking status");
				//-------------------------------------------------------------


				//-------------------------------------------------------------
				// Write a Convert to Paper System Comment
				log(0, "ECCTP: BEGIN - Write System Comment");
				comment.addComment(Integer.parseInt(requestID), 54, "Convert Paper", "eContract converted to paper", "SYSTEM", "", "");
				log(0, "ECCTP: END - Write System Comment");
				//-------------------------------------------------------------


				//-------------------------------------------------------------
				// Write a Convert to Paper Journal entry
				log(0, "ECCTP: BEGIN - Write Journal Entry");
				journal.addJournal(Integer.parseInt(requestID), 50, "eContract Converted to Paper", "SYSTEM");
				log(0, "ECCTP: END - Write Journal Entry");
				//-------------------------------------------------------------


				//-------------------------------------------------------------
				// Generate and post an XML transaction to the eContract source
				log(0, "ECCTP: BEGIN - Post XML transaction to eContract source");
				try {
					postXMLTransaction(con, requestID, appID, originatorRefnum);
				} catch (Exception e) {
					throw new Exception("Error in posting XML transaction for Request ID " + requestID + "; Exception: " + e.toString(), e);
				}
				log(0, "ECCTP: END - Post XML transaction to eContract source");
				//-------------------------------------------------------------


				//-------------------------------------------------------------
				// Per the Convert to Paper input parameter, initiate a
				// TaskTeamUser call to eValuate and redirect if applicable
				log(0, "ECCTP: BEGIN - Call eValuate");
				if(redirect) {
					updateTaskTeamUser(con, requestID);
				} else {
					log(0, "ECCTP: Call to eValuate not configured");
				}
				log(0, "ECCTP: END - Call eValuate");
				//-------------------------------------------------------------

				// If everything was successful,
				// increment the count of apps converted
				count++;
			} catch (Exception e) {
				log(0, "Exception converting AppID " + appID +
						", Request ID " + requestID +
						" to paper. Moving past this app. Exception: " + e.toString(), e);
			}
		} // End application. Move onto next application.

		return count;
	}

	/**
	 * Initializes the table deletion query. What is returned is a Query object
	 * containing the order in which to delete tables, ending with the baseTable.
	 * This method should be called before calling <b>deleteApp</b>.
	 * @param con Open connection to the Origenate DB
	 * @param baseTable Base table from which to delete the application
	 * @return Query containing delete order
	 */
	private Query initDeleteApp(Connection con, String baseTable) {
		if(con == null || baseTable == null) {
			return null;
		}

		baseTable = baseTable.toUpperCase();
		try {
			String origTableSQL = "select distinct level, table_name from " +
					"(	select p.table_name, p.constraint_name pk, r.r_constraint_name fk from user_constraints p, " +
					"user_constraints r where p.table_name = r.table_name and p.constraint_type in ('P','U','R') " +
					"and r.constraint_type ='R' and r.constraint_name not in " +
					"('CR_CRDE_LATEST_FINAL_REF_ID_FK','CR_CRDE_LATEST_REF_ID_FK','PORTAL_COMMENT_FK') )  " +
					"start with table_name = ? connect by prior pk = fk " +
					"order by level desc, " +
					"decode(table_name,'EVALUATE_CACHE',2,'EVALUATE_SHARE',3,'CREDIT_REQUEST_AUDIT',1,0) asc";
			Query origTableQuery = new Query(con);
			origTableQuery.prepareStatement(origTableSQL);
			origTableQuery.setString(1, baseTable, false);
			origTableQuery.executePreparedQuery();

			return origTableQuery;
		} catch (Exception e) {
			return null;
		}
	}

	/**
	 * Deletes all information for the application starting with the baseTable.
	 * The origTableQuery parameter should have been initialized with <b>initDeleteApp</b>.
	 * @param con Open connection to the Origenate DB
	 * @param origTableQuery Query object returned from call to <i>initDeleteApp</i>
	 * @param request_id The application to delete
	 * @param autoCommit This method turns AutoCommit off; after completion, it will be set to this value
	 * @return success - Whether successful or failed call
	 * @throws Exception If there is an exception setting DB auto-commit state
	 */
	private boolean deleteApp(Connection con, Query origTableQuery, Integer request_id, boolean autoCommit)
		throws Exception {

		if(origTableQuery == null) {
			log(0, "The Table Deletion Query cannot be null");
			return false;
		}

		boolean success = true;
		String origDeleteQuery = "";
		String origTableName = "";
		PreparedStatement stmt = null;
		con.setAutoCommit(false);
		try {
			origTableQuery.reset();
			while(origTableQuery.next()) {
				origTableName = origTableQuery.getColValue("table_name");

				// If CREDIT_REQ_DECISIONS_EVALUATOR or CREDIT_REQUEST_COMMENT,
				// we need to make sure the foreign key contraint in
				// CREDIT_REQUEST does not cause any issues
				if(origTableName.equals("CREDIT_REQ_DECISIONS_EVALUATOR")) {
					stmt = con.prepareStatement("update credit_request set " +
							"latest_final_dec_ref_id = null, " +
							"latest_dec_ref_id = null where request_id = ?");
					stmt.setInt(1, request_id);
					stmt.execute();
					stmt.close();
				}
				else if(origTableName.equals("CREDIT_REQUEST_COMMENT")) {
					stmt = con.prepareStatement("update credit_request set " +
							"portal_comment_id = null where request_id = ?");
					stmt.setInt(1,request_id);
					stmt.execute();
					stmt.close();
				}

				 /**
				 * TTP 324955 Security Remediation Fortify Scan
				 */
				origDeleteQuery = "delete from " + SQLSecurity.sanitize(origTableName);
				if(origTableName.equals("CREDIT_REQ_DECISION_REASONS") ||
					origTableName.equals("CREDIT_REQ_DECISION_STIP") ||
					origTableName.equals("CREDIT_REQ_DECISIONS_PTIDTI") ||
					origTableName.equals("CREDIT_REQ_DECISIONS_MESSAGE") ||
					origTableName.equals("CREDIT_REQ_FIELD_REASONS") ||
					origTableName.equals("ALTERNATIVE_PRICING") ) {
					origDeleteQuery += " where decision_ref_id in (select decision_ref_id from " +
						"credit_req_decisions_evaluator where request_id = ?)";
				}
				else if(origTableName.equals("PRINTFAX_QUEUE_ATTACHMENTS") ||
						origTableName.equals("PRINTFAX_QUEUE_RECIPIENTS") ||
						origTableName.equals("PRINTFAX_QUEUE_VALUES") ) {
					origDeleteQuery += " where job_id in (select job_id from printfax_queue " +
						"where request_id = ?)";
				}
				else if(origTableName.equals("EVENT")) {
					origDeleteQuery += " where client_app_id in (select client_app_id " +
						"from credit_request where request_id = ?)";
				}
				else {
					origDeleteQuery += " where request_id = ?";
				}

				stmt = con.prepareStatement(origDeleteQuery);
				stmt.setInt(1, request_id);
				stmt.execute();
				stmt.close();
			}
		} catch (Exception e) {
			log(0, "Exception deleting Contract for Request ID " + request_id + ": " + e.toString(), e);
			success = false;
		}
		finally {
		    try{ if(stmt != null) stmt.close(); }catch(Exception e1){e1.printStackTrace();}
		}
		try {
			if(success) {
				con.commit();
			} else {
				con.rollback();
			}
		} catch (Exception e) {
			log(0, "Exception finalizing delete Contract for Request ID " + request_id + ": " + e.toString(), e);
		}

		con.setAutoCommit(autoCommit);

		return success;
	}

	/**
	 * Posts to fuseeContConvertToPaperTTU in evaluation/default.cfm
	 * It is expected that urls.eval_app_complete_url is defined in the
	 * INI file passed in to this program and that the config points
	 * to a fuse_action in evaluation/default.cfm
	 * @param con
	 * @param requestID
	 * @throws Exception
	 */
	private void updateTaskTeamUser(Connection con, String requestID) throws Exception {
		String response = "", error_txt = "";
		String sql = "select 1 from concurrency_control where request_id = ? ";
		Query query2 = new Query(con);
		query2.prepareStatement(sql);
		query2.setInt(1, requestID);
		query2.executePreparedQuery();
		String ccURL = ini.getINIVar("urls.eval_app_complete_url","");
		if(!query2.next()) {
			if(!ccURL.equals("")) {
				ccURL = ccURL.substring(0, ccURL.indexOf("fuse_action="));
				ccURL += "fuse_action=fuseeContConvertToPaperTTU&user_id=SYSTEM" +
						"&request_id="+requestID+"&evaluator_id="+evaluatorID+ "&closeSession=true";
				try {
					PostRequest postRequest = new PostRequest();
					response = postRequest.post(ccURL, "", 60);
					int idx = response.indexOf("econtconverttopaper_response=");
					error_txt = response.substring(idx,(idx+34)).trim();
					error_txt = error_txt.substring(error_txt.indexOf("=")+1);

					if(error_txt.equals("true")) {
						throw new Exception("Error in eValuate TTU call");
					}
				} catch (Exception e) {
					throw new Exception("Exception running TaskTeamUser: " + e.toString(), e);
				}
			} else {
				throw new Exception("TaskTeamUser URL not found in INI. Should be placed in urls.eval_app_complete_url");
			}
		} else {
			log(0, "Request ID " + requestID + " is in use. Cannot update TaskTeamUser " +
					"or redirect application");
		}
	}

	/**
	 * Copies the logic from ca/action/act_notifydealer.cfm for status code of CANCEL
	 * @param con
	 * @param requestID
	 * @param appID
	 * @param originatorRefnum
	 * @throws Exception
	 */
	private void postXMLTransaction(Connection con, String requestID, String appID, String originatorRefnum)
		throws Exception {
		String responseType = "", networkTxt = "", notificationType = "";
		String sendToNetwork = "0";
		String sendToDT = "0", sendToRt1 = "0";
		String network = "";
		String sql;
		Query query2;
		SQLUpdate update;
		sql = "SELECT cndn.response_type, cndn.network_txt, cndn.notification_type " +
			"FROM credit_request cr, config_network_dec_notify cndn " +
			"WHERE cr.request_id = ? " +
		    "AND cr.evaluator_id = ? " +
			"AND cr.product_id = (select product_id from credit_request where request_id = ?) " +
	        "AND cndn.evaluator_id = cr.evaluator_id  " +
		    "AND cndn.product_id = cr.product_id " +
			"AND cr.network_txt = cndn.network_txt	" +
		   	"AND cndn.active_flg = 1 ";
		query2 = new Query(con);
		query2.prepareStatement(sql);
		query2.setInt(1, requestID);
		query2.setInt(2, evaluatorID);
		query2.setInt(3, requestID);
		query2.executePreparedQuery();
		if(query2.next()) {
			responseType = query2.getColValue("response_type","");
			networkTxt = query2.getColValue("network_txt","");
			notificationType = query2.getColValue("notification_type","");
		}
		sql = "select send_to_dealertrack_flg, send_to_routeone_flg " +
			"from evaluator where evaluator_id = ? ";
		query2 = new Query(con);
		query2.prepareStatement(sql);
		query2.setInt(1, evaluatorID);
		query2.executePreparedQuery();
		if(query2.next()) {
			sendToDT = query2.getColValue("send_to_dealertrack_flg","0");
			sendToRt1 = query2.getColValue("send_to_routeone_flg","0");
		}

		if(networkTxt.equals("DEALERTRACK")) {
			sendToNetwork = sendToDT;
			network = "DEALERTRACK";
		} else if(networkTxt.equals("ROUTEONE")) {
			sendToNetwork = sendToRt1;
			network = "ROUTEONE";
		} else if(networkTxt.equals("ODE")) {
			network = "ODE";
		} else if(networkTxt.equals("AP1")) {
			network = "AP1";
		}

		if(sendToNetwork.equals("1") && !notificationType.equals("2") &&
				!notificationType.equals("3")) {
			responseType = "";
			networkTxt = "";
			notificationType = "";
			sql = "SELECT cndn.response_type, cndn.network_txt, cndn.notification_type " +
			"FROM credit_request cr, config_network_dec_notify cndn " +
			"WHERE cr.request_id = ? " +
		    "AND cr.evaluator_id = ? " +
			"AND cr.product_id = (select product_id from credit_request where request_id = ?) " +
	        "AND cndn.evaluator_id = cr.evaluator_id  " +
		    "AND cndn.product_id = cr.product_id " +
		    "AND upper(cndn.network_txt) = ? " +
		   	"AND cndn.active_flg = 1 ";
			query2 = new Query(con);
			query2.prepareStatement(sql);
			query2.setInt(1, requestID);
			query2.setInt(2, evaluatorID);
			query2.setInt(3, requestID);
			query2.setString(4, network);
			query2.executePreparedQuery();
			if(query2.next()) {
				responseType = query2.getColValue("response_type","");
				networkTxt = query2.getColValue("network_txt","");
				notificationType = query2.getColValue("notification_type","");
			}
		}

		if(notificationType.equals("2") || notificationType.equals("3")) {
			String gatewayUrl = "", responseUrl = "", postConfigId = "";
			String originatorCode = "";

			sql = "select mn.gateway_url_txt, mn.response_url_txt, cnop.post_config_id "
					+ "from mstr_networks mn, config_network_outbound_post cnop "
					+ "where mn.network_txt = ? "
					+ "and mn.active_flg = 1 "
					+ "and mn.network_txt = cnop.network_txt (+) "
					+ "and cnop.evaluator_id (+) = ? "
					+ "and cnop.active_flg (+) = 1 ";
			query2 = new Query(con);
			query2.prepareStatement(sql);
			query2.setString(1, networkTxt);
			query2.setInt(2, evaluatorID);
			query2.executePreparedQuery();
			if(query2.next()) {
				gatewayUrl = query2.getColValue("gateway_url_txt","");
				responseUrl = query2.getColValue("response_url_txt","");
				postConfigId = query2.getColValue("post_config_id", "");
			}

			sql = "select eo.originator_code_txt " +
				"from credit_request cr, credit_request_originator cro, evaluator_originator eo " +
				"where cr.request_id = ? and cr.request_id = cro.request_id " +
				"and cro.originator_id = eo.originator_id and cr.evaluator_id = cro.evaluator_id " +
				"and cro.evaluator_id = eo.evaluator_id ";
			query2 = new Query(con);
			query2.prepareStatement(sql);
			query2.setInt(1, requestID);
			query2.executePreparedQuery();
			if(query2.next()) {
				originatorCode = query2.getColValue("originator_code_txt","");
			}

			String transTypeVal = "ContractRs|ChecklistRs|AppActivityRq|LoanAppRq";

			String additionalData = "TRANSACTION_TYPE,"+transTypeVal;
			additionalData += ",STATUS,CANCEL";
			additionalData += ",REQUEST_ID,"+requestID;
			additionalData += ",CLIENT_APP_ID,"+appID;
			if(!originatorRefnum.equals("")) {
				additionalData += ",REMOTE_REF_NUM,"+originatorRefnum;
			}
			additionalData += ",EVALUATOR_ID,"+evaluatorID;
			additionalData += ",ORIGINATOR_ID,"+originatorCode;
			if(!networkTxt.equals("")) {
				additionalData += ",NETWORK,"+networkTxt;
			}
			additionalData += ",NETWORK_TXT,'"+networkTxt+"'";
			additionalData += ",DESTINATION,"+responseUrl;
			additionalData += ",COL_DESTINATION,"+gatewayUrl;
			additionalData += ",POST_CONFIG_ID,"+postConfigId;

			sql = "insert into routing_queue " +
				"(request_id, queue_priority_num,routing_state_id,run_dt,tries_num,additional_data_txt,routing_queue_id) " +
				"VALUES " +
				"(?, 0, 9, sysdate, 0, ?, ROUTING_QUEUE_SEQ.NEXTVAL) ";
			update = new SQLUpdate();
			update.SetPreparedUpdateStatement(con, sql);
			update.setInt(1, requestID);
			update.setString(2, additionalData);
			update.RunPreparedUpdateStatement();
		}
	}

	private void GetArgs(String args[], LogMsg log_obj) {
		if(args.length > 0) {
			for(int i = 0; i < args.length; i++) {
				if((args[i].charAt(0) != '-') && (args[i].length() > 1)) {
					ShowUsage();
				}

				switch(args[i].charAt(1)) {

				case 'i':
					sIniFile = args[i].substring(2);
					log(0, "IniFile is '" + sIniFile + "'");
					try {
						// Read host, user, sid and password from ini file
						ini.readINIFile(sIniFile);

						logFile = ini.getINIVar("logs.econt_convert_to_paper_log_file", "");
						if(logFile.length() > 0) {
							log_obj.openLogFile(logFile);
						}

						log(0, "EContConvertToPaper version " + VERSION + " initializing...");

						sHost = ini.getINIVar("database.host", "");
						log(0, "Host is '" + sHost + "'");

						sPort = ini.getINIVar("database.port", "");
						log(0, "Port is '" + sPort + "'");

						sUser = ini.getINIVar("database.user", "");
						log(0, "User is '" + sUser + "'");

						sPass = ini.getINIVar("database.password", "");
						// log(0,"Password:"+sPass);

						sSIDname = ini.getINIVar("database.sid", "");
						log(0, "Database (SID name) is '" + sSIDname + "'");

						sTNSEntry = ini.getINIVar("database.TNSEntry", "");
						log(0, "TNS Entry is '" + sTNSEntry + "'");
					}
					catch(Exception e){
						log(0, "Caught exception reading ini file '" + sIniFile + "': " + e.toString(), e);
					}
					break;

				// Not much logging. We'll leave this flag out
				/*case 'd': //turn debug on
					i_dbg_level = 5;
					log(0, "debugging turned on");
					break;*/

				case 'c': //call evaluate
					redirect = true;
					log(0, "call evaluate set");
					break;

				case 'e': //evaluator id
					evaluatorID = args[i].substring(2);
					log(0, "Evaluator ID: " + evaluatorID);
					break;

				default:
					log(0, "Unknown parameter: " + args[i]);
					ShowUsage();
					break;
				} // end case
			} // end for loop

			//edits
			if ((sHost.length() == 0) || (sUser.length() == 0)
					|| (sSIDname.length() == 0) || (sPort.length() == 0)) {
				log(0, "Host,User,Pwd,SID or Port not specified in INI file");
				ShowUsage();
			}
			if (evaluatorID.length() == 0) {
				log(0, "-e parm is required");
				ShowUsage();
			}
		} // end if
		else {
			ShowUsage();
		}
	}

	private void ShowUsage() {
		System.out.println();
		System.out.println("Usage: java EContConvertToPaper -i<inifile> -e<evaluator id> [-c]");
		System.out.println("---------------------");
		System.out.println("-i - required: INI file to use for configuration");
		System.out.println("-e - required: evaluator id");
		System.out.println("-c - optional: if flag is set, call TaskTeamUser and redirect apps");
		System.exit(1);
	}

	private void log(int level, String msg) {
		log_obj.FmtAndLogMsg(msg, i_dbg_level, level);
	}

	private void log(int level, String msg, Throwable throwable) {
		log_obj.FmtAndLogMsg(msg, throwable, i_dbg_level, level);
	}

	public void run(String[] args) throws Exception {
		Connection con = null;

		log(0, "EContConvertToPaper initializing...");

		GetArgs(args, log_obj);

		String sConStr = "jdbc:oracle:thin:@";
		if (sTNSEntry.length() == 0) {
			sConStr = sConStr + sHost + ":" + sPort + ":" + sSIDname;
		}
		else {
			sConStr = sConStr + sTNSEntry;
			log(0, "Using TNS Entry");
		}

		try {
			// Load Oracle driver
			DriverManager.registerDriver(new oracle.jdbc.OracleDriver());

			log(0, "Connecting to database: " + sConStr);

			sPass = COLEncrypt.sDecrypt(sPass);

			// Connect to the Oracle database
			con = DriverManager.getConnection(sConStr, sUser, sPass);
		}
		catch (Exception e) {
			log(0, "Error connecting to database: " + e.toString(), e);
			throw e;
		}

		int count = 0;
		try {
			count = convertApps(con);
		}
		catch (Exception e) {
			log(0, "Error in EContConvertToPaper: " + e.toString(), e);
		}

		try {
			con.close();
		}
		catch (Exception e1){}

		log(0, "EContConvertToPaper: " + count + " Applications Converted to Paper");
		log(0, "EContConvertToPaper exiting...");
	}

	public static void main(String[] args) {
		EContConvertToPaper ctp = new EContConvertToPaper();
		try {
			ctp.run(args);
		}
		catch (Exception e) {
		}

		System.exit(0);
	}

	public EContConvertToPaper() {
	}
}
