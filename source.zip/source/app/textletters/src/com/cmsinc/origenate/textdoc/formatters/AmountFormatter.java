package com.cmsinc.origenate.textdoc.formatters;

import java.math.BigDecimal;
import com.cmsinc.origenate.textdoc.AppException;

/**
 * Abstract base class for formatting an amount document field (<code>java.util.BigDecimal</code>, <code>java.util.Integer</code> or 
 * <code>java.util.Long</code>) into an amount string. If an integer type is
 * passed, no cents are included in the amount string.
 * 
 * @since Origenate 6.0
 */
public abstract class AmountFormatter {

  public static BigDecimal toBigDecimal(Object aValue, boolean[] aCentsFlag) throws AppException {
    BigDecimal decimal = null;
    boolean wantCents = false;
    if (aValue instanceof BigDecimal) {
      decimal = (BigDecimal) aValue;
      wantCents = true;
    }
    else if (aValue instanceof Integer) {
      decimal = BigDecimal.valueOf(((Integer) aValue).longValue());
      wantCents = false;
    }
    else if (aValue instanceof Long) {
      decimal = BigDecimal.valueOf(((Long) aValue).longValue());
      wantCents = false;
    }
    else
      throw new AppException("argument to AmountAsWordsFormatter must be a BigDecimal, Integer or Long");
    
    if (aCentsFlag != null && aCentsFlag.length > 0)
      aCentsFlag[0] = wantCents;
    return decimal;
  }
}
