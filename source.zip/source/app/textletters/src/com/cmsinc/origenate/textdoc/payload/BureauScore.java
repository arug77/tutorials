package com.cmsinc.origenate.textdoc.payload;

import java.util.Date;
/**
 * Data about the bureau results including Score, Score Reasons, and Pull Date.<br>
 * 
 * Treat this class as "thread-safe", since it is immutable once created.
 * 
 * @since Origenate 8.5.25
 */
public class BureauScore 
{
  
	private String bureau_score = null;
	private String score_reason_c_1 = null;
	private String score_reason_c_2 = null;
	private String score_reason_c_3 = null;
	private String score_reason_c_4 = null;
	private String score_reason_d_1 = null;
	private String score_reason_d_2 = null;
	private String score_reason_d_3 = null;
	private String score_reason_d_4 = null;
	private Date score_pull_date = null;
	private String inquiries=null;
  
	BureauScore(String abureau_score, String ascore_reason_c_1, String ascore_reason_c_2, String ascore_reason_c_3,
		        String ascore_reason_c_4, String ascore_reason_d_1, String ascore_reason_d_2, String ascore_reason_d_3,
		        String ascore_reason_d_4, Date ascore_pull_date, String ainquiries) {

		this.bureau_score = abureau_score;
		this.score_reason_c_1 = ascore_reason_c_1;
		this.score_reason_c_2 = ascore_reason_c_2;
		this.score_reason_c_3 = ascore_reason_c_3;
		this.score_reason_c_4 = ascore_reason_c_4;
		this.score_reason_d_1 = ascore_reason_d_1;
		this.score_reason_d_2 = ascore_reason_d_2;
		this.score_reason_d_3 = ascore_reason_d_3;
		this.score_reason_d_4 = ascore_reason_d_4;
		this.score_pull_date = ascore_pull_date;
		this.inquiries = ainquiries;
	}
  
	public String getbureau_score() 
	{
		return this.bureau_score;
	}
  
	public String getscore_reason_c_1() 
	{
		return this.score_reason_c_1;
	}
  
	public String getscore_reason_c_2() 
	{
		return this.score_reason_c_2;
	}
  
	public String getscore_reason_c_3() 
	{
		return this.score_reason_c_3;
	}
  
	public String getscore_reason_c_4() 
	{
		return this.score_reason_c_4;
	}
  
	public String getscore_reason_d_1() 
	{
		return this.score_reason_d_1;
	}
  
	public String getscore_reason_d_2() 
	{
		return this.score_reason_d_2;
	}
  
	public String getscore_reason_d_3() 
	{
		return this.score_reason_d_3;
	}

	public String getscore_reason_d_4() 
	{
		return this.score_reason_d_4;
	}

	public Date getscore_pull_date() 
	{
		return score_pull_date;
	}
	
	public String getinquiries()
	{
		return inquiries;
	}
}
