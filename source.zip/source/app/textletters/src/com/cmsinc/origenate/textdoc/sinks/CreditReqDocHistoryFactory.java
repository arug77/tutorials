package com.cmsinc.origenate.textdoc.sinks;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Types;
import java.util.Date;
import java.util.logging.Level;
import com.cmsinc.origenate.textdoc.AppLogger;
import com.cmsinc.origenate.textdoc.AppException;

import com.cmsinc.origenate.util.OWASPSecurity;

/**
 * Simple factory class for creating persistent instances of <code>CreditReqDocHistory</code> 
 * by inserting rows into the database.<br>
 * 
 * Treat this class as "thread-hostile", since it caches a statement and database connection.<br>
 * 
 * @since Origenate 6.0
 */
public class CreditReqDocHistoryFactory {
  private static final String INSERT_SQL = 
    "INSERT INTO CREDIT_REQ_DOC_HISTORY(REQUEST_ID, EVALUATOR_ID, DOCUMENT_ID, " +
    "  SUBMIT_REASON_ID, PACKAGE_ID, JOB_ID, BATCH_JOB_ID, JOB_TYPE_TXT, " +
    "  JOB_NAME_TXT, STATUS_ID, ERROR_TXT, USER_ID, CENTRAL_PRO_SERVER_ID, " +
    "  FAX_SERVER_ID, FAX_NUMBER_TXT, COPIES_NUM, COMMENT_TXT, PRINT_DATE, CREATE_DT) " +
    "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

  private Connection conn = null;
  
  private PreparedStatement stmtInsert = null;
  
  private int batchSize = 0;
  
  private int updateCount = 0;
    
  public CreditReqDocHistoryFactory(Connection aConnection, int aBatchSize) throws AppException {
    try {
      this.conn = aConnection;
      this.batchSize = aBatchSize;
      this.stmtInsert = this.conn.prepareStatement(INSERT_SQL);
      this.stmtInsert.clearBatch();
      this.updateCount = 0;
    }
    catch (SQLException ex) {
      throw new AppException("prepare INSERT into CREDIT_REQ_DOC_HISTORY", ex);
    }
  }
  
  public void create(CreditReqDocHistory aNewHistoryObject) throws AppException {
    int[] updateStatus = null;
    try {
      int idx = 1;
 
      // Set attributes from history object into SQL insert statement.
      
      /**		
       * OWASP TOP 10 2010 - A4 ACCESS CONTROL DATABASE
	   * Changes to the below code to fix vulnerabilities
	   **/      
      /*this.stmtInsert.setLong(idx++, aNewHistoryObject.getRequestId());
        this.stmtInsert.setLong(idx++, aNewHistoryObject.getEvaluatorId());
        this.stmtInsert.setLong(idx++, aNewHistoryObject.getDocumentId());
        this.stmtInsert.setInt(idx++, aNewHistoryObject.getSubmitReasonId());*/      
      this.stmtInsert.setLong(idx++, Long.valueOf(aNewHistoryObject.getRequestId()).longValue());
      this.stmtInsert.setLong(idx++, Long.valueOf(aNewHistoryObject.getEvaluatorId()).longValue());
      this.stmtInsert.setLong(idx++, Long.valueOf(aNewHistoryObject.getDocumentId()).longValue());
      // OWASP Security false positive
      this.stmtInsert.setInt(idx++, Integer.parseInt(String.valueOf(aNewHistoryObject.getSubmitReasonId())));
      
      if (aNewHistoryObject.getPackageId() < 0)
        this.stmtInsert.setNull(idx++, Types.NUMERIC); 
      else
    	  
    	  /**		
           * OWASP TOP 10 2010 - A4 ACCESS CONTROL DATABASE
    	   * Changes to the below code to fix vulnerabilities
    	   **/    	  
    	  //this.stmtInsert.setLong(idx++, aNewHistoryObject.getPackageId());
    	  this.stmtInsert.setLong(idx++, Long.valueOf(aNewHistoryObject.getPackageId()).longValue());
        
      if (aNewHistoryObject.getJobId() < 0)
        this.stmtInsert.setNull(idx++, Types.NUMERIC); 
      else
    	  
    	  /**		
           * OWASP TOP 10 2010 - A4 ACCESS CONTROL DATABASE
    	   * Changes to the below code to fix vulnerabilities
    	   **/    	  
    	  //this.stmtInsert.setLong(idx++, aNewHistoryObject.getJobId());
    	  this.stmtInsert.setLong(idx++, Long.valueOf(aNewHistoryObject.getJobId()).longValue());
        
      if (aNewHistoryObject.getBatchJobId() < 0)
        this.stmtInsert.setNull(idx++, Types.NUMERIC); 
      else
    	  
    	  /**		
           * OWASP TOP 10 2010 - A4 ACCESS CONTROL DATABASE
    	   * Changes to the below code to fix vulnerabilities
    	   **/    	  
    	  //this.stmtInsert.setLong(idx++, aNewHistoryObject.getBatchJobId());
    	  this.stmtInsert.setLong(idx++, Long.valueOf(aNewHistoryObject.getBatchJobId()).longValue());
      	
      	/**		
      	 * OWASP TOP 10 2010 - A4 ACCESS CONTROL DATABASE
      	 * Changes to the below code to fix vulnerabilities
         * TTP 324955
      	 **/        
       /*this.stmtInsert.setString(idx++, aNewHistoryObject.getJobType());
         this.stmtInsert.setString(idx++, aNewHistoryObject.getJobName());
         this.stmtInsert.setString(idx++, aNewHistoryObject.getStatus());
         this.stmtInsert.setString(idx++, aNewHistoryObject.getError());
         this.stmtInsert.setString(idx++, aNewHistoryObject.getUser());
         this.stmtInsert.setString(idx++, aNewHistoryObject.getCentralProServer());
         this.stmtInsert.setString(idx++, aNewHistoryObject.getFaxServer());
         this.stmtInsert.setString(idx++, aNewHistoryObject.getFaxNumber());*/
     try
     {
      this.stmtInsert.setString(idx++, OWASPSecurity.validationCheck(aNewHistoryObject.getJobType(), OWASPSecurity.SQLPARAMSTRING));
      this.stmtInsert.setString(idx++, OWASPSecurity.validationCheck(aNewHistoryObject.getJobName(), OWASPSecurity.SQLPARAMSTRING));
      this.stmtInsert.setString(idx++, OWASPSecurity.validationCheck(aNewHistoryObject.getStatus(), OWASPSecurity.SQLPARAMSTRING));
      this.stmtInsert.setString(idx++, OWASPSecurity.validationCheck(aNewHistoryObject.getError(),OWASPSecurity.SQLPARAMSTRING));
      this.stmtInsert.setString(idx++, OWASPSecurity.validationCheck(aNewHistoryObject.getUser(),OWASPSecurity.SQLPARAMSTRING));
      this.stmtInsert.setString(idx++,  OWASPSecurity.validationCheck(aNewHistoryObject.getCentralProServer(),OWASPSecurity.SQLPARAMSTRING));
      this.stmtInsert.setString(idx++,  OWASPSecurity.validationCheck(aNewHistoryObject.getFaxServer(),OWASPSecurity.SQLPARAMSTRING)); 
      this.stmtInsert.setString(idx++,  OWASPSecurity.validationCheck(aNewHistoryObject.getFaxNumber(),OWASPSecurity.SQLPARAMSTRING));     
      }
      catch(Exception e)
      {
        e.printStackTrace();
      }
      if (aNewHistoryObject.getNumberOfCopies() < 0)
        this.stmtInsert.setNull(idx++, Types.NUMERIC); 
      else
    	  
    	  /**		
	       * OWASP TOP 10 2010 - A4 ACCESS CONTROL DATABASE
		   * Changes to the below code to fix vulnerabilities
       * TTP 324955
		   **/    	  
    	  /*this.stmtInsert.setInt(idx++, aNewHistoryObject.getNumberOfCopies());
    	    this.stmtInsert.setString(idx++, aNewHistoryObject.getComment());*/
    	  this.stmtInsert.setInt(idx++, Integer.valueOf(aNewHistoryObject.getNumberOfCopies()).intValue());      
      	 try
         {
          this.stmtInsert.setString(idx++,  OWASPSecurity.validationCheck(aNewHistoryObject.getComment(), OWASPSecurity.SQLPARAMSTRING));
        }
        catch(Exception e)
        {
          e.printStackTrace();
        }
      this.stmtInsert.setDate(idx++, aNewHistoryObject.getDatePrinted());
      this.stmtInsert.setDate(idx++, aNewHistoryObject.getDateCreated());
      
      // Add parameterized statement to batch, and execute batch if batch size reached.
      
      this.stmtInsert.addBatch();
      if (++this.updateCount >= this.batchSize)
        flushUpdates();
    }
    catch (SQLException ex) {
      throw new AppException("failed to insert CREDIT_REQ_DOC_HISTORY " +
        "for request ID=" + aNewHistoryObject.getRequestId(), ex);
    }
  }
  
  public void flushUpdates() throws AppException {
    long startUpdateTime = (new Date()).getTime();
    int numberOfAffectedRows = 0;
    
    try {
      int[] updateStatus = this.stmtInsert.executeBatch();
      this.stmtInsert.clearBatch();
      this.updateCount = 0;
      
      for (int i=0;updateStatus != null && i < updateStatus.length;i++) {
        if (updateStatus[i] == PreparedStatement.EXECUTE_FAILED)
          throw new AppException("one or more batch INSERTS into CREDIT_REQ_DOC_HISTORY failed");
        else
          numberOfAffectedRows++;
      }
    }
    catch (SQLException ex) {
      throw new AppException("failed to execute batch INSERT into CREDIT_REQ_DOC_HISTORY", ex);
    }
    
    long endUpdateTime = (new Date()).getTime();
    long elapsedUpdateTime = endUpdateTime - startUpdateTime;
    AppLogger.logger.log(Level.FINEST, Thread.currentThread().getName() + 
      ": inserted " + numberOfAffectedRows + " CreditReqDocHistory objects in " + elapsedUpdateTime + " ms");

    // GL need to close and reopen cursor to free JDBC resources
    dispose();
    try {
      this.stmtInsert = this.conn.prepareStatement(INSERT_SQL);
      this.stmtInsert.clearBatch();
      this.updateCount = 0;
    }
    catch (SQLException ex) {
      throw new AppException("prepare INSERT into CREDIT_REQ_DOC_HISTORY", ex);
    }

  } // flushUpdates()
  
  /**
   * Release resources held by this instance, such as JDBC statements. This method
   * must be safe to call twice in a row (i.e., must determine if it has already
   * done cleanup) since it is called from <code>finalize()</code> as a fail-safe.
   */
  public void dispose() {
    try {
      if (this.stmtInsert != null)
        this.stmtInsert.close();
        this.stmtInsert = null;
    }
    catch (SQLException ex) {
      AppLogger.logger.log(Level.WARNING, "failed to close CREDIT_REQ_DOC_HISTORY statement", ex);
    }
  }
  
  protected void finalize() throws Throwable {
    dispose();
  }
}
