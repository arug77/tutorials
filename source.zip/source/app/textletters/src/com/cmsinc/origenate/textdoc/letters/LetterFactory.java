package com.cmsinc.origenate.textdoc.letters;

import java.util.Date;
import java.util.Map;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Arrays;
import java.text.MessageFormat;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import com.cmsinc.origenate.textdoc.AppLogger;
import com.cmsinc.origenate.textdoc.AppException;
import com.cmsinc.origenate.util.Query;
import com.cmsinc.origenate.util.SQLSecurity;


/**
 * Abstract base, factory class for creating welcome, counter-offer and declined letters.<br>
 *
 * Treat this class as "thread-hostile"; a single thread should create, use, and
 * then discard instances of this class, due to the JDBC query executed and managed
 * by this class.
 *
 * @since Origenate 6.0
 */
public abstract class LetterFactory {
  /**
   * Inner class that stores information about a document.
   */
  public static class DocumentInfo {
    public long evaluatorId = -99;
    public long documentId = -1;
    public String documentType = null;

    DocumentInfo(long aEvaluatorId, long aDocumentId, String aDocumentType) {
      this.evaluatorId = aEvaluatorId;
      this.documentId = aDocumentId;
      this.documentType = aDocumentType;
    }
  }

  private static final String BASE_SELECT_LIST =
    "cr.request_id, cr.evaluator_id, cr.client_app_id, cr.initiation_dt, " +
    "cr.app_status_id, cr.task_id, cr.personal_flg, ev.evaluator_name_txt";

  private static final String BASE_FROM_CLAUSE =
    "credit_request cr, evaluator ev, config_product_settings cps";

  /**
   * Exclude looking at apps older than 90 days to reduce the result set. The
   * two placeholders here ({0}, {1}) are for credit history document IDs conditional
   * and evaluator ID conditional, respectively. Noet that we double up on single
   * quotes to preserve them since <code>MessageFormat</code> eats them otherwise.
   */
  private static final String BASE_WHERE_CLAUSE =
    "(cr.initiation_dt > (sysdate - 90)) AND " +
    "cr.evaluator_id = ev.evaluator_id AND " +
    "cr.request_id NOT IN ( " +
    "  SELECT ch.request_id FROM credit_req_doc_history ch " +
    "  WHERE ch.request_id = cr.request_id AND ch.status_id IN (''SUCCESS'', ''GENERATED'') " +
    "        {0} ) AND " +
    "cr.evaluator_id = cps.evaluator_id AND cr.product_id = cps.product_id " +
    " {1} ";

  /**
   * Sort by request ID, then evaluator.  The main letter processing logic
   * depends on letters being sorted by request ID as the major sort key.
   */
  private static final String BASE_ORDER_BY =
    "cr.request_id, cr.evaluator_id";

  private static final String CFGEVALDOCS_QUERY_SQL =
    "SELECT * FROM ( " +
    "SELECT cd.doc_type_id, ce.document_id, ce.evaluator_id " +
    "FROM config_evaluator_documents ce, config_documents cd " +
    "WHERE ce.category_id = ? AND " +
    "      ce.evaluator_id = cd.evaluator_id (+) AND " +
    "      ce.document_id = cd.document_id (+) " +
    "      {0} " +
    "UNION " +
    "SELECT cd.doc_type_id, ce.document_id, ce.evaluator_id " +
    "FROM config_evaluator_documents ce, config_documents cd " +
    "WHERE ce.category_id = ? AND " +
    "      ce.evaluator_id = cd.evaluator_id (+) AND " +
    "      ce.document_id = cd.document_id (+) AND " +
    "      ce.evaluator_id < 0 " +
    ") ORDER BY evaluator_id";

  private final static int SYSTEM_EVALUATOR_ID = -1;

  //private String letterCategoryId = null;

  private long[] evaluatorIds = null;

  protected Connection conn = null;

  protected abstract String getLetterCategory();

  protected LetterFactory(Connection aConnection, String aLetterCategoryId, long[] someEvaluatorIds) {
    this.conn = aConnection;
    //this.letterCategoryId = aLetterCategoryId;
    this.evaluatorIds = someEvaluatorIds;
    if (this.evaluatorIds != null && this.evaluatorIds.length > 1)
      Arrays.sort(this.evaluatorIds);
  }

  public LetterIterator queryLetters() throws AppException {
    long startQueryTime = (new Date()).getTime();

    // Get document info for each evaluator passed to program (or for all
    // evaluators if no specific evaluator(s) specified).

    Map mapEvaluatorDocumentInfo = null;

	//tries to find from config_touchpoint_documents
	mapEvaluatorDocumentInfo = getTouchpointInfo(getLetterCategory());
	AppLogger.logger.log(Level.FINEST, Thread.currentThread().getName() + " Touchpoint mapEvaluatorDocumentInfo size: "+mapEvaluatorDocumentInfo.size() + "   Letter: " + getLetterCategory() );

     if (mapEvaluatorDocumentInfo == null || mapEvaluatorDocumentInfo.size() == 0) {

		//if no recrod found from config_touchpoint_docuemts table, try with config_evaluator_documents table
		mapEvaluatorDocumentInfo = getDocumentInfo(getLetterCategory());
		AppLogger.logger.log(Level.FINEST, Thread.currentThread().getName() + " Document mapEvaluatorDocumentInfo size: "+mapEvaluatorDocumentInfo.size() + "   Letter: " + getLetterCategory() );
		//If still no documetns found, return null
		if(mapEvaluatorDocumentInfo == null || mapEvaluatorDocumentInfo.size() == 0) {
			AppLogger.logger.log(Level.WARNING, "no documents defined for letter category = " + getLetterCategory() +
			 " and any evaluator(s) passed as program argument(s), no letters processed");
		   return null;
		}
    }

    // Build array of all document IDs this program will operate on for subquery
    // of CREDIT_REQ_DOC_HISTORY table. Per the NightlyLetters program, this reduces
    // the set of selected credit apps to those that have not printed a document in
    // the array. Using the document ID by itself relies on documents for different
    // evaluators being mutually exclusive (see the original NightlyLetters program).

    ArrayList arrlistHistoryDocumentIds = new ArrayList();
    for (Iterator iter=mapEvaluatorDocumentInfo.values().iterator();iter.hasNext();) {
      DocumentInfo[] docInfo = (DocumentInfo[]) iter.next();
      for (int i=0;docInfo != null && i < docInfo.length;i++)
        arrlistHistoryDocumentIds.add(Long.valueOf(docInfo[i].documentId));
    }

    long[] historyDocumentIds = new long[arrlistHistoryDocumentIds.size()];
    for (int i=0,n=arrlistHistoryDocumentIds.size();i < n;i++)
      historyDocumentIds[i] = ((Long) arrlistHistoryDocumentIds.get(i)).longValue();

    // Execute the main letters query.
    // Gets touchpoint ID from letter categoryID
	String touchPointID = "";
	try {
	   touchPointID = getTouchpointID(getLetterCategory());
	} catch(Exception e) {
	   e.printStackTrace();
	}
	boolean printOnceFlg = getPrintOnceFlg(touchPointID);

    String letterSpecificSQL = "";
  
     letterSpecificSQL = buildSQL(printOnceFlg);

    String documentWhereCondition = buildMatchMoreOrMoreIdsWhereCondition("ch.document_id", " AND ", historyDocumentIds);
    String evaluatorWhereCondition = buildMatchMoreOrMoreIdsWhereCondition("ev.evaluator_id", " AND ", this.evaluatorIds);
    String finalSQL = MessageFormat.format(letterSpecificSQL, new Object[] { documentWhereCondition, evaluatorWhereCondition });
    PreparedStatement stmt = null;
    ResultSet rs = null;
    boolean isGood = false;
	    AppLogger.logger.log(Level.FINEST, Thread.currentThread().getName() +
      ": letter query SQL BEFORE = <" + finalSQL + ">");
    if(finalSQL.contains("{0}"))
    	finalSQL = finalSQL.replace("{0}", " ");
    if(finalSQL.contains("{1}"))
    	finalSQL = finalSQL.replace("{1}", " ");
    AppLogger.logger.log(Level.FINEST, Thread.currentThread().getName() +
      ": letter query SQL AFTER = <" + finalSQL + ">");

    try {
      int idx = 1;
	  /**
	  * OWASP TOP 10 2010 - A1 High SQL Injection
	  *  TTP 324955 Security Remediation Fortify Scan
    * Encoding is unnecessary because the string finalSQL was
    * built with string literals that have no malicious SQL.
	  */
      stmt = conn.prepareStatement(finalSQL);
      //stmt = conn.prepareStatement(ESAPI.encoder().encodeForSQL( new OracleCodec(),finalSQL.toString()));
      //stmt = conn.
      for (int i=0;historyDocumentIds != null && i < historyDocumentIds.length;i++)
        stmt.setLong(idx++, historyDocumentIds[i]);
      for (int i=0;this.evaluatorIds != null && i < this.evaluatorIds.length;i++)
        stmt.setLong(idx++, this.evaluatorIds[i]);
      rs = stmt.executeQuery();
      isGood = true;
    }
    catch (SQLException ex) {
      throw new AppException("failed to query CREDIT_REQUEST to get letters", ex);
    }
    finally {
      if (!isGood) {
        try {
          if (rs != null)
            rs.close();
          if (stmt != null)
            stmt.close();
        }
        catch (SQLException ex) {
          AppLogger.logger.log(Level.WARNING, "failed to cleanup properly by closing statements or result set", ex);
        }
      }
    }

    long endQueryTime = (new Date()).getTime();
    long elapsedQueryTime = endQueryTime - startQueryTime;
    String className = getClass().getName().substring(getClass().getName().lastIndexOf('.') + 1);
    AppLogger.logger.log(Level.FINEST, Thread.currentThread().getName() +
      ": " + className + ".queryLetters --> query of documentInfo " +
      "and seed of LetterIterator took " + elapsedQueryTime + " ms");

    LetterIterator iter = new LetterIterator(getLetterCategory(), mapEvaluatorDocumentInfo, rs, stmt);
    return iter;
  }

  protected StringBuffer selectList() {
    StringBuffer buf = new StringBuffer(BASE_SELECT_LIST);
    return buf;
  }

  protected StringBuffer fromClause() {
    StringBuffer buf = new StringBuffer(BASE_FROM_CLAUSE);
    return buf;
  }

  protected StringBuffer whereClause() {
    StringBuffer buf = new StringBuffer(BASE_WHERE_CLAUSE);
    return buf;
  }

  protected StringBuffer orderBy() {
    StringBuffer buf = new StringBuffer(BASE_ORDER_BY);
    return buf;
  }
  protected String buildSQL() {
    return buildSQL(true);
  }

  protected String buildSQL(boolean printOnceFlg) {
    StringBuffer bufSQL = new StringBuffer("SELECT DISTINCT");
    StringBuffer bufSelect = selectList(); // string literals based on final string variable
    bufSQL = appendWhitespaceIfNeeded(bufSQL);
    bufSQL.append(bufSelect);

    StringBuffer bufFrom = fromClause(); // string literals based on final string variable 
    bufSQL = appendWhitespaceIfNeeded(bufSQL);
    bufSQL.append("FROM");
    bufSQL = appendWhitespaceIfNeeded(bufSQL);
    bufSQL.append(bufFrom);

    if (printOnceFlg) {
        StringBuffer bufWhere = whereClause();// string literals based on final string variable 
		bufSQL = appendWhitespaceIfNeeded(bufSQL);
		bufSQL.append("WHERE");
		bufSQL = appendWhitespaceIfNeeded(bufSQL);
		bufSQL.append(bufWhere);
    }
	else {
	    //StringBuffer bufWhere = whereClause();
		bufSQL = appendWhitespaceIfNeeded(bufSQL);
		bufSQL.append("WHERE");
		bufSQL = appendWhitespaceIfNeeded(bufSQL);
		bufSQL.append("(cr.initiation_dt > (sysdate - 90)) AND cr.evaluator_id = ev.evaluator_id AND cr.evaluator_id = cps.evaluator_id AND cr.product_id = cps.product_id {1}");
	}

    StringBuffer bufOrder = orderBy(); // 
    bufSQL = appendWhitespaceIfNeeded(bufSQL);
    bufSQL.append("ORDER BY");
    bufSQL = appendWhitespaceIfNeeded(bufSQL);
    bufSQL.append(bufOrder);

    return bufSQL.toString();
  }
/**
 * Gets PrintOnceFlag
 * @param con
 * @param touchpointID
 * @return boolean printOnceFlg value
 * @throws Exception
 */
 protected boolean getPrintOnceFlg(String touchpointID) {
	boolean printOnceFlg = true;
	try {
		Query queryTmp = new Query(this.conn);
		 // Get the printOnce Flg for this touchpoint
		String sql="select print_once_flg from config_print_delivery where touchpoint_id = ? ";
		queryTmp.prepareStatement(sql);
		queryTmp.setString(1, touchpointID);
		queryTmp.executePreparedQuery();
		while (queryTmp.next()) {
		   printOnceFlg= queryTmp.getColValue("print_once_flg", "1").equals("1");
		}
	} catch (Exception e) {
		e.printStackTrace();
	}
	return printOnceFlg;
 }

 public static String getTouchpointID(String letterID) throws Exception{

		String touchPoint="";
		if (letterID.equals("DECLINE_LETTER")) {
			touchPoint="2";
		}
		if (letterID.equals("COUNTER_OFFER_LETTER")){
			touchPoint="4";

		}
		if (letterID.equals("WELCOME_LETTER")) {
			touchPoint="1";

		}
		if (letterID.equals("EXPIRED_OFFER_LETTER")) {
			touchPoint="6";

		}
		if (letterID.equals("WITHDRAW_LETTER")) {
			touchPoint="5";

		}
		if (letterID.equals("FIRST_PAYMENT_LETTER")) {
			touchPoint="3";

		}
		if (letterID.equals("BATCH")) {
			touchPoint="8";

		}
		if (letterID.equals("CLOSING_DOCUMENT")) {
			touchPoint="7";

		}
		if (letterID.equals("EARLY_DISCLOSURE_DOCUMENT")) {
			touchPoint="9";

		}

		if (letterID.equals("INITIAL")) {
			touchPoint="10";

		}
		if (letterID.equals("FOLLOW_UP_1")) {
			touchPoint="12";

		}
		if (letterID.equals("FOLLOW_UP_2")) {
			touchPoint="13";

		}
		if (letterID.equals("MISSING_INFO")) {
			touchPoint="11";

		}
		if (letterID.equals("RISK_BASED_PRICING_LETTER"))
		{
			touchPoint="60";

		}
		if (letterID.equals("GEN_NOTIFICATION_LETTER"))
		{
			touchPoint="63";

		}

		return touchPoint;

	}

  protected Map getTouchpointInfo(String aLetterCategoryId) throws AppException {
	Map mapEvaluatorDocInfo = new HashMap();

	try {

	  // gets touchpoint ID from letter categoryID
	  String touchPoint = getTouchpointID(aLetterCategoryId);

	  Query queryTmp = new Query(this.conn);

	  // select all the documents that are defined for this touchpoint from config_touchpoints_documents table
	  String sql="select distinct ctd.document_id,ctd.evaluator_id,ctd.delivery_method_id,cd.doc_type_id from config_touchpoint_documents ctd,config_documents cd where ctd.evaluator_id = ? and ctd.touchpoint_id = ? and ctd.active_flg = 1 and ctd.document_id = cd.document_id";
	  queryTmp.prepareStatement(sql);
	  queryTmp.setString(2, touchPoint);

	  //go through each evaluator
		  for (int i=0;this.evaluatorIds != null && i < this.evaluatorIds.length;i++) {
			queryTmp.setLong(1, this.evaluatorIds[i]);
			queryTmp.executePreparedQuery();

			LinkedList listDocInfo = null;
			long prevEvaluatorId = -99;

			//Find document_id and store that into hashmap with doc_type_id and evaluator_id
			while (queryTmp != null && queryTmp.next()) {
				long evaluatorId = Long.parseLong(queryTmp.getColValue("evaluator_id","0"));

				  if (evaluatorId != prevEvaluatorId) {
				  if (prevEvaluatorId >= SYSTEM_EVALUATOR_ID) {
					DocumentInfo[] arrDocInfo = null;
					if (listDocInfo.size() > 0)
					  arrDocInfo = (DocumentInfo[]) listDocInfo.toArray(new DocumentInfo[0]);
					mapEvaluatorDocInfo.put(Long.valueOf(prevEvaluatorId), arrDocInfo);
				  }
				  listDocInfo = new LinkedList();
				}

				long documentId = Long.parseLong(queryTmp.getColValue("document_id","0"));
				String docTypeId = queryTmp.getColValue("doc_type_id","0");

				DocumentInfo docInfo = new DocumentInfo(evaluatorId, documentId, docTypeId);
				listDocInfo.add(docInfo);
				prevEvaluatorId = evaluatorId;

			}

			if (prevEvaluatorId >= SYSTEM_EVALUATOR_ID) {
				DocumentInfo[] arrDocInfo = null;
				if (listDocInfo.size() > 0)
					arrDocInfo = (DocumentInfo[]) listDocInfo.toArray(new DocumentInfo[0]);
				mapEvaluatorDocInfo.put(Long.valueOf(prevEvaluatorId), arrDocInfo);
			}

		  }

	} catch (Exception ex) {
      throw new AppException("failed to query config_touchpoint_documents for letter category ID=" + aLetterCategoryId, ex);
    }

	//returning hashmap
	return mapEvaluatorDocInfo;
  }

  protected Map getDocumentInfo(String aLetterCategoryId) throws AppException {
    Map mapEvaluatorDocInfo = new HashMap();
    String evaluatorWhereCondition = buildMatchMoreOrMoreIdsWhereCondition("ce.evaluator_id", " AND ", this.evaluatorIds);
    String sql = MessageFormat.format(CFGEVALDOCS_QUERY_SQL, new Object[] {evaluatorWhereCondition });
    PreparedStatement stmt = null;
    ResultSet rs = null;

    AppLogger.logger.log(Level.FINEST, Thread.currentThread().getName() +
      ": evaluator documents query SQL = <" + sql + ">");

    try {
      int idx = 1;
      stmt = conn.prepareStatement(sql);
      stmt.setString(idx++, aLetterCategoryId);
      for (int i=0;this.evaluatorIds != null && i < this.evaluatorIds.length;i++)
        stmt.setLong(idx++, this.evaluatorIds[i]);
      stmt.setString(idx++, aLetterCategoryId);
      rs = stmt.executeQuery();

      LinkedList listDocInfo = null;
      long prevEvaluatorId = -99;
      while (rs != null && rs.next()) {
        long evaluatorId = rs.getLong("evaluator_id");
        if (evaluatorId != prevEvaluatorId) {
          if (prevEvaluatorId >= SYSTEM_EVALUATOR_ID) {
            DocumentInfo[] arrDocInfo = null;
            if (listDocInfo.size() > 0)
              arrDocInfo = (DocumentInfo[]) listDocInfo.toArray(new DocumentInfo[0]);
            mapEvaluatorDocInfo.put(Long.valueOf(prevEvaluatorId), arrDocInfo);
          }
          listDocInfo = new LinkedList();
        }

        long documentId = rs.getLong("document_id");
        String docTypeId = rs.getString("doc_type_id");
        DocumentInfo docInfo = new DocumentInfo(evaluatorId, documentId, docTypeId);
        listDocInfo.add(docInfo);
        prevEvaluatorId = evaluatorId;
      }

      if (prevEvaluatorId >= SYSTEM_EVALUATOR_ID) {
        DocumentInfo[] arrDocInfo = null;
        if (listDocInfo.size() > 0)
          arrDocInfo = (DocumentInfo[]) listDocInfo.toArray(new DocumentInfo[0]);
        mapEvaluatorDocInfo.put(Long.valueOf(prevEvaluatorId), arrDocInfo);
      }
    }
    catch (SQLException ex) {
      throw new AppException("failed to query config_evaluator_documents for letter category ID=" +
      aLetterCategoryId, ex);
    }
	finally {
		try{ if(rs != null) rs.close(); }catch(Exception e1){e1.printStackTrace();}
		try{ if(stmt != null) stmt.close(); }catch(Exception e1){e1.printStackTrace();}
	}
    return mapEvaluatorDocInfo;
  }

  protected String buildMatchMoreOrMoreIdsWhereCondition(String aColumnName, String aPrefixWord, long[] someIds) {
    StringBuffer buf = new StringBuffer();
    if (someIds != null && someIds.length > 0) {
      buf.append(aPrefixWord == null ? "" : aPrefixWord);
      buf.append(aColumnName);
      if (someIds.length == 1)
        buf.append(" = ?");
      else {
        buf.append(" IN (");
        for (int i=0;i < someIds.length;i++) {
          buf.append('?');
          buf.append(i == (someIds.length - 1) ? ')' : ',');
        }
      }
    }
    return buf.toString();
  }

  protected StringBuffer appendWhitespaceIfNeeded(StringBuffer aBuffer) {
    if (aBuffer != null && aBuffer.length() > 0) {
      char lastChar = aBuffer.charAt(aBuffer.length() - 1);
      if (lastChar != ' ')
        aBuffer.append(' ');
    }
    return aBuffer;
  }

  protected StringBuffer appendCharIfNeeded(StringBuffer aBuffer, char aChar) {
    if (aBuffer != null && aBuffer.length() > 0) {
      int i = aBuffer.length() - 1;
      for (;i >= 0 && aBuffer.charAt(i) == ' ';i--) ;
      if (i >= 0 && aBuffer.charAt(i) == aChar) {
        // last non-blank character is character we are asked to append,
        // so we are all set
      }
      else
        aBuffer.append(aChar);
    }
    return aBuffer;
  }

  protected StringBuffer appendWordIfNeeded(StringBuffer aBuffer, String aWord) {
    if (aBuffer != null && aBuffer.length() > 0) {
      boolean wantAppend = true;
      int i = aBuffer.length() - 1;
      int idxStartOfLastWord = -1, idxEndOfLastWord = -1;
      for (;i >= 0 && aBuffer.charAt(i) == ' ';i--) ;
      if (i >= 0) {
        idxEndOfLastWord = i;
        for (--i;i >= 0 && aBuffer.charAt(i) != ' ';i--) ;
        if ((i >= 0 && aBuffer.charAt(i) == ' ') || (i < 0)) {
          idxStartOfLastWord = i + 1;
          String lastWord = aBuffer.substring(idxStartOfLastWord, idxEndOfLastWord + 1);
          wantAppend = !lastWord.equalsIgnoreCase(aWord);
        }
      }
      if (wantAppend) {
        aBuffer.append(' ');
        aBuffer.append(aWord);
        aBuffer.append(' ');

      }
    }
    return aBuffer;
  }
}
