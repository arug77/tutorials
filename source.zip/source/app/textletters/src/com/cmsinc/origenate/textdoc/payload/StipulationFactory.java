package com.cmsinc.origenate.textdoc.payload;

import java.util.Date;
import java.util.LinkedList;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import com.cmsinc.origenate.textdoc.AppLogger;
import com.cmsinc.origenate.textdoc.AppException;

/**
 * Simple factory class for creating instances of <code>Stipulation</code> 
 * by quering the database.<br>
 * 
 * Treat this class as "thread-hostile".<br>
 * 
 * @since Origenate 6.0
 */
public class StipulationFactory {
  private static final String QUERY_SQL = 
    "SELECT rs.STIPULATION_DESCRIPTION_TXT, cs.STIPULATION_TXT " +
    "FROM CREDIT_REQ_DECISION_STIP rs, CONFIG_STIPULATION cs " +
    "WHERE rs.DECISION_REF_ID = ? AND " +
    "      rs.EVALUATOR_ID = cs.EVALUATOR_ID AND " +
    "      rs.STIPULATION_ID = cs.STIPULATION_ID";

  private Connection conn = null;
  
  public StipulationFactory(Connection aConnection) {
    this.conn = aConnection;
  }
  
  public Stipulation[] getStipulations(long aDecisionRefId) throws AppException {
    LinkedList list = new LinkedList();
    PreparedStatement stmt = null;
    ResultSet rs = null;
    long elapsedQueryTime = 0;
    
    try {
      int idx = 1;
      long startQueryTime = (new Date()).getTime();
      stmt = this.conn.prepareStatement(QUERY_SQL);
      stmt.setLong(idx++, aDecisionRefId);
      rs = stmt.executeQuery();
      while (rs != null && rs.next()) { 
        Stipulation data = new Stipulation(rs.getString("STIPULATION_TXT"), 
          rs.getString("STIPULATION_DESCRIPTION_TXT"));
        list.add(data);
      }
      
      long endQueryTime = (new Date()).getTime();
      elapsedQueryTime = endQueryTime - startQueryTime;
    }
    catch (SQLException ex) {
      throw new AppException("failed to query CREDIT_REQ_DECISION_STIP for request ID=" + aDecisionRefId, ex);
    }
    finally {
		try{ if(rs != null) rs.close(); }catch(Exception e1){e1.printStackTrace();}
		try{ if(stmt != null) stmt.close(); }catch(Exception e1){e1.printStackTrace();}
	}
    
    AppLogger.logger.log(Level.FINEST, Thread.currentThread().getName() + 
      ": queried " + list.size() + " Stipulation object in " + elapsedQueryTime + " ms");
    
    Stipulation[] arrData = null;
    if (list.size() > 0)
      arrData = (Stipulation[]) list.toArray(new Stipulation[0]);
    return arrData;
  }
}
