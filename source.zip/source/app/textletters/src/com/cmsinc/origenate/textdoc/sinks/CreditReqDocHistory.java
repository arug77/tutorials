package com.cmsinc.origenate.textdoc.sinks;

import java.util.Date;

/**
 * Data about the history of document related of a credit request such as a decline 
 * letter, counter-offer letter, etc.<br>
 * 
 * Treat this class as "thread-safe", since it is immutable once created.
 * 
 * @since Origenate 6.0
 */
public class CreditReqDocHistory {
  
  private long requestId = -1;
  private long evaluatorId = -1;
  private long documentId = -1;
  private int submitReasonId = -1;
  private long packageId = -1;
  private long jobId = -1;
  private long batchJobId = -1;
  private String jobType = null;
  private String jobName = null;
  private String status = null;
  private String error = null;
  private String user = null;
  private String centralProServer = null;
  private String faxServer = null;
  private String faxNumber = null;
  private int numberOfCopies = -1;
  private String comment = null;
  private Date datePrinted = null;
  private Date dateCreated = null;
         
  public CreditReqDocHistory(long aRequestId, long anEvaluatorId, long aDocumentId, int aSubmitReasonId) {
    this.requestId = aRequestId;
    this.evaluatorId = anEvaluatorId;
    this.documentId = aDocumentId;
    this.submitReasonId = aSubmitReasonId;
    this.dateCreated = new Date();
  }
  
  public long getRequestId() {
    return this.requestId;
  }
  
  public void setRequestId(long aRequestId) {
    this.requestId = aRequestId;
  }  
  
  public long getEvaluatorId() {
    return this.evaluatorId;
  }
  
  public void setEvaluatorId(long anEvaluatorId) {
    this.evaluatorId = anEvaluatorId;
  }
  
  public long getDocumentId() {
    return this.documentId;
  }
  
  public void setDocumentId(long aDocumentId) {
    this.documentId = aDocumentId;
  }  
  
  public int getSubmitReasonId() {
    return this.submitReasonId;
  }
  
  public void setSubmitReasonId(int aSubmitReasonId) {
    this.submitReasonId = aSubmitReasonId;
  }  
  
  public long getPackageId() {
    return this.packageId;
  }
  
  public void setPackageId(long aPackageId) {
    this.packageId = aPackageId;
  }  
  
  public long getJobId() {
    return this.jobId;
  }
  
  public void setJobId(long aJobId) {
    this.jobId = aJobId;
  }
  
  public long getBatchJobId() {
    return this.batchJobId;
  }
  
  public void setBatchJobId(long aBatchJobId) {
    this.batchJobId = aBatchJobId;
  }  
  
  public String getJobType() {
    return this.jobType;
  }
  
  public void setJobType(String aJobType) {
    this.jobType = aJobType;
  }  
  
  public String getJobName() {
    return this.jobName;
  }
  
  public void setJobName(String aJobName) {
    this.jobName = aJobName;
  }  
  
  public String getStatus() {
    return this.status;
  }
  
  public void setStatus(String aStatus) {
    this.status = aStatus;
  }  
  
  public String getError() {
    return this.error;
  }
  
  public void setError(String anError) {
    this.error = anError;
  }  
  
  public String getUser() {
    return this.user;
  }
  
  public void setUser(String aUser) {
    this.user = aUser;
  }  
  
  public String getCentralProServer() {
    return this.centralProServer;
  }
  
  public void setCentralProServer(String aServer) {
    this.centralProServer = aServer;
  }  
  
  public String getFaxServer() {
    return this.faxServer;
  }
  
  public void setFaxServer(String aServer) {
    this.faxServer = aServer;
  }  
  
  public String getFaxNumber() {
    return this.faxNumber;
  }
  
  public void setFaxNumber(String aFaxNumber) {
    this.faxNumber = aFaxNumber;
  }  
  
  public int getNumberOfCopies() {
    return this.numberOfCopies;
  }
  
  public void setNumberOfCopies(int aCopyCount) {
    this.numberOfCopies = aCopyCount;
  }
  
  public String getComment() {
    return this.comment;
  }
  
  public void setComment(String aComment) {
    this.comment = aComment;
  }  
  
  public java.sql.Date getDatePrinted() {
    return new java.sql.Date(this.datePrinted.getTime());
  }
  
  public void setDatePrinted(Date aDate) {
    this.datePrinted = aDate;
  }

  public java.sql.Date getDateCreated() {
    return new java.sql.Date(this.dateCreated.getTime());
  }
  
  public void setDateCreated(Date aDate) {
    this.dateCreated = aDate;
  }
}
