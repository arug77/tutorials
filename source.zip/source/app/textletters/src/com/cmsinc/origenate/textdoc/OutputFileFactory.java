package com.cmsinc.origenate.textdoc;

import java.util.Date;
import java.util.Map;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Collections;
import java.text.SimpleDateFormat;
import java.io.IOException;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.io.File;

import com.cmsinc.origenate.util.OWASPSecurity;

/**
 * Factory class for creating extract output files.
 * 
 * Treat this class as "thread-safe".
 * 
 * @since Origenate 6.0
 */
public class OutputFileFactory {
  /**
   * Inner class that represents an output file.
   */
  static class OutputFile {
    private PrintWriter writer = null;
    private File file = null;
    private boolean isNewlyOpened = true;
    
    OutputFile(PrintWriter aWriter, File aFile) {
      this.writer = aWriter;
      this.file = aFile;
    }
    
    public PrintWriter getWriter() {
      return this.writer;
    }
    
    public File getFile() {
      return this.file;
    }
    
    public boolean isNewlyOpened() {
      return this.isNewlyOpened;
    }
    
    public void setNewlyOpened(boolean aNewlyOpenedFlag) {
      isNewlyOpened = aNewlyOpenedFlag;
    }    
  }

  /**
   * Inner class that serves as key to file map.
   */
  private static class FileMapKey {
    private String evaluatorName = null;
    private String letterCategory = null;
    private String documentType = null;
    
    FileMapKey(String anEvaluatorName, String aLetterCategory, String aDocumentType) {
      this.evaluatorName = anEvaluatorName;
      this.letterCategory = aLetterCategory;
      this.documentType = aDocumentType;
    }
    
    private String buildConcatenatedKey() {
      StringBuffer buf = new StringBuffer();
      buf.append(this.evaluatorName == null ? "X" : this.evaluatorName);
      buf.append('.');
      buf.append(this.letterCategory == null ? "Y" : this.letterCategory);
      buf.append('.');
      buf.append(this.documentType == null ? "Z" : this.documentType);
      return buf.toString();
    }
    
    public boolean equals(Object obj) {
      boolean isEquals = false;
      if (obj instanceof FileMapKey) {
        FileMapKey other = (FileMapKey) obj;
        isEquals = this.buildConcatenatedKey().equals(other.buildConcatenatedKey());
      }
      return isEquals;
    }
    
    public int hashCode() {
      return buildConcatenatedKey().hashCode();
    }
  }
  
  public static final String DECLINED = "DECLIN";
  
  public static final String COUNTER_OFFER = "CTROFR";
  
  public static final String WELCOME = "WELCOM";

  public static final String EXPIRED = "EXPIRE";

  public static final String GEN_NOTIFICATION = "GNNOTF";

  public static final String WITHDRAW = "WITHDRW";
  
  public static final String CLOSING = "CLOSIN";
  
  public static final String FIRST_PAYMENT = "FSTPYMT";
  
  public static final String RISK_BASED_PRICING = "RKBEDPRICIN";
  
  public static final String MISSING_INFO = "MISININFO";
  
  public static final String EARLY_DISCLOSURE_DOCUMENT = "ELYDISC";
  
  public static final String INITIAL = "INTIAL";
  
  public static final String FOLLOW_UP_1 = "FOLUP1";
  
  public static final String FOLLOW_UP_2 = "FOLUP2";
  
  private String outputDirectory = null;
  
  private Map mapFiles = null;
  
  private static OutputFileFactory factory = null;
  
  public static synchronized OutputFileFactory getInstance(String anOutputDirectory) {
    if (factory == null)
      factory = new OutputFileFactory(anOutputDirectory);
    return factory;
  }
  
  private OutputFileFactory(String anOutputDirectory) {
    this.mapFiles = new HashMap();
    this.mapFiles = Collections.synchronizedMap(this.mapFiles );
    this.outputDirectory = anOutputDirectory;
  }
  
  public OutputFile getFile(String anEvaluatorName, String aLetterCategory, 
    String aDocumentType) throws AppException {

    FileMapKey key = new FileMapKey(anEvaluatorName, aLetterCategory, aDocumentType);
    OutputFile outputFile = (OutputFile) this.mapFiles.get(key);
    if (outputFile == null) {
      File file = null;
      try {
        String filename = buildFilename(anEvaluatorName, aLetterCategory, aDocumentType);
        
        /**  
        * OWASP TOP 10 2010 - A4 Path Manipulation
        * Changes to the below code to fix vulnerabilities
        */
        //file = new File(this.outputDirectory, filename);
        try
        {
        file = new File(OWASPSecurity.validationCheck(this.outputDirectory, OWASPSecurity.DIRANDFILE), OWASPSecurity.validationCheck(filename, OWASPSecurity.DIRANDFILE));
        }
        catch(Exception e)
        {
          e.printStackTrace();
        }
        FileWriter fw = new FileWriter(file); 
        PrintWriter pw = new PrintWriter(fw);
        outputFile = new OutputFile(pw, file);
        this.mapFiles.put(key, outputFile);
      }
      catch (IOException ex) {
        throw new AppException("failed to create new extract file '" + 
          (file == null ? "NULL" : file.getAbsolutePath()) + "'", ex);
      }
    }
    return outputFile;
  }
  
  public File[] closeAllFiles() {
    int idxFile = 0;
    File[] allFiles = new File[this.mapFiles.size()];
    for (Iterator iter=this.mapFiles.values().iterator();iter.hasNext();) {
      OutputFile outputFile = (OutputFile) iter.next();
      outputFile.writer.flush();
      outputFile.writer.close();
      allFiles[idxFile++] = outputFile.file;
    }
    return allFiles;
  }
  
  private String buildFilename(String anEvaluatorName, String aLetterCategory, String aDocumentType) {
    StringBuffer buf = new StringBuffer();
    buf.append(normalizeForFileSystem(anEvaluatorName));
    buf.append('.');
    buf.append(normalizeForFileSystem(aLetterCategory));
    buf.append('.');
    buf.append(normalizeForFileSystem(aDocumentType));
    buf.append('.');
    
    Date now = new Date();
    SimpleDateFormat fmt = new SimpleDateFormat("yyyyMMdd.HHmmss");
    buf.append(fmt.format(now));
    buf.append(".CSV");
    return buf.toString();
  }
  
  private String normalizeForFileSystem(String aDatum) {
    char[] chDatum = aDatum.toCharArray();
    char[] chNormal = new char[chDatum.length];
    for (int i=0;i < chDatum.length;i++) {
      chNormal[i] = Character.isLetter(chDatum[i]) || Character.isDigit(chDatum[i]) ?
        chDatum[i] : '_';
    }
    return new String(chNormal);
  }
}
