package com.cmsinc.origenate.textdoc;

import java.util.logging.Level;

/**
 * Manages threads in parallel fashion, i.e., runs each thread simultaneously.<br>
 * 
 * Treat this class itself as "thread-hostile" (it should be called from
 * the main thread).
 * 
 * @since Origenate 6.0
 */
public class ParallelThreadManager extends ThreadManager {
  private int initialNap = -1;
  private int pulseCheckNap = -1;
  private int joinWaitMillis = -1;
  
  ParallelThreadManager(ThreadGroup aThreadGroup, Thread[] someThreads, int anInitialNap, int aPulseCheckNap, int aJoinWaitMillis) {
    super(aThreadGroup, someThreads);
    this.initialNap = anInitialNap;
    this.pulseCheckNap = aPulseCheckNap;
    this.joinWaitMillis = aJoinWaitMillis;
  }
  
  void run() {
    if (super.threads == null || super.threads.length == 0)
      return;
    AppLogger.logger.log(Level.INFO, "executing " + super.threads.length + " threads in parallel ...");
    
    // Start all worker threads running in parallel.
    
    for (int i=0;i < super.threads.length;i++) {
      Thread thread = super.threads[i];
      thread.start();
    }
    
    // Loop (and sleep) until all worker threads have completed.
    
    workerThreadPulseLoop: 
    for (boolean isInitialPulseCheck=true;;isInitialPulseCheck=false) {
      //
      // Sleep while worker threads complete. We wait much longer
      // the first time, since initially the worker threads will be 
      // busy extracting data for letters.
      
      try {
        long napMillis = isInitialPulseCheck ? this.initialNap : this.pulseCheckNap;
        AppLogger.logger.log(Level.FINEST, Thread.currentThread().getName() + 
          ": waiting " + napMillis + " ms for thread death"); 
        Thread.sleep(napMillis); 
      }
      catch (InterruptedException ex) {
        //
        // If the main thread is interrupted, we quit this method and the main
        // thread terminates; since the worker threads are daemon threads,
        // they will die ungraciously with the main thread. So interrupting the 
        // main thread kills the whole app.
        
        AppLogger.logger.log(Level.FINEST, Thread.currentThread().getName() + 
          ": sleep() interrupted!"); 
        break workerThreadPulseLoop;
      }
    
      // If no active threads in worker thread group, all worker threads finished, 
      // we are done. We expect this check to usually terminate this app.
      
      AppLogger.logger.log(Level.FINEST, Thread.currentThread().getName() + 
        ": check active thread count");
      if (super.threadGroup.activeCount() == 0)
        break workerThreadPulseLoop;
      
      // Fall into "fail-safe" thread death detection code. If thread group reports 
      // some threads active, try to join with each thread ourselves. If a thread 
      // has died, mark it's slot in the thread array as NULL (note if join is 
      // interrupted, whole app dies, as explained above).      
      
      AppLogger.logger.log(Level.FINEST, Thread.currentThread().getName() + 
        ": active thread count non-zero (" + super.threadGroup.activeCount() + 
        "), try joining with worker threads, join-wait-time = " + joinWaitMillis + " ms");

      for (int i=0; i < super.threads.length;i++) {
        if (super.threads[i] != null) {
          try {
            super.threads[i].join(joinWaitMillis);
            if (!super.threads[i].isAlive())
              super.threads[i] = null;
          }
          catch (InterruptedException ex) {
            AppLogger.logger.log(Level.FINEST, Thread.currentThread().getName() + 
              ": join() interrupted!");
            break workerThreadPulseLoop;
          }
        }
      }

      // See if all threads are marked as dead (NULL), if so exit loop.
      
      AppLogger.logger.log(Level.FINEST, Thread.currentThread().getName() + 
        ": count remaining live threads after join");      
      boolean allWorkerThreadsFinished = true;
      for (int i=0; i < super.threads.length ;i++) {
        if (super.threads[i] != null)
          allWorkerThreadsFinished = false;
      }
      if (allWorkerThreadsFinished) {
        AppLogger.logger.log(Level.FINEST, Thread.currentThread().getName() + 
          ": joined with all worker threads, done");
        break workerThreadPulseLoop;
      }
    }
  }
}
