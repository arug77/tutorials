package com.cmsinc.origenate.textdoc.sources;

import java.util.Map;
import com.cmsinc.origenate.tool.origaging.AppException;

/**
 * This class uses a map of name/value pairs as the source of the document field value.
 */
public class NVPairSource {
  
  private String key = null;
  
  private Map mapNVPair = null;
  
  NVPairSource(String aKey, Map aMapOfNVPair) {
    this.key = aKey;
    this.mapNVPair = aMapOfNVPair;
  }
  
  public String getValue() throws AppException {
    return (String) this.mapNVPair.get(this.key);
  }
}
