package com.cmsinc.origenate.textdoc.sinks;

import java.util.Date;

/**
 * Credit request journal entry.<br>
 * 
 * Treat this class as "thread-safe", since it is immutable once created.
 * 
 * @since Origenate 6.0
 */
public class CreditRequestJournal {

  private long requestId = -1;
  private long evaluatorId = -1;
  private long journalId = -1;
  private long journalEventId = -1;
  private long appSeqno = -1;
  private int appStatusId = -1;
  private String journalEvent = null;
  private String user = null;
  private String task = null;
         
  public CreditRequestJournal(long aRequestId, long anEvaluatorId, long aJournalEventId, 
    long anAppSeqno, int anAppStatusId, String aJournalEvent, String aTask) {
    this.requestId = aRequestId;
    this.evaluatorId = anEvaluatorId;
    this.journalEventId = aJournalEventId;
    this.appSeqno = anAppSeqno;
    this.appStatusId = anAppStatusId;
    this.journalEvent = aJournalEvent;
    this.task = aTask;
  }
  
  public long getRequestId() {
    return this.requestId;
  }
  
  public void setRequestId(long aRequestId) {
    this.requestId = aRequestId;
  }  
  
  public long getEvaluatorId() {
    return this.evaluatorId;
  }
  
  public void setEvaluatorId(long anEvaluatorId) {
    this.evaluatorId = anEvaluatorId;
  }
  
  public long getJournalId() {
    return this.journalId;
  }
  
  public void setJournalId(long aJournalId) {
    this.journalId = aJournalId;
  }  

  public long getJournalEventId() {
    return this.journalEventId;
  }
  
  public void setJournalEventId(long aJournalEventId) {
    this.journalEventId = aJournalEventId;
  }  
  
  public long getAppSeqno() {
    return this.appSeqno;
  }
  
  public void setAppSeqno(long aAppSeqno) {
    this.appSeqno = aAppSeqno;
  }    
  
  public int getAppStatusId() {
    return this.appStatusId;
  }

  public void setAppStatusId(int anAppStatusId) {
    this.appStatusId = anAppStatusId;
  }
  
  public String getJournalEvent() {
    return this.journalEvent;
  }

  public void setJournalEvent(String aJournalEvent) {
    this.journalEvent = aJournalEvent;
  }
  
  public String getUser() {
    return this.user;
  }
  
  public void setUser(String aUser) {
    this.user = aUser;
  }
  
  public String getTask() {
    return this.task;
  }
  
  public void setTask(String aTask) {
    this.user = aTask;
  }      

}
