package com.cmsinc.origenate.textdoc;

import com.cmsinc.origenate.util.COLEncrypt;
import com.cmsinc.origenate.util.IniFile;

public class ConfigInfo { 
  public static final String CLIENTNAME_CFGVAR_NAME = "general.client_name";
  public static final String DBHOST_CFGVAR_NAME = "database.host";
  public static final String DBPORT_CFGVAR_NAME = "database.port";
  public static final String DBSID_CFGVAR_NAME = "database.sid";
  public static final String DBUSER_CFGVAR_NAME = "database.user";
  public static final String DBPASSWD_CFGVAR_NAME = "database.password";
  public static final String LOGFILE_CFGVAR_NAME = "logs.textdoc_log_file";
  public static final String LOGLEVEL_CFGVAR_NAME = "debug.textdoc_dbg_lvl";
  public static final String THREADING_CFGVAR_NAME = "textdoc.threading";
  public static final String INITIALNAP_CFGVAR_NAME = "textdoc.headstart_nap";
  public static final String PULSECHECKNAP_CFGVAR_NAME = "textdoc.nap_between_pulsecheck";
  public static final String JOINWAITMILLIS_CFGVAR_NAME = "textdoc.worker_thread_join_wait_millis";
  public static final String TNSENTRY_CFGVAR_NAME = "database.TNSEntry";
  
  public static final String[] allCfgvarNames = {
    CLIENTNAME_CFGVAR_NAME,
    DBHOST_CFGVAR_NAME,
    DBPORT_CFGVAR_NAME,
    DBSID_CFGVAR_NAME,
    DBUSER_CFGVAR_NAME,
    DBPASSWD_CFGVAR_NAME,
    LOGFILE_CFGVAR_NAME,
    LOGLEVEL_CFGVAR_NAME,
    THREADING_CFGVAR_NAME,
    INITIALNAP_CFGVAR_NAME,
    PULSECHECKNAP_CFGVAR_NAME,
    JOINWAITMILLIS_CFGVAR_NAME,
    TNSENTRY_CFGVAR_NAME
  };

  private static ConfigInfo singleton = null;
  
  public synchronized static ConfigInfo getInstance(String aConfigFilePath) throws AppException {
    if (singleton == null)
      singleton = new ConfigInfo(aConfigFilePath);
    return singleton;
  }
  
  private String clientName = null;
  private String dbUser = null;
  private String dbPasswdCipher = null;
  private String dbHost = null;
  private String dbPort = null;
  private String dbSid = null;
  private String sTNSEntry = null;
  private String logFile = null;
  private String logLevel = null;
  private boolean isMultiThreaded = false;
  private int initialNap = -1;
  private int pulseCheckNap = -1;
  private int joinWaitMillis = -1;
  
  private ConfigInfo(String aConfigFilePath) throws AppException {
    IniFile ini = null;
    try {
      ini = new IniFile();
      ini.readINIFile(aConfigFilePath);
    }
    catch (Exception ex) {
      throw new AppException("failed to read config .INI file '" + aConfigFilePath + "', ex = " + ex, ex);
    }

    this.clientName = ini.getINIVar(CLIENTNAME_CFGVAR_NAME);
    this.dbUser = ini.getINIVar(DBUSER_CFGVAR_NAME);
    this.dbPasswdCipher = ini.getINIVar(DBPASSWD_CFGVAR_NAME);
    this.dbHost = ini.getINIVar(DBHOST_CFGVAR_NAME);
    this.dbPort = ini.getINIVar(DBPORT_CFGVAR_NAME);
    this.dbSid = ini.getINIVar(DBSID_CFGVAR_NAME);
    this.sTNSEntry = ini.getINIVar(TNSENTRY_CFGVAR_NAME);
    this.logFile = ini.getINIVar(LOGFILE_CFGVAR_NAME);
    this.logLevel = ini.getINIVar(LOGLEVEL_CFGVAR_NAME);
    
    String strThreading = ini.getINIVar(THREADING_CFGVAR_NAME);
    if (strThreading == null || strThreading.trim().length() == 0)
      strThreading = "multi";
    if ("single".equalsIgnoreCase(strThreading))
      this.isMultiThreaded = false; 
    else if ("multi".equalsIgnoreCase(strThreading))
      this.isMultiThreaded = true;
    else 
      throw new AppException("config variable " + THREADING_CFGVAR_NAME + " must be 'single' or 'multi'");

    String strInitialNap = ini.getINIVar(INITIALNAP_CFGVAR_NAME);
    if (strInitialNap == null || strInitialNap.trim().length() == 0)
      strInitialNap = "-1";
    try { this.initialNap = Integer.parseInt(strInitialNap); }
      catch (NumberFormatException ex) { throw new AppException("config variable " + 
        INITIALNAP_CFGVAR_NAME + " must be an integer"); }
        
    String strPulseNap = ini.getINIVar(PULSECHECKNAP_CFGVAR_NAME);
    if (strPulseNap == null || strPulseNap.trim().length() == 0)
      strPulseNap = "-1";    
    try { this.pulseCheckNap = Integer.parseInt(strPulseNap); }
      catch (NumberFormatException ex) { throw new AppException("config variable " + 
        PULSECHECKNAP_CFGVAR_NAME + " must be an integer"); } 
      
    String strJoinWaitMillis = ini.getINIVar(JOINWAITMILLIS_CFGVAR_NAME);
    if (strJoinWaitMillis == null || strJoinWaitMillis.trim().length() == 0)
      strJoinWaitMillis = "-1";      
    try { this.joinWaitMillis = Integer.parseInt(strJoinWaitMillis); }
      catch (NumberFormatException ex) { throw new AppException("config variable " + 
        JOINWAITMILLIS_CFGVAR_NAME + " must be an integer"); }
  }

  public String getClientName() {
    return this.clientName;
  }
  
  public String getDbUser() {
    return this.dbUser;
  }
  
  public String getDbPasswd() {
    return COLEncrypt.sDecrypt(this.dbPasswdCipher);
  }
  
  public String getDbHost() {
    return this.dbHost;
  }
  
  public String getDbPort() {
    return this.dbPort;
  }
  
  public String getDbSid() {
    return this.dbSid;
  }
  
  public String getTNSEntry() {
	  return this.sTNSEntry;
  }
  
  public String getLogFile() {
    return this.logFile;
  }
  
  public String getLogLevel() {
    return this.logLevel;
  }
  
  public boolean isMultiThreaded() {
    return this.isMultiThreaded;
  }
  
  public int getInitialNap() {
    return this.initialNap;
  }
  
  public int getPulseCheckNap() {
    return this.pulseCheckNap;
  } 
  
  public int getWorkerThreadJoinWaitMillis() {
    return this.joinWaitMillis;
  }  
}
