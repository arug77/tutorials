package com.cmsinc.origenate.textdoc;

/**
 * Exception thrown by other classes in credit request aging application.
 * 
 * Treat this class as "thread-safe".
 * 
 * @since Origenate 6.0
 */
public class AppException extends java.lang.Exception {
  /**
   * Public ctor for creating an instance of this class.
   * 
   * @param aMessage
   *   an error message.
   */
  public AppException(String aMessage) {
  	super(aMessage);
  }
  
  /**
   * Public ctor for creating an instance of this class.
   * 
   * @param aMessage
   *   an error message.
   * @param anException
   *   the causing exception.
   */
  public AppException(String aMessage, Throwable anException) {
  	super(aMessage, anException);
  }  
}
