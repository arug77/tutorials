package com.cmsinc.origenate.textdoc.payload;

import java.util.Date;
import java.math.BigDecimal;

/**
 * Data about a decision (i.e., approved) regarding a credit request.<br>
 * 
 * Treat this class as "thread-safe", since it is immutable once created.
 * 
 * @since Origenate 6.0
 */
public class CreditRequestDecision {
         
  private long decisionId = -1;
  private long decisionRefId = -1;
  private BigDecimal amount = null;
  private BigDecimal rate = null;
  private BigDecimal payment = null;
  private int term = -1;
  private Date receivedDate = null;
  private BigDecimal approvedBuyRate = null;
  private String decisionUserId = null;
  private String decisionDesc = null;
  private String phoneNumber = null;
  private String comments = null;

  public CreditRequestDecision(long aDecisionId, long aDecisionRefId, BigDecimal anAmount, BigDecimal aRate,
    BigDecimal aPayment, int aTerm, Date aReceivedDate, BigDecimal anApprovedBuyRate,
    String aDecisionUserId, String aDecisionDesc, String aPhoneNumber, String aComment) {
    this.decisionId = aDecisionId;
    this.decisionRefId = aDecisionRefId;
    this.amount = anAmount;
    this.rate = aRate;
    this.payment = aPayment;
    this.term = aTerm;
    this.receivedDate = aReceivedDate;
    this.approvedBuyRate = anApprovedBuyRate;
    this.decisionUserId = aDecisionUserId;
    this.decisionDesc = aDecisionDesc;
    this.phoneNumber = aPhoneNumber;
    this.comments = aComment;    
  }

  public long getDecisionId() {
    return this.decisionId;
  }
  
  public long getDecisionRefId() {
    return this.decisionRefId;
  }
  
  public BigDecimal getApprovedAmount() {
    return this.amount;
  }
  
  public BigDecimal getApprovedRate() {
    return this.rate;
  }
  
  public BigDecimal getApprovedPayment() {
    return this.payment;
  }
  
  public int getApprovedTerm() {
    return this.term;
  }
  
  public Date getDecisionDate() {
    return this.receivedDate;
  }
  
  public BigDecimal getApprovedBuyRate() {
    return this.approvedBuyRate;
  }
  
  public String getDecisionUserId() {
    return this.decisionUserId;
  }
  
  public String getDecisionDesc() {
    return this.decisionDesc;
  }
  
  public String getPhoneNumber() {
    return this.phoneNumber;
  }
  
  public String getComments() {
    return this.comments;
  }
}
