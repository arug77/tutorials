package com.cmsinc.origenate.textdoc.payload;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import java.util.logging.Level;
import com.cmsinc.origenate.textdoc.AppLogger;
import com.cmsinc.origenate.textdoc.AppException;

/**
 * Simple factory class for creating instances of <code>BureauRBP</code> 
 * by quering the database.<br>
 * 
 * Treat this class as "thread-hostile".<br>
 * 
 * @since Origenate 8.5.25
 */
public class BureauRBPFactory 
{

	private Connection conn = null;
  
	public BureauRBPFactory(Connection aConnection) 
	{
		this.conn = aConnection;
	}
  
	public BureauRBP getBureauRBP(long aRequestId, long aRequestorId) throws AppException 
	{
		String QUERY_SQL =  "SELECT "+
						    "CASE " +
							"WHEN substr(es.BUREAUOFRECORD,1,3)='EFX' THEN RBP_EFX_LOW " +
							"WHEN substr(es.BUREAUOFRECORD,1,3)='XPN' THEN RBP_XPN_LOW " +
							"WHEN substr(es.BUREAUOFRECORD,1,3)='TRU' THEN RBP_TRU_LOW " +
							"ELSE '' " +
							"END AS LOW, " +
							"CASE " +
							"WHEN substr(es.BUREAUOFRECORD,1,3)='EFX' THEN RBP_EFX_HIGH " +
							"WHEN substr(es.BUREAUOFRECORD,1,3)='XPN' THEN RBP_XPN_HIGH " +
							"WHEN substr(es.BUREAUOFRECORD,1,3)='TRU' THEN RBP_TRU_HIGH " +
							"ELSE '' " +
							"END AS HIGH, " +
							"CASE " +
							"WHEN substr(es.BUREAUOFRECORD,1,3)='EFX' THEN RBP_EFX_INQ_FLG " +
							"WHEN substr(es.BUREAUOFRECORD,1,3)='XPN' THEN RBP_XPN_INQ_FLG " +
							"WHEN substr(es.BUREAUOFRECORD,1,3)='TRU' THEN RBP_TRU_INQ_FLG " +
							"ELSE '' " +
							"END AS INQ " +
							"FROM EVAPP_SEQNO es LEFT OUTER JOIN EVAPP_INTERFACE_APPENTITY eia ON (es.APPSEQNO = eia.APPSEQNO) " +
							"WHERE es.REQUEST_ID = ? " +
							"AND eia.REQUESTOR_ID = ? ";
		
		BureauRBP data = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		long elapsedQueryTime = 0;
    
		try 
		{
			int idx = 1;
			long startQueryTime = (new Date()).getTime();
			stmt = this.conn.prepareStatement(QUERY_SQL);
			stmt.setLong(idx++, aRequestId);
			stmt.setLong(idx++, aRequestorId);
			rs = stmt.executeQuery();
			if (rs != null && rs.next()) 
			{ 
          
				data = new BureauRBP(rs.getString("LOW"), rs.getString("HIGH"), 
					rs.getString("INQ"));
			}
      
			long endQueryTime = (new Date()).getTime();
			elapsedQueryTime = endQueryTime - startQueryTime;
		}
		catch (SQLException ex) 
		{
			throw new AppException("failed to query EVAPP_INTERFACE_APPENTITY " +
				"for request ID=" + aRequestId + ", requestor ID=" + aRequestorId, ex);
		}
		finally {
			try{ if(rs != null) rs.close(); }catch(Exception e1){e1.printStackTrace();}
			try{ if(stmt != null) stmt.close(); }catch(Exception e1){e1.printStackTrace();}
		}

		AppLogger.logger.log(Level.FINEST, Thread.currentThread().getName() + 
			": queried " + 1 + " BureauRPB object in " + elapsedQueryTime + " ms");
		return data;
	}
}
