package com.cmsinc.origenate.textdoc.sources;

import com.cmsinc.origenate.tool.origaging.AppException;

/**
 * This class uses a constant as the source of the document field value.
 */
public class ConstantSource {
  private String constant = null;
  
  ConstantSource(String aConstant) {
    this.constant = aConstant;
  }
  
  public String getValue() throws AppException {
    return this.constant;
  }
}
