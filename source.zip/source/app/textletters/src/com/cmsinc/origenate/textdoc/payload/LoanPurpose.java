package com.cmsinc.origenate.textdoc.payload;

/**
 * Data about the purpose of a loan.<br>
 * 
 * Treat this class as "thread-safe", since it is immutable once created.
 * 
 * @since Origenate 6.0
 */
public class LoanPurpose {
  private String loanPurposeCode = null;
  
  public LoanPurpose(String aLoanPurposeCode) {
    this.loanPurposeCode = aLoanPurposeCode;
  }
  
  public String getLoanPurposeCode(){
    return this.loanPurposeCode;
  }
}
