package com.cmsinc.origenate.textdoc.letters;

import java.util.Date;

/**
 * Abstract base class that represent an instance of a "flat-file" letter
 * such as declined or counter-offer letter.
 * 
 * Treat this class as "thread-safe", since it is immutable (but not 
 * actually operated on by multiple threads in this app).
 * 
 * @since Origenate 6.0
 */
public class Letter {
  private long requestId = -1;
  private long evaluatorId = -1;
  private String evaluatorName = null;
  private long clientAppId = -1;
  private Date initiationDate = null;
  private long appStatusId = -1;
  private String taskId = null;
  private boolean isPersonalApp = false;
  private long documentId = -1;
  private String documentType = null;
  private int numberOfDelayDays = -1;
  private String bodyText = null;
  private String letterType = null;
  
  Letter(long aRequestId, long anEvaluatorId, String anEvaluatorName, long aClientAppId, 
    Date anInitiationDate, long anAppStatusId, String aTaskId, boolean aPersonalFlag, 
    long aDocumentId, String aDocumentType, int aNumberOfDelayDays, String aBodyText, String aLetterType) {
    this.requestId = aRequestId;
    this.evaluatorId = anEvaluatorId;
    this.evaluatorName = anEvaluatorName;
    this.clientAppId = aClientAppId;
    this.initiationDate = anInitiationDate;
    this.appStatusId = anAppStatusId;
    this.taskId = aTaskId;
    this.isPersonalApp = aPersonalFlag;
    this.documentId = aDocumentId;
    this.documentType = aDocumentType;
    this.numberOfDelayDays = aNumberOfDelayDays;
    this.bodyText = aBodyText;
    this.letterType = aLetterType;
  }
  
  public long getRequestId() {
    return this.requestId;
  }
  
  public long getEvaluatorId() {
    return this.evaluatorId;
  }
  
  public String getEvaluatorName() {
    return this.evaluatorName;
  }  
  
  public long getClientAppId() {
    return this.clientAppId;
  }
  
  public Date getInitiationDate() {
    return this.initiationDate;
  }
  
  public long getAppStatusId() {
    return this.appStatusId;
  }
  
  public String getTaskId() {
    return this.taskId;
  }
  
  public boolean isPersonalApp() {
    return this.isPersonalApp;
  }
  
  public long getDocumentId() {
    return this.documentId;
  }
  
  public String getDocumentType() {
    return this.documentType;
  }
  
  public int getDelayDays() {
    return this.numberOfDelayDays;
  }
  
  public String getBodyText() {
    return this.bodyText;
  }
  
  public String getLetterType() {
    return this.letterType;
  }  
}
