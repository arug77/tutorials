package com.cmsinc.origenate.textdoc.letters;

import java.sql.Connection;

/**
 * Factory for selecting accepted credit apps and creating <code>WelcomeLetter</code> instances.<br>
 * 
 * Treat this class as "thread-hostile".
 * 
 * @since Origenate 6.0
 */
public class WelcomeLetterFactory extends LetterFactory {
  private static final String WELCOME_SELECT_LIST = 
    "cps.welcome_delay_days_num delay_days, ev.welcome_printer_txt printer_text";
    
  private static final String WELCOME_FROM_CLAUSE = 
    "xref_tasks_in_task_group xq";

  /**
   * To select welcome (accepted and booked) apps: 
   * 
   * The application must have a decision status of APPROVE or CONDITIONAL and a 
   * booking status of Booked or Booked w/Exception.
   * Decision status: 1=conditional, 3=approved, 102=appscor (auto approved)
   * Booking status: 2=booked, 3=bookedex
   */  
  private static final String WELCOME_WHERE_CLAUSE =     
    "cr.decision_status_id IN (1,3,102) AND " +
    "cr.booking_status_id IN (2,3) AND " +
    "cr.task_id = xq.task_id AND " +
    "cr.product_id = xq.product_id AND "+
    "(xq.evaluator_id = cr.evaluator_id OR xq.evaluator_id = -1) AND "+
	"sysdate > (cr.initiation_dt + cps.welcome_delay_days_num)";

    
  public static final String LETTER_CATEGORY = "WELCOME_LETTER";
   
  protected String getLetterCategory() {
    return LETTER_CATEGORY;
  }
  
  /**
   * Restricted ctor for creating an instance of this class.
   *  
   * @param someEvaluatorIds
   *  evaluators to search by, or null to search regardless of evaluator.
   */
  public WelcomeLetterFactory(Connection aConnection, long[] someEvaluatorIds) {
    super(aConnection, LETTER_CATEGORY, someEvaluatorIds);
  }
  
  protected StringBuffer selectList() {
    StringBuffer buf = super.selectList();
    buf = appendCharIfNeeded(buf, ',');
    buf.append(WELCOME_SELECT_LIST);
    return buf;
  }
  
  protected StringBuffer fromClause() {
    StringBuffer buf = super.fromClause();
    buf = appendCharIfNeeded(buf, ',');
    buf.append(WELCOME_FROM_CLAUSE);
    return buf;
  }  
  
  protected StringBuffer whereClause() {
    StringBuffer buf = super.whereClause();
    buf = appendWordIfNeeded(buf, "AND");
    buf.append(WELCOME_WHERE_CLAUSE);
    return buf;
  }  
}
