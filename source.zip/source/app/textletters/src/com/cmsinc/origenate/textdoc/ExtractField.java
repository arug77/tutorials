package com.cmsinc.origenate.textdoc;

import com.cmsinc.origenate.textdoc.formatters.FieldFormatter;
import com.cmsinc.origenate.textdoc.formatters.DefaultFormatter;
import com.cmsinc.origenate.textdoc.formatters.AmountAsNumbersFormatter;
import com.cmsinc.origenate.textdoc.formatters.AmountAsWordsFormatter;
import com.cmsinc.origenate.textdoc.formatters.SSNFormatter;
import com.cmsinc.origenate.textdoc.formatters.PhoneFormatter;
import com.cmsinc.origenate.textdoc.formatters.DateFormatter;
import com.cmsinc.origenate.textdoc.formatters.ZipcodeFormatter;

/**
 * Represents an extracted data field that is sent as output data to a flat
 * file. All extract fields are defined in this class.<br>.
 * 
 * Treat this class as "thread-safe", although an instance is only used by a
 * single thread in this aplication.
 * 
 * @since Origenate 6.0
 */
public class ExtractField implements Comparable {

	/**
	 * Used to automatically set field position based on order of static field
	 * declarations below that define all of fields in the extract output.
	 */
	private static int nextOrdinal = 0;

	// //////////////////////////////////////////////////////////////////////////
	// Static fields instances that make up the extract output. Place fields
	// here in the order they should appear in the extract.
	// //////////////////////////////////////////////////////////////////////////

	// //////////////////////////////////////////////////////////////////////////
	// Core credit request fields.
	// //////////////////////////////////////////////////////////////////////////

	public static final ExtractField CLIENT_APPL_ID = new ExtractField(
			"CLIENT_APPL_ID", null, new DefaultFormatter());

	public static final ExtractField INITIATION_DATE = new ExtractField(
			"INITIATION_DATE", null, new DateFormatter());

	// //////////////////////////////////////////////////////////////////////////
	// Evaluator address fields.
	// //////////////////////////////////////////////////////////////////////////

	public static final ExtractField EVALADDR_ADDRESS1 = new ExtractField(
			"EVALADDR_ADDRESS1", null, new DefaultFormatter());

	public static final ExtractField EVALADDR_ADDRESS2 = new ExtractField(
			"EVALADDR_ADDRESS2", null, new DefaultFormatter());

	public static final ExtractField EVALADDR_CITY = new ExtractField(
			"EVALADDR_CITY", null, new DefaultFormatter());

	public static final ExtractField EVALADDR_STATE = new ExtractField(
			"EVALADDR_STATE", null, new DefaultFormatter());

	public static final ExtractField EVALADDR_ZIPCODE = new ExtractField(
			"EVALADDR_ZIPCODE", null, new ZipcodeFormatter());

	public static final ExtractField EVALADDR_PHONE = new ExtractField(
			"EVALADDR_PHONE", null, new PhoneFormatter());

	public static final ExtractField EVALADDR_FAX = new ExtractField(
			"EVALADDR_FAX", null, new PhoneFormatter());

	// //////////////////////////////////////////////////////////////////////////
	// Evaluator originator fields.
	// //////////////////////////////////////////////////////////////////////////

	public static final ExtractField EVALORIG_ORIGINATOR_NAME = new ExtractField(
			"EVALORIG_ORIGINATOR_NAME", null, new DefaultFormatter());

	public static final ExtractField EVALORIG_DBA_NAME = new ExtractField(
			"EVALORIG_DBA_NAME", null, new DefaultFormatter());

	// //////////////////////////////////////////////////////////////////////////
	// Applicant fields. In the original specification, the applicant,
	// co-applicant
	// and co-signer fields are all the same, so these all may need to be kept
	// sync unless the requirements change.
	// //////////////////////////////////////////////////////////////////////////

	public static final ExtractField APPLICANT_LASTNAME = new ExtractField(
			"APPLICANT_LASTNAME", null, new DefaultFormatter());

	public static final ExtractField APPLICANT_FIRSTNAME = new ExtractField(
			"APPLICANT_FIRSTNAME", null, new DefaultFormatter());

	public static final ExtractField APPLICANT_MIDDLENAME = new ExtractField(
			"APPLICANT_MIDDLENAME", null, new DefaultFormatter());

	public static final ExtractField APPLICANT_NAMESUFFIX = new ExtractField(
			"APPLICANT_NAMESUFFIX", null, new DefaultFormatter());

	public static final ExtractField APPLICANT_SSN = new ExtractField(
			"APPLICANT_SSN", null, new SSNFormatter());

	public static final ExtractField APPLICANT_STREETNUMBER = new ExtractField(
			"APPLICANT_STREETNUMBER", null, new DefaultFormatter());

	public static final ExtractField APPLICANT_STREETNAME = new ExtractField(
			"APPLICANT_STREETNAME", null, new DefaultFormatter());

	public static final ExtractField APPLICANT_TYPEOFSTREET = new ExtractField(
			"APPLICANT_TYPEOFSTREET", null, new DefaultFormatter());

	public static final ExtractField APPLICANT_APARTMENTBOXORSUITE = new ExtractField(
			"APPLICANT_APARTMENTBOXORSUITE", null, new DefaultFormatter());

	public static final ExtractField APPLICANT_ADDRESS2 = new ExtractField(
			"APPLICANT_ADDRESS2", null, new DefaultFormatter());

	public static final ExtractField APPLICANT_CITY = new ExtractField(
			"APPLICANT_CITY", null, new DefaultFormatter());

	public static final ExtractField APPLICANT_STATE = new ExtractField(
			"APPLICANT_STATE", null, new DefaultFormatter());

	public static final ExtractField APPLICANT_ZIPCODE = new ExtractField(
			"APPLICANT_ZIPCODE", null, new ZipcodeFormatter());

	public static final ExtractField APPLICANT_PHONE = new ExtractField(
			"APPLICANT_PHONE", null, new PhoneFormatter());

	public static final ExtractField APPLICANT_PHONEEXT = new ExtractField(
			"APPLICANT_PHONEEXT", null, new DefaultFormatter());

	public static final ExtractField APPLICANT_FAX = new ExtractField(
			"APPLICANT_FAX", null, new PhoneFormatter());

	// //////////////////////////////////////////////////////////////////////////
	// Co-applicant fields.
	// //////////////////////////////////////////////////////////////////////////

	public static final ExtractField COAPPLICANT_LASTNAME = new ExtractField(
			"COAPPLICANT_LASTNAME", null, new DefaultFormatter());

	public static final ExtractField COAPPLICANT_FIRSTNAME = new ExtractField(
			"COAPPLICANT_FIRSTNAME", null, new DefaultFormatter());

	public static final ExtractField COAPPLICANT_MIDDLENAME = new ExtractField(
			"COAPPLICANT_MIDDLENAME", null, new DefaultFormatter());

	public static final ExtractField COAPPLICANT_NAMESUFFIX = new ExtractField(
			"COAPPLICANT_NAMESUFFIX", null, new DefaultFormatter());

	public static final ExtractField COAPPLICANT_SSN = new ExtractField(
			"COAPPLICANT_SSN", null, new SSNFormatter());

	public static final ExtractField COAPPLICANT_STREETNUMBER = new ExtractField(
			"COAPPLICANT_STREETNUMBER", null, new DefaultFormatter());

	public static final ExtractField COAPPLICANT_STREETNAME = new ExtractField(
			"COAPPLICANT_STREETNAME", null, new DefaultFormatter());

	public static final ExtractField COAPPLICANT_TYPEOFSTREET = new ExtractField(
			"COAPPLICANT_TYPEOFSTREET", null, new DefaultFormatter());

	public static final ExtractField COAPPLICANT_APARTMENTBOXORSUITE = new ExtractField(
			"COAPPLICANT_APARTMENTBOXORSUITE", null, new DefaultFormatter());

	public static final ExtractField COAPPLICANT_ADDRESS2 = new ExtractField(
			"COAPPLICANT_ADDRESS2", null, new DefaultFormatter());

	public static final ExtractField COAPPLICANT_CITY = new ExtractField(
			"COAPPLICANT_CITY", null, new DefaultFormatter());

	public static final ExtractField COAPPLICANT_STATE = new ExtractField(
			"COAPPLICANT_STATE", null, new DefaultFormatter());

	public static final ExtractField COAPPLICANT_ZIPCODE = new ExtractField(
			"COAPPLICANT_ZIPCODE", null, new ZipcodeFormatter());

	public static final ExtractField COAPPLICANT_PHONE = new ExtractField(
			"COAPPLICANT_PHONE", null, new PhoneFormatter());

	public static final ExtractField COAPPLICANT_PHONEEXT = new ExtractField(
			"COAPPLICANT_PHONEEXT", null, new DefaultFormatter());

	public static final ExtractField COAPPLICANT_FAX = new ExtractField(
			"COAPPLICANT_FAX", null, new PhoneFormatter());

	// //////////////////////////////////////////////////////////////////////////
	// Co-signer 1 fields.
	// //////////////////////////////////////////////////////////////////////////

	public static final ExtractField COSIGNER1_LASTNAME = new ExtractField(
			"COSIGNER1_LASTNAME", null, new DefaultFormatter());

	public static final ExtractField COSIGNER1_FIRSTNAME = new ExtractField(
			"COSIGNER1_FIRSTNAME", null, new DefaultFormatter());

	public static final ExtractField COSIGNER1_MIDDLENAME = new ExtractField(
			"COSIGNER1_MIDDLENAME", null, new DefaultFormatter());

	public static final ExtractField COSIGNER1_NAMESUFFIX = new ExtractField(
			"COSIGNER1_NAMESUFFIX", null, new DefaultFormatter());

	public static final ExtractField COSIGNER1_SSN = new ExtractField(
			"COSIGNER1_SSN", null, new SSNFormatter());

	public static final ExtractField COSIGNER1_STREETNUMBER = new ExtractField(
			"COSIGNER1_STREETNUMBER", null, new DefaultFormatter());

	public static final ExtractField COSIGNER1_STREETNAME = new ExtractField(
			"COSIGNER1_STREETNAME", null, new DefaultFormatter());

	public static final ExtractField COSIGNER1_TYPEOFSTREET = new ExtractField(
			"COSIGNER1_TYPEOFSTREET", null, new DefaultFormatter());

	public static final ExtractField COSIGNER1_APARTMENTBOXORSUITE = new ExtractField(
			"COSIGNER1_APARTMENTBOXORSUITE", null, new DefaultFormatter());

	public static final ExtractField COSIGNER1_ADDRESS2 = new ExtractField(
			"COSIGNER1_ADDRESS2", null, new DefaultFormatter());

	public static final ExtractField COSIGNER1_CITY = new ExtractField(
			"COSIGNER1_CITY", null, new DefaultFormatter());

	public static final ExtractField COSIGNER1_STATE = new ExtractField(
			"COSIGNER1_STATE", null, new DefaultFormatter());

	public static final ExtractField COSIGNER1_ZIPCODE = new ExtractField(
			"COSIGNER1_ZIPCODE", null, new ZipcodeFormatter());

	public static final ExtractField COSIGNER1_PHONE = new ExtractField(
			"COSIGNER1_PHONE", null, new PhoneFormatter());

	public static final ExtractField COSIGNER1_PHONEEXT = new ExtractField(
			"COSIGNER1_PHONEEXT", null, new DefaultFormatter());

	public static final ExtractField COSIGNER1_FAX = new ExtractField(
			"COSIGNER1_FAX", null, new PhoneFormatter());

	// //////////////////////////////////////////////////////////////////////////
	// Co-signer 2 fields.
	// //////////////////////////////////////////////////////////////////////////

	public static final ExtractField COSIGNER2_LASTNAME = new ExtractField(
			"COSIGNER2_LASTNAME", null, new DefaultFormatter());

	public static final ExtractField COSIGNER2_FIRSTNAME = new ExtractField(
			"COSIGNER2_FIRSTNAME", null, new DefaultFormatter());

	public static final ExtractField COSIGNER2_MIDDLENAME = new ExtractField(
			"COSIGNER2_MIDDLENAME", null, new DefaultFormatter());

	public static final ExtractField COSIGNER2_NAMESUFFIX = new ExtractField(
			"COSIGNER2_NAMESUFFIX", null, new DefaultFormatter());

	public static final ExtractField COSIGNER2_SSN = new ExtractField(
			"COSIGNER2_SSN", null, new SSNFormatter());

	public static final ExtractField COSIGNER2_STREETNUMBER = new ExtractField(
			"COSIGNER2_STREETNUMBER", null, new DefaultFormatter());

	public static final ExtractField COSIGNER2_STREETNAME = new ExtractField(
			"COSIGNER2_STREETNAME", null, new DefaultFormatter());

	public static final ExtractField COSIGNER2_TYPEOFSTREET = new ExtractField(
			"COSIGNER2_TYPEOFSTREET", null, new DefaultFormatter());

	public static final ExtractField COSIGNER2_APARTMENTBOXORSUITE = new ExtractField(
			"COSIGNER2_APARTMENTBOXORSUITE", null, new DefaultFormatter());

	public static final ExtractField COSIGNER2_ADDRESS2 = new ExtractField(
			"COSIGNER2_ADDRESS2", null, new DefaultFormatter());

	public static final ExtractField COSIGNER2_CITY = new ExtractField(
			"COSIGNER2_CITY", null, new DefaultFormatter());

	public static final ExtractField COSIGNER2_STATE = new ExtractField(
			"COSIGNER2_STATE", null, new DefaultFormatter());

	public static final ExtractField COSIGNER2_ZIPCODE = new ExtractField(
			"COSIGNER2_ZIPCODE", null, new ZipcodeFormatter());

	public static final ExtractField COSIGNER2_PHONE = new ExtractField(
			"COSIGNER2_PHONE", null, new PhoneFormatter());

	public static final ExtractField COSIGNER2_PHONEEXT = new ExtractField(
			"COSIGNER2_PHONEEXT", null, new DefaultFormatter());

	public static final ExtractField COSIGNER2_FAX = new ExtractField(
			"COSIGNER2_FAX", null, new PhoneFormatter());

	// //////////////////////////////////////////////////////////////////////////
	// Co-signer 3 fields.
	// //////////////////////////////////////////////////////////////////////////

	public static final ExtractField COSIGNER3_LASTNAME = new ExtractField(
			"COSIGNER3_LASTNAME", null, new DefaultFormatter());

	public static final ExtractField COSIGNER3_FIRSTNAME = new ExtractField(
			"COSIGNER3_FIRSTNAME", null, new DefaultFormatter());

	public static final ExtractField COSIGNER3_MIDDLENAME = new ExtractField(
			"COSIGNER3_MIDDLENAME", null, new DefaultFormatter());

	public static final ExtractField COSIGNER3_NAMESUFFIX = new ExtractField(
			"COSIGNER3_NAMESUFFIX", null, new DefaultFormatter());

	public static final ExtractField COSIGNER3_SSN = new ExtractField(
			"COSIGNER3_SSN", null, new SSNFormatter());

	public static final ExtractField COSIGNER3_STREETNUMBER = new ExtractField(
			"COSIGNER3_STREETNUMBER", null, new DefaultFormatter());

	public static final ExtractField COSIGNER3_STREETNAME = new ExtractField(
			"COSIGNER3_STREETNAME", null, new DefaultFormatter());

	public static final ExtractField COSIGNER3_TYPEOFSTREET = new ExtractField(
			"COSIGNER3_TYPEOFSTREET", null, new DefaultFormatter());

	public static final ExtractField COSIGNER3_APARTMENTBOXORSUITE = new ExtractField(
			"COSIGNER3_APARTMENTBOXORSUITE", null, new DefaultFormatter());

	public static final ExtractField COSIGNER3_ADDRESS2 = new ExtractField(
			"COSIGNER3_ADDRESS2", null, new DefaultFormatter());

	public static final ExtractField COSIGNER3_CITY = new ExtractField(
			"COSIGNER3_CITY", null, new DefaultFormatter());

	public static final ExtractField COSIGNER3_STATE = new ExtractField(
			"COSIGNER3_STATE", null, new DefaultFormatter());

	public static final ExtractField COSIGNER3_ZIPCODE = new ExtractField(
			"COSIGNER3_ZIPCODE", null, new ZipcodeFormatter());

	public static final ExtractField COSIGNER3_PHONE = new ExtractField(
			"COSIGNER3_PHONE", null, new PhoneFormatter());

	public static final ExtractField COSIGNER3_PHONEEXT = new ExtractField(
			"COSIGNER3_PHONEEXT", null, new DefaultFormatter());

	public static final ExtractField COSIGNER3_FAX = new ExtractField(
			"COSIGNER3_FAX", null, new PhoneFormatter());

	// //////////////////////////////////////////////////////////////////////////
	// Co-signer 4 fields.
	// //////////////////////////////////////////////////////////////////////////

	public static final ExtractField COSIGNER4_LASTNAME = new ExtractField(
			"COSIGNER4_LASTNAME", null, new DefaultFormatter());

	public static final ExtractField COSIGNER4_FIRSTNAME = new ExtractField(
			"COSIGNER4_FIRSTNAME", null, new DefaultFormatter());

	public static final ExtractField COSIGNER4_MIDDLENAME = new ExtractField(
			"COSIGNER4_MIDDLENAME", null, new DefaultFormatter());

	public static final ExtractField COSIGNER4_NAMESUFFIX = new ExtractField(
			"COSIGNER4_NAMESUFFIX", null, new DefaultFormatter());

	public static final ExtractField COSIGNER4_SSN = new ExtractField(
			"COSIGNER4_SSN", null, new SSNFormatter());

	public static final ExtractField COSIGNER4_STREETNUMBER = new ExtractField(
			"COSIGNER4_STREETNUMBER", null, new DefaultFormatter());

	public static final ExtractField COSIGNER4_STREETNAME = new ExtractField(
			"COSIGNER4_STREETNAME", null, new DefaultFormatter());

	public static final ExtractField COSIGNER4_TYPEOFSTREET = new ExtractField(
			"COSIGNER4_TYPEOFSTREET", null, new DefaultFormatter());

	public static final ExtractField COSIGNER4_APARTMENTBOXORSUITE = new ExtractField(
			"COSIGNER4_APARTMENTBOXORSUITE", null, new DefaultFormatter());

	public static final ExtractField COSIGNER4_ADDRESS2 = new ExtractField(
			"COSIGNER4_ADDRESS2", null, new DefaultFormatter());

	public static final ExtractField COSIGNER4_CITY = new ExtractField(
			"COSIGNER4_CITY", null, new DefaultFormatter());

	public static final ExtractField COSIGNER4_STATE = new ExtractField(
			"COSIGNER4_STATE", null, new DefaultFormatter());

	public static final ExtractField COSIGNER4_ZIPCODE = new ExtractField(
			"COSIGNER4_ZIPCODE", null, new ZipcodeFormatter());

	public static final ExtractField COSIGNER4_PHONE = new ExtractField(
			"COSIGNER4_PHONE", null, new PhoneFormatter());

	public static final ExtractField COSIGNER4_PHONEEXT = new ExtractField(
			"COSIGNER4_PHONEEXT", null, new DefaultFormatter());

	public static final ExtractField COSIGNER4_FAX = new ExtractField(
			"COSIGNER4_FAX", null, new PhoneFormatter());

	// //////////////////////////////////////////////////////////////////////////
	// Applicant (requestor) business fields.
	// //////////////////////////////////////////////////////////////////////////

	public static final ExtractField APPLICANT_BUSINESS_BUSINESSNAME = new ExtractField(
			"APPLICANT_BUSINESS_BUSINESSNAME", null, new DefaultFormatter());

	public static final ExtractField APPLICANT_BUSINESS_PHONE = new ExtractField(
			"APPLICANT_BUSINESS_PHONE", null, new PhoneFormatter());

	public static final ExtractField APPLICANT_BUSINESS_PHONEEXT = new ExtractField(
			"APPLICANT_BUSINESS_PHONEEXT", null, new DefaultFormatter());

	public static final ExtractField APPLICANT_BUSINESS_ADDRESS1 = new ExtractField(
			"APPLICANT_BUSINESS_ADDRESS1", null, new DefaultFormatter());

	public static final ExtractField APPLICANT_BUSINESS_ADDRESS2 = new ExtractField(
			"APPLICANT_BUSINESS_ADDRESS2", null, new DefaultFormatter());

	public static final ExtractField APPLICANT_BUSINESS_CITY = new ExtractField(
			"APPLICANT_BUSINESS_CITY", null, new DefaultFormatter());

	public static final ExtractField APPLICANT_BUSINESS_STATE = new ExtractField(
			"APPLICANT_BUSINESS_STATE", null, new DefaultFormatter());

	public static final ExtractField APPLICANT_BUSINESS_ZIPCODE = new ExtractField(
			"APPLICANT_BUSINESS_ZIPCODE", null, new ZipcodeFormatter());

	public static final ExtractField APPLICANT_BUSINESS_OFFICERNAME = new ExtractField(
			"APPLICANT_BUSINESS_OFFICERNAME", null, new DefaultFormatter());

	public static final ExtractField APPLICANT_BUSINESS_OFFICERTITLE = new ExtractField(
			"APPLICANT_BUSINESS_OFFICERTITLE", null, new DefaultFormatter());

	// //////////////////////////////////////////////////////////////////////////
	// Auto collateral fields.
	// //////////////////////////////////////////////////////////////////////////

	public static final ExtractField AUTO_YEAR = new ExtractField("AUTO_YEAR",
			null, new DefaultFormatter());

	public static final ExtractField AUTO_MAKE = new ExtractField("AUTO_MAKE",
			null, new DefaultFormatter());

	public static final ExtractField AUTO_MODEL = new ExtractField(
			"AUTO_MODEL", null, new DefaultFormatter());

	public static final ExtractField AUTO_VIN = new ExtractField("AUTO_VIN",
			null, new DefaultFormatter());

	public static final ExtractField AUTO_COLOR = new ExtractField(
			"AUTO_COLOR", null, new DefaultFormatter());

	public static final ExtractField AUTO_NEWUSEDFLAG = new ExtractField(
			"AUTO_NEWUSEDFLAG", null, new DefaultFormatter());

	public static final ExtractField AUTO_MILEAGE = new ExtractField(
			"AUTO_MILEAGE", null, new DefaultFormatter());

	// //////////////////////////////////////////////////////////////////////////
	// Secured / un-secured fields.
	// //////////////////////////////////////////////////////////////////////////

	public static final ExtractField SECURED_FLAG = new ExtractField(
			"SECURED_FLAG", null, new DefaultFormatter());

	// //////////////////////////////////////////////////////////////////////////
	// Deal structure fields.
	// //////////////////////////////////////////////////////////////////////////

	public static final ExtractField DEALSTRUCT_REQUESTEDAMOUNT = new ExtractField(
			"DEALSTRUCT_REQUESTEDAMOUNT", null, new AmountAsNumbersFormatter());

	public static final ExtractField DEALSTRUCT_REQUESTEDAMOUNT2 = new ExtractField(
			"DEALSTRUCT_REQUESTEDAMOUNT2", null, new AmountAsWordsFormatter());

	public static final ExtractField DEALSTRUCT_REQUESTEDTERM = new ExtractField(
			"DEALSTRUCT_REQUESTEDTERM", null, new DefaultFormatter());

	public static final ExtractField DEALSTRUCT_REQUESTEDRATE = new ExtractField(
			"DEALSTRUCT_REQUESTEDRATE", null, new DefaultFormatter());

	public static final ExtractField DEALSTRUCT_REQUESTEDPAYMENT = new ExtractField(
			"DEALSTRUCT_REQUESTEDPAYMENT", null, new AmountAsNumbersFormatter());

	public static final ExtractField DEALSTRUCT_REQUESTEDPAYMENT2 = new ExtractField(
			"DEALSTRUCT_REQUESTEDPAYMENT2", null, new AmountAsWordsFormatter());

	public static final ExtractField DEALSTRUCT_APPROVEDAMOUNT = new ExtractField(
			"DEALSTRUCT_APPROVEDAMOUNT", null, new AmountAsNumbersFormatter());

	public static final ExtractField DEALSTRUCT_APPROVEDAMOUNT2 = new ExtractField(
			"DEALSTRUCT_APPROVEDAMOUNT2", null, new AmountAsWordsFormatter());

	public static final ExtractField DEALSTRUCT_APPROVEDTERM = new ExtractField(
			"DEALSTRUCT_APPROVEDTERM", null, new DefaultFormatter());

	public static final ExtractField DEALSTRUCT_APPROVEDRATE = new ExtractField(
			"DEALSTRUCT_APPROVEDRATE", null, new DefaultFormatter());

	public static final ExtractField DEALSTRUCT_APPROVEDPAYMENT = new ExtractField(
			"DEALSTRUCT_APPROVEDPAYMENT", null, new AmountAsNumbersFormatter());

	public static final ExtractField DEALSTRUCT_APPROVEDPAYMENT2 = new ExtractField(
			"DEALSTRUCT_APPROVEDPAYMENT2", null, new AmountAsWordsFormatter());

	public static final ExtractField DEALSTRUCT_APPROVEDBUYRATE = new ExtractField(
			"DEALSTRUCT_APPROVEDBUYRATE", null, new DefaultFormatter());

	public static final ExtractField DEALSTRUCT_CASHDOWN = new ExtractField(
			"DEALSTRUCT_CASHDOWN", null, new AmountAsNumbersFormatter());

	public static final ExtractField DEALSTRUCT_CASHDOWN2 = new ExtractField(
			"DEALSTRUCT_CASHDOWN2", null, new AmountAsWordsFormatter());

	public static final ExtractField DEALSTRUCT_DECISIONDATE = new ExtractField(
			"DEALSTRUCT_DECISIONDATE", null, new DateFormatter());

	public static final ExtractField DEALSTRUCT_DECISIONDESC = new ExtractField(
			"DEALSTRUCT_DECISIONDESC", null, new DefaultFormatter());

	public static final ExtractField DEALSTRUCT_DECISIONUSER = new ExtractField(
			"DEALSTRUCT_DECISIONUSER", null, new DefaultFormatter());

	public static final ExtractField DEALSTRUCT_DECISIONPHONE = new ExtractField(
			"DEALSTRUCT_DECISIONPHONE", null, new PhoneFormatter());

	// //////////////////////////////////////////////////////////////////////////
	// Turndown reason fields.
	// //////////////////////////////////////////////////////////////////////////

	public static final ExtractField TURNDOWN_REASON1 = new ExtractField(
			"TURNDOWN_REASON1", null, new DefaultFormatter());
	
	public static final ExtractField TURNDOWN_REASON1_ENTITY = new ExtractField(
			"TURNDOWN_REASON1_ENTITY", null, new DefaultFormatter());

	public static final ExtractField TURNDOWN_REASON2 = new ExtractField(
			"TURNDOWN_REASON2", null, new DefaultFormatter());
			
	public static final ExtractField TURNDOWN_REASON2_ENTITY = new ExtractField(
			"TURNDOWN_REASON2_ENTITY", null, new DefaultFormatter());

	public static final ExtractField TURNDOWN_REASON3 = new ExtractField(
			"TURNDOWN_REASON3", null, new DefaultFormatter());
			
	public static final ExtractField TURNDOWN_REASON3_ENTITY = new ExtractField(
			"TURNDOWN_REASON3_ENTITY", null, new DefaultFormatter());		

	public static final ExtractField TURNDOWN_REASON4 = new ExtractField(
			"TURNDOWN_REASON4", null, new DefaultFormatter());
			
	public static final ExtractField TURNDOWN_REASON4_ENTITY = new ExtractField(
			"TURNDOWN_REASON4_ENTITY", null, new DefaultFormatter());

	public static final ExtractField TURNDOWN_REASON5 = new ExtractField(
			"TURNDOWN_REASON5", null, new DefaultFormatter());
			
	public static final ExtractField TURNDOWN_REASON5_ENTITY = new ExtractField(
			"TURNDOWN_REASON5_ENTITY", null, new DefaultFormatter());

	public static final ExtractField TURNDOWN_REASON6 = new ExtractField(
			"TURNDOWN_REASON6", null, new DefaultFormatter());
			
	public static final ExtractField TURNDOWN_REASON6_ENTITY = new ExtractField(
			"TURNDOWN_REASON6_ENTITY", null, new DefaultFormatter());

	public static final ExtractField TURNDOWN_REASON7 = new ExtractField(
			"TURNDOWN_REASON7", null, new DefaultFormatter());
			
	public static final ExtractField TURNDOWN_REASON7_ENTITY = new ExtractField(
			"TURNDOWN_REASON7_ENTITY", null, new DefaultFormatter());

	public static final ExtractField TURNDOWN_REASON8 = new ExtractField(
			"TURNDOWN_REASON8", null, new DefaultFormatter());
			
	public static final ExtractField TURNDOWN_REASON8_ENTITY = new ExtractField(
			"TURNDOWN_REASON8_ENTITY", null, new DefaultFormatter());

	public static final ExtractField TURNDOWN_REASON9 = new ExtractField(
			"TURNDOWN_REASON9", null, new DefaultFormatter());
			
	public static final ExtractField TURNDOWN_REASON9_ENTITY = new ExtractField(
			"TURNDOWN_REASON9_ENTITY", null, new DefaultFormatter());

	public static final ExtractField TURNDOWN_REASON10 = new ExtractField(
			"TURNDOWN_REASON10", null, new DefaultFormatter());
			
	public static final ExtractField TURNDOWN_REASON10_ENTITY = new ExtractField(
			"TURNDOWN_REASON10_ENTITY", null, new DefaultFormatter());

	public static final ExtractField AT_LEAST_ONE_BUREAU_RELATED_REASON_FLAG = new ExtractField(
			"AT_LEAST_ONE_BUREAU_RELATED_REASON_FLAG", null,
			new DefaultFormatter());

	// //////////////////////////////////////////////////////////////////////////
	// Bureau fields.
	// //////////////////////////////////////////////////////////////////////////

	public static final ExtractField DECLINED_DUE_TO_BUREAU_FLAG = new ExtractField(
			"DECLINED_DUE_TO_BUREAU_FLAG", null, new DefaultFormatter());

	public static final ExtractField BUREAU_CONSUMERREFCODE = new ExtractField(
			"BUREAU_CONSUMERREFCODE", null, new DefaultFormatter());

	public static final ExtractField BUREAU_NAME = new ExtractField(
			"BUREAU_NAME", null, new DefaultFormatter());

	public static final ExtractField BUREAU_ADDRESS1 = new ExtractField(
			"BUREAU_ADDRESS1", null, new DefaultFormatter());

	public static final ExtractField BUREAU_ADDRESS2 = new ExtractField(
			"BUREAU_ADDRESS2", null, new DefaultFormatter());

	public static final ExtractField BUREAU_CITY = new ExtractField(
			"BUREAU_CITY", null, new DefaultFormatter());

	public static final ExtractField BUREAU_STATE = new ExtractField(
			"BUREAU_STATE", null, new DefaultFormatter());

	public static final ExtractField BUREAU_ZIPCODE = new ExtractField(
			"BUREAU_ZIPCODE", null, new ZipcodeFormatter());

	public static final ExtractField BUREAU_PHONE = new ExtractField(
			"BUREAU_PHONE", null, new PhoneFormatter());

	public static final ExtractField BUREAU_URL = new ExtractField(
			"BUREAU_URL", null, new DefaultFormatter());
	
	
	public static final ExtractField BUREAU_CONSUMERREFCODE_1 = new ExtractField(
			"BUREAU_CONSUMERREFCODE_1", null, new DefaultFormatter());

	public static final ExtractField BUREAU_NAME_1 = new ExtractField(
			"BUREAU_NAME_1", null, new DefaultFormatter());

	public static final ExtractField BUREAU_ADDRESS1_1 = new ExtractField(
			"BUREAU_ADDRESS1_1", null, new DefaultFormatter());

	public static final ExtractField BUREAU_ADDRESS2_1 = new ExtractField(
			"BUREAU_ADDRESS2_1", null, new DefaultFormatter());

	public static final ExtractField BUREAU_CITY_1 = new ExtractField(
			"BUREAU_CITY_1", null, new DefaultFormatter());

	public static final ExtractField BUREAU_STATE_1 = new ExtractField(
			"BUREAU_STATE_1", null, new DefaultFormatter());

	public static final ExtractField BUREAU_ZIPCODE_1 = new ExtractField(
			"BUREAU_ZIPCODE_1", null, new ZipcodeFormatter());

	public static final ExtractField BUREAU_PHONE_1 = new ExtractField(
			"BUREAU_PHONE_1", null, new PhoneFormatter());

	public static final ExtractField BUREAU_URL_1 = new ExtractField(
			"BUREAU_URL_1", null, new DefaultFormatter());
	
	
	
	public static final ExtractField BUREAU_CONSUMERREFCODE_2 = new ExtractField(
			"BUREAU_CONSUMERREFCODE_2", null, new DefaultFormatter());

	public static final ExtractField BUREAU_NAME_2 = new ExtractField(
			"BUREAU_NAME_2", null, new DefaultFormatter());

	public static final ExtractField BUREAU_ADDRESS1_2 = new ExtractField(
			"BUREAU_ADDRESS1_2", null, new DefaultFormatter());

	public static final ExtractField BUREAU_ADDRESS2_2 = new ExtractField(
			"BUREAU_ADDRESS2_2", null, new DefaultFormatter());

	public static final ExtractField BUREAU_CITY_2 = new ExtractField(
			"BUREAU_CITY_2", null, new DefaultFormatter());

	public static final ExtractField BUREAU_STATE_2 = new ExtractField(
			"BUREAU_STATE_2", null, new DefaultFormatter());

	public static final ExtractField BUREAU_ZIPCODE_2 = new ExtractField(
			"BUREAU_ZIPCODE_2", null, new ZipcodeFormatter());

	public static final ExtractField BUREAU_PHONE_2 = new ExtractField(
			"BUREAU_PHONE_2", null, new PhoneFormatter());
	
	public static final ExtractField BUREAU_URL_2 = new ExtractField(
			"BUREAU_URL_2", null, new DefaultFormatter());
	
	
	public static final ExtractField BUREAU_CONSUMERREFCODE_3 = new ExtractField(
			"BUREAU_CONSUMERREFCODE_3", null, new DefaultFormatter());

	public static final ExtractField BUREAU_NAME_3 = new ExtractField(
			"BUREAU_NAME_3", null, new DefaultFormatter());

	public static final ExtractField BUREAU_ADDRESS1_3 = new ExtractField(
			"BUREAU_ADDRESS1_3", null, new DefaultFormatter());

	public static final ExtractField BUREAU_ADDRESS2_3 = new ExtractField(
			"BUREAU_ADDRESS2_3", null, new DefaultFormatter());

	public static final ExtractField BUREAU_CITY_3 = new ExtractField(
			"BUREAU_CITY_3", null, new DefaultFormatter());

	public static final ExtractField BUREAU_STATE_3 = new ExtractField(
			"BUREAU_STATE_3", null, new DefaultFormatter());

	public static final ExtractField BUREAU_ZIPCODE_3 = new ExtractField(
			"BUREAU_ZIPCODE_3", null, new ZipcodeFormatter());

	public static final ExtractField BUREAU_PHONE_3 = new ExtractField(
			"BUREAU_PHONE_3", null, new PhoneFormatter());

	public static final ExtractField BUREAU_URL_3 = new ExtractField(
			"BUREAU_URL_3", null, new DefaultFormatter());

	// //////////////////////////////////////////////////////////////////////////
	// Center fields.
	// //////////////////////////////////////////////////////////////////////////

	public static final ExtractField CENTER_NAME = new ExtractField(
			"CENTER_NAME", null, new DefaultFormatter());

	public static final ExtractField CENTER_STREETNUMBER = new ExtractField(
			"CENTER_STREETNUMBER", null, new DefaultFormatter());

	public static final ExtractField CENTER_STREETNAME = new ExtractField(
			"CENTER_STREETNAME", null, new DefaultFormatter());

	public static final ExtractField CENTER_TYPEOFSTREET = new ExtractField(
			"CENTER_TYPEOFSTREET", null, new DefaultFormatter());

	public static final ExtractField CENTER_CITY = new ExtractField(
			"CENTER_CITY", null, new DefaultFormatter());

	public static final ExtractField CENTER_STATE = new ExtractField(
			"CENTER_STATE", null, new DefaultFormatter());

	public static final ExtractField CENTER_ZIPCODE = new ExtractField(
			"CENTER_ZIPCODE", null, new ZipcodeFormatter());

	public static final ExtractField CENTER_PHONE = new ExtractField(
			"CENTER_PHONE", null, new PhoneFormatter());

	public static final ExtractField CENTER_FAX = new ExtractField(
			"CENTER_FAX", null, new PhoneFormatter());

	// //////////////////////////////////////////////////////////////////////////
	// Branch (originator) fields, originator is either branch or dealer.
	// //////////////////////////////////////////////////////////////////////////

	public static final ExtractField BRANCH_NAME = new ExtractField(
			"BRANCH_NAME", null, new DefaultFormatter());

	public static final ExtractField BRANCH_ADDRESS1 = new ExtractField(
			"BRANCH_ADDRESS1", null, new DefaultFormatter());

	public static final ExtractField BRANCH_ADDRESS2 = new ExtractField(
			"BRANCH_ADDRESS2", null, new DefaultFormatter());

	public static final ExtractField BRANCH_CITY = new ExtractField(
			"BRANCH_CITY", null, new DefaultFormatter());

	public static final ExtractField BRANCH_STATE = new ExtractField(
			"BRANCH_STATE", null, new DefaultFormatter());

	public static final ExtractField BRANCH_ZIPCODE = new ExtractField(
			"BRANCH_ZIPCODE", null, new ZipcodeFormatter());

	public static final ExtractField BRANCH_PHONE = new ExtractField(
			"BRANCH_PHONE", null, new PhoneFormatter());

	public static final ExtractField BRANCH_PHONEEXT = new ExtractField(
			"BRANCH_PHONEEXT", null, new DefaultFormatter());

	public static final ExtractField BRANCH_FAX = new ExtractField(
			"BRANCH_FAX", null, new PhoneFormatter());

	public static final ExtractField BRANCH_CONTACT = new ExtractField(
			"BRANCH_CONTACT", null, new DefaultFormatter());

	// //////////////////////////////////////////////////////////////////////////
	// Dealer (originator) fields, originator is either branch or dealer.
	// //////////////////////////////////////////////////////////////////////////

	public static final ExtractField DEALER_NAME = new ExtractField(
			"DEALER_NAME", null, new DefaultFormatter());

	public static final ExtractField DEALER_ADDRESS1 = new ExtractField(
			"DEALER_ADDRESS1", null, new DefaultFormatter());

	public static final ExtractField DEALER_ADDRESS2 = new ExtractField(
			"DEALER_ADDRESS2", null, new DefaultFormatter());

	public static final ExtractField DEALER_CITY = new ExtractField(
			"DEALER_CITY", null, new DefaultFormatter());

	public static final ExtractField DEALER_STATE = new ExtractField(
			"DEALER_STATE", null, new DefaultFormatter());

	public static final ExtractField DEALER_ZIPCODE = new ExtractField(
			"DEALER_ZIPCODE", null, new ZipcodeFormatter());

	public static final ExtractField DEALER_PHONE = new ExtractField(
			"DEALER_PHONE", null, new PhoneFormatter());

	public static final ExtractField DEALER_PHONEEXT = new ExtractField(
			"DEALER_PHONEEXT", null, new DefaultFormatter());

	public static final ExtractField DEALER_FAX = new ExtractField(
			"DEALER_FAX", null, new PhoneFormatter());

	public static final ExtractField DEALER_CONTACT = new ExtractField(
			"DEALER_CONTACT", null, new DefaultFormatter());

	// //////////////////////////////////////////////////////////////////////////
	// Load purpose, comments and stipulation fields.
	// //////////////////////////////////////////////////////////////////////////

	public static final ExtractField LOAN_PURPOSE_CODE = new ExtractField(
			"LOAN_PURPOSE_CODE", null, new DefaultFormatter());

	public static final ExtractField COMMENTS = new ExtractField("COMMENTS",
			null, new DefaultFormatter());

	public static final ExtractField STIPULATION_TEXT1 = new ExtractField(
			"STIPULATION_TEXT1", null, new DefaultFormatter());

	public static final ExtractField STIPULATION_DESC1 = new ExtractField(
			"STIPULATION_DESC1", null, new DefaultFormatter());

	public static final ExtractField STIPULATION_TEXT2 = new ExtractField(
			"STIPULATION_TEXT2", null, new DefaultFormatter());

	public static final ExtractField STIPULATION_DESC2 = new ExtractField(
			"STIPULATION_DESC2", null, new DefaultFormatter());

	public static final ExtractField STIPULATION_TEXT3 = new ExtractField(
			"STIPULATION_TEXT3", null, new DefaultFormatter());

	public static final ExtractField STIPULATION_DESC3 = new ExtractField(
			"STIPULATION_DESC3", null, new DefaultFormatter());

	// //////////////////////////////////////////////////////////////////////////
	// BureauScore  and BureauRBP fields.
	// //////////////////////////////////////////////////////////////////////////
	
	// Applicant

	public static final ExtractField APPLICANT_CREDIT_SCORE = new ExtractField(
		"APPLICANT_CREDIT_SCORE", null, new DefaultFormatter());

	public static final ExtractField APPLICANT_MIN_SCORE= new ExtractField(
		"APPLICANT_MIN_SCORE", null, new DefaultFormatter());
	
	public static final ExtractField APPLICANT_MAX_SCORE = new ExtractField(
		"APPLICANT_MAX_SCORE", null, new DefaultFormatter());

	public static final ExtractField APPLICANT_SCORE_CALCULATED_DATE= new ExtractField(
		"APPLICANT_SCORE_CALCULATED_DATE", null, new DateFormatter());
	
	public static final ExtractField APPLICANT_SCORE_REASON_CODE_1 = new ExtractField(
		"APPLICANT_SCORE_REASON_CODE_1", null, new DefaultFormatter());

	public static final ExtractField APPLICANT_SCORE_REASON_DESC_1 = new ExtractField(
		"APPLICANT_SCORE_REASON_DESC_1", null, new DefaultFormatter());

	public static final ExtractField APPLICANT_SCORE_REASON_CODE_2 = new ExtractField(
		"APPLICANT_SCORE_REASON_CODE_2", null, new DefaultFormatter());
	
	public static final ExtractField APPLICANT_SCORE_REASON_DESC_2 = new ExtractField(
		"APPLICANT_SCORE_REASON_DESC_2", null, new DefaultFormatter());

	public static final ExtractField APPLICANT_SCORE_REASON_CODE_3 = new ExtractField(
		"APPLICANT_SCORE_REASON_CODE_3", null, new DefaultFormatter());
	
	public static final ExtractField APPLICANT_SCORE_REASON_DESC_3 = new ExtractField(
		"APPLICANT_SCORE_REASON_DESC_3", null, new DefaultFormatter());

	public static final ExtractField APPLICANT_SCORE_REASON_CODE_4 = new ExtractField(
		"APPLICANT_SCORE_REASON_CODE_4", null, new DefaultFormatter());

	public static final ExtractField APPLICANT_SCORE_REASON_DESC_4 = new ExtractField(
		"APPLICANT_SCORE_REASON_DESC_4", null, new DefaultFormatter());

	public static final ExtractField APPLICANT_SCORE_REASON_5 = new ExtractField(
		"APPLICANT_SCORE_REASON_5", null, new DefaultFormatter());

	public static final ExtractField APPLICANT_SCORE_INQUIRIES = new ExtractField(
		"APPLICANT_SCORE_INQUIRIES", null, new DefaultFormatter());

		
	//Co-Applicant
	public static final ExtractField COAPPLICANT_CREDIT_SCORE = new ExtractField(
		"COAPPLICANT_CREDIT_SCORE", null, new DefaultFormatter());

	public static final ExtractField COAPPLICANT_MIN_SCORE = new ExtractField(
		"COAPPLICANT_MIN_SCORE", null, new DefaultFormatter());
	
	public static final ExtractField COAPPLICANT_MAX_SCORE = new ExtractField(
		"COAPPLICANT_MAX_SCORE", null, new DefaultFormatter());
	
	public static final ExtractField COAPPLICANT_SCORE_CALCULATED_DATE= new ExtractField(
		"COAPPLICANT_SCORE_CALCULATED_DATE", null, new DateFormatter());

	public static final ExtractField COAPPLICANT_SCORE_REASON_CODE_1 = new ExtractField(
		"COAPPLICANT_SCORE_REASON_CODE_1", null, new DefaultFormatter());

	public static final ExtractField COAPPLICANT_SCORE_REASON_DESC_1 = new ExtractField(
		"COAPPLICANT_SCORE_REASON_DESC_1", null, new DefaultFormatter());

	public static final ExtractField COAPPLICANT_SCORE_REASON_CODE_2 = new ExtractField(
		"COAPPLICANT_SCORE_REASON_CODE_2", null, new DefaultFormatter());

	public static final ExtractField COAPPLICANT_SCORE_REASON_DESC_2 = new ExtractField(
		"COAPPLICANT_SCORE_REASON_DESC_2", null, new DefaultFormatter());

	public static final ExtractField COAPPLICANT_SCORE_REASON_CODE_3 = new ExtractField(
		"COAPPLICANT_SCORE_REASON_CODE_3", null, new DefaultFormatter());

	public static final ExtractField COAPPLICANT_SCORE_REASON_DESC_3 = new ExtractField(
		"COAPPLICANT_SCORE_REASON_DESC_3", null, new DefaultFormatter());

	public static final ExtractField COAPPLICANT_SCORE_REASON_CODE_4 = new ExtractField(
		"COAPPLICANT_SCORE_REASON_CODE_4", null, new DefaultFormatter());

	public static final ExtractField COAPPLICANT_SCORE_REASON_DESC_4 = new ExtractField(
		"COAPPLICANT_SCORE_REASON_DESC_4", null, new DefaultFormatter());

	public static final ExtractField COAPPLICANT_SCORE_REASON_5 = new ExtractField(
		"COAPPLICANT_SCORE_REASON_5", null, new DefaultFormatter());

	public static final ExtractField COAPPLICANT_SCORE_INQUIRIES = new ExtractField(
		"COAPPLICANT_SCORE_INQUIRIES", null, new DefaultFormatter());
	
	// Co-Applciant2	
	public static final ExtractField COAPPLICANT2_CREDIT_SCORE = new ExtractField(
		"COAPPLICANT2_CREDIT_SCORE", null, new DefaultFormatter());

	public static final ExtractField COAPPLICANT2_MIN_SCORE = new ExtractField(
		"COAPPLICANT2_MIN_SCORE", null, new DefaultFormatter());
	
	public static final ExtractField COAPPLICANT2_MAX_SCORE = new ExtractField(
		"COAPPLICANT2_MAX_SCORE", null, new DefaultFormatter());
	
	public static final ExtractField COAPPLICANT2_SCORE_CALCULATED_DATE= new ExtractField(
		"COAPPLICANT2_SCORE_CALCULATED_DATE", null, new DateFormatter());

	public static final ExtractField COAPPLICANT2_SCORE_REASON_CODE_1 = new ExtractField(
		"COAPPLICANT2_SCORE_REASON_CODE_1", null, new DefaultFormatter());

	public static final ExtractField COAPPLICANT2_SCORE_REASON_DESC_1 = new ExtractField(
		"COAPPLICANT2_SCORE_REASON_DESC_1", null, new DefaultFormatter());

	public static final ExtractField COAPPLICANT2_SCORE_REASON_CODE_2 = new ExtractField(
		"COAPPLICANT2_SCORE_REASON_CODE_2", null, new DefaultFormatter());

	public static final ExtractField COAPPLICANT2_SCORE_REASON_DESC_2 = new ExtractField(
		"COAPPLICANT2_SCORE_REASON_DESC_2", null, new DefaultFormatter());

	public static final ExtractField COAPPLICANT2_SCORE_REASON_CODE_3 = new ExtractField(
		"COAPPLICANT2_SCORE_REASON_CODE_3", null, new DefaultFormatter());

	public static final ExtractField COAPPLICANT2_SCORE_REASON_DESC_3 = new ExtractField(
		"COAPPLICANT2_SCORE_REASON_DESC_3", null, new DefaultFormatter());

	public static final ExtractField COAPPLICANT2_SCORE_REASON_CODE_4 = new ExtractField(
		"COAPPLICANT2_SCORE_REASON_CODE_4", null, new DefaultFormatter());

	public static final ExtractField COAPPLICANT2_SCORE_REASON_DESC_4 = new ExtractField(
		"COAPPLICANT2_SCORE_REASON_DESC_4", null, new DefaultFormatter());

	public static final ExtractField COAPPLICANT2_SCORE_REASON_5 = new ExtractField(
		"COAPPLICANT2_SCORE_REASON_5", null, new DefaultFormatter());

	public static final ExtractField COAPPLICANT2_SCORE_INQUIRIES = new ExtractField(
		"COAPPLICANT2_SCORE_INQUIRIES", null, new DefaultFormatter());
	
	
	//Co-Signer
	public static final ExtractField COSIGNER_CREDIT_SCORE = new ExtractField(
		"COSIGNER_CREDIT_SCORE", null, new DefaultFormatter());

	public static final ExtractField COSIGNER_MIN_SCORE = new ExtractField(
		"COSIGNER_MIN_SCORE", null, new DefaultFormatter());
	
	public static final ExtractField COSIGNER_MAX_SCORE = new ExtractField(
		"COSIGNER_MAX_SCORE", null, new DefaultFormatter());
	
	public static final ExtractField COSIGNER_SCORE_CALCULATED_DATE= new ExtractField(
		"COSIGNER_SCORE_CALCULATED_DATE", null, new DateFormatter());

	public static final ExtractField COSIGNER_SCORE_REASON_CODE_1 = new ExtractField(
		"COSIGNER_SCORE_REASON_CODE_1", null, new DefaultFormatter());

	public static final ExtractField COSIGNER_SCORE_REASON_DESC_1 = new ExtractField(
		"COSIGNER_SCORE_REASON_DESC_1", null, new DefaultFormatter());

	public static final ExtractField COSIGNER_SCORE_REASON_CODE_2 = new ExtractField(
		"COSIGNER_SCORE_REASON_CODE_2", null, new DefaultFormatter());

	public static final ExtractField COSIGNER_SCORE_REASON_DESC_2 = new ExtractField(
		"COSIGNER_SCORE_REASON_DESC_2", null, new DefaultFormatter());

	public static final ExtractField COSIGNER_SCORE_REASON_CODE_3 = new ExtractField(
		"COSIGNER_SCORE_REASON_CODE_3", null, new DefaultFormatter());

	public static final ExtractField COSIGNER_SCORE_REASON_DESC_3 = new ExtractField(
		"COSIGNER_SCORE_REASON_DESC_3", null, new DefaultFormatter());

	public static final ExtractField COSIGNER_SCORE_REASON_CODE_4 = new ExtractField(
		"COSIGNER_SCORE_REASON_CODE_4", null, new DefaultFormatter());

	public static final ExtractField COSIGNER_SCORE_REASON_DESC_4 = new ExtractField(
		"COSIGNER_SCORE_REASON_DESC_4", null, new DefaultFormatter());

	public static final ExtractField COSIGNER_SCORE_REASON_5 = new ExtractField(
		"COSIGNER_SCORE_REASON_5", null, new DefaultFormatter());

	public static final ExtractField COSIGNER_SCORE_INQUIRIES = new ExtractField(
		"COSIGNER_SCORE_INQUIRIES", null, new DefaultFormatter());
	
	
	// Co-Signer 2
	public static final ExtractField COSIGNER2_CREDIT_SCORE = new ExtractField(
		"COSIGNER2_CREDIT_SCORE", null, new DefaultFormatter());

	public static final ExtractField COSIGNER2_MIN_SCORE = new ExtractField(
		"COSIGNER2_MIN_SCORE", null, new DefaultFormatter());
	
	public static final ExtractField COSIGNER2_MAX_SCORE = new ExtractField(
		"COSIGNER2_MAX_SCORE", null, new DefaultFormatter());
	
	public static final ExtractField COSIGNER2_SCORE_CALCULATED_DATE= new ExtractField(
		"COSIGNER2_SCORE_CALCULATED_DATE", null, new DateFormatter());

	public static final ExtractField COSIGNER2_SCORE_REASON_CODE_1 = new ExtractField(
		"COSIGNER2_SCORE_REASON_CODE_1", null, new DefaultFormatter());

	public static final ExtractField COSIGNER2_SCORE_REASON_DESC_1 = new ExtractField(
		"COSIGNER2_SCORE_REASON_DESC_1", null, new DefaultFormatter());

	public static final ExtractField COSIGNER2_SCORE_REASON_CODE_2 = new ExtractField(
		"COSIGNER2_SCORE_REASON_CODE_2", null, new DefaultFormatter());

	public static final ExtractField COSIGNER2_SCORE_REASON_DESC_2 = new ExtractField(
		"COSIGNER2_SCORE_REASON_DESC_2", null, new DefaultFormatter());

	public static final ExtractField COSIGNER2_SCORE_REASON_CODE_3 = new ExtractField(
		"COSIGNER2_SCORE_REASON_CODE_3", null, new DefaultFormatter());

	public static final ExtractField COSIGNER2_SCORE_REASON_DESC_3 = new ExtractField(
		"COSIGNER2_SCORE_REASON_DESC_3", null, new DefaultFormatter());

	public static final ExtractField COSIGNER2_SCORE_REASON_CODE_4 = new ExtractField(
		"COSIGNER2_SCORE_REASON_CODE_4", null, new DefaultFormatter());

	public static final ExtractField COSIGNER2_SCORE_REASON_DESC_4 = new ExtractField(
		"COSIGNER2_SCORE_REASON_DESC_4", null, new DefaultFormatter());

	public static final ExtractField COSIGNER2_SCORE_REASON_5 = new ExtractField(
		"COSIGNER2_SCORE_REASON_5", null, new DefaultFormatter());

	public static final ExtractField COSIGNER2_SCORE_INQUIRIES = new ExtractField(
		"COSIGNER2_SCORE_INQUIRIES", null, new DefaultFormatter());
		
	
	// Co-Signer 3
	public static final ExtractField COSIGNER3_CREDIT_SCORE = new ExtractField(
		"COSIGNER3_CREDIT_SCORE", null, new DefaultFormatter());

	public static final ExtractField COSIGNER3_MIN_SCORE = new ExtractField(
		"COSIGNER3_MIN_SCORE", null, new DefaultFormatter());
	
	public static final ExtractField COSIGNER3_MAX_SCORE = new ExtractField(
		"COSIGNER3_MAX_SCORE", null, new DefaultFormatter());
	
	public static final ExtractField COSIGNER3_SCORE_CALCULATED_DATE= new ExtractField(
		"COSIGNER3_SCORE_CALCULATED_DATE", null, new DateFormatter());

	public static final ExtractField COSIGNER3_SCORE_REASON_CODE_1 = new ExtractField(
		"COSIGNER3_SCORE_REASON_CODE_1", null, new DefaultFormatter());

	public static final ExtractField COSIGNER3_SCORE_REASON_DESC_1 = new ExtractField(
		"COSIGNER3_SCORE_REASON_DESC_1", null, new DefaultFormatter());

	public static final ExtractField COSIGNER3_SCORE_REASON_CODE_2 = new ExtractField(
		"COSIGNER3_SCORE_REASON_CODE_2", null, new DefaultFormatter());

	public static final ExtractField COSIGNER3_SCORE_REASON_DESC_2 = new ExtractField(
		"COSIGNER3_SCORE_REASON_DESC_2", null, new DefaultFormatter());

	public static final ExtractField COSIGNER3_SCORE_REASON_CODE_3 = new ExtractField(
		"COSIGNER3_SCORE_REASON_CODE_3", null, new DefaultFormatter());

	public static final ExtractField COSIGNER3_SCORE_REASON_DESC_3 = new ExtractField(
		"COSIGNER3_SCORE_REASON_DESC_3", null, new DefaultFormatter());

	public static final ExtractField COSIGNER3_SCORE_REASON_CODE_4 = new ExtractField(
		"COSIGNER3_SCORE_REASON_CODE_4", null, new DefaultFormatter());

	public static final ExtractField COSIGNER3_SCORE_REASON_DESC_4 = new ExtractField(
		"COSIGNER3_SCORE_REASON_DESC_4", null, new DefaultFormatter());

	public static final ExtractField COSIGNER3_SCORE_REASON_5 = new ExtractField(
		"COSIGNER3_SCORE_REASON_5", null, new DefaultFormatter());

	public static final ExtractField COSIGNER3_SCORE_INQUIRIES = new ExtractField(
		"COSIGNER3_SCORE_INQUIRIES", null, new DefaultFormatter());
		
	
	// Co-Signer 4
	public static final ExtractField COSIGNER4_CREDIT_SCORE = new ExtractField(
		"COSIGNER4_CREDIT_SCORE", null, new DefaultFormatter());

	public static final ExtractField COSIGNER4_MIN_SCORE = new ExtractField(
		"COSIGNER4_MIN_SCORE", null, new DefaultFormatter());
	
	public static final ExtractField COSIGNER4_MAX_SCORE = new ExtractField(
		"COSIGNER4_MAX_SCORE", null, new DefaultFormatter());
	
	public static final ExtractField COSIGNER4_SCORE_CALCULATED_DATE= new ExtractField(
		"COSIGNER4_SCORE_CALCULATED_DATE", null, new DateFormatter());

	public static final ExtractField COSIGNER4_SCORE_REASON_CODE_1 = new ExtractField(
		"COSIGNER4_SCORE_REASON_CODE_1", null, new DefaultFormatter());

	public static final ExtractField COSIGNER4_SCORE_REASON_DESC_1 = new ExtractField(
		"COSIGNER4_SCORE_REASON_DESC_1", null, new DefaultFormatter());

	public static final ExtractField COSIGNER4_SCORE_REASON_CODE_2 = new ExtractField(
		"COSIGNER4_SCORE_REASON_CODE_2", null, new DefaultFormatter());

	public static final ExtractField COSIGNER4_SCORE_REASON_DESC_2 = new ExtractField(
		"COSIGNER4_SCORE_REASON_DESC_2", null, new DefaultFormatter());

	public static final ExtractField COSIGNER4_SCORE_REASON_CODE_3 = new ExtractField(
		"COSIGNER4_SCORE_REASON_CODE_3", null, new DefaultFormatter());

	public static final ExtractField COSIGNER4_SCORE_REASON_DESC_3 = new ExtractField(
		"COSIGNER4_SCORE_REASON_DESC_3", null, new DefaultFormatter());

	public static final ExtractField COSIGNER4_SCORE_REASON_CODE_4 = new ExtractField(
		"COSIGNER4_SCORE_REASON_CODE_4", null, new DefaultFormatter());

	public static final ExtractField COSIGNER4_SCORE_REASON_DESC_4 = new ExtractField(
		"COSIGNER4_SCORE_REASON_DESC_4", null, new DefaultFormatter());

	public static final ExtractField COSIGNER4_SCORE_REASON_5 = new ExtractField(
		"COSIGNER4_SCORE_REASON_5", null, new DefaultFormatter());

	public static final ExtractField COSIGNER4_SCORE_INQUIRIES = new ExtractField(
		"COSIGNER4_SCORE_INQUIRIES", null, new DefaultFormatter());
		
	
	// //////////////////////////////////////////////////////////////////////////
	// Co-applicant2 fields.
	// //////////////////////////////////////////////////////////////////////////

	public static final ExtractField COAPPLICANT2_LASTNAME = new ExtractField(
			"COAPPLICANT2_LASTNAME", null, new DefaultFormatter());

	public static final ExtractField COAPPLICANT2_FIRSTNAME = new ExtractField(
			"COAPPLICANT2_FIRSTNAME", null, new DefaultFormatter());

	public static final ExtractField COAPPLICANT2_MIDDLENAME = new ExtractField(
			"COAPPLICANT2_MIDDLENAME", null, new DefaultFormatter());

	public static final ExtractField COAPPLICANT2_NAMESUFFIX = new ExtractField(
			"COAPPLICANT2_NAMESUFFIX", null, new DefaultFormatter());

	public static final ExtractField COAPPLICANT2_SSN = new ExtractField(
			"COAPPLICANT2_SSN", null, new SSNFormatter());

	public static final ExtractField COAPPLICANT2_STREETNUMBER = new ExtractField(
			"COAPPLICANT2_STREETNUMBER", null, new DefaultFormatter());

	public static final ExtractField COAPPLICANT2_STREETNAME = new ExtractField(
			"COAPPLICANT2_STREETNAME", null, new DefaultFormatter());

	public static final ExtractField COAPPLICANT2_TYPEOFSTREET = new ExtractField(
			"COAPPLICANT2_TYPEOFSTREET", null, new DefaultFormatter());

	public static final ExtractField COAPPLICANT2_APARTMENTBOXORSUITE = new ExtractField(
			"COAPPLICANT2_APARTMENTBOXORSUITE", null, new DefaultFormatter());

	public static final ExtractField COAPPLICANT2_ADDRESS2 = new ExtractField(
			"COAPPLICANT2_ADDRESS2", null, new DefaultFormatter());

	public static final ExtractField COAPPLICANT2_CITY = new ExtractField(
			"COAPPLICANT2_CITY", null, new DefaultFormatter());

	public static final ExtractField COAPPLICANT2_STATE = new ExtractField(
			"COAPPLICANT2_STATE", null, new DefaultFormatter());

	public static final ExtractField COAPPLICANT2_ZIPCODE = new ExtractField(
			"COAPPLICANT2_ZIPCODE", null, new ZipcodeFormatter());

	public static final ExtractField COAPPLICANT2_PHONE = new ExtractField(
			"COAPPLICANT2_PHONE", null, new PhoneFormatter());

	public static final ExtractField COAPPLICANT2_PHONEEXT = new ExtractField(
			"COAPPLICANT2_PHONEEXT", null, new DefaultFormatter());

	public static final ExtractField COAPPLICANT2_FAX = new ExtractField(
			"COAPPLICANT2_FAX", null, new PhoneFormatter());
			
	

	// //////////////////////////////////////////////////////////////////////////
	// Instance variables.
	// //////////////////////////////////////////////////////////////////////////

	private String fieldName = null;

	private Object defaultValue = null;

	private FieldFormatter formatter = null;

	private int ordinal = -1;

	/**
	 * Get the number of fields defined in this class.
	 * 
	 * @return the number of defined fields.
	 */
	public static int getNumberOfDefinedFields() {
		return nextOrdinal;
	}

	/**
	 * Public ctor for creating an instance of this class that uses default
	 * ordinal assignment (based on order of static <code>ExtractField</code>
	 * declaration in this class).
	 */
	public ExtractField(String aFieldName, Object aDefaultValue,
			FieldFormatter aFormatter) {
		this.fieldName = aFieldName;
		this.defaultValue = aDefaultValue;
		this.formatter = aFormatter;
		this.ordinal = ExtractField.nextOrdinal++;
	}

	/**
	 * Public ctor for creating an instance of this class that uses specific
	 * ordinal assignment. Provided as a convenience,
	 * <em>but typically not used by 
	 * this application; instead, the app relies on the order of static 
	 * <code>ExtractField</code> declarations in this class.</em>
	 */
	public ExtractField(String aFieldName, Object aDefaultValue,
			FieldFormatter aFormatter, int anOrdinalFieldPosition) {
		this.fieldName = aFieldName;
		this.defaultValue = aDefaultValue;
		this.formatter = aFormatter;
		this.ordinal = anOrdinalFieldPosition;
	}

	public String getFieldName() {
		return this.fieldName;
	}

	public Object getDefaultValue() {
		return this.defaultValue;
	}

	public FieldFormatter getFormatter() {
		return this.formatter;
	}

	public int getOrdinal() {
		return this.ordinal;
	}

	public boolean equals(Object obj) {
		boolean isEqual = false;
		if (obj instanceof ExtractField) {
			ExtractField otherField = (ExtractField) obj;
			String thisFieldName = this.fieldName == null ? "" : this.fieldName;
			String otherFieldName = otherField.fieldName == null ? ""
					: otherField.fieldName;
			isEqual = thisFieldName.equals(otherFieldName);
		}
		return isEqual;
	}

	public int hashCode() {
		return this.fieldName == null ? 1 : this.fieldName.hashCode();
	}

	public int compareTo(Object obj) {
		int compare = 0;
		if (obj instanceof ExtractField) {
			ExtractField otherField = (ExtractField) obj;
			compare = this.ordinal - otherField.ordinal;
		}
		return compare;
	}
}
