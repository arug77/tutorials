
package com.cmsinc.origenate.textdoc.formatters;

import java.math.BigDecimal;
import com.cmsinc.origenate.textdoc.AppException;

/**
 * Formats an amount document field (<code>java.util.BigDecimal</code>, <code>java.util.Integer</code> or 
 * <code>java.util.Long</code>) as an amount on a check is typically formatted,
 * i.e., using words for thousands, hundreds, etc. If an integer type is
 * passed, no cents are included in the amount string.
 * 
 * @since Origenate 6.0
 */
public class AmountAsWordsFormatter extends AmountFormatter implements FieldFormatter {
  /** 
   * @see com.cmsinc.origenate.textdoc.formatters.FieldFormatter#format(java.lang.Object)
   */
  public String format(Object aValue) throws AppException {
    if (aValue == null)
      return "";
      
    boolean[] arrWantCentsReturnFlag = { false };
    BigDecimal decimal = toBigDecimal(aValue, arrWantCentsReturnFlag);
    
    boolean wantCents = arrWantCentsReturnFlag[0];
    String strDecimal = decimal.toString();
    String strDollars = formatAsDollars(strDecimal);
    String strCents = wantCents ? formatAsCents(strDecimal) : "";
    return strDollars + (strCents.length() == 0 ? "" : " ") + strCents;
  }
  
  
  /**
   * Formats dollars (whole number) portion of currency amount. This code was copied from the 
   * <code>NightyLetters</code> program, and should be kept in sync with any 
   * changes there.
   * 
   * @param strValue
   *   an amount as a string (this method only cares about part before '.').
   * @return
   *   the formatted dollars part of the original amount string.
   * @throws AppException
   *   if the numeric formatting code this method delegates to encounters an error.
   */  
  public static String formatAsDollars(String strValue) throws AppException {
    String minus = "";
	if (strValue.length() == 0)
      strValue = "Zero Dollars and";
    else {
      try {
        //
        // only whole numbers an be converted
		 if(strValue.substring(0,1).equals("-"))
		{
			minus = "(minus) ";
			strValue = strValue.substring(1,strValue.length());
		}
        if (strValue.indexOf(".") >= 0)
          strValue = strValue.substring(0, strValue.indexOf("."));
        if (strValue.equals("0"))
          strValue = "Zero Dollars and";
        else {
          strValue = convertNumberToText(strValue);
          strValue += " and";
        }
      }
      catch (Exception ex) {
        throw new AppException("Could not convert amount to text, error = " + ex.toString()+ 
          ", value being converted = " + strValue);
      }
    }
    return minus + strValue;
  }
  
  /**
   * Convert a simple numeric string (such as <code>Integer.toString(</code>))
   * to a "word-format" numeric string, where the number is expressed using
   * "thousands", "hundreds", etc., as one mhgt find on a check.<br>
   * 
   * This code was copied from the <code>NightyLetters</code> program, and should 
   * be kept in sync with any changes there.
   * 
   * @param anyNumber
   *   a simple numeric string.
   * @return
   *   the numeric string in "word-format".
   * @throws Exception
   *   not sure, as not the author, but most likely an index out of bounds
   *   condition. The caller should catch the exception and deal with it.
   */
  public static String convertNumberToText(String anyNumber) throws Exception {
    String text = "";
    StringBuilder temp_builder = new StringBuilder("");
    String validChars = "0123456789";
    String bits[] = new String[100];
    final String and[] = {"", ""}; // they don't want 'and' in the words
    final String hundred[] = {"", "Hundred "};
    final String divisor[] = {"Trillion ","Billion ","Million ", "Thousand ", ""};
    int groups[] = new int[divisor.length];
    int firstDigit=0, secondDigit=0, thirdDigit=0, H=0, A= 0,D=0,i=0;
    int flag = 0;
    int x;

    if(anyNumber.equals(""))
    {
        return "";
    }

    while(anyNumber.substring(0,1).equals("0"))
    {
        anyNumber = anyNumber.substring(1,anyNumber.length());
    }

    for(x=0; x<anyNumber.length(); x++)
    {
        if(validChars.indexOf(anyNumber.substring(x,x+1)) < 0)
        {
            return "error - invalid characters detected";
        }
    }

    if(anyNumber.length() > divisor.length * 3)
    {
         return "error - outside of number range";
    }

    bits[0]= ""; bits[1]= "One ";
    bits[2]= "Two "; bits[3]= "Three ";
    bits[4]= "Four "; bits[5]= "Five ";
    bits[6]= "Six "; bits[7]= "Seven ";
    bits[8]= "Eight "; bits[9]= "Nine ";
    bits[10]= "Ten "; bits[11]= "Eleven ";
    bits[12]= "Twelve "; bits[13]= "Thirteen ";
    bits[14]= "Fourteen "; bits[15]= "Fifteen ";
    bits[16]= "Sixteen "; bits[17]= "Seventeen ";
    bits[18]= "Eighteen "; bits[19]= "Nineteen ";
    bits[20]= "Twenty "; bits[30]= "Thirty ";
    bits[40]= "Forty "; bits[50]= "Fifty ";
    bits[60]= "Sixty "; bits[70]= "Seventy ";
    bits[80]= "Eighty "; bits[90]= "Ninety ";

    x = groups.length-1;
    while(anyNumber.length() > 0) // convert in groups - 111,222,333
    {
        if(anyNumber.length() < 3)
        {
            groups[x] = Integer.parseInt(anyNumber);
            anyNumber = "";
        }
        else
        {
            groups[x] = Integer.parseInt(
                anyNumber.substring(anyNumber.length()-3,anyNumber.length()));
            anyNumber = anyNumber.substring(0,anyNumber.length()-3);
        }
        x--;
    }

    for(i = x+1; i < groups.length; i++)
    {
        firstDigit = (int)groups[i]/100;
        secondDigit = (int)(groups[i] - (int)(groups[i]/100) * 100)/10;
        thirdDigit = groups[i] - (firstDigit * 100) - (secondDigit * 10);

        if(secondDigit == 1)
        {
            secondDigit += 9 + thirdDigit;
            thirdDigit = 0;
        }
        else secondDigit *= 10;
        // setting flag for "and" in third group
        flag = (i < groups.length-1 && (firstDigit + secondDigit + thirdDigit) > 0)? 1:flag;

        H = firstDigit > 0? 1 : 0;

        A = ((firstDigit > 0 || (i == groups.length-1 && flag == 1)) &&
                            (secondDigit > 0 || thirdDigit > 0))? 1 : 0;

        D = (firstDigit + secondDigit + thirdDigit) > 0? i : groups.length-1;
        temp_builder.append(bits[firstDigit] + hundred[H] + and[A] +
            bits[secondDigit] + bits[thirdDigit] + divisor[D]); // appending "\n" to the end is optional

    }
    text = temp_builder.toString();
    return text;
  }    
  
  /**
   * Formats cents portion of currency amount. This code was copied from the 
   * <code>NightyLetters</code> program, and should be kept in sync with any 
   * changes there.
   * 
   * @param strValue
   *   an amount as a string (this method only cares about part after '.').
   * @return
   *   the formatted cents part of the original amount string.
   */
  public static String formatAsCents(String strValue) {
    if (strValue.indexOf(".") >= 0) {
      strValue = strValue.substring(strValue.indexOf(".") + 1);
      if (strValue.length() > 2)
        strValue = strValue.substring(0, 2);
      else {
        if (strValue.length() < 2) {
          if (strValue.length() == 1)
            strValue += "0";
          else
            strValue = "00";
        }
      }
    }
    else
      strValue = "00";

    // GL. 07/30/04 they want it expressed as 00/100
    strValue += "/100";
    return strValue;
  }  
}
