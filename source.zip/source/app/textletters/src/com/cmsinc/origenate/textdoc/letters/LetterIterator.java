package com.cmsinc.origenate.textdoc.letters;

import java.util.Date;
import java.util.Map;
import java.util.Iterator;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.SQLException;
import java.util.logging.Level;
import com.cmsinc.origenate.textdoc.AppLogger;

/**
 * 
 */
public class LetterIterator implements Iterator {

  private static final long SYSTEM_EVALUATOR_ID = -1;

  private String letterType = null;

  private Map mapEvaluatorDocumentInfo = null;
  
  private LetterFactory.DocumentInfo[] arrDocumentInfo = null;
  
  private int indexDocumentInfo = -1;

  private ResultSet rs = null;
  
  private Statement stmt = null;

  private boolean hasMoreResults = true; 
  
  private long currentRequestId = -1;

  private long currentEvaluatorId = -1;
  
  private String currentEvaluatorName = null;
  
  private long currentClientAppId = -1;
  
  private Date currentInitiationDate = null;
  
  private long currentAppStatusId = -1;
  
  private String currentTaskId = null;
  
  private boolean currentPersonalFlag = false;
  
  private String currentBodyText = null;
  
  private int currentNumberOfDelayDays = 0;
  
  /**
   *
   * @throws IllegalStateException
   *   if a database error occurs trying to fetch the next row.
   */
  LetterIterator(String aLetterType, Map anEvaluatorDocumentInfoMap, 
    ResultSet aCreditRequestResultSet, Statement aCreditRequestStmt) {
    this.letterType = aLetterType;
    this.mapEvaluatorDocumentInfo = anEvaluatorDocumentInfoMap;
    this.rs = aCreditRequestResultSet;
    this.stmt = aCreditRequestStmt;
    this.arrDocumentInfo = new LetterFactory.DocumentInfo[0];
    this.indexDocumentInfo = this.arrDocumentInfo.length;
  }

  /**
   * @throws IllegalStateException
   *   if a database error occurs trying to fetch the next row.
   * @see java.util.Iterator#hasNext()
   */
  public boolean hasNext() {
    try {
      if (this.indexDocumentInfo >= this.arrDocumentInfo.length)
        this.hasMoreResults = this.rs.next();
    }
    catch (SQLException ex) {
      throw new IllegalStateException("failed to check next() is result set, excception = " + ex);
    }
    return this.hasMoreResults;
  }

  /**
   * @see java.util.Iterator#next()
   */
  public Object next() {
    if (!this.hasMoreResults)
      return null;
 
    Letter letter = null;
    try {
      if (this.indexDocumentInfo >= this.arrDocumentInfo.length) {
        for (;;) {
          this.currentRequestId = rs.getLong("request_id");
          this.currentEvaluatorId = rs.getLong("evaluator_id");
          this.currentEvaluatorName = rs.getString("evaluator_name_txt");
          this.currentClientAppId = rs.getLong("client_app_id"); 
          this.currentInitiationDate = rs.getDate("initiation_dt");
          this.currentAppStatusId = rs.getLong("app_status_id"); 
          this.currentTaskId = rs.getString("task_id");
          this.currentPersonalFlag = rs.getInt("personal_flg") != 0;
          this.currentBodyText = rs.getString("printer_text");
          this.currentNumberOfDelayDays = rs.getInt("delay_days");
          if (rs.wasNull())
            this.currentNumberOfDelayDays = 0;
  
          this.arrDocumentInfo = (LetterFactory.DocumentInfo[]) this.mapEvaluatorDocumentInfo.get(
            Long.valueOf(this.currentEvaluatorId));
          if (this.arrDocumentInfo == null) {
            this.arrDocumentInfo = (LetterFactory.DocumentInfo[]) this.mapEvaluatorDocumentInfo.get(
              Long.valueOf(SYSTEM_EVALUATOR_ID));
          }
          if (this.arrDocumentInfo == null) {         
            AppLogger.logger.log(Level.FINEST, "no letter generated since no documentInfo for letter type = " + this.letterType + 
              " and evaluator ID=" + this.currentEvaluatorId + " (request ID=" + this.currentRequestId + ")");            
            if (this.rs.next())
              continue;
            return null;
          }
          this.indexDocumentInfo = 0;
          break;
        }
      }

      letter = new Letter(this.currentRequestId, this.currentEvaluatorId,
        this.currentEvaluatorName, this.currentClientAppId, this.currentInitiationDate,
        this.currentAppStatusId, this.currentTaskId, this.currentPersonalFlag,
        this.arrDocumentInfo[this.indexDocumentInfo].documentId,
        this.arrDocumentInfo[this.indexDocumentInfo].documentType, 
        this.currentNumberOfDelayDays, this.currentBodyText, 
        this.letterType);
      this.indexDocumentInfo++;
    }
    catch (SQLException ex) {
      throw new IllegalStateException("failed to fetch next CREDIT_REQUEST, exception = " + ex);
    }
    return letter;
  }
  
  public void remove() {
    throw new UnsupportedOperationException();
  }

  public void dispose() {
    try { 
      this.rs.close();
      this.stmt.close();
      this.mapEvaluatorDocumentInfo = null;
      this.arrDocumentInfo = null; 
    } 
    catch (SQLException ex) {
      AppLogger.logger.log(Level.WARNING, "failed to cleanup properly by closing stmt or result set", ex);
    } 
  }
}
