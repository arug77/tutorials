package com.cmsinc.origenate.textdoc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.sql.DataSource;
import oracle.jdbc.OracleDriver;
import javax.naming.InitialContext;
import javax.naming.NamingException;

/**
 * Factory for obtain connections to JDBC. Currently this simply allocates a
 * new connection when requested, but round-robin, caching (internal or via
 * pooled connection JDBC interface) or other strategies may be encapsulated
 * as needed.<br>
 * 
 * Treat this class as "thread-safe".<br>
 * 
 * @since Origenate 6.0 
 */
public class ConnectionFactory { 
  /**
   * Name of app-server managed databaase connection pool for Origenate, prefixed 
   * with client name from configuration.
   */
  private static final String ORIGENATE_CONNPOOL_NAME = "_origpool";
  
  /**
   * Singleton instance of this class.
   */
  private static ConnectionFactory singleton = null;
  
  /**
   * Tracks if Oracle driver was registered with JDBC driver manager.
   */
  private boolean wasDriverRegistered = false;
  
  /**
   * Database (and other) configuration information load from Origenate .INI file.
   */
  private ConfigInfo configInfo = null;
  
  /**
   * Get singleton instance of this class. 
   * 
   * @param aConfigInfo
   *   database (and other) config info.
   * @return
   *   the factory instance.
   * @throws AppException
   *   if config file cannot be read.
   */
  public synchronized static ConnectionFactory getInstance(ConfigInfo aConfigInfo) throws AppException {
    if (singleton == null)
      singleton = new ConnectionFactory(aConfigInfo);
    return singleton;
  }

  /**
   * Restricted ctor for creating an instance of this class.
   * 
   * @param aConfigInfo
   *   database (and other) config info.
   * @throws AppException
   *   if config file cannot be read.
   */
  private ConnectionFactory(ConfigInfo aConfigInfo) throws AppException {
    if (aConfigInfo == null)
      throw new AppException("config info required");
    this.wasDriverRegistered = false;
    this.configInfo = aConfigInfo;
  }
  
  /**
   * Allocate an "unbound" database connection by getting a connection directly
   * from the JDBC driver manager. This method is synchronized since it can change
   * the state of the object.
   * 
   * @return
   *   the allocated database connection.
   * @throws AppException
   *   if a database error occurs.
   */
  public synchronized Connection getUnboundConnection() throws AppException {
    Connection conn = null;
    try {
      if (!this.wasDriverRegistered)
        DriverManager.registerDriver (new OracleDriver());
      
      String dbUrl = "jdbc:oracle:thin:@";
      String sTNSEntry = this.configInfo.getTNSEntry();
      
      if (sTNSEntry == null) {
    	  dbUrl = dbUrl + this.configInfo.getDbHost() + ":" + this.configInfo.getDbPort() + ":" + this.configInfo.getDbSid();
      } else {
    	  // use tns entry if available
    	  dbUrl = dbUrl + sTNSEntry;
      }
      
      conn = DriverManager.getConnection(dbUrl, this.configInfo.getDbUser(), this.configInfo.getDbPasswd());
      //conn.setAutoCommit(false);
      conn.setAutoCommit(true); // GL. commit as you go so out file matches doc history rows
      this.wasDriverRegistered = true;
    }
    catch (SQLException ex) {
      throw new AppException("Failed to connect to database", ex);
    }
    return conn;
  }
  
  /**
   * Allocate an "bound" database connection by getting a connection from a 
   * <code>DataSource</code> bound into JNDI via an application server environment 
   * (e.g., JRun).
   * 
   * @return
   *   the allocated database connection.
   * @throws AppException
   *   if a database error occurs.
   */
  public Connection getBoundConnection() throws AppException {
    Connection conn = null;
    String jndiName = this.configInfo.getClientName() + ORIGENATE_CONNPOOL_NAME;
    try {
      InitialContext ctx = new InitialContext();
  	  DataSource ds = (javax.sql.DataSource) ctx.lookup(jndiName);
  	  conn = ds.getConnection();
      //conn.setAutoCommit(false);
      conn.setAutoCommit(true); // GL. commit as you go so out file matches doc history rows
    }
    catch (NamingException ex) {
      throw new AppException("Failed to lookup name '" + jndiName + "' in JNDI", ex);
    }
    catch (SQLException ex) {
      throw new AppException("Failed to connect to database", ex);
    }
    return conn;
  }  
}
