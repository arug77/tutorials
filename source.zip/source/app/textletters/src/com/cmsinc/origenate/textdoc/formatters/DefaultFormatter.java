package com.cmsinc.origenate.textdoc.formatters;

import com.cmsinc.origenate.textdoc.AppException;

/**
 * This class performs default formatting for a document field, which is
 * to simply convert the value to a string.
 * 
 * @since Origenate 6.0
 */
public class DefaultFormatter implements FieldFormatter {
  public String format(Object aValue) throws AppException {
    String strValue = null;
    if (aValue == null)
      strValue = "";
    else if (aValue instanceof Integer || aValue instanceof Long) {
      Number number = (Number) aValue;
      strValue = number.longValue() < 0 ? "" : number.toString();
    }
    else
      strValue = aValue.toString();
    return strValue;
  }
}
