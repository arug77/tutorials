package com.cmsinc.origenate.textdoc.payload;

/**
 * Data about stipulations on loan.<br>
 * 
 * Treat this class as "thread-safe", since it is immutable once created.
 * 
 * @since Origenate 6.0
 */
public class Stipulation {  
  private String text = null;
  private String description = null; 
  
  public Stipulation(String aStipulationText, String aDescription) {
    this.text = aStipulationText;
    this.description = aDescription;
  }
  
  public String getText() {
    return this.text;
  }
  
  public String getDescription() {
    return this.description;
  }
}
