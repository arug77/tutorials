package com.cmsinc.origenate.textdoc.formatters;

import java.util.Date;
import java.text.SimpleDateFormat;
import com.cmsinc.origenate.textdoc.AppException;

/**
 * Formats a date document field (<code>java.util.Date</code>) into a date string.
 *
 * @since Origenate 6.0
 */
public class DateFormatter implements FieldFormatter {

  private static final String DATE_FORMAT = "MM/dd/yyyy";

  public String format(Object aValue) throws AppException {

		/*** 2/17/2007 ChrisN CL141132 Triad's exception in generate counter offer letters:
		SEVERE: formatting failed for extract field 'DEALSTRUCT_DECISIONDATE', value = 'null', error = argument to DateFormatter must be a date
		***/
    if ((aValue != null) && !(aValue instanceof Date))
      throw new AppException("argument to DateFormatter must be a date");

    String strValue = null;
    Date date = (Date) aValue;
    if (date == null)
      strValue = "";
    else {
      SimpleDateFormat fmt = new SimpleDateFormat(DATE_FORMAT);
      strValue = fmt.format(date);
    }
    return strValue;
  }
}
