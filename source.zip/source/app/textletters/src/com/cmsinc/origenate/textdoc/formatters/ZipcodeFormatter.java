package com.cmsinc.origenate.textdoc.formatters;

import com.cmsinc.origenate.textdoc.AppException;

/**
 * Formats an SSN.
 * 
 * @since Origenate 6.0
 */
public class ZipcodeFormatter extends MaskFormatter implements FieldFormatter {
 
  private static final String ZIPCODE_MASK = "?????-????";
  
  /** 
   * @see com.cmsinc.origenate.textdoc.formatters.FieldFormatter#format(java.lang.Object)
   */
  public String format(Object aValue) throws AppException {
    if (aValue == null)
      return "";
      
    String zip = aValue.toString().trim();
    String formattedZip = zip;
    if (zip.length() == 9) 
      formattedZip = applyDisplayMask(ZIPCODE_MASK, ' ', zip);
    return formattedZip;
  }
}
