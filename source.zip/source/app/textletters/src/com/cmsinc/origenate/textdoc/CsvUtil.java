package com.cmsinc.origenate.textdoc;

import java.util.Map;
import java.util.Iterator;
import java.util.logging.Level;
import java.io.PrintWriter;
import com.cmsinc.origenate.textdoc.formatters.FieldFormatter;

/**
 * Utility class for creating CSV (comma-separated values) output.
 * 
 * Treat this class as "thread-safe".
 * 
 * @since Origenate 6.0
 */
public class CsvUtil {
  
  static void writeExtractFieldsAsHeader(Map aFieldMap, PrintWriter aWriter) {
    for (Iterator iter=aFieldMap.entrySet().iterator();iter.hasNext();) {
      Map.Entry entry = (Map.Entry) iter.next();
      ExtractField field = (ExtractField) entry.getKey();
      StringBuffer bufField = new StringBuffer();
      bufField.append('"');
      bufField.append(escapeChar(field.getFieldName(), '"', '"'));
      bufField.append('"');
      bufField.append(iter.hasNext() ? "," : "");
      aWriter.print(bufField.toString());
    }
    aWriter.println();
    aWriter.flush();
  }
  
  static void writeExtractFieldsAsLine(Map aFieldMap, PrintWriter aWriter) throws AppException {
    for (Iterator iter=aFieldMap.entrySet().iterator();iter.hasNext();) {
      Map.Entry entry = (Map.Entry) iter.next();
      ExtractField field = (ExtractField) entry.getKey();

      Object objValue = entry.getValue();
      if (objValue == null)
        objValue = field.getDefaultValue();
      
// debug
      /*
System.out.println("FIELD = " + field.getFieldName());
if (entry.getValue() == null)
  System.out.println("\tentry.value is NULL");
else
  System.out.println("\tentry.value.class=" + entry.getValue().getClass().getName());

if (objValue == null)
  System.out.println("\tobjValue is NULL");
else
  System.out.println("\tobjValue.class=" + objValue.getClass().getName());
  */
// end debug
    
      String strValue = null;
      try {
        FieldFormatter ftor = field.getFormatter();
        if (ftor == null)
          throw new AppException("formatter not specified");
        
        if ((strValue = ftor.format(objValue)) == null)
          throw new AppException("value should not be NULL after formatting");
      }
      catch (AppException ex) {
        AppLogger.logger.log(Level.SEVERE, "formatting failed for extract field '" + 
          field.getFieldName() + "', value = '" + objValue + "', error = " + ex.getMessage());      
        throw ex;
      }

      StringBuffer bufField = new StringBuffer();
      bufField.append('"');
      bufField.append(escapeChar(strValue, '"', '"'));
      bufField.append('"');
      bufField.append(iter.hasNext() ? "," : "");
      aWriter.print(bufField.toString());
    }
    aWriter.println();
    aWriter.flush();
  }
  
  static String escapeChar(String s, char chChar, char chEscape) {
    //
    // See if we need to re-write string, i.e., if any special characters
    // or if string is null. If no changes, simply return input argunment.

    if (s == null)
      return s;

    int i = 0, n = s.length();
    for (;i < n && s.charAt(i) != chChar;i++) ;
    if (i == n)
      return s;

    // Copy string, inserting escape character before special character.

    StringBuffer buf = new StringBuffer(s.length() + 16);
    for (i=0,n=s.length();i < n;i++) {
      char c = s.charAt(i);
      if (c == chChar) {
        buf.append(chEscape);
        buf.append(chChar);
      }
      else
        buf.append(c);
    }
    return buf.toString();
  }  
}
