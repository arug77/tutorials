package com.cmsinc.origenate.textdoc.payload;

/**
 * Data about the Risk Based Pricing Results from the Bureau Of Record.<br>
 * 
 * Treat this class as "thread-safe", since it is immutable once created.
 * 
 * @since Origenate 8.5.25
 */
public class BureauRBP 
{
  
	private String rbp_low = null;
	private String rbp_high = null;
	private String rbp_inq = null;
  
	BureauRBP(String arbp_low, String arbp_high, String arbp_inq) 
	{

		this.rbp_low = arbp_low;
		this.rbp_high = arbp_high;
		if(arbp_inq != null)
		{
			this.rbp_inq = arbp_inq;
		}
		else
		{
			this.rbp_inq = "F";
		}
	}
  
	public String getRbp_low() 
	{
		return this.rbp_low;
	}
  
	public String getRbp_high() 
	{
		return this.rbp_high;
	}
  
	public String getRbp_inq() 
	{
		return this.rbp_inq;
	}
}
