package com.cmsinc.origenate.textdoc.letters;

import java.sql.Connection;

/**
 * Factory for selecting credit apps and creating <code>InitialLetter</code> instances.<br>
 * 
 * Treat this class as "thread-hostile".
 * 
 * @since Origenate 8.5
 */
public class InitialLetterFactory extends LetterFactory 
{

	/**
	 * To select Expired apps: 
	 * 
	 * The application must have a an app status of 20 (expired).
	 * similar to Nightly Letters, we exclude apps older than 90
	 * days to reduce the result set.
	 */  
	private static final String INITIAL_SELECT_LIST = 
	"cps.turndown_delay_days_num delay_days, '' '' AS printer_text";
	
	private static final String INITIAL_FROM_CLAUSE = 
    "credit_req_checklist_item chklist ";
	
	private static final String INITIAL_WHERE_CLAUSE =     
	" cr.DECISION_STATUS_ID in (1,3,102) "
				    + "and (trunc(sysdate, ''dd'') - "
				    +"(CASE cps.NGHTLY_LTTRS_CMPDT_ID"
						+" WHEN 1 THEN "
							+"trunc((SELECT a.send_dt FROM credit_req_decisions_evaluator a WHERE a.request_id = cr.request_id AND a.decision_ref_id ="
							+"(SELECT MAX (b.decision_ref_id) FROM credit_req_decisions_evaluator b WHERE b.request_id = cr.request_id "
							+"AND b.decision_id = cr.decision_status_id AND b.decision_category_id <= 4 AND NVL(b.configurable_redecision_flg,0) = 0)),''dd'')"
						+"ELSE "
							+"trunc((SELECT cr.APP_SIGNED_DT from dual),''dd'')"
							+"END))>=cps.open_stips_initial_days_num "
					+ "and cr.request_id = chklist.request_id "
					+ "and chklist.EVALUATOR_ID = cr.EVALUATOR_ID "
					+ "and chklist.SEND_TO_BORR_FLG = 1 "
					+ "and nvl(chklist.CHECKLIST_ITEM_STATUS_ID,1) = 1";
    
	public static final String LETTER_CATEGORY = "INITIAL";
   
	protected String getLetterCategory() 
	{
		return LETTER_CATEGORY;
	}
  
	/**
	 * Restricted ctor for creating an instance of this class.
	 *  
	 * @param someEvaluatorIds
	 *  evaluators to search by, or null to search regardless of evaluator.
	 */
	public InitialLetterFactory(Connection aConnection, long[] someEvaluatorIds) 
	{
		super(aConnection, LETTER_CATEGORY, someEvaluatorIds);
	}
  
	protected StringBuffer selectList() 
	{
		StringBuffer buf = super.selectList();
		buf = appendCharIfNeeded(buf, ',');
		buf.append(INITIAL_SELECT_LIST);
		return buf;
	}
  
	protected StringBuffer fromClause() 
	{
		StringBuffer buf = super.fromClause();	
		buf = appendCharIfNeeded(buf, ',');
		buf.append(INITIAL_FROM_CLAUSE);		
		return buf;
	}  
  
	protected StringBuffer whereClause() 
	{
		StringBuffer buf = super.whereClause();
		buf = appendWordIfNeeded(buf, "AND");
		buf.append(INITIAL_WHERE_CLAUSE);
		return buf;
	}  
}
