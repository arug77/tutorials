package com.cmsinc.origenate.textdoc.payload;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import java.util.logging.Level;
import com.cmsinc.origenate.textdoc.AppLogger;
import com.cmsinc.origenate.textdoc.AppException;

/**
 * Simple factory class for creating instances of <code>CreditRequestFinance</code> 
 * by quering the database.<br>
 * 
 * Treat this class as "thread-hostile".<br>
 * 
 * @since Origenate 6.0
 */
public class CreditRequestFinanceFactory {
  private static final String QUERY_SQL = 
    "SELECT cf.CASH_DOWN_NUM, cf.TERM_NUM, cf.REQUESTED_RATE_NUM, cf.PAYMENT_NUM, calc_total_financed_num(?, ?) REQUESTED_AMT " +
    "FROM CREDIT_REQUEST_FINANCE cf  " +
    "WHERE REQUEST_ID = ? AND EVALUATOR_ID = ?";

  private Connection conn = null;
    
  public CreditRequestFinanceFactory(Connection aConnection) {
    this.conn = aConnection;
  }
  
  public CreditRequestFinance getFinance(long aRequestId, long anEvaluatorId) throws AppException {
    CreditRequestFinance data = null;
    PreparedStatement stmt = null;
    ResultSet rs = null;
    long elapsedQueryTime = 0;
    
    try {
      int idx = 1;
      long startQueryTime = (new Date()).getTime();
      stmt = this.conn.prepareStatement(QUERY_SQL);
      stmt.setLong(idx++, aRequestId);
      stmt.setLong(idx++, anEvaluatorId);
      stmt.setLong(idx++, aRequestId);      
      stmt.setLong(idx++, anEvaluatorId);
      rs = stmt.executeQuery();
      if (rs != null && rs.next()) {
        int term = rs.getInt("TERM_NUM"); 
        if (rs.wasNull())
          term = -1;
                    
        data = new CreditRequestFinance(term, rs.getBigDecimal("REQUESTED_AMT"), 
          rs.getBigDecimal("REQUESTED_RATE_NUM"), rs.getBigDecimal("PAYMENT_NUM"), 
          rs.getBigDecimal("CASH_DOWN_NUM"));
      }
      
      long endQueryTime = (new Date()).getTime();
      elapsedQueryTime = endQueryTime - startQueryTime;
    }
    catch (SQLException ex) {
      throw new AppException("failed to query CREDIT_REQUEST_FINANCE " +
        "for request ID=" + aRequestId + ", evaluator ID=" + anEvaluatorId, ex);
    }
    finally {
		try{ if(rs != null) rs.close(); }catch(Exception e1){e1.printStackTrace();}
		try{ if(stmt != null) stmt.close(); }catch(Exception e1){e1.printStackTrace();}
	}
    
    AppLogger.logger.log(Level.FINEST, Thread.currentThread().getName() + 
      ": queried " + 1 + " CreditRequestFinance object in " + elapsedQueryTime + " ms");    
    return data;
  }
}
