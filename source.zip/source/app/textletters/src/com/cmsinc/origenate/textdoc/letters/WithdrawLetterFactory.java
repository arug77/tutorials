package com.cmsinc.origenate.textdoc.letters;

import java.sql.Connection;

/**
 * Factory for selecting credit apps and creating <code>WithdrawLetter</code> instances.<br>
 * 
 * Treat this class as "thread-hostile".
 * 
 * @since Origenate 8.5
 */
public class WithdrawLetterFactory extends LetterFactory 
{
	private static final String WITHDRAW_SELECT_LIST = 
	"cps.turndown_delay_days_num delay_days, ev.turndown_printer_txt printer_text";
    
	private static final String WITHDRAW_FROM_CLAUSE = 
		"credit_request_journal crj";

	/**
	 * To select Expired apps: 
	 * 
	 * The application must have a an app status of 20 (expired).
	 * similar to Nightly Letters, we exclude apps older than 90
	 * days to reduce the result set.
	 */  
	private static final String WITHDRAW_WHERE_CLAUSE =     
	"cr.app_status_id = 19 and cr.request_id = crj.request_id and crj.journal_event_id = 22 and crj.created_user_id = ''SYSTEM''";
    
	public static final String LETTER_CATEGORY = "WITHDRAW_LETTER";
   
	protected String getLetterCategory() 
	{
		return LETTER_CATEGORY;
	}
  
	/**
	 * Restricted ctor for creating an instance of this class.
	 *  
	 * @param someEvaluatorIds
	 *  evaluators to search by, or null to search regardless of evaluator.
	 */
	public WithdrawLetterFactory(Connection aConnection, long[] someEvaluatorIds) 
	{
		super(aConnection, LETTER_CATEGORY, someEvaluatorIds);
	}
  
	protected StringBuffer selectList() 
	{
		StringBuffer buf = super.selectList();
		buf = appendCharIfNeeded(buf, ',');
		buf.append(WITHDRAW_SELECT_LIST);
		return buf;
	}
  
	protected StringBuffer fromClause() 
	{
		StringBuffer buf = super.fromClause();
		buf = appendCharIfNeeded(buf, ',');
		buf.append(WITHDRAW_FROM_CLAUSE);
		return buf;
	}  
  
	protected StringBuffer whereClause() 
	{
		StringBuffer buf = super.whereClause();
		buf = appendWordIfNeeded(buf, "AND");
		buf.append(WITHDRAW_WHERE_CLAUSE);
		return buf;
	}  
}
