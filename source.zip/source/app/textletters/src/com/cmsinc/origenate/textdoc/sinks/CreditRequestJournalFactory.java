package com.cmsinc.origenate.textdoc.sinks;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import java.util.logging.Level;
import com.cmsinc.origenate.textdoc.AppLogger;
import com.cmsinc.origenate.textdoc.AppException;
import com.cmsinc.origenate.util.OWASPSecurity;

/**
 * Simple factory class for creating persistent instances of <code>CreditRequestJournal</code> 
 * by inserting rows into the database.<br>
 * 
 * Treat this class as "thread-hostile", since it caches a statement and database connection.<br>
 * 
 * @since Origenate 6.0
 */
public class CreditRequestJournalFactory {
  private static final String INSERT_SQL = 
    "INSERT INTO CREDIT_REQUEST_JOURNAL(" +
    "  REQUEST_ID, EVALUATOR_ID, JOURNAL_ID, JOURNAL_EVENT_ID, " +
    "  APP_STATUS_ID, JOURNAL_EVENT_TXT, CREATED_USER_ID, TASK_ID, JOURNAL_DT, APPSEQNO, TEAM_ID) " +
    "VALUES (?,?,?,?,?,?,?,?,sysdate,?,null) ";
   
  private static final String QUERY_JOURNALID_SQL = 
    "SELECT GET_JOURNAL_ID.NEXTVAL AS JOURNAL_ID FROM DUAL";

  private Connection conn = null;
  
  private PreparedStatement stmtInsert = null;
  
  private PreparedStatement stmtSelectJournalId = null;
  
  private int batchSize = 0;
  
  private int updateCount = 0;
    
  public CreditRequestJournalFactory(Connection aConnection, int aBatchSize) throws AppException {
    try {
      this.conn = aConnection;
      this.batchSize = aBatchSize;
      this.stmtSelectJournalId = this.conn.prepareStatement(QUERY_JOURNALID_SQL);
      this.stmtInsert = this.conn.prepareStatement(INSERT_SQL);
      this.stmtInsert.clearBatch();
      this.updateCount = 0;
    }
    catch (SQLException ex) {
      throw new AppException("prepare INSERT into CREDIT_REQUEST_JOURNAL", ex);
    }
  }
  
  public void create(CreditRequestJournal aNewJournalObject) throws AppException {
    String operation = null;
    int[] updateStatus = null;
	ResultSet rs = null;
    try {
      operation = "query GET_JOURNAL_ID sequence";
      rs = this.stmtSelectJournalId.executeQuery();
      long journalId = (rs != null && rs.next()) ? rs.getLong(1) : -1;
      // GL. need to close
      rs.close();
      if (journalId >= 0)
        aNewJournalObject.setJournalId(journalId);
      else
        throw new AppException("failed obtain next value from GET_JOURNAL_ID sequence");

      operation = "insert CREDIT_REQUEST_JOURNAL";
      int idx = 1;
      
      // Set attributes from journal object into SQL insert statement.
            
      this.stmtInsert.setLong(idx++, aNewJournalObject.getRequestId());
      this.stmtInsert.setLong(idx++, aNewJournalObject.getEvaluatorId());
      this.stmtInsert.setLong(idx++, aNewJournalObject.getJournalId());
      this.stmtInsert.setLong(idx++, aNewJournalObject.getJournalEventId());
      this.stmtInsert.setInt(idx++, aNewJournalObject.getAppStatusId());     
      this.stmtInsert.setString(idx++, OWASPSecurity.validationCheck(aNewJournalObject.getJournalEvent(),OWASPSecurity.SQLPARAMSTRING));
      this.stmtInsert.setString(idx++, aNewJournalObject.getUser());
      this.stmtInsert.setString(idx++, aNewJournalObject.getTask());
      this.stmtInsert.setLong(idx++, aNewJournalObject.getAppSeqno());

      // Add parameterized statement to batch, and execute batch if batch size reached.
      
      this.stmtInsert.addBatch();
      if (++this.updateCount >= this.batchSize)
        flushUpdates();
    }
    catch (Exception ex) {
      throw new AppException(operation + " failed for request ID=" + aNewJournalObject.getRequestId(), ex);
    }
	finally {
	  try{ if(rs != null) rs.close(); }catch(Exception e1){e1.printStackTrace();}
	}
  }
  
  public void flushUpdates() throws AppException {
    long startUpdateTime = (new Date()).getTime();
    int numberOfAffectedRows = 0;
    
    try {
      int[] updateStatus = this.stmtInsert.executeBatch();
      this.stmtInsert.clearBatch();
      this.updateCount = 0;
      
      for (int i=0;updateStatus != null && i < updateStatus.length;i++) {
        if (updateStatus[i] == PreparedStatement.EXECUTE_FAILED)
          throw new  AppException("one or more batch INSERTS into CREDIT_REQUEST_JOURNAL failed");
        else
          numberOfAffectedRows++;
      }
    }
    catch (SQLException ex) {
      throw new AppException("failed to execute batch INSERT into CREDIT_REQUEST_JOURNAL", ex);
    }
    
    long endUpdateTime = (new Date()).getTime();
    long elapsedUpdateTime = endUpdateTime - startUpdateTime;
    AppLogger.logger.log(Level.FINEST, Thread.currentThread().getName() + 
      ": inserted " + numberOfAffectedRows + " CreditRequestJournal objects in " + elapsedUpdateTime + " ms");    
    // GL need to close and reopen cursor to free JDBC resources
    dispose();
    try {
      this.stmtSelectJournalId = this.conn.prepareStatement(QUERY_JOURNALID_SQL);
      this.stmtInsert = this.conn.prepareStatement(INSERT_SQL);
      this.stmtInsert.clearBatch();
      this.updateCount = 0;
    }
    catch (SQLException ex) {
      throw new AppException("prepare INSERT into CREDIT_REQUEST_JOURNAL", ex);
    }
  } // flushUpdates()

  /**
   * Release resources held by this instance, such as JDBC statements. This method
   * must be safe to call twice in a row (i.e., must determine if it has already
   * done cleanup) since it is called from <code>finalize()</code> as a fail-safe.
   */  
  public void dispose() {
    try {
      if (this.stmtSelectJournalId != null) {
        this.stmtSelectJournalId.close();
        this.stmtSelectJournalId = null;
      }
      if (this.stmtInsert != null) {
        this.stmtInsert.close();
        this.stmtInsert = null;
      }
    }
    catch (SQLException ex) {
      AppLogger.logger.log(Level.WARNING, "failed to close CREDIT_REQUEST_JOURNAL statement", ex);
    }
  }
  
  protected void finalize() throws Throwable {
    dispose();
  }
}
