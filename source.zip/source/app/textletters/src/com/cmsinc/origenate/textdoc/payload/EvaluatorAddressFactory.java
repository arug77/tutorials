package com.cmsinc.origenate.textdoc.payload;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import java.util.logging.Level;
import com.cmsinc.origenate.textdoc.AppLogger;
import com.cmsinc.origenate.textdoc.AppException;

/**
 * Simple factory class for creating instances of <code>EvaluatorAddress</code> 
 * by quering the database.<br>
 * 
 * Treat this class as "thread-hostile" (tied to a JDBC connection, which may or may not be thread-safe).<br>
 * 
 * @since Origenate 6.0
 */
public class EvaluatorAddressFactory {
  private static final String QUERY_SQL = 
    "SELECT ADDRESS1_TXT, ADDRESS2_TXT, CITY_TXT, STATE_ID, ZIPCODE_TXT, " +
    "       PHONE_NUMBER_TXT, FAX_NUMBER_TXT " +
    "FROM EVALUATOR_ADDRESS " +
    "WHERE EVALUATOR_ID = ?"; 

  private Connection conn = null;
    
  public EvaluatorAddressFactory(Connection aConnection) {
    this.conn = aConnection;
  }
  
  public EvaluatorAddress getAddress(long anEvaluatorId) throws AppException {
    EvaluatorAddress data = null;
    PreparedStatement stmt = null;
    ResultSet rs = null;
    long elapsedQueryTime = 0;

    try {
      int idx = 1;
      long startQueryTime = (new Date()).getTime();
      stmt = this.conn.prepareStatement(QUERY_SQL);
      stmt.setLong(idx++, anEvaluatorId);
      rs = stmt.executeQuery();
      if (rs != null && rs.next()) {      	
        data = new EvaluatorAddress(rs.getString("ADDRESS1_TXT"), 
          rs.getString("ADDRESS2_TXT"), rs.getString("CITY_TXT"), 
          rs.getString("STATE_ID"), rs.getString("ZIPCODE_TXT"), 
          rs.getString("PHONE_NUMBER_TXT"), rs.getString("FAX_NUMBER_TXT"));
      }
      
      long endQueryTime = (new Date()).getTime();
      elapsedQueryTime = endQueryTime - startQueryTime;      
    }
    catch (SQLException ex) {
      throw new AppException("failed to query EVALUATOR_ADDRESS for evaluator ID=" + 
        anEvaluatorId, ex);
    }
    finally {
		try{ if(rs != null) rs.close(); }catch(Exception e1){e1.printStackTrace();}
		try{ if(stmt != null) stmt.close(); }catch(Exception e1){e1.printStackTrace();}
	}
    
    AppLogger.logger.log(Level.FINEST, Thread.currentThread().getName() + 
      ": queried " + 1 + " EvaluatorAddress object in " + elapsedQueryTime + " ms");    
    return data;
  }
}
