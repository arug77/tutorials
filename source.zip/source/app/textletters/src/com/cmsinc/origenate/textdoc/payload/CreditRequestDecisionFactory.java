package com.cmsinc.origenate.textdoc.payload;

import java.util.Date;
import java.util.LinkedList;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import com.cmsinc.origenate.textdoc.AppLogger;
import com.cmsinc.origenate.textdoc.AppException;

/**
 * Simple factory class for creating instances of <code>CreditRequestDecision</code> 
 * by quering the database.<br>
 * 
 * Treat this class as "thread-safe" (though not typically not used by multiple threads).<br>
 * 
 * @since Origenate 6.0
 */
public class CreditRequestDecisionFactory {
  private static final String QUERY_SQL = 
	    "SELECT ce.APPROVED_AMOUNT_NUM, ce.APPROVED_RATE_NUM, ce.APPROVED_TERM_NUM, " + 
	    "       ce.APPROVED_PAYMENT_NUM, ce.RECEIVED_DT, ce.APPROVED_BUY_RATE_NUM, " +
	    "       ce.DECISIONED_BY_USER_ID, ce.PHONE_NUMBER_TXT, " +
		"substr(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(ce.COMMENTS_TXT,'|',''),CHR(1),' '),CHR(2),' '),CHR(3),' '),CHR(4),' '),CHR(5),' '),CHR(6),' '),CHR(7),' '),CHR(8),' '),CHR(9),' '),CHR(10),' '),CHR(11),' '),CHR(12),' '),CHR(13),' '),CHR(14),' '),CHR(15),' '),CHR(16),' '),CHR(17),' '),CHR(18),' '),CHR(19),' '),CHR(20),' '),CHR(21),' '),CHR(22),' '),CHR(23),' '),CHR(24),' '),CHR(25),' '),CHR(26),' '),CHR(27),' '),CHR(28),' '),CHR(29),' '),CHR(30),' '),CHR(31),' '),1,2000) as COMMENTS_TXT," +
	    "       ce.DECISION_ID, md.DECISION_TXT, ce.DECISION_REF_ID " +
	    "FROM CREDIT_REQ_DECISIONS_EVALUATOR ce, MSTR_EVALUATOR_DECISION md, CREDIT_REQUEST cr " +
	    "WHERE ce.REQUEST_ID = ? AND ce.request_id = cr.request_id and ce.EVALUATOR_ID = ? AND " +
	    "      ce.DECISION_ID = md.DECISION_ID and " +
		      "ce.decision_ref_id = "  +
			  "(select max(decision_ref_id) from credit_req_decisions_evaluator "+  
			  "where decision_id = "  +
			  "(select decision_status_id "+  
			  "from credit_request "  +
			  "where request_id = ?) " +
			  "and request_id = ?)  " +
	    "ORDER BY ce.RECEIVED_DT DESC";

  private Connection conn = null;
  
  public CreditRequestDecisionFactory(Connection aConnection) {
    this.conn = aConnection;
  }
  
  public CreditRequestDecision[] getDecisions(long aRequestId, long anEvaluatorId) throws AppException {
    LinkedList list = new LinkedList();
    PreparedStatement stmt = null;
    ResultSet rs = null;
    long elapsedQueryTime = 0;

    try {
      int idx = 1;
      long startQueryTime = (new Date()).getTime();
      stmt = this.conn.prepareStatement(QUERY_SQL);
      stmt.setLong(idx++, aRequestId);
      stmt.setLong(idx++, anEvaluatorId);
      stmt.setLong(idx++, aRequestId);
      stmt.setLong(idx++, aRequestId);
      rs = stmt.executeQuery();
      while (rs != null && rs.next()) {             
        long decisionId = rs.getLong("DECISION_ID");
        long decisionRefId = rs.getLong("DECISION_REF_ID");
        int term = rs.getInt("APPROVED_TERM_NUM");
        if (rs.wasNull()) 
          term = -1;
             
        CreditRequestDecision data = new CreditRequestDecision(decisionId, decisionRefId,
          rs.getBigDecimal("APPROVED_AMOUNT_NUM"), rs.getBigDecimal("APPROVED_RATE_NUM"),
          rs.getBigDecimal("APPROVED_PAYMENT_NUM"), term, rs.getDate("RECEIVED_DT"), 
          rs.getBigDecimal("APPROVED_BUY_RATE_NUM"), rs.getString("DECISIONED_BY_USER_ID"), 
          rs.getString("DECISION_TXT"), rs.getString("PHONE_NUMBER_TXT"), 
          rs.getString("COMMENTS_TXT"));
        list.add(data);
      }
      
      long endQueryTime = (new Date()).getTime();
      elapsedQueryTime = endQueryTime - startQueryTime;      
    }
    catch (SQLException ex) {
      throw new AppException("failed to query CREDIT_REQ_DECISIONS_EVALUATOR " +
        "for request ID=" + aRequestId + " and evaluator ID=" + anEvaluatorId, ex);
    }
    finally {
		try{ if(rs != null) rs.close(); }catch(Exception e1){e1.printStackTrace();}
		try{ if(stmt != null) stmt.close(); }catch(Exception e1){e1.printStackTrace();}
	}
    
    AppLogger.logger.log(Level.FINEST, Thread.currentThread().getName() + 
      ": queried " + list.size() + " CreditRequestDecision objects in " + elapsedQueryTime + " ms");
    
    CreditRequestDecision[] arrData = null;
    if (list.size() > 0)
      arrData = (CreditRequestDecision[]) list.toArray(new CreditRequestDecision[0]);
    return arrData;
  }
}
