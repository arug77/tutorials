
package com.cmsinc.origenate.textdoc.formatters;

import java.math.BigDecimal;
import java.text.DecimalFormat;
import com.cmsinc.origenate.textdoc.AppException;

/**
 * Formats an amount document field (<code>java.util.BigDecimal</code>, <code>java.util.Integer</code> or 
 * <code>java.util.Long</code>) as dollar sign, digits, comma(s) and a decimal point. If an integer type is
 * passed, no cents are included in the amount string.
 * 
 * @since Origenate 6.0
 */
public class AmountAsNumbersFormatter extends AmountFormatter implements FieldFormatter {
  
  private static final String DOLLARS_AND_CENTS_FORMAT = "$###,###,###,##0.00;($###,###,###,##0.00)";
  
  private static final String DOLLARS_ONLY_FORMAT = "$###,###,###,##0;($###,###,###,##0)";
  
  /** 
   * @see com.cmsinc.origenate.textdoc.formatters.FieldFormatter#format(java.lang.Object)
   */
  public String format(Object aValue) throws AppException {
    if (aValue == null)
      return "";
      
    boolean[] arrWantCentsReturnFlag = { false };
    BigDecimal decimal = toBigDecimal(aValue, arrWantCentsReturnFlag);
    
    boolean wantCents = arrWantCentsReturnFlag[0];
    DecimalFormat fmt = null;
    if (wantCents) {
      fmt = new DecimalFormat(DOLLARS_AND_CENTS_FORMAT);
      fmt.setDecimalSeparatorAlwaysShown(true);
      fmt.setMaximumFractionDigits(2);
    }
    else {
      fmt = new DecimalFormat(DOLLARS_ONLY_FORMAT);
      fmt.setDecimalSeparatorAlwaysShown(false);
      fmt.setMaximumFractionDigits(0);
    } 
    return fmt.format(decimal);
  }
}
