package com.cmsinc.origenate.textdoc.payload;

import java.util.Date;
import java.util.LinkedList;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import com.cmsinc.origenate.textdoc.AppLogger;
import com.cmsinc.origenate.textdoc.AppException;

/**
 * Simple factory class for creating instances of <code>TurndownReason</code>
 * by quering the database.<br>
 * 
 * Treat this class as "thread-safe" (though not typically not used by multiple
 * threads).<br>
 * 
 * @since Origenate 6.0
 */
public class TurndownReasonFactory {

	private Connection conn = null;

	public TurndownReasonFactory(Connection aConnection) {
		this.conn = aConnection;
	}

	public TurndownReason[] getTurndownReasons(long aRequestId,
			long anEvaluatorId, long decisionRefID,
			boolean showOnlyTurndownReasonsFlag) throws AppException {

		String QUERY_SQL = "SELECT cd.REASON_TYPE_ID, cd.REASON_ID, dr.DESCRIPTION_TXT, dr.REASON_TXT, "  
				+ "dr.BUREAU_RELATED_FLG, cd.OWNER_TXT " 
				+ "FROM CREDIT_REQ_DECISIONS_EVALUATOR cr, CREDIT_REQ_DECISION_REASONS cd, CONFIG_DECISION_REASONS dr "
				+ "WHERE cr.REQUEST_ID = ? AND cr.EVALUATOR_ID = ? AND "
				+ "      cr.DECISION_REF_ID = cd.DECISION_REF_ID AND "
				+ "      cd.REASON_TYPE_ID = dr.REASON_TYPE_ID AND "
				+ "      cd.REASON_ID = dr.REASON_ID AND "
				+ "      dr.EVALUATOR_ID = ? and cr.DECISION_REF_ID = ? ";
		if (showOnlyTurndownReasonsFlag) {
			QUERY_SQL = QUERY_SQL + "AND cd.REASON_TYPE_ID not in (2,3)";
		}
		QUERY_SQL = QUERY_SQL +  " order by cd.ORDER_PRECEDENCE_NUM ";
		LinkedList list = new LinkedList();
		PreparedStatement stmt = null;
		ResultSet rs = null;
		long elapsedQueryTime = 0;

		try {
			int idx = 1;
			long startQueryTime = (new Date()).getTime();
			stmt = this.conn.prepareStatement(QUERY_SQL);
			stmt.setLong(idx++, aRequestId);
			stmt.setLong(idx++, anEvaluatorId);
			stmt.setLong(idx++, anEvaluatorId);
			stmt.setLong(idx++, decisionRefID);
			rs = stmt.executeQuery();
			while (rs != null && rs.next()) {
				long reasonId = rs.getLong("REASON_ID");
				if (rs.wasNull())
					reasonId = -1;

				long reasonTypeId = rs.getLong("REASON_TYPE_ID");
				if (rs.wasNull())
					reasonTypeId = -1;

				TurndownReason data = new TurndownReason(reasonId,
						reasonTypeId, rs.getString("REASON_TXT"), rs
								.getString("DESCRIPTION_TXT"), rs
								.getString("OWNER_TXT"), (rs
								.getInt("BUREAU_RELATED_FLG") == 1 ? true
								: false));
				list.add(data);
			}

			long endQueryTime = (new Date()).getTime();
			elapsedQueryTime = endQueryTime - startQueryTime;
		} catch (SQLException ex) {
			throw new AppException(
					"failed to query CREDIT_REQ_DECISIONS_EVALUATOR / CREDIT_REQ_DECISION_REASONS "
							+ "for request ID=" + aRequestId
							+ " and evaluator ID=" + anEvaluatorId, ex);
		} 
		finally {
			try{ if(rs != null) rs.close(); }catch(Exception e1){e1.printStackTrace();}
			try{ if(stmt != null) stmt.close(); }catch(Exception e1){e1.printStackTrace();}
		}

		AppLogger.logger.log(Level.FINEST, Thread.currentThread().getName()
				+ ": queried " + list.size() + " TurndownReason objects in "
				+ elapsedQueryTime + " ms");

		TurndownReason[] arrData = null;
		if (list.size() > 0)
			arrData = (TurndownReason[]) list.toArray(new TurndownReason[0]);
		return arrData;
	}
}
