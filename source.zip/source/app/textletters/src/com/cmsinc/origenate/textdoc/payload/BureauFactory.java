package com.cmsinc.origenate.textdoc.payload;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import java.util.logging.Level;
import com.cmsinc.origenate.textdoc.AppLogger;
import com.cmsinc.origenate.textdoc.AppException;

/**
 * Simple factory class for creating instances of <code>Bureau</code> 
 * by quering the database.<br>
 * 
 * Treat this class as "thread-hostile".<br>
 * 
 * @since Origenate 6.0
 */
public class BureauFactory {

	private Connection conn = null;
  
  public BureauFactory(Connection aConnection) {
    this.conn = aConnection;
  }
  
  public Bureau getBureau(long aRequestId, long anEvaluatorId, long aRequestorId, boolean checkDefaultFlag) throws AppException {
	String QUERY_SQL = 
		    "SELECT * FROM (SELECT bh.BUREAU_OF_RECORD_FLG, bc.CONSUMER_REF_CODE_TXT, bc.ADDRESS1_TXT, " +
		    "       bc.ADDRESS2_TXT, bc.STATE_ID, bc.CITY_TXT, bc.PHONE_NUMBER_TXT, " +
		    "       bc.ZIPCODE_TXT, bc.NAME_TXT, bc.BUREAU_URL " +
		    "FROM REQUESTOR_BUREAU_HEADER bh, BUREAU_CONSUMER_REF_CODES bc " +
		    "WHERE bh.REQUEST_ID = ? AND bh.EVALUATOR_ID = ? AND bh.REQUESTOR_ID = ? AND " +
		    "      bh.BUREAU_ID = bc.BUREAU_ID AND " +
		    (checkDefaultFlag ? "bc.DEFAULT_FLG = 1 AND " : "") + 
		    "1=1 " +
		    "ORDER BY bh.BUREAU_OF_RECORD_FLG DESC) A " +
			"WHERE ROWNUM=1";
	Bureau data = null;
    PreparedStatement stmt = null;
    ResultSet rs = null;
    long elapsedQueryTime = 0;
    
    try {
      int idx = 1;
      long startQueryTime = (new Date()).getTime();
      stmt = this.conn.prepareStatement(QUERY_SQL);
      stmt.setLong(idx++, aRequestId);
      stmt.setLong(idx++, anEvaluatorId);
      stmt.setLong(idx++, aRequestorId);
      rs = stmt.executeQuery();
      if (rs != null && rs.next()) {  
        int bureauOfRecordFlag = rs.getInt("BUREAU_OF_RECORD_FLG"); 
        if (rs.wasNull())
          bureauOfRecordFlag = 0;
          
        data = new Bureau(rs.getString("NAME_TXT"), rs.getString("CONSUMER_REF_CODE_TXT"), 
          rs.getString("ADDRESS1_TXT"), rs.getString("ADDRESS2_TXT"), rs.getString("CITY_TXT"), 
          rs.getString("STATE_ID"), rs.getString("ZIPCODE_TXT"), rs.getString("PHONE_NUMBER_TXT"), 
          bureauOfRecordFlag != 0, rs.getString("BUREAU_URL"));
      }
      
      long endQueryTime = (new Date()).getTime();
      elapsedQueryTime = endQueryTime - startQueryTime;
    }
    catch (SQLException ex) {
      throw new AppException("failed to query REQUESTOR_BUREAU_HEADER " +
        "for request ID=" + aRequestId + ", evaluator ID=" + anEvaluatorId + 
        ", requestor ID=" + aRequestorId, ex);
    }
    finally {
		try{ if(rs != null) rs.close(); }catch(Exception e1){e1.printStackTrace();}
		try{ if(stmt != null) stmt.close(); }catch(Exception e1){e1.printStackTrace();}
	}
    
    AppLogger.logger.log(Level.FINEST, Thread.currentThread().getName() + 
      ": queried " + 1 + " Bureau object in " + elapsedQueryTime + " ms");
    return data;
  }
  
  public Bureau[] getAllBureaus(long aRequestId, long anEvaluatorId, long aRequestorId, boolean checkDefaultFlag) throws AppException {
  
		/*
	       * ======================================================================
	       * Changed logic on 3/9/2012 - dhavalt 
	       * CL157463 - TU AND XPN NO LONGER USE A CONSUMER REF CODE TO DETERMINE WHICH BUREAU DATA TO USE IN THE LETTER. EFX STILL DOES. 
		   * THE TEXT LETTER FILE WILL NOT PERFORM A LOOK-UP USING THE CONSUMER REF CODE REGARDLESS OF BUREAU. WE WILL EITHER USE THE DEFAULT RECORD OR THE FIRST RECORD.
		   *
		   * SO CHANGED LOGIC:
		   *	Instead keeping condition of default_flg=1, I select all consumer ref codes for that bureau by ordering BUREAU_OF_RECORD_FLG,DEFAULT_FLG
		   *	so, if default_flg=1 will be first record, if we have that for bureau
		   *	and while copying data to bureau object, I added condition to check prevBureauID.. purpose is simple.. don't add same bureau information more than once.
	       * ======================================================================
	       */
		   
		 /*
	       * ======================================================================
	       * Changed logic on 5/31/2012 - dhavalt 
	       * CL159346 - SHOW ONLY THAT BUREAU DATA WHICH IS CALLED INSTEAD SHOWING ALL, SO IF ONLY 2 BUREAUS ARE CALLED FOR APPLICANT, THEN THIRD BUREAU INFORMATION WILL BE NULL ON TEXTLETTER
		   *
	       * ======================================================================
	     */
		   
		String QUERY_SQL = 
			    "SELECT * FROM (SELECT bh.BUREAU_ID, bh.BUREAU_OF_RECORD_FLG, bc.CONSUMER_REF_CODE_TXT, bc.ADDRESS1_TXT, " +
				"       bc.ADDRESS2_TXT, bc.STATE_ID, bc.CITY_TXT, bc.PHONE_NUMBER_TXT, " +
				"       bc.ZIPCODE_TXT, bc.NAME_TXT, bc.BUREAU_URL " +
				"FROM REQUESTOR_BUREAU_HEADER bh, BUREAU_CONSUMER_REF_CODES bc " +
				"WHERE bh.REQUEST_ID = ? AND bh.EVALUATOR_ID = ? AND bh.REQUESTOR_ID = ? AND " +
				"      bh.BUREAU_ID = bc.BUREAU_ID AND " +
				(checkDefaultFlag ? "bc.DEFAULT_FLG = 1 AND " : "") + 
				"1=1 " +
				"ORDER BY bh.BUREAU_OF_RECORD_FLG DESC) A ";
		Bureau[] bureaus;
		Bureau data = null;
	    PreparedStatement stmt = null;
	    ResultSet rs = null;
	    long elapsedQueryTime = 0;
	    int prevBureauID = 0;
	    try {
		  
	      int idx = 1;
	      long startQueryTime = (new Date()).getTime();
	      stmt = this.conn.prepareStatement(QUERY_SQL);
	      stmt.setLong(idx++, aRequestId);
	      stmt.setLong(idx++, anEvaluatorId);
	      stmt.setLong(idx++, aRequestorId);
	      rs = stmt.executeQuery();
	      int i = 0;
	      while (rs != null && rs.next()) { 
			  //Checking if we have same bureau_id as previous then don't include new row.
			  if(prevBureauID == rs.getInt("BUREAU_ID"))
				continue;
	    	  i++;
			  prevBureauID = rs.getInt("BUREAU_ID");
	      }
	      
	      /*
	       * ======================================================================
	       * Ensure statement and result set are closed before re-use (PotSoft, 
	       * out-of-cursors fix(?), 10/11/06
	       * ======================================================================
	       */
	      rs.close();
	      stmt.close();

	      bureaus = new Bureau[i];
	      stmt = this.conn.prepareStatement(QUERY_SQL);
	      idx = 1;
	      stmt.setLong(idx++, aRequestId);
	      stmt.setLong(idx++, anEvaluatorId);
	      stmt.setLong(idx++, aRequestorId);
	      rs = stmt.executeQuery();
	      i=0;
		  prevBureauID=0;
		  
	      while (rs != null && rs.next()) {  
		  
			//Checking if we have same bureau_id as previous then don't include new row.
			if(prevBureauID == rs.getInt("BUREAU_ID"))
				continue;
			
			prevBureauID = rs.getInt("BUREAU_ID");
			
	        int bureauOfRecordFlag = rs.getInt("BUREAU_OF_RECORD_FLG"); 
	        if (rs.wasNull())
	          bureauOfRecordFlag = 0;
	          
	        data = new Bureau(rs.getString("NAME_TXT"), rs.getString("CONSUMER_REF_CODE_TXT"), 
	          rs.getString("ADDRESS1_TXT"), rs.getString("ADDRESS2_TXT"), rs.getString("CITY_TXT"), 
	          rs.getString("STATE_ID"), rs.getString("ZIPCODE_TXT"), rs.getString("PHONE_NUMBER_TXT"), 
	          bureauOfRecordFlag != 0, rs.getString("BUREAU_URL"));
	        bureaus[i] = data;
	        i++;
	      }
	      long endQueryTime = (new Date()).getTime();
	      elapsedQueryTime = endQueryTime - startQueryTime;
	    }
	    catch (SQLException ex) {
	      throw new AppException("failed to query REQUESTOR_BUREAU_HEADER " +
	        "for request ID=" + aRequestId + ", evaluator ID=" + anEvaluatorId + 
	        ", requestor ID=" + aRequestorId, ex);
	    }
	    finally {
			try{ if(rs != null) rs.close(); }catch(Exception e1){e1.printStackTrace();}
			try{ if(stmt != null) stmt.close(); }catch(Exception e1){e1.printStackTrace();}
		}
	    
	    AppLogger.logger.log(Level.FINEST, Thread.currentThread().getName() + 
	      ": queried " + 1 + " Bureau object in " + elapsedQueryTime + " ms");
	    return bureaus;
	  }
}
