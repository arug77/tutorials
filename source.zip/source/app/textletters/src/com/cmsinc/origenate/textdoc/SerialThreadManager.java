package com.cmsinc.origenate.textdoc;

import java.util.logging.Level;

/**
 * Manages threads in a serial fashion, i.e., runs each thread singly, one
 * after the other. If a thread throws an exception, processing stops.<br>
 * 
 * Treat this class itself as "thread-hostile" (it should be called from
 * the main thread).
 * 
 * @since Origenate 6.0
 */
public class SerialThreadManager extends ThreadManager {
  
  private int initialNap = -1;
  //private int joinWaitMillis = -1;
  
  SerialThreadManager(ThreadGroup aThreadGroup, Thread[] someThreads, int anInitialNap) {
    super(aThreadGroup, someThreads);
    this.initialNap = anInitialNap;
  }
  
  void run() {
    if (super.threads == null || super.threads.length == 0)
      return;
    AppLogger.logger.log(Level.INFO, "executing " + super.threads.length + " threads in serial fashion (one after the other) ...");
    
    for (int i=0;super.threads != null && i < super.threads.length;i++) {
      boolean wasInterrupted = false;
      Thread thread = super.threads[i];
      thread.start();

      try { Thread.sleep(this.initialNap * 1000); } 
        catch (InterruptedException ex) { wasInterrupted = true; }
      if (wasInterrupted) {
        AppLogger.logger.log(Level.INFO, "main thread interrupted, terminating...");
        break;
      }
      
      try { thread.join(); } catch (InterruptedException ex) { wasInterrupted = true; }
      if (wasInterrupted) {
        AppLogger.logger.log(Level.INFO, "main thread interrupted, terminating...");
        break;
      }
    }
  }
}
