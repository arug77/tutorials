/******************************************************************************
 Company: First American CMSI
 Product: Origenate
 Author: Potomac Software, Inc.
 Copyright (c) 2005. All rights reserved.

 Description: Batch application that runs daily to produce flat file containing
 parameters needed for ASP customers to produce their own declined, counter-offer,
 expired, General Notifcation and welcome letters.
******************************************************************************/

package com.cmsinc.origenate.textdoc;

import java.sql.Connection;
import java.text.SimpleDateFormat;
import java.util.LinkedList;
import java.util.StringTokenizer;
import java.util.logging.Level;
import java.io.File;
import java.io.PrintWriter;

import com.cmsinc.origenate.textdoc.letters.LetterFactory;
import com.cmsinc.origenate.textdoc.letters.DeclinedLetterFactory;
import com.cmsinc.origenate.textdoc.letters.CounterOfferLetterFactory;
import com.cmsinc.origenate.textdoc.letters.WelcomeLetterFactory;
import com.cmsinc.origenate.textdoc.letters.ExpiredLetterFactory;
import com.cmsinc.origenate.textdoc.letters.GenNotificationLetterFactory;
import com.cmsinc.origenate.textdoc.letters.WithdrawLetterFactory;
import com.cmsinc.origenate.textdoc.letters.ClosingLetterFactory;
import com.cmsinc.origenate.textdoc.letters.FirstPaymentLetterFactory;
import com.cmsinc.origenate.textdoc.letters.RiskBasedPricingLetterFactory;
import com.cmsinc.origenate.textdoc.letters.MissingInfoLetterFactory;
import com.cmsinc.origenate.textdoc.letters.EarlyDisclosureLetterFactory;
import com.cmsinc.origenate.textdoc.letters.InitialLetterFactory;
import com.cmsinc.origenate.textdoc.letters.Followup1LetterFactory;
import com.cmsinc.origenate.textdoc.letters.Followup2LetterFactory;
import com.cmsinc.origenate.workflow.ApplicationIDs;
import com.cmsinc.origenate.util.OWASPSecurity;

public class TextdocApp {

  public static final int DECISION_APPROVED = ApplicationIDs.dec_approve;
  public static final int DECISION_APPROVED_CONDITIONALLY = ApplicationIDs.dec_appcond;
  public static final int DECISION_APPROVED_BY_SCORE = ApplicationIDs.dec_appscor;

  public static final int DECISION_DECLINED = ApplicationIDs.dec_decline;
  public static final int DECISION_DECLINED_BY_SCORE = ApplicationIDs.dec_decscor;

  private static final int DEFAULT_INITIAL_NAP = 15;

  private static final int DEFAULT_PULSE_CHECK_NAP = 5;

  private static final int DEFAULT_JOIN_WAIT_MILLIS = 100;

  private static long[] evaluatorIds = null;

  private static String outputDir = null;

  private static String queryId = null;

  private static String configPath = null;

  private ConfigInfo configInfo = null;

  //If this flag is set to true, only the rows in
  //BUREAU_CONSUMER_REF_CODE with DEFAULT_FLG = 1 will be checked.
  private static boolean checkDefaultBureauFlag = false;

  //If this flag is set to true, the turndown descriptions will be
  //used in the extract instead of the turndown text
  private static boolean useTurndownDescriptionFlag = false;

  //This parameter now does nothing
  private static boolean showAllBureausFlag = false;

  //If set, only turndown reasons will be shown, not withdraw or override
  private static boolean showOnlyTurndownReasonsFlag = false;

  public static boolean failedToGen = false;
  
  //This parameter if set will not populate the SSN column; blank value is shown.
  private static boolean hideSSNFlag = false;
  
  public static void main(String[] args) {
    Thread.currentThread().setName("mainThread");

    String usageError = getArguments(args);
    if (usageError != null)
      usage(usageError);

    int exitStatus = 0;
    TextdocApp app = null;
    try {
      ConfigInfo configInfo = ConfigInfo.getInstance(TextdocApp.configPath);
      AppLogger.bootstrap(configInfo);
      AppLogger.logger.log(Level.INFO, Thread.currentThread().getName() +
        ": ==================== APPLICATION STARTED ====================");

      app = new TextdocApp(configInfo);
      app.go();
    }
    catch (AppException ex) {
      String errorText = "application encountered an error";
      if (AppLogger.logger != null)
        AppLogger.logger.log(Level.SEVERE, errorText, ex);
      System.err.println(errorText + ": " + ex);
      exitStatus = 1;
    }
    finally {
    }

    AppLogger.logger.log(Level.INFO, Thread.currentThread().getName() +
      ": ========== APPLICATION FINISHED (exit status = " + exitStatus + ") ==========");
    System.exit(exitStatus);
  }

  private TextdocApp(ConfigInfo aConfigInfo) throws AppException {
    this.configInfo = aConfigInfo;
  }

  private void go() throws AppException {
    AppLogger.logger.entering(getClass().getName(), "go", Thread.currentThread().getName());

    ConnectionFactory connFactory = ConnectionFactory.getInstance(this.configInfo);
    ThreadGroup threadGroup = new ThreadGroup("worker");

    // Create a worker thread for each letter category. Each thread is given it's
    // own connection to the database (which the thread then manages and closes).

    Connection conn = connFactory.getUnboundConnection();
    LetterFactory letterFactory = new DeclinedLetterFactory(conn, TextdocApp.evaluatorIds);
    TextdocThread threadDeclined = new TextdocThread(threadGroup, conn, letterFactory,
      OutputFileFactory.DECLINED, new long[] { DECISION_DECLINED, DECISION_DECLINED_BY_SCORE },
      TextdocApp.evaluatorIds, TextdocApp.outputDir, this.configInfo, checkDefaultBureauFlag, useTurndownDescriptionFlag, showAllBureausFlag, showOnlyTurndownReasonsFlag, hideSSNFlag);

    conn = connFactory.getUnboundConnection();
    letterFactory = new CounterOfferLetterFactory(conn, TextdocApp.evaluatorIds);
    TextdocThread threadCounterOffer = new TextdocThread(threadGroup, conn, letterFactory,
      OutputFileFactory.COUNTER_OFFER, null, TextdocApp.evaluatorIds, TextdocApp.outputDir, this.configInfo, checkDefaultBureauFlag, useTurndownDescriptionFlag, showAllBureausFlag, showOnlyTurndownReasonsFlag, hideSSNFlag);

    conn = connFactory.getUnboundConnection();
    letterFactory = new WelcomeLetterFactory(conn, TextdocApp.evaluatorIds);
    TextdocThread threadWelcome = new TextdocThread(threadGroup, conn, letterFactory,
      OutputFileFactory.WELCOME, new long[] { DECISION_APPROVED, DECISION_APPROVED_CONDITIONALLY, DECISION_APPROVED_BY_SCORE },
      TextdocApp.evaluatorIds, TextdocApp.outputDir, this.configInfo, checkDefaultBureauFlag, useTurndownDescriptionFlag, showAllBureausFlag, showOnlyTurndownReasonsFlag, hideSSNFlag);

	conn = connFactory.getUnboundConnection();
	letterFactory = new ExpiredLetterFactory(conn, TextdocApp.evaluatorIds);
	TextdocThread threadExpired = new TextdocThread(threadGroup, conn, letterFactory,
	  OutputFileFactory.EXPIRED,null, TextdocApp.evaluatorIds, TextdocApp.outputDir, this.configInfo, checkDefaultBureauFlag, useTurndownDescriptionFlag, showAllBureausFlag, showOnlyTurndownReasonsFlag, hideSSNFlag);

	conn = connFactory.getUnboundConnection();
	letterFactory = new GenNotificationLetterFactory(conn, TextdocApp.evaluatorIds, TextdocApp.queryId);
	TextdocThread threadGenNotification = new TextdocThread(threadGroup, conn, letterFactory,
	  OutputFileFactory.GEN_NOTIFICATION,null, TextdocApp.evaluatorIds, TextdocApp.outputDir, this.configInfo, checkDefaultBureauFlag, useTurndownDescriptionFlag, showAllBureausFlag, showOnlyTurndownReasonsFlag, hideSSNFlag);

	/* This Modules specifications is not Defined yet, It will be added in future release. CL 155406- Product Input
	conn = connFactory.getUnboundConnection();
	letterFactory = new WithdrawLetterFactory(conn, TextdocApp.evaluatorIds);
	TextdocThread threadWithdraw = new TextdocThread(threadGroup, conn, letterFactory,
	  OutputFileFactory.WITHDRAW,null, TextdocApp.evaluatorIds, TextdocApp.outputDir, this.configInfo, checkDefaultBureauFlag, useTurndownDescriptionFlag, showAllBureausFlag, showOnlyTurndownReasonsFlag);
	  
	conn = connFactory.getUnboundConnection();
	letterFactory = new ClosingLetterFactory(conn, TextdocApp.evaluatorIds);
	TextdocThread threadClosing = new TextdocThread(threadGroup, conn, letterFactory,
	  OutputFileFactory.CLOSING,null, TextdocApp.evaluatorIds, TextdocApp.outputDir, this.configInfo, checkDefaultBureauFlag, useTurndownDescriptionFlag, showAllBureausFlag, showOnlyTurndownReasonsFlag);
	  
	conn = connFactory.getUnboundConnection();
	letterFactory = new FirstPaymentLetterFactory(conn, TextdocApp.evaluatorIds);
	TextdocThread threadFstpymt = new TextdocThread(threadGroup, conn, letterFactory,
	  OutputFileFactory.FIRST_PAYMENT,null, TextdocApp.evaluatorIds, TextdocApp.outputDir, this.configInfo, checkDefaultBureauFlag, useTurndownDescriptionFlag, showAllBureausFlag, showOnlyTurndownReasonsFlag);
	  
	conn = connFactory.getUnboundConnection();
	letterFactory = new RiskBasedPricingLetterFactory(conn, TextdocApp.evaluatorIds);
	TextdocThread threadRiskPricing = new TextdocThread(threadGroup, conn, letterFactory,
	  OutputFileFactory.RISK_BASED_PRICING,null, TextdocApp.evaluatorIds, TextdocApp.outputDir, this.configInfo, checkDefaultBureauFlag, useTurndownDescriptionFlag, showAllBureausFlag, showOnlyTurndownReasonsFlag);
	  
	conn = connFactory.getUnboundConnection();
	letterFactory = new MissingInfoLetterFactory(conn, TextdocApp.evaluatorIds);
	TextdocThread threadMissingInfo = new TextdocThread(threadGroup, conn, letterFactory,
	  OutputFileFactory.MISSING_INFO,null, TextdocApp.evaluatorIds, TextdocApp.outputDir, this.configInfo, checkDefaultBureauFlag, useTurndownDescriptionFlag, showAllBureausFlag, showOnlyTurndownReasonsFlag);
	  
	conn = connFactory.getUnboundConnection();
	letterFactory = new EarlyDisclosureLetterFactory(conn, TextdocApp.evaluatorIds);
	TextdocThread threadEarlyDisc = new TextdocThread(threadGroup, conn, letterFactory,
	  OutputFileFactory.EARLY_DISCLOSURE_DOCUMENT,null, TextdocApp.evaluatorIds, TextdocApp.outputDir, this.configInfo, checkDefaultBureauFlag, useTurndownDescriptionFlag, showAllBureausFlag, showOnlyTurndownReasonsFlag);
	  
	conn = connFactory.getUnboundConnection();
	letterFactory = new InitialLetterFactory(conn, TextdocApp.evaluatorIds);
	TextdocThread threadInitial = new TextdocThread(threadGroup, conn, letterFactory,
	  OutputFileFactory.INITIAL,null, TextdocApp.evaluatorIds, TextdocApp.outputDir, this.configInfo, checkDefaultBureauFlag, useTurndownDescriptionFlag, showAllBureausFlag, showOnlyTurndownReasonsFlag);
	  
	conn = connFactory.getUnboundConnection();
	letterFactory = new Followup1LetterFactory(conn, TextdocApp.evaluatorIds);
	TextdocThread threadFollowup1 = new TextdocThread(threadGroup, conn, letterFactory,
	  OutputFileFactory.FOLLOW_UP_1,null, TextdocApp.evaluatorIds, TextdocApp.outputDir, this.configInfo, checkDefaultBureauFlag, useTurndownDescriptionFlag, showAllBureausFlag, showOnlyTurndownReasonsFlag);
	  
	conn = connFactory.getUnboundConnection();
	letterFactory = new Followup2LetterFactory(conn, TextdocApp.evaluatorIds);
	TextdocThread threadFollowup2 = new TextdocThread(threadGroup, conn, letterFactory,
	  OutputFileFactory.FOLLOW_UP_2,null, TextdocApp.evaluatorIds, TextdocApp.outputDir, this.configInfo, checkDefaultBureauFlag, useTurndownDescriptionFlag, showAllBureausFlag, showOnlyTurndownReasonsFlag);
	 */ 

    // Get various timing parameters from configuration, using appropriate
    // defaults if not configured.

    int initialNap = this.configInfo.getInitialNap() < 0 ?
      DEFAULT_INITIAL_NAP : this.configInfo.getInitialNap();
    int pulseCheckNap = this.configInfo.getPulseCheckNap() < 0 ?
      DEFAULT_PULSE_CHECK_NAP : this.configInfo.getPulseCheckNap();
    int joinWaitMillis = this.configInfo.getWorkerThreadJoinWaitMillis() < 0 ?
      DEFAULT_JOIN_WAIT_MILLIS : this.configInfo.getWorkerThreadJoinWaitMillis();

    // Hand dormant worker threads off to single or multi-threaded thread manager,
    // and let the manager execute the threads. When the thread manager returns,
    // the worker threads are done.

    ThreadManager threadMgr = null;
    Thread[] workerThreads = { threadDeclined, threadCounterOffer, threadWelcome, threadExpired, threadGenNotification};//,  threadWithdraw, threadClosing, threadFstpymt, threadRiskPricing , threadMissingInfo, threadEarlyDisc, threadInitial, threadFollowup1, threadFollowup2 };

    if (this.configInfo.isMultiThreaded()) {
      threadMgr = new ParallelThreadManager(threadGroup, workerThreads,
        initialNap, pulseCheckNap, joinWaitMillis);
    }
    else {
      threadMgr = new SerialThreadManager(threadGroup, workerThreads, initialNap);
    }
    threadMgr.run();
    
    // Flush data to all open extract files, then close each file.
    OutputFileFactory outputFileFactory = OutputFileFactory.getInstance(TextdocApp.outputDir);
    File[] extractFiles = outputFileFactory.closeAllFiles();
    for (int i=0;extractFiles != null && i < extractFiles.length;i++){
      AppLogger.logger.log(Level.INFO, "created extract file '" + extractFiles[i].getName() + "'");
	    try{
	    	generateTextdocReady(TextdocApp.outputDir,extractFiles[i].getName());//generate .ready for each extract file
	    }
	    catch (Exception e){
			AppLogger.logger.log(Level.SEVERE,"Exception in TextdocThread.java generateTextdocReady : " +e.toString());
	    }
    }
        
    if(extractFiles != null && extractFiles.length >= workerThreads.length && !failedToGen ){
        AppLogger.logger.log(Level.INFO, "generating .ready file for job complete");
	    try{
	    	generateTextdocReadyAll(TextdocApp.outputDir,TextdocApp.evaluatorIds);
	    }
	    catch (Exception e){
			AppLogger.logger.log(Level.SEVERE,"Exception in TextdocThread.java generateTextdocReadyAll : " +e.toString());
	    }
    }
    else
    	AppLogger.logger.log(Level.INFO, "Errors exist: .ready file not generated for Textletters job");
    
    
    AppLogger.logger.exiting(getClass().getName(), "go", Thread.currentThread().getName());
  }

  private static String getArguments(String[] anArrayOfArgs) {
    int idxArg = 0;
    String errorMessage = null;

    // Get options (these start with a hyphen).

    for (;errorMessage == null && idxArg < anArrayOfArgs.length;idxArg++) {
      if (anArrayOfArgs[idxArg].charAt(0) == '-') {
        if (anArrayOfArgs[idxArg].equalsIgnoreCase("-evaluators")) {
          if (idxArg + 1 == anArrayOfArgs.length)
            errorMessage = "-evaluators must be followed by comma-separated list of evaluator IDs";
          else {
            String[] strEvaluatorIds = delimitedListToArray(anArrayOfArgs[++idxArg], ",");
            if (strEvaluatorIds != null && strEvaluatorIds.length > 0) {
              TextdocApp.evaluatorIds = new long[strEvaluatorIds.length];
              for (int i=0;i < strEvaluatorIds.length;i++) {
                try {
                  TextdocApp.evaluatorIds[i] = Integer.parseInt(strEvaluatorIds[i]);
                }
                catch (NumberFormatException ex) {
                  errorMessage = "non-numeric evaluator ID '" + strEvaluatorIds[i] + "', exception = " + ex;
                  break;
                }
              }
            }
          }
          continue;
        }

        if (anArrayOfArgs[idxArg].equalsIgnoreCase("-outputDir")) {
          if (idxArg + 1 == anArrayOfArgs.length)
            errorMessage = "-outputDir must be followed by path to output directory";
          else {
            TextdocApp.outputDir = anArrayOfArgs[++idxArg];
            
            /**  
            * OWASP TOP 10 2010 - A4 Path Manipulation
            * Changes to the below code to fix vulnerabilities
            * TTP 324955
            */
            //File fileOutputDir = new File(TextdocApp.outputDir);
            File fileOutputDir=null;
            try
            {
            fileOutputDir = new File(OWASPSecurity.validationCheck(TextdocApp.outputDir, OWASPSecurity.DIRANDFILE));
            }
            catch(Exception e)
            {
              e.printStackTrace();
            }
            if (!(fileOutputDir.exists() && fileOutputDir.canWrite()))
              errorMessage = "output directory '" + TextdocApp.outputDir + "' does not exist or is not writeable";
          }
          continue;
        }

		if (anArrayOfArgs[idxArg].equalsIgnoreCase("-queryId")) 
		  {
			  if (idxArg + 1 == anArrayOfArgs.length)
				  errorMessage = "-queryId must be followed by a queryId from the CONFIG_DOC_QUERIES table";
			  else 
			  {
				  TextdocApp.queryId = anArrayOfArgs[++idxArg];
			  }
			  continue;
		  }

        if (anArrayOfArgs[idxArg].equalsIgnoreCase("-checkDefaultBureauFlag")) {
        	checkDefaultBureauFlag = true;
        	continue;
        }

        if (anArrayOfArgs[idxArg].equalsIgnoreCase("-useTurndownDescriptionFlag")) {
        	useTurndownDescriptionFlag = true;
        	continue;
        }

        if (anArrayOfArgs[idxArg].equalsIgnoreCase("-showAllBureausFlag")) {
        	//this parameter now does nothing
        	showAllBureausFlag = true;
        	continue;
        }

        if (anArrayOfArgs[idxArg].equalsIgnoreCase("-showOnlyTurndownReasonsFlag")) {
        	showOnlyTurndownReasonsFlag = true;
        	continue;
        }
		
		if (anArrayOfArgs[idxArg].equalsIgnoreCase("-hideSSNFlag")) {
        	hideSSNFlag = true;
        	continue;
        }

        errorMessage = "unknown option '" + anArrayOfArgs[idxArg] + "'";
      }
      else
        break;
    }

    if (errorMessage != null)
      return errorMessage;

    // Get last argument, which must be the path to origenate.ini file.

    if (idxArg < anArrayOfArgs.length)
      TextdocApp.configPath = anArrayOfArgs[idxArg];
    else {
      errorMessage = "final argument must be path to 'origenate.ini'";
      return errorMessage;
    }

    // Check that required arguments have been passed.

    if (TextdocApp.outputDir == null)
      errorMessage = "'-outputDir' is a required argument";
    else if (configPath == null)
      errorMessage = "path to 'origenate.ini' is a required argument";
    return errorMessage;
  }

  public static String[] delimitedListToArray(String aList, String aDelim) {
    LinkedList list = new LinkedList();
    StringTokenizer tkz = new StringTokenizer(aList, aDelim);
    while (tkz.hasMoreTokens())
       list.add(tkz.nextToken().trim());

    String[] array = new String[0];
    if (list.size() > 0)
      array = (String[]) list.toArray(array);
    return array;
  }

  private static void usage(String anErrorMessage) {
    String newline = System.getProperty("line.separator", "\n");
    anErrorMessage = anErrorMessage == null ? "bad calling syntax" : anErrorMessage;
    System.err.println("ERROR! " + anErrorMessage);
    System.err.println("Usage: java -classpath <origenate-classpath> " + newline +
      "\t com.cmsinc.origenate.TextdocApp [-evaluators list-of-eval-IDs] " + newline +
      "\t -outputDir <path-to-output-dir> <path-to-config-file>");
    System.exit(1);
  }
  private void generateTextdocReadyAll(String outputDirectory,long[] evaluatorIds) throws Exception {
	  java.util.Date curDate = new java.util.Date(System.currentTimeMillis());
	  SimpleDateFormat timeFormatter= new SimpleDateFormat ("HHmmss");
      SimpleDateFormat dateFormatter= new SimpleDateFormat ("yyyy-MM-dd");
      String standardFileEnd = dateFormatter.format(curDate)+"."+timeFormatter.format(curDate)+".ready";
		try{
			for(long eval_id: evaluatorIds){
				//appending .ready to filename
				String filename = eval_id + "_" + standardFileEnd;
				
				/**  
				* OWASP TOP 10 2010 - A4 Path Manipulation
				* Changes to the below code to fix vulnerabilities
        * TTP 324955
				*/
				//File file = new File(outputDirectory, filename);
				File file = new File(OWASPSecurity.validationCheck(outputDirectory, OWASPSecurity.DIRANDFILE), OWASPSecurity.validationCheck(filename, OWASPSecurity.FILENAME));
				
				PrintWriter outFile = null;
				outFile = new PrintWriter(file);
				outFile.close();
				}
		}
		catch (Exception e){
			AppLogger.logger.log(Level.SEVERE,"Exception in TextdocThread.java generateTextdocReadyAll (generating .ready for job complete) : " +e.toString());
		}
  }
  
  private void generateTextdocReady(String outputDirectory,String filename) throws Exception {
		try{
			filename += ".ready";
			
			/**  
			* OWASP TOP 10 2010 - A4 Path Manipulation
			* Changes to the below code to fix vulnerabilities
      * TTP 324955
			*/
			//File file = new File(outputDirectory, filename);
			File file = new File(OWASPSecurity.validationCheck(outputDirectory, OWASPSecurity.DIRANDFILE), OWASPSecurity.validationCheck(filename, OWASPSecurity.FILENAME));
			
			PrintWriter outFile = null;
			outFile = new PrintWriter(file);
			outFile.close();
		}
		catch (Exception e){
			AppLogger.logger.log(Level.SEVERE,"Exception in TextdocThread.java generateTextdocReady (generating .ready file for single textletter) : " +e.toString());
		}
  }

  public static void failedToGenerateTextDoc()
  {
	  failedToGen = true;
  }
  
}
