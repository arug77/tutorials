package com.cmsinc.origenate.textdoc.letters;

import java.sql.Connection;

/**
 * Factory for selecting credit apps and creating <code>MissingInfoLetter</code> instances.<br>
 * 
 * Treat this class as "thread-hostile".
 * 
 * @since Origenate 8.5
 */
public class MissingInfoLetterFactory extends LetterFactory 
{

	/**
	 * To select Expired apps: 
	 * 
	 * The application must have a an app status of 20 (expired).
	 * similar to Nightly Letters, we exclude apps older than 90
	 * days to reduce the result set.
	 */  
	private static final String MISSING_INFO_SELECT_LIST = 
	"cps.turndown_delay_days_num delay_days, '' '' as printer_text";
	
	private static final String MISSING_INFO_WHERE_CLAUSE =     
	"cr.APP_STATUS_ID in (1,6) "
					+ "and  trunc(sysdate, ''dd'') - trunc(cr.INITIATION_DT, ''dd'')<=60 "
					+ "and (trunc(sysdate, ''dd'') - trunc(cr.CURRENT_STATUS_DT, ''dd''))>=cps.MISSING_INFO_DELAY_NUM";
    
	public static final String LETTER_CATEGORY = "MISSING_INFO";
   
	protected String getLetterCategory() 
	{
		return LETTER_CATEGORY;
	}
  
	/**
	 * Restricted ctor for creating an instance of this class.
	 *  
	 * @param someEvaluatorIds
	 *  evaluators to search by, or null to search regardless of evaluator.
	 */
	public MissingInfoLetterFactory(Connection aConnection, long[] someEvaluatorIds) 
	{
		super(aConnection, LETTER_CATEGORY, someEvaluatorIds);
	}
  
	protected StringBuffer selectList() 
	{
		StringBuffer buf = super.selectList();
		buf = appendCharIfNeeded(buf, ',');
		buf.append(MISSING_INFO_SELECT_LIST);
		return buf;
	}
  
	protected StringBuffer fromClause() 
	{
		StringBuffer buf = super.fromClause();		
		return buf;
	}  
  
	protected StringBuffer whereClause() 
	{
		StringBuffer buf = super.whereClause();
		buf = appendWordIfNeeded(buf, "AND");
		buf.append(MISSING_INFO_WHERE_CLAUSE);
		return buf;
	}  
}
