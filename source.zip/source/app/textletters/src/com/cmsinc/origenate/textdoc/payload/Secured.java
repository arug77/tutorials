package com.cmsinc.origenate.textdoc.payload;

/**
 * Data about loan security (i.e., collateral).<br>
 * 
 * Treat this class as "thread-safe", since it is immutable once created.
 * 
 * @since Origenate 6.0
 */
public class Secured {
  
  private String code = null;
  private String codeDesc = null; 
  
  public Secured(String aSecuredCode, String aCodeDesc) {
    this.code = aSecuredCode;
    this.codeDesc = aCodeDesc;
  }
  
  public String getCode() {
    return this.code;
  }
  
  public String getCodeDesc() {
    return this.codeDesc;
  }
}
