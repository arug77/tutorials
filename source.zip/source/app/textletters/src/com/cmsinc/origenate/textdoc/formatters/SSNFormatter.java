package com.cmsinc.origenate.textdoc.formatters;

import com.cmsinc.origenate.textdoc.AppException;

/**
 * Formats an SSN.
 * 
 * @since Origenate 6.0
 */
public class SSNFormatter extends MaskFormatter implements FieldFormatter {
 
  private static final String SSN_MASK = "???-??-????";
  
  /** 
   * @see com.cmsinc.origenate.textdoc.formatters.FieldFormatter#format(java.lang.Object)
   */
  public String format(Object aValue) throws AppException {
    if (aValue == null)
      return "";
      
    String ssn = aValue.toString().trim();
    String formattedSSN = ssn;
    if (ssn.length() == 9) 
      formattedSSN = applyDisplayMask(SSN_MASK, ' ', ssn);
    return formattedSSN;
  }
}
