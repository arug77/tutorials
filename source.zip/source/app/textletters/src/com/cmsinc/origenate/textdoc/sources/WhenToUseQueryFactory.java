package com.cmsinc.origenate.textdoc.sources;

import java.util.List;
import java.util.LinkedList;
import java.util.Map;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Collections;
import java.util.logging.Level;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import com.cmsinc.origenate.textdoc.AppException;
import com.cmsinc.origenate.textdoc.AppLogger;

/**
 * Factory class for obtaining SQL and parameters for a dynamic, when-to-use query.<br>
 * 
 * Treat this class as thread-safe; it must be, since it is a singleton.
 * 
 * @since Origenate 6.0
 */
public class WhenToUseQueryFactory {
  /**
   * Inner class that stores key information about a dynamic query.
   */
  public static class QueryInfo {
    private long queryId = -1;
    private String querySQL = null;
    private List listQueryParams = null;
    
    QueryInfo(long aQueryId, String aQuerySQL, List aQueryParamsList) {
      this.queryId = aQueryId;
      this.querySQL = aQuerySQL;
      this.listQueryParams = aQueryParamsList;
    }
    
    public long getQueryId() {
      return this.queryId;
    }
    
    public String getSQL() {
      return this.querySQL;
    }
    
    public Map getQueryParams(long aRequestId, Map aRuntimeParamMap) throws AppException {
      HashMap map = new HashMap();
      for (Iterator iter=this.listQueryParams.iterator();iter.hasNext();) {
        QueryParam param = (QueryParam) iter.next();
        String value = getParamValue(param.sourceId, param.sourceModifier, aRequestId, aRuntimeParamMap);
        map.put(param.paramName, value);
      }
      return map;
    }
  }
  
  /**
   * Inner class that stores a query parameter.
   */
  private static class QueryParam {
    int sourceId = -1; 
    String sourceModifier = null;
    String paramName = null;
    
    QueryParam(int aSourceId, String aSourceModifier, String aParamName) {
      this.sourceId = aSourceId; 
      this.sourceModifier = aSourceModifier;
      this.paramName = aParamName;
    }
  }
  
  /**
   * Inner class that wraps document and evaluator IDs to act as key to cached map  
   * of <code>QueryInfo</code> objects.
   */
  private static class QueryInfoKey {
    private String strKey = null;
    
    QueryInfoKey(long aDocumentId, long anEvaluatorId) {
      this.strKey = String.valueOf(aDocumentId) + ":" + String.valueOf(anEvaluatorId);
    }
    
    public boolean equals(Object obj) {
      boolean isEquals = false;
      if (obj instanceof QueryInfoKey) {
        QueryInfoKey otherKey = (QueryInfoKey) obj;
        isEquals = this.strKey.equals(otherKey.strKey);
      }
      return isEquals;
    }
    
    public int hashCode() {
      return this.strKey.hashCode();
    }
  }  
  
  public static final int QUERY_SOURCE_REQUEST_ID = 1;
  public static final int QUERY_SOURCE_CONSTANT = 2;
  public static final int QUERY_SOURCE_USER_ID = 3;
  public static final int QUERY_SOURCE_RUNTIME = 4;
  
  private static final String CONFIGDOC_WHENTOUSE_SQL =
    "SELECT dw.query_id, dq.query_txt " +
    "FROM config_doc_when_to_use dw, config_doc_queries dq " +
    "WHERE dw.document_id = ? AND dw.evaluator_id = ? AND " +
    "      dw.query_id = dq.query_id AND dq.evaluator_id = ? " +
    "ORDER BY dw.order_precedence_num";
  
  private static final String CONFIGDOC_PARAMS_SQL =
    "SELECT dp.parm_name_txt, dp.source_id, dp.source_txt " +
    "FROM config_doc_query_parms dp " +
    "WHERE dp.query_id = ? AND dp.evaluator_id = ?";
  
  private Map mapQueryInfo = null;
  
  private static WhenToUseQueryFactory factory = null;
  
  public static synchronized WhenToUseQueryFactory getInstance() {
    if (factory == null)
      factory = new WhenToUseQueryFactory();
    return factory;
  }
  
  private WhenToUseQueryFactory() {
    this.mapQueryInfo = new HashMap();
    this.mapQueryInfo = Collections.synchronizedMap(this.mapQueryInfo);
  }
  
  public synchronized QueryInfo[] getQueryInfo(Connection aConnection, long aDocumentId, long anEvaluatorId) throws AppException {
    
    QueryInfoKey key = new QueryInfoKey(aDocumentId, anEvaluatorId);
    QueryInfo[] queryInfo = (QueryInfo[]) this.mapQueryInfo.get(key);
    if (queryInfo != null)
      return queryInfo;

    LinkedList list = new LinkedList();
    PreparedStatement stmt = null;
    ResultSet rs = null;
    try {
      int idx = 1;
      stmt = aConnection.prepareStatement(CONFIGDOC_WHENTOUSE_SQL);
      stmt.setLong(idx++, aDocumentId);
      stmt.setLong(idx++, anEvaluatorId);
      stmt.setLong(idx++, anEvaluatorId);
      rs = stmt.executeQuery();
      while (rs != null && rs.next()) {
        long queryId = rs.getLong("query_id"); 
        String querySQL = rs.getString("query_txt"); 
        List listParams = getQueryParams(aConnection, queryId, anEvaluatorId);
        QueryInfo qi = new QueryInfo(queryId, querySQL, listParams);
        list.add(qi);
      }
    }
    catch (SQLException ex) {
      throw new AppException("failed to query config_doc_when_to_use / config_doc_queries " +
        "for document ID=" + aDocumentId + ", evaluator ID=" + anEvaluatorId, ex);
    }
    finally {
	  try{ if(rs != null) rs.close(); }catch(Exception e1){e1.printStackTrace();}
	  try{ if(stmt != null) stmt.close(); }catch(Exception e1){e1.printStackTrace();}
    }
    
    queryInfo = null;
    if (list.size() > 0) {
      queryInfo = (QueryInfo[]) list.toArray(new QueryInfo[0]);
      this.mapQueryInfo.put(key, queryInfo);
    }
    return queryInfo;
  }
  
  private List getQueryParams(Connection aConnection, long aQueryId, long anEvaluatorId) throws AppException {

    List list = new LinkedList();
    PreparedStatement stmt = null;
    ResultSet rs = null;
    try {
      int idx = 1;
      stmt = aConnection.prepareStatement(CONFIGDOC_PARAMS_SQL);
      stmt.setLong(idx++, aQueryId);
      stmt.setLong(idx++, anEvaluatorId);
      rs = stmt.executeQuery();
      while (rs != null && rs.next()) {
        int sourceId = rs.getInt("source_id"); 
        String sourceModifier = rs.getString("source_txt");
        String paramName = rs.getString("parm_name_txt");
        QueryParam param = new QueryParam(sourceId, sourceModifier, paramName);
        list.add(param);
      }
    }
    catch (SQLException ex) {
      throw new AppException("failed to config_doc_query_parms " +
        "for query ID=" + aQueryId + ", evaluator ID=" + anEvaluatorId, ex);
    }
    finally {
      try{ if(rs != null) rs.close(); }catch(Exception e1){e1.printStackTrace();}
	  try{ if(stmt != null) stmt.close(); }catch(Exception e1){e1.printStackTrace();}
    }
    return list;
  }
  
  private static String getParamValue(int aSourceId, String aSourceModifier, long aRequestId, 
    Map aRuntimeParamMap) throws AppException {
    
    String value = null;
    switch (aSourceId) {
      case QUERY_SOURCE_REQUEST_ID: {
        value = String.valueOf(aRequestId);
        break;
      }
        
      case QUERY_SOURCE_CONSTANT: {
        value = aSourceModifier;
        break;
      }
        
      case QUERY_SOURCE_USER_ID: {
        Object objValue = aRuntimeParamMap.get("user_id");
        if (objValue == null)
          throw new AppException("'user_id' not present in runtime parameter map, request ID=" + aRequestId);
        value = objValue.toString();
        break;
      }
        
      case QUERY_SOURCE_RUNTIME: {
        Object objValue = aRuntimeParamMap.get(aSourceModifier);
        if (objValue == null)
          throw new AppException("'" + aSourceModifier + "' not present in runtime parameter map, request ID=" + aRequestId);
        value = objValue.toString();
        break;
      }
      
      default:
        throw new AppException("unknown source ID " + aSourceId);
    }
    return value;
  }
}
