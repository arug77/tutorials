package com.cmsinc.origenate.textdoc.formatters;

import com.cmsinc.origenate.textdoc.AppException;

/**
 * Formats a phone number.
 * 
 * @since Origenate 6.0
 */
public class PhoneFormatter extends MaskFormatter implements FieldFormatter {
 
  private static final String DIALONE_PHONE_MASK = "? (???) ???-????";

  private static final String LONG_PHONE_MASK = "(???) ???-????";
  
  private static final String SHORT_PHONE_MASK = "???-????";
  
  /** 
   * @see com.cmsinc.origenate.textdoc.formatters.FieldFormatter#format(java.lang.Object)
   */
  public String format(Object aValue) throws AppException {
    if (aValue == null)
      return "";
      
    String phoneNumber = aValue.toString().trim();
    String formattedPhoneNumber = phoneNumber;
    if (phoneNumber.length() == 11)
      formattedPhoneNumber = applyDisplayMask(DIALONE_PHONE_MASK, ' ', phoneNumber);
    else if (phoneNumber.length() == 10)
      formattedPhoneNumber = applyDisplayMask(LONG_PHONE_MASK, ' ', phoneNumber);
    else if (phoneNumber.length() == 7)
      formattedPhoneNumber = applyDisplayMask(SHORT_PHONE_MASK, ' ', phoneNumber);
    return formattedPhoneNumber;
  }
}
