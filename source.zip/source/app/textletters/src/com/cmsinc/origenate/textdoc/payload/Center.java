package com.cmsinc.origenate.textdoc.payload;

/**
 * Data about a sales center, including address.<br>
 * 
 * Treat this class as "thread-safe", since it is immutable once created.
 * 
 * @since Origenate 6.0
 */
public class Center {
    
  private String name = null;
  private String streetNumber = null;
  private String streetName = null;
  private String streetTypeId = null;
  private String typeOfStreet = null;
  private String city = null;
  private String state = null;
  private String zipcode = null;
  private String phone = null;
  private String fax = null;
  
  Center(String aName, String aStreetNumber, 
    String aStreetName, String aStreetTypeId, String aTypeOfStreet, 
    String aCity, String aState, String aZipcode, String aPhone, String aFax) {

    this.name = aName;
    this.streetNumber = aStreetNumber;
    this.streetName = aStreetName;
    this.streetTypeId = aStreetTypeId;
    this.typeOfStreet = aTypeOfStreet;
    this.city = aCity;
    this.state = aState;
    this.zipcode = aZipcode;
    this.phone = aPhone;
    this.fax = aFax;
  }
    
  public String getName() {
    return this.name;
  }
  
  public String getStreetNumber() {
    return this.streetNumber;
  }
  
  public String getStreetName() {
    return this.streetName;
  }
  
  public String getStreetTypeId() {
    return this.streetTypeId;
  }
  
  public String getTypeOfStreet() {
    return this.typeOfStreet;
  }
  
  public String getCity() {
    return this.city;
  }
  
  public String getState() {
    return this.state;
  }
  
  public String getZipcode() {
    return this.zipcode;
  }
  
  public String getPhone() {
    return this.phone;
  }
  
  public String getFax() { 
    return this.fax;
  }  
}
