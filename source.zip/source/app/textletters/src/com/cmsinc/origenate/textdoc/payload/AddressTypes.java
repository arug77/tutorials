package com.cmsinc.origenate.textdoc.payload;

/**
 * Static that exists simply to define address types.
 * 
 * @since Origenate 6.0
 */
public abstract class AddressTypes {
  static final int CURRENT_ADDRESS = 0;
  static final int MAILING_ADDRESS = 3;
}
