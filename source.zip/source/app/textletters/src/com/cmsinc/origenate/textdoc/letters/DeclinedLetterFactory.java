package com.cmsinc.origenate.textdoc.letters;

import java.sql.Connection;

/**
 * Factory for selecting declined credit apps and creating <code>DeclinedLetter</code> instances.<br>
 * 
 * Treat this class as "thread-hostile".
 * 
 * @since Origenate 6.0
 */
public class DeclinedLetterFactory extends LetterFactory {
  private static final String DECLINED_SELECT_LIST = 
    "cps.turndown_delay_days_num delay_days, ev.turndown_printer_txt printer_text";

  /**
   * To select declined apps: 
   * 
   * The application must have a decision status of DECLINE or DECSCOR.
   * The current date must be beyond the application's initiated date plus the turndown delay.
   * Decision status: 2=decline, 103=decscor (decline based on score)
   */  
  private static final String DECLINED_WHERE_CLAUSE = 
    "cr.decision_status_id IN (2,103) AND "+
    "sysdate > (cr.initiation_dt + cps.turndown_delay_days_num)";
    
  public static final String LETTER_CATEGORY = "DECLINE_LETTER";
   
  protected String getLetterCategory() {
    return LETTER_CATEGORY;
  }    
  
  /**
   * Restricted ctor for creating an instance of this class.
   *  
   * @param someEvaluatorIds
   *  evaluators to search by, or null to search regardless of evaluator.
   */
  public DeclinedLetterFactory(Connection aConnection, long[] someEvaluatorIds) {
    super(aConnection, LETTER_CATEGORY, someEvaluatorIds);
  }
  
  protected StringBuffer selectList() {
    StringBuffer buf = super.selectList();
    buf = appendCharIfNeeded(buf, ',');
    buf.append(DECLINED_SELECT_LIST);
    return buf;
  }
  
  protected StringBuffer whereClause() {
    StringBuffer buf = super.whereClause();
    buf = appendWordIfNeeded(buf, "AND");
    buf.append(DECLINED_WHERE_CLAUSE);
    return buf;
  }  
}
