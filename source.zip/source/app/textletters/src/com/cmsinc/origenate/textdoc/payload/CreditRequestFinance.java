package com.cmsinc.origenate.textdoc.payload;

import java.math.BigDecimal;

/**
 * Data about the original, financial aspects of a credit request.<br>
 * 
 * Treat this class as "thread-safe", since it is immutable once created.
 * 
 * @since Origenate 6.0
 */
public class CreditRequestFinance {
  
  private int term = -1;
  private BigDecimal amount = null;
  private BigDecimal rate = null;
  private BigDecimal payment = null;
  private BigDecimal cashDown = null;

  public CreditRequestFinance(int aTerm, BigDecimal anAmount, BigDecimal aRate,
    BigDecimal aPayment, BigDecimal aCashDownAmt) {
    this.term = aTerm;
    this.amount = anAmount;
    this.rate = aRate;
    this.payment = aPayment;
    this.cashDown = aCashDownAmt;
  }
  
  public int getRequestedTerm() {
    return this.term;
  }
  
  public BigDecimal getRequestedAmount() {
    return this.amount;
  }
  
  public BigDecimal getRequestedRate() {
    return this.rate;
  }
  
  public BigDecimal getRequestedPayment() {
    return this.payment;
  }
  
  public BigDecimal getCashDown() {  
    return this.cashDown;
  }
}
