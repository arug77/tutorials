package com.cmsinc.origenate.textdoc.payload;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import java.util.logging.Level;
import com.cmsinc.origenate.textdoc.AppLogger;
import com.cmsinc.origenate.textdoc.AppException;

/**
 * Simple factory class for creating instances of <code>BureauScore</code> 
 * by quering the database.<br>
 * 
 * Treat this class as "thread-hostile".<br>
 * 
 * @since Origenate 8.5.25
 */
public class BureauScoreFactory 
{

	private Connection conn = null;
  
	public BureauScoreFactory(Connection aConnection) 
	{
		this.conn = aConnection;
	}
  
	public BureauScore getBureauScore(long aRequestId, long aRequestorId) throws AppException 
	{
		String QUERY_SQL = 
			"SELECT esum.BUREAUSCORE1, esum.SCOREREASON1_1, esum.SCOREREASON1_2, esum.SCOREREASON1_3, " +
			"       esum.SCOREREASON1_4, bsr.SCORERSNTEXT as RTEXT1, d2.SCORERSNTEXT as RTEXT2, d3.SCORERSNTEXT as RTEXT3, " +
			"       d4.SCORERSNTEXT as RTEXT4, bh.PULLDATE, esum.INQUIRIES  " +
			" FROM EVAPP_SUMMARY esum " +
			" LEFT OUTER JOIN EVAPP_SEQNO es ON (es.APPSEQNO=esum.APPSEQNO AND es.BUREAUOFRECORD = esum.BUREAU) " +
			" LEFT OUTER JOIN  BUREAU_HEADER bh ON (es.APPSEQNO = bh.APPSEQNO AND esum.APPENTITY = bh.APPENTITY " +
			" AND esum.BUREAU = bh.BUREAUID AND esum.BURPRODUCT = bh.BURPRODUCT) " +
			" LEFT OUTER JOIN BUREAU_SCOREREASONS bsr ON (  esum.BUREAU = bsr.BUREAUID " +  
			" AND esum.SCOREMODEL1 = bsr.MODELID AND esum.SCOREREASON1_1 = bsr.SCOREREASON AND bsr.CLIENTID = es.CLIENTID) " +
			" LEFT OUTER JOIN BUREAU_SCOREREASONS d2 ON ( esum.BUREAU = d2.BUREAUID " +
			" AND esum.SCOREMODEL1 = d2.MODELID AND esum.SCOREREASON1_2 = d2.SCOREREASON AND d2.CLIENTID = es.CLIENTID) " +
			" LEFT OUTER JOIN BUREAU_SCOREREASONS d3 ON ( esum.BUREAU = d3.BUREAUID " +
			" AND esum.SCOREMODEL1 = d3.MODELID AND esum.SCOREREASON1_3 = d3.SCOREREASON AND d3.CLIENTID = es.CLIENTID) " +
			" LEFT OUTER JOIN BUREAU_SCOREREASONS d4 ON ( esum.BUREAU = d4.BUREAUID " +
			" AND esum.SCOREMODEL1 = d4.MODELID AND esum.SCOREREASON1_4 = d4.SCOREREASON AND d4.CLIENTID = es.CLIENTID) " +
			"  WHERE es.REQUEST_ID = ? " +
			" AND esum.REQUESTOR_ID = ? " +
		    " AND bh.FILENUM = 1 " +
			"ORDER BY es.BUREAUOFRECORD";
		BureauScore data = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		long elapsedQueryTime = 0;
    
		try 
		{
			int idx = 1;
			long startQueryTime = (new Date()).getTime();
			stmt = this.conn.prepareStatement(QUERY_SQL);
			stmt.setLong(idx++, aRequestId);
			stmt.setLong(idx++, aRequestorId);
			rs = stmt.executeQuery();
			if (rs != null && rs.next()) 
			{ 
          
				data = new BureauScore(rs.getString("BUREAUSCORE1"), rs.getString("SCOREREASON1_1"), 
					rs.getString("SCOREREASON1_2"), rs.getString("SCOREREASON1_3"), rs.getString("SCOREREASON1_4"), 
					rs.getString("RTEXT1"), rs.getString("RTEXT2"), rs.getString("RTEXT3"), rs.getString("RTEXT4"),
					rs.getDate("PULLDATE"), rs.getString("INQUIRIES"));
			}
      
			long endQueryTime = (new Date()).getTime();
			elapsedQueryTime = endQueryTime - startQueryTime;
		}
		catch (SQLException ex) 
		{
			throw new AppException("failed to query EVAPP_SUMMARY " +
				"for request ID=" + aRequestId + ", requestor ID=" + aRequestorId, ex);
		}
		finally {
			try{ if(rs != null) rs.close(); }catch(Exception e1){e1.printStackTrace();}
			try{ if(stmt != null) stmt.close(); }catch(Exception e1){e1.printStackTrace();}
		}

		AppLogger.logger.log(Level.FINEST, Thread.currentThread().getName() + 
			": queried " + 1 + " BureauScore object in " + elapsedQueryTime + " ms");
		return data;
	}
}
