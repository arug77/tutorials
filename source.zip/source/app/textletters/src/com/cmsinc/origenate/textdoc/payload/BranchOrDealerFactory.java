package com.cmsinc.origenate.textdoc.payload;

import java.util.Date;
import java.util.LinkedList;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import com.cmsinc.origenate.textdoc.AppLogger;
import com.cmsinc.origenate.textdoc.AppException;

/**
 * Simple factory class for creating instances of <code>BranchOrDealer</code> 
 * by quering the database.<br>
 * 
 * Treat this class as "thread-hostile" (tied to a JDBC connection, which may or may not be thread-safe).<br>
 * 
 * @since Origenate 6.0
 */
public class BranchOrDealerFactory {

  /* 151786
  private static final String QUERY_SQL = 
    "SELECT eo.ORIGINATOR_TYPE_ID, mo.ORIGINATOR_TYPE_DESC_TXT, eo.ORIGINATOR_NAME_TXT, eo.DBA_NAME_TXT, eo.CONTACT_TXT, " + 
    "        oa.ADDRESS_TYPE_ID, oa.ADDRESS1_TXT, oa.ADDRESS2_TXT, oa.CITY_TXT, oa.STATE_ID, oa.ZIPCODE_TXT, " +
    "        oa.PHONE_NUMBER_TXT, oa.PHONE_EXTENSION_TXT, oa.FAX_NUMBER_TXT " +
    "FROM CREDIT_REQUEST_ORIGINATOR co, EVALUATOR_ORIGINATOR eo, " +
    "     ORIGINATOR_ADDRESS oa, MSTR_ORIGINATOR_TYPE mo " +
    "WHERE co.REQUEST_ID = ? AND co.EVALUATOR_ID = ? AND " +
    "      co.EVALUATOR_ID = eo.EVALUATOR_ID AND " +
    "      co.ORIGINATOR_ID = eo.ORIGINATOR_ID AND " +
    "      co.EVALUATOR_ID = oa.EVALUATOR_ID AND " +
    "      co.ORIGINATOR_ID = oa.ORIGINATOR_ID AND " +
    "      eo.ORIGINATOR_TYPE_ID = mo.ORIGINATOR_TYPE_ID AND " +
    "      (oa.ADDRESS_TYPE_ID = ? OR oa.ADDRESS_TYPE_ID = ?) " + 
    "ORDER BY oa.EVALUATOR_ID, oa.ORIGINATOR_ID, oa.ADDRESS_TYPE_ID";
  */
  	
  private static final String QUERY_SQL = 
	"SELECT eo.ORIGINATOR_TYPE_ID, mo.ORIGINATOR_TYPE_DESC_TXT, eo.ORIGINATOR_NAME_TXT, eo.DBA_NAME_TXT, eo.CONTACT_TXT, " +
	"       oa.ADDRESS_TYPE_ID, oa.ADDRESS1_TXT, oa.ADDRESS2_TXT, oa.CITY_TXT, oa.STATE_ID, oa.ZIPCODE_TXT, " +
	"       oa.PHONE_NUMBER_TXT, oa.PHONE_EXTENSION_TXT, xeoc.comm_type_number_txt as FAX_NUMBER_TXT " +
	"FROM CREDIT_REQUEST_ORIGINATOR co, EVALUATOR_ORIGINATOR eo, xref_eval_orig_comm_type xeoc, " +
	"     ORIGINATOR_ADDRESS oa, MSTR_ORIGINATOR_TYPE mo " +
	"WHERE co.REQUEST_ID = ? AND co.EVALUATOR_ID = ? AND " +
	"      co.EVALUATOR_ID = eo.EVALUATOR_ID AND " +
	"      co.ORIGINATOR_ID = eo.ORIGINATOR_ID AND " +
	"      co.EVALUATOR_ID = oa.EVALUATOR_ID AND " +
	"      co.ORIGINATOR_ID = oa.ORIGINATOR_ID AND " +
	"      eo.ORIGINATOR_TYPE_ID = mo.ORIGINATOR_TYPE_ID AND " +
	"      (oa.ADDRESS_TYPE_ID = ? OR oa.ADDRESS_TYPE_ID = ?) AND " +
	"       xeoc.evaluator_id = oa.evaluator_id AND " +
	"   	xeoc.originator_id = oa.originator_id AND " +
	"       xeoc.address_type_id = oa.address_type_id AND " +
	"	    xeoc.comm_type_id = 1  AND " +
	"	    xeoc.comm_id = 1 " +      
	"ORDER BY oa.EVALUATOR_ID, oa.ORIGINATOR_ID, oa.ADDRESS_TYPE_ID";
	
  private Connection conn = null;
  
  public BranchOrDealerFactory(Connection aConnection) {
    this.conn = aConnection;
  }
  
  public BranchOrDealer[] getBranchesOrDealers(long aRequestId, long anEvaluatorId) throws AppException {
    LinkedList list = new LinkedList();
    PreparedStatement stmt = null;
    ResultSet rs = null;
    long elapsedQueryTime = 0;
    
    try {
      int idx = 1;
      long startQueryTime = (new Date()).getTime();
      stmt = this.conn.prepareStatement(QUERY_SQL);
      stmt.setLong(idx++, aRequestId);
      stmt.setLong(idx++, anEvaluatorId);
      stmt.setLong(idx++, AddressTypes.MAILING_ADDRESS);
      stmt.setLong(idx++, AddressTypes.CURRENT_ADDRESS);
      rs = stmt.executeQuery();
      while (rs != null && rs.next()) { 
        long originatorTypeId = rs.getLong("ORIGINATOR_TYPE_ID");
        if (rs.wasNull()) 
          originatorTypeId = -1;
          
        long addressTypeId = rs.getLong("ADDRESS_TYPE_ID");
        if (rs.wasNull()) 
          addressTypeId = -1;
             
        BranchOrDealer data = new BranchOrDealer(originatorTypeId, rs.getString("ORIGINATOR_TYPE_DESC_TXT"), 
          rs.getString("ORIGINATOR_NAME_TXT"), rs.getString("DBA_NAME_TXT"), rs.getString("CONTACT_TXT"), 
          addressTypeId, rs.getString("ADDRESS1_TXT"), rs.getString("ADDRESS2_TXT"), rs.getString("CITY_TXT"), 
          rs.getString("STATE_ID"), rs.getString("ZIPCODE_TXT"), 
          rs.getString("PHONE_NUMBER_TXT"), rs.getString("PHONE_EXTENSION_TXT"), 
          rs.getString("FAX_NUMBER_TXT"));
        list.add(data);
      }
      
      long endQueryTime = (new Date()).getTime();
      elapsedQueryTime = endQueryTime - startQueryTime;
    }
    catch (SQLException ex) {
      throw new AppException("failed to query CREDIT_REQUEST_ORIGINATOR / EVALUATOR_ORIGINATOR " +
        "for request ID=" + aRequestId + " and evaluator ID=" + anEvaluatorId, ex);
    }
    finally {
		try{ if(rs != null) rs.close(); }catch(Exception e1){e1.printStackTrace();}
		try{ if(stmt != null) stmt.close(); }catch(Exception e1){e1.printStackTrace();}
	}
    
    AppLogger.logger.log(Level.FINEST, Thread.currentThread().getName() + 
      ": queried " + list.size() + " BranchOrDealer objects in " + elapsedQueryTime + " ms");
    
    BranchOrDealer[] arrData = null;
    if (list.size() > 0)
      arrData = (BranchOrDealer[]) list.toArray(new BranchOrDealer[0]);
    return arrData;
  }
}
