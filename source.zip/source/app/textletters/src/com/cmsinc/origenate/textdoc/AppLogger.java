/******************************************************************************
 Company: First American CMSI
 Product: Origenate
 Author: Potomac Software, Inc.
 Copyright 2004, 2005 by Potomac Software, Inc. 
 Copyright 2005 by First American CMSI. All rights reserved.
******************************************************************************/

package com.cmsinc.origenate.textdoc;

import java.io.IOException;
import java.util.logging.Logger;
import java.util.logging.Level;
import java.util.logging.StreamHandler;
import java.util.logging.FileHandler;
import java.util.logging.ConsoleHandler;
import java.util.logging.SimpleFormatter;

/**
 * Convenience wrapper around JDK 1.4 logging. If a particular logger is not configured,
 * this ensures a reasonable default logger will be setup.<br>
 * 
 * Messages should be logged with level SEVERE (errors only), INFO (warnings and
 * basic feedback) or FINEST (debug).<br>
 * 
 * Treat this class as "thread-hostile" (only the main thread should invoke the
 * <code>bootstrap</code> method), but the <code>logger</code> static instance 
 * variable as "thread-safe" once initialized (assuming JDK logger is thread-safe).
 * 
 * @since Origenate 6.0
 */
public class AppLogger {
  /**
   * Logger name for this application.
   */
  public static final String LOGGER_NAME = "com.cmsinc.origenate.tool.creditReqOrigAging";
  
  /**
   * Default log file name and location (user's home directory).
   */
  private static final String DEFAULT_LOGFILE_PATTERN = "%h/creditReqOrigAging_%u.log";
  
  /**
   * Default logging level, statis messahe are at INFO level. 
   */
  private static final Level DEFAULT_LEVEL = Level.INFO;
  
  /**
   * JVM property (-D) that can be passed as <code>true</code> to use JDK logging setup.
   */
  private static final String IGNORE_INI_SETTINGS = "ignoreIniSettings";
   
  /**
   * Logger instance used by all other class in this application.
   */
  public static Logger logger = null;
  
  /**
   * Guarantee logger instance is initialized with some reasonable defaults. 
   * Essentially, this method uses the log settings in the Origenate .INI file
   * unless JVM <code>ignoreIniSettings</code> argument is passed as true, in 
   * which case standard JDK 1.4 logging configuration mechanisms are used.<br>
   * 
   * <em>This method MUST be called before referencing static variable <code>logger<code>.</em>
   */
  public static void bootstrap(ConfigInfo aConfigInfo) {
    //
    // Determine if logger has a handler and a level (perhaps set by configuration).
    
    logger = Logger.getLogger(LOGGER_NAME);
    boolean hasHandler = false, hasLevel = false;
    while (logger != null) {
      if (logger.getHandlers() != null && logger.getHandlers().length > 0)
        hasHandler = true;
      if (logger.getLevel() != null)
        hasLevel = true;
      logger = logger.getParent();
    }
  
    // Get the logger instance and stash it, then see if we want to force
    // logger to be configured with default settings (handler and level).
    
    logger = Logger.getLogger(LOGGER_NAME);
    boolean ignoreIniSettings = Boolean.getBoolean(IGNORE_INI_SETTINGS);
    String defaultLogfilePattern = DEFAULT_LOGFILE_PATTERN;
    Level defaultLogLevel = DEFAULT_LEVEL;
    if (!ignoreIniSettings) {
      hasHandler = hasLevel = false;
      logger.setUseParentHandlers(false);
      if (aConfigInfo != null && aConfigInfo.getLogFile() != null)
        defaultLogfilePattern = aConfigInfo.getLogFile();
      if (aConfigInfo != null && aConfigInfo.getLogLevel() != null) {
        defaultLogLevel = origenateToLogLevel(aConfigInfo.getLogLevel());
      }
    } 

    // If no handler, then create a default handler that writes to a file.
    
    if (!hasHandler) {
      StreamHandler handler = null;
      try { 
        handler = new FileHandler(defaultLogfilePattern, true);
        handler.setFormatter(new SimpleFormatter());
      }
      catch (IOException ex) { 
        handler = new ConsoleHandler(); 
      }
      logger.addHandler(handler);
    }
    
    // If no level, set the default level.
    
    if (!hasLevel)
      logger.setLevel(defaultLogLevel);
  }
  
  /**
   * Convert Origenate debug level of 0 thru 5 to log level in JDK 1.l4 logging API.
   * 
   * @param anOrigenateDebugLevel
   *   Origenate debug level.
   * @return
   *   the converted log level.
   */
  private static Level origenateToLogLevel(String anOrigenateDebugLevel) {
    Level level = Level.INFO;
    try {
      int iOrigenateDebugLevel = Integer.parseInt(anOrigenateDebugLevel);
      switch (iOrigenateDebugLevel) {
        case 0:
          level = Level.SEVERE;
          break;
        case 1:
        case 2:
          level = Level.INFO;
          break;
        case 3:
        case 4:
        case 5:
          level = Level.FINEST;
          break;            
        default:
          level = Level.FINEST;
          break;   
      }
    }
    catch (NumberFormatException ex) {
      // Warn on stderr, but otherwise ignore
      System.err.println("debug level '" + anOrigenateDebugLevel + 
        "' is not numeric (0 to 5), using default debug level");
    }
    return level;
  }
  
  /**
   * Test driver for this class.
   * 
   * @param args
   *   not used.
   */
  public static void main(String[] args) {
    logger.severe("A severe TEST message!");
    System.exit(0);
  }
}
