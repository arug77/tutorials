package com.cmsinc.origenate.textdoc.sources;

import com.cmsinc.origenate.tool.origaging.AppException;

/**
 * Interface that defines simple API for document field sources. 
 */
public interface DocumentFieldSource {
  public String getValue() throws AppException;
}
