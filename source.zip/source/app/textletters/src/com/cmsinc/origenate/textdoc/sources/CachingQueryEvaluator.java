package com.cmsinc.origenate.textdoc.sources;

import java.util.Map;
import java.util.HashMap;
import java.util.List;
import java.util.LinkedList;
import java.util.Iterator;
import java.util.Collections;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.sql.RowSet;
import oracle.jdbc.rowset.OracleCachedRowSet;
import java.util.logging.Level;
import com.cmsinc.origenate.textdoc.AppLogger;
import com.cmsinc.origenate.textdoc.AppException;
import com.cmsinc.origenate.util.SQLSecurity;



/**
 * Evaluates dynamic queries, such as those stored in the <code>config_doc_queries</code> table.<br>
 *
 * Treat this class as thread-safe, i.e., multiples threads may use a single instance of
 * this class to execute queries. The cache is local the class instance, i.e., not a singleton.
 *
 * @since Origenate 6.0
 */
public class CachingQueryEvaluator {

  private Map mapRowsets = null;

  public CachingQueryEvaluator() {
    this.mapRowsets = new HashMap();
    this.mapRowsets = Collections.synchronizedMap(this.mapRowsets);
  }

  /**
   * Execute a dynamic query, but defer to the cache if the same query (after parameter
   * substitution) has been previously executed.
   *
   * @param aConn
   *   connection the Origenate database.
   * @param aTemplateSQL
   *   SQL select statement that may contain parameters..
   * @param aParamMap
   *   a map of parameters to their associated values, both must be <code>String</code>s.
   * @return
   *   a cached (disconnected) rowset, or null if no data is retrieved.
   * @throws AppException
   *   if a database error occurs, or if a parameter is not matched in the template SQL.
   */


  //public RowSet executeQuery(Connection aConn, String aTemplateSQL, Map aParamMap) throws AppException {
  public boolean executeQuery(Connection aConn, String aTemplateSQL, Map aParamMap) throws AppException, SQLException {
  // GL. changed to not use OracleCachedRowSet, possible cursor leak

     boolean foundOne=false;
    List listUnmatchedParams = new LinkedList();
    String selectSQL = CachingQueryEvaluator.replaceParams(aTemplateSQL, aParamMap, listUnmatchedParams);
    
    // unmatched parameters are appended to a single string in order to display in the exception
    if (listUnmatchedParams.size() > 0) {
      StringBuffer bufError = new StringBuffer();
      for (Iterator iter=listUnmatchedParams.iterator();iter.hasNext();) {
        String unmatchedParam = (String) iter.next();
        if (bufError.length() > 0)
          bufError.append(", ");
        bufError.append(unmatchedParam);
      }
      throw new AppException("dynamic query '" + aTemplateSQL + "' contains unmatched parameters " + bufError);
    }

    // If the SQL statement after parameter substitution exists in the cache, return the
    // rowset resulting from a previous execution of the query.
    //
    // The cache (map) manipulation is essentially thread-safe since the map is synchronized;
    // multiple threads executing the exact same query simultaneously might encounter a
    // he-who-writes-last-wins situation, but this is harmless and an acceptable trade-off
    // to synchronizing the whole method.

    /*
    OracleCachedRowSet rowset = (OracleCachedRowSet) this.mapRowsets.get(selectSQL);
    if (rowset != null)
      return false;
      */

    AppLogger.logger.log(Level.FINEST, Thread.currentThread().getName() +
      ": caching query evaluator SQL = <" + selectSQL + ">");

    String operation = "dynamic execution of '" + selectSQL + "'";
    PreparedStatement stmtQuery = null;
    ResultSet rs = null;
    try {
		/**
		 * OWASP TOP 10 2010 - A1 Critical SQL Injection
		 *  TTP 324955 Security Remediation Fortify Scan
		 */
		stmtQuery = aConn.prepareStatement(SQLSecurity.basicSanitize(selectSQL));
		//stmtQuery = aConn.prepareStatement(ESAPI.encoder().encodeForSQL( new OracleCodec(),selectSQL.toString()));

      /*
      if ((rs = stmtQuery.executeQuery()) != null) {
        rowset = new OracleCachedRowSet();
        rowset.populate(rs);
      }
      */

      // new
      if ((rs = stmtQuery.executeQuery()) != null)
          if (rs.next()) foundOne=true; // new

    }
    catch (SQLException ex) {
      throw new AppException("database error occurred during " + operation, ex);
    }
    finally {
	  try{ if(rs != null) rs.close(); }catch(Exception e1){e1.printStackTrace();}
	  try{ if(stmtQuery != null) stmtQuery.close(); }catch(Exception e1){e1.printStackTrace();}
    }

    /*
     * ======================================================================
     * Disable caching completely by never adding rowset to cache, caller
     * should close rowset (PotSoft, out-of-cursors fix(?), 10/06/06
     * ======================================================================
     *
    if (rowset != null)
      this.mapRowsets.put(selectSQL, rowset);
    */
   // return rowset;
   // returning true or false now if result set found one
    return foundOne;
  }

  /**
   * Replace parameters in a string with their associated values. The parameters may be of any
   * form, and are actually just substrings in the template strings.
   *
   * @param aTemplateString
   *   the template string that contains zero or more parameters, i.e., substrings to find and replace.
   * @param aParamMap
   *   the map of parameters strings to parameter values.
   * @param anUnmatchedParamList
   *   a list of unmatched parameters names stored as <code>String</code>s.
   * @return
   *   the resulting string after parameter substition.
   */
  public static String replaceParams(String aTemplateString, Map aParamMap, List anUnmatchedParamList) {
    Iterator iter = aParamMap.keySet().iterator();
    char[][] chParams = new char[aParamMap.size()][];
    HashMap mapMatchedParams = new HashMap();
    for (int i=0;iter.hasNext();i++) {
      String param = (String) iter.next();
      mapMatchedParams.put(param, Boolean.valueOf(false));
      chParams[i] = param.toCharArray();
    }

    int idxInput = 0, idxOutput = 0;
    char[] chInput = aTemplateString.toCharArray();
    char[] chOutput = new char[chInput.length * 2];

    for (;idxInput < chInput.length;idxInput++) {
      int idxMatchedParam = -1;
      for (int i=0;i < chParams.length;i++) {
        int j = 0;
        for (;j < chParams[i].length && (idxInput + j) < chInput.length;j++) {
          if (chInput[idxInput + j] != chParams[i][j])
            break;
        }
        if (j == chParams[i].length) {
          idxMatchedParam = i;
          break;
        }
      }

      if (idxMatchedParam >= 0) {
        idxInput += (chParams[idxMatchedParam].length - 1);
        mapMatchedParams.put(new String(chParams[idxMatchedParam]), Boolean.valueOf(true));

        String param = new String(chParams[idxMatchedParam]);
        String value = (String) aParamMap.get(param);
        if (value == null)
          continue;

        char[] chValue = value.toCharArray();
        for (int i=0;i < chValue.length && idxOutput < chOutput.length;i++)
          chOutput[idxOutput++] = chValue[i];
      }
      else
        chOutput[idxOutput++] = chInput[idxInput];
    }

    for (iter=mapMatchedParams.entrySet().iterator();iter.hasNext();) {
      Map.Entry entry = (Map.Entry) iter.next();
      String param = (String) entry.getKey();
      Boolean matchedFlag = (Boolean) entry.getValue();
      if (!matchedFlag.booleanValue())
        anUnmatchedParamList.add(param);
    }
    return new String(chOutput, 0, idxOutput);
  }
}
