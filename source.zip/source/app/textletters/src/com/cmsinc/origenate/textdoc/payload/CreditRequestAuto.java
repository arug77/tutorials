package com.cmsinc.origenate.textdoc.payload;

import java.math.BigDecimal;

/**
 * Data about an automobile pledged as collateral for the (auto, usually) loan.<br>
 * 
 * Treat this class as "thread-safe", since it is immutable once created.
 * 
 * @since Origenate 6.0
 */
public class CreditRequestAuto {
  
  private int year = -1;
  private String autoMake = null;
  private String autoModel = null;
  private String vin = null;
  private String color = null;
  private boolean isNew = false; 
  private BigDecimal mileage = null;
         
  public CreditRequestAuto(int aYear, String anAutoMake, String anAutoModel,
    String anVIN, String aColor, boolean aNewOrUsedFlag, BigDecimal aMileage) {
    this.year = aYear;
    this.autoMake = anAutoMake;
    this.autoModel = anAutoModel;
    this.vin = anVIN;
    this.color = aColor;
    this.isNew = aNewOrUsedFlag; 
    this.mileage = aMileage;
  }
  
  public int getYear() {
    return this.year;
  }

  public String getAutoMake() {
    return this.autoMake;
  }
  
  public String getAutoModel() {
    return this.autoModel;
  }
  
  public String getVIN() {
    return this.vin;
  }
  
  public String getColor() {
    return this.color;
  }
  
  public boolean isNew() {
    return this.isNew;
  }
 
  public BigDecimal getMileage() {
    return this.mileage;
  }    
}
