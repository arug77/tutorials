package com.cmsinc.origenate.textdoc.payload;

/**
 * Data about the dealer or branch that originated the credit request, including address.<br>
 * 
 * Treat this class as "thread-safe", since it is immutable once created.
 * 
 * @since Origenate 6.0
 */
public class BranchOrDealer {
  
  private long originatorTypeId = -1;
  private String originatorTypeDesc = null;
  private String originatorName = null;
  private String dbaName = null;
  private String contact = null;
  private long addressTypeId = -1;
  private String address1 = null;
  private String address2 = null;
  private String city = null;
  private String state = null;
  private String zipcode = null;
  private String phone = null;
  private String phoneExt = null;
  private String fax = null;
  
  BranchOrDealer(long anOriginatorTypeId, String anOriginatorTypeDesc, String anOriginatorName, 
    String aDBAName, String aContact, long anAddressTypeId, String anAddress1, String anAddress2, String aCity, 
    String aState, String aZipcode, String aPhone, String aPhoneExt, String aFax) {

    this.originatorTypeId = anOriginatorTypeId;
    this.originatorTypeDesc = anOriginatorTypeDesc;
    this.originatorName = anOriginatorName;
    this.dbaName = aDBAName;
    this.contact = aContact;
    this.addressTypeId = anAddressTypeId;
    this.address1 = anAddress1;
    this.address2 = anAddress2;
    this.city = aCity;
    this.state = aState;
    this.zipcode = aZipcode;
    this.phone = aPhone;
    this.phoneExt = aPhoneExt;
    this.fax = aFax;
  }
  
  public long getOriginatorTypeId() {
    return this.originatorTypeId;
  }
  
  public String getOriginatorTypeDesc() {
    return this.originatorTypeDesc;
  }
  
  public String getOriginatorName() {
    return this.originatorName;
  }
  
  public String getDBAName() {
    return this.dbaName;
  }  

  public String getContact() {
    return this.contact;
  }
  
  public long getAddressTypeId() {
    return this.addressTypeId;
  }
  
  public String getAddress1() {
    return this.address1;
  }
  
  public String getAddress2() {
    return this.address2;
  }
  
  public String getCity() {
    return this.city;
  }
  
  public String getState() {
    return this.state;
  }
  
  public String getZipcode() {
    return this.zipcode;
  }
  
  public String getPhone() {
    return this.phone;
  }
  
  public String getPhoneExt() {
    return this.phoneExt;
  }
  
  public String getFax() {
    return this.fax;
  }  
}
