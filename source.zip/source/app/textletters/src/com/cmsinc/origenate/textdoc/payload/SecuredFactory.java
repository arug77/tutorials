package com.cmsinc.origenate.textdoc.payload;

import java.util.Date;
import java.util.LinkedList;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import com.cmsinc.origenate.textdoc.AppLogger;
import com.cmsinc.origenate.textdoc.AppException;

/**
 * Simple factory class for creating instances of <code>Secured</code> 
 * by quering the database.<br>
 * 
 * Treat this class as "thread-hostile".<br>
 * 
 * @since Origenate 6.0
 */
public class SecuredFactory {
  private static final String QUERY_SQL = 
    "SELECT cc.SEC_CODE_ID, mc.SEC_CODE_DESC_TXT " + 
    "FROM CREDIT_REQ_COMPASSAL_SETUP cc, MSTR_COMPASSAL_SECURED_CODE mc " +
    "WHERE cc.REQUEST_ID = ? AND " +
    "      cc.SEC_CODE_ID = mc.SEC_CODE_ID (+)" +
    "ORDER BY cc.SEC_CODE_ID";

  private Connection conn = null;
  
  public SecuredFactory(Connection aConnection) {
    this.conn = aConnection;
  }
  
  public Secured[] getSecured(long aRequestId) throws AppException {
    LinkedList list = new LinkedList();
    PreparedStatement stmt = null;
    ResultSet rs = null;
    long elapsedQueryTime = 0;
    
    try {
      int idx = 1;
      long startQueryTime = (new Date()).getTime();
      stmt = this.conn.prepareStatement(QUERY_SQL);
      stmt.setLong(idx++, aRequestId);
      rs = stmt.executeQuery();
      while (rs != null && rs.next()) { 
        Secured data = new Secured(rs.getString("SEC_CODE_ID"), 
          rs.getString("SEC_CODE_DESC_TXT"));
        list.add(data);
      }
      
      long endQueryTime = (new Date()).getTime();
      elapsedQueryTime = endQueryTime - startQueryTime;
    }
    catch (SQLException ex) {
      throw new AppException("failed to query CREDIT_REQ_COMPASSAL_SETUP for request ID=" + aRequestId, ex);
    }
    finally {
		try{ if(rs != null) rs.close(); }catch(Exception e1){e1.printStackTrace();}
		try{ if(stmt != null) stmt.close(); }catch(Exception e1){e1.printStackTrace();}
	}
    
    AppLogger.logger.log(Level.FINEST, Thread.currentThread().getName() + 
      ": queried " + list.size() + " Secured objects in " + elapsedQueryTime + " ms");
    
    Secured[] arrData = null;
    if (list.size() > 0)
      arrData = (Secured[]) list.toArray(new Secured[0]);
    return arrData;
  }
}
