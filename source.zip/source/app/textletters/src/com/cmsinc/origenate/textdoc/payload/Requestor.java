package com.cmsinc.origenate.textdoc.payload;

/**
 * Data about a requestor (applicant), including address.<br>
 * 
 * Treat this class as "thread-safe", since it is immutable once created.
 * 
 * @since Origenate 6.0
 */
public class Requestor {
  
  private long requestorId = -1;
  private int typeOfRequestor = -1;
  private long appSeqno = -1;
  private String lastName = null;
  private String firstName = null;
  private String middleName = null;
  private String nameSuffix = null;
  private String ssn = null;
  private String streetNumber = null;
  private String streetName = null;
  private String streetTypeId = null;
  private String typeOfStreet = null;
  private String address2 = null;
  private String apartmentBoxOrSuite = null;
  private String city = null;
  private String state = null;
  private String zipcode = null;
  private String phone = null;
  private String phoneExt = null;
  private String fax = null;
  
  Requestor(long aRequestorId, int aTypeOfRequestor, long anAppSeqno, String aLastName, String aFirstName, 
    String aMiddleName, String aNameSuffix, String anSSN, String aStreetNumber, 
    String aStreetName, String aStreetTypeId, String aTypeOfStreet, String anAddress2, String anApartmentBoxOrSuite, 
    String aCity, String aState, String aZipcode, String aPhone, String aPhoneExt, String aFax) {
    this.requestorId = aRequestorId;
    this.typeOfRequestor = aTypeOfRequestor;
    this.appSeqno = anAppSeqno;
    this.lastName = aLastName;
    this.firstName = aFirstName;
    this.middleName = aMiddleName;
    this.nameSuffix = aNameSuffix;
    this.ssn = anSSN;
    this.streetNumber = aStreetNumber;
    this.streetName = aStreetName;
    this.streetTypeId = aStreetTypeId;
    this.typeOfStreet = aTypeOfStreet;
    this.address2 = anAddress2;
    this.apartmentBoxOrSuite = anApartmentBoxOrSuite;
    this.city = aCity;
    this.state = aState;
    this.zipcode = aZipcode;
    this.phone = aPhone;
    this.phoneExt = aPhoneExt;
    this.fax = aFax;
  }
  
  public long getRequestorId() {
    return this.requestorId;
  }
  
  public int getTypeOfRequestor() {
    return this.typeOfRequestor;
  }
  
  public long getAppSeqno() {
    return this.appSeqno;
  }
  
  public String getLastName() {
    return this.lastName;
  }
  
  public String getFirstName() {
    return this.firstName;
  }
  
  public String getMiddleName() {
    return this.middleName;
  }
  
  public String getNameSuffix() {
    return this.nameSuffix;
  }
  
  public String getSSN() {
    return this.ssn;
  }
  
  public String getStreetNumber() {
    return this.streetNumber;
  }
  
  public String getStreetName() {
    return this.streetName;
  }
  
  public String getStreetTypeId() {
    return this.streetTypeId;
  }
  
  public String getTypeOfStreet() {
    return this.typeOfStreet;
  }
  
  public String getAddress2() {
    return this.address2;
  }
  
  public String getApartmentBoxOrSuite() {
    return this.apartmentBoxOrSuite;
  }
  
  public String getCity() {
    return this.city;
  }
  
  public String getState() {
    return this.state;
  }
  
  public String getZipcode() {
    return this.zipcode;
  }
  
  public String getPhone() {
    return this.phone;
  }
  
  public String getPhoneExt() {
    return this.phoneExt;
  }
  
  public String getFax() { 
    return this.fax;
  }  
}
