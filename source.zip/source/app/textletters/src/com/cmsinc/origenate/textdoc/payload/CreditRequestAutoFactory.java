package com.cmsinc.origenate.textdoc.payload;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import java.util.logging.Level;
import com.cmsinc.origenate.textdoc.AppLogger;
import com.cmsinc.origenate.textdoc.AppException;

/**
 * Simple factory class for creating instances of <code>CreditRequestAuto</code> 
 * by quering the database.<br>
 * 
 * Treat this class as "thread-hostile".<br>
 * 
 * @since Origenate 6.0
 */
public class CreditRequestAutoFactory {
  private static final String QUERY_SQL = 
    "SELECT ca.YEAR_NUM, ma.AUTO_MAKE_DESCRIPTION_TXT, ca.MODEL_TXT, ca.VIN_TXT, " +
    "       ca.COLOR_TXT, ca.NEW_USED_FLG, ca.MILEAGE_VALUE_NUM " +
    "FROM CREDIT_REQUEST_COLLATERAL cc, CREDIT_REQUEST_AUTO ca, MSTR_AUTO_MAKE ma " +
    "WHERE cc.REQUEST_ID = ? AND cc.EVALUATOR_ID = ? AND " +
    "      cc.REQUEST_ID = ca.REQUEST_ID AND " +
    "      cc.COLLATERAL_REQUEST_ID = ca.COLLATERAL_REQUEST_ID AND " +
    "      ca.AUTO_MAKE_ID = ma.AUTO_MAKE_ID (+) AND " +
    "      (ROWNUM = 1)";

  private Connection conn = null;
    
  public CreditRequestAutoFactory(Connection aConnection) {
    this.conn = aConnection;
  }
  
  public CreditRequestAuto getAuto(long aRequestId, long anEvaluatorId) throws AppException {
    CreditRequestAuto data = null;
    PreparedStatement stmt = null;
    ResultSet rs = null;
    long elapsedQueryTime = 0;
 
    try {
      int idx = 1;
      long startQueryTime = (new Date()).getTime();
      stmt = this.conn.prepareStatement(QUERY_SQL);
      stmt.setLong(idx++, aRequestId);
      stmt.setLong(idx++, anEvaluatorId);
      rs = stmt.executeQuery();
      if (rs != null && rs.next()) {
        int year = rs.getInt("YEAR_NUM"); 
        if (rs.wasNull())
          year = -1;
                   
        int newUsedFlag = rs.getInt("NEW_USED_FLG"); 
        if (rs.wasNull())
          newUsedFlag = 0;
          
        data = new CreditRequestAuto(year, rs.getString("AUTO_MAKE_DESCRIPTION_TXT"), 
          rs.getString("MODEL_TXT"), rs.getString("VIN_TXT"), rs.getString("COLOR_TXT"), 
          newUsedFlag == 1, rs.getBigDecimal("MILEAGE_VALUE_NUM")); 
      }
      
      long endQueryTime = (new Date()).getTime();
      elapsedQueryTime = endQueryTime - startQueryTime;
    }
    catch (SQLException ex) {
      throw new AppException("failed to query REQUESTOR_BUREAU_HEADER " +
        "for request ID=" + aRequestId + ", evaluator ID=" + anEvaluatorId, ex);
    }
    finally {
		try{ if(rs != null) rs.close(); }catch(Exception e1){e1.printStackTrace();}
		try{ if(stmt != null) stmt.close(); }catch(Exception e1){e1.printStackTrace();}
	}
    
    AppLogger.logger.log(Level.FINEST, Thread.currentThread().getName() + 
      ": queried " + 1 + " CreditRequestAuto object in " + elapsedQueryTime + " ms");    
    return data;
  }
}
