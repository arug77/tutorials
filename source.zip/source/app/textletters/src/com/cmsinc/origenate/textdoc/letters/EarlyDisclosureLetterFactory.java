package com.cmsinc.origenate.textdoc.letters;

import java.sql.Connection;

/**
 * Factory for selecting credit apps and creating <code>EarlyDisclosreLetter</code> instances.<br>
 * 
 * Treat this class as "thread-hostile".
 * 
 * @since Origenate 8.5
 */
public class EarlyDisclosureLetterFactory extends LetterFactory 
{

	/**
	 * To select Expired apps: 
	 * 
	 * The application must have a an app status of 20 (expired).
	 * similar to Nightly Letters, we exclude apps older than 90
	 * days to reduce the result set.
	 */  
	private static final String EARLY_DISCLOSURE_SELECT_LIST = 
	"0 as delay_days, ev.welcome_printer_txt as printer_text";
	
	private static final String EARLY_DISCLOSURE_WHERE_CLAUSE =     
	" cr.product_id in (16,17) and cr.app_signed_dt is not null and ev.evaluator_id = cps.evaluator_id ";
    
	public static final String LETTER_CATEGORY = "EARLY_DISCLOSURE_DOCUMENT";
   
	protected String getLetterCategory() 
	{
		return LETTER_CATEGORY;
	}
  
	/**
	 * Restricted ctor for creating an instance of this class.
	 *  
	 * @param someEvaluatorIds
	 *  evaluators to search by, or null to search regardless of evaluator.
	 */
	public EarlyDisclosureLetterFactory(Connection aConnection, long[] someEvaluatorIds) 
	{
		super(aConnection, LETTER_CATEGORY, someEvaluatorIds);
	}
  
	protected StringBuffer selectList() 
	{
		StringBuffer buf = super.selectList();
		buf = appendCharIfNeeded(buf, ',');
		buf.append(EARLY_DISCLOSURE_SELECT_LIST);
		return buf;
	}
  
	protected StringBuffer fromClause() 
	{
		StringBuffer buf = super.fromClause();		
		return buf;
	}  
  
	protected StringBuffer whereClause() 
	{
		StringBuffer buf = super.whereClause();
		buf = appendWordIfNeeded(buf, "AND");
		buf.append(EARLY_DISCLOSURE_WHERE_CLAUSE);
		return buf;
	}  
}
