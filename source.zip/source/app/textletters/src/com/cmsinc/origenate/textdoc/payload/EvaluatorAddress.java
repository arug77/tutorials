package com.cmsinc.origenate.textdoc.payload;

/**
 * Data about an evaluator address.<br>
 * 
 * Treat this class as "thread-safe", since it is immutable once created.
 * 
 * @since Origenate 6.0
 */
public class EvaluatorAddress {
  
  private String addrLine1 = null;
  private String addrLine2 = null;
  private String city = null;
  private String state = null;
  private String zipcode = null;
  private String phone = null;
  private String fax = null;
  
  EvaluatorAddress(String anAddrLine1, String anAddrLine2, String aCity, String aState,
    String aZipcode, String aPhone, String aFax) {
  	this.addrLine1 = anAddrLine1;
  	this.addrLine2 = anAddrLine2;
  	this.city = aCity;
  	this.state = aState;
  	this.zipcode = aZipcode;
  	this.phone = aPhone;
  	this.fax = aFax;
  }
  
  public String getAddress1() {
    return this.addrLine1;
  }

  public String getAddress2() {
    return this.addrLine2;
  }
  
  public String getCity() {
    return this.city;
  }
  
  public String getState() {
    return this.state;
  }  
  
  public String getZipCode() {
    return this.zipcode;
  }

  public String getPhone() {
    return this.phone;
  }
  
  public String getFax() {
    return this.fax;
  }   
}
