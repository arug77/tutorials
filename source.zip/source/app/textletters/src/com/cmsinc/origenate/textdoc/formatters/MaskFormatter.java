package com.cmsinc.origenate.textdoc.formatters;

/**
 * Abstract base class for formatting a value with a mask, such as phone number or SSN.
 * 
 * @since Origenate 6.0
 */
public abstract class MaskFormatter {
  /**
   * Apply a simple formatting mask to a string value, e.g., the telephone mask 
   * "(???) ???-????" applied to "3014249088" yields "(301) 424-9088".<br>
   * 
   * Copied from <code>OriginatorAgingStats</code> JavaBean, should be kept in 
   * sync with code there.
   * 
   * @param aMask
   *   the mask, where "?" represents a character from the input string, anything else
   *   is taken as a literal. This simple version does not support an escape for
   *   a literal question mark. 
   * @param aFillChar
   *   character used to fill out mask if input string is shorter than number of
   *   question marks in mask.
   * @param aValue
   *   the input string the mask is applied to.
   * @return
   *   the formatted display string.
   * @see javax.swing.text.MaskFormatter
   */
  public static String applyDisplayMask(String aMask, char aFillChar, String aValue) {
    char[] chMask = aMask.toCharArray();
    char[] chValue = aValue == null ? "".toCharArray() : aValue.toCharArray();
    char[] chOutput = new char[Math.max(chMask.length, chValue.length)];
    int idxMask = 0, idxValue = 0, idxOutput = 0;
    
    for (;idxMask < chMask.length;idxMask++) {
      if (chMask[idxMask] == '?') {
        if (idxValue >= chValue.length)
          chOutput[idxOutput++] = aFillChar;
        else
          chOutput[idxOutput++] = chValue[idxValue++];
      }
      else
        chOutput[idxOutput++] = chMask[idxMask];
    }
    return new String(chOutput, 0, idxOutput);
  }
}
