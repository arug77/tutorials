package com.cmsinc.origenate.textdoc.payload;

/**
 * Data about a requestor business (business owned or controlled by applicant), including address.<br>
 * 
 * Treat this class as "thread-safe", since it is immutable once created.
 * 
 * @since Origenate 6.0
 */
public class RequestorBusiness {
  
  private long appSeqno = -1;
  private String businessName = null;
  private String officerName = null;
  private String officerTitle = null;
  private String address1 = null;
  private String address2 = null;
  private String city = null;
  private String state = null;
  private String zipcode = null;
  private String phone = null;
  private String phoneExt = null;
  
  RequestorBusiness(long anAppSeqno, String aBusinessName, String anOfficerName, String anOfficerTitle, 
    String anAddress1, String anAddress2, String aCity, String aState, String aZipcode, 
    String aPhone, String aPhoneExt) {

    this.appSeqno = anAppSeqno;
    this.businessName = aBusinessName;
    this.officerName = anOfficerName;
    this.officerTitle = anOfficerTitle;
    this.address1 = anAddress1;
    this.address2 = anAddress2;
    this.city = aCity;
    this.state = aState;
    this.zipcode = aZipcode;
    this.phone = aPhone;
    this.phoneExt = aPhoneExt;
  }
  
  public long getAppSeqno() {
    return this.appSeqno;
  }
  
  public String getBusinessName() {
    return this.businessName;
  }
  
  public String getOfficerName() {
    return this.officerName;
  }
  
  public String getOfficerTitle() {
    return this.officerTitle;
  }
  
  public String getAddress1() {
    return this.address1;
  }
  
  public String getAddress2() {
    return this.address2;
  }
  
  public String getCity() {
    return this.city;
  }
  
  public String getState() {
    return this.state;
  }
  
  public String getZipcode() {
    return this.zipcode;
  }
  
  public String getPhone() {
    return this.phone;
  }
  
  public String getPhoneExt() {
    return this.phoneExt;
  }
}
