package com.cmsinc.origenate.textdoc.payload;

/**
 * Data about reason the loan was denied.<br>
 * 
 * Treat this class as "thread-safe", since it is immutable once created.
 * 
 * @since Origenate 6.0
 */
public class TurndownReason {

  private long reasonId = -1;
  private long reasonTypeId = -1;
  private String text = null;
  private String description = null; 
  private String entity = null; 
  private boolean bureauRelated = false;
  
  public TurndownReason(long aReasonId, long aReasonTypeId, 
    String aReasonText, String aDescription, String aEntity, boolean bureauRelated) {
    this.reasonId = aReasonId;
    this.reasonTypeId = aReasonTypeId;
    this.text = aReasonText;
    this.description = aDescription;
	this.entity = aEntity;
    this.bureauRelated = bureauRelated;
  }
  
  public long getReasonId() {
    return this.reasonId;
  }
  
  public long getReasonTypeId() {
    return this.reasonTypeId;
  }  
  
  public String getText() {
    return this.text;
  }
  
  public String getDescription() {
    return this.description;
  }
  
  public String getEntity() {
    return this.entity;
  }
  
  public boolean isBureauRelated() {
	    return this.bureauRelated;
	  }
}
