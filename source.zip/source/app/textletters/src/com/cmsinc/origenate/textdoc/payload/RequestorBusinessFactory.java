package com.cmsinc.origenate.textdoc.payload;

import java.util.Date;
import java.util.LinkedList;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import com.cmsinc.origenate.textdoc.AppLogger;
import com.cmsinc.origenate.textdoc.AppException;

/**
 * Simple factory class for creating instances of <code>RequestorBusiness</code> 
 * by quering the database.<br>
 * 
 * Treat this class as "thread-hostile".<br>
 * 
 * @since Origenate 6.0
 */
public class RequestorBusinessFactory {
  private static final String QUERY_SQL = 
    "SELECT rb.APPSEQNO, rb.BUSINESS_NAME_TXT, rb.PHONE_NUMBER_TXT, rb.PHONE_EXTENSION_TXT, " +
    "       ra.ADDRESS1_TXT, ra.ADDRESS2_TXT, ra.STATE_ID, ra.CITY_TXT, ra.ZIPCODE_TXT, " +
    "       ro.OFFICER_NAME_TXT, ro.OFFICER_TITLE_TXT, " +
	"		ra.STREET_NUMBER_TXT, ra.STREET_NAME_TXT, ra.STREET_TYPE_ID, mt.STREET_TYPE_DESCRIPTION_TXT, ra.STREET_DIR_CODE_TXT, ra.APT_SUITE_BOX_TXT "+ //163716 
    "FROM REQUESTOR_BUSINESS rb, REQUESTOR_BUSINESS_ADDRESS ra, REQUESTOR_BUSINESS_OFFICERS ro, MSTR_STREET_TYPE mt " +
    "WHERE rb.REQUEST_ID = ? AND rb.REQUESTOR_ID = ? AND " +
    "      rb.REQUEST_ID = ra.REQUEST_ID (+) AND " +
    "      rb.REQUESTOR_ID = ra.REQUESTOR_ID (+) AND " +
    "      rb.REQUEST_ID = ro.REQUEST_ID (+) AND " +
    "      rb.REQUESTOR_ID = ro.REQUESTOR_ID (+) " +
	"	   AND ra.STREET_TYPE_ID = mt.STREET_TYPE_ID (+) ";

  private Connection conn = null;
  
  public RequestorBusinessFactory(Connection aConnection) {
    this.conn = aConnection;
  }
  
  public RequestorBusiness[] getRequestorBusinesses(long aRequestId, long anRequestorId) throws AppException {
 
	LinkedList list = new LinkedList();
    PreparedStatement stmt = null;
    ResultSet rs = null;
    long elapsedQueryTime = 0;
    
    try {
      int idx = 1;
      long startQueryTime = (new Date()).getTime();
      stmt = this.conn.prepareStatement(QUERY_SQL);
      stmt.setLong(idx++, aRequestId);
      stmt.setLong(idx++, anRequestorId);
      rs = stmt.executeQuery();
	  
      while (rs != null && rs.next()) {
	 
        long appSeqno = rs.getLong("APPSEQNO");
        if (rs.wasNull())
          appSeqno = -1; 
		  
		//cl163716 if the already concatenated address exists, use that for the text letter, otherwise concatenate the parsed business address fields into a single address string and include it in the file.
		String addressLine1Text = "";
		String addressLine1Text_concat = rs.getString("ADDRESS1_TXT");
		String addressLine1Text_parsed = createAddressLineString(rs.getString("STREET_NUMBER_TXT"),rs.getString("STREET_NAME_TXT"),rs.getString("STREET_TYPE_DESCRIPTION_TXT"),rs.getString("STREET_DIR_CODE_TXT"),rs.getString("APT_SUITE_BOX_TXT"));
		
		if(addressLine1Text_concat !=null && addressLine1Text_concat.length()>0){
			addressLine1Text = addressLine1Text_concat;
		}
		else if(addressLine1Text_parsed !=null && addressLine1Text_parsed.length()>0){
			addressLine1Text = addressLine1Text_parsed;
		}
         
        RequestorBusiness data = new RequestorBusiness(appSeqno, rs.getString("BUSINESS_NAME_TXT"), 
          rs.getString("OFFICER_NAME_TXT"), rs.getString("OFFICER_TITLE_TXT"), 
          addressLine1Text, rs.getString("ADDRESS2_TXT"), rs.getString("CITY_TXT"), 
          rs.getString("STATE_ID"), rs.getString("ZIPCODE_TXT"), 
          rs.getString("PHONE_NUMBER_TXT"), rs.getString("PHONE_EXTENSION_TXT"));
        list.add(data);
      }
      
      long endQueryTime = (new Date()).getTime();
      elapsedQueryTime = endQueryTime - startQueryTime;
    }
    catch (SQLException ex) {
      throw new AppException("failed to query REQUESTOR_BUSINESS / REQUESTOR_BUSINESS_ADDRESS " +
        "for request ID=" + aRequestId + " and evaluator ID=" + anRequestorId, ex);
    }
    finally {
		try{ if(rs != null) rs.close(); }catch(Exception e1){e1.printStackTrace();}
		try{ if(stmt != null) stmt.close(); }catch(Exception e1){e1.printStackTrace();}
	}
    
    AppLogger.logger.log(Level.FINEST, Thread.currentThread().getName() + 
      ": queried " + list.size() + " RequestorBusiness objects in " + elapsedQueryTime + " ms");
    
    RequestorBusiness[] arrData = null;
    if (list.size() > 0)
      arrData = (RequestorBusiness[]) list.toArray(new RequestorBusiness[0]);
    return arrData;
  }
  
  //method createAddressLineString to concatenate the parsed address
  private static String createAddressLineString(String streetNum, String streetName, String streetType, String streetDir, String streetExtra){
	String addressLine1 = "";
	if(streetNum != null && streetNum.length()>0){
		addressLine1 += streetNum;
	}
	if(streetName != null && streetName.length()>0){
		if(addressLine1.length()>0) addressLine1 +=" ";
		addressLine1 += streetName;
	}
	if(streetType != null && streetType.length()>0){
		if(addressLine1.length()>0) addressLine1 +=" ";
		addressLine1 += streetType;
	}
	if(streetDir != null && streetDir.length()>0){
		if(addressLine1.length()>0) addressLine1 +=" ";
		addressLine1 += streetDir;
	}
	if(streetExtra != null && streetExtra.length()>0){
		if(addressLine1.length()>0) addressLine1 +=" ";
		addressLine1 += streetExtra;
	}
	return addressLine1; 
  }

  
}
