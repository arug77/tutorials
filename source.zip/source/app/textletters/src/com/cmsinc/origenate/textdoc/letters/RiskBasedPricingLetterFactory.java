package com.cmsinc.origenate.textdoc.letters;

import java.sql.Connection;

/**
 * Factory for selecting credit apps and creating <code>RiskBasedPricingLetter</code> instances.<br>
 * 
 * Treat this class as "thread-hostile".
 * 
 * @since Origenate 8.5
 */
public class RiskBasedPricingLetterFactory extends LetterFactory 
{

	/**
	 * To select Expired apps: 
	 * 
	 * The application must have a an app status of 20 (expired).
	 * similar to Nightly Letters, we exclude apps older than 90
	 * days to reduce the result set.
	 */  
		
	private static final String RISK_BASED_PRICING_SELECT_LIST = 
	"cps.turndown_delay_days_num delay_days, '' '' AS printer_text";
	
	private static final String RISK_BASED_PRICING_WHERE_CLAUSE =     
	"cr.decision_status_id in (1,3,2,101)";
    
	public static final String LETTER_CATEGORY = "RISK_BASED_PRICING_LETTER";
   
	protected String getLetterCategory() 
	{
		return LETTER_CATEGORY;
	}
  
	/**
	 * Restricted ctor for creating an instance of this class.
	 *  
	 * @param someEvaluatorIds
	 *  evaluators to search by, or null to search regardless of evaluator.
	 */
	public RiskBasedPricingLetterFactory(Connection aConnection, long[] someEvaluatorIds) 
	{
		super(aConnection, LETTER_CATEGORY, someEvaluatorIds);
	}
  
	protected StringBuffer selectList() 
	{
		StringBuffer buf = super.selectList();
		buf = appendCharIfNeeded(buf, ',');
		buf.append(RISK_BASED_PRICING_SELECT_LIST);
		return buf;
	}
  
	protected StringBuffer fromClause() 
	{
		StringBuffer buf = super.fromClause();		
		return buf;
	}  
  
	protected StringBuffer whereClause() 
	{
		StringBuffer buf = super.whereClause();
		buf = appendWordIfNeeded(buf, "AND");
		buf.append(RISK_BASED_PRICING_WHERE_CLAUSE);
		return buf;
	}  
}
