package com.cmsinc.origenate.textdoc;

/**
 * Abstract base class for managing threads.
 * 
 * Treat this class as "thread-hostile"; it should be invoked from main thread.
 * 
 * @since Origenate 6.0
 */
public abstract class ThreadManager {
  protected ThreadGroup threadGroup = null;
  protected Thread[] threads = null;
  
  protected ThreadManager(ThreadGroup aThreadGroup, Thread[] someThreads) {
    this.threads = someThreads;
    this.threadGroup = aThreadGroup;
  }
  
  abstract void run();
}
