package com.cmsinc.origenate.textdoc.formatters;

import com.cmsinc.origenate.textdoc.AppException;

/**
 * Interface that defines simple API for formatting document field values.
 * 
 * @since Origenate 6.0 
 */
public interface FieldFormatter {
  /**
   * Format the field value into a string.
   * 
   * @param aValue
   *   the field value to format. This can be null, and can be of different object types,
   *   such as <code>String</code>, <code>Date</code>, <code>Integer</code>, <code>BigDecimal</code>, etc. 
   *   The formatter should attempt to convert accordingly, but may throw an exception if 
   *   a type is not supported.
   * @return
   *   the formatted field value as a non-null string.
   * @throws AppException
   *   if an error occurs during formatting.
   */
  public String format(Object aValue) throws AppException;
}
