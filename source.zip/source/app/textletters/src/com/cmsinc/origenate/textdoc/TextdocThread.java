package com.cmsinc.origenate.textdoc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;

import javax.sql.RowSet;
import java.io.File;
import java.util.ArrayList;
import java.util.Date;
import java.util.Map;
import java.util.TreeMap;
import java.util.logging.Level;
import com.cmsinc.origenate.textdoc.letters.Letter;
import com.cmsinc.origenate.textdoc.letters.LetterIterator;
import com.cmsinc.origenate.textdoc.letters.LetterFactory;
import com.cmsinc.origenate.textdoc.payload.CreditRequestAuto;
import com.cmsinc.origenate.textdoc.payload.CreditRequestAutoFactory;
import com.cmsinc.origenate.textdoc.payload.CreditRequestDecision;
import com.cmsinc.origenate.textdoc.payload.CreditRequestDecisionFactory;
import com.cmsinc.origenate.textdoc.payload.CreditRequestFinance;
import com.cmsinc.origenate.textdoc.payload.CreditRequestFinanceFactory;
import com.cmsinc.origenate.textdoc.payload.EvaluatorAddress;
import com.cmsinc.origenate.textdoc.payload.EvaluatorAddressFactory;
import com.cmsinc.origenate.textdoc.payload.Bureau;
import com.cmsinc.origenate.textdoc.payload.BureauFactory;
import com.cmsinc.origenate.textdoc.payload.BureauScore;
import com.cmsinc.origenate.textdoc.payload.BureauScoreFactory;
import com.cmsinc.origenate.textdoc.payload.BureauRBP;
import com.cmsinc.origenate.textdoc.payload.BureauRBPFactory;
import com.cmsinc.origenate.textdoc.payload.BranchOrDealer;
import com.cmsinc.origenate.textdoc.payload.BranchOrDealerFactory;
import com.cmsinc.origenate.textdoc.payload.Center;
import com.cmsinc.origenate.textdoc.payload.CenterFactory;
import com.cmsinc.origenate.textdoc.payload.Requestor;
import com.cmsinc.origenate.textdoc.payload.RequestorFactory;
import com.cmsinc.origenate.textdoc.payload.RequestorBusiness;
import com.cmsinc.origenate.textdoc.payload.RequestorBusinessFactory;
import com.cmsinc.origenate.textdoc.payload.Secured;
import com.cmsinc.origenate.textdoc.payload.SecuredFactory;
import com.cmsinc.origenate.textdoc.payload.TurndownReason;
import com.cmsinc.origenate.textdoc.payload.TurndownReasonFactory;
import com.cmsinc.origenate.textdoc.payload.LoanPurpose;
import com.cmsinc.origenate.textdoc.payload.LoanPurposeFactory;
import com.cmsinc.origenate.textdoc.payload.Stipulation;
import com.cmsinc.origenate.textdoc.payload.StipulationFactory;
import com.cmsinc.origenate.textdoc.sources.CachingQueryEvaluator;
import com.cmsinc.origenate.textdoc.sources.WhenToUseQueryFactory;
import com.cmsinc.origenate.textdoc.sinks.CreditReqDocHistory;
import com.cmsinc.origenate.textdoc.sinks.CreditReqDocHistoryFactory;
import com.cmsinc.origenate.textdoc.sinks.CreditRequestJournal;
import com.cmsinc.origenate.textdoc.sinks.CreditRequestJournalFactory;
import com.cmsinc.origenate.workflow.ApplicationIDs;
import com.cmsinc.origenate.util.Query;

public class TextdocThread extends Thread {
  private static final int REQUESTOR_APPLICANT = 0;
  private static final int REQUESTOR_COAPPLICANT = 1;
  private static final int REQUESTOR_COSIGNER = 2;
  private static final int REQUESTOR_BUSINESS = 3;
  
  private static final int ORIGINATOR_DEALER = 1;
  private static final int ORIGINATOR_BRANCH = 2;
  
  private static final int SUBMIT_REASON_TURNDOWN_LETTER = 5;
  private static final int SUBMIT_REASON_COUNTER_LETTER = 6;
  private static final int SUBMIT_REASON_WELCOME_LETTER = 7;
  private static final int SUBMIT_REASON_EXPIRED_LETTER = 8;
  private static final int SUBMIT_REASON_GEN_NOTIFICATION_LETTER = 29;
  private static final int SUBMIT_REASON_WITHDRAW_LETTER = 18;
  private static final int SUBMIT_REASON_CLOSING_LETTER = 12;
  private static final int SUBMIT_REASON_FIRST_PAYMENT_LETTER = 9;
  private static final int SUBMIT_REASON_RISK_BASED_PRICING_LETTER = 26;
  private static final int SUBMIT_REASON_MISSING_INFO_LETTER = 22;
  private static final int SUBMIT_REASON_EARLY_DISCLOSURE_LETTER = 14;
  private static final int SUBMIT_REASON_INITIAL_LETTER = 19;
  private static final int SUBMIT_REASON_FOLLOW_UP_1_LETTER = 20;
  private static final int SUBMIT_REASON_FOLLOW_UP_2_LETTER = 21;
   
  private static final int JOURNAL_EVENT_LETTER = 28;
  
  private int CRDOCHISTORY_SUBMIT_REASON = SUBMIT_REASON_TURNDOWN_LETTER;
  private static final String CRDOCHISTORY_USER = ApplicationIDs.sysuser;
  private static final String CRDOCHISTORY_STATUS = "SUCCESS";
  private static final String CRDOCHISTORY_JOB_TYPE = "TEXTLETTERS";
  
  private static final long CRJOURNAL_EVENT_ID = JOURNAL_EVENT_LETTER;
  private static final String CRJOURNAL_EVENT = "ADVERSE ACTION: LETTERTYPE Letter (DOCUMENTNAME) Sent - DATE to REQUESTORS";
  private static final String CRJOURNAL_USER = ApplicationIDs.sysuser;
  
  private static final int AUDIT_TRAIL_BATCH_SIZE = 1;  // GL. was 50, but now we want to commit as we go
  
  private Connection conn = null;
  
  private LetterFactory letterFactory = null;
  
  private String outputLetterType = null;
  
  private long[] decisionIds = null;
 
  private long[] evaluatorIds = null;
  
  private String outputDir = null;
	
  //private ConfigInfo configInfo = null; 
  
  private boolean checkDefaultFlag = false;
  
  private boolean useTurndownDescriptionFlag = false;
  
  //private boolean showAllBureausFlag = false;
  
  private boolean showOnlyTurndownReasonsFlag = false;
  
  private boolean hideSSNFlag = false;
    
  TextdocThread(ThreadGroup aThreadGroup, Connection aConnection, LetterFactory aLetterFactory, 
    String outputLetterType, long[] someDecisionIds, long[] someEvaluatorIds, String anOutputDir, 
    ConfigInfo aConfigInfo, boolean checkDefaultFlag, boolean useTurndownDescriptionFlag, boolean showAllBureaus, boolean showOnlyTurndownReasonsFlag, boolean hideSSNFlag) {
      
    super(aThreadGroup, outputLetterType + "-" + (new Date().getTime() % 1000));
    this.checkDefaultFlag = checkDefaultFlag;
    this.useTurndownDescriptionFlag = useTurndownDescriptionFlag;
    //this.showAllBureausFlag=showAllBureaus;
    this.showOnlyTurndownReasonsFlag = showOnlyTurndownReasonsFlag;
    this.conn = aConnection;
    this.letterFactory = aLetterFactory;
    this.outputLetterType = outputLetterType;
    this.decisionIds = someDecisionIds;
    this.evaluatorIds = someEvaluatorIds;
    this.outputDir = anOutputDir;
    //this.configInfo = aConfigInfo;
	this.hideSSNFlag = hideSSNFlag;
	     
    
    if (outputLetterType.equals(OutputFileFactory.COUNTER_OFFER))
        this.CRDOCHISTORY_SUBMIT_REASON = SUBMIT_REASON_COUNTER_LETTER;
    if (outputLetterType.equals(OutputFileFactory.WELCOME))
        this.CRDOCHISTORY_SUBMIT_REASON = SUBMIT_REASON_WELCOME_LETTER;
	if (outputLetterType.equals(OutputFileFactory.EXPIRED))
		this.CRDOCHISTORY_SUBMIT_REASON = SUBMIT_REASON_EXPIRED_LETTER;
	if (outputLetterType.equals(OutputFileFactory.GEN_NOTIFICATION))
		this.CRDOCHISTORY_SUBMIT_REASON = SUBMIT_REASON_GEN_NOTIFICATION_LETTER;
    if (outputLetterType.equals(OutputFileFactory.WITHDRAW))
		this.CRDOCHISTORY_SUBMIT_REASON = SUBMIT_REASON_WITHDRAW_LETTER;
	if (outputLetterType.equals(OutputFileFactory.CLOSING))
		this.CRDOCHISTORY_SUBMIT_REASON = SUBMIT_REASON_CLOSING_LETTER;
	if (outputLetterType.equals(OutputFileFactory.FIRST_PAYMENT))
		this.CRDOCHISTORY_SUBMIT_REASON = SUBMIT_REASON_FIRST_PAYMENT_LETTER;
	if (outputLetterType.equals(OutputFileFactory.RISK_BASED_PRICING))
		this.CRDOCHISTORY_SUBMIT_REASON = SUBMIT_REASON_RISK_BASED_PRICING_LETTER;
	if (outputLetterType.equals(OutputFileFactory.MISSING_INFO))
		this.CRDOCHISTORY_SUBMIT_REASON = SUBMIT_REASON_MISSING_INFO_LETTER;
	if (outputLetterType.equals(OutputFileFactory.EARLY_DISCLOSURE_DOCUMENT))
		this.CRDOCHISTORY_SUBMIT_REASON = SUBMIT_REASON_EARLY_DISCLOSURE_LETTER;
	if (outputLetterType.equals(OutputFileFactory.INITIAL))
		this.CRDOCHISTORY_SUBMIT_REASON = SUBMIT_REASON_INITIAL_LETTER;
	if (outputLetterType.equals(OutputFileFactory.FOLLOW_UP_1))
		this.CRDOCHISTORY_SUBMIT_REASON = SUBMIT_REASON_FOLLOW_UP_1_LETTER;
	if (outputLetterType.equals(OutputFileFactory.FOLLOW_UP_2))
		this.CRDOCHISTORY_SUBMIT_REASON = SUBMIT_REASON_FOLLOW_UP_2_LETTER;
    
    setDaemon(true);
  }
  
  public void run() {
    AppLogger.logger.entering(getClass().getName(), "run", Thread.currentThread().getName());
    LetterIterator letterIterator = null;
    boolean isGood = false;
    
    try {
  	  if ((letterIterator = letterFactory.queryLetters()) != null) {
		int extractCount = processLetters(this.conn, this.outputLetterType, letterIterator, decisionIds);    
        if(extractCount ==0){//config exists but no letters to generate
        	generateBlankFile(this.outputLetterType, this.evaluatorIds);
        }
        isGood = true;
      }
  	  else{ //config doesnt exist - generate blank file
  		generateBlankFile(this.outputLetterType, this.evaluatorIds); // generate blank files for letters with no configuration
  		isGood = true;
  	  }
  	  
    }
    catch (Throwable ex) {
      AppLogger.logger.log(Level.SEVERE, "error occurred processing " + this.outputLetterType + " letters", ex);
    }
    finally {
      try {
      	if (letterIterator != null)
          letterIterator.dispose();
          
        if (isGood)
          this.conn.commit();
        else{
        	TextdocApp.failedToGenerateTextDoc(); //if one of the letters failed to generate we want to set the flag to indicate not to generate a .ready file for the overall process completion
			this.conn.rollback();
        }
      	this.conn.close();
      }
      catch (SQLException ex) {
      	AppLogger.logger.log(Level.SEVERE, "failed to either commit or rollback, or to close database resources", ex);
      }
    }

    AppLogger.logger.exiting(getClass().getName(), "run", Thread.currentThread().getName());    
  }

  private int processLetters(Connection aConnection, String anOutputLetterType, 
    LetterIterator aLetterIterator, long[] someDecisionIdsInPreferredOrder) throws AppException {

    OutputFileFactory outputFileFactory = OutputFileFactory.getInstance(this.outputDir);
    CreditReqDocHistoryFactory historyFactory = new CreditReqDocHistoryFactory(aConnection, AUDIT_TRAIL_BATCH_SIZE);
    CreditRequestJournalFactory journalFactory = new CreditRequestJournalFactory(aConnection, AUDIT_TRAIL_BATCH_SIZE);
    CachingQueryEvaluator cachingEvaluator = new CachingQueryEvaluator();
    long previousRequestId = -1;
    int extractedRecordCount = 0;

    while (aLetterIterator.hasNext()) {

      //
      // Get the next letter to send to the extract file. We used the values in
      // the letter object to drive the queries below that collect the many
      // extract field values not stored in the letter object.
      
      Letter letter = (Letter) aLetterIterator.next();
      if (letter == null)
        break;
      
      // Letter must pass when-to-use criteria to be output to extract file.
      
      OutputFileFactory.OutputFile outFile = outputFileFactory.getFile(
    	        letter.getEvaluatorName(), anOutputLetterType, letter.getDocumentType());
      if (outFile == null)
        throw new IllegalStateException("unexpected error, output file obtained via factory should not be null");
      
      if (!doesLetterPassWhenToUseCriteria(aConnection, cachingEvaluator, letter))
    	  continue;
     
      // Place all fields in a map, sorted by ordinal position. Then start 
      // extracting data fields from various sources.
       
      Map fieldMap = new TreeMap();
      fieldMap.put(ExtractField.CLIENT_APPL_ID, Long.valueOf(letter.getClientAppId()));
      fieldMap.put(ExtractField.INITIATION_DATE, letter.getInitiationDate());
      
      extractEvaluatorAddress(aConnection, letter, fieldMap); 
      
      BranchOrDealerFactory factoryBranchOrDealer = new BranchOrDealerFactory(aConnection);
      BranchOrDealer[] allBranchOrDealers = factoryBranchOrDealer.getBranchesOrDealers(
        letter.getRequestId(), letter.getEvaluatorId());
      BranchOrDealer branchOrDealer = null;
      if (allBranchOrDealers != null && allBranchOrDealers.length > 0)
        branchOrDealer = allBranchOrDealers[0];
      
      String evalOrigName = branchOrDealer == null ? null : branchOrDealer.getOriginatorName();
      String evalDbaName =  branchOrDealer == null ? null : branchOrDealer.getDBAName();
      fieldMap.put(ExtractField.EVALORIG_ORIGINATOR_NAME, evalOrigName);
      fieldMap.put(ExtractField.EVALORIG_DBA_NAME, evalDbaName);
      
      RequestorFactory factoryRequestor = new RequestorFactory(aConnection);
      Requestor[] allRequestors = factoryRequestor.getRequestors(
        letter.getRequestId(), letter.getEvaluatorId());
      
      Requestor requestor = findRequestor(REQUESTOR_APPLICANT, 1, allRequestors);
      addRequestorFields(requestor, fieldMap, new ExtractField[] {
        ExtractField.APPLICANT_LASTNAME, ExtractField.APPLICANT_FIRSTNAME, 
        ExtractField.APPLICANT_MIDDLENAME, ExtractField.APPLICANT_NAMESUFFIX, 
        ExtractField.APPLICANT_SSN, ExtractField.APPLICANT_STREETNUMBER, 
        ExtractField.APPLICANT_STREETNAME, ExtractField.APPLICANT_TYPEOFSTREET, 
        ExtractField.APPLICANT_APARTMENTBOXORSUITE, ExtractField.APPLICANT_ADDRESS2, 
        ExtractField.APPLICANT_CITY, ExtractField.APPLICANT_STATE, 
        ExtractField.APPLICANT_ZIPCODE, ExtractField.APPLICANT_PHONE, 
        ExtractField.APPLICANT_PHONEEXT, ExtractField.APPLICANT_FAX
      } );
      
      requestor = findRequestor(REQUESTOR_COAPPLICANT, 1, allRequestors);
      addRequestorFields(requestor, fieldMap, new ExtractField[] {
        ExtractField.COAPPLICANT_LASTNAME, ExtractField.COAPPLICANT_FIRSTNAME, 
        ExtractField.COAPPLICANT_MIDDLENAME, ExtractField.COAPPLICANT_NAMESUFFIX, 
        ExtractField.COAPPLICANT_SSN, ExtractField.COAPPLICANT_STREETNUMBER, 
        ExtractField.COAPPLICANT_STREETNAME, ExtractField.COAPPLICANT_TYPEOFSTREET, 
        ExtractField.COAPPLICANT_APARTMENTBOXORSUITE, ExtractField.COAPPLICANT_ADDRESS2, 
        ExtractField.COAPPLICANT_CITY, ExtractField.COAPPLICANT_STATE, 
        ExtractField.COAPPLICANT_ZIPCODE, ExtractField.COAPPLICANT_PHONE, 
        ExtractField.COAPPLICANT_PHONEEXT, ExtractField.COAPPLICANT_FAX
      } );
	  
	  requestor = findRequestor(REQUESTOR_COAPPLICANT, 2, allRequestors);
      addRequestorFields(requestor, fieldMap, new ExtractField[] {
        ExtractField.COAPPLICANT2_LASTNAME, ExtractField.COAPPLICANT2_FIRSTNAME, 
        ExtractField.COAPPLICANT2_MIDDLENAME, ExtractField.COAPPLICANT2_NAMESUFFIX, 
        ExtractField.COAPPLICANT2_SSN, ExtractField.COAPPLICANT2_STREETNUMBER, 
        ExtractField.COAPPLICANT2_STREETNAME, ExtractField.COAPPLICANT2_TYPEOFSTREET, 
        ExtractField.COAPPLICANT2_APARTMENTBOXORSUITE, ExtractField.COAPPLICANT2_ADDRESS2, 
        ExtractField.COAPPLICANT2_CITY, ExtractField.COAPPLICANT2_STATE, 
        ExtractField.COAPPLICANT2_ZIPCODE, ExtractField.COAPPLICANT2_PHONE, 
        ExtractField.COAPPLICANT2_PHONEEXT, ExtractField.COAPPLICANT2_FAX
      } );
      
      requestor = findRequestor(REQUESTOR_COSIGNER, 1, allRequestors);
      addRequestorFields(requestor, fieldMap, new ExtractField[] {
        ExtractField.COSIGNER1_LASTNAME, ExtractField.COSIGNER1_FIRSTNAME, 
        ExtractField.COSIGNER1_MIDDLENAME, ExtractField.COSIGNER1_NAMESUFFIX, 
        ExtractField.COSIGNER1_SSN, ExtractField.COSIGNER1_STREETNUMBER, 
        ExtractField.COSIGNER1_STREETNAME, ExtractField.COSIGNER1_TYPEOFSTREET, 
        ExtractField.COSIGNER1_APARTMENTBOXORSUITE, ExtractField.COSIGNER1_ADDRESS2, 
        ExtractField.COSIGNER1_CITY, ExtractField.COSIGNER1_STATE, 
        ExtractField.COSIGNER1_ZIPCODE, ExtractField.COSIGNER1_PHONE, 
        ExtractField.COSIGNER1_PHONEEXT, ExtractField.COSIGNER1_FAX
      } );   
      
      requestor = findRequestor(REQUESTOR_COSIGNER, 2, allRequestors);
      addRequestorFields(requestor, fieldMap, new ExtractField[] {
        ExtractField.COSIGNER2_LASTNAME, ExtractField.COSIGNER2_FIRSTNAME, 
        ExtractField.COSIGNER2_MIDDLENAME, ExtractField.COSIGNER2_NAMESUFFIX, 
        ExtractField.COSIGNER2_SSN, ExtractField.COSIGNER2_STREETNUMBER, 
        ExtractField.COSIGNER2_STREETNAME, ExtractField.COSIGNER2_TYPEOFSTREET, 
        ExtractField.COSIGNER2_APARTMENTBOXORSUITE, ExtractField.COSIGNER2_ADDRESS2, 
        ExtractField.COSIGNER2_CITY, ExtractField.COSIGNER2_STATE, 
        ExtractField.COSIGNER2_ZIPCODE, ExtractField.COSIGNER2_PHONE, 
        ExtractField.COSIGNER2_PHONEEXT, ExtractField.COSIGNER2_FAX
      } );
      
      requestor = findRequestor(REQUESTOR_COSIGNER, 3, allRequestors);
      addRequestorFields(requestor, fieldMap, new ExtractField[] {
        ExtractField.COSIGNER3_LASTNAME, ExtractField.COSIGNER3_FIRSTNAME, 
        ExtractField.COSIGNER3_MIDDLENAME, ExtractField.COSIGNER3_NAMESUFFIX, 
        ExtractField.COSIGNER3_SSN, ExtractField.COSIGNER3_STREETNUMBER, 
        ExtractField.COSIGNER3_STREETNAME, ExtractField.COSIGNER3_TYPEOFSTREET, 
        ExtractField.COSIGNER3_APARTMENTBOXORSUITE, ExtractField.COSIGNER3_ADDRESS2, 
        ExtractField.COSIGNER3_CITY, ExtractField.COSIGNER3_STATE, 
        ExtractField.COSIGNER3_ZIPCODE, ExtractField.COSIGNER3_PHONE, 
        ExtractField.COSIGNER3_PHONEEXT, ExtractField.COSIGNER3_FAX
      } );
      
      requestor = findRequestor(REQUESTOR_COSIGNER, 4, allRequestors);
      addRequestorFields(requestor, fieldMap, new ExtractField[] {
        ExtractField.COSIGNER4_LASTNAME, ExtractField.COSIGNER4_FIRSTNAME, 
        ExtractField.COSIGNER4_MIDDLENAME, ExtractField.COSIGNER4_NAMESUFFIX, 
        ExtractField.COSIGNER4_SSN, ExtractField.COSIGNER4_STREETNUMBER, 
        ExtractField.COSIGNER4_STREETNAME, ExtractField.COSIGNER4_TYPEOFSTREET, 
        ExtractField.COSIGNER4_APARTMENTBOXORSUITE, ExtractField.COSIGNER4_ADDRESS2, 
        ExtractField.COSIGNER4_CITY, ExtractField.COSIGNER4_STATE, 
        ExtractField.COSIGNER4_ZIPCODE, ExtractField.COSIGNER4_PHONE, 
        ExtractField.COSIGNER4_PHONEEXT, ExtractField.COSIGNER4_FAX
      } );   
      
      RequestorBusiness requestorBiz = extractRequestorBusiness(aConnection, letter, allRequestors, fieldMap);
      extractAuto(aConnection, letter, fieldMap);
      extractSecured(aConnection, letter, fieldMap);
      
      CreditRequestDecisionFactory factoryDecision = new CreditRequestDecisionFactory(aConnection); 
      CreditRequestDecision[] allDecisions = factoryDecision.getDecisions(letter.getRequestId(), letter.getEvaluatorId());
      CreditRequestDecision decision = findDecision(someDecisionIdsInPreferredOrder, allDecisions);
      if (decision == null && allDecisions != null && allDecisions.length > 0)
        decision = allDecisions[0];
      extractDealStructure(aConnection, letter, decision, fieldMap);

      boolean wasDeclinedDueToBureau = decision != null && 
        decision.getDecisionId() == TextdocApp.DECISION_DECLINED_BY_SCORE;
      extractTurndownReasons(aConnection, letter, fieldMap, decision);
      extractBureau(aConnection, letter, wasDeclinedDueToBureau, allRequestors, fieldMap);
      extractBuyingCenter(aConnection, letter, fieldMap);
      
      addBranchOrDealerFields(
        branchOrDealer == null || branchOrDealer.getOriginatorTypeId() == ORIGINATOR_DEALER ? 
          null : branchOrDealer, fieldMap, 
        new ExtractField[] { 
          ExtractField.BRANCH_NAME, ExtractField.BRANCH_ADDRESS1, ExtractField.BRANCH_ADDRESS2,
          ExtractField.BRANCH_CITY, ExtractField.BRANCH_STATE,
          ExtractField.BRANCH_ZIPCODE, ExtractField.BRANCH_PHONE,
          ExtractField.BRANCH_PHONEEXT, ExtractField.BRANCH_FAX,
		  ExtractField.BRANCH_CONTACT           
        } 
      );  
      addBranchOrDealerFields(
        branchOrDealer == null || branchOrDealer.getOriginatorTypeId() == ORIGINATOR_BRANCH ? 
          null : branchOrDealer, fieldMap, 
        new ExtractField[] {
          ExtractField.DEALER_NAME, ExtractField.DEALER_ADDRESS1, ExtractField.DEALER_ADDRESS2,
          ExtractField.DEALER_CITY, ExtractField.DEALER_STATE,
          ExtractField.DEALER_ZIPCODE, ExtractField.DEALER_PHONE,
          ExtractField.DEALER_PHONEEXT, ExtractField.DEALER_FAX,            
          ExtractField.DEALER_CONTACT 
        } 
      );
      
      extractLoanPurpose(aConnection, letter, fieldMap);
      addCommentField(decision, fieldMap);
      extractStipulations(aConnection, decision, fieldMap);
      //if (showAllBureausFlag) { //Do this all the time, the parameter will be ignored
    	  //Append all bureaus to the end if the correct parameter is set
    	  extractAllBureaus(aConnection, letter, allRequestors, fieldMap);
      //}
     extractBureauScoreAndBureauRBP(aConnection, letter, allRequestors, fieldMap); 

      // Sanity check, make sure each lne of data has same number of fields (compared to
      // the number of fields defined).
      
      if (fieldMap.size() != ExtractField.getNumberOfDefinedFields())
        throw new IllegalStateException("unexpected error, different number of fields in map (# of fields in data line=" + 
          fieldMap.size() + ", # of defined fields=" + ExtractField.getNumberOfDefinedFields() + ")");
      
      // Write all fields as a line of comma-separated values to the appropriate
      // file (i.e., specific file for evaluator, letter and document type). If
      // the is first time file has been written to, write a header line with just
      // the field names first.

      if (outFile.isNewlyOpened()) {
        outFile.setNewlyOpened(false);
        CsvUtil.writeExtractFieldsAsHeader(fieldMap, outFile.getWriter());
      }
      CsvUtil.writeExtractFieldsAsLine(fieldMap, outFile.getWriter());
      extractedRecordCount++;

      
      // Insert audit-type events, the inserts are batched for better performance.
      // First, create a credit request document history entry.
      
      CreditReqDocHistory history = new CreditReqDocHistory(letter.getRequestId(), letter.getEvaluatorId(), 
        letter.getDocumentId(), CRDOCHISTORY_SUBMIT_REASON);
      history.setDatePrinted(new Date());
      history.setUser(CRDOCHISTORY_USER);
      history.setStatus(CRDOCHISTORY_STATUS);
      history.setJobType(CRDOCHISTORY_JOB_TYPE);
      history.setJobName(outFile.getFile().getName());
      history.setNumberOfCopies(1);
      historyFactory.create(history);
      
      // Create credit request journal entry to show request was extracted,
      // but do this only one time for the credit request (even though there
      // may be multiple document types extracted for the credit request).

      if (previousRequestId != letter.getRequestId()) {
        long anAppSeqno = 0;
        if (letter.isPersonalApp()) {
          if ((requestor = findRequestor(REQUESTOR_APPLICANT, 1, allRequestors)) != null)
            anAppSeqno = requestor.getAppSeqno();
        }
        else {
          if (requestorBiz != null)
            anAppSeqno = requestorBiz.getAppSeqno();
        }
        
        // using the letter document id, document name needs to be looked up
        //from the config_documents table 
        
        Query queryTmp = new Query(conn);
        String documentName = "";
        try {

			String sql = "select description_txt from config_documents where document_id = ? and evaluator_id = ? ";

			queryTmp.prepareStatement(sql);
			queryTmp.setLong(1, letter.getDocumentId());
			queryTmp.setLong(1, letter.getEvaluatorId());
			queryTmp.executePreparedQuery();
			if (queryTmp.next()) {
				documentName = queryTmp.getColValue("description_txt", "");
			}
        } catch (Exception e) {
		}
        
        //CRJOURNAL_EVENT = "ADVERSE ACTION: LETTERTYPE Letter Sent - DATE to REQUESTORS";
        String eventText = CRJOURNAL_EVENT;
        String letterType = outputLetterType;
        if (letterType.equals(OutputFileFactory.WELCOME)) {
        	letterType = "Welcome";
        } else if (letterType.equals(OutputFileFactory.DECLINED)) {
        	letterType = "Decline";
        } else if (letterType.equals(OutputFileFactory.COUNTER_OFFER)) {
        	letterType = "Counter-Offer";
        } else if (letterType.equals(OutputFileFactory.EXPIRED)) {
        	letterType = "Expired";
		} else if (letterType.equals(OutputFileFactory.GEN_NOTIFICATION)) {
			letterType = "Gen Notification";
        } else if (letterType.equals(OutputFileFactory.WITHDRAW)) {
        	letterType = "Withdraw";
        } else if (letterType.equals(OutputFileFactory.CLOSING)) {
        	letterType = "Closing";
        } else if (letterType.equals(OutputFileFactory.FIRST_PAYMENT)) {
        	letterType = "FIRST_PAYMENT";
        } else if (letterType.equals(OutputFileFactory.RISK_BASED_PRICING)) {
        	letterType = "RISK_BASED_PRICING";
        } else if (letterType.equals(OutputFileFactory.MISSING_INFO)) {
        	letterType = "MISSING_INFO";
        }  else if (letterType.equals(OutputFileFactory.EARLY_DISCLOSURE_DOCUMENT)) {
        	letterType = "EARLY_DISCLOSURE_DOCUMENT";
        } else if (letterType.equals(OutputFileFactory.INITIAL)) {
        	letterType = "INITIAL";
        } else if (letterType.equals(OutputFileFactory.FOLLOW_UP_1)) {
        	letterType = "FOLLOW_UP_1";
        } else if (letterType.equals(OutputFileFactory.FOLLOW_UP_2)) {
        	letterType = "FOLLOW_UP_2";
        } else {
        	//do nothing and keep it as is
        }    

        StringBuffer temp_buffer = new StringBuffer("");
        for (int i=0; i<allRequestors.length; i++) {
        	if (i != 0) {
                temp_buffer.append(" and ");
        	}
        	String requestorType = allRequestors[i].getTypeOfRequestor() + "";
        	if (allRequestors[i].getTypeOfRequestor() == REQUESTOR_APPLICANT) {
        		requestorType = "Applicant";
        	} else if (allRequestors[i].getTypeOfRequestor() == REQUESTOR_COAPPLICANT) {
        		requestorType = "Co-Applicant";
        	} else if (allRequestors[i].getTypeOfRequestor() == REQUESTOR_COSIGNER) {
        		requestorType = "Co-Signer";
        	} else if (allRequestors[i].getTypeOfRequestor() == REQUESTOR_BUSINESS) {
        		requestorType = "Business";
        	} else {
        		//do nothing and keep it as is
        	}
            temp_buffer.append(requestorType);
        }
        String requestors = temp_buffer.toString();
        eventText = eventText.replaceAll("LETTERTYPE", letterType);
        eventText = eventText.replaceAll("DOCUMENTNAME", documentName);
        eventText = eventText.replaceAll("DATE", new SimpleDateFormat("MM/dd/yyyy").format(new Date()));
        eventText = eventText.replaceAll("REQUESTORS", requestors);
        CreditRequestJournal journal = new CreditRequestJournal(
          letter.getRequestId(), letter.getEvaluatorId(), CRJOURNAL_EVENT_ID, 
          anAppSeqno, (int) letter.getAppStatusId(), eventText, letter.getTaskId());
        journal.setUser(CRJOURNAL_USER);
        journalFactory.create(journal);
      }
      
      // Track the previous request ID so we can determine when it changes,
      // this ASSUMES the letters are sorted by request ID as the major sort key.
      
      previousRequestId = letter.getRequestId();
    }                                                    // end while more letters
    
    // Insert last batch of credit request document history and journal events rows,
    // and release resources help by factories.
    
    historyFactory.flushUpdates();
    historyFactory.dispose();
    journalFactory.flushUpdates();
    journalFactory.dispose();   

    return extractedRecordCount;
  }
  
  /**
   * Run dynamic queries to evaluate when-to-use criteria. 
   * 
   * @param aConnection
   *   connection to database.
   * @param aCachingEvaluator
   *   a query evaluator that caches previous query results. 
   * @param aLetter
   *   a letter to check against when-t0-use criteria.
   * @return
   *   true if letter passes when-to-use criteria, false if it fails.
   * @throws AppException
   *   if a database error occurs.
   */
  private boolean doesLetterPassWhenToUseCriteria(Connection aConnection, CachingQueryEvaluator aCachingEvaluator, 
    Letter aLetter) throws AppException {

    WhenToUseQueryFactory whenToUseFactory = WhenToUseQueryFactory.getInstance();
    WhenToUseQueryFactory.QueryInfo[] queryInfo = whenToUseFactory.getQueryInfo(aConnection, 
      aLetter.getDocumentId(), aLetter.getEvaluatorId());
      
    boolean rowFound = true;
    try {
      for (int i=0;queryInfo != null && i < queryInfo.length && rowFound;i++) {
         /****
        RowSet rowset = aCachingEvaluator.executeQuery(aConnection, queryInfo[i].getSQL(), 
          queryInfo[i].getQueryParams(aLetter.getRequestId(), null));
        rowFound = rowset.next();
        ****/
         rowFound = aCachingEvaluator.executeQuery(aConnection, queryInfo[i].getSQL(), 
           queryInfo[i].getQueryParams(aLetter.getRequestId(), null));

        /**
         * ================================================================
         * Dispose of the rowset since it is no longer cached, PotSoft,
         * out-of-cursors fix (?), 10/06/06
         * ================================================================
         */
        // rowset.close();
      }
    }
    catch (SQLException ex) {
      throw new AppException("SQL error getting next row from cached rowset", ex);
    }
    return rowFound;
  }  
  
  private void extractEvaluatorAddress(Connection aConnection, Letter aLetter, Map aFieldMap) throws AppException {
    EvaluatorAddressFactory factory = new EvaluatorAddressFactory(aConnection);
    EvaluatorAddress addr = factory.getAddress(aLetter.getEvaluatorId()); 
    aFieldMap.put(ExtractField.EVALADDR_ADDRESS1, addr == null ? null : addr.getAddress1());
    aFieldMap.put(ExtractField.EVALADDR_ADDRESS2, addr == null ? null : addr.getAddress2());
    aFieldMap.put(ExtractField.EVALADDR_CITY, addr == null ? null : addr.getCity());
    aFieldMap.put(ExtractField.EVALADDR_STATE, addr == null ? null : addr.getState());
    aFieldMap.put(ExtractField.EVALADDR_ZIPCODE, addr == null ? null : addr.getZipCode());
    aFieldMap.put(ExtractField.EVALADDR_PHONE, addr == null ? null : addr.getPhone());
    aFieldMap.put(ExtractField.EVALADDR_FAX, addr == null ? null : addr.getFax());
  }
  
  private void addRequestorFields(Requestor aRequestor, Map aFieldMap, ExtractField[] requesterFields) throws AppException {
    int idx = 0;
    aFieldMap.put(requesterFields[idx++], aRequestor == null ? null : aRequestor.getLastName());
    aFieldMap.put(requesterFields[idx++], aRequestor == null ? null : aRequestor.getFirstName());
    aFieldMap.put(requesterFields[idx++], aRequestor == null ? null : aRequestor.getMiddleName());
    aFieldMap.put(requesterFields[idx++], aRequestor == null ? null : aRequestor.getNameSuffix());
	if(hideSSNFlag) { 
		aFieldMap.put(requesterFields[idx++], null);
	} else {
    aFieldMap.put(requesterFields[idx++], aRequestor == null ? null : aRequestor.getSSN());
	}
    aFieldMap.put(requesterFields[idx++], aRequestor == null ? null : aRequestor.getStreetNumber());
    aFieldMap.put(requesterFields[idx++], aRequestor == null ? null : aRequestor.getStreetName());
    aFieldMap.put(requesterFields[idx++], aRequestor == null ? null : aRequestor.getStreetTypeId());
    aFieldMap.put(requesterFields[idx++], aRequestor == null ? null : aRequestor.getApartmentBoxOrSuite());
    aFieldMap.put(requesterFields[idx++], aRequestor == null ? null : aRequestor.getAddress2());
    aFieldMap.put(requesterFields[idx++], aRequestor == null ? null : aRequestor.getCity());
    aFieldMap.put(requesterFields[idx++], aRequestor == null ? null : aRequestor.getState());
    aFieldMap.put(requesterFields[idx++], aRequestor == null ? null : aRequestor.getZipcode());
    aFieldMap.put(requesterFields[idx++], aRequestor == null ? null : aRequestor.getPhone());
    aFieldMap.put(requesterFields[idx++], aRequestor == null ? null : aRequestor.getPhoneExt());
    aFieldMap.put(requesterFields[idx++], aRequestor == null ? null : aRequestor.getFax());
  }
  
  private RequestorBusiness extractRequestorBusiness(Connection aConnection, Letter aLetter, 
    Requestor[] someRequestors, Map aFieldMap) throws AppException {
    
    RequestorBusiness biz = null;
    Requestor requestor = findRequestor(REQUESTOR_BUSINESS, 1, someRequestors);
    if (requestor != null) {
      RequestorBusinessFactory factory = new RequestorBusinessFactory(aConnection);
      RequestorBusiness[] businesses = factory.getRequestorBusinesses(aLetter.getRequestId(), requestor.getRequestorId());
      if (businesses != null && businesses.length > 0)
        biz = businesses[0];
    }
    
    aFieldMap.put(ExtractField.APPLICANT_BUSINESS_BUSINESSNAME, biz == null ? null : biz.getBusinessName()); 
    aFieldMap.put(ExtractField.APPLICANT_BUSINESS_PHONE, biz == null ? null : biz.getPhone()); 
    aFieldMap.put(ExtractField.APPLICANT_BUSINESS_PHONEEXT, biz == null ? null : biz.getPhoneExt()); 
    aFieldMap.put(ExtractField.APPLICANT_BUSINESS_ADDRESS1, biz == null ? null : biz.getAddress1()); 
    aFieldMap.put(ExtractField.APPLICANT_BUSINESS_ADDRESS2, biz == null ? null : biz.getAddress2()); 
    aFieldMap.put(ExtractField.APPLICANT_BUSINESS_CITY, biz == null ? null : biz.getCity()); 
    aFieldMap.put(ExtractField.APPLICANT_BUSINESS_STATE, biz == null ? null : biz.getState()); 
    aFieldMap.put(ExtractField.APPLICANT_BUSINESS_ZIPCODE, biz == null ? null : biz.getZipcode()); 
    aFieldMap.put(ExtractField.APPLICANT_BUSINESS_OFFICERNAME, biz == null ? null : biz.getOfficerName()); 
    aFieldMap.put(ExtractField.APPLICANT_BUSINESS_OFFICERTITLE, biz == null ? null : biz.getOfficerTitle());
    return biz; 
  }
  
  private void extractAuto(Connection aConnection, Letter aLetter, Map aFieldMap) throws AppException {
    CreditRequestAutoFactory factory = new CreditRequestAutoFactory(aConnection);
    CreditRequestAuto auto = factory.getAuto(aLetter.getRequestId(), aLetter.getEvaluatorId());   
    aFieldMap.put(ExtractField.AUTO_YEAR, auto == null ? null :  Integer.valueOf(auto.getYear()));
    aFieldMap.put(ExtractField.AUTO_MAKE, auto == null ? null : auto.getAutoMake());
    aFieldMap.put(ExtractField.AUTO_MODEL, auto == null ? null : auto.getAutoModel());
    aFieldMap.put(ExtractField.AUTO_VIN, auto == null ? null : auto.getVIN());
    aFieldMap.put(ExtractField.AUTO_COLOR, auto == null ? null : auto.getColor());
    aFieldMap.put(ExtractField.AUTO_NEWUSEDFLAG, auto == null ? null : (auto.isNew() ? "NEW" : "USED"));
    aFieldMap.put(ExtractField.AUTO_MILEAGE, auto == null ? null : auto.getMileage());
  }
  
  private void extractSecured(Connection aConnection, Letter aLetter, Map aFieldMap) throws AppException {
    SecuredFactory factory = new SecuredFactory(aConnection);
    Secured[] allSecured = factory.getSecured(aLetter.getRequestId());
    Secured secured = allSecured == null || allSecured.length == 0 ? null : allSecured[0];
    aFieldMap.put(ExtractField.SECURED_FLAG, secured == null ? null : secured.getCodeDesc());
  }
  
  private void extractDealStructure(Connection aConnection, Letter aLetter, 
    CreditRequestDecision dec, Map aFieldMap) throws AppException {
    
    CreditRequestFinanceFactory factory = new CreditRequestFinanceFactory(aConnection);
    CreditRequestFinance fin = factory.getFinance(aLetter.getRequestId(), aLetter.getEvaluatorId());
    aFieldMap.put(ExtractField. DEALSTRUCT_REQUESTEDAMOUNT, fin == null ? null : fin.getRequestedAmount());
    aFieldMap.put(ExtractField. DEALSTRUCT_REQUESTEDAMOUNT2, fin == null ? null : fin.getRequestedAmount());
    aFieldMap.put(ExtractField. DEALSTRUCT_REQUESTEDTERM, fin == null ? null : Integer.valueOf(fin.getRequestedTerm()));
    aFieldMap.put(ExtractField. DEALSTRUCT_REQUESTEDRATE, fin == null ? null : fin.getRequestedRate());
    aFieldMap.put(ExtractField. DEALSTRUCT_REQUESTEDPAYMENT, fin == null ? null : fin.getRequestedPayment());
    aFieldMap.put(ExtractField. DEALSTRUCT_REQUESTEDPAYMENT2, fin == null ? null : fin.getRequestedPayment());
    aFieldMap.put(ExtractField. DEALSTRUCT_APPROVEDAMOUNT, dec == null ? null : dec.getApprovedAmount());
    aFieldMap.put(ExtractField. DEALSTRUCT_APPROVEDAMOUNT2, dec == null ? null : dec.getApprovedAmount());
    aFieldMap.put(ExtractField. DEALSTRUCT_APPROVEDTERM, dec == null ? null : Integer.valueOf(dec.getApprovedTerm()));
    aFieldMap.put(ExtractField. DEALSTRUCT_APPROVEDRATE, dec == null ? null : dec.getApprovedRate());
    aFieldMap.put(ExtractField. DEALSTRUCT_APPROVEDPAYMENT, dec == null ? null : dec.getApprovedPayment());
    aFieldMap.put(ExtractField. DEALSTRUCT_APPROVEDPAYMENT2, dec == null ? null : dec.getApprovedPayment());   
    aFieldMap.put(ExtractField. DEALSTRUCT_APPROVEDBUYRATE , dec == null ? null : dec.getApprovedBuyRate());   
    aFieldMap.put(ExtractField. DEALSTRUCT_CASHDOWN, fin == null ? null : fin.getCashDown());
    aFieldMap.put(ExtractField. DEALSTRUCT_CASHDOWN2, fin == null ? null : fin.getCashDown());
    aFieldMap.put(ExtractField. DEALSTRUCT_DECISIONDATE, dec == null ? null : dec.getDecisionDate());    
    aFieldMap.put(ExtractField. DEALSTRUCT_DECISIONDESC, dec == null ? null : dec.getDecisionDesc());    
    aFieldMap.put(ExtractField. DEALSTRUCT_DECISIONUSER, dec == null ? null : dec.getDecisionUserId());    
    aFieldMap.put(ExtractField. DEALSTRUCT_DECISIONPHONE, dec == null ? null : dec.getPhoneNumber());  
  }

  private void extractTurndownReasons(Connection aConnection, Letter aLetter, Map aFieldMap, CreditRequestDecision decision) throws AppException {
    TurndownReasonFactory factory = new TurndownReasonFactory(aConnection); 
    TurndownReason[] allReasons = factory.getTurndownReasons(
      aLetter.getRequestId(), aLetter.getEvaluatorId(), decision.getDecisionRefId(), showOnlyTurndownReasonsFlag);
    ExtractField[] turndownFields = new ExtractField[] { 
      ExtractField.TURNDOWN_REASON1, ExtractField.TURNDOWN_REASON2,
      ExtractField.TURNDOWN_REASON3, ExtractField.TURNDOWN_REASON4,
      ExtractField.TURNDOWN_REASON5, ExtractField.TURNDOWN_REASON6,
      ExtractField.TURNDOWN_REASON7, ExtractField.TURNDOWN_REASON8,
      ExtractField.TURNDOWN_REASON9, ExtractField.TURNDOWN_REASON10
    };
	
	ExtractField[] turndownEntities = new ExtractField[] { 
      ExtractField.TURNDOWN_REASON1_ENTITY, 
	  ExtractField.TURNDOWN_REASON2_ENTITY,
      ExtractField.TURNDOWN_REASON3_ENTITY,
	  ExtractField.TURNDOWN_REASON4_ENTITY,
      ExtractField.TURNDOWN_REASON5_ENTITY,
	  ExtractField.TURNDOWN_REASON6_ENTITY,
      ExtractField.TURNDOWN_REASON7_ENTITY,
	  ExtractField.TURNDOWN_REASON8_ENTITY,
      ExtractField.TURNDOWN_REASON9_ENTITY,
	  ExtractField.TURNDOWN_REASON10_ENTITY
    };
	
   AppLogger.logger.log(Level.FINEST, "Turndown Reasons Extracted Successfully");
    //Is there at least one bureau-related reason?
    boolean bureauRelated = false;
    for (int i=0;i < turndownFields.length;i++) {
      TurndownReason reason = allReasons != null && i < allReasons.length ? allReasons[i] : null;
      String txt = null;
	  String entity = null;
      if (reason != null) {
    	  txt = useTurndownDescriptionFlag ? reason.getDescription() : reason.getText();
		  entity = reason.getEntity();
      }
      if (reason != null && reason.isBureauRelated()) {
    	  bureauRelated = true;
      }
      aFieldMap.put(turndownFields[i], reason == null ? null : txt);
	  aFieldMap.put(turndownEntities[i], entity == null ? null : entity);
    }
    aFieldMap.put(ExtractField.AT_LEAST_ONE_BUREAU_RELATED_REASON_FLAG, bureauRelated? "Y" : "N");
  }
  
  private void extractBureau(Connection aConnection, Letter aLetter, boolean aDeclinedDueToBureauFlag, 
    Requestor[] someRequestors, Map aFieldMap) throws AppException {
    
    Bureau bureau = null;
	
    Requestor requestor = findRequestor(REQUESTOR_APPLICANT, 1, someRequestors);
	if(requestor == null) {
		Requestor requestorBusiness = findRequestor(REQUESTOR_BUSINESS, 1, someRequestors);
		if(requestorBusiness != null)
			requestor = findRequestor(REQUESTOR_COSIGNER, 1, someRequestors);
	}
		
    if (requestor != null) {
      BureauFactory factory = new BureauFactory(aConnection);
      bureau = factory.getBureau(aLetter.getRequestId(), aLetter.getEvaluatorId(), 
        requestor.getRequestorId(), checkDefaultFlag);
    } 
    
    aFieldMap.put(ExtractField.DECLINED_DUE_TO_BUREAU_FLAG, aDeclinedDueToBureauFlag ? "Y" : "N");
		aFieldMap.put(ExtractField.BUREAU_CONSUMERREFCODE, bureau == null ? null : bureau.getConsumerRefCode());
		aFieldMap.put(ExtractField.BUREAU_NAME, bureau == null ? null : bureau.getName());
		aFieldMap.put(ExtractField.BUREAU_ADDRESS1, bureau == null ? null : bureau.getAddress1());
		aFieldMap.put(ExtractField.BUREAU_ADDRESS2, bureau == null ? null : bureau.getAddress2());
		aFieldMap.put(ExtractField.BUREAU_CITY, bureau == null ? null : bureau.getCity());
		aFieldMap.put(ExtractField.BUREAU_STATE, bureau == null ? null : bureau.getState());
		aFieldMap.put(ExtractField.BUREAU_ZIPCODE, bureau == null ? null : bureau.getZipcode());
		aFieldMap.put(ExtractField.BUREAU_PHONE, bureau == null ? null : bureau.getPhone());
		aFieldMap.put(ExtractField.BUREAU_URL, bureau == null  ? null : bureau.getMailurl());
  AppLogger.logger.log(Level.FINEST, "Finished extracting Bureau successfully");
  }

	private void extractBureauScoreAndBureauRBP(Connection aConnection, Letter aLetter, 
	 Requestor[] someRequestors, Map aFieldMap) throws AppException 
	{
    
		BureauScore bureauscore = null;
		BureauRBP bureaurbp = null;
		BureauScore cabureauscore = null, ca2bureauscore = null, csbureauscore = null, cs2bureauscore = null, cs3bureauscore = null, cs4bureauscore = null ;
		BureauRBP cabureaurbp = null, ca2bureaurbp = null, csbureaurbp = null, cs2bureaurbp = null, cs3bureaurbp = null, cs4bureaurbp = null;
		
		// Showing Dodd Frank data for Applicant
		Requestor requestor = findRequestor(REQUESTOR_APPLICANT, 1, someRequestors);
		if (requestor != null) 
		{
			BureauScoreFactory factory = new BureauScoreFactory(aConnection);
			BureauRBPFactory factory2 = new BureauRBPFactory(aConnection);
			bureauscore = factory.getBureauScore(aLetter.getRequestId(), requestor.getRequestorId());
			bureaurbp = factory2.getBureauRBP(aLetter.getRequestId(), requestor.getRequestorId());
		}
		aFieldMap.put(ExtractField.APPLICANT_CREDIT_SCORE, bureauscore == null ? null : bureauscore.getbureau_score());
		aFieldMap.put(ExtractField.APPLICANT_MIN_SCORE, bureaurbp == null ? null : bureaurbp.getRbp_low());
		aFieldMap.put(ExtractField.APPLICANT_MAX_SCORE, bureaurbp == null ? null : bureaurbp.getRbp_high());
		aFieldMap.put(ExtractField.APPLICANT_SCORE_CALCULATED_DATE, bureauscore == null  ? null : bureauscore.getscore_pull_date());
		aFieldMap.put(ExtractField.APPLICANT_SCORE_REASON_CODE_1, bureauscore == null ? null : bureauscore.getscore_reason_c_1());
		aFieldMap.put(ExtractField.APPLICANT_SCORE_REASON_DESC_1, bureauscore == null ? null : bureauscore.getscore_reason_d_1());
		aFieldMap.put(ExtractField.APPLICANT_SCORE_REASON_CODE_2, bureauscore == null ? null : bureauscore.getscore_reason_c_2());
		aFieldMap.put(ExtractField.APPLICANT_SCORE_REASON_DESC_2, bureauscore == null ? null : bureauscore.getscore_reason_d_2());
		aFieldMap.put(ExtractField.APPLICANT_SCORE_REASON_CODE_3, bureauscore == null ? null : bureauscore.getscore_reason_c_3());
		aFieldMap.put(ExtractField.APPLICANT_SCORE_REASON_DESC_3, bureauscore == null ? null : bureauscore.getscore_reason_d_3());
		aFieldMap.put(ExtractField.APPLICANT_SCORE_REASON_CODE_4, bureauscore == null ? null : bureauscore.getscore_reason_c_4());
		aFieldMap.put(ExtractField.APPLICANT_SCORE_REASON_DESC_4, bureauscore == null ? null : bureauscore.getscore_reason_d_4());
			if((bureaurbp == null ? "F" : bureaurbp.getRbp_inq()).equals("T") || (bureaurbp == null ? "N" : bureaurbp.getRbp_inq()).equals("Y"))
			{
				aFieldMap.put(ExtractField.APPLICANT_SCORE_REASON_5, bureaurbp == null ? null : "NUMBER OF INQUIRIES ADVERSELY AFFECTED THE SCORE BUT NOT SIGNIFICANTLY");
				aFieldMap.put(ExtractField.APPLICANT_SCORE_INQUIRIES, bureauscore == null ? null : bureauscore.getinquiries());
			}
			else
			{
				aFieldMap.put(ExtractField.APPLICANT_SCORE_REASON_5, null);
				aFieldMap.put(ExtractField.APPLICANT_SCORE_INQUIRIES, null);
			}
		AppLogger.logger.log(Level.FINEST, "Finished extracting Bureau Score Reasons  App successfully");
		
		// Showing Dodd Frank data for Co-Applicant
		requestor = findRequestor(REQUESTOR_COAPPLICANT, 1, someRequestors);
		if (requestor != null) 
		{
			BureauScoreFactory cafactory = new BureauScoreFactory(aConnection);
			BureauRBPFactory cafactory2 = new BureauRBPFactory(aConnection);
			cabureauscore = cafactory.getBureauScore(aLetter.getRequestId(), requestor.getRequestorId());
			cabureaurbp = cafactory2.getBureauRBP(aLetter.getRequestId(), requestor.getRequestorId());
		}
         
		aFieldMap.put(ExtractField.COAPPLICANT_CREDIT_SCORE, cabureauscore == null ? null : cabureauscore.getbureau_score());
		aFieldMap.put(ExtractField.COAPPLICANT_MIN_SCORE, cabureaurbp == null ? null : cabureaurbp.getRbp_low());
		aFieldMap.put(ExtractField.COAPPLICANT_MAX_SCORE, cabureaurbp == null ? null : cabureaurbp.getRbp_high());
		aFieldMap.put(ExtractField.COAPPLICANT_SCORE_CALCULATED_DATE, cabureauscore == null  ? null : cabureauscore.getscore_pull_date());
		aFieldMap.put(ExtractField.COAPPLICANT_SCORE_REASON_CODE_1, cabureauscore == null ? null : cabureauscore.getscore_reason_c_1());
		aFieldMap.put(ExtractField.COAPPLICANT_SCORE_REASON_DESC_1, cabureauscore == null ? null : cabureauscore.getscore_reason_d_1());
		aFieldMap.put(ExtractField.COAPPLICANT_SCORE_REASON_CODE_2, cabureauscore == null ? null : cabureauscore.getscore_reason_c_2());
		aFieldMap.put(ExtractField.COAPPLICANT_SCORE_REASON_DESC_2, cabureauscore == null ? null : cabureauscore.getscore_reason_d_2());
		aFieldMap.put(ExtractField.COAPPLICANT_SCORE_REASON_CODE_3, cabureauscore == null ? null : cabureauscore.getscore_reason_c_3());
		aFieldMap.put(ExtractField.COAPPLICANT_SCORE_REASON_DESC_3, cabureauscore == null ? null : cabureauscore.getscore_reason_d_3());
		aFieldMap.put(ExtractField.COAPPLICANT_SCORE_REASON_CODE_4, cabureauscore == null ? null : cabureauscore.getscore_reason_c_4());
		aFieldMap.put(ExtractField.COAPPLICANT_SCORE_REASON_DESC_4, cabureauscore == null ? null : cabureauscore.getscore_reason_d_4());
			if((cabureaurbp == null ? "F" : cabureaurbp.getRbp_inq()).equals("T")|| (cabureaurbp == null ? "N" : cabureaurbp.getRbp_inq()).equals("Y"))
			{
				aFieldMap.put(ExtractField.COAPPLICANT_SCORE_REASON_5, cabureaurbp == null ? null : "NUMBER OF INQUIRIES ADVERSELY AFFECTED THE SCORE BUT NOT SIGNIFICANTLY");
				aFieldMap.put(ExtractField.COAPPLICANT_SCORE_INQUIRIES, cabureauscore == null ? null : cabureauscore.getinquiries());
			}
			else
			{
				aFieldMap.put(ExtractField.COAPPLICANT_SCORE_REASON_5, null);
				aFieldMap.put(ExtractField.COAPPLICANT_SCORE_INQUIRIES, null);
			}
		AppLogger.logger.log(Level.FINEST, "Finished extracting Bureau Score Reasons  CoApp successfully");
		
		// Showing Dodd Frank data for Co-Applicant 2
		requestor = findRequestor(REQUESTOR_COAPPLICANT, 2, someRequestors);
		if (requestor != null) 
		{
			BureauScoreFactory ca2factory = new BureauScoreFactory(aConnection);
			BureauRBPFactory ca2factory2 = new BureauRBPFactory(aConnection);
			ca2bureauscore = ca2factory.getBureauScore(aLetter.getRequestId(), requestor.getRequestorId());
			ca2bureaurbp = ca2factory2.getBureauRBP(aLetter.getRequestId(), requestor.getRequestorId());
		}
         
		aFieldMap.put(ExtractField.COAPPLICANT2_CREDIT_SCORE, ca2bureauscore == null ? null : ca2bureauscore.getbureau_score());
		aFieldMap.put(ExtractField.COAPPLICANT2_MIN_SCORE, ca2bureaurbp == null ? null : ca2bureaurbp.getRbp_low());
		aFieldMap.put(ExtractField.COAPPLICANT2_MAX_SCORE, ca2bureaurbp == null ? null : ca2bureaurbp.getRbp_high());
		aFieldMap.put(ExtractField.COAPPLICANT2_SCORE_CALCULATED_DATE, ca2bureauscore == null  ? null : ca2bureauscore.getscore_pull_date());
		aFieldMap.put(ExtractField.COAPPLICANT2_SCORE_REASON_CODE_1, ca2bureauscore == null ? null : ca2bureauscore.getscore_reason_c_1());
		aFieldMap.put(ExtractField.COAPPLICANT2_SCORE_REASON_DESC_1, ca2bureauscore == null ? null : ca2bureauscore.getscore_reason_d_1());
		aFieldMap.put(ExtractField.COAPPLICANT2_SCORE_REASON_CODE_2, ca2bureauscore == null ? null : ca2bureauscore.getscore_reason_c_2());
		aFieldMap.put(ExtractField.COAPPLICANT2_SCORE_REASON_DESC_2, ca2bureauscore == null ? null : ca2bureauscore.getscore_reason_d_2());
		aFieldMap.put(ExtractField.COAPPLICANT2_SCORE_REASON_CODE_3, ca2bureauscore == null ? null : ca2bureauscore.getscore_reason_c_3());
		aFieldMap.put(ExtractField.COAPPLICANT2_SCORE_REASON_DESC_3, ca2bureauscore == null ? null : ca2bureauscore.getscore_reason_d_3());
		aFieldMap.put(ExtractField.COAPPLICANT2_SCORE_REASON_CODE_4, ca2bureauscore == null ? null : ca2bureauscore.getscore_reason_c_4());
		aFieldMap.put(ExtractField.COAPPLICANT2_SCORE_REASON_DESC_4, ca2bureauscore == null ? null : ca2bureauscore.getscore_reason_d_4());
			if((ca2bureaurbp == null ? "F" : ca2bureaurbp.getRbp_inq()).equals("T")|| (ca2bureaurbp == null ? "N" : ca2bureaurbp.getRbp_inq()).equals("Y"))
			{
				aFieldMap.put(ExtractField.COAPPLICANT2_SCORE_REASON_5, ca2bureaurbp == null ? null : "NUMBER OF INQUIRIES ADVERSELY AFFECTED THE SCORE BUT NOT SIGNIFICANTLY");
				aFieldMap.put(ExtractField.COAPPLICANT2_SCORE_INQUIRIES, ca2bureauscore == null ? null : ca2bureauscore.getinquiries());
			}
			else
			{
				aFieldMap.put(ExtractField.COAPPLICANT2_SCORE_REASON_5, null);
				aFieldMap.put(ExtractField.COAPPLICANT2_SCORE_INQUIRIES, null);
			}
		AppLogger.logger.log(Level.FINEST, "Finished extracting Bureau Score Reasons  CoApp2 successfully");
		
		// Showing Dodd Frank data for Co-Signer
		requestor = findRequestor(REQUESTOR_COSIGNER, 1, someRequestors);
		if (requestor != null) 
		{
			BureauScoreFactory csfactory = new BureauScoreFactory(aConnection);
			BureauRBPFactory csfactory2 = new BureauRBPFactory(aConnection);
			csbureauscore = csfactory.getBureauScore(aLetter.getRequestId(), requestor.getRequestorId());
			csbureaurbp = csfactory2.getBureauRBP(aLetter.getRequestId(), requestor.getRequestorId());
		}
         
		aFieldMap.put(ExtractField.COSIGNER_CREDIT_SCORE, csbureauscore == null ? null : csbureauscore.getbureau_score());
		aFieldMap.put(ExtractField.COSIGNER_MIN_SCORE, csbureaurbp == null ? null : csbureaurbp.getRbp_low());
		aFieldMap.put(ExtractField.COSIGNER_MAX_SCORE, csbureaurbp == null ? null : csbureaurbp.getRbp_high());
		aFieldMap.put(ExtractField.COSIGNER_SCORE_CALCULATED_DATE, csbureauscore == null  ? null : csbureauscore.getscore_pull_date());
		aFieldMap.put(ExtractField.COSIGNER_SCORE_REASON_CODE_1, csbureauscore == null ? null : csbureauscore.getscore_reason_c_1());
		aFieldMap.put(ExtractField.COSIGNER_SCORE_REASON_DESC_1, csbureauscore == null ? null : csbureauscore.getscore_reason_d_1());
		aFieldMap.put(ExtractField.COSIGNER_SCORE_REASON_CODE_2, csbureauscore == null ? null : csbureauscore.getscore_reason_c_2());
		aFieldMap.put(ExtractField.COSIGNER_SCORE_REASON_DESC_2, csbureauscore == null ? null : csbureauscore.getscore_reason_d_2());
		aFieldMap.put(ExtractField.COSIGNER_SCORE_REASON_CODE_3, csbureauscore == null ? null : csbureauscore.getscore_reason_c_3());
		aFieldMap.put(ExtractField.COSIGNER_SCORE_REASON_DESC_3, csbureauscore == null ? null : csbureauscore.getscore_reason_d_3());
		aFieldMap.put(ExtractField.COSIGNER_SCORE_REASON_CODE_4, csbureauscore == null ? null : csbureauscore.getscore_reason_c_4());
		aFieldMap.put(ExtractField.COSIGNER_SCORE_REASON_DESC_4, csbureauscore == null ? null : csbureauscore.getscore_reason_d_4());
			if((csbureaurbp == null ? "F" : csbureaurbp.getRbp_inq()).equals("T")|| (csbureaurbp == null ? "N" : csbureaurbp.getRbp_inq()).equals("Y"))
			{
				aFieldMap.put(ExtractField.COSIGNER_SCORE_REASON_5, csbureaurbp == null ? null : "NUMBER OF INQUIRIES ADVERSELY AFFECTED THE SCORE BUT NOT SIGNIFICANTLY");
				aFieldMap.put(ExtractField.COSIGNER_SCORE_INQUIRIES, csbureauscore == null ? null : csbureauscore.getinquiries());
			}
			else
			{
				aFieldMap.put(ExtractField.COSIGNER_SCORE_REASON_5, null);
				aFieldMap.put(ExtractField.COSIGNER_SCORE_INQUIRIES, null);
			}
		AppLogger.logger.log(Level.FINEST, "Finished extracting Bureau Score Reasons  CoSigner successfully");
		
		// Showing Dodd Frank data for Co-Signer 2
		requestor = findRequestor(REQUESTOR_COSIGNER, 2, someRequestors);
		if (requestor != null) 
		{
			BureauScoreFactory cs2factory = new BureauScoreFactory(aConnection);
			BureauRBPFactory cs2factory2 = new BureauRBPFactory(aConnection);
			cs2bureauscore = cs2factory.getBureauScore(aLetter.getRequestId(), requestor.getRequestorId());
			cs2bureaurbp = cs2factory2.getBureauRBP(aLetter.getRequestId(), requestor.getRequestorId());
		}
         
		aFieldMap.put(ExtractField.COSIGNER2_CREDIT_SCORE, cs2bureauscore == null ? null : cs2bureauscore.getbureau_score());
		aFieldMap.put(ExtractField.COSIGNER2_MIN_SCORE, cs2bureaurbp == null ? null : cs2bureaurbp.getRbp_low());
		aFieldMap.put(ExtractField.COSIGNER2_MAX_SCORE, cs2bureaurbp == null ? null : cs2bureaurbp.getRbp_high());
		aFieldMap.put(ExtractField.COSIGNER2_SCORE_CALCULATED_DATE, cs2bureauscore == null  ? null : cs2bureauscore.getscore_pull_date());
		aFieldMap.put(ExtractField.COSIGNER2_SCORE_REASON_CODE_1, cs2bureauscore == null ? null : cs2bureauscore.getscore_reason_c_1());
		aFieldMap.put(ExtractField.COSIGNER2_SCORE_REASON_DESC_1, cs2bureauscore == null ? null : cs2bureauscore.getscore_reason_d_1());
		aFieldMap.put(ExtractField.COSIGNER2_SCORE_REASON_CODE_2, cs2bureauscore == null ? null : cs2bureauscore.getscore_reason_c_2());
		aFieldMap.put(ExtractField.COSIGNER2_SCORE_REASON_DESC_2, cs2bureauscore == null ? null : cs2bureauscore.getscore_reason_d_2());
		aFieldMap.put(ExtractField.COSIGNER2_SCORE_REASON_CODE_3, cs2bureauscore == null ? null : cs2bureauscore.getscore_reason_c_3());
		aFieldMap.put(ExtractField.COSIGNER2_SCORE_REASON_DESC_3, cs2bureauscore == null ? null : cs2bureauscore.getscore_reason_d_3());
		aFieldMap.put(ExtractField.COSIGNER2_SCORE_REASON_CODE_4, cs2bureauscore == null ? null : cs2bureauscore.getscore_reason_c_4());
		aFieldMap.put(ExtractField.COSIGNER2_SCORE_REASON_DESC_4, cs2bureauscore == null ? null : cs2bureauscore.getscore_reason_d_4());
			if((cs2bureaurbp == null ? "F" : cs2bureaurbp.getRbp_inq()).equals("T")|| (cs2bureaurbp == null ? "N" : cs2bureaurbp.getRbp_inq()).equals("Y"))
			{
				aFieldMap.put(ExtractField.COSIGNER2_SCORE_REASON_5, cs2bureaurbp == null ? null : "NUMBER OF INQUIRIES ADVERSELY AFFECTED THE SCORE BUT NOT SIGNIFICANTLY");
				aFieldMap.put(ExtractField.COSIGNER2_SCORE_INQUIRIES, cs2bureauscore == null ? null : cs2bureauscore.getinquiries());
			}
			else
			{
				aFieldMap.put(ExtractField.COSIGNER2_SCORE_REASON_5, null);
				aFieldMap.put(ExtractField.COSIGNER2_SCORE_INQUIRIES, null);
			}
		AppLogger.logger.log(Level.FINEST, "Finished extracting Bureau Score Reasons  CoSigner2 successfully");
		
		// Showing Dodd Frank data for Co-Signer 3
		requestor = findRequestor(REQUESTOR_COSIGNER, 3, someRequestors);
		if (requestor != null) 
		{
			BureauScoreFactory cs3factory = new BureauScoreFactory(aConnection);
			BureauRBPFactory cs3factory2 = new BureauRBPFactory(aConnection);
			cs3bureauscore = cs3factory.getBureauScore(aLetter.getRequestId(), requestor.getRequestorId());
			cs3bureaurbp = cs3factory2.getBureauRBP(aLetter.getRequestId(), requestor.getRequestorId());
		}
         
		aFieldMap.put(ExtractField.COSIGNER3_CREDIT_SCORE, cs3bureauscore == null ? null : cs3bureauscore.getbureau_score());
		aFieldMap.put(ExtractField.COSIGNER3_MIN_SCORE, cs3bureaurbp == null ? null : cs3bureaurbp.getRbp_low());
		aFieldMap.put(ExtractField.COSIGNER3_MAX_SCORE, cs3bureaurbp == null ? null : cs3bureaurbp.getRbp_high());
		aFieldMap.put(ExtractField.COSIGNER3_SCORE_CALCULATED_DATE, cs3bureauscore == null  ? null : cs3bureauscore.getscore_pull_date());
		aFieldMap.put(ExtractField.COSIGNER3_SCORE_REASON_CODE_1, cs3bureauscore == null ? null : cs3bureauscore.getscore_reason_c_1());
		aFieldMap.put(ExtractField.COSIGNER3_SCORE_REASON_DESC_1, cs3bureauscore == null ? null : cs3bureauscore.getscore_reason_d_1());
		aFieldMap.put(ExtractField.COSIGNER3_SCORE_REASON_CODE_2, cs3bureauscore == null ? null : cs3bureauscore.getscore_reason_c_2());
		aFieldMap.put(ExtractField.COSIGNER3_SCORE_REASON_DESC_2, cs3bureauscore == null ? null : cs3bureauscore.getscore_reason_d_2());
		aFieldMap.put(ExtractField.COSIGNER3_SCORE_REASON_CODE_3, cs3bureauscore == null ? null : cs3bureauscore.getscore_reason_c_3());
		aFieldMap.put(ExtractField.COSIGNER3_SCORE_REASON_DESC_3, cs3bureauscore == null ? null : cs3bureauscore.getscore_reason_d_3());
		aFieldMap.put(ExtractField.COSIGNER3_SCORE_REASON_CODE_4, cs3bureauscore == null ? null : cs3bureauscore.getscore_reason_c_4());
		aFieldMap.put(ExtractField.COSIGNER3_SCORE_REASON_DESC_4, cs3bureauscore == null ? null : cs3bureauscore.getscore_reason_d_4());
			if((cs3bureaurbp == null ? "F" : cs3bureaurbp.getRbp_inq()).equals("T")|| (cs3bureaurbp == null ? "N" : cs3bureaurbp.getRbp_inq()).equals("Y"))
			{
				aFieldMap.put(ExtractField.COSIGNER3_SCORE_REASON_5, cs3bureaurbp == null ? null : "NUMBER OF INQUIRIES ADVERSELY AFFECTED THE SCORE BUT NOT SIGNIFICANTLY");
				aFieldMap.put(ExtractField.COSIGNER3_SCORE_INQUIRIES, cs3bureauscore == null ? null : cs3bureauscore.getinquiries());
			}
			else
			{
				aFieldMap.put(ExtractField.COSIGNER3_SCORE_REASON_5, null);
				aFieldMap.put(ExtractField.COSIGNER3_SCORE_INQUIRIES, null);
			}
		AppLogger.logger.log(Level.FINEST, "Finished extracting Bureau Score Reasons  COSIGNER3 successfully");
		
		// Showing Dodd Frank data for Co-Signer 4
		requestor = findRequestor(REQUESTOR_COSIGNER, 4, someRequestors);
		if (requestor != null) 
		{
			BureauScoreFactory cs4factory = new BureauScoreFactory(aConnection);
			BureauRBPFactory cs4factory2 = new BureauRBPFactory(aConnection);
			cs4bureauscore = cs4factory.getBureauScore(aLetter.getRequestId(), requestor.getRequestorId());
			cs4bureaurbp = cs4factory2.getBureauRBP(aLetter.getRequestId(), requestor.getRequestorId());
		}
         
		aFieldMap.put(ExtractField.COSIGNER4_CREDIT_SCORE, cs4bureauscore == null ? null : cs4bureauscore.getbureau_score());
		aFieldMap.put(ExtractField.COSIGNER4_MIN_SCORE, cs4bureaurbp == null ? null : cs4bureaurbp.getRbp_low());
		aFieldMap.put(ExtractField.COSIGNER4_MAX_SCORE, cs4bureaurbp == null ? null : cs4bureaurbp.getRbp_high());
		aFieldMap.put(ExtractField.COSIGNER4_SCORE_CALCULATED_DATE, cs4bureauscore == null  ? null : cs4bureauscore.getscore_pull_date());
		aFieldMap.put(ExtractField.COSIGNER4_SCORE_REASON_CODE_1, cs4bureauscore == null ? null : cs4bureauscore.getscore_reason_c_1());
		aFieldMap.put(ExtractField.COSIGNER4_SCORE_REASON_DESC_1, cs4bureauscore == null ? null : cs4bureauscore.getscore_reason_d_1());
		aFieldMap.put(ExtractField.COSIGNER4_SCORE_REASON_CODE_2, cs4bureauscore == null ? null : cs4bureauscore.getscore_reason_c_2());
		aFieldMap.put(ExtractField.COSIGNER4_SCORE_REASON_DESC_2, cs4bureauscore == null ? null : cs4bureauscore.getscore_reason_d_2());
		aFieldMap.put(ExtractField.COSIGNER4_SCORE_REASON_CODE_3, cs4bureauscore == null ? null : cs4bureauscore.getscore_reason_c_3());
		aFieldMap.put(ExtractField.COSIGNER4_SCORE_REASON_DESC_3, cs4bureauscore == null ? null : cs4bureauscore.getscore_reason_d_3());
		aFieldMap.put(ExtractField.COSIGNER4_SCORE_REASON_CODE_4, cs4bureauscore == null ? null : cs4bureauscore.getscore_reason_c_4());
		aFieldMap.put(ExtractField.COSIGNER4_SCORE_REASON_DESC_4, cs4bureauscore == null ? null : cs4bureauscore.getscore_reason_d_4());
			if((cs4bureaurbp == null ? "F" : cs4bureaurbp.getRbp_inq()).equals("T")|| (cs4bureaurbp == null ? "N" : cs4bureaurbp.getRbp_inq()).equals("Y"))
			{
				aFieldMap.put(ExtractField.COSIGNER4_SCORE_REASON_5, cs4bureaurbp == null ? null : "NUMBER OF INQUIRIES ADVERSELY AFFECTED THE SCORE BUT NOT SIGNIFICANTLY");
				aFieldMap.put(ExtractField.COSIGNER4_SCORE_INQUIRIES, cs4bureauscore == null ? null : cs4bureauscore.getinquiries());
			}
			else
			{
				aFieldMap.put(ExtractField.COSIGNER4_SCORE_REASON_5, null);
				aFieldMap.put(ExtractField.COSIGNER4_SCORE_INQUIRIES, null);
			}
		AppLogger.logger.log(Level.FINEST, "Finished extracting Bureau Score Reasons  COSIGNER4 successfully");
	}
  
  private void extractAllBureaus(Connection aConnection, Letter aLetter, 
		    Requestor[] someRequestors, Map aFieldMap) throws AppException {
		    
		    Bureau[] bureaus = null;
		    Requestor requestor = findRequestor(REQUESTOR_APPLICANT, 1, someRequestors);
		    if (requestor != null) {
		      BureauFactory factory = new BureauFactory(aConnection);
		      bureaus = factory.getAllBureaus(aLetter.getRequestId(), aLetter.getEvaluatorId(), 
		        requestor.getRequestorId(), checkDefaultFlag);
		    }
		    
				aFieldMap.put(ExtractField.BUREAU_CONSUMERREFCODE_1, (bureaus == null || bureaus.length < 1) ? null : bureaus[0].getConsumerRefCode());
				aFieldMap.put(ExtractField.BUREAU_NAME_1, (bureaus == null || bureaus.length < 1) ? null : bureaus[0].getName());
				aFieldMap.put(ExtractField.BUREAU_ADDRESS1_1, (bureaus == null || bureaus.length < 1) ? null : bureaus[0].getAddress1());
				aFieldMap.put(ExtractField.BUREAU_ADDRESS2_1, (bureaus == null || bureaus.length < 1) ? null : bureaus[0].getAddress2());
				aFieldMap.put(ExtractField.BUREAU_CITY_1, (bureaus == null || bureaus.length < 1) ? null : bureaus[0].getCity());
				aFieldMap.put(ExtractField.BUREAU_STATE_1, (bureaus == null || bureaus.length < 1) ? null : bureaus[0].getState());
				aFieldMap.put(ExtractField.BUREAU_ZIPCODE_1, (bureaus == null || bureaus.length < 1) ? null : bureaus[0].getZipcode());
				aFieldMap.put(ExtractField.BUREAU_PHONE_1, (bureaus == null || bureaus.length < 1) ? null : bureaus[0].getPhone());
				aFieldMap.put(ExtractField.BUREAU_URL_1, (bureaus == null || bureaus.length < 1) ? null : bureaus[0].getMailurl());
				
				aFieldMap.put(ExtractField.BUREAU_CONSUMERREFCODE_2, (bureaus == null || bureaus.length < 2) ? null : bureaus[1].getConsumerRefCode());
				aFieldMap.put(ExtractField.BUREAU_NAME_2, (bureaus == null || bureaus.length < 2) ? null : bureaus[1].getName());
				aFieldMap.put(ExtractField.BUREAU_ADDRESS1_2, (bureaus == null || bureaus.length < 2) ? null : bureaus[1].getAddress1());
				aFieldMap.put(ExtractField.BUREAU_ADDRESS2_2, (bureaus == null || bureaus.length < 2) ? null : bureaus[1].getAddress2());
				aFieldMap.put(ExtractField.BUREAU_CITY_2, (bureaus == null || bureaus.length < 2) ? null : bureaus[1].getCity());
				aFieldMap.put(ExtractField.BUREAU_STATE_2, (bureaus == null || bureaus.length < 2) ? null : bureaus[1].getState());
				aFieldMap.put(ExtractField.BUREAU_ZIPCODE_2, (bureaus == null || bureaus.length < 2) ? null : bureaus[1].getZipcode());
				aFieldMap.put(ExtractField.BUREAU_PHONE_2, (bureaus == null || bureaus.length < 2) ? null : bureaus[1].getPhone());
				aFieldMap.put(ExtractField.BUREAU_URL_2, (bureaus == null || bureaus.length < 2) ? null : bureaus[1].getMailurl());
				
				aFieldMap.put(ExtractField.BUREAU_CONSUMERREFCODE_3, (bureaus == null || bureaus.length < 3) ? null : bureaus[2].getConsumerRefCode());
				aFieldMap.put(ExtractField.BUREAU_NAME_3, (bureaus == null || bureaus.length < 3) ? null : bureaus[2].getName());
				aFieldMap.put(ExtractField.BUREAU_ADDRESS1_3, (bureaus == null || bureaus.length < 3) ? null : bureaus[2].getAddress1());
				aFieldMap.put(ExtractField.BUREAU_ADDRESS2_3, (bureaus == null || bureaus.length < 3) ? null : bureaus[2].getAddress2());
				aFieldMap.put(ExtractField.BUREAU_CITY_3, (bureaus == null || bureaus.length < 3) ? null : bureaus[2].getCity());
				aFieldMap.put(ExtractField.BUREAU_STATE_3, (bureaus == null || bureaus.length < 3) ? null : bureaus[2].getState());
				aFieldMap.put(ExtractField.BUREAU_ZIPCODE_3, (bureaus == null || bureaus.length < 3) ? null : bureaus[2].getZipcode());
				aFieldMap.put(ExtractField.BUREAU_PHONE_3, (bureaus == null || bureaus.length < 3) ? null : bureaus[2].getPhone());
				aFieldMap.put(ExtractField.BUREAU_URL_3, (bureaus == null || bureaus.length < 3) ? null : bureaus[2].getMailurl());
				AppLogger.logger.log(Level.FINEST, "Finished extracting All Bureaus successfully");
		  }  

  private void extractBuyingCenter(Connection aConnection, Letter aLetter, Map aFieldMap) throws AppException {
    CenterFactory factory = new CenterFactory(aConnection);
    Center center = factory.getCenter(aLetter.getRequestId(), aLetter.getEvaluatorId());
    aFieldMap.put(ExtractField.CENTER_NAME, center == null ? null : center.getName());
    aFieldMap.put(ExtractField.CENTER_STREETNUMBER, center == null ? null : center.getStreetNumber());
    aFieldMap.put(ExtractField.CENTER_STREETNAME, center == null ? null : center.getStreetName());
    aFieldMap.put(ExtractField.CENTER_TYPEOFSTREET, center == null ? null : center.getStreetTypeId());
    aFieldMap.put(ExtractField.CENTER_CITY, center == null ? null : center.getCity());
    aFieldMap.put(ExtractField.CENTER_STATE, center == null ? null : center.getState());
    aFieldMap.put(ExtractField.CENTER_ZIPCODE, center == null ? null : center.getZipcode());
    aFieldMap.put(ExtractField.CENTER_PHONE, center == null ? null : center.getPhone());
    aFieldMap.put(ExtractField.CENTER_FAX, center == null ? null : center.getFax());
  }
  
  private void addBranchOrDealerFields(BranchOrDealer aDatum, Map aFieldMap, 
    ExtractField[] requesterFields) throws AppException {
    
    int idx = 0;
    aFieldMap.put(requesterFields[idx++], aDatum == null ? null : aDatum.getOriginatorName());
    aFieldMap.put(requesterFields[idx++], aDatum == null ? null : aDatum.getAddress1());
    aFieldMap.put(requesterFields[idx++], aDatum == null ? null : aDatum.getAddress2());
    aFieldMap.put(requesterFields[idx++], aDatum == null ? null : aDatum.getCity());
    aFieldMap.put(requesterFields[idx++], aDatum == null ? null : aDatum.getState());
    aFieldMap.put(requesterFields[idx++], aDatum == null ? null : aDatum.getZipcode());
    aFieldMap.put(requesterFields[idx++], aDatum == null ? null : aDatum.getPhone());
    aFieldMap.put(requesterFields[idx++], aDatum == null ? null : aDatum.getPhoneExt());
    aFieldMap.put(requesterFields[idx++], aDatum == null ? null : aDatum.getFax());
    aFieldMap.put(requesterFields[idx++], aDatum == null ? null : aDatum.getContact());
  }
  
  private void extractLoanPurpose(Connection aConnection, Letter aLetter, Map aFieldMap) throws AppException {
    LoanPurposeFactory factory = new LoanPurposeFactory(aConnection);
    LoanPurpose lp = factory.getLoanPurpose(aLetter.getRequestId(), aLetter.getEvaluatorId());   
    aFieldMap.put(ExtractField.LOAN_PURPOSE_CODE, lp == null ? null : lp.getLoanPurposeCode());  
  }
  
  private void addCommentField(CreditRequestDecision aDecision, Map aFieldMap) {
    aFieldMap.put(ExtractField.COMMENTS, aDecision == null ? null : aDecision.getComments());
  }
  
  private void extractStipulations(Connection aConnection, CreditRequestDecision aDecision, Map aFieldMap) throws AppException {
    StipulationFactory factory = new StipulationFactory(aConnection); 
    Stipulation[] allStipulations = aDecision == null ?
      null : factory.getStipulations(aDecision.getDecisionRefId());
    ExtractField[] stipFields = new ExtractField[] { 
      ExtractField.STIPULATION_TEXT1, ExtractField.STIPULATION_DESC1,
      ExtractField.STIPULATION_TEXT2, ExtractField.STIPULATION_DESC2,
      ExtractField.STIPULATION_TEXT3, ExtractField.STIPULATION_DESC3
    };
 
    for (int i=0,j=0;i < stipFields.length;j++) {
      Stipulation stip = allStipulations != null && j < allStipulations.length ? allStipulations[j] : null;
      aFieldMap.put(stipFields[i++], stip == null ? null : stip.getText());
      aFieldMap.put(stipFields[i++], stip == null ? null : stip.getDescription());
    }
  }  

  private Requestor findRequestor(int aRequestorType, int requestorNumber, Requestor[] someRequestors) {
    Requestor requestor = null;
    int numberOfRequestorTypeMatches = 0;
    mainLoop: for (int i=0;someRequestors != null && i < someRequestors.length;i++) {
      if (someRequestors[i].getTypeOfRequestor() == aRequestorType) {
        if (requestorNumber == ++numberOfRequestorTypeMatches) {
          requestor = someRequestors[i];
          break mainLoop;
        }
      }
    }
    return requestor;
  }
  
  private CreditRequestDecision findDecision(long[] someDecisionIdsInPreferredOrder, CreditRequestDecision[] someDecisions) {
    CreditRequestDecision decision = null;
    mainLoop: for (int i=0;someDecisionIdsInPreferredOrder != null && i < someDecisionIdsInPreferredOrder.length;i++) {
      for (int j=0;someDecisions != null && j < someDecisions.length;j++) {
        if (someDecisionIdsInPreferredOrder[i] == someDecisions[j].getDecisionId()) {
          decision = someDecisions[j];
          break mainLoop;
        }
      }
    }
    return decision;
  } 
  private String getEvaluatorName(long ev_id) throws Exception{
	PreparedStatement stmt = null;
	ResultSet rs = null;
	String sql = "select evaluator_name_txt from evaluator where evaluator_id = ?";
	String evaluator_name = "";
	try{
		 Query queryTmp = new Query(this.conn);
		 queryTmp.prepareStatement(sql);
		 queryTmp.setLong(1, ev_id);
		 queryTmp.executePreparedQuery();
		 if (queryTmp != null && queryTmp.next()) {
			 evaluator_name = queryTmp.getColValue("evaluator_name_txt","0");
		 }
	}
	catch (Exception e){
	      throw new AppException("failed to query evaluator for evaluator ID," + e);
	}
	
	return evaluator_name; 
  }
  
  private void generateBlankFile(String outputLetterType, long[] allEvaluators) throws AppException
  {
	  try{
			  OutputFileFactory outputFileFactory = OutputFileFactory.getInstance(this.outputDir);
			  //for each evaluator
			  for(long eval_id: this.evaluatorIds){
				  ArrayList<String> docTypeIds =  new ArrayList<String>();
					  docTypeIds = getDocTypeIds(outputLetterType,eval_id);
					  //for each doc type configured create a blank file for the letter type
					  for(String docTypeId: docTypeIds){
					  	OutputFileFactory.OutputFile outFile = outputFileFactory.getFile(getEvaluatorName(eval_id), this.outputLetterType, docTypeId);
					  	if (outFile == null)
					  		throw new IllegalStateException("unexpected error, output file obtained via factory should not be null");
					  }
			  }
	  }
	  catch (Exception ex){
	      throw new AppException("failed to generate blank files for letter type: "+ outputLetterType + " exception info: "+ ex);
	  }
  }
  
  private ArrayList<String> getDocTypeIds(String outputLetterType, long eval_id) throws AppException {
	  ArrayList<String> docTypes = new ArrayList<String>();
		
		try {

		  // gets touchpoint ID from letter categoryID
			String letterIdText = getLetterID(outputLetterType);

			String touchPoint = LetterFactory.getTouchpointID(letterIdText);
			if(!touchPoint.equals("")){
				Query queryTmp = new Query(this.conn);  
			  // select all the documents that are defined for this touchpoint from config_touchpoints_documents table
			  	String sql="select distinct cd.doc_type_id from config_touchpoint_documents ctd,config_documents cd where ctd.evaluator_id = ? and ctd.touchpoint_id = ? and ctd.active_flg = 1 and ctd.document_id = cd.document_id";
			  	queryTmp.prepareStatement(sql);
			  	queryTmp.setLong(1, eval_id);
			  	queryTmp.setString(2, touchPoint);
				queryTmp.executePreparedQuery();
		
				while (queryTmp.next()) {
					String val = queryTmp.getColValue("doc_type_id","0");
					docTypes.add(val);
				}
				if(docTypes.size() ==0){  //if nothing configured in config_touchpoint_documents check if anything is configured in config_evaluator_documents
					sql = "SELECT cd.doc_type_id FROM config_evaluator_documents ce, " +
							" config_documents cd WHERE ce.category_id = ? AND " +
							" ce.evaluator_id = cd.evaluator_id (+) AND " +
							" ce.document_id = cd.document_id (+) " +
							" AND ce.evaluator_id = ? UNION SELECT cd.doc_type_id " +
							" FROM config_evaluator_documents ce, " +
							" config_documents cd WHERE ce.category_id = ? AND " +
							" ce.evaluator_id = cd.evaluator_id (+) AND " +
							" ce.document_id = cd.document_id (+) AND " +
							" ce.evaluator_id < 0 ";
					queryTmp.prepareStatement(sql);
				  	queryTmp.setString(1, letterIdText);
					queryTmp.setLong(2, eval_id);
					queryTmp.setString(3, letterIdText);

					queryTmp.executePreparedQuery();
					while (queryTmp.next()) {
						String val = queryTmp.getColValue("doc_type_id","0");
						docTypes.add(val);
					}
				}
			}
			if(docTypes.size() ==0){ //if nothing configured in either config_touchpoint_documents or config_evaluator_documents defaulting a doc type of PDF or if there is no touchpoint id grabbed 
				docTypes.add("PDF");
			}

		} catch (Exception ex) {
	      throw new AppException("failed getting getDocTypeIds letter category ID=" + outputLetterType, ex);
	    }
		
		return docTypes;
  }

  private String getLetterID(String letterIDTxt)
  {
	  if (letterIDTxt.equals(OutputFileFactory.WELCOME)) {
		  	letterIDTxt = "WELCOME_LETTER";
      } else if (letterIDTxt.equals(OutputFileFactory.DECLINED)) {
    	  	letterIDTxt = "DECLINE_LETTER";
      } else if (letterIDTxt.equals(OutputFileFactory.COUNTER_OFFER)) {
    	  	letterIDTxt = "COUNTER_OFFER_LETTER";
      } else if (letterIDTxt.equals(OutputFileFactory.EXPIRED)) {
    	  	letterIDTxt = "EXPIRED_OFFER_LETTER";
      } else if (letterIDTxt.equals(OutputFileFactory.GEN_NOTIFICATION)) {
		  	letterIDTxt = "GEN_NOTIFICATION_LETTER";
      } else if (letterIDTxt.equals(OutputFileFactory.WITHDRAW)) {
    	  	letterIDTxt = "WITHDRAW_LETTER";
      } else if (letterIDTxt.equals(OutputFileFactory.CLOSING)) {
    	  	letterIDTxt = "CLOSING_DOCUMENT";
      } else if (letterIDTxt.equals(OutputFileFactory.FIRST_PAYMENT)) {
    	  	letterIDTxt = "FIRST_PAYMENT_LETTER";
      } else if (letterIDTxt.equals(OutputFileFactory.RISK_BASED_PRICING)) {
    	  	letterIDTxt = "RISK_BASED_PRICING_LETTER";
      } else if (letterIDTxt.equals(OutputFileFactory.MISSING_INFO)) {
    	  	letterIDTxt = "MISSING_INFO";
      }  else if (letterIDTxt.equals(OutputFileFactory.EARLY_DISCLOSURE_DOCUMENT)) {
      		letterIDTxt = "EARLY_DISCLOSURE_DOCUMENT";
      } else if (letterIDTxt.equals(OutputFileFactory.INITIAL)) {
      		letterIDTxt = "INITIAL";
      } else if (letterIDTxt.equals(OutputFileFactory.FOLLOW_UP_1)) {
      		letterIDTxt = "FOLLOW_UP_1";
      } else if (letterIDTxt.equals(OutputFileFactory.FOLLOW_UP_2)) {
      		letterIDTxt = "FOLLOW_UP_2";
      } else {
      	//do nothing and keep it as is
      }
	  return letterIDTxt;
  }


}
