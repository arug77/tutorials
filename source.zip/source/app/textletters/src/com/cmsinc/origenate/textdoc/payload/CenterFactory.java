package com.cmsinc.origenate.textdoc.payload;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import java.util.logging.Level;
import com.cmsinc.origenate.textdoc.AppLogger;
import com.cmsinc.origenate.textdoc.AppException;

/**
 * Simple factory class for creating instances of <code>Center</code> 
 * by quering the database.<br>
 * 
 * Treat this class as "thread-safe" (though not typically not used by multiple threads).<br>
 * 
 * @since Origenate 6.0
 */
public class CenterFactory {
  private static final String QUERY_SQL = 
    "SELECT cc.CENTER_NAME, cc.STREET_NUMBER_TXT, cc.STREET_NAME_TXT, cc.STREET_TYPE_ID, " +
    "       mt.STREET_TYPE_DESCRIPTION_TXT, cc.CITY_TXT, cc.STATE_ID, cc.ZIPCODE_TXT, " +
    "       cc.PHONE_NUMBER_TXT, cc.FAX_NUMBER_TXT " +
    "FROM CREDIT_REQUEST_ORIGINATOR co, EVALUATOR_ORIGINATOR eo, CONFIG_CENTER cc, MSTR_STREET_TYPE mt " +
    "WHERE co.REQUEST_ID = ? AND co.EVALUATOR_ID = ? AND " +
    "      co.EVALUATOR_ID = eo.EVALUATOR_ID AND " +
    "      co.ORIGINATOR_ID = eo.ORIGINATOR_ID AND " +
    "      eo.BUYING_CENTER_ID = cc.CENTER_ID AND " +
    "      eo.EVALUATOR_ID = cc.EVALUATOR_ID AND " +
    "      cc.STREET_TYPE_ID = mt.STREET_TYPE_ID (+)";

  private Connection conn = null;
  
  public CenterFactory(Connection aConnection) {
    this.conn = aConnection;
  }
  
  public Center getCenter(long aRequestId, long anEvaluatorId) throws AppException {
    Center data = null;
    PreparedStatement stmt = null;
    ResultSet rs = null;
    long elapsedQueryTime = 0;
    
    try {
      int idx = 1;
      long startQueryTime = (new Date()).getTime();
      stmt = this.conn.prepareStatement(QUERY_SQL);
      stmt.setLong(idx++, aRequestId);
      stmt.setLong(idx++, anEvaluatorId);
      rs = stmt.executeQuery();
      if (rs != null && rs.next()) {            
        data = new Center(rs.getString("CENTER_NAME"), rs.getString("STREET_NUMBER_TXT"), 
          rs.getString("STREET_NAME_TXT"), rs.getString("STREET_TYPE_ID"), rs.getString("STREET_TYPE_DESCRIPTION_TXT"), 
          rs.getString("CITY_TXT"), rs.getString("STATE_ID"), rs.getString("ZIPCODE_TXT"), 
          rs.getString("PHONE_NUMBER_TXT"), rs.getString("FAX_NUMBER_TXT"));
      }
      
      long endQueryTime = (new Date()).getTime();
      elapsedQueryTime = endQueryTime - startQueryTime;
    }
    catch (SQLException ex) {
      throw new AppException("failed to query CREDIT_REQUEST_ORIGINATOR / EVALUATOR_ORIGINATOR / CONFIG_CENTER " +
        "for request ID=" + aRequestId + ", evaluator ID=" + anEvaluatorId, ex);
    }
    finally {
		try{ if(rs != null) rs.close(); }catch(Exception e1){e1.printStackTrace();}
		try{ if(stmt != null) stmt.close(); }catch(Exception e1){e1.printStackTrace();}
	}
    
    AppLogger.logger.log(Level.FINEST, Thread.currentThread().getName() + 
      ": queried " + 1 + " Center object in " + elapsedQueryTime + " ms");
    return data;
  }
}
