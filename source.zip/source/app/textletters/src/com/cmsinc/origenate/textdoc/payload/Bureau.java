package com.cmsinc.origenate.textdoc.payload;

/**
 * Data about the bureua that reported on applicant, including address.<br>
 * 
 * Treat this class as "thread-safe", since it is immutable once created.
 * 
 * @since Origenate 6.0
 */
public class Bureau {
  
  private String name = null;
  private String consumerRefCode = null;
  private String address1 = null;
  private String address2 = null;
  private String city = null;
  private String state = null;
  private String zipcode = null;
  private String phone = null;
  private String mailurl = null;
  private boolean isBureauOfRecord = false;
  
  Bureau(String aName, String aConsumerRefCode, String anAddress1, String anAddress2, String aCity, 
    String aState, String aZipcode, String aPhone, boolean aBureauOfRecordFlag, String mailurl) {

    this.name = aName;
    this.consumerRefCode = aConsumerRefCode;
    this.address1 = anAddress1;
    this.address2 = anAddress2;
    this.city = aCity;
    this.state = aState;
    this.zipcode = aZipcode;
    this.phone = aPhone;
    this.isBureauOfRecord = aBureauOfRecordFlag;
    this.mailurl = mailurl;
  }
  
  public String getConsumerRefCode() {
    return this.consumerRefCode;
  }
  
  public String getName() {
    return this.name;
  }
  
  public String getAddress1() {
    return this.address1;
  }
  
  public String getAddress2() {
    return this.address2;
  }
  
  public String getCity() {
    return this.city;
  }
  
  public String getState() {
    return this.state;
  }
  
  public String getZipcode() {
    return this.zipcode;
  }
  
  public String getPhone() {
    return this.phone;
  }

  public boolean isBureauOfRecord() {
    return this.isBureauOfRecord;
  }

  public String getMailurl() {
	return mailurl;
  }

  public void setMailurl(String mailurl) {
	this.mailurl = mailurl;
  }  
}
