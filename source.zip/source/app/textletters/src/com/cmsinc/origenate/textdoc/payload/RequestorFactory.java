package com.cmsinc.origenate.textdoc.payload;

import java.util.Date;
import java.util.LinkedList;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import com.cmsinc.origenate.textdoc.AppLogger;
import com.cmsinc.origenate.textdoc.AppException;

/**
 * Simple factory class for creating instances of <code>Requestor</code> 
 * by quering the database.<br>
 * 
 * Treat this class as "thread-hostile".<br>
 * 
 * @since Origenate 6.0
 */
public class RequestorFactory {
  private static final String QUERY_SQL = 
    "SELECT rq.REQUESTOR_ID, rq.REQUESTOR_TYPE_ID , rq.APPSEQNO, rq.LAST_NAME_TXT, rq.FIRST_NAME_TXT, " + 
    "       rq.MIDDLE_NAME_TXT, rq.SOC_SEC_NUM_TXT, ms.SUFFIX_DESCRIPTION_TXT, ms.SUFFIX_ROMAN_TXT, " +
    "       ra.STREET_NUMBER_TXT , ra.STREET_NAME_TXT , ra.STREET_TYPE_ID , mt.STREET_TYPE_DESCRIPTION_TXT , " +
    "       ra.ADDRESS2_TXT , ra.CITY_TXT , ra.STATE_ID , ra.APT_SUITE_BOX_TXT , ra.ZIPCODE_TXT , " +
    "       ra.PHONE_NUMBER_TXT , ra.PHONE_EXTENSION_TXT , ra.FAX_NUMBER_TXT  " +
    "FROM REQUESTOR rq, MSTR_REQUESTOR_SUFFIX ms, REQUESTOR_ADDRESS ra, MSTR_STREET_TYPE mt " +
    "WHERE rq.REQUEST_ID = ? AND rq.EVALUATOR_ID = ? AND " +
    "      rq.SUFFIX_ID = ms.SUFFIX_ID (+) AND " +
    "      rq.REQUESTOR_ID = ra.REQUESTOR_ID (+) AND " +
    "      ra.REQUEST_ID = ? AND ra.EVALUATOR_ID = ? AND " + 
    "      (ra.ADDRESS_TYPE_ID = ? OR ra.ADDRESS_TYPE_ID = ?) AND " +
    "      ra.STREET_TYPE_ID = mt.STREET_TYPE_ID (+) " +
	
    "UNION " +
	
	"SELECT rb.REQUESTOR_ID, rb.REQUESTOR_TYPE_ID , rq.APPSEQNO, rq.LAST_NAME_TXT, rq.FIRST_NAME_TXT, " + 
    "       rq.MIDDLE_NAME_TXT, rq.SOC_SEC_NUM_TXT, ms.SUFFIX_DESCRIPTION_TXT, ms.SUFFIX_ROMAN_TXT, " +
    "       ra.STREET_NUMBER_TXT , ra.STREET_NAME_TXT , ra.STREET_TYPE_ID , mt.STREET_TYPE_DESCRIPTION_TXT , " +
    "       ra.ADDRESS2_TXT , ra.CITY_TXT , ra.STATE_ID , ra.APT_SUITE_BOX_TXT , ra.ZIPCODE_TXT , " +
    "       ra.PHONE_NUMBER_TXT , ra.PHONE_EXTENSION_TXT , ra.FAX_NUMBER_TXT  " +
    "FROM REQUESTOR rq, MSTR_REQUESTOR_SUFFIX ms, REQUESTOR_BUSINESS rb, REQUESTOR_ADDRESS ra, MSTR_STREET_TYPE mt  " +
    "WHERE rb.REQUEST_ID = ? AND " +
    "      rb.REQUEST_ID = rq.REQUEST_ID (+) AND rb.REQUESTOR_ID = rq.REQUESTOR_ID (+) AND" +
	"      rb.REQUEST_ID = ra.REQUEST_ID (+) AND rb.REQUESTOR_ID = ra.REQUESTOR_ID (+) AND" +
    "      rq.SUFFIX_ID = ms.SUFFIX_ID (+) AND ra.STREET_TYPE_ID = mt.STREET_TYPE_ID (+) " +
    "ORDER BY REQUESTOR_TYPE_ID";
	
  

  private Connection conn = null;
  
  public RequestorFactory(Connection aConnection) {
    this.conn = aConnection;
  }
  
  public Requestor[] getRequestors(long aRequestId, long anEvaluatorId) throws AppException {
    LinkedList list = new LinkedList();
    PreparedStatement stmt = null;
    ResultSet rs = null;
    long elapsedQueryTime = 0;
    
    try {
      int idx = 1;
      long startQueryTime = (new Date()).getTime();
	  
	  AppLogger.logger.log(Level.FINEST, "Requestor Query: " + QUERY_SQL);
	  
      stmt = this.conn.prepareStatement(QUERY_SQL);
      stmt.setLong(idx++, aRequestId);
      stmt.setLong(idx++, anEvaluatorId);
      stmt.setLong(idx++, aRequestId);
      stmt.setLong(idx++, anEvaluatorId);
      stmt.setLong(idx++, AddressTypes.MAILING_ADDRESS);
      stmt.setLong(idx++, AddressTypes.CURRENT_ADDRESS);
	  stmt.setLong(idx++, aRequestId);
      rs = stmt.executeQuery();
      while (rs != null && rs.next()) { 
        long requestorId = rs.getLong("REQUESTOR_ID");          
        int typeOfRequestor = rs.getInt("REQUESTOR_TYPE_ID");
        if (rs.wasNull()) 
          typeOfRequestor = -1;
          
        long appSeqno = rs.getLong("APPSEQNO");
        if (rs.wasNull())
          appSeqno = -1; 
             
        Requestor data = new Requestor(requestorId, typeOfRequestor, appSeqno,
          rs.getString("LAST_NAME_TXT"), rs.getString("FIRST_NAME_TXT"), 
          rs.getString("MIDDLE_NAME_TXT"), rs.getString("SUFFIX_ROMAN_TXT"), 
          rs.getString("SOC_SEC_NUM_TXT"), rs.getString("STREET_NUMBER_TXT"), 
          rs.getString("STREET_NAME_TXT"), rs.getString("STREET_TYPE_ID"), 
          rs.getString("STREET_TYPE_DESCRIPTION_TXT"), rs.getString("ADDRESS2_TXT"), 
          rs.getString("APT_SUITE_BOX_TXT"), rs.getString("CITY_TXT"), 
          rs.getString("STATE_ID"), rs.getString("ZIPCODE_TXT"), 
          rs.getString("PHONE_NUMBER_TXT"), rs.getString("PHONE_EXTENSION_TXT"), 
          rs.getString("FAX_NUMBER_TXT"));
        list.add(data);
      }

      long endQueryTime = (new Date()).getTime();
      elapsedQueryTime = endQueryTime - startQueryTime;
    }
    catch (SQLException ex) {
      throw new AppException("failed to query REQUESTOR / REQUESTOR_ADDRESS " +
        "for request ID=" + aRequestId + " and evaluator ID=" + anEvaluatorId, ex);
    }
    finally {
		try{ if(rs != null) rs.close(); }catch(Exception e1){e1.printStackTrace();}
		try{ if(stmt != null) stmt.close(); }catch(Exception e1){e1.printStackTrace();}
	}
    
    AppLogger.logger.log(Level.FINEST, Thread.currentThread().getName() + 
      ": queried " + list.size() + " Requestor objects in " + elapsedQueryTime + " ms");
    
    Requestor[] arrData = null;
    if (list.size() > 0)
      arrData = (Requestor[]) list.toArray(new Requestor[0]);
    return arrData;
  }
}
