package com.cmsinc.origenate.textdoc.letters;

import java.sql.Connection;

/**
 * Factory for selecting counter-offer"able" credit apps and creating <code>CounterOfferLetter</code> instances.<br>
 * 
 * Treat this class as "thread-hostile".
 * 
 * @since Origenate 6.0
 */
public class CounterOfferLetterFactory extends LetterFactory {
  private static final String COUNTEROFFER_SELECT_LIST = 
    "cps.counter_delay_days_num delay_days, ev.counter_printer_txt printer_text";
    
  private static final String COUNTEROFFER_FROM_CLAUSE = 
    "xref_tasks_in_task_group xq";

  /**
   * To select counter-offer apps: 
   * 
   * The application must have a decision status of CONDITIONAL and an application status of DECISIONED.
   * The application must be in Contract Admin Task Type.
   * The current date must be beyond the application's initiated date plus the counteroffer delay.
   */  
  private static final String COUNTEROFFER_WHERE_CLAUSE = 
    "cr.decision_status_id = 1 AND " +
    "cr.task_id = xq.task_id AND " +
    "cr.product_id = xq.product_id AND " +
    "(xq.evaluator_id = cr.evaluator_id OR xq.evaluator_id = -1) AND " +
    //"xq.task_group_id = ''CONTRACTADMIN'' AND " +
	"(cr.booking_status_id not in (2,3) or cr.booking_status_id is null) AND " +
    "sysdate > (cr.initiation_dt + cps.counter_delay_days_num)";
    
  public static final String LETTER_CATEGORY = "COUNTER_OFFER_LETTER";
   
  protected String getLetterCategory() {
    return LETTER_CATEGORY;
  }    
  
  /**
   * Restricted ctor for creating an instance of this class.
   *  
   * @param someEvaluatorIds
   *  evaluators to search by, or null to search regardless of evaluator.
   */
  public CounterOfferLetterFactory(Connection aConnection, long[] someEvaluatorIds) {
    super(aConnection, LETTER_CATEGORY, someEvaluatorIds);
  }
  
  protected StringBuffer selectList() {
    StringBuffer buf = super.selectList();
    buf = appendCharIfNeeded(buf, ',');
    buf.append(COUNTEROFFER_SELECT_LIST);
    return buf;
  }
  
  protected StringBuffer fromClause() {
    StringBuffer buf = super.fromClause();
    buf = appendCharIfNeeded(buf, ',');
    buf.append(COUNTEROFFER_FROM_CLAUSE);
    return buf;
  }  
  
  protected StringBuffer whereClause() {
    StringBuffer buf = super.whereClause();
    buf = appendWordIfNeeded(buf, "AND");
    buf.append(COUNTEROFFER_WHERE_CLAUSE);
    return buf;
  }  
}
