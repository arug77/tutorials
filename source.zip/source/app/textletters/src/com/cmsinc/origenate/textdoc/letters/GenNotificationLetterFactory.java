package com.cmsinc.origenate.textdoc.letters;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import com.cmsinc.origenate.textdoc.AppLogger;
import com.cmsinc.origenate.textdoc.AppException;

/**
 * Factory for selecting credit apps and creating <code>General NotificationLetter</code> instances.<br>
 * 
 * Treat this class as "thread-hostile".
 * 
 * @since Origenate 8.5
 */
public class GenNotificationLetterFactory extends LetterFactory
{
	private String queryId="0";

	private long evaluatorId=-99;

	private String whereclauseqry="";

	private static final String GEN_NOTIFICATION_SELECT_LIST = 
		"cps.turndown_delay_days_num delay_days, ev.gen_notification_printer_txt printer_text";

	/**
	 * To select General Notification apps: 
	 *
	 */  
	private static final String GEN_NOTIFICATION_WHERE_CLAUSE =     
		"";

    
	public static final String LETTER_CATEGORY = "GEN_NOTIFICATION_LETTER";
   
	protected String getLetterCategory() 
	{
		return LETTER_CATEGORY;
	}
  
	/**
	 * Restricted ctor for creating an instance of this class.
	 *  
	 * @param someEvaluatorIds
	 *  evaluators to search by, or null to search regardless of evaluator.
	 */
	public GenNotificationLetterFactory(Connection aConnection, long[] someEvaluatorIds, String aqueryId) 
	{
		super(aConnection, LETTER_CATEGORY, someEvaluatorIds);
		if(aqueryId!=null)
			queryId=aqueryId;
		if(someEvaluatorIds.length!=0)
			evaluatorId=someEvaluatorIds[0];
	}
  
	protected StringBuffer selectList() 
	{
		StringBuffer buf = super.selectList();
		buf = appendCharIfNeeded(buf, ',');
		buf.append(GEN_NOTIFICATION_SELECT_LIST);
		return buf;
	}  
  
	protected StringBuffer whereClause() 
	{
		/*
		 * Special where clause that pulls when to use query from command line
		 * This is done so the when to use applies before the pull
		 *! for this letter type only!
		 */
		PreparedStatement stmtq = null;
		ResultSet rsq = null;
		try	{
			stmtq = null;
			stmtq = conn.prepareStatement("select QUERY_TXT FROM CONFIG_DOC_QUERIES WHERE EVALUATOR_ID= ?  AND QUERY_ID= ?");
			stmtq.setLong(1,evaluatorId);
			stmtq.setString(2,queryId);
			rsq = null;
			rsq = stmtq.executeQuery();
			while(rsq.next())
			{
				whereclauseqry = "cr.request_id in ("+rsq.getString("QUERY_TXT")+") ";
			}
				AppLogger.logger.log(Level.FINEST, "General Notification Letter WHERE CLAUSE WITH EVALID="+evaluatorId+" AND QueryID="+queryId+" is :"+whereclauseqry);
		}
		catch (SQLException ex) {
			AppLogger.logger.log(Level.SEVERE, "ERROR PULLING WHEN TO USE FOR GENERAL_NOTIFICATION_LETTER, QueryID="+queryId+" AND EVALID="+evaluatorId+" ERROR: "+ ex);
		}
		finally {
			try{ if(rsq != null) rsq.close(); }catch(Exception e1){e1.printStackTrace();}
			try{ if(stmtq != null) stmtq.close(); }catch(Exception e1){e1.printStackTrace();}
		}
		StringBuffer buf = super.whereClause();
		if(whereclauseqry.length()>0)
		{
		 buf = appendWordIfNeeded(buf, "AND");
		}
		buf.append(whereclauseqry);
		return buf;
	}  
}
