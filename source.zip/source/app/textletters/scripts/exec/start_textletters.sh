#!/bin/sh
#
# Start generation of text letters data extract
#

INIFILE=/opt/jrun4/servers/dv60/cfusion-ear/cfusion-war/config/origenate.ini
LOGFILE=/opt/origenate/dv60/start_textletter.sh.log
OUTDIR=/opt/origenate/dv60/textletters

nohup java -classpath $JAVA_HOME/jre/lib/rt.jar:.:../lib/common.jar:../lib/ojdbc6.jar:../lib/ocrs12.jar  \
  com.cmsinc.origenate.textdoc.TextdocApp -outputDir $OUTDIR  $INIFILE >> $LOGFILE &
exit 0
