/**
 * DocumentArachive.java
 * Date: 01/16/2012
 * Author: Jayanth Venkatraj
 *
 * This program gets the Document Archive Query for the Evaluator ID and the Profile ID in command line argument
 * and runs it to get the applications to delete completely from the system. The Document
 * Archive Query is expected to return at least the REQUEST_ID and CLIENT_APP_ID and have only
 * EVALUATOR_ID as a wildcard field in the WHERE clause. Any apps that are returned by the
 * query are copied, moved or deleted.
 */

package com.cmsinc.origenate.documentarchive;

import java.sql.*;
import java.io.*;
import java.util.*;

import com.cmsinc.origenate.doc.GenJob;
import com.cmsinc.origenate.cp.mpe.Mpe;
import com.cmsinc.origenate.xmldbt.GenX;
import com.cmsinc.origenate.util.COLEncrypt;
import com.cmsinc.origenate.util.IniFile;
import com.cmsinc.origenate.util.LogMsg;
import com.cmsinc.origenate.util.OWASPSecurity;
import com.cmsinc.origenate.util.Query;
import com.cmsinc.origenate.util.SQLSecurity;
import com.cmsinc.origenate.util.SQLUpdate;
import com.cmsinc.origenate.event.JournalEvents;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;
import com.cmsinc.origenate.crypto.Crypto;
import com.cmsinc.origenate.crypto.CryptoFactory;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import org.w3c.dom.Document;
import org.xml.sax.InputSource;
import oracle.sql.BFILE;
import oracle.jdbc.OracleResultSet;

public class DocumentArchive {


	String evaluatorID = "";
	String docQuery = "";
	LogMsg log_obj = new LogMsg();;
	String queryID = "";
	String sHost = "";
	String sSIDname = "";
	String sUser = "";
	String sPass = "";
	String sPort = "";
	String sTNSEntry = "";
	String sIniFile = "";
	String profile_id = "";
	int i_dbg_level = 0;
	String profileID = "";
	String filexml= "";
	String xml_file_path = "outfile.xml";
	IniFile ini = new IniFile();
	String logFile = "";
	String zip_path = "";

      /*
      * in order to prevent duplcaite record in arrayLisy fileList_contr_doc, fileList_tafTitlefile,List_tafFlood , fileList_tafAppraisal fileList_tty
      * fileList_orig_doc
      */
      HashSet<String> contractingCheck = new HashSet<String>();
      HashSet<String> tafDocCheck = new HashSet<String>();
      HashSet<String> ttyCheck = new HashSet<String>();
      HashSet<String> origDocCheck = new HashSet<String>();

	public static void main(String[] args) {
		DocumentArchive da = new DocumentArchive();
		try {
			da.run(args);
		}
		catch (Exception e) {
		}

		System.exit(0);
	}

	public DocumentArchive() {
	}

	private void archiveApps(Connection con) throws Exception {
		Query query = null;
		ArrayList<String> doc_type_id_lst = new ArrayList<String>();
		String ftp_type_id = "";
		String zip_file_name_txt = "";
		String remote_file_name_txt = "";
		String file_server_txt = "";
		String ftp_port_name_txt = "";
		String ftp_user_name = "";
		String ftp_password = "";
		String ftp_password_file = "";
		String version_num = "";
		String copy_move_flg = "";
		String copy_txt = "";
		ArrayList<String> taf_type_list = new ArrayList<String>();
		String xml_stylesheet = "";
		String file_dir_contr_docs = ini.getINIVar("contracting.contract_docs_path");
		String file_dir_taf_title = ini.getINIVar("taf.taf_title_dir");
		String file_dir_taf_appraisal = ini.getINIVar("taf.taf_appraisal_dir");
		String file_dir_taf_fax = ini.getINIVar("taf.taf_flood_dir");
		String tty_export_txt = "";
		ArrayList<String> orig_doc_type_id_lst = new ArrayList<String>();
		String styled_output_file_name_txt = "";
		String stylesheet_location = "";
		boolean version_flg = false;
		boolean contr_doc_extract = false;
		boolean taf_extract = false;
		boolean tty_extract = false;
		boolean orig_doc_extract = false;
		boolean ttyEncryptedFlg = false;
        String tmpIndividualIndexingFlg = "";
        boolean indvidualIndexingFlg = false;
		String encryptionUserName = "origenate_"+ini.getINIVar("database.user");
		encryptionUserName = encryptionUserName.toLowerCase();
		String xmlIndexFileInfo = "";
		filexml = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\" ?><DocumentArchive>";

		//keep the file lists seperate for each individual extract because the file extracts may be coming from different directories - the extract would error out if it were to try to iterate over the generic fileList a file in that list did not exist in the a given directory
		ArrayList<ContrDocsContainerBean> fileList_contr_doc = new ArrayList<ContrDocsContainerBean>();
		ArrayList<TAFDocsContainerBean> fileList_tafTitle = new ArrayList<TAFDocsContainerBean>();
		ArrayList<TAFDocsContainerBean> fileList_tafFlood = new ArrayList<TAFDocsContainerBean>();
		ArrayList<TAFDocsContainerBean> fileList_tafAppraisal = new ArrayList<TAFDocsContainerBean>();
		ArrayList<GenericDocsContainerBean> fileList_tty = new ArrayList<GenericDocsContainerBean>();
		ArrayList<OrigDocsContainerBean> fileList_orig_doc = new ArrayList<OrigDocsContainerBean>();

		String tmpDirRoot = zip_path + "/temp";
		String tmpDir = tmpDirRoot + "/files";
		String tmpDirZip = tmpDirRoot + "/zip";
		createTempDir(tmpDirRoot);
		createTempDir(tmpDir);
		createTempDir(tmpDirZip);

		// Get the App Deletion Query
		String sql =
			"select cdq.query_id, cdq.query_txt from config_doc_queries cdq, evaluator e, config_document_archive cda " +
			"where e.evaluator_id = cdq.evaluator_id  " +
			"and cda.query_id = cdq.query_id  " +
			"and cda.profile_id = ?  " +
			"and cdq.when_to_use_flg = 11 " + // Check that it is an doc archive query
			"and e.evaluator_id = ? ";

		try {
			query = new Query(con);
			query.prepareStatement(sql);
			query.setInt(1, Integer.parseInt(profileID));
			query.setInt(2, Integer.parseInt(evaluatorID));
			query.executePreparedQuery();
		}
		catch(Exception e) {
			log(0, "Document Archive: Exception getting Document Archive Query: " + e.toString(), e);
			throw new Exception("Document Archive: Exception getting Document Archive Query: " + e.toString(), e);
		}

		if(query.next()) {
			docQuery = query.getColValue("query_txt","");
			queryID = query.getColValue("query_id","");
		}

		// If nothing configured
		if(docQuery.length() == 0) {//not a realistic scenario now that query_id can not be null in the db
			log(0, "Document Archive : No Document Archive query configured for Evaluator ID " + evaluatorID);
			return;
		}

		try {
			Query queryTmp = new Query(con);
			queryTmp.prepareStatement("select ftp_type_id, nvl(doc_type_id,'-1') as doc_type_id, nvl(taf_type_txt,'-1') as taf_type_txt, stylesheet_txt, file_name_txt, remote_file_name_txt, ftp_file_server_txt, ftp_port_name_txt, ftp_user_txt, ftp_password_txt, ftp_passwordkey_path_txt, version_flg, copy_move_flg, TTY_EXPORT_TXT, nvl(ORIG_DOC_TYPE_ID,'-1') as ORIG_DOC_TYPE_ID, styled_output_file_name_txt, individual_indexing_flg from config_document_archive where profile_id = ? and evaluator_id = ? and active_flg = 1");
			queryTmp.setInt(1, Integer.parseInt(profileID));
			queryTmp.setInt(2, Integer.parseInt(evaluatorID));
			queryTmp.executePreparedQuery();

			if(queryTmp.next()){
				//doc_type_id = queryTmp.getColValue("doc_type_id");
				ftp_type_id = queryTmp.getColValue("ftp_type_id", "0");
				zip_file_name_txt = queryTmp.getColValue("file_name_txt");
				remote_file_name_txt = queryTmp.getColValue("remote_file_name_txt","");
				file_server_txt = queryTmp.getColValue("ftp_file_server_txt");
				ftp_port_name_txt = queryTmp.getColValue("ftp_port_name_txt", "");
				xml_stylesheet = queryTmp.getColValue("stylesheet_txt", "");
				ftp_user_name = queryTmp.getColValue("ftp_user_txt","");
				ftp_password = queryTmp.getColValue("ftp_password_txt","");
				ftp_password_file = queryTmp.getColValue("ftp_passwordkey_path_txt","");
				version_num = queryTmp.getColValue("version_flg");
				copy_move_flg = queryTmp.getColValue("copy_move_flg");
				tty_export_txt = queryTmp.getColValue("TTY_EXPORT_TXT");
				//orig_doc_type_id = queryTmp.getColValue("ORIG_DOC_TYPE_ID");
				styled_output_file_name_txt = queryTmp.getColValue("styled_output_file_name_txt");
				tmpIndividualIndexingFlg = queryTmp.getColValue("individual_indexing_flg");
                if (tmpIndividualIndexingFlg.equals("1")){
					indvidualIndexingFlg = true;
				}
                else{
                    indvidualIndexingFlg = false;
				}
			}
			else{
				log(0,"Error during Document Archive : No record found for the given Profile ID. Please check config.");
				throw new Exception("Caught exception running doc archive ");
			}

			Query queryTafTypes = new Query(con);
			queryTafTypes.prepareStatement("select nvl(TAF_TYPE_TXT,'-1') as TAF_TYPE_TXT from CONFIG_DOC_ARCHIVE_TAF_TYPE where profile_id = ? and evaluator_id = ?");
			queryTafTypes.setInt(1, Integer.parseInt(profileID));
			queryTafTypes.setInt(2, Integer.parseInt(evaluatorID));
			queryTafTypes.executePreparedQuery();

			taf_type_list.clear();
			while (queryTafTypes.next()){
				String tafTypeTxt = queryTafTypes.getColValue("TAF_TYPE_TXT");
				if(!tafTypeTxt.equals("-1")){
					taf_type_list.add(tafTypeTxt);
				}
			}

			queryTmp.prepareStatement("select nvl(ORIG_DOC_TYPE_ID,'-1') as ORIG_DOC_TYPE_ID from xref_document_archive_docs where profile_id = ? and evaluator_id = ?");
			queryTmp.setInt(1, Integer.parseInt(profileID));
			queryTmp.setInt(2, Integer.parseInt(evaluatorID));
			queryTmp.executePreparedQuery();

			while (queryTmp.next()){
				String origDocTypeID = queryTmp.getColValue("ORIG_DOC_TYPE_ID");
				if(!origDocTypeID.equals("-1")){
					orig_doc_type_id_lst.add(origDocTypeID);
				}
			}

			queryTmp.prepareStatement("select nvl(DOC_TYPE_ID,'-1') as DOC_TYPE_ID from xref_document_archive_doctypes where profile_id = ? and evaluator_id = ?");
			queryTmp.setInt(1, Integer.parseInt(profileID));
			queryTmp.setInt(2, Integer.parseInt(evaluatorID));
			queryTmp.executePreparedQuery();

			while (queryTmp.next()){
				String contrDocTypeId = queryTmp.getColValue("DOC_TYPE_ID");
				if(!contrDocTypeId.equals("-1")){
					doc_type_id_lst.add(contrDocTypeId);
				}
			}

			String tmp_logtxt1 = "";
			if(version_num.equals("1")){
				version_flg = true; //most recent version
			}
			else{
				version_flg = false; //all versions
			}

			if(copy_move_flg.equals("0"))
				tmp_logtxt1 = "Copy: ";
			else
				tmp_logtxt1 = "Move: ";


			if(doc_type_id_lst.size() > 0)
			{
				contr_doc_extract = true;
				String tmp_logtxtContr = "Contracting files.";
				if(version_flg){
					tmp_logtxtContr = "most recent " + tmp_logtxtContr;
				}
				else{
					tmp_logtxtContr = "most recent " + tmp_logtxtContr;
				}
				log(0, tmp_logtxt1 + "Contracting files.");
			}
			if(orig_doc_type_id_lst.size() > 0){
				orig_doc_extract = true;
				log(0, tmp_logtxt1 + "Origenate Documents.");
			}
			if(!tty_export_txt.equalsIgnoreCase("None")){
				tty_extract = true;
				log(0, tmp_logtxt1 + "TTY Export Documents.");
			}
			if(taf_type_list.size()>0){
				taf_extract = true;
				log(0, tmp_logtxt1 + "TAF files.");
			}
		}
		catch (Exception e) {
			log(0, "DocumentArchive: Document Archive Query error extracting config columns: " + e.toString(), e);
			throw new Exception("DocumentArchive: Document Archive config columns have bad data: " + e.toString(), e);
		}

		//unused
		if(copy_move_flg.equals("0"))
			copy_txt = "Copied";
		else
			copy_txt = "Moved";

		//get the location of the stylesheet from the ini file or use the path given in the CONFIG_DOCUMENT_ARCHIVE table
		stylesheet_location = ini.getINIVar("mpe.xslt_dir");

		if(xml_stylesheet == null || xml_stylesheet.equals(""))
			log(0, "Empty stylesheet, no styling will be done");
		else if(xml_stylesheet.contains("/"))
			log(0, "Using stylesheet path defined in config");
		else{
			log(0, "Using stylesheet path defined in origenate.ini");
			xml_stylesheet = stylesheet_location + "/" + xml_stylesheet;
		}

		// Build and execute the Doc Archive selection query
		GenJob genJob = new GenJob(con, log_obj);
		query = buildAndExecuteQuery(genJob, con, docQuery, queryID, evaluatorID);

		// Now we have list of request_id's to archive

		String request_id = "", app_id = "";
		ArrayList<String> requestIdList = new ArrayList<String>();
		boolean success = true;

		// Count of apps successfully archived
		int totalCount = 0;
		int successfulCount = 0;
		// Will be running one app at a time, so don't want to commit to any
		// changes until all files are archived for an app.
		//con.setAutoCommit(false);

		while(query.next()) {
			success = true;
			xmlIndexFileInfo = "";//reset for given loop

			try {
				request_id = query.getColValue("request_id","");
				requestIdList.add(request_id);//create an array list of all of the request ids that are picked up by the WTU query, this is so we only need to iterate through the query once
			}
			catch (Exception e) {
				// This exception should be caught the first time through this loop
				//log(0, "DocumentArchive: Document Archive Query must have request_id and client_app_id columns: " + e.toString());
				throw new Exception("DocumentArchive: Document Archive Query must have request_id and client_app_id columns: " + e.toString(), e);
			}

			//now get all the file info for each individual extract and place it into an arraylist for each individual extract
			try{
				if(request_id.length() > 0 && !request_id.equals("")){
					Query queryTmp = new Query(con);
					//String file_name = "";
					if(contr_doc_extract)
					{
						fileList_contr_doc = getContrDocsFileInfo(fileList_contr_doc, queryTmp, request_id, doc_type_id_lst, file_dir_contr_docs);
					}
					if(taf_extract)
					{
						if(taf_type_list.contains("T"))
						{
							fileList_tafTitle = getTAFDocsFileInfo(fileList_tafTitle, queryTmp, request_id, "title", file_dir_taf_title);
						}
						if(taf_type_list.contains("A"))
						{
							fileList_tafAppraisal = getTAFDocsFileInfo(fileList_tafAppraisal, queryTmp, request_id, "appraisal",file_dir_taf_appraisal);
						}
						if(taf_type_list.contains("F"))
						{
							fileList_tafFlood = getTAFDocsFileInfo(fileList_tafFlood, queryTmp, request_id, "flood", file_dir_taf_fax);
						}
						if(!taf_type_list.contains("T") && !taf_type_list.contains("A") && taf_type_list.contains("F"))
						{
							log(0, "Document Archive: TAF Extract error, values queried from CONFIG_DOC_ARCHIVE_TAF_TYPE does not contain expected values.");
						}
					}

					if(tty_extract){
						fileList_tty = getTTYFileName(fileList_tty, queryTmp, request_id, tty_export_txt);
					}

					if(orig_doc_extract){
						fileList_orig_doc = getOrigDocsFileInfo(fileList_orig_doc, queryTmp, request_id, orig_doc_type_id_lst ,version_flg, con);
					}

				} else {
					log(0, "Document Archive: Doc Archive Query must have request_id " );
				}
			} catch (Exception e) {
				log(0, "DocumentArchive: Document Archive error: " + e.toString(), e);
			}

		}

		Boolean failedCopy = false;
		String dirToCopy = "";
		String fileNameToCopy = "";
		boolean latestVersion = false;
		//copy the files to a temporary folder from where we will zip it up
		if (contr_doc_extract && fileList_contr_doc.size() != 0) {
			for (ContrDocsContainerBean singleFile : fileList_contr_doc) {
				dirToCopy = getDirNameFromString(singleFile.getFileAndDir());
				fileNameToCopy = getFileNameFromString(singleFile.getFileAndDir());

				latestVersion = singleFile.isLatestVersion();
				if ((latestVersion && version_flg) || (!version_flg)) {
					failedCopy = copyFiles(fileNameToCopy, dirToCopy, tmpDir, singleFile);
					singleFile.setErroredFile(failedCopy);

					if (!failedCopy) {
						successfulCount++;

					}
					totalCount++;
				}
			}
		}
		if (taf_extract) {
			if (taf_type_list.contains("T") && fileList_tafTitle.size() != 0) {
				for (TAFDocsContainerBean singleFile : fileList_tafTitle) {
					dirToCopy = singleFile.getDirName();
					fileNameToCopy = singleFile.getFileName();
					failedCopy = copyFiles(fileNameToCopy, dirToCopy, tmpDir, singleFile);
					singleFile.setErroredFile(failedCopy);

					if (!failedCopy) {
						successfulCount++;

					}
					totalCount++;
				}
			}
			if (taf_type_list.contains("A") && fileList_tafAppraisal.size() != 0) {
				for (TAFDocsContainerBean singleFile : fileList_tafAppraisal) {
					dirToCopy = singleFile.getDirName();
					fileNameToCopy = singleFile.getFileName();
					failedCopy = copyFiles(fileNameToCopy, dirToCopy, tmpDir, singleFile);
					singleFile.setErroredFile(failedCopy);

					if (!failedCopy) {
						successfulCount++;

					}
					totalCount++;
				}
			}
			if (taf_type_list.contains("F") && fileList_tafFlood.size() != 0) {
				for (TAFDocsContainerBean singleFile : fileList_tafFlood) {
					dirToCopy = singleFile.getDirName();
					fileNameToCopy = singleFile.getFileName();
					failedCopy = copyFiles(fileNameToCopy, dirToCopy, tmpDir, singleFile);
					singleFile.setErroredFile(failedCopy);

					if (!failedCopy) {
						successfulCount++;

					}
					totalCount++;
				}
			}
		}
		if (orig_doc_extract && fileList_orig_doc.size() != 0) {
			for (OrigDocsContainerBean singleFile : fileList_orig_doc) {
				dirToCopy = getDirNameFromString(singleFile.getFileAndDir());
				fileNameToCopy = getFileNameFromString(singleFile.getFileAndDir());
				latestVersion = singleFile.isLatestVersion();
				if ((latestVersion && version_flg) || (!version_flg)) {
					failedCopy = copyFiles(fileNameToCopy, dirToCopy, tmpDir, singleFile);
					singleFile.setErroredFile(failedCopy);

					if (!failedCopy) {
						successfulCount++;

					}
					totalCount++;
				}
			}
		}
		if (tty_extract && fileList_tty.size() != 0) {
			ttyEncryptedFlg = getTTYEncryptedFlg(con);// encryptionUserName
			int ttySuccessCount = copyTTYFiles(fileList_tty, tmpDir, ttyEncryptedFlg, encryptionUserName);
			successfulCount += ttySuccessCount;
			totalCount += fileList_tty.size();
		}

		// GENERATE OUTFILE BEGIN
		ArrayList<String> tmpRequestIdList = new ArrayList<String>();
		for (int i = 0; i < requestIdList.size(); i++) {
			if (!tmpRequestIdList.contains(requestIdList.get(i))) {
				tmpRequestIdList.add(requestIdList.get(i));
			}
		}

		for (String req_id : tmpRequestIdList) {

			xmlIndexFileInfo = "";// reset for given loop
			app_id = getClientAppId(req_id, con);
			if (contr_doc_extract) {
				if (!indvidualIndexingFlg) {
					xmlIndexFileInfo += generateXMLContrDocs(req_id, fileList_contr_doc, version_flg);
				} else {
					for (ContrDocsContainerBean singleFile : fileList_contr_doc) {
						if (req_id.equals(singleFile.getRequestId())) {
							ArrayList<ContrDocsContainerBean> tmpSingleFile = new ArrayList<ContrDocsContainerBean>();
							tmpSingleFile.add(singleFile);
							xmlIndexFileInfo = "";
							boolean failedFile = singleFile.isErroredFile();
							if (!failedFile && ((version_flg && latestVersion) || !version_flg)) {
								// if (!singleFile.isErroredFile()) {
								xmlIndexFileInfo = generateXMLContrDocs(req_id, tmpSingleFile, version_flg);
								String versionNum = singleFile.getVersionNum();
								generateOutFile(xmlIndexFileInfo, tmpDir, con, app_id, xml_stylesheet, styled_output_file_name_txt, req_id,
										versionNum);
								// }
							}
						}
					}
				}
			}
			if (taf_extract) {
				if (taf_type_list.contains("T")) {
					if (!indvidualIndexingFlg) {
						xmlIndexFileInfo += generateXMLTAF(req_id, fileList_tafTitle, "title");
					} else {
						for (TAFDocsContainerBean singleFile : fileList_tafTitle) {
							ArrayList<TAFDocsContainerBean> tmpSingleFile = new ArrayList<TAFDocsContainerBean>();
							tmpSingleFile.add(singleFile);
							xmlIndexFileInfo = "";
							if (!singleFile.isErroredFile()) {
								xmlIndexFileInfo = generateXMLTAF(req_id, tmpSingleFile, "title");
								generateOutFile(xmlIndexFileInfo, tmpDir, con, app_id, xml_stylesheet, styled_output_file_name_txt, req_id, "1");
							}
						}
					}

				}
				if (taf_type_list.contains("A")) {
					if (!indvidualIndexingFlg) {
						xmlIndexFileInfo += generateXMLTAF(req_id, fileList_tafAppraisal, "appraisal");
					} else {
						for (TAFDocsContainerBean singleFile : fileList_tafAppraisal) {
							ArrayList<TAFDocsContainerBean> tmpSingleFile = new ArrayList<TAFDocsContainerBean>();
							tmpSingleFile.add(singleFile);
							xmlIndexFileInfo = "";
							if (!singleFile.isErroredFile()) {
								xmlIndexFileInfo = generateXMLTAF(req_id, tmpSingleFile, "appraisal");
								generateOutFile(xmlIndexFileInfo, tmpDir, con, app_id, xml_stylesheet, styled_output_file_name_txt, req_id, "1");
							}
						}
					}
				}
				if (taf_type_list.contains("F")) {
					if (!indvidualIndexingFlg) {
						xmlIndexFileInfo += generateXMLTAF(req_id, fileList_tafFlood, "flood");
					} else {
						for (TAFDocsContainerBean singleFile : fileList_tafFlood) {
							ArrayList<TAFDocsContainerBean> tmpSingleFile = new ArrayList<TAFDocsContainerBean>();
							tmpSingleFile.add(singleFile);
							xmlIndexFileInfo = "";
							if (!singleFile.isErroredFile()) {
								xmlIndexFileInfo = generateXMLTAF(req_id, tmpSingleFile, "flood");
								generateOutFile(xmlIndexFileInfo, tmpDir, con, app_id, xml_stylesheet, styled_output_file_name_txt, req_id, "1");
							}
						}
					}

				}
			}
			if (tty_extract) {
				if (!indvidualIndexingFlg) {
					xmlIndexFileInfo += generateXMLTTY(req_id, fileList_tty);
				} else {
					for (GenericDocsContainerBean singleFile : fileList_tty) {
						ArrayList<GenericDocsContainerBean> tmpSingleFile = new ArrayList<GenericDocsContainerBean>();
						tmpSingleFile.add(singleFile);
						xmlIndexFileInfo = "";
						if (!singleFile.isErroredFile()) {
							xmlIndexFileInfo = generateXMLTTY(req_id, tmpSingleFile);
							generateOutFile(xmlIndexFileInfo, tmpDir, con, app_id, xml_stylesheet, styled_output_file_name_txt, req_id, "1");
						}
					}
				}
			}
			if (orig_doc_extract) {
				if (!indvidualIndexingFlg) {
					xmlIndexFileInfo += generateXMLOrigDocs(req_id, fileList_orig_doc, version_flg);
				} else {
					for (OrigDocsContainerBean singleFile : fileList_orig_doc) {
						ArrayList<OrigDocsContainerBean> tmpSingleFile = new ArrayList<OrigDocsContainerBean>();
						tmpSingleFile.add(singleFile);
						xmlIndexFileInfo = "";
						if (!singleFile.isErroredFile()) {
							xmlIndexFileInfo = generateXMLOrigDocs(req_id, tmpSingleFile, version_flg);
							String versionNum = singleFile.getVersionNum();
							generateOutFile(xmlIndexFileInfo, tmpDir, con, app_id, xml_stylesheet, styled_output_file_name_txt, req_id, versionNum);
						}
					}
				}

			}
			if (!indvidualIndexingFlg) {
				if (xmlIndexFileInfo.length() > 0) {
					filexml += "<Application><app_id>" + app_id + "</app_id>" + xmlIndexFileInfo;
					filexml += generateLoanAppRqXML(req_id, con) + "</Application>";
				}
			}
		}
		//Convert the xml string to a file

		filexml += "</DocumentArchive>";


		if (!indvidualIndexingFlg) {
                  // Apply stylesheet if it exists
                  if (xml_stylesheet.length() > 0 && !xml_stylesheet.equals("")) {
                        Mpe mpe = new Mpe(con);
                        filexml = mpe.sApplyXSL(filexml, xml_stylesheet);
                  }

                  if (filexml.length() > 0 && !filexml.equals("")) {
                        Document doc = null;
                        InputSource source = new InputSource(new StringReader(filexml));

                        // If styled_output_file_name_txt is configured then use that file name
                        if (styled_output_file_name_txt != null && !styled_output_file_name_txt.equals("")) {
                              if (styled_output_file_name_txt.contains("%")) {
                                    styled_output_file_name_txt = "";
                              } else {
                                    xml_file_path = styled_output_file_name_txt;
                              }
                        }
                        xml_file_path = OWASPSecurity.validationCheck(tmpDir + File.separator + xml_file_path, OWASPSecurity.DIRANDFILE);
                        /**
                         * OWASP TOP 10 2010 - A4 Path Manipulation
                         * Changes to the below code to fix vulnerabilities
                         * TTP 324955
                         */
                      //  BufferedWriter out = new BufferedWriter(new FileWriter(xml_file_path));
                       // BufferedWriter out = new BufferedWriter(new FileWriter(Encode.forJava(xml_file_path)));
                         	BufferedWriter out = new BufferedWriter(new FileWriter(xml_file_path));
                        try {
                              out.write(filexml);
                              out.close();
                        } catch (IOException e) {
                              out.close();
                        }
                  } else {
                        log(0, "DocumentArchive: XML returned is empty, hence no xml file will be included in the zip: ");
                  }
            }
		//GENERATE OUTFILE END


		//ZIPPING AND FTPING LOGIC BEGIN
		//let's start zipping up the files before FTP'ing them
		String new_file_name = zipFiles(zip_file_name_txt, tmpDir, con, tmpDirZip);
		String file_name_noPath = new_file_name;

		if(remote_file_name_txt.length() > 0)
			file_name_noPath = remote_file_name_txt;

		new_file_name = tmpDirZip + "/" + new_file_name;//for ftp we needed this to not have the zip path appended, for all other logic we actually need to reappend the zip path.


		if( (ftp_type_id.equals("0") && ftp_user_name.length() > 0 && !ftp_user_name.equals("")) || (ftp_type_id.equals("1") && ftp_password_file.length() >  0 && !ftp_password_file.equals("")) ) //FTP is optional, refer CL 167422
		{
			//FTP them using the routing queue
			if(successfulCount>0){
				ftpFile(con, new_file_name, file_name_noPath, ftp_type_id, file_server_txt, ftp_port_name_txt, ftp_user_name, ftp_password, ftp_password_file);
			} else {
				log(0,"No files to FTP.  FTP will not be done.");
			}
		} else {
			log(0, "Not doing FTP since it is not configured");
		}

		//ZIPPING AND FTPING LOGIC END


		//LOGGING AND FILE DELETION (IF MOVING FILES) BEGIN
		//clean up temp files and permanent files depending on the flag
		if(contr_doc_extract && fileList_contr_doc.size() !=0 ){
			cleanupFilesContrDocs(con,requestIdList,copy_move_flg,version_flg,fileList_contr_doc);
		}
		if(taf_extract){
			//fyi: no versioning for TAF docs
			if(taf_type_list.contains("T") && fileList_tafTitle.size() !=0)
			{
				cleanupFilesTAFDocs(con, requestIdList, copy_move_flg, fileList_tafTitle);
			}
			if(taf_type_list.contains("A") && fileList_tafAppraisal.size() !=0 )
			{
				cleanupFilesTAFDocs(con, requestIdList, copy_move_flg, fileList_tafAppraisal);
			}
			if(taf_type_list.contains("F") && fileList_tafFlood.size() !=0 )
			{
				cleanupFilesTAFDocs(con, requestIdList, copy_move_flg, fileList_tafFlood);
			}
		}
		if(orig_doc_extract && fileList_orig_doc.size() != 0 ){
			cleanupFilesOrigDocs(con, requestIdList, copy_move_flg, version_flg, fileList_orig_doc);
		}
		if(tty_extract && fileList_tty.size() != 0 ){
			cleanupFilesTTYDocs(con, requestIdList, fileList_tty);
		}
		//LOGGING AND FILE DELETION (IF MOVING FILES) END

		log(0, "DocumentArchive: attempted to archive " + totalCount + " documents" );
		log(0, "DocumentArchive: successfully archived " + successfulCount + " documents" );

	}

    private void generateOutFile(String xmlIndexFileInfo, String tmpDir, Connection con, String app_id, String xml_stylesheet,
			String styled_output_file_name_txt, String requestId, String versionNum) throws Exception {
            filexml = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\" ?><DocumentArchive>";
            log(0, "DocumentArchive: calling generateOutFile  ");

            if (xmlIndexFileInfo.length() > 0) {
                  filexml += "<Application><app_id>" + app_id + "</app_id>" + xmlIndexFileInfo;
                  filexml += generateLoanAppRqXML(requestId, con) + "</Application>";
            } else
                  return;
            // Convert the xml string to a file

            filexml += "</DocumentArchive>";

            // Apply stylesheet if it exists
            if (xml_stylesheet.length() > 0 && !xml_stylesheet.equals("")) {
                  Mpe mpe = new Mpe(con);
                  filexml = mpe.sApplyXSL(filexml, xml_stylesheet);
            }

            if (filexml.length() > 0 && !filexml.equals("")) {
                  Document doc = null;
                  InputSource source = new InputSource(new StringReader(filexml));

                  // If styled_output_file_name_txt is configured then use that file
                  // name
                  /*
                  * if (styled_output_file_name_txt != null && !styled_output_file_name_txt.equals("")) { xml_file_path = styled_output_file_name_txt; }
                  */
                  // xml_file_path = tmpDir + "/" +xml_file_path;

                  String loanAccountNumber = getLoanAccountNumber(requestId, con);
                  log(0, "VERSION NUMEBR IS : " + versionNum);
                  log(0, "loanAccountNumber IS : " + loanAccountNumber);
                  String tmp_xml_file_path = "";
                  if (styled_output_file_name_txt != null && !styled_output_file_name_txt.equals("")) {
                        tmp_xml_file_path = generateIndexFileName(con, tmpDir, versionNum, loanAccountNumber, styled_output_file_name_txt);
                        // xml_file_path = checkFileName(styled_output_file_name_txt, tmpDir, 0);
                  } else {
                        tmp_xml_file_path = generateIndexFileName(con, tmpDir, versionNum, loanAccountNumber, xml_file_path);
                        // checkFileName(xml_file_path, tmpDir, 0);
                  }
                  log(0, "DocumentArchive:************* calling generateOutFile AFTER  " + tmp_xml_file_path);
                  xml_file_path = OWASPSecurity.validationCheck(tmpDir + File.separator + tmp_xml_file_path, OWASPSecurity.DIRANDFILE);
                  log(0, "DocumentArchive:************* calling generateOutFile AT THE END  " + xml_file_path);
                  /**
                   * OWASP TOP 10 2010 - A4 Path Manipulation
                   * Changes to the below code to fix vulnerabilities
                   * TTP 324955
                   */
                 // BufferedWriter out = new BufferedWriter(new FileWriter(xml_file_path));
                  //BufferedWriter out = new BufferedWriter(new FileWriter(Encode.forJava(xml_file_path)));
                 	BufferedWriter out = new BufferedWriter(new FileWriter(xml_file_path));
                  try {
                        out.write(filexml);
                        out.close();
                  } catch (IOException e) {
                        out.close();
                  }
                  xml_file_path = "outfile.xml";
            } else {
                  log(0, "DocumentArchive: XML returned is empty, hence no xml file will be included in the zip: ");
            }
      }

      private String getLoanAccountNumber(String requestId, Connection con) throws Exception {
            String nlsuAccountNumber = "";
            Query queryCreditReqSeq = new Query(con);
            queryCreditReqSeq.prepareStatement("select seq_num from CREDIT_REQ_SEQ_NUM where evaluator_id = ? and request_id = ?");
            queryCreditReqSeq.setInt(1, Integer.valueOf(evaluatorID));
            queryCreditReqSeq.setInt(2, Integer.parseInt(requestId));
            queryCreditReqSeq.executePreparedQuery();
            if (queryCreditReqSeq.next()) {
                  nlsuAccountNumber = queryCreditReqSeq.getColValue("seq_num");
            }

            return nlsuAccountNumber;
      }



      private String checkFileName(String styled_output_file_name_txt, String tmpDir, int counter) {
            /*
            * log(0, "***************checkFileName Starts :   " + styled_output_file_name_txt + "     " + tmpDir + "  " + counter);
            */
            String tmp = styled_output_file_name_txt;
            if (counter != 0) {
                  tmp = Integer.toString(counter) + "_" + tmp;
            }
            /*
            * log(0, "***************checkFileName Starts checking tmp :   " + tmp + "     " + tmpDir + "  " + counter);
            */
            String tmpFileCheck="";
            try
            {
             tmpFileCheck = OWASPSecurity.validationCheck(tmpDir + File.separator + tmp ,OWASPSecurity.DIRANDFILE);
            }
            catch( Exception e)
            {
            	e.printStackTrace();
            }
            /*
            * log(0, "***************%%%% tmpFileCheck :   " + tmpFileCheck + "    " + counter);
            */
            /**
             * OWASP TOP 10 2010 - A4 Path Manipulation
             * Changes to the below code to fix vulnerabilities
             * TTP 324955
             */
          //  File checkFile = new File(tmpFileCheck);
            File checkFile= null;
            try
            {
            checkFile= new File(tmpFileCheck);
            }
            catch(Exception e)
            {
            	e.printStackTrace();
            }
            /*
            * log(0, "&&&&&&&&&&***************%%%%tmpFileCheck :   " + checkFile.exists());
            */
            if (checkFile.exists()) {
                  counter = counter + 1;
                  /*
                  * log(0, "***************STILL IN THE SAME WHILE styled_output_file_name_txt :   " + styled_output_file_name_txt + "     " + tmpDir + "  " + counter);
                  */
                  return checkFileName(styled_output_file_name_txt, tmpDir, counter);
                  // log(0,"***************STILL IN THE SAME WHILE:   "+xml_file_path + "     "+tmpDir+"  "+ counter);
            } else {
                  return tmp;
            }
      }


	private ArrayList<ContrDocsContainerBean> getVersionedContrDocsInfo(Query queryTmp, String request_id, ArrayList<String> doc_type_id_lst) throws Exception {
		ArrayList<ContrDocsContainerBean> versionedArray = new ArrayList<ContrDocsContainerBean>();
		String versionsql = "Select Max(Version_Num) As Version_Num, Doc_Type_Id" +
				" From Credit_Req_Contr_Docs " +
				" Where Request_Id = ? " +
				" And " + BuildSqlStringHelperInClause(doc_type_id_lst, "doc_type_id") +  //build the ?'s for the entire array
				" group by Doc_Type_Id ";

		queryTmp.prepareStatement(versionsql);
		queryTmp.setInt(1,Integer.parseInt(request_id));
		int updateIdx = 2;
		for(int i=0; i< doc_type_id_lst.size();i++) {
			queryTmp.setString(updateIdx++, doc_type_id_lst.get(i));
		}
		queryTmp.executePreparedQuery();
		while(queryTmp.next()) {
			String contrDocId = queryTmp.getColValue("Doc_Type_Id");
			String versionNum = queryTmp.getColValue("Version_Num");
			ContrDocsContainerBean versionedDocs = new ContrDocsContainerBean(contrDocId,versionNum);
			versionedArray.add(versionedDocs);
		}
		return versionedArray;
	}

	private ArrayList<ContrDocsContainerBean> getContrDocsFileInfo(ArrayList<ContrDocsContainerBean> contrFileList, Query queryTmp, String request_id, ArrayList<String> doc_type_id_lst, String contrFilesDirName) throws Exception{
		ArrayList<ContrDocsContainerBean> versionedArray = new ArrayList<ContrDocsContainerBean>();//used to get the latest version of each contr doc type
		versionedArray = getVersionedContrDocsInfo(queryTmp,request_id,doc_type_id_lst);
		StringBuffer buf_sql = new StringBuffer();

		buf_sql.append("Select Request_Id, Doc_Type_Id, Version_Num, to_char(received_dt,'YYYYMM') as rec_dt, to_char(received_dt,'DD-MON-YYYY HH24:MI:SS') as received_dt, document_desc_txt, file_name_txt, upload_flg,  ");
			//start building case statement to set the alias latestVersion
		if(versionedArray.size() > 0){
			buf_sql.append(" Case ");
					for(int i=0; i < versionedArray.size(); i++){ //for each item in the version array create a when case
						buf_sql.append(" When Version_Num = ? And Doc_Type_Id = ? Then 'true' ");
					}
					buf_sql.append(" Else 'false' ");
					buf_sql.append(" END as latestVersion ") ;//end of alias latestVersion
		} else {
			buf_sql.append(" 'false' as latestVersion ");
		}

		buf_sql.append(" From Credit_Req_Contr_Docs ");
		buf_sql.append(" WHERE Request_Id = ? ");
		buf_sql.append("and " + BuildSqlStringHelperInClause(doc_type_id_lst, "doc_type_id")); //build the ?'s for the entire array
		String sql = buf_sql.toString();
		queryTmp.prepareStatement(sql);
		int updateIdx = 1;
		for(int i=0; i < versionedArray.size(); i++){ //first fill in the bind variables for the case statement
			ContrDocsContainerBean versionedDocs = versionedArray.get(i);
			queryTmp.setString(updateIdx++, versionedDocs.getVersionNum()); //fill in version_num bind variable
			queryTmp.setString(updateIdx++, versionedDocs.getContrDocId()); //fill in doc_type_id bind variable
		}
		queryTmp.setInt(updateIdx++,Integer.parseInt(request_id)); //set request id bind variable
		for(int i=0; i< doc_type_id_lst.size();i++) {
			queryTmp.setString(updateIdx++, doc_type_id_lst.get(i)); //fill in all bind variables for doc type id list
		}

		queryTmp.executePreparedQuery();

		//ArrayList<ContrDocsContainerBean> contrFileList = new ArrayList<ContrDocsContainerBean>();
		while(queryTmp.next()) {
			String contrDocFilename  = queryTmp.getColValue("file_name_txt","");
			String uploadFlg  = queryTmp.getColValue("upload_flg","");
			String received_dt = queryTmp.getColValue("received_dt","");
			String docTypeId = queryTmp.getColValue("doc_type_id","");
			String docDescText = queryTmp.getColValue("document_desc_txt",""); //used in summary outfilexml
			Boolean latestVersion =  Boolean.valueOf(queryTmp.getColValue("latestVersion","0")); //convert string to boolean
			String fileNameReceivedDt = queryTmp.getColValue("rec_dt","");
			String versionNum = queryTmp.getColValue("Version_Num", "");

			if(uploadFlg.equals("1")) {
				contrDocFilename = "attacheddocs" + "/" + fileNameReceivedDt + "/" + contrDocFilename;
			}
			log(0, "Contract doc extract for request_id = " + request_id + " file name " + contrDocFilename);
			ContrDocsContainerBean contrFileInfo = new ContrDocsContainerBean(request_id, contrFilesDirName, contrDocFilename, docTypeId, latestVersion, received_dt, docDescText,versionNum);

			if (!contractingCheck.contains(request_id + contrFilesDirName + contrDocFilename + docTypeId)) {
                contractingCheck.add(request_id + contrFilesDirName + contrDocFilename + docTypeId);
                contrFileList.add(contrFileInfo);
            }
		}
		return contrFileList;
	}

	//note: no versioning in TAF (we may get multiple docs or notes on calls to external TAF vendor but we do not have a versioning system
	private ArrayList<TAFDocsContainerBean> getTAFDocsFileInfo(ArrayList<TAFDocsContainerBean> tafDocs, Query queryTmp, String request_id, String taf_type_txt, String tafDirName) throws Exception{
		//ArrayList<TAFDocsContainerBean> tafDocs = new ArrayList<TAFDocsContainerBean>();

		queryTmp.prepareStatement("select document_name_txt, collateral_request_id, home_equity_id, seqno, respseqno, occurrence from credit_req_" + taf_type_txt + "_docs where request_id = ? and document_name_txt is not null ");
		queryTmp.setInt(1,Integer.parseInt(request_id));
		queryTmp.executePreparedQuery();

		while (queryTmp.next())
		{
			String tafDocFileName = queryTmp.getColValue("document_name_txt");
			int tafcollatRequestId = Integer.parseInt(queryTmp.getColValue("collateral_request_id"));
			int tafhomeEquityId = Integer.parseInt(queryTmp.getColValue("home_equity_id"));
			int tafseqno = Integer.parseInt(queryTmp.getColValue("seqno"));
			int tafrespseqno = Integer.parseInt(queryTmp.getColValue("respseqno"));
			int tafoccurrence = Integer.parseInt(queryTmp.getColValue("occurrence"));
			log(0,"TAF doc extract for request_id = " + request_id + " tafDocFileName " + tafDocFileName );
			TAFDocsContainerBean tafDocItem = new TAFDocsContainerBean(request_id, taf_type_txt, tafDirName, tafDocFileName, tafcollatRequestId, tafhomeEquityId, tafseqno, tafrespseqno, tafoccurrence);
			if (!tafDocCheck.contains(request_id + taf_type_txt + tafDirName + tafDocFileName + tafseqno + tafcollatRequestId)) {
                        tafDocCheck.add(request_id + taf_type_txt + tafDirName + tafDocFileName + tafseqno + tafcollatRequestId);
                        tafDocs.add(tafDocItem);
            }
		}
		return tafDocs;
	}

	private ArrayList<GenericDocsContainerBean> getTTYFileName(ArrayList<GenericDocsContainerBean> tty_filelist, Query queryTmp, String request_id, String tty_export_txt) throws Exception{
		//ArrayList<GenericDocsContainerBean> tty_filelist = new ArrayList<GenericDocsContainerBean>();
		String sql = 	" SELECT  rbh.bureau_id, r.entity_txt, ef.other, ef.path " +
				" FROM    requestor_bureau_header rbh, requestor r, bureau b, evapp_files ef " +
				" WHERE   r.request_id = ?   " +
				" AND     r.evaluator_id  = ? " +
				" AND     rbh.request_id = r.request_id " +
				" AND     rbh.requestor_id = r.requestor_id " +
				" AND     b.bureau_id = rbh.bureau_id " +
				" AND     ef.other =b.EVALUATE_BUREAUID_TXT " +
				" AND     r.entity_txt = ef.APPENTITY " +
				" AND     ef.appseqno = (select appseqno from credit_request where request_id = ? and evaluator_id = ?) " +
				" AND     ef.filetype = 'TTY' ";

		if(!tty_export_txt.equalsIgnoreCase("All TTYs")){
			sql += " AND	    rbh.bureau_of_record_flg = 1";
		}//tty_export_txt is anything other than "All TTYs"

		queryTmp.prepareStatement(sql);
		queryTmp.setString(1, request_id);
		queryTmp.setString(2, evaluatorID);
		queryTmp.setString(3, request_id);
		queryTmp.setString(4, evaluatorID);
		queryTmp.executePreparedQuery();

		while(queryTmp.next()) {
			String ttyFileAndDir  = queryTmp.getColValue("path","");
			String ttyBureau  = queryTmp.getColValue("other","");
			if(ttyFileAndDir.length() <=0 || ttyFileAndDir.equals("")){
				log(0,"No TTY path name exists for entity_txt " + queryTmp.getColValue("entity_txt","") + " bureau_id " + queryTmp.getColValue("bureau_id","") );
			}
			GenericDocsContainerBean ttyFileDocs = new GenericDocsContainerBean();
			String fileAndDirName= ttyFileAndDir+"."+ttyBureau;
			String fileName = getFileNameFromString(fileAndDirName);
			String srcDirName = getDirNameFromString(fileAndDirName);
			ttyFileDocs.setFileAndDir(fileAndDirName);
			ttyFileDocs.setFileName(fileName); //this is the file name of the file we are CREATING not the ORIGINAL file name (tty bureau concatenated)
			ttyFileDocs.setDirName(srcDirName);
			ttyFileDocs.setRequestId(request_id);
			log(0,"TTY doc extract for request_id " + request_id + " file name "+ fileAndDirName);
			tty_filelist.add(ttyFileDocs);//concatenate the ttybureau name to the file name, this is when we have
		}
		return tty_filelist;
	}

	private String getFileNameFromString(String fileAndDirName){
		int indexBackSlash = fileAndDirName.lastIndexOf("/");
		String fileName = fileAndDirName.substring(indexBackSlash+1, fileAndDirName.length());
		return fileName;
	}

	private String getOriginalFileNameTTY(String fileName){
		int indexLastDot = fileName.lastIndexOf(".");
		String fileNameOnly = fileName.substring(0, indexLastDot);
		return fileNameOnly;
	}

	private String getDirNameFromString(String fileAndDirName){
		int indexBackSlash = fileAndDirName.lastIndexOf("/");
		String directoryName = fileAndDirName.substring(0, indexBackSlash);
		return directoryName;
	}

	private ArrayList<String> getLatestOrigDocsSeqId(Connection con, String request_id, ArrayList<String> orig_doc_type_id_lst) throws Exception {
		PreparedStatement stmt = null;
		ResultSet rset = null;
		ArrayList<String> seqIdList = new ArrayList<String>();
		String seqIdSQL = "";

		try{
			seqIdSQL = "select max(crdhi.sequence_id) as sequence_id from " +
			" credit_req_doc_hist_imgs crdhi, credit_req_doc_history crdh where crdhi.request_id = ? and crdhi.evaluator_id =?  "+
			" and " + BuildSqlStringHelperInClause(orig_doc_type_id_lst, "crdhi.document_id") +
			" and crdhi.request_id = crdh.request_id and crdhi.evaluator_id = crdh.evaluator_id "+
			" and crdhi.document_id = crdh.document_id and crdhi.sequence_id = crdh.HIST_IMGS_SEQ_ID "+
			" group by crdhi.Document_Id ";

			stmt = con.prepareStatement(seqIdSQL);
			stmt.setString(1,request_id);
			stmt.setString(2,evaluatorID);
			int updateIdx = 3;
			for(int i=0; i< orig_doc_type_id_lst.size();i++) {
				stmt.setString(updateIdx++, orig_doc_type_id_lst.get(i));
			}
			rset = stmt.executeQuery();
			while(rset.next()){
				String sequence_id = rset.getString("sequence_id");
				seqIdList.add(sequence_id);
			}
			try {rset.close();} catch (Exception e) {log("Error in getLatestOrigDocsSeqId " + e.toString(), e);}
			try {stmt.close();} catch (Exception e) {log("Error in getLatestOrigDocsSeqId " + e.toString(), e);}
		}
		catch (Exception e) {
			log(0,"DocumentArchive:getLatestOrigDocsSeqId: " + e.toString(), e);
		}
		finally{
			try {if(rset != null) rset.close();} catch (Exception e) {log("Error in getLatestOrigDocsSeqId " + e.toString(), e);}
			try {if(stmt != null) stmt.close();} catch (Exception e) {log("Error in getLatestOrigDocsSeqId " + e.toString(), e);}
		}

		return seqIdList;
	}

	private ArrayList<OrigDocsContainerBean> getOrigDocsFileInfo(ArrayList<OrigDocsContainerBean> origDocs_filelist, Query queryTmp, String request_id, ArrayList<String> orig_doc_type_id_lst, boolean version_flg, Connection con) throws Exception{
		PreparedStatement stmt = null;
		BFILE bfile = null;
		ResultSet rset = null;
		//ArrayList<OrigDocsContainerBean> origDocs_filelist = new ArrayList<OrigDocsContainerBean>();
		ArrayList<String> seq_id_val = new ArrayList<String>();
		seq_id_val = getLatestOrigDocsSeqId(con, request_id,orig_doc_type_id_lst);
		StringBuffer buf_sql = new StringBuffer();
		buf_sql.append("select crdhi.document_id, crdhi.bfile_ref as bfile_ref, crdhi.sequence_id, crdhi.doc_hist_seq_id, cd.description_txt, ");

		if(seq_id_val.size() > 0){
			//start building case statement to set the alias latestVersion
			buf_sql.append(" Case ");
			for(int i=0; i < seq_id_val.size(); i++){ //for each item in the version array create a when case
				buf_sql.append(" When crdhi.sequence_id = ? Then 'true' ");
			}
			buf_sql.append(" Else 'false' ");
			buf_sql.append(" END as latestVersion ");//end of alias latestVersion
		} else {
			buf_sql.append(" 'false' as latestVersion ");
		}
		buf_sql.append(" from credit_req_doc_hist_imgs crdhi, CONFIG_DOCUMENTS cd ");
		buf_sql.append(" where crdhi.request_id = ? and crdhi.evaluator_id = ? " );
		buf_sql.append(" and cd.evaluator_id = crdhi.evaluator_id and cd.document_id = crdhi.document_id ");

		buf_sql.append(" and " + BuildSqlStringHelperInClause(orig_doc_type_id_lst, "crdhi.document_id"));
		String sql = buf_sql.toString();
		try{
			stmt = con.prepareStatement(sql);
			int updateIdx = 1;
			for(int i=0; i< seq_id_val.size();i++) {
				String deleteme =  seq_id_val.get(i);
				stmt.setString(updateIdx++, seq_id_val.get(i));
			}
			stmt.setString(updateIdx++,request_id);
			stmt.setString(updateIdx++,evaluatorID);
			for(int i=0; i< orig_doc_type_id_lst.size();i++) {
				stmt.setString(updateIdx++, orig_doc_type_id_lst.get(i));
			}
			rset = stmt.executeQuery();
			while(rset.next()) {
				try{
					String imgSeqId = rset.getString("sequence_id");
					String associatedOrigDocId = rset.getString("document_id");
					String docHistorySeqId = rset.getString("doc_hist_seq_id");
					String docDescription = rset.getString("description_txt");
					System.out.println("for "+ imgSeqId + " associatedOrigDocId " + associatedOrigDocId + " the latest version? " + rset.getString("latestVersion"));
					Boolean latestVersion = Boolean.valueOf(rset.getString("latestVersion"));//convert string to boolean

					bfile = ((OracleResultSet)rset).getBFILE(2);

					if(bfile == null){
						String errMsg="Will be unable to archive file. Document contains no data, credit_req_doc_hist_imgs.request_id = "+request_id + " associatedOrigDocId = " + associatedOrigDocId + " sequence id " +imgSeqId + " orig docs sequence id " + docHistorySeqId;
						log(0,errMsg);
						continue;
					}else{
						String fileName = bfile.getName();
						String dirName = bfile.getDirAlias();
						//look up directory,if not set then leave the directory value as set
						queryTmp.prepareStatement("select directory_path from all_directories where upper(directory_name) = ?");
						queryTmp.setString(1,dirName.toUpperCase());
						queryTmp.executePreparedQuery();
						if(queryTmp.next()){
							dirName = queryTmp.getColValue("directory_path");
						} else {
							log(0,"Origenate doc extract: all_directories view may be missing the directory path for " + dirName );
						}
						OrigDocsContainerBean odc = new OrigDocsContainerBean(request_id, dirName, fileName, imgSeqId, associatedOrigDocId, docDescription, latestVersion);
                        if (!origDocCheck.contains(request_id + dirName + fileName + associatedOrigDocId)) {
                            origDocCheck.add(request_id + dirName + fileName + associatedOrigDocId);
                            origDocs_filelist.add(odc);
                        }
						if((latestVersion && version_flg) || (!version_flg)){
							log(0,"Origenate doc extract for request_id = "+request_id+" document id "+associatedOrigDocId+" sequence id "+imgSeqId+" file name: " + fileName + " in file dir " +dirName);
						}
					}
				}catch (Exception e) {
					System.out.println( "DocumentArchive: Document Archive error in Orig docs: " + e.toString());
					e.printStackTrace();
				}
			}
			try {rset.close();} catch (Exception e1) {log("Error in getOrigDocsFileInfo " +e1.toString(), e1);}
			try {stmt.close();} catch (Exception e1) {log("Error in getOrigDocsFileInfo " +e1.toString(), e1);}
		}
	   catch (Exception e) {
			log(0,"Error in getOrigDocsFileInf: " + e.toString(), e);
	   }
	   finally {
		  try {if(rset!=null) rset.close();} catch (Exception e1) {log("Error in getOrigDocsFileInfo " +e1.toString(), e1);}
		  try {if(stmt!=null) stmt.close();} catch (Exception e1) {log("Error in getOrigDocsFileInfo " +e1.toString(), e1);}
	   }

		return origDocs_filelist;
	}

	private void createTempDir(String dirName) throws Exception {
		/**
		  * OWASP TOP 10 2010 - A4 Path Manipulation
		  * Changes to the below code to fix vulnerabilities
		  * TTP 324955
		  */
//		File tmpDir = new File(dirName);
		//File tmpDir = new File(Encode.forJava(dirName));
		File tmpDir = new File(OWASPSecurity.validationCheck(dirName,OWASPSecurity.DIRANDFILE));
		if (!tmpDir.exists()){
		    boolean result = tmpDir.mkdir();
		    if(!result){
		       log(0, "Document Archive: Unable to create tmpDir directory: " );
			   throw new Exception("Document Archive: Unable to create tmpDir directory: " + dirName);
		     }

  		}else{
			File[] files = tmpDir.listFiles();
			if(files!=null) { //some JVMs return null for empty dirs
				for(File f: files) {
					String fileName = f.getName();
					if(!fileName.endsWith("zip")) //don't delete the zip files.
						f.delete();
				}
			}
		}
	}

	private boolean getTTYEncryptedFlg(Connection con) throws Exception{
		boolean ttyEncrypted = false;
		Query queryTTYEncryptionFlg = new Query(con);

		queryTTYEncryptionFlg.prepareStatement("select nvl(TTY_FLG,'0') as TTY_FLG from CONFIG_ENCRYPTION where evaluator_id = ?");
		queryTTYEncryptionFlg.setString(1,evaluatorID);
		queryTTYEncryptionFlg.executePreparedQuery();
		String ttyEncryptedValue = "";
		if(queryTTYEncryptionFlg.next()){
			ttyEncryptedValue = queryTTYEncryptionFlg.getColValue("TTY_FLG");
		}

		if(ttyEncryptedValue.equals("1")){
			ttyEncrypted = true;
		}

		return ttyEncrypted;
	}

    private String generateIndexFileName(Connection con, String tmpDir, String versionNum, String loanAccountNumber, String styled_output_file_name_txt)
                  throws Exception {
            // xml_file_path ="";
          //  log(0, "**********genrateIndexFileName  STARTS " + styled_output_file_name_txt + " V NUM " + versionNum);
            Hashtable<String, String> vars = new Hashtable<String, String>();
            DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd-HH_mm_ss");
            vars.put("VERSION_NUM", versionNum);
            vars.put("LOAN_ACCOUNT_NUM", loanAccountNumber);
            Mpe mpe = new Mpe(con);
            if (styled_output_file_name_txt.contains("%")) {
                  styled_output_file_name_txt = mpe.parseFileName(styled_output_file_name_txt, vars);
                  if (styled_output_file_name_txt.startsWith("_"))
                        styled_output_file_name_txt = styled_output_file_name_txt.substring(1);
            }
            /*
            * else { if (styled_output_file_name_txt.length() > 0 && !loanAccountNumber.equals("")) styled_output_file_name_txt = loanAccountNumber + "_"
            * + versionNum + styled_output_file_name_txt; else styled_output_file_name_txt = versionNum + "_" + styled_output_file_name_txt; //
            * xml_file_path = tmpDir + "/" + xml_file_path; }
            */
            //log(0, "****************** genrateIndexFileName before calling CheckFileName " + styled_output_file_name_txt);
            styled_output_file_name_txt = checkFileName(styled_output_file_name_txt, tmpDir, 0);

            //log(0, "**********genrateIndexFileName Result  " + styled_output_file_name_txt);
            return styled_output_file_name_txt;
    }
	private String zipFiles(String zip_file_name_txt, String file_dir, Connection con, String zipFile_dir) throws Exception{

		ZipOutputStream fileZip = null;
		Hashtable<String, String> vars = new Hashtable<String, String>();
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd-HH_mm_ss");
		java.util.Date date = new java.util.Date();
		String timestamp = dateFormat.format(date);
		vars.put("TIMESTAMP",timestamp);
		vars.put("EVALUATOR_ID", evaluatorID);
		Mpe mpe = new Mpe(con);
		String new_file_name=mpe.parseFileName(zip_file_name_txt, vars);
		String return_new_file_name = new_file_name;
		//add file dir
		new_file_name = OWASPSecurity.validationCheck(zipFile_dir + File.separator + new_file_name, OWASPSecurity.DIRANDFILE);
		/**
		  * OWASP TOP 10 2010 - A4 Path Manipulation
		  * Changes to the below code to fix vulnerabilities
		  * TTP 324955
		  */
		/*fileZip = new ZipOutputStream(new FileOutputStream(new_file_name));
		   File dir = new File(file_dir);
		 */
		//fileZip = new ZipOutputStream(new FileOutputStream(Encode.forJava(new_file_name)));
		fileZip = new ZipOutputStream(new FileOutputStream(new_file_name));
		//File dir = new File(Encode.forJava(file_dir));
		File dir = new File(OWASPSecurity.validationCheck(file_dir, OWASPSecurity.DIRANDFILE));
		byte[] buffer = new byte[1024];
		try{
			for(File files: dir.listFiles())
			{
				FileInputStream in = null;
				try{
					fileZip.putNextEntry(new ZipEntry(files.getName()));
					in = new FileInputStream(files);
					int len = 0;
					while((len = in.read(buffer)) > 0) {
						fileZip.write(buffer, 0, len);
					}
					fileZip.closeEntry();
					in.close();
					boolean filedelete = files.delete();
				} catch (Exception e) {
					log(0, "Exception writing  to "+new_file_name+": "+e.toString(), e);
				} finally {
					try{ if(fileZip != null) fileZip.closeEntry(); }catch(Exception e1){e1.printStackTrace();}
					try{ if(in != null) in.close(); }catch(Exception e1){e1.printStackTrace();}
				}
			}
		}catch (Exception e) {
			log(0,"Exception zipping files: "+e.toString(), e);
			throw e;
		} finally {
			try{ if(fileZip != null) fileZip.close(); }catch(Exception e1){e1.printStackTrace();}
		}
		return return_new_file_name;
	}

	private String generateLoanAppRqXML(String request_id,  Connection con) throws Exception{
		String documentxml = "";
		GenX genx = new GenX(con, "", 5);
		genx.ResetParams();
		genx.bSetParam("REQUEST_ID", request_id);
		String transType  = "LoanAppRq";
		String s_xml = null, s_xml2 = null;
		genx.setEncryptionParms(sUser.toLowerCase(),"ssn"); //dont encrypt ssn when creating the outfile
		s_xml = genx.sGetXMLorThrow(transType,genx.build_type_xml);
		String nlsuName = "";
		Query queryNLSU = new Query(con);
		queryNLSU.prepareStatement("select nlsu_name_txt from "+
		"config_product_settings where evaluator_id = ? and product_id = (select product_id from credit_request where request_id =? )");
		queryNLSU.setInt(1, Integer.valueOf(evaluatorID));
		queryNLSU.setInt(2, Integer.valueOf(request_id));
		queryNLSU.executePreparedQuery();
		if(queryNLSU.next()){
			nlsuName = queryNLSU.getColValue("nlsu_name_txt", "");
		}
		if(!nlsuName.equals("")) {
            // 167874 - Use full MPE XML for Document Archive for client evaluator 135
            if (evaluatorID.equals("135")) {
                Mpe mpe = new Mpe(con);
                s_xml = mpe.addNLSUTableFields(s_xml, evaluatorID, request_id, "asb", "", null, true);
            }
            else {
                Mpe mpe = new Mpe(con);
                s_xml = mpe.addNLSUTableFields(s_xml, evaluatorID, request_id, nlsuName, "");
            }
		}
		if (s_xml.startsWith("<?xml ")) {
		    s_xml = s_xml.substring(s_xml.indexOf("?>") + 2);
		}
		return s_xml;
	}

	private String generateXMLContrDocs(String requestId, ArrayList<ContrDocsContainerBean> fileList_contr_doc, boolean version_flg) throws Exception{
		String documentxml = "";
		StringBuffer buf_documentxml = new StringBuffer();

		for(ContrDocsContainerBean singleFile: fileList_contr_doc){
			if(requestId.equals(singleFile.getRequestId())){
				boolean latestVersion = singleFile.isLatestVersion();
				String fileName = getFileNameFromString(singleFile.getFileAndDir());
				String doc_type_txt = singleFile.getDocDescText();
				String fullFileNmAndDir = singleFile.getFileAndDir();
				boolean failedFile = singleFile.isErroredFile();
				//first, if this is not a failed file ...then we check if we are versioning and this is the lastest version of the doc then add it to the summary xml generated, if we aren't versioning then add every file to the xml
				if(!failedFile && ((version_flg && latestVersion) || !version_flg)){
					buf_documentxml.append("<ArchiveDocument><DocumentType>"+ doc_type_txt + "</DocumentType><FileName>" + fileName  + "</FileName></ArchiveDocument>");
				}
			}
		}
		documentxml = buf_documentxml.toString();
		return documentxml;
	}

	private String generateXMLTTY(String requestId, ArrayList<GenericDocsContainerBean> fileList_tty) throws Exception{
		String documentxml = "";
		StringBuffer buf_documentxml = new StringBuffer();

		for(GenericDocsContainerBean singleFile: fileList_tty)
		{
			if(requestId.equals(singleFile.getRequestId())){
				String fileName = singleFile.getFileName();
				boolean failedFile = singleFile.isErroredFile();
				if(!failedFile){
					buf_documentxml.append("<ArchiveDocument><DocumentType></DocumentType><FileName>" + fileName  + "</FileName></ArchiveDocument>");
				}
			}
		}
		documentxml = buf_documentxml.toString();
		return documentxml;
	}

	private String generateXMLOrigDocs(String requestId, ArrayList<OrigDocsContainerBean> origDocsItems, boolean version_flg) throws Exception{
		String documentxml = "";
		StringBuffer buf_documentxml = new StringBuffer();
		String doc_type_txt = "";
		String fileName = "";

		for(OrigDocsContainerBean singleFile: origDocsItems){
			if(requestId.equals(singleFile.getRequestId())){
				String fullFileNmAndDir = singleFile.getFileAndDir();
				boolean latestVersion = singleFile.isLatestVersion();
				boolean failedFile = singleFile.isErroredFile();
				//first, if this is not a failed file ...then we check if we are versioning and this is the lastest version of the doc then add it to the summary xml generated, if we aren't versioning then add every file to the xml
				if(!failedFile && ((version_flg && latestVersion) || !version_flg)){
					doc_type_txt = singleFile.getDocDescription();
					fileName = getFileNameFromString(singleFile.getFileAndDir());
					buf_documentxml.append("<ArchiveDocument><DocumentType>"+ doc_type_txt + "</DocumentType><FileName>" + fileName  + "</FileName></ArchiveDocument>");
				}
			}
		}
		documentxml = buf_documentxml.toString();
		return documentxml;
	}

	private String generateXMLTAF(String requestId, ArrayList<TAFDocsContainerBean> tafFileList, String taf_type_txt) throws Exception{
		StringBuffer buf_documentxml = new StringBuffer();
		String documentxml = "";
		for(TAFDocsContainerBean singleFile: tafFileList){
			if(requestId.equals(singleFile.getRequestId())){
				String fileName = singleFile.getFileName();
				String fullFileNmAndDir = singleFile.getFileAndDir();
				boolean failedFile = singleFile.isErroredFile();
				if(!failedFile){
					buf_documentxml.append("<ArchiveDocument><DocumentType>"+ taf_type_txt + "</DocumentType><FileName>" + fileName  + "</FileName></ArchiveDocument>");
				}
			}
		}
		documentxml = buf_documentxml.toString();
		return documentxml;
	}


	private boolean copyFiles(String singlefileName, String srcDir, String tmpDir, GenericDocsContainerBean singleFile) {
            boolean failedCopy = false;
            InputStream inStream = null;
            OutputStream outStream = null;

            if (singlefileName == null)
                  singlefileName = "";

            try {
                  if (!singlefileName.equals("")) {
                	  /**
                	   * OWASP TOP 10 2010 - A4 Path Manipulation
                	   * Changes to the below code to fix vulnerabilities
                	   * TTP 324955
                	   */
                       // inStream = new FileInputStream(new File(srcDir, singlefileName));
                	  //inStream = new FileInputStream(new File(Encode.forJava(srcDir), Encode.forJava(singlefileName)));
                         inStream = new FileInputStream(new File(OWASPSecurity.validationCheck(srcDir, OWASPSecurity.DIRANDFILE), OWASPSecurity.validationCheck(singlefileName, OWASPSecurity.DIRANDFILE)));
                        String tmpFileName = OWASPSecurity.validationCheck(tmpDir + File.separator + singlefileName, OWASPSecurity.DIRANDFILE);
                        /**
                  	   * OWASP TOP 10 2010 - A4 Path Manipulation
                  	   * Changes to the below code to fix vulnerabilities
                  	   */
                       // File checkExsitingFile = new File(tmpFileName);
                        //File checkExsitingFile = new File(Encode.forJava(tmpFileName));
                        File checkExsitingFile = new File(tmpFileName);
                        if (checkExsitingFile.exists()) {
                              singlefileName = checkFileName(singlefileName, tmpDir, 0);
							  singleFile.setFileName(singlefileName);
							  singleFile.setFileAndDir(tmpDir + "/" + singlefileName);
                        }
                        /**
                  	     * OWASP TOP 10 2010 - A4 Path Manipulation
                  	     * Changes to the below code to fix vulnerabilities
                  	     * TTP 324955
                  	     */
                        //outStream = new FileOutputStream(new File(tmpDir, singlefileName))
                        //outStream = new FileOutputStream(new File(Encode.forJava(tmpDir),Encode.forJava( singlefileName)));
                        outStream = new FileOutputStream(new File(OWASPSecurity.validationCheck(tmpDir, OWASPSecurity.DIRANDFILE),OWASPSecurity.validationCheck( singlefileName, OWASPSecurity.DIRANDFILE)));
                        byte[] buffer = new byte[1024];

                        int length;
                        // copy the file content in bytes
                        while ((length = inStream.read(buffer)) > 0) {
                              outStream.write(buffer, 0, length);
                        }
                        inStream.close();
                        outStream.close();
                  }
            } catch (Exception e) {
                  if (!srcDir.endsWith("/"))
                        srcDir += "/";
                  log(0, "Error in file : " + srcDir + singlefileName);
                  log(0, e.toString(), e);
                  failedCopy = true; // failed to copy, return true from this method
            } finally {
                  if (inStream != null) {
                        try {
                              inStream.close();
                        } catch (Exception e) {}
                  }
                  if (outStream != null) {
                        try {
                              outStream.close();
                        } catch (Exception e) {}
                  }
            }
            return failedCopy;
      }


	private int copyTTYFiles(ArrayList<GenericDocsContainerBean> fileList, String tmpDir, boolean ttyEncryptedFlg, String encryptionUserName) {
		int successCount = 0;
		String fileNameAndDir = "";
		String srcDir = "";
		String singlefileName_out = "";
		String singlefileName_in = "";
		InputStream inStream = null;
		OutputStream outStream = null;
		BufferedInputStream bpBufferedInputStream = null;
		ByteArrayOutputStream bufferOutput = null;
		for(GenericDocsContainerBean singleFile:fileList){
			try{
				successCount++;
				srcDir = singleFile.getDirName();
				singlefileName_out = singleFile.getFileName();
				fileNameAndDir = singleFile.getFileAndDir();
				singlefileName_in = getOriginalFileNameTTY(singlefileName_out); // get the TTY file name (when getting the tty file name we not only get the directory too, but the subdirectory which is needed to know which bureau the tty is related to.  to grab the correct file, we need to get this filename, we create a new file name as follows [ttyfilename].[bureaucalled]
				  /**
				  * OWASP TOP 10 2010 - A4 Path Manipulation
				  * Changes to the below code to fix vulnerabilities
				  * TTP 324955
				  */
					//File filein = new File(srcDir, singlefileName_in);
				//File filein = new File(Encode.forJava(srcDir), Encode.forJava(singlefileName_in));
					File filein = new File(OWASPSecurity.validationCheck(srcDir, OWASPSecurity.DIRANDFILE), OWASPSecurity.validationCheck(singlefileName_in, OWASPSecurity.DIRANDFILE));
					inStream = new FileInputStream(filein);
					//outStream = new FileOutputStream(new File(tmpDir, singlefileName_out));
					//outStream = new FileOutputStream(new File(Encode.forJava(tmpDir), Encode.forJava(singlefileName_out)));
					outStream = new FileOutputStream(new File(OWASPSecurity.validationCheck(tmpDir, OWASPSecurity.DIRANDFILE), OWASPSecurity.validationCheck(singlefileName_out, OWASPSecurity.DIRANDFILE)));	
					int len=(int)filein.length();
					byte[] buffer = new byte[len];

					if(ttyEncryptedFlg){ //decrypt

						String ttyDecrypted = "";
						// Create a buffered input stream to read the file contents
						bpBufferedInputStream = new BufferedInputStream(inStream);
						bufferOutput = new ByteArrayOutputStream(len);

						int b = -1;
						// Copy contents of input stream to byte array output stream
						while((b=bpBufferedInputStream.read()) != -1){
							bufferOutput.write(b);
						}

						Crypto crypto =  CryptoFactory.getCrypto();
						log(0, "Starting Decryption of TTY with User: "+encryptionUserName);
						// Decrypting TTY and saving it in ttyDecrypted with "file" as key
						ttyDecrypted = crypto.decryptString(encryptionUserName,"file",new String(bufferOutput.toByteArray()));
						outStream.write(ttyDecrypted.getBytes());//write the string to the new outfile that will be put into the zip
						try {bpBufferedInputStream.close();}catch(Exception e){}
						try {bufferOutput.close();}catch(Exception e){}
					}
					else{//no need to decrypt tty
						int length;
						//copy the file content in bytes
						while ((length = inStream.read(buffer)) > 0){
								outStream.write(buffer, 0, length);
						}
					}

					inStream.close();
					outStream.close();
			} catch (Exception e) {
				log(0, "CopyTTY: Error in file : "+fileNameAndDir + " DETAILS: " + e.toString(), e);
				successCount--;
				singleFile.setErroredFile(true);
			} finally {
				if(inStream !=null){
					try {inStream.close();}catch(Exception e){}
				}
				if(outStream !=null){
					try {outStream.close();}catch(Exception e){}
				}
				if(bpBufferedInputStream != null){
					try {bpBufferedInputStream.close();}catch(Exception e){}
				}
				if(bufferOutput != null){
					try {bufferOutput.close();}catch(Exception e){}
				}
			}
		}
		return successCount;
	}

	private void ftpFile(Connection con, String fileName, String fileNameNoPath, String mode, String hostName, String port, String userName, String password, String certPath) throws Exception{

		String encryption_flg = ini.getINIVar("encryption.encryption_flg");
	   FileInputStream fis = null;
	   try {
		    /**
		    * OWASP TOP 10 2010 - A4 Path Manipulation
		    * Changes to the below code to fix vulnerabilities
		    * TTP 324955
		    */
		 // fis = new FileInputStream(fileName);
		   //fis = new FileInputStream(Encode.forJava(fileName));
		    fis = new FileInputStream(OWASPSecurity.validationCheck(fileName, OWASPSecurity.DIRANDFILE));
	   } catch (FileNotFoundException e) {
		   log(0,"Unable to FTP. " + fileName + " does not exist.");
	   }
       finally {
			try{if(fis !=null) fis.close();} catch(Exception ex) {ex.printStackTrace();}
	   }
	   Boolean isBasicFTP = true;

	   if(mode.equals("0"))
	   		isBasicFTP = true;
	   else
	   		isBasicFTP = false;

	   try {
		   Crypto crypto = CryptoFactory.getCrypto();

		   String passwordEncrypted = password;
		// Pwd Encryption - if encryption is turend on the pwd stored in the db is already encrypted
		/*   		if(encryption_flg.equals("1")) {
		   			passwordEncrypted = crypto.encryptString("origenate","password",password);

			}  */

		   String s_additional_data = "";
		   		s_additional_data += "MODE,"+(isBasicFTP?"FTP":"SFTP");
		   		s_additional_data += ",BINARY,1";
		   		// Make adjustment in case file_dir does not contain ending slash
		   		s_additional_data += ",FILE_LOCATION,"+ fileName; //zip_path here does not have the appended tmpDirZip value but the fileName does
		   		s_additional_data += ",NEW_FILE_NAME,"+fileNameNoPath; //need to use the file name without the tmpDirZip appended (as it is in fileName)
		   		s_additional_data += ",DELETE_FILE,1"; //altered to have FTP logic to delete the COPIED FROM file 164552 9/20/2013
		   		if(port.length() > 0 && !(port.equals("")))
		   			s_additional_data += ",HOST_NAME,"+hostName + ":" + port;
		   		else
		   			s_additional_data += ",HOST_NAME,"+hostName;
		   		s_additional_data += ",USER_NAME,"+userName;

		   		if(isBasicFTP) {
		   			s_additional_data += ",PASSWORD,"+passwordEncrypted;
		   			s_additional_data += ",CERT_PATH,NONE";
		   		} else {
		   			if(certPath !=null && !certPath.equals("")) {
		   				s_additional_data += ",PASSWORD,NONE";
		   				s_additional_data += ",CERT_PATH,"+certPath;
		   			} else if(password != null && !password.equals("")) {
		   				s_additional_data += ",PASSWORD,"+passwordEncrypted;
		   				s_additional_data += ",CERT_PATH,NONE";
		   			} else {
		   				String resp="Will not be able to FTP. Invalid SFTP creds, no private key or password found : "+profile_id;
		   				log(0,resp);
		   			}
		   		}
		   		s_additional_data += ",CLEANUP,0,CLEANUP_DIR,NONE,CLEANUP_DAYS,NONE,CLEANUP_FILTER,NONE";

		   		SQLUpdate rqpInsert = new SQLUpdate();
		   		rqpInsert.SetPreparedUpdateStatement(con, "INSERT INTO routing_queue (request_id, queue_priority_num, routing_state_id, run_dt, tries_num, additional_data_txt, routing_queue_id, routing_state_subtype_txt) VALUES " +
		   									"(?,0,35,sysdate,0,?,ROUTING_QUEUE_SEQ.nextval,'From Document Export')");
		   		rqpInsert.setInt(1, Integer.parseInt("1"));
		   		rqpInsert.setString(2, s_additional_data);
				rqpInsert.RunPreparedUpdateStatement();
				log(0,"Inserted into Routing Queue");

		} catch (Exception e) {
			// This exception should be caught the first time through this loop
			log(0, "DocumentArchive: Document Archive had an exception during FTP: " + e.toString(), e);
		}
   }

   private void cleanupFilesContrDocs(Connection con, ArrayList<String> requestIdList,String copy_move_flg, boolean version_flg,ArrayList<ContrDocsContainerBean> fileList_contr_doc) throws Exception {
		PreparedStatement stmt1 = null;
		ResultSet rset1 = null;
		JournalEvents journal = new JournalEvents(con, null);
		String delSQL = "";
		String file_name = "";
		String fileCompletePath = "";
		String directory_name = "";
		String contrDocTypeId = "";
		String receivedDt = "";
		Boolean latestVersion = false;

		for(String request_id : requestIdList){ //iterate over valid request ids
			if(copy_move_flg.equals("1")){ //DELEVE/MOVE
				try{
					for(ContrDocsContainerBean singleFile : fileList_contr_doc){
						if(request_id.equals(singleFile.getRequestId())){
							directory_name = singleFile.getDirName();
							fileCompletePath = singleFile.getFileAndDir();
							contrDocTypeId = singleFile.getContrDocId();
							latestVersion = singleFile.isLatestVersion();
							receivedDt = singleFile.getReceivedDt();
							file_name = getFileNameFromString(singleFile.getFileAndDir());
							/**
							  * OWASP TOP 10 2010 - A4 Path Manipulation
							  * Changes to the below code to fix vulnerabilities
							  * TTP 324955
							  */
							File file = new File(OWASPSecurity.validationCheck(fileCompletePath, OWASPSecurity.DIRANDFILE));
							boolean failedFile = singleFile.isErroredFile();
							if(!failedFile){
								if(file.delete()){
									//check if we are versioning and this is the lastest version of the doc then we can log the move and delete of the file, if we aren't versioning then log the delete only
									if((version_flg && latestVersion) || (!version_flg)) {
										log(0,"File succesfully moved and deleted: " + fileCompletePath);
										journal.addJournal(Integer.parseInt(request_id), 116, "Document moved and deleted: "+file_name+" to document extract.", "SYSTEM");
									} else {
										log(0,"File succesfully deleted: " + fileCompletePath);
										journal.addJournal(Integer.parseInt(request_id), 117, "Document deleted: "+file_name+" to document extract.", "SYSTEM");
									}
								} else {
									log(0,"Unable to move/delete file after FTP: " + fileCompletePath);
									continue;//if you cant delete the file, then dont create journal entries or delete the data from the database table credit_req_contr_docs
								}
							} else {
								log(0,"Delete not performed, error in document archive process for file: " + fileCompletePath);
								continue; //go to the next file since this one had an error in it
							}
							//delete from db
							delSQL = "delete from credit_req_contr_docs " +
									" where request_id = ? and doc_type_id = ? " +
									" and file_name_txt = ? and received_dt = to_date(?,'DD-MON-YYYY HH24:MI:SS') ";
							stmt1 = con.prepareStatement(delSQL);
							stmt1.setString(1,request_id);
							stmt1.setString(2,contrDocTypeId);
							stmt1.setString(3,file_name);
							stmt1.setString(4, receivedDt);
							rset1 = stmt1.executeQuery();
							log(0,"File deleted from database: " + fileCompletePath);
							try {rset1.close();} catch (Exception e) {log("Error in cleanupFilesContrDocs " + e.toString(), e);}
							try {stmt1.close();} catch (Exception e) {log("Error in cleanupFilesContrDocs " + e.toString(), e);}
						}
					} //end for each doc
				} catch (Exception e) {
					// This exception should be caught the first time through this loop
					log(0, "DocumentArchive cleanupFilesContrDocs: Document Archive move docs exception: " + e.toString(), e);
				} finally {
					if(rset1 !=null) try {rset1.close();} catch (Exception e) {log("Error in cleanupFilesContrDocs closing result set " + e.toString(), e);}
					if(stmt1 !=null) try {stmt1.close();} catch (Exception e) {log("Error in cleanupFilesContrDocs closing prepared statement " + e.toString(), e);}
				}
			} else { //copy only
				try{
					for(ContrDocsContainerBean singleFile : fileList_contr_doc){
						if(request_id.equals(singleFile.getRequestId())){
							file_name = getFileNameFromString(singleFile.getFileAndDir());
							fileCompletePath = singleFile.getFileAndDir();
							latestVersion = singleFile.isLatestVersion();
							boolean failedFile = singleFile.isErroredFile();
							//check if we are versioning and this is the lastest version of the doc then we can log the copy of the file, if we aren't versioning then we can log the copy of every file
							if((version_flg && latestVersion) || (!version_flg)) {
								if(!failedFile){
									log(0,"File succesfully copied: " + fileCompletePath);
									journal.addJournal(Integer.parseInt(request_id), 115, "Document copied: "+file_name+" to document extract.", "SYSTEM");
								} else {
									log(0,"Copy not performed, error in document archive process for file: " + fileCompletePath);
								}
							}
						}
					}//end for each doc
				} catch (Exception e) {
					// This exception should be caught the first time through this loop
					log(0, "DocumentArchive cleanupFilesContrDocs: Document Archive copy docs exception: " + e.toString(), e);
				}
			} //end else
		}//end each individual request id
   }

   private void cleanupFilesTAFDocs(Connection con, ArrayList<String> requestIdList, String copy_move_flg, ArrayList<TAFDocsContainerBean> taf_type_list) throws Exception {
		PreparedStatement stmt1 = null;
		ResultSet rset1 = null;
		JournalEvents journal = new JournalEvents(con, null);
		String delSQL = "";
		String file_name = "";
		String fileCompletePath = "";
		String directory_name = "";
		String tafType = "";
		for(String request_id : requestIdList){ //iterate over valid request ids
			if(copy_move_flg.equals("1")) { //DELEVE/MOVE
				try{
					for(TAFDocsContainerBean singleFile : taf_type_list){
						if(request_id.equals(singleFile.getRequestId())){
							file_name = singleFile.getFileName();
							directory_name = singleFile.getDirName();
							fileCompletePath = singleFile.getFileAndDir();
							tafType = singleFile.getTafType();
							boolean failedFile = singleFile.isErroredFile();

							//the following are needed for the delete statement (pk)
							int collaRequestId = singleFile.getCollateralRequestId();
							int homeEquityId = singleFile.getHomeEquityId();
							int seqno = singleFile.getSeqno();
							int respSeqno = singleFile.getRespSeqno();
							int occurence = singleFile.getOccurrence();
							//
							/**
							  * OWASP TOP 10 2010 - A4 Path Manipulation
							  * Changes to the below code to fix vulnerabilities
							  */
						//File file = new File(fileCompletePath);
							//File file = new File(Encode.forJava(fileCompletePath));
							File file = new File(OWASPSecurity.validationCheck(fileCompletePath, OWASPSecurity.DIRANDFILE));
							if(!failedFile){
								if(file.delete()) {
									log(0,"File succesfully moved and deleted: ("+tafType+") " + fileCompletePath);
									journal.addJournal(Integer.parseInt(request_id), 116, "Document moved and deleted: TAF ("+file_name+") to document extract.", "SYSTEM");
								} else {
									log(0,"Unable to delete file after FTP: " + fileCompletePath);
									continue;
								}
							} else {
								log(0,"Delete/Move not performed, error in document archive process for file: " + fileCompletePath);
								continue;
							}
							delSQL = "delete from ";
							if(tafType.equals("title"))
								delSQL +=" credit_req_title_docs ";
							else if(tafType.equals("appraisal"))
								delSQL +=" credit_req_appraisal_docs ";
							else // tafType is flood
								delSQL +=" credit_req_flood_docs ";
							delSQL +=" where request_id = ? and collateral_request_id = ? " +
									" and home_equity_id = ? and seqno = ? and respseqno = ? and occurrence = ? ";
							stmt1 = con.prepareStatement(delSQL);
							stmt1.setString(1,request_id);
							stmt1.setInt(2,collaRequestId);
							stmt1.setInt(3,homeEquityId);
							stmt1.setInt(4,seqno);
							stmt1.setInt(5,respSeqno);
							stmt1.setInt(6,occurence);
							rset1 = stmt1.executeQuery();
							log(0,"File deleted from database: " + directory_name + file_name);
						}
					}//end for

					try {if(rset1 !=null) rset1.close();} catch (Exception e) {log("Error in cleanupFilesTAFDocs " + e.toString(), e);}
					try {if(stmt1 !=null) stmt1.close();} catch (Exception e) {log("Error in cleanupFilesTAFDocs " + e.toString(), e);}
				} catch (Exception e) {
					// This exception should be caught the first time through this loop
					log(0, "DocumentArchive cleanupFilesTAFDocs: Document Archive move docs exception: " + e.toString(), e);
				} finally {
					if(rset1 !=null) try {rset1.close();} catch (Exception e) {log("Error in cleanupFilesTAFDocs closing result set " + e.toString(), e);}
					if(stmt1 !=null) try {stmt1.close();} catch (Exception e) {log("Error in cleanupFilesTAFDocs closing prepared statement " + e.toString(), e);}
				}
			} else { //COPY files
				try{
					for(TAFDocsContainerBean singleFile : taf_type_list){
						if(request_id.equals(singleFile.getRequestId())){
							file_name = singleFile.getFileName();
							directory_name = singleFile.getDirName();
							fileCompletePath = singleFile.getFileAndDir();
							tafType = singleFile.getTafType();
							boolean failedFile = singleFile.isErroredFile();
							/**
							  * OWASP TOP 10 2010 - A4 Path Manipulation
							  * Changes to the below code to fix vulnerabilities
							  * TTP 324955
							  */
							//File file = new File(fileCompletePath);
							//File file = new File(Encode.forJava(fileCompletePath));
							File file = new File(OWASPSecurity.validationCheck(fileCompletePath, OWASPSecurity.DIRANDFILE));
							if(!failedFile){
								log(0,"File succesfully copied: ("+tafType+") " + fileCompletePath );
								journal.addJournal(Integer.parseInt(request_id), 115, "Document copied: TAF ("+file_name+") to document extract.", "SYSTEM");
							} else {
								log(0,"Copy not performed, error in document archive process for file: " + fileCompletePath);
							}
						}//end if
					}//end for
				} catch (Exception e) {
					// This exception should be caught the first time through this loop
					log(0, "DocumentArchive cleanupFilesTAFDocs: Document Archive copy docs exception: " + e.toString(), e);
				}
			} //end else/copy
		} //end each individual request id
   }

	private void cleanupFilesOrigDocs(Connection con, ArrayList<String> requestIdList, String copy_move_flg, boolean version_flg, ArrayList<OrigDocsContainerBean> fileList_orig_doc) throws Exception {
		PreparedStatement stmt1 = null;
		ResultSet rset1 = null;
		JournalEvents journal = new JournalEvents(con, null);
		String delSQL = "", updtSQL = "";
		String fileName = "";
		String fullFileNmAndDir = "";
		String directory_name = "";

		String origDocDescr = "";
		boolean latestVersion = false;
		for(String request_id : requestIdList){ //iterate over valid request ids
			if(copy_move_flg.equals("1")) { //DELEVE/MOVE
				try{
					for(OrigDocsContainerBean singleFile: fileList_orig_doc)
					{
						if(request_id.equals(singleFile.getRequestId())){
							String origDocId = singleFile.getOrigDocId();
							origDocDescr = singleFile.getDocDescription();
							fileName = getFileNameFromString(singleFile.getFileAndDir());
							fullFileNmAndDir = singleFile.getFileAndDir();
							String seq_id_val = singleFile.getSequenceId();
							latestVersion = singleFile.isLatestVersion();
							boolean failedFile = singleFile.isErroredFile();
							if(!failedFile){
								/**
								  * OWASP TOP 10 2010 - A4 Path Manipulation
								  * Changes to the below code to fix vulnerabilities
								  * TTP 324955
								  */
							//	File file = new File(fullFileNmAndDir);
								//File file = new File(Encode.forJava(fullFileNmAndDir));
								File file = new File(OWASPSecurity.validationCheck(fullFileNmAndDir, OWASPSecurity.DIRANDFILE));
								if(file.delete()) {
									//check if we are versioning and this is the lastest version of the doc then we can log the move and delete of the file, if we aren't versioning then log the delete only
									if((version_flg && latestVersion) || (!version_flg)) {
										log(0,"File succesfully moved and deleted: " + fullFileNmAndDir);
										journal.addJournal(Integer.parseInt(request_id), 116, "Document moved and deleted: " + origDocDescr + " ("+fileName+") to document extract.", "SYSTEM");
									} else {
										log(0,"File succesfully deleted: " + fullFileNmAndDir);
										journal.addJournal(Integer.parseInt(request_id), 117, "Document deleted: " + origDocDescr + " ("+fileName+") to document extract.", "SYSTEM");
									}
								} else {
									log(0,"Unable to move/delete file after FTP: " + fullFileNmAndDir);
									continue;//if you can't delete the file after FTP, then dont log the journal entry or delete values from the db related to this document
								}
							} else {
								log(0,"Delete not performed, error in document archive process for file: " + fullFileNmAndDir);
								continue; //go to the next file
							}

							//delete each individual file type

							delSQL = "delete from credit_req_doc_hist_imgs "+
							" where request_id = ? and evaluator_id = ? "+
							" and document_id = ? " +
							" and sequence_id = ? ";

							stmt1 = con.prepareStatement(delSQL);
							stmt1.setString(1,request_id);
							stmt1.setString(2,evaluatorID);
							stmt1.setString(3,origDocId);
							stmt1.setString(4,seq_id_val);

							rset1 = stmt1.executeQuery();
							log(0,"File deleted from database: " + fullFileNmAndDir);
							try {rset1.close();} catch (Exception e) {log("Error in cleanupFilesOrigDocs " + e.toString(), e);}
							try {stmt1.close();} catch (Exception e) {log("Error in cleanupFilesOrigDocs " + e.toString(), e);}

							updtSQL = "update credit_req_doc_history "+
							" set HIST_IMGS_SEQ_ID = null " +
							" where request_id = ? and evaluator_id =? "+
							" and document_id = ? " +
							" and HIST_IMGS_SEQ_ID = ? ";

							stmt1 = con.prepareStatement(updtSQL);
							stmt1.setString(1,request_id);
							stmt1.setString(2,evaluatorID);
							stmt1.setString(3,origDocId);
							stmt1.setString(4,seq_id_val);

							rset1 = stmt1.executeQuery();
							log(0,"credit_req_doc_history updated to no longer have a sequence number value " + fullFileNmAndDir);
							try {rset1.close();} catch (Exception e) {log("Error in cleanupFilesOrigDocs " + e.toString(), e);}
							try {stmt1.close();} catch (Exception e) {log("Error in cleanupFilesOrigDocs " + e.toString(), e);}
						}
					}//end for  OrigDocsContainerBean singleFile: fileandDirList_origDocType (iterating over each individual file)
				} catch (Exception e) {
					// This exception should be caught the first time through this loop
					log(0, "DocumentArchive cleanupFilesOrigDocs: Document Archive move docs exception: " + e.toString(), e);
				} finally {
					if(rset1 !=null) try {rset1.close();} catch (Exception e) {log("Error in cleanupFilesOrigDocs closing result set " + e.toString(), e);}
					if(stmt1 !=null) try {stmt1.close();} catch (Exception e) {log("Error in cleanupFilesOrigDocs closing prepared statement " + e.toString(), e);}
				}
			} else { //COPY files
				try{
					for(OrigDocsContainerBean singleFile: fileList_orig_doc)
					{
						if(request_id.equals(singleFile.getRequestId())){
							origDocDescr = singleFile.getDocDescription();
							fileName = getFileNameFromString(singleFile.getFileAndDir());
							latestVersion = singleFile.isLatestVersion();
							fullFileNmAndDir = singleFile.getFileAndDir();
							boolean failedFile = singleFile.isErroredFile();
							//check if we are versioning and this is the lastest version of the doc then we can log the copy of the file, if we aren't versioning then we can log the copy of every file
							if((version_flg && latestVersion) || (!version_flg)) {
								if(!failedFile){
									log(0,"File succesfully copied: " + fullFileNmAndDir);
									journal.addJournal(Integer.parseInt(request_id), 115, "Document copied: " + origDocDescr + " ("+fileName+") to document extract.", "SYSTEM");
								} else {
									log(0,"Copy not performed, error in document archive process for file: " + fullFileNmAndDir);
								}
							}
						}
					}//end for
				} catch (Exception e) {
					// This exception should be caught the first time through this loop
					log(0, "DocumentArchive cleanupFilesOrigDocs: Document Archive copy docs exception: " + e.toString(), e);
				}
			} //end else/copy
		} //end each individual request id
	}

	private void cleanupFilesTTYDocs(Connection con, ArrayList<String> requestIdList, ArrayList<GenericDocsContainerBean> fileList_tty) throws Exception {
		JournalEvents journal = new JournalEvents(con, null);
		String delSQL = "", updtSQL = "";
		String file_name = "";
		String fileCompletePath = "";
		String directory_name = "";
		//value of copy_move_flg is not important, as configuration does not allow the move flag to be set with a TTY export value of anything other than 'None' so this scenario should never occur anyways for the move scenario, so if it did we would simply COPY the TTY
		//no versioning for TTY
		for(String request_id : requestIdList){ //iterate over valid request ids
			if(fileList_tty.size()>0){
				Query queryTmp = new Query(con);
				createTtyExportJournalEntries(queryTmp, request_id, fileList_tty, journal);//TTYs do not get deleted, just create a journal entry to indicate that it was successfully copied.
			}
		} //end each individual request id
	}

	private void createTtyExportJournalEntries(Query queryTmp, String request_id, ArrayList<GenericDocsContainerBean> fileList_tty, JournalEvents journal) throws Exception{
		for(GenericDocsContainerBean singleFile: fileList_tty){
			if(request_id.equals(singleFile.getRequestId())){
				boolean failedFile = singleFile.isErroredFile();
				String fileName = singleFile.getFileName();
				String fileAndDirName = singleFile.getFileAndDir();
				if(!failedFile){
					log(0,"File succesfully copied: " + fileAndDirName);
					journal.addJournal(Integer.parseInt(request_id), 115, "Document copied: TTY ("+fileName+") to document extract.", "SYSTEM");
				} else {
					log(0,"Copy not performed, error in document archive process for file: " + fileAndDirName);
				}
			}
		} //end for
	}

	private String getClientAppId(String request_id, Connection con) throws Exception{
		Query qry = new Query(con);
		qry.prepareStatement("select client_app_id from credit_request where request_id = ?");
		qry.setString(1,request_id);
		qry.executePreparedQuery();
		if(qry.next()){
			return  qry.getColValue("client_app_id");
		}
		else{
			throw new Exception("Error in doc archive processs: Unable to retrieve client_app_id from credit_request in method getClientAppId");
		}
	}

	private static String BuildSqlStringHelperInClause(ArrayList<String> columnValues, String ColumnName){
		StringBuffer buf_sql = new StringBuffer();
		buf_sql.append( " " +ColumnName + " ");
		for(int i=0; i< columnValues.size();i++) {
			//oracle has a limit of 1000 items in the list of a query using the "in" clause , so we had to do logic for scenarios where the extract is working with more than 1000 originators, the final where clause will now look like where originator_id in (?,...,?) or originator_id in (?,...,?) or originator_id in (?,...,?) etc
			if(i%1000 == 0){
				String sql_temp = "";
				if(i/1000 > 0){
					sql_temp += " ) or " + ColumnName + " ";
				}
				buf_sql.append(sql_temp+" in ( ");
			}
			if(i>0 && i%1000 != 0){
				buf_sql.append( ", ?");
			}else{
				buf_sql.append( "?");
			}
		}
		buf_sql.append( " ) ");
		String sql = buf_sql.toString();
		return sql;
	}

	// Based off of code from GenJob. It doesn't seem like this method would be used much in there in the future,
	// so I'm just putting it by itself here to be used by this program only. Takes evaluator_id rather than request_id.
	private Query buildAndExecuteQuery(GenJob genJob, Connection con, String sql, String query_id, String evaluator_id) throws Exception {
		Query query = new Query(con);
		Query querySQLParms = new Query(con);

		if(evaluator_id == null || evaluator_id.trim().equals("")) {
			return null;
		}

		querySQLParms.prepareStatement("select parm_name_txt,source_id,source_txt from config_doc_query_parms where query_id = ? and evaluator_id = ? ");
		querySQLParms.setInt(1, Integer.parseInt(query_id));
		querySQLParms.setInt(2, Integer.parseInt(evaluator_id));
		querySQLParms.executePreparedQuery();

		int source_id;
		String parm, sourceValue;
		ArrayList<Integer> parmCt = new ArrayList<Integer>();
		while(querySQLParms.next()) {
			source_id = Integer.parseInt(querySQLParms.getColValue("source_id"));

			switch (source_id) {
			// Only want to support evaluator_id
			case 4: {
				sourceValue = querySQLParms.getColValue("source_txt", "notavail");
				if(!sourceValue.equalsIgnoreCase("evaluator_id")) {
					log(0, "DocumentArchive: Source " + sourceValue + " not supported in Document Archive Query");
					throw new Exception("DocumentArchive: Source " + sourceValue + " not supported in Document Archive Query");
				}
				parm = querySQLParms.getColValue("parm_name_txt");
				if(sql.indexOf(parm) < 0) {
					log(0, "DocumentArchive: Parameter " + parm + " not found in Document Archive Query");
					throw new Exception("DocumentArchive: Parameter " + parm + " not found in Document Archive Query");
				}
				sql = genJob.replace(sql, parm, " ? ", true, parmCt);
			}
			break;
			default:
				log(0, "DocumentArchive: Source ID " + source_id + " not supported in Document Archive Query");
				throw new Exception("DocumentArchive: Source ID " + source_id + " not supported in Document Archive Query");
			} // end switch
		}

		//TTP 324955 Security Remediation Fortify Scan
		query.prepareStatement(SQLSecurity.basicSanitize(sql));
		for(int c = 0; c < parmCt.get(0); c++){
			query.setInt(c + 1, evaluator_id);
		}
		query.executePreparedQuery();

		return query;
	}

	public void run(String[] args) throws Exception {
		Connection con = null;
		Connection evalcon = null;

		log(0, "Document Archive initializing...");

		GetArgs(args, log_obj);

		String sConStr = "jdbc:oracle:thin:@";
		if (sTNSEntry.length() == 0) {
			sConStr = sConStr + sHost + ":" + sPort + ":" + sSIDname;
		}
		else {
			sConStr = sConStr + sTNSEntry;
			log(0, "Using TNS Entry");
		}

		try {
			// Load Oracle driver
			DriverManager.registerDriver(new oracle.jdbc.OracleDriver());

			log(0, "Connecting to database: " + sConStr);

			sPass = COLEncrypt.sDecrypt(sPass);

			// Connect to the Oracle database
			con = DriverManager.getConnection(sConStr, sUser, sPass);
		}
		catch (Exception e) {
			log(0, "Error connecting to database: " + e.toString(), e);
			throw e;
		}


		try {
			archiveApps(con);
		}
		catch (Exception e) {
			log(0, "Error in Document Archive: " + e.toString(), e);
			//throw e;
		}

		try {
			con.close();
		}
		catch (Exception e1){}

		log(0, "Document Archive exiting...");
	}

	private void GetArgs(String args[], LogMsg log_obj) {
		if(args.length > 0) {
			for(int i = 0; i < args.length; i++) {
				if((args[i].charAt(0) != '-') && (args[i].length() > 1)) {
					ShowUsage();
				}

				switch(args[i].charAt(1)) {

				case 'i':
					sIniFile = args[i].substring(2);
					log(0, "IniFile is '" + sIniFile + "'");
					try {
						// Read host, user, sid and password from ini file
						ini.readINIFile(sIniFile);

						logFile = ini.getINIVar("logs.document_archive_log_file", "");
						if(logFile.length() > 0) {
							log_obj.openLogFile(logFile);
						}

						log(0, "Document Archive initializing...");

						sHost = ini.getINIVar("database.host", "");
						log(0, "Host is '" + sHost + "'");

						sPort = ini.getINIVar("database.port", "");
						log(0, "Port is '" + sPort + "'");

						sUser = ini.getINIVar("database.user", "");
						log(0, "User is '" + sUser + "'");

						sPass = ini.getINIVar("database.password", "");
						// log(0,"Password:"+sPass);

						sSIDname = ini.getINIVar("database.sid", "");
						log(0, "Database (SID name) is '" + sSIDname + "'");

						sTNSEntry = ini.getINIVar("database.TNSEntry", "");
						log(0, "TNS Entry is '" + sTNSEntry + "'");
					}
					catch(Exception e){
						log(0, "Caught exception reading ini file '" + sIniFile + "': " + e.toString(), e);
					}
					break;

				// Not much logging. We'll leave this flag out
				/*case 'd': //turn debug on
					i_dbg_level = 5;
					log(0, "debugging turned on");
					break;*/

				case 'e': //evaluator id
					evaluatorID = args[i].substring(2);
					log(0, "Evaluator ID: " + evaluatorID);
					break;

				case 'p': //evaluator id
					profileID = args[i].substring(2);
					log(0, "Profile ID: " + profileID);
					break;

				case 'z'://zip path
					zip_path = args[i].substring(2);
					log(0, "Zip Path: " + zip_path);
					break;

				default:
					log(0, "Unknown parameter: " + args[i]);
					ShowUsage();
					break;
				} // end case
			} // end for loop

			//edits
			if ((sHost.length() == 0) || (sUser.length() == 0)
					|| (sSIDname.length() == 0) || (sPort.length() == 0)) {
				log(0, "Host,User,Pwd,SID or Port not specified in INI file");
				ShowUsage();
			}
			if (evaluatorID.length() == 0) {
				log(0, "-e parm is required");
				ShowUsage();
			}
			if (profileID.length() == 0) {
				log(0, "-p parm is required");
				ShowUsage();
			}
			if (zip_path.length() == 0) {
				log(0, "-z parm is required");
				ShowUsage();
			}
		} // end if
		else {
			ShowUsage();
		}
	}

	private void ShowUsage() {
		System.out.println();
		System.out.println("Usage: java DocumentArchive -i<inifile> -e<evaluator id> -p<profile id>");
		System.out.println("---------------------");
		System.out.println("-i - required: INI file to use for configuration");
		System.out.println("-e - required: evaluator id");
		System.out.println("-p - required: Document Archive profile id");
		System.out.println("-z - required: PWD");
		System.exit(1);
	}

	private void log(int level, String msg) {
		log_obj.FmtAndLogMsg(msg, i_dbg_level, level);
	}

	private void log(int level, String msg, Throwable throwable) {
		log_obj.FmtAndLogMsg(msg, throwable, i_dbg_level, level);
	}

	private void log(String msg) {
		log_obj.FmtAndLogMsg(msg);
	}

	private void log(String msg, Throwable throwable) {
		log_obj.FmtAndLogMsg(msg, throwable);
	}
}