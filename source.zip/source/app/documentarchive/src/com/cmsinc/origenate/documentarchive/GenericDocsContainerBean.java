package com.cmsinc.origenate.documentarchive;

public class GenericDocsContainerBean {
	private String dirName;
	private String fileName;
	private String fileAndDir;
	private String versionNum;
	private boolean latestVersion = false;
	private boolean erroredFile = false;
	private boolean copyFile = false;
	private String requestId;

	public String getVersionNum() {
		return versionNum;
	}

	public void setVersionNum(String versionNum) {
		this.versionNum = versionNum;
	}

	public String getRequestId() {
		return requestId;
	}

	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}

	public String getDirName() {
		return dirName;
	}

	public void setDirName(String dirName) {
		this.dirName = dirName;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public String getFileAndDir() {
		return fileAndDir;
	}

	public void setFileAndDir(String fileAndDir) {
		this.fileAndDir = fileAndDir;
	}

	public boolean isLatestVersion() {
		return latestVersion;
	}

	public void setLatestVersion(boolean latestVersion) {
		this.latestVersion = latestVersion;
	}

	public boolean isErroredFile() {
		return erroredFile;
	}

	public void setErroredFile(boolean erroredFile) {
		this.erroredFile = erroredFile;
	}

	public boolean isCopyFile() {
		return copyFile;
	}

	public void setCopyFile(boolean copyFile) {
		this.copyFile = copyFile;
	}
}