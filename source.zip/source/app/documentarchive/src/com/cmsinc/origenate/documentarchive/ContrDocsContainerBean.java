package com.cmsinc.origenate.documentarchive;

public class ContrDocsContainerBean extends GenericDocsContainerBean {
	private String contrDocId;
	private String versionNum;
	private String receivedDt;
	private String docDescText;

	public ContrDocsContainerBean(String requestId, String dirName, String fileName, String contrDocId, Boolean latestVersion, String receivedDt,
			String docDescText, String versionNum) {
		setRequestId(requestId);
		setDirName(dirName);
		setFileName(fileName);
		if (!dirName.endsWith("/")) {// this is to ensure that all FULL file names end with the forwardslash, do this AFTER assigning the dir name
			dirName += "/";
		}
		setFileAndDir(dirName + fileName);
		setLatestVersion(latestVersion);
		this.contrDocId = contrDocId;
		this.versionNum = "";
		this.receivedDt = receivedDt;
		this.docDescText = docDescText;
		setVersionNum(versionNum);
	}

	// below constructor used for versioning only
	public ContrDocsContainerBean(String contrDocId, String versionNum) {
		this.contrDocId = contrDocId;
		this.versionNum = versionNum;
		this.receivedDt = "";
		this.docDescText = "";
	}

	public String getContrDocId() {
		return contrDocId;
	}

	public void setContrDocId(String contrDocId) {
		this.contrDocId = contrDocId;
	}

	@Override
	public String getVersionNum() {
		return versionNum;
	}

	@Override
	public void setVersionNum(String versionNum) {
		this.versionNum = versionNum;
	}

	public String getReceivedDt() {
		return receivedDt;
	}

	public void setReceivedDt(String receivedDt) {
		this.receivedDt = receivedDt;
	}

	public String getDocDescText() {
		return docDescText;
	}

	public void setDocDescText(String docDescText) {
		this.docDescText = docDescText;
	}

}