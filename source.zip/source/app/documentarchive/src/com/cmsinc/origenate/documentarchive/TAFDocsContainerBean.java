package com.cmsinc.origenate.documentarchive;

public class TAFDocsContainerBean extends GenericDocsContainerBean {
		private String tafType;
		private int collateralRequestId;
		private int homeEquityId;
		private int seqno;
		private int respSeqno; 
		private int occurrence;
		public TAFDocsContainerBean(String requestId,String tafType, String dirName, String fileName, int collateralRequestId, int homeEquityId, int seqno, int respSeqno, int occurrence) {
			setRequestId(requestId);
			setDirName(dirName);
			setFileName(fileName);
			if(!dirName.endsWith("/")){//this is to ensure that all FULL file names end with the forwardslash, do this AFTER assigning the dir name
				dirName+="/";
			}
			setFileAndDir(dirName+fileName);
			this.tafType = tafType;
			this.collateralRequestId = collateralRequestId;
			this.homeEquityId = homeEquityId;
			this.seqno = seqno;
			this.respSeqno = respSeqno;
			this.occurrence = occurrence;
		}
		public String getTafType() {
			return tafType;
		}
		public void setTafType(String tafType) {
			this.tafType = tafType;
		}
		public int getCollateralRequestId() {
			return collateralRequestId;
		}
		public void setCollateralRequestId(int collateralRequestId) {
			this.collateralRequestId = collateralRequestId;
		}
		public int getHomeEquityId() {
			return homeEquityId;
		}
		public void setHomeEquityid(int homeEquityId) {
			this.homeEquityId = homeEquityId;
		}
		public int getSeqno() {
			return seqno;
		}
		public void setSeqno(int seqno) {
			this.seqno = seqno;
		}
		public int getRespSeqno() {
			return respSeqno;
		}
		public void setRespseqno(int respSeqno) {
			this.respSeqno = respSeqno;
		}
		public int getOccurrence() {
			return occurrence;
		}
		public void setOccurrence(int occurrence) {
			this.occurrence = occurrence;
		}

	}