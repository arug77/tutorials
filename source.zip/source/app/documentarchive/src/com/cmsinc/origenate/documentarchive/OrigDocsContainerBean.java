package com.cmsinc.origenate.documentarchive;

public class OrigDocsContainerBean extends GenericDocsContainerBean {
	private String sequenceId;
	private String origDocId;
	private String docDescription;

	public OrigDocsContainerBean(String requestId, String dirName, String fileName, String seqID, String origDocId, String docDescription,
			Boolean latestVersion) {
		setRequestId(requestId);
		setDirName(dirName);
		setVersionNum(seqID);
		setFileName(fileName);
		if (!dirName.endsWith("/")) {// this is to ensure that all FULL file names end with the forwardslash, do this AFTER assigning the dir name
			dirName += "/";
		}
		setFileAndDir(dirName + fileName);
		setLatestVersion(latestVersion);
		this.sequenceId = seqID;
		this.origDocId = origDocId;
		this.docDescription = docDescription;
	}

	public String getSequenceId() {
		return sequenceId;
	}

	public void setSequenceId(String sequenceId) {
		this.sequenceId = sequenceId;
	}

	public String getOrigDocId() {
		return origDocId;
	}

	public void setOrigDocId(String origDocId) {
		this.origDocId = origDocId;
	}

	public String getDocDescription() {
		return docDescription;
	}

	public void setDocDescription(String docDescription) {
		this.docDescription = docDescription;
	}

}