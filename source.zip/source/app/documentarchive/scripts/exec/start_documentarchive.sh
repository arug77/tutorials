
. ../../config/usrconfig.sh

export CLASSPATH=$CLASSPATH:../lib/commons-net-3.3.jar:../lib/jsch-0.1.50.jar

nohup java com.cmsinc.origenate.documentarchive.DocumentArchive -e65 -i/opt/jrun4/servers/prodqs85/cfusion-ear/cfusion-war/config/origenate.ini -p15 -z$PWD &

