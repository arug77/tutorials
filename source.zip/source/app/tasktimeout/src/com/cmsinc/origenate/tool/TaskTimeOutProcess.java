package com.cmsinc.origenate.tool;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.apache.commons.lang3.StringUtils;

import com.cmsinc.origenate.doc.DocGen;
import com.cmsinc.origenate.doc.GenJob;
import com.cmsinc.origenate.event.CommentEvents;
import com.cmsinc.origenate.event.JournalEvents;
import com.cmsinc.origenate.util.ConnectionUtils;
import com.cmsinc.origenate.util.DBConnection;
import com.cmsinc.origenate.util.IniFile;
import com.cmsinc.origenate.util.LogMsg;
import com.cmsinc.origenate.util.PostRequest;
import com.cmsinc.origenate.util.Query;
import com.cmsinc.origenate.util.SQLUpdate;
import com.cmsinc.origenate.workflow.ApplicationIDs;
import com.cmsinc.origenate.workflow.WorkFlowManager;

public class TaskTimeOutProcess {
	private static final int NUM_THREADS = 20;

	private String logFileName;

	//Current valid situations: D1
	private String situation;

	private Connection con;
	private LogMsg log = new LogMsg();
	private IniFile ini = new IniFile();

	private static final String QUERY_CRED_REQ_TASKS = 
			"SELECT * \r\n" + 
					"FROM credit_request cr\r\n" + 
					"INNER JOIN credit_req_work_item_assign crwa \r\n" + 
					"  ON cr.request_id = crwa.request_id AND cr.evaluator_id = crwa.evaluator_id\r\n" + 
					"INNER JOIN xref_tasks_in_task_group xtitg \r\n" + 
					"  ON cr.task_id = xtitg.task_id AND cr.evaluator_id = xtitg.evaluator_id \r\n" + 
					"  AND xtitg.product_id = cr.product_id \r\n" + 
					"WHERE upper(cr.task_id) != 'SCORING' AND upper(cr.task_id) != 'DONE' AND (cr.task_group_id != 'SYSTEM' OR cr.task_group_id IS NULL) \r\n" +
					"AND ((timeout_duration != 0 AND timeout_duration IS NOT null AND timeout_task_id IS NOT NULL) or query_id IS NOT NULL) \r\n";

	private static final String PROCESS_TYPE_FLG_TRUE_CLAUSE = "AND xtitg.process_type_flg = 1";
	private static final String PROCESS_TYPE_FLG_FALSE_CLAUSE = "AND (xtitg.process_type_flg != 1 OR xtitg.process_type_flg IS NULL)";

	private static final String UPDATE_CREDIT_REQ_TTO = 
			"UPDATE credit_request \r\n" + 
					"SET  task_id = ?, task_group_id = ?, audit_updated_user_id = ?, \r\n" + 
					"audit_last_updated_dt = ?, last_tasktimeout_dt = ?, task_time_out_flg = ?, \r\n" + 
					"assigned_user_id = ?, assigned_team_id = ?\r\n" + 
					"WHERE request_id = ? AND evaluator_id = ? ";

	private static final String QUERY_LOCK_APP = 
			"SELECT lock_type_id \r\n" + 
					"FROM concurrency_control \r\n" + 
					"WHERE request_id = ?";

	private static final String INSERT_LOCK_APP = 
			"INSERT INTO concurrency_control (request_id,user_id,lock_dt,\r\n" + 
					"lock_type_id,lock_desc_txt, eval_host, eval_port, eval_env) \r\n" + 
					"VALUES (?,?,SYSDATE,1,'Locked by portal user',?,?,?)";

	private static final String DELETE_LOCK_APP = 
			"DELETE concurrency_control \r\n" + 
					"WHERE request_id = ? AND user_id = ? ";

	private static final String QUERY_TASK_TIMEOUT_FREQ = 
			"SELECT task_timeout_frequency_num \r\n" + 
					"FROM origenate_setting ";

	/**
	 * Representation of a task timeout record
	 * 
	 * @author thomasv
	 */
	private class TaskTimeoutRecord {
		public String taskId;
		public String assignedUserId;
		public String taskGroupId;
		public String requestId;
		public String timeoutTaskId;
		public String timeoutUserId;
		public int productId;		
		public int timeoutTeamId;
		public int queryId; 
		public int assignedTeamId;
		public int callRescoreFlg;
		public int evaluatorId;
		public long timeoutDuration;
		public Timestamp lastAccessDate;
		public Timestamp lastTaskTimeoutDt;
		public Timestamp lastActivityDate;
		public Timestamp appStartDate;
	}

	/**
	 * Entry point.
	 * @param argv The args [ini file] [situation] [evaluator id]
	 * @throws Exception If there is a problem starting task timeout
	 */
	public static void main(String argv[]) {
		//Read in args
		try {
			String iniFileNm = argv.length >= 1 ? argv[0].trim() : null;
			String situation = argv.length >= 2 ? argv[1].trim() : null;

			//Create object of timeout process
			TaskTimeOutProcess t = new TaskTimeOutProcess(iniFileNm, situation);
			t.start();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Default constructor. Starts the task timeout process.
	 * 
	 * @throws Exception If there is an issue starting the task timeout process
	 */
	public TaskTimeOutProcess(String iniFileName, String situation) throws Exception  {		
		this.situation = situation;

		ini = new IniFile();
		ini.readINIFile(iniFileName);

		logFileName = ini.getINIVar("logs.timeouttask_log_file");
		log.openLogFile(logFileName);

		con = getDBConnection();
	}

	/**
	 * Start the task timeout process
	 * 
	 * @throws Exception
	 */
	public void start() throws Exception {
		PreparedStatement ps = null;
		ResultSet rs = null;

		try {			
			Timestamp currentTime = new Timestamp(System.currentTimeMillis());

			//Get the frequency of running from Origenate settings and check the situation
			long procFreq = getTimeOutProcessFreq();
			boolean checkSituation  =  situation != null && situation.equals("D1") ? true : false;

			Timer timer = new Timer();
			if(procFreq != 0 && situation == null) {
				timer.schedule(new CheckTaskTimeOut(currentTime), currentTime, procFreq);
			} else {
				String sql = QUERY_CRED_REQ_TASKS;
				sql += PROCESS_TYPE_FLG_TRUE_CLAUSE;

				ps = con.prepareStatement(sql);
				rs = ps.executeQuery();

				List<CheckTaskTimeOut> processThreads = new ArrayList<CheckTaskTimeOut>();

				while(rs.next()){
					TaskTimeoutRecord taskTimeoutRecord = generateTaskTimeoutRecord(rs);

					if(!checkSituation) { 
						processThreads.add(new CheckTaskTimeOut(true, taskTimeoutRecord, currentTime));
					} else {
						log.FmtAndLogMsg("checkSituation is :"+checkSituation + " procFreq is :"+ procFreq +"situation is " +situation);
					}
				}

				ExecutorService threadExecutor = Executors.newFixedThreadPool(NUM_THREADS);

				// Start threads and place in runnable state
				for (CheckTaskTimeOut t : processThreads) {
					threadExecutor.execute(t);
					try {
						Thread.sleep(5000);
					} catch (Exception e) {
						log.FmtAndLogMsg("Issue putting thread to sleep", e);
					}
				}

				threadExecutor.shutdown();
				while (true) {
					Thread.sleep(2000);
					if (threadExecutor.isTerminated()) {
						break;
					}
				}
			}
		} 
		finally {
			ConnectionUtils.closeConnection(con);
			ConnectionUtils.closePreparedStatement(ps);
			ConnectionUtils.closeResultSet(rs);
		}
	}	

	/**
	 * Generate a task timeout record form a result set object
	 * 
	 * @param rs The result set to generate from
	 * 
	 * @return The task timeout record
	 * @throws SQLException If there is an issue generating the task timeout record
	 */
	private TaskTimeoutRecord generateTaskTimeoutRecord(ResultSet rs) throws Exception {
		TaskTimeoutRecord taskTimeoutRecord = new TaskTimeoutRecord();

		taskTimeoutRecord.taskId = rs.getString("task_id").trim();
		taskTimeoutRecord.assignedUserId = rs.getString("assigned_user_id");
		taskTimeoutRecord.taskGroupId = rs.getString("task_group_id");
		taskTimeoutRecord.requestId = rs.getString("request_id");
		taskTimeoutRecord.timeoutTaskId = rs.getString("timeout_task_id");
		taskTimeoutRecord.timeoutUserId = rs.getString("timeout_user_id");

		taskTimeoutRecord.productId = rs.getInt("product_id");
		taskTimeoutRecord.timeoutTeamId = rs.getInt("timeout_team_id");
		taskTimeoutRecord.queryId = rs.getInt("query_id");
		taskTimeoutRecord.assignedTeamId = rs.getInt("assigned_team_id");
		taskTimeoutRecord.callRescoreFlg = rs.getInt("call_rescore_flg");
		taskTimeoutRecord.evaluatorId = rs.getInt("evaluator_id");

		taskTimeoutRecord.timeoutDuration = rs.getLong("timeout_duration");

		taskTimeoutRecord.lastAccessDate = rs.getTimestamp("last_access_date");
		taskTimeoutRecord.lastTaskTimeoutDt = rs.getTimestamp("last_tasktimeout_dt");
		
		taskTimeoutRecord.appStartDate = getLastAccessDt(con, rs.getString("request_id"), rs.getInt("evaluator_id"), rs.getTimestamp("last_access_date"));


		taskTimeoutRecord.lastActivityDate = new Timestamp(Math.max(
				taskTimeoutRecord.appStartDate != null ? taskTimeoutRecord.appStartDate.getTime() : 0, 
						taskTimeoutRecord.lastTaskTimeoutDt != null ? taskTimeoutRecord.lastTaskTimeoutDt.getTime() : 0
				));
		
		return taskTimeoutRecord;
	}

	/** 
	* Determines the date that the application was moved to its current task 
	* @param con - Db connection
	* @param requestID - Application request id
	* @param evaluatorId - Application evaluator id 
	* @param lastAccessDt - last_access_date from credit_request (only used as a default)
	* @throws Exception if any errors are encountered pulling date from credit_request_app_history
	* @return Timestamp - start_date of task currently assigned to application
	*/	
	private Timestamp getLastAccessDt(Connection con, String requestId, int evaluatorId, Timestamp lastAccessDt) throws Exception{
		Timestamp ts = lastAccessDt;
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			String sql = "select start_dt from credit_request_app_history where request_id = "+requestId+" and evaluator_id = "+evaluatorId+" and next_task_id is null order by seq_num desc";
			ps = con.prepareStatement(sql);
			rs = ps.executeQuery();
			if (rs.next()) {
				ts = rs.getTimestamp("start_dt");
			}
		} catch (Exception e) {
			log.FmtAndLogMsg("Exception getting last access date. error="+e.toString());
		}
		finally {
			if (rs != null) rs.close();
			if (ps != null) ps.close();
		}	
		return ts;
	} //getLastAccessDt

	/**
	 * Get a database connection with auto commit disabled from an ini file
	 * 
	 * @throws Exception Problem getting and setting the database connection
	 */
	private Connection getDBConnection() throws Exception {
		//Get ini file values for DB connection
		String host = ini.getINIVar("database.host");
		String port = ini.getINIVar("database.port");
		String sid = ini.getINIVar("database.sid");
		String user = ini.getINIVar("database.user");
		String password = ini.getINIVar("database.password");
		String tnsEntry = ini.getINIVar("database.TNSEntry");

		DBConnection DBConnect = new DBConnection();

		Connection con = null;

		//Use TNS entry if available
		if (tnsEntry == null) {
			con = DBConnect.getConnection(host, sid, user, password, logFileName, port,"");
		} else {
			con = DBConnect.getConnectionTNS(tnsEntry, user,  password, port);
		}

		con.setAutoCommit(false);

		return con;
	}

	/**
	 * Get the timeout process interval
	 * 
	 * @return How often to run task timeout in milliseconds
	 * @throws Exception If there was an issue retrieving the interval
	 */
	private long getTimeOutProcessFreq() throws Exception  {

		long timeOutFreq = 0;

		//Select task time out frequency
		String sql = QUERY_TASK_TIMEOUT_FREQ;
		Query query = new Query(con);
		query.prepareStatement(sql);
		query.executePreparedQuery();

		//Get value of freq.
		if (query.next()) {
			timeOutFreq = Long.parseLong(query.getColValue("task_timeout_frequency_num"));
		}

		//Convert to millisecs
		timeOutFreq = timeOutFreq * 60 * 1000;
		
		return timeOutFreq;
	}

	/**
	 * Check task timeout timer task
	 * 
	 * @author thomasv
	 */
	private class CheckTaskTimeOut extends TimerTask {
		private CommentEvents commEvent;
		private JournalEvents journalEvent;
		private TaskTimeoutRecord taskTimeoutRecord;
		private Timestamp currentTime;
		private boolean isThreadPool;

		/**
		 * Constructor for thread pool mode
		 * 
		 * @param isThreadPool Is this a thread pool task
		 * @param taskTimeoutRecord The task timeout record
		 * @param currentTime The current time
		 */
		public CheckTaskTimeOut(boolean isThreadPool, TaskTimeoutRecord taskTimeoutRecord, Timestamp currentTime) {
			this.isThreadPool = isThreadPool;
			this.taskTimeoutRecord = taskTimeoutRecord;
			this.currentTime = currentTime;
		}

		/**
		 * Contructor for timer mode
		 * 
		 * @param currentTime The current time this task timeout ran
		 */
		public CheckTaskTimeOut(Timestamp currentTime) {
			this(false, null, currentTime);
		}

		@Override
		public void run() {
			try {
				log.FmtAndLogMsg("[BEGIN]");			

				if (con.isClosed()) {
					con = getDBConnection();
				}

				//Create comment obj
				commEvent = new CommentEvents(con, logFileName);

				//Create journal obj
				journalEvent = new JournalEvents(con, logFileName);

				//Update timeout tasks
				if(isThreadPool) {
					checkTimeOutTask();
				} else {
					checkTimeOutTasks();
				}

				//Commit if no errors
				con.commit();
			} catch (Exception e) {
				try {
					//Roll back if errors
					con.rollback();
				} catch (Exception e2) {
					log.FmtAndLogMsg("Error rolling back the database", e2);
				}

				log.FmtAndLogMsg("Error checking the timeout tasks", e);
				log.FmtAndLogMsg("All task timeout updates are rollback from last run. Please contact Administrator!");
				log.FmtAndLogMsg("[END - FAILURE]");
				System.exit(1);
			} finally {
				ConnectionUtils.closeConnection(con);
			}

			log.FmtAndLogMsg("[END - SUCCESSFUL]");			
		}

		/**
		 * Check and update all the timeoout tasks
		 * 
		 * @throws Exception If there is an issue checking or updating the tasks
		 */
		private void checkTimeOutTasks() throws Exception {
			log.FmtAndLogMsg("Starting check for task timeouts...");

			PreparedStatement ps = null;
			ResultSet rs = null;

			//Get current date and time
			Timestamp sysDate = new Timestamp(System.currentTimeMillis());

			try {
				//Select task id and last access date value
				String sql = QUERY_CRED_REQ_TASKS;
				sql += PROCESS_TYPE_FLG_FALSE_CLAUSE;

				//Prepare statement to execute
				ps = con.prepareStatement(sql);

				//Execute statement
				rs = ps.executeQuery();

				log.FmtAndLogMsg("Retrieved configured task timeouts and their corresponding credit request entries...");

				while (rs.next()) {
					taskTimeoutRecord = generateTaskTimeoutRecord(rs);

					//Check if task is eligible to timeout
					if(isTimeOut(taskTimeoutRecord.lastActivityDate, taskTimeoutRecord.timeoutDuration, sysDate) || taskTimeoutRecord.queryId != 0) {
						boolean concurrence  = isAppLocked(taskTimeoutRecord.requestId);

						if(!concurrence && taskTimeoutRecord.callRescoreFlg == 1) {
							lockApp(taskTimeoutRecord.requestId);
							callRescore(taskTimeoutRecord.requestId, taskTimeoutRecord.evaluatorId);
							Thread.sleep(5000);
							deleteConc(taskTimeoutRecord.requestId);
						}

						//Update the task
						updateTaskTimeout(taskTimeoutRecord);
					} else {
						log.FmtAndLogMsg(String.format("Request ID: %s did NOT qualify for task timeout -- "
								+ "Last Activity: %s, Timeout Duration: %s minutes (%s days), Current Time: %s", taskTimeoutRecord.requestId, taskTimeoutRecord.lastActivityDate, 
								taskTimeoutRecord.timeoutDuration, taskTimeoutRecord.timeoutDuration/60/24, sysDate));
					}
				}
			} finally {
				commEvent = null;
				journalEvent = null;
				ConnectionUtils.closeResultSet(rs);
				ConnectionUtils.closePreparedStatement(ps);
			}
		}

		/**
		 * Checks and times out a task using the task timeout record of this class
		 * 
		 * @throws Exception If there is an issue checking or updating the task
		 */
		private void checkTimeOutTask() throws Exception {
			boolean concurrence = isAppLocked(taskTimeoutRecord.requestId);

			Timestamp sysDate = new Timestamp(System.currentTimeMillis());

			if (isTimeOut(taskTimeoutRecord.lastAccessDate, taskTimeoutRecord.timeoutDuration, sysDate)){
				if(taskTimeoutRecord.callRescoreFlg == 1 && !concurrence){
					lockApp(taskTimeoutRecord.requestId);
					callRescore(taskTimeoutRecord.requestId, taskTimeoutRecord.evaluatorId);
					Thread.sleep(5000);
					deleteConc(taskTimeoutRecord.requestId);
				}
			}

			log.FmtAndLogMsg("Start updateTimeOutTask Method... with updateTimeOutTask(5 param)");

			try {
				log.FmtAndLogMsg("Fetched Records from credit_request table. Now checking for time out task for exising requests...");

				//Get values of time out task, if timeout_duration is 0 then it means task can't be timeout

				updateTaskTimeout(taskTimeoutRecord);
			} finally {
				commEvent = null;
				journalEvent = null;
			}

			log.FmtAndLogMsg("End updateTimeOutTask Method...");
		}

		/**
		 * Timeout the task by updating its fields in credit request
		 * 
		 * @throws Exception If there is an issue updating the task
		 */
		private void updateTaskTimeout(TaskTimeoutRecord taskTimeoutRecord) throws Exception {
			Hashtable<String, String> params = new Hashtable<String, String>();

			// If query_id is present, execute query to obtain TTU
			if (taskTimeoutRecord.queryId != 0) {
				GenJob genJob = new GenJob(con, log);
				params.put("request_id", taskTimeoutRecord.requestId);
				params.put("evaluator_id", String.valueOf(taskTimeoutRecord.evaluatorId));
				params.put("product_id", String.valueOf(taskTimeoutRecord.productId));

				Query ttuQuery=genJob.buildAndExecuteQuery(con, ((Integer) taskTimeoutRecord.queryId).toString(), taskTimeoutRecord.requestId, params);

				if (ttuQuery.next()) {
					taskTimeoutRecord.timeoutTaskId = ttuQuery.getColValue("timeout_task_id", "");
					taskTimeoutRecord.timeoutTeamId = Integer.parseInt(ttuQuery.getColValue("timeout_team_id", "0"));
					taskTimeoutRecord.timeoutUserId = ttuQuery.getColValue("timeout_user_id", "");
				} else {
					log.FmtAndLogMsg(String.format("Request ID: %s did NOT qualify for task timeout -- "
							+ "WTU query %s did not return any results", taskTimeoutRecord.requestId, taskTimeoutRecord.queryId));
					return;
				}
			}
			
			long requestID = Long.parseLong(taskTimeoutRecord.requestId);

			//Can't timeout a task if it has none specified
			if (StringUtils.isBlank(taskTimeoutRecord.timeoutTaskId)) {
				log.FmtAndLogMsg(String.format("Request ID: %s did NOT qualify for task timeout -- "
						+ "The task to timeout to is not specified", taskTimeoutRecord.requestId));
				return;
			}

			//Continue, but use the already assigned team
			if (taskTimeoutRecord.timeoutTeamId == 0) {
				taskTimeoutRecord.timeoutTeamId = taskTimeoutRecord.assignedTeamId;
			}
			
			//Continue, but use the already assigned user
			if (StringUtils.isBlank(taskTimeoutRecord.timeoutUserId)) {
				taskTimeoutRecord.timeoutUserId = taskTimeoutRecord.assignedUserId;
			}
			
			//Update to next time out task
			String sql =  UPDATE_CREDIT_REQ_TTO;
			SQLUpdate update = new SQLUpdate();
			update.SetPreparedUpdateStatement(con, sql);
			update.setString(1, taskTimeoutRecord.timeoutTaskId);
			update.setString(2, taskTimeoutRecord.taskGroupId);
			update.setString(3, ApplicationIDs.sysuser);
			update.setTimestamp(4, currentTime);
			update.setTimestamp(5, currentTime);
			update.setInt(6, 1);
			update.setString(7,taskTimeoutRecord.timeoutUserId);
			update.setInt(8,taskTimeoutRecord.timeoutTeamId);
			update.setLong(9, requestID);
			update.setInt(10, taskTimeoutRecord.evaluatorId);

			//Execute statement
			update.RunPreparedUpdateStatement();

			//Log timeout tasks
			log.FmtAndLogMsg(String.format("Request ID: %d WTU Query ID: %d -- Old Task/Team/User: %s, %s, %s -- New Task/Team/User: %s, %s, %s", 
					requestID, taskTimeoutRecord.queryId, taskTimeoutRecord.taskId, taskTimeoutRecord.assignedTeamId, taskTimeoutRecord.assignedUserId, 
					taskTimeoutRecord.timeoutTaskId, taskTimeoutRecord.timeoutTeamId, taskTimeoutRecord.timeoutUserId));                      

			//Add comment entry
			addComment(requestID, currentTime, ApplicationIDs.sysuser, taskTimeoutRecord.taskId, taskTimeoutRecord.timeoutTaskId);

			//Add journal entry
			journalEvent.addJournal(Long.valueOf(requestID).intValue(), 25, "Task TimeOut", ApplicationIDs.sysuser);

			
			//sprint 7 - update app history so that latest status of task is refected in the application history screen 
			//sprint 7 - app history crd_req_app_hist_trg trigger will refect the correct CURRENT_TASK_START_DT
			
			WorkFlowManager wfm = new WorkFlowManager(con, log);
			wfm.updateAppHist(Long.valueOf(requestID).intValue(), taskTimeoutRecord.evaluatorId, taskTimeoutRecord.timeoutTaskId, taskTimeoutRecord.timeoutUserId, 0);
			
			DocGen docGen = new DocGen(ini.getIniFilePath());

			docGen.generateTouchpointDocuments(con, String.valueOf(taskTimeoutRecord.evaluatorId), "81", Long.valueOf(requestID).toString(),
					"DEFAULT",
					"0", 
					"LOCAL",
					"DEFAULT",
					"0",
					"0",
					"SYSTEM",
					"0",
					"0",
					"0",
					false
					);
		}

		/**
		 * Check if a task has timed out
		 * 
		 * @param timeToCompare The time to compare
		 * @param timeDuration The duration that qualifies a timeout
		 * @param theCurrentTime The current time
		 * 
		 * @return If eligible for timeout
		 * @throws Exception If there was a problem checking a task for timeout eligibility
		 */
		private boolean isTimeOut(Timestamp timeToCompare, long timeDuration,  Timestamp theCurrentTime) throws Exception {
			boolean ret_isTimeOut = false;

			if (timeToCompare != null) {
				//Convert timeduration into millisecs
				timeDuration = timeDuration * 1000 * 60;

				//Get total duration time (last access date + duration)
				Timestamp timePeriod = new Timestamp(timeToCompare.getTime() + timeDuration);

				//If current datetime is greater then total duration time
				if (theCurrentTime.after(timePeriod))
					ret_isTimeOut = true;
			}

			return ret_isTimeOut;
		}

		/**
		 * Add a comment
		 * 
		 * @param request_id The request id
		 * @param sysDate The system date/time
		 * @param user_id The user id
		 * @param curr_task The current task
		 * @param next_task The next task
		 * 
		 * @throws Exception If there was an issue adding the comment
		 */
		private void addComment(long request_id, Timestamp sysDate, String user_id, String curr_task, String next_task) throws Exception  {
			String strTaskTimeOutDesc = "";

			if (!next_task.equals("")) {
				strTaskTimeOutDesc = curr_task +  " Task timed out. New task " + next_task + " has been assigned.";
			} else {
				strTaskTimeOutDesc =  curr_task +  " Task timed out. TimeOut Task ID is not defined.";
			}
			//Add comment
			commEvent.addComment(Long.valueOf(request_id).intValue(),26,"Task TimeOut",strTaskTimeOutDesc,user_id, null, "", false);			
		}

		/**
		 * Call rescore on this application
		 * 
		 * @param requestId The request id to call rescore upon
		 * @param evaluatorId The evaluator id to call rescore upon
		 */
		private void callRescore (String requestId, int evaluatorId) throws Exception {

			log.FmtAndLogMsg("*** CALLING RESCORE START ***");
			String ccURL = "";

			ccURL = ini.getINIVar("urls.eval_app_complete_url","");
			if(ccURL.length() <= 0){
				log.FmtAndLogMsg("urls.eval_app_complete_url not defined in origenate.ini, cannot be called");
			}
			ccURL=ccURL.substring(0,ccURL.indexOf("fuse_action="));
			ccURL +=  "fuse_action=";

			ccURL += "fuseTaskTimeOutRescore"+"&request_id="+requestId+"&evaluator_id="+evaluatorId + "&closeSession=true&TaskTimeOuttaskTeamUser=1&user_id=System&calledfromexternal=true&closeSession=true";

			PostRequest postRequest = new PostRequest(log, 5);
			postRequest.post(ccURL,"",300); // 300 sec timeout

			log.FmtAndLogMsg("*** CALLING RESCORE END ***");

		}

		/**
		 * Check if an app is locked
		 * 
		 * @param requestId The request id of the application
		 * 
		 * @return If there was a concurrency flag
		 */
		private boolean isAppLocked(String requestId) throws Exception {
			boolean concurrenceFlg = false;

			String sql = QUERY_LOCK_APP;

			Query query = new Query(con);
			query.prepareStatement(sql);
			query.setString(1, requestId);
			query.executePreparedQuery();

			if (query.next()) {
				concurrenceFlg = true;
			}

			return concurrenceFlg;
		}

		/**
		 * Lock an app by inserting a record into concurrency control
		 * 
		 * @param requestId The request id of the app to lock
		 */
		private void lockApp(String requestId) throws Exception {
			String sql = INSERT_LOCK_APP;

			SQLUpdate update = new SQLUpdate();

			//This this needs to be its own transaction to lock in real time
			Connection con = getDBConnection();

			update.SetPreparedUpdateStatement(con, sql);
			update.setInt(1, requestId);
			update.setString(2, "System");
			update.setString(3, ini.getINIVar("evaluate.ini_host", "").toUpperCase());
			update.setString(4, ini.getINIVar("evaluate.ini_port", ""));
			update.setString(5, ini.getINIVar("evaluate.environment", "").toUpperCase());
			update.RunPreparedUpdateStatement();

			con.commit();

			ConnectionUtils.closeConnection(con);
		}

		/**
		 * Delete a record from concurrency control
		 * 
		 * @param requestId The request id
		 */
		private void deleteConc(String requestId) throws Exception {
			String  sql = DELETE_LOCK_APP;

			SQLUpdate update = new SQLUpdate();

			//This this needs to be its own transaction to unlock in real time
			Connection con = getDBConnection();

			update.SetPreparedUpdateStatement(con, sql);
			update.setLong(1, requestId);
			update.setString(2, "System");

			update.RunPreparedUpdateStatement();

			con.commit();

			ConnectionUtils.closeConnection(con);
		}
		

	}
}
