#!/bin/sh
#
# Process task time out
#


INIFILE=/opt/jrun4/servers/qs42/cfusion-ear/cfusion-war/config/origenate.ini
LOGFILE=/opt/origenate/qs42/timeouttask.log

nohup java -classpath .:../lib/common.jar:../lib/classes111.jar com.cmsinc.origenate.tool.TaskTimeOutProcess $INIFILE $1 >> $LOGFILE &
exit 0
