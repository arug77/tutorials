#!/bin/sh
#
# Starts the BatchMPE process
#
# Make sure origenate.ini is set up properly before running this process
#
INIFILE=/opt/jrun4/servers/qs42/cfusion-ear/cfusion-war/config/origenate.ini
HOSTNAME=`hostname`

nohup java -Xms64m com.cmsinc.origenate.cp.mpe.BatchMpe -i$INIFILE -mEXTRACT -p1 -a1 -c1 -o/opt/origenate/qs42/aaa $1 >> /opt/origenate/qs42/log/BatchMpe.log &
exit 0
