package com.cmsinc.origenate.cp.mpe;

import java.sql.*;

import com.cmsinc.origenate.util.IniFile;
import com.cmsinc.origenate.util.LogMsg;

/**
 *
 *
 */
public class ProcessThread extends Thread  {


    // INSTANCE VARIABLES

    Connection con=null;
    BatchMpe main=null;
    //boolean busy=false;
    //boolean workToDo=false;
    //boolean errorOccurred=false;
    //boolean endThread=false;
    //String errorMessage=null;
    String mpeType="MPE";
    String mpeID = "";
    String mpeSubType = "";
    String mpeFileNm = "";
    String evaluatorID="";
    //String sConStr,sUser,sPass;
    //LogMsg log_obj = null;
    //String batch_job_id="";
    //String submitDate="";
    Mpe mpe=null;
    //String tempDir="";
    //String outputDir="";
    String startDate="";
    //String xsltDir="";
    String endDate="";
    //String product_id="";
	String ach_interface_id="-1";
    //int i_dbg_level=0;
    //boolean applyStyleSheet=false;
    boolean rerun=false;
	//boolean encryption_flg = false;
	String schemaUser = "";
	//IniFile ini;

    // CONSTRUCTOR

    public ProcessThread(BatchMpe main,String sConStr,String sUser,String sPass,
                         String ID,LogMsg log_obj,int i_dbg_level,
                         String submitDate,String tempDir,String outputDir, String startDate,
                         String endDate,boolean applyStyleSheet,String product_id,boolean rerun,String xsltDir,String mpeType, String mpeID, String mpeSubType, String mpeFileNm, boolean encryption_flg, String ach_interface_id, IniFile ini) throws Exception {

       evaluatorID=ID;
       this.main=main;
       //this.sConStr=sConStr;
       //this.product_id=product_id;
       //this.sUser=sUser;
       //this.sPass=sPass;
       //this.log_obj=log_obj;
       //this.i_dbg_level=i_dbg_level;
       //this.submitDate=submitDate;
       //this.tempDir=tempDir;
       //this.outputDir=outputDir;
       this.startDate=startDate;
       this.endDate=endDate;
       //this.applyStyleSheet=applyStyleSheet;
       this.rerun=rerun;
       //this.xsltDir=xsltDir;
       this.mpeType=mpeType;
       this.mpeID = mpeID;
       this.mpeSubType = mpeSubType;
       this.mpeFileNm = mpeFileNm;
	   //this.encryption_flg = encryption_flg;
	   this.schemaUser = sUser;
	   this.ach_interface_id = ach_interface_id;
	   //this.ini = ini;


       // Connect to the Oracle database
       con = DriverManager.getConnection (sConStr,sUser,sPass);

       mpe= new Mpe(con,log_obj,tempDir,outputDir,
                    i_dbg_level,
                    applyStyleSheet,xsltDir,true,"SYSTEM", encryption_flg, schemaUser); // true=batchMode

       if(mpeType.equals("SST") && mpeSubType.equals("PSH")) {
    	   mpe.setini(ini);
       }
       } // end constructor


/////////////////////////////////////////////////////////////////////////////

    // RUN METHOD - execution continues in its own thread

    public void run() {

        // all messages are logged in mpe class

        try {

	        String resp = mpe.generateMpeFile(evaluatorID,rerun,startDate,endDate,mpeType,mpeID,mpeSubType,mpeFileNm,ach_interface_id);
	        if (mpeType.equals("SST") && mpeSubType.equals("PSH")) {
                if (resp.startsWith("ERROR: Empty Records")) {
                    main.setExitStatus(3); // Blank file - code 3
                }
	        	else if(resp.startsWith("ERROR: Unable to connect to PSH Web Service")) {
	        		main.setExitStatus(8); // Complete job fail - code 8
	        	}
	        	else if(resp.startsWith("ERROR: Complete job fail")) {
	        		main.setExitStatus(8); // Complete job fail - code 8
	        	}
	        	else if(resp.startsWith("ERROR: Partial job fail")) {
	        		main.setExitStatus(9); // Partial job fail - code 9
	        	}
	        	else if(resp.startsWith("ERROR: Partial call fail")) {
	        		main.setExitStatus(4); // Partial call fail - code 4
	        	}
                else {
                    main.setExitStatus(0); // All records processed successfully - code 0
                }
	        }
        }
        catch (Exception e) {
            // error logged in mpe class
        }

        // close down this thread

        try {con.close();} catch (Exception e1) {}


        main.threadCount(true); // decrease thread count

      // fall thru to end thread

    } // end run()




} // ProcessThread


