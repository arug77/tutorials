package com.cmsinc.origenate.cp.mpe;

import java.io.*;
import java.util.*;
import java.sql.*;

import com.cmsinc.origenate.util.LogMsg;
import com.cmsinc.origenate.util.IniFile;
import com.cmsinc.origenate.util.COLEncrypt;
import com.cmsinc.origenate.util.Query;
import com.cmsinc.origenate.util.OWASPSecurity;

/*
 * BatchMpe.java   ( Multi Purpose Export )
 *
 * Created on May 15, 2003
 *
 * @author  Glenn Leyba
 * @version
 *
 * Searches for apps that need to be exported to a servicing system
 *
 */
public class BatchMpe extends Object {

    /* Version history

        1.0  - Initial release
    */


    static String VERSION = "1.0";

    static String DATEFORMAT = "mm/dd/yy hh24:mi";



    String sHost = "";
    String sSIDname = "";
    String sPort = "";
    String sUser = "";
    String sPass = "";
    String sTNSEntry = "";
    String sIniFile = "";
	//String schemaUser = "";
	boolean encryption_flg = false;
    String eojFileName="";
    File   eojFile = null;  // file object used to find eoj file

    int i_dbg_level=0;
    IniFile ini= new IniFile();
    LogMsg log_obj = new LogMsg();
    String evaluatorList="";
    //String letterIDList="";
    String submitDate="";
    String startDate="";
    String endDate="";
    String mpeType="";
    String mpeID ="";
    String mpeSubType ="";
    String mpeFileNm = "";
    String tempDir="";
    String outputDir="";
    String xsltDir="";
    String product_id="1";
	String ach_interface_id="-1";
    boolean applyStyleSheet=true;
    boolean rerun=false;
    int exitStatus = 0;

    Vector<ProcessThread> processThreads=null;
    int runningThreads=0;


    public BatchMpe() {}


    /////////////////////////////////////////////////////////////////////////////////


    static public void main (String args[]) {

        BatchMpe mpe = new BatchMpe();
        try {
          mpe.run(args);
        }
        catch (Exception e) {} // error already reported
        
        System.exit(mpe.exitStatus);
    }

    ///////////////////////////////////////////////////////////////////////////////////////


    private void GetArgs(String args[],LogMsg log_obj) {
        int ix;

        if (args.length > 0) {

            for (ix = 0; ix < args.length; ++ix) {

                if ((args[ix].charAt(0) != '-') && (args[ix].length() > 1)){
                    ShowUsage();
                }

                switch (args[ix].charAt(1)) {

                    case 'i':
                    sIniFile = args[ix].substring(2);
                    log(0,"IniFile is '" + sIniFile + "'");
                    try {
                        //
                        // Read host, user, sid and password from ini file
                        //
                        ini.readINIFile(sIniFile);

                        //String logFile = ini.getINIVar("mpe.log_file","");

                        /*************
                        don't open log file, let it write to systemout like
                        the RQP, PQP
                        if (logFile.length()>0) {
                            log_obj.openLogFile(logFile);
                        }
                        *************/

                        log(0,"BatchMpe version "+VERSION+" initializing...");

                        sHost = ini.getINIVar("database.host","");
                        log(0,"Host is '" + sHost + "'");

                        sPort = ini.getINIVar("database.port","");
                        log(0,"Port is '" + sPort + "'");

                        sUser = ini.getINIVar("database.user","");
                        log(0,"User:"+sUser);

                        sPass = ini.getINIVar("database.password","");
                        //log(0,"Password:"+sPass);

                        sSIDname = ini.getINIVar("database.sid","");
                        log(0,"Database (SID name) is '" + sSIDname + "'");

                        sTNSEntry = ini.getINIVar("database.TNSEntry","");
                        log(0,"TNS Entry is '" + sTNSEntry + "'");
                        
                        tempDir = ini.getINIVar("mpe.temp_dir","");
                        if (tempDir.length()>0) {
                          log(0,"ini temp dir: "+tempDir);
                          tempDir+=File.separator;
                        }

                        outputDir = ini.getINIVar("mpe.output_dir","");
                        if (outputDir.length()>0) {
                          log(0,"ini output dir: "+outputDir);
                          outputDir+=File.separator;
                        }

                        xsltDir = ini.getINIVar("mpe.xslt_dir","");
                        if (xsltDir.length()>0) {
                          log(0,"ini xslt dir: "+xsltDir);
                          xsltDir+=File.separator;
                        }

                        i_dbg_level = Integer.parseInt(ini.getINIVar("mpe.debug_level","0"));
                        if (i_dbg_level > 0)
                            log(0,"debug in ON");
						
						if(Integer.parseInt(ini.getINIVar("encryption.encryption_flg","0")) == 1) {
							encryption_flg = true;
						}
						
						log(0,"BatchMPE Encryption (True/False): '" + encryption_flg + "':"+sUser);

                    }
                    catch (Exception e) {
                        log(0,"Caught exception reading ini file '" + sIniFile + "':"+e.toString());
                    }
                    break;


                    case 'd': // turn debug on
                       i_dbg_level=5;
                    break;

                    case 'j': // eoj file name
                       eojFileName=args[ix].substring(2);
                    break;

                    case 'm':
                       mpeType=args[ix].substring(2);
                    break;

                   case 'b':
                    mpeID=args[ix].substring(2);
                    break;

                   case 'f':
                    mpeSubType=args[ix].substring(2);
                    break;

                  case 'g':
                    mpeFileNm=args[ix].substring(2);
                    break;

                    case 'h': // ach interface id
                       ach_interface_id=args[ix].substring(2);
                    break;	

                    case 'a': //
                       applyStyleSheet=(args[ix].substring(2).equals("1"));
                    break;

                    case 't': // temp dir
                       tempDir=args[ix].substring(2);
                       tempDir+=File.separator;
                    break;

                    case 'x': // xslt dir
                       xsltDir=args[ix].substring(2);
                       xsltDir+=File.separator;
                    break;

                    case 'p': // temp dir
                       product_id=args[ix].substring(2);
                    break;

                    case 'o': // output dir
                       outputDir=args[ix].substring(2);
                       outputDir+=File.separator;
                    break;

                    case 's': // start date for reruns mm/dd/yyyy
                       startDate=args[ix].substring(2);
                    break;

                    case 'e': // end date for reruns mm/dd/yyyy
                       endDate=args[ix].substring(2);
                    break;

                    case 'c': // evaluator list
                    evaluatorList=args[ix].substring(2);
                    evaluatorList=evaluatorList.toLowerCase();
                    break;

                    default:
                    log(0,"Unknown parameter: " + args[ix]);
                    ShowUsage();
                    break;
                }
            } // for each parm


            // edits

            if ((sHost.length()==0) ||
                (sUser.length()==0) ||
                (tempDir.length()==0) ||
                (outputDir.length()==0) ||
                (sSIDname.length()==0) ||
                (mpeType.length()==0) ||
                (sPort.length()==0)
                ) {
                log(0,"MPE Type,Host,User,Pwd,tempDir,outputDir,SID or Port not specified");
                ShowUsage();
            }


            if (evaluatorList.length()==0) {
                log(0,"-c parm is required");
                ShowUsage();
            }



            log(0,"Debug level:  "+i_dbg_level);
            log(0,"MPE Type: "+mpeType);
            log(0,"Product ID: "+product_id);
			log(0,"ACH Interface ID: "+ach_interface_id);
            log(0,"Company list: "+evaluatorList);
            if (startDate.length()==0) {
                rerun=false;
                log(0,"Start date: TODAY");
                log(0,"End date:   TODAY");
                log(0,"Rerun:   "+rerun);
            }
            else {
               rerun=true;
               log(0,"Start date: "+startDate);
               log(0,"End date:   "+endDate);
               log(0,"Rerun:   "+rerun);
            }
            log(0,"Style sheet: "+applyStyleSheet);
            log(0,"Temp dir: "+tempDir);
            log(0,"Output dir: "+outputDir);
            log(0,"XSLT dir: "+xsltDir);
            log(0,"EOJ file: "+eojFileName);



            if (evaluatorList.toLowerCase().equals("all")) evaluatorList="";

        }
        else {
            ShowUsage();
        }


    } // getArgs

    ////////////////////////////////////////////////////////////////////////////////////


    private void ShowUsage() {
        System.out.println("");
        System.out.println("Usage: java BatchMpe -i<inifile> -m<mpe type> -p<product id> -c<company ID list> -t<temp dir path> -o<output dir path> [-s<startdate mm/dd/yyyy>] [-e<enddate mm/dd/yyyy>] [-d] [-j<eoj file name>] ");
        System.out.println("---------------------");
        System.out.println("-i - required: INI file to use for configuration");
        System.out.println("-c - required: Company ID list separated by commas (-c1279,1123,3312 or -cALL for all companies)");
        System.out.println("-m - required: MPE Type: MPE, ACH, SST, CHK, GL, or EXTRACT");
        System.out.println("-b - required: MPE ID");
        System.out.println("-f - required: MPE Sub Type ");
        System.out.println("-g - required: File Name text");
		System.out.println("-h - required: ACH Interface ID (-1 if not utilized - this will be the default)");
        System.out.println("-t - optional: temp dir (dir while file is being built) overrides mpe_temp_dir in ini file");
        System.out.println("-o - optional: output dir (dir will output file will be deposited) overrides mpe_output_dir in ini file");
        System.out.println("-x - optional: xslt dir (dir to find stylesheets to convert to lender format) overrides xslt dir in ini file");
        System.out.println("-s - optional: start date (for reruns)");
        System.out.println("-e - optional: end   date (for reruns)");
        System.out.println("-j - optional: filename and path of eoj file");
        System.out.println("-d - optional: turns debug messages on.  (Default is off) overrides ini setting");
        System.out.println("-a - optional: apply assigned style sheet (default 1)");
        System.out.println("-p - optional: Product ID (default 1 - indirect auto)");
        System.out.println("example: java BatchMpe -ic:/development/origenatebin/origenate.ini -eALL -tc:/development/origenateapps/mpe/tmp -oc:/development/origenateapps/mpe/output");
        System.exit(1);
    }


    /////////////////////////////////////////////////////////////////////////////////



    void run(String args[]) throws Exception {
        Connection con = null;

        log(0,"BatchMpe initializing..."); // to stderr

        GetArgs(args,log_obj);

        if (eojFileName.length()>0) {
        
        /**		
         * OWASP TOP 10 2010 - A4 Path Manipulation
         * Changes to the below code to fix vulnerabilities
         * TTP 324955
         **/        	
         //eojFile = new File(eojFileName);
		   //eojFile = new File(Encode.forJava(eojFileName));     	
        	eojFile = new File(OWASPSecurity.validationCheck(eojFileName, OWASPSecurity.DIRANDFILE)); 
          if (eojFile.exists()) eojFile.delete(); // make sure one doesn't already exist
        }

        // sConStr should be something like:
        // "jdbc:oracle:thin:@172.16.17.108:1521:cmsiprod"
        String sConStr = "jdbc:oracle:thin:@";
        
        if (sTNSEntry.length() == 0) {
        	sConStr = sConStr + sHost + ":" + sPort + ":" + sSIDname;
        } else {
        	sConStr = sConStr + sTNSEntry;
        }

        try {

            // Load Oracle driver
            DriverManager.registerDriver (new oracle.jdbc.OracleDriver());

            log(0,"Connecting to database: "+sConStr);

            sPass=COLEncrypt.sDecrypt(sPass);

            // Connect to the Oracle database
            con = DriverManager.getConnection (sConStr,sUser,sPass);

        }
        catch (Exception e) {
            log(0,"Error connecting to database: "+e.toString());
            throw e;
        }


        Query queryTmp = new Query(con);

        queryTmp.executeQuery("SELECT to_char(sysdate,'mm/dd/yyyy') as curr_dt FROM DUAL");

        queryTmp.next();

        // submitDate is used by all threads to indicate the date that all related rows were processed
        submitDate=queryTmp.getColValue("curr_dt");


        if (startDate.length()==0) {
            startDate=submitDate;
            endDate=submitDate;
        }



        // if evaluator list is all then create an all inclusive list


        if (evaluatorList.length()==0) {

           queryTmp.executeQuery("SELECT evaluator_id from evaluator where evaluator_id <> -1 order by evaluator_id");

           while(queryTmp.next())
               evaluatorList+=queryTmp.getColValue("evaluator_id")+",";
        }




        // create a thread for each evaluator

        log(0,"Starting company threads...");

        processThreads = new Vector<ProcessThread>();

        StringTokenizer t = new StringTokenizer(evaluatorList, ",");
        String evaluator_id;
        runningThreads=0;
        ProcessThread pt = null;

        while (t.hasMoreTokens()) {
            evaluator_id = t.nextToken().toUpperCase();
            // create the thread but don't start it running yet
            try {
                  pt = new ProcessThread(this,sConStr,sUser,sPass,
                                         evaluator_id,log_obj,i_dbg_level,submitDate,
                                         tempDir,outputDir,startDate,endDate,applyStyleSheet,
                                         product_id,rerun,xsltDir,mpeType,mpeID,mpeSubType,mpeFileNm, encryption_flg, ach_interface_id,ini);
            }
            catch (Exception e) {
                log(0,"Error creating company thread: "+e.toString());
                throw e;
            }
            processThreads.addElement(pt);
            runningThreads++;
        } // for each evaluator

        // start each thread to do the actual work

        for (Enumeration<ProcessThread> e = processThreads.elements(); e.hasMoreElements (); ) {
        	e.nextElement().start();
        }

        // Now wait for all threads to finish their work

        // wait for threads to end gracefully

        while(true) {

           if (threadCount(false)<=0) break;

           // sleep 3 seconds
           try {Thread.sleep(3000);} catch (Exception e) {}

            if (eojFileExists()) {
              log(0,"EOJ file found, shutting down...");
              break;
            }

        }


        try {con.close();} catch (Exception e1) {}

        log(0,"BatchMpe exiting.");


    } // run


    ///////////////////////////////////////////////////////////////////////////////////////


    public boolean eojFileExists() {

        if (eojFile!=null && eojFile.exists()) {
           eojFile.delete();
           return(true);
        }
        return(false);
    }

  ////////////////////////////////////////////////////////////////////


  public synchronized void log(int level,String msg) {

      log_obj.FmtAndLogMsg(msg,i_dbg_level,level);

  }


  public synchronized int threadCount(boolean decreaseCount) {
      if (decreaseCount)
          runningThreads--;
      return(runningThreads);
  }
  
  public synchronized void setExitStatus(int status) {
	  this.exitStatus = status;
  }


} // end class BatchMpe