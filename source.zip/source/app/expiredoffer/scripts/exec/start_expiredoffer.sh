#!/bin/sh
#
# Process Expired offer
#


INIFILE=/opt/jrun4/servers/qs42/cfusion-ear/cfusion-war/config/origenate.ini
LOGFILE=/opt/origenate/qs42/log/expiredoffer.log

nohup java -classpath .:../lib/evidl.jar:../lib/common.jar:../lib/ojdbc6.jar com.cmsinc.origenate.tool.ExpiredOffer $INIFILE $1 >> $LOGFILE &
exit 0
