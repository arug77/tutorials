/****************************************************************************************************************
   Company: First American CMSI
    Product: Origenate
    Version: Beta
    Author: Akash Pandya
    Copyright (c) 2002. All rights reserved

    Description: Manages expired offers
                 Check start.bat file to start this process.
*******************************************************************************************************************/
package com.cmsinc.origenate.tool;


import com.cmsinc.origenate.util.DBConnection;
import com.cmsinc.origenate.workflow.ApplicationIDs;
import com.cmsinc.origenate.workflow.WorkFlowManager;
import com.cmsinc.origenate.util.IniFile;
import com.cmsinc.origenate.event.CommentEvents;
import com.cmsinc.origenate.event.JournalEvents;
import com.cmsinc.origenate.uw.decisioning.RealTimeDataExtractor;

import java.util.Timer;
import java.util.TimerTask;
import java.util.*;
import com.cmsinc.origenate.util.LogMsg;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.PreparedStatement;
import java.sql.Timestamp;
import java.text.*;

public class ExpiredOffer {

  //Set debugger
  private static boolean b_debugger = true;
  private static CommentEvents commEvent;
  private static JournalEvents journalEvent;
  private static int appLockParam = 0;


  private Timer timer;
  private static java.sql.Connection con;
  private static LogMsg log = new LogMsg();
  private static  String s_log_file = "";
  private static String iniFileNm = "c:\\development\\origenatebin\\origenate.ini";
  private static IniFile ini = null;


  /***************************************************************/
   /*              Main method to call expired offer process      */
   /***************************************************************/
  public static void main(String argv[]) throws Exception {
    if (argv.length != 0) {
      //Call time out process with ini file
      iniFileNm = argv[0].trim();
	  
	  //  CIT 157587 appLockParam var will be used  to lock down all the expired apps if this input arg is 1
	  if (argv.length >= 2) {
	  appLockParam = Integer.parseInt(argv[1].trim());
	   } else { 
			 appLockParam = 0;	
			}
	  	    
    }
    //Create object of expired offer process
    //new ExpiredOffer();
    updateExpiredOffer();
  }


  /***************************************************************/
  /* Create Expired offer obejct and get DB connection         */
  /***************************************************************/
  private static void getDBConnection(String s_iniFile) throws Exception {

    try {
      //Get ini file values for DB connection
      ini = new IniFile();
      ini.readINIFile(s_iniFile);
      String s_host = ini.getINIVar("database.host");
      String s_port = ini.getINIVar("database.port");
      String s_sid = ini.getINIVar("database.sid");
      String s_user = ini.getINIVar("database.user");
      String s_password = ini.getINIVar("database.password");
      String sTNSEntry = ini.getINIVar("database.TNSEntry", "");
      s_log_file = ini.getINIVar("logs.expiredoffer_log_file");
      
      DBConnection DBConnect = new DBConnection();
      log.openLogFile(s_log_file);
      
      if (sTNSEntry.length() == 0) {
    	  con = DBConnect.getConnection( s_host,  s_sid, s_user,  s_password, s_log_file, s_port,"");
      } else {
    	  // use tns entry if available
    	  con = DBConnect.getConnectionTNS(sTNSEntry, s_user,  s_password, s_log_file);
      }
    } catch (Exception e) {
      recordError(e, "getDBConnection");
    }
  }

  /***************************************************************/
  /*                    Reocord error                            */
  /***************************************************************/
  private static void recordError(Exception err, String classStr) throws Exception  {
    try {
      if (b_debugger)
        err.printStackTrace();
      log.FmtAndLogMsg("Error in " + classStr + " method of : " + err.toString());
      throw new Exception("Error in " + classStr + " method of : " + err.toString());
    } catch (Exception e) {
      log.FmtAndLogMsg("Error in recordError method of : " + e.toString());
    }
  }

  /***************************************************************/
  /*                    Reocord thread  error                    */
  /***************************************************************/
  private void recordThreadError(Exception err, String classStr)  {
    try {
      if (b_debugger)
        err.printStackTrace();
      log.FmtAndLogMsg("Error in " + classStr + " method of : " + err.toString());
      throw new Exception("Error in " + classStr + " method of : " + err.toString());
    } catch (Exception e) {
      log.FmtAndLogMsg("Error in recordError method of : " + e.toString());
    }
  }


  /***************************************************************/
  /*    Gets Expired offer frequency                             */
  /***************************************************************/
  private long getExpiredOfferFreq() throws Exception  {

    long ret_expiredOfferFreq = 0;
    PreparedStatement ps = null;
    ResultSet rs = null;
    String sql = "";

    try {

      //Select task time out frequency
      sql =   " select expired_offer_frequency_num from origenate_setting ";

      //Prepare statement to execute
      ps = con.prepareStatement(sql);

      //Execute statement
      rs = ps.executeQuery();

      //Get value of freq.
      if (rs.next())
         ret_expiredOfferFreq = rs.getLong("expired_offer_frequency_num");


    } catch (Exception ex) {
      recordError(ex, "getExpiredOfferFreq");
    } finally {
        try{ if(rs != null) rs.close(); }catch(Exception e1){e1.printStackTrace();}
	    try{ if(ps != null) ps.close(); }catch(Exception e1){e1.printStackTrace();}
    }
    //Convert to millisecs
    ret_expiredOfferFreq = ret_expiredOfferFreq * 60 * 1000;
    return ret_expiredOfferFreq;
  }

  /***************************************************************/
  /*    Schedule a task that executes at specific time           */
 /***************************************************************/
  public ExpiredOffer() throws Exception  {
    try {


      timer = new Timer();

      //Get db connection
      getDBConnection(iniFileNm);

      //Get frquency of expired offer execution
      long procFreq = getExpiredOfferFreq();

      //If frequency is not set then do not schedule process
      if (procFreq != 0) {

        Timestamp procDt = new java.sql.Timestamp(System.currentTimeMillis());
        timer = new Timer();

        log.FmtAndLogMsg("About to Schedule Expired Offer Process....");
        //Create thread to manage scheduling
        timer.schedule(new CheckExpiredOffer(), procDt, procFreq);

      } else {
        log.FmtAndLogMsg("Error: Frequecy period is not defined. Expired Offer process has not been scheduled...");
        System.out.println("Error: Frequecy period is not defined. Expired Offer process has not been scheduled...");
        System.exit(0);
      }
    } catch (Exception ex) {
      recordError(ex, "ExpiredOffer");
      System.exit(0);
    }
  }


  /***************************************************************/
   /*               Thread class for time out task                */
   /***************************************************************/
  class CheckExpiredOffer extends TimerTask {
	  
    /***************************************************************/
    /*    Default method of the thread                             */
    /***************************************************************/
    public void run() {
      try {
        //Get db connection; if it is closed
        if (con.isClosed())
          getDBConnection(iniFileNm);

        //Create comment obj
        commEvent = new CommentEvents(con,s_log_file);

        //Create comment obj
        journalEvent = new JournalEvents(con,s_log_file);

        //Update expired offer
        updateExpiredOffer();

      }  catch (Exception ex) {
        recordThreadError(ex, "run");
      }
    }
  }

    /***************************************************************/
    /*    Check  task time out  and update to next task            */
    /***************************************************************/
     private static void updateExpiredOffer() throws Exception {
    	PreparedStatement ps = null, ps1 = null;
    	ResultSet rs = null, rs1 = null;
    	String sql = "";
    	WorkFlowManager wfManager = null;
		int referralConfig = 0;
    	
    	// get current date and time
    	Timestamp sysDate = new java.sql.Timestamp(System.currentTimeMillis());

    	try {
    		// get db connection; if it is closed
    		getDBConnection(iniFileNm);
    		// create comment obj
    		commEvent = new CommentEvents(con,s_log_file);
    		// create comment obj
    		journalEvent = new JournalEvents(con,s_log_file);

    		log.FmtAndLogMsg("*** Expired offer process started successfully. ****");

    		// join the numerous queries that were running inside a loop into
    		// one for performance

                /* GL. 160972 12/14/2012 - Do not expire any apps that have the econtract_flg set
                */
    		sql =
    			"SELECT " + 
    				"cr.request_id, cr.evaluator_id, cr.product_id, cr.app_status_id, cr.previously_logged_flg, " +
    				"nvl(cr.convert_to_paper_flg, -1) AS convert_to_paper_flg, " + 
    				"nvl(cr.paper_contract_started_flg, -1) AS paper_contract_started_flg, " +
					"nvl(cr.econtract_flg, 0) AS econtract_flg, " + 
    				"crde.send_dt, crde.decision_id, crde.decisioning_evaluator_id " +
    			"FROM " +
    				"credit_request cr, " + 
    				"credit_req_work_item_assign crwa, " + 
    				"config_task ct, " + 
    				"credit_req_decisions_evaluator crde " +
    			"WHERE cr.request_id = crwa.request_id " +
    			"AND cr.evaluator_id = crwa.evaluator_id " +
    			"AND cr.evaluator_id = ct.evaluator_id " +
    			"AND cr.task_id = ct.task_id " +
    			"AND cr.app_status_id <> ? " +
                        " AND nvl(cr.econtract_flg,0) = 0 " +
    			"AND ct.ok_to_expire_flg = 1 " +
				"AND ct.task_id != 'DONE' " +
    			"AND crde.decision_ref_id = (" +
    				"SELECT MAX(decision_ref_id) " +
    				"FROM credit_req_decisions_evaluator " +
    				"WHERE evaluator_id = cr.evaluator_id " +
    				"AND request_id = cr.request_id " +
    				"AND (decision_id = ? OR decision_id  = ? OR decision_id  = ?) " +
    				"AND decision_category_id <> ?)";
    		
    		// prepare statement to execute
    		ps = con.prepareStatement(sql);
    		ps.setInt(1, ApplicationIDs.app_expired);
            ps.setInt(2, ApplicationIDs.dec_approve);
            ps.setInt(3, ApplicationIDs.dec_appcond);
            ps.setInt(4, ApplicationIDs.dec_appscor);
            ps.setInt(5, ApplicationIDs.dec_cat_ll);
    		// execute statement
    		rs = ps.executeQuery();

    		log.FmtAndLogMsg("Fetching CR records...");
    		
    		// get values of expired offer period
    		while (rs.next()) {
    			long requestId = rs.getInt("request_id");
    			int evaluatorId = rs.getInt("evaluator_id");
    			int productId = rs.getInt("product_id");
    			int previouslyLoggedFlg = rs.getInt("previously_logged_flg");
    			int decisionId = rs.getInt("decision_id");
    			Integer decEvaluatorId = rs.getInt("decisioning_evaluator_id");
				


					sql = "select lr_evaluator_id " + 
					  "from xref_evaluator_lr_evaluator " +
					  "where evaluator_id = ? and active_flg = 1";
					 
					 ps1 = con.prepareStatement(sql);
					 ps1.setInt(1, evaluatorId);
					 rs1 = ps1.executeQuery();
					 int lrEvaluatorId = 0;
					 referralConfig = 0;
					
					while (rs1.next()) { 
					  lrEvaluatorId = rs1.getInt("lr_evaluator_id");
  
					  if(decEvaluatorId != 0 && decEvaluatorId.equals(lrEvaluatorId)) { 
					  referralConfig = 1;
					  break; }
					 }
					 
					try {rs1.close();} catch (Exception e1) {}
    				try {ps1.close();} catch (Exception e1) {}
							
					String table_name = "config_expired_book_status";
					if(referralConfig == 1) { 
						table_name = "config_lr_expired_book_status";
					}
					
				
    			// select expired offer duration
    			sql = 
	            	"SELECT expired_offer_delay_days_num " +
	            	"FROM "  + table_name +
	            	" WHERE decision_id = ? " +
	            	"AND previously_logged_flg = ? " +
	            	"AND evaluator_id = ? " +
	            	"AND product_id = ?";
					
					if(referralConfig == 1) { 
						sql = sql + " AND lr_evaluator_id = ?";
					}

    			
				// prepare statement to execute
    			ps1 = con.prepareStatement(sql,ResultSet.TYPE_SCROLL_INSENSITIVE,
                                      ResultSet.CONCUR_READ_ONLY);
	           
    			ps1.setInt(1, decisionId);
    			ps1.setInt(2, previouslyLoggedFlg);
    			ps1.setInt(3, evaluatorId);
    			ps1.setInt(4, productId);
				
				if(referralConfig == 1) { 
						ps1.setInt(5, lrEvaluatorId);
					}

    			// execute statement
    			rs1 = ps1.executeQuery();
				
				//check if the Referral Lenders Configuration is available
				if(referralConfig == 1) { 
					if (rs1.next()){ 
					rs1.previous();
					} else {  	
					// select expired offer duration
					try {rs1.close();} catch (Exception e1) {}
    				try {ps1.close();} catch (Exception e1) {}
					
					sql = 
						"SELECT expired_offer_delay_days_num " +
						"FROM config_expired_book_status " +
						"WHERE decision_id = ? " +
						"AND previously_logged_flg = ? " +
						"AND evaluator_id = ? " +
						"AND product_id = ?";
					
				
					// prepare statement to execute
					ps1 = con.prepareStatement(sql);
					ps1.setInt(1, decisionId);
					ps1.setInt(2, previouslyLoggedFlg);
					ps1.setInt(3, evaluatorId);
					ps1.setInt(4, productId);
					
					
					// execute statement
					rs1 = ps1.executeQuery();
				 }
				}
				
				

    			// get values of expired offer period
    			if (rs1.next()) {
    				long expiredOffer = rs1.getLong("expired_offer_delay_days_num");

    				try {rs1.close();} catch (Exception e1) {}
    				try {ps1.close();} catch (Exception e1) {}
    				
    				if  (expiredOffer != 0) {						
    					// convert time duration into millisecs
    					expiredOffer = expiredOffer * 24 * 60 * 60 * 1000;

    					// get total duration time (last decisoin date + duration)
    					Timestamp timePeriod = new Timestamp(rs.getTimestamp("send_dt").getTime() + expiredOffer);

    					// if current datetime is greater then total duration time
    					if (sysDate.after(timePeriod)) {
    						int bookStatus = 1;
                    
    						sql =
    							"SELECT booking_status_id " +
    							"FROM config_expired_book_status " + 
    							"WHERE decision_id = ? " +
    							"AND previously_logged_flg = ? " +
    							"AND evaluator_id = ? " +
    							"AND product_id = ?";

    						// prepare statement to execute
    						ps1 = con.prepareStatement(sql);
    						ps1.setInt(1, decisionId);
    						ps1.setInt(2,previouslyLoggedFlg);
    						ps1.setInt(3, evaluatorId);
    						ps1.setInt(4, productId);
	            
    						// execute statement
    						rs1 = ps1.executeQuery();
		
    						// if decision exists
    						if (rs1.next()) {
    							bookStatus = rs1.getInt("booking_status_id");
    						}

    						try {rs1.close();} catch (Exception e1) {}
    						try {ps1.close();} catch (Exception e1) {}
                   
    						// update to next time out task and set the applock flag.
    						sql = 
    							"UPDATE credit_request " +
    							"SET booking_status_id = ?, app_status_id = ?, app_lock_flg = ? " +
    							"WHERE request_id = ?";

    						// prepare statement to execute
    						ps1 = con.prepareStatement(sql);
    						ps1.setInt(1, bookStatus);
    						ps1.setInt(2, ApplicationIDs.app_expired);
							ps1.setInt(3, appLockParam);
    						ps1.setLong(4, requestId);

    						// execute statement
    						ps1.execute();

    						try {ps1.close();} catch (Exception e1) {}

												
							
			if((bookStatus == 2) || (bookStatus == 3) || (bookStatus == 4) || (bookStatus == 5)) {
			
				Integer eval = evaluatorId;
			
			 // Run realtime data extractor when the booking status is updated to NOTBKD, NOTACC,BOOKED, BOOKEX
			 
			 RealTimeDataExtractor rtData = new RealTimeDataExtractor(con, ini);
			 
			 rtData.realTimeExtract(5, requestId, eval.longValue()); }
							
							
							//update booking status
    						sql = 
    							"UPDATE credit_request_activity " +
    							"SET activity_status_id = ?, audit_updated_user_id = ?, audit_last_updated_dt = sysdate " +
    							"WHERE request_id = ? and activity_id = 23";

    						// prepare statement to execute
    						ps1 = con.prepareStatement(sql);
    						ps1.setInt(1, 3);
    						ps1.setString(2,"SYSTEM");
    						ps1.setLong(3,requestId);

    						// execute statement
    						ps1.execute();	
							
							try {ps1.close();} catch (Exception e1) {}
							
    						wfManager = new WorkFlowManager(con, log);

    						// send cancel transaction to dealer for econtract
    						if (rs.getInt("econtract_flg") == 1) {
    							if (!wfManager.addRQEntry(requestId, evaluatorId, "ContractRs|ChecklistRs|AppActivityRq|LoanAppRq", "CANCEL")) {
    								log.FmtAndLogMsg("REQUEST_ID: " + requestId  + " ,expired offer error in adding RQ entry for cancel transaction.");
    							}
    						}
    						// move app to system/done
    						wfManager.setNewTaskandTaskGroup(requestId, "DONE", "SYSTEM", ApplicationIDs.sysuser); 
    						// create string comment
    						String strComment = "Offer expired on " + getDateTimeStr(timePeriod, "M/d/yyyy HH:mm:ss");

    						// log timeout tasks
    						log.FmtAndLogMsg("Request id : " + requestId + ", " + strComment );

    						// add comment entry
    						addComment(requestId, sysDate, ApplicationIDs.sysuser, strComment);
							
    						// add journal entry
    						addJournal(requestId, ApplicationIDs.sysuser);

    						// check to see if app is hmda eligible
    						// if it is, then set hmda activity and alert accordingly
    						setHMDA(requestId, productId); 
						
    					}
    				}
    			} else {
    				log.FmtAndLogMsg("Request ID: " + requestId  + ", expired offer period is not configured for Product ID : " + productId);
    				
    				try {rs1.close();} catch (Exception e1) {}
    				try {ps1.close();} catch (Exception e1) {}
    			}
    		}
    		
    		try {rs.close();} catch (Exception e1) {}
    		try {ps.close();} catch (Exception e1) {}

    		log.FmtAndLogMsg("*** Expired offer process completed successfully. ****");
    	}
    	
    	catch (Exception ex) {
    		// roll back changes
    		con.rollback();
    		con.close();
    		// record error
    		recordError(ex, "updateExpiredOffer");
    		System.out.println(ex.getMessage());
    		ex.printStackTrace();
    		System.exit(0);
    	}
    	
    	finally {
    		try {
    			if (rs != null) rs.close();
    			if (rs1 != null) rs1.close();
    			if (ps != null) ps.close();
    			if (ps1 != null) ps1.close();
    			if (commEvent != null) commEvent = null;
    			if (journalEvent != null) journalEvent = null;
    			if (wfManager != null) wfManager = null;
    			if (con != null) con.close();
    		}
    		
    		catch (Exception e) {
    			recordError(e, "updateExpiredOffer");
    		}
    	}
    }

   /***************************************************************/
  /*               Add comments                                  */
  /***************************************************************/
    private static void addComment(long request_id, Timestamp sysDate, String user_id, String expiredOfferDesc) throws Exception  {
      try {
        //Add comment
        commEvent.addComment((Long.valueOf(request_id)).intValue(),24,"Offer Expired",expiredOfferDesc,user_id, "", "");
      } catch (Exception ex) {
        try {
          con.rollback();
          recordError(ex, "addComment");
          log.FmtAndLogMsg("*** All offer expired updates are rollback from last run. Please contact Administrator. ***");
          con.close();
        } finally {
          try {
            if (commEvent != null) commEvent = null;
            if (journalEvent != null) journalEvent = null;
            if (con != null) con.close();
            System.exit(0);
          } catch (Exception e) {
            recordError(e, "addComment");
            log.FmtAndLogMsg("*** All offer expired updates are rollback from last run. Please contact Administrator. ***");
          }
        }
      }
    }


  /***************************************************************/
  /*               Add journals                                 */
  /***************************************************************/
    private static void addJournal(long request_id,  String user_id) throws Exception  {
      try {
        //Add journal
        journalEvent.addJournal((Long.valueOf(request_id)).intValue(),23,"Offer Expired",user_id);
		
		if(appLockParam == 1) { 
		journalEvent.addJournal((Long.valueOf(request_id)).intValue(),109,"App Locked by Expired Offer",user_id);				
		}
		
      } catch (Exception ex) {
        try {
          con.rollback();
          recordError(ex, "addJournal");
          log.FmtAndLogMsg("*** All expired offer updates are rollback from last run. Please contact Administrator. ***");
          con.close();
        } finally {
          try {
            if (commEvent != null) commEvent = null;
            if (journalEvent != null) journalEvent = null;
            if (con != null) con.close();
            System.exit(0);
          } catch (Exception e) {
            recordError(e, "addJournal");
            log.FmtAndLogMsg("*** All expired offer updates are rollback from last run. Please contact Administrator. ***");
          }
        }
      }
    }


  /***************************************************************/
  /*               Date formatter                                */
 /***************************************************************/
  public static String getDateTimeStr(Timestamp stamp, String formatString) {

      if (stamp==null) return "";
      String dateStr = null;
      Locale curLocale = Locale.getDefault();
      java.util.Date date = (java.util.Date)stamp;

      if(curLocale.equals(Locale.US))
      {
         SimpleDateFormat formatter = new SimpleDateFormat(formatString, curLocale);
         dateStr = formatter.format(date);
      }else
      {
          DateFormat formatter = DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.MEDIUM, curLocale);
          dateStr = formatter.format(date);
      }

      return dateStr;
    }
	
  /************************************************************************/
  /* Sets HMDA Activity and Alert if the app in question is HMDA eligible */	
  /************************************************************************/
  public static void setHMDA(long request_id, int product_id) throws Exception {
	PreparedStatement ps = null, ps2 = null, ps3 = null, ps4 = null, ps5 = null, ps6 = null, ps7 = null;
	PreparedStatement pstmt = null;
	ResultSet rs = null, rs2 = null, rs3 = null, rs4 = null, rs5 = null, rs6 = null, rs7 = null;
	Statement update_stmt = null;
	Statement update_stmt2 = null;
	Statement update_stmt3 = null;
	int action = 0; 
	String action_date = null; 
	boolean complete_activity = true;
	boolean denial_exists = false;
	String sql2;
	String sql3;
	String sql4;
	String sql5;
	String sql6 = null;
	String sql7;
	String update_sql;
	String update_sql2;
	String update_sql3;
	
	// since hmda isn't home equity specific anymore, we must get program from another table depending on product
	int program_id = -1;
	try {
		if (product_id == 16 || product_id == 17) {
			sql7 = "SELECT program_id from credit_request_home_loan where request_id = ?";
		}
		else if (product_id == 22) {
			sql7 = "SELECT nvl(program_id,-1) as program_id from credit_request_credit_card where request_id = ?";
		}
		else {
			sql7 = "SELECT nvl(program_id,-1) as program_id from credit_request_loan where request_id = ?";
		}
		
		ps7 = con.prepareStatement(sql7);
		ps7.setLong(1, request_id);
		rs7 = ps7.executeQuery();
		
		if (rs7.next())
			program_id = rs7.getInt(1);
	} catch (Exception e) {
	   e.printStackTrace();
	}
	finally {
		try{ if(rs7 != null) rs7.close(); }catch(Exception e1){e1.printStackTrace();}
		try{ if(ps7 != null) ps7.close(); }catch(Exception e1){e1.printStackTrace();}
	}	

	// retrieve hmda eligibility and if app qualifies, then check completeness	
	String sql = "SELECT nvl(clp.hmda_eligible_flg,0)+nvl(cpp.hmda_eligible_flg,1)-1 as hmda_eligible_flg "+
				 "FROM config_loan_purpose clp, config_product_program cpp, credit_request cr "+
				 "WHERE	clp.evaluator_id = cr.evaluator_id AND clp.product_id = cr.product_id AND clp.loan_purpose_id = cr.loan_purpose_id "+
				 "AND clp.evaluator_id = cpp.evaluator_id (+) AND clp.product_id = cpp.product_id (+) "+
				 "AND cpp.program_id (+) = ? AND cr.request_id = ?";
    try { 
		//Prepare statement to execute
		ps = con.prepareStatement(sql);
		ps.setInt(1, program_id);
		ps.setLong(2, request_id);
		//Execute statement
		rs = ps.executeQuery();

	// if app is hmda eligible, select data and check for completeness
		if (rs.next() && rs.getInt("hmda_eligible_flg") == 1) {
		    try {	
				// first, check requestor hmda items for completeness
				sql2 =	"SELECT	rh.requestor_type_id, rh.requestor_id, rhmda.gender_id, "+
						"rhmda.ethnicity_id, nvl(rhmda.race_bmsk,0) as race_bmsk "+
						"FROM requestor_header rh, requestor_hmda rhmda "+
						"WHERE rh.request_id = ? "+
						"AND rh.request_id = rhmda.request_id (+) "+
						"AND rh.requestor_id = rhmda.requestor_id (+) "+
						"ORDER BY rh.requestor_type_id, rh.requestor_id";
			
				ps2 = con.prepareStatement(sql2);
				
				ps2.setLong(1, request_id);

				rs2 = ps2.executeQuery();

				while(rs2.next()) {
					if(rs2.getObject("gender_id") == null || rs2.getObject("ethnicity_id") == null || rs2.getObject("race_bmsk") == null)
						complete_activity = false;
				}
			} catch (Exception e) {
			   e.printStackTrace();
			}
			finally {
				try{ if(rs2 != null) rs2.close(); }catch(Exception e1){e1.printStackTrace();}
				try{ if(ps2 != null) ps2.close(); }catch(Exception e1){e1.printStackTrace();}
			}
			
			try {
				sql3 = 	"SELECT crh.preapproval_id, nvl(cr.booking_status_id,0) as booking_status_id, nvl(crh.purchaser_id,0) as purchaser_id, "+
						"nvl(cr.app_status_id,0) as app_status_id, crh.purpose_id, crh.lien_status_id, crh.property_type_id, crh.hoepa_flg, "+
						"crh.rate_spread_num, crh.loan_type_id, crh.occupancy_id, crh.gross_income_num, to_char(crh.purchaser_dt,'DD-MON-YYYY HH24:MI:SS') as purchaser_dt, to_char(cr.booking_dt,'DD-MON-YYYY HH24:MI:SS') as booking_dt "+
						"FROM credit_request_hmda crh, credit_request cr "+
						"WHERE cr.request_id = ? "+
						"AND cr.request_id = crh.request_id (+) "+
						"ORDER BY crh.home_equity_id";
						
				ps3 = con.prepareStatement(sql3);
				
				ps3.setLong(1, request_id);
			
				rs3 = ps3.executeQuery();		
				
				sql4 = 	"SELECT decision_ref_id, decision_id, evaluator_id "+
						"FROM credit_req_decisions_evaluator "+
						"WHERE decision_ref_id = (SELECT max(decision_ref_id) FROM credit_req_decisions_evaluator where request_id = ? AND Decision_category_id IN (1,2,3))";
						
				ps4 = con.prepareStatement(sql4);
				
				ps4.setLong(1, request_id);

				rs4 = ps4.executeQuery();	

				// check hmda values and latest decision, if there are no records, then cannot complete activity
				if (rs3.next() && rs4.next()) {
					// set actions

					if (rs3.getInt("preapproval_id") == 1 && (rs4.getInt("decision_id") == 3 || rs4.getInt("decision_id") == 102) && (rs3.getInt("booking_status_id") == 4 || rs3.getInt("booking_status_id") == 5)) {
						action = 8;
						
						sql6 = "SELECT to_char(audit_last_updated_dt,'DD-MON-YYYY HH24:MI:SS') as audit_last_updated_dt "+
							   "FROM credit_request_activity "+
							   "WHERE request_id = ? AND activity_id = 23";
						
						ps6 = con.prepareStatement(sql6);
				
						ps6.setLong(1, request_id);

						rs6 = ps6.executeQuery();
						
						if (rs6.next())
							action_date = rs6.getString(1);	 
							
						try {rs6.close();} catch (Exception e1) {}
						try {ps6.close();} catch (Exception e1) {}	 

					}	
					else if (rs3.getInt("preapproval_id") == 1 && ((rs4.getInt("decision_id") == 2 || rs4.getInt("decision_id") == 103) || (rs4.getInt("decision_id") == 1 && (rs3.getInt("booking_status_id") == 4 || rs3.getInt("booking_status_id") == 5))) ) {
						action = 7;
						
						if (rs4.getInt("decision_id") == 2 || rs4.getInt("decision_id") == 103) {
							sql6 = "SELECT to_char(received_dt,'DD-MON-YYYY HH24:MI:SS') as received_dt "+
								   "FROM credit_req_decisions_evaluator "+
								   "WHERE decision_ref_id = ?";
		 
							ps6 = con.prepareStatement(sql6);

							ps6.setInt(1, rs4.getInt("decision_ref_id"));	   
						}
						else {
							sql6 = "SELECT to_char(audit_last_updated_dt,'DD-MON-YYYY HH24:MI:SS') as audit_last_updated_dt "+
								   "FROM credit_request_activity "+
								   "WHERE request_id = ? AND activity_id = 23";

							ps6 = con.prepareStatement(sql6);

							ps6.setLong(1, request_id);
						}

						rs6 = ps6.executeQuery();
						
						if (rs6.next())
							action_date = rs6.getString(1);	 
							
						try {rs6.close();} catch (Exception e1) {}
						try {ps6.close();} catch (Exception e1) {}

					}	
					else if (rs3.getInt("purchaser_id") != 0) {
						action = 6;
						action_date = rs3.getString("purchaser_dt");
					}	
					else if (rs3.getInt("app_status_id") == 19 && (rs4.getInt("decision_id") == 1 || rs4.getInt("decision_id") == 2 || rs4.getInt("decision_id") == 3 || rs4.getInt("decision_id") == 102 || rs4.getInt("decision_id") == 103))	{
						action = 4;
						
						sql6 = "SELECT 	to_char(journal_dt,'DD-MON-YYYY HH24:MI:SS') as journal_dt "+
							   "FROM credit_request_journal "+
							   "WHERE request_id = ? AND journal_event_id = 22";

						ps6 = con.prepareStatement(sql6);
				
						ps6.setLong(1, request_id);
				
						rs6 = ps6.executeQuery();

						if (rs6.next())
							action_date = rs6.getString(1);	 
							
						try {rs6.close();} catch (Exception e1) {}
						try {ps6.close();} catch (Exception e1) {}
					}	
					// we cannot implement this logic until we can tell the difference between system and manual withdraw
					/*else if (rs3.getInt("app_status_id") == 19) {
						action = 5;
						sql6 = "SELECT 	to_char(journal_dt,'DD-MON-YYYY HH24:MI:SS') as journal_dt "+
							   "FROM credit_request_journal "+
							   "WHERE request_id = ? AND journal_event_id = 23";
						
						ps6 = con.prepareStatement(sql6);
				
						ps6.setLong(1, request_id);
				
						rs6 = ps6.executeQuery();
					
						if (rs6.next())
							action_date = rs6.getString(1);	 
							
						try {rs6.close();} catch (Exception e1) {}
						try {ps6.close();} catch (Exception e1) {}
					}*/
					else if (((rs3.getInt("preapproval_id") == 2 || rs3.getInt("preapproval_id") == 3) && (rs4.getInt("decision_id") == 2 || rs4.getInt("decision_id") == 103)) || (rs4.getInt("decision_id") == 1 && (rs3.getInt("booking_status_id") == 4 || rs3.getInt("booking_status_id") == 5))) {
						action = 3;

						if (rs4.getInt("decision_id") == 2 || rs4.getInt("decision_id") == 103) {
							sql6 = "SELECT to_char(received_dt,'DD-MON-YYYY HH24:MI:SS') as received_dt "+
								   "FROM credit_req_decisions_evaluator "+
								   "WHERE decision_ref_id = ?";
								   
							ps6 = con.prepareStatement(sql6);
				
							ps6.setInt(1, rs4.getInt("decision_ref_id"));	
						}
						else if (rs3.getInt("app_status_id") == 19) {
							sql6 = "SELECT 	to_char(journal_dt,'DD-MON-YYYY HH24:MI:SS') as journal_dt "+
								   "FROM credit_request_journal "+
								   "WHERE request_id = ? AND journal_event_id = 22";
						
							ps6 = con.prepareStatement(sql6);
				
							ps6.setLong(1, request_id);
						}
						else if (rs3.getInt("app_status_id") == 20) {
							sql6 = "SELECT 	to_char(journal_dt,'DD-MON-YYYY HH24:MI:SS') as journal_dt "+
								   "FROM credit_request_journal "+
								   "WHERE request_id = ? AND journal_event_id = 23";
						
							ps6 = con.prepareStatement(sql6);
				
							ps6.setLong(1, request_id);
						}
						else {
							sql6 = "SELECT to_char(audit_last_updated_dt,'DD-MON-YYYY HH24:MI:SS') as audit_last_updated_dt "+
								   "FROM credit_request_activity "+
								   "WHERE request_id = ? AND activity_id = 23";

							ps6 = con.prepareStatement(sql6);
				
							ps6.setLong(1, request_id);
						}
				
						rs6 = ps6.executeQuery();

						if (rs6.next())
							action_date = rs6.getString(1);	 
							
						try {rs6.close();} catch (Exception e1) {}
						try {ps6.close();} catch (Exception e1) {}
					}	
					else if ((rs4.getInt("decision_id") == 3 || rs4.getInt("decision_id") == 102) && (rs3.getInt("preapproval_id") == 2 || rs3.getInt("preapproval_id") == 3) && (rs3.getInt("booking_status_id") == 4 || rs3.getInt("booking_status_id") == 5)) {
						action = 2;
						action_date = rs3.getString("booking_dt");	 
					}	
					else if (rs3.getInt("booking_status_id") == 2 || rs3.getInt("booking_status_id") == 3) {
						action = 1;
						
						if (product_id == 16 || product_id == 17) {
							sql6 = "SELECT to_char(audit_last_updated_dt,'DD-MON-YYYY HH24:MI:SS') as audit_last_updated_dt "+
								   "FROM credit_request_activity "+
								   "WHERE request_id = ? AND activity_id = 36";
						}
						else {
							sql6 = "SELECT to_char(contract_dt, 'DD-MON-YYYY HH24:MI:SS') as audit_last_updated_dt "+
								   "FROM credit_req_contract "+
								   "WHERE request_id = ?";
						}

						ps6 = con.prepareStatement(sql6);
				
						ps6.setLong(1, request_id);
				
						rs6 = ps6.executeQuery();

						if (rs6.next())
							action_date = rs6.getString(1);	 
								
						try {rs6.close();} catch (Exception e1) {}
						try {ps6.close();} catch (Exception e1) {}	
						
						if (action_date.length() == 0) {
							sql6 = "SELECT to_char(received_dt,'DD-MON-YYYY HH24:MI:SS') as received_dt "+
								   "FROM credit_req_decisions_evaluator "+
								   "WHERE decision_ref_id = ?";
								   
							ps6 = con.prepareStatement(sql6);
				
							ps6.setInt(1, rs4.getInt("decision_ref_id"));
							
							rs6 = ps6.executeQuery();

							if (rs6.next())
								action_date = rs6.getString(1);	 
									
							try {rs6.close();} catch (Exception e1) {}
							try {ps6.close();} catch (Exception e1) {}	
						}
					}	

					// default case, if action date still isn't populated, use booking_dt	
					if (action_date == null && (action == 3 || action == 7 || action == 8)) {
						sql6 = 	"SELECT to_char(booking_dt,'DD-MON-YYYY HH24:MI:SS') as booking_dt "+
								"FROM credit_request "+
								"WHERE request_id = ?";
								   
							ps6 = con.prepareStatement(sql6);
				
							ps6.setLong(1, request_id);

							rs6 = ps6.executeQuery();
				
							if (rs6.next())
								action_date = rs6.getString(1);	 
									
							try {rs6.close();} catch (Exception e1) {}
							try {ps6.close();} catch (Exception e1) {}	

					}	

					// absolute last ditch effort...still no action date, set it to NOW
					if (action_date == null && action != 0) {
						sql6 = 	"SELECT to_char(sysdate,'DD-MON-YYYY HH24:MI:SS') "+
								"FROM dual";
								   
							ps6 = con.prepareStatement(sql6);
						
							rs6 = ps6.executeQuery();
				
							if (rs6.next())
								action_date = rs6.getString(1);	 
									
							try {rs6.close();} catch (Exception e1) {}
							try {ps6.close();} catch (Exception e1) {}	
							
							log.FmtAndLogMsg("hmda action date was still null, although it had an action.  therefore default date to sysdate.");

					}	

					// if an action was found, then update the hmda record with it	
					if (action != 0) {
					try {
						update_sql3 = "update credit_request_hmda "+
									  "set action_id = ?, "+
									  "action_dt = to_date(?,'DD-MON-YYYY HH24:MI:SS') "+
									  "where request_id = ?";
						 pstmt = con.prepareStatement(update_sql3);
						 pstmt.setInt(1, action);
						 pstmt.setString(2, action_date);
						 pstmt.setLong(3, request_id);
						 pstmt.executeQuery();
						 pstmt.close();							  
									  
					}
					 catch (Exception e) {
						e.printStackTrace();
					}
					finally {
						try{if(pstmt !=null) pstmt.close();} catch(Exception ex) {ex.printStackTrace();}
					}			
						/*
						update_sql3 = "update credit_request_hmda "+
									  "set action_id = "+action+", "+
									  "action_dt = to_date('"+action_date+"','DD-MON-YYYY HH24:MI:SS') "+
									  "where request_id = "+request_id;

						update_stmt3 = con.createStatement();
						update_stmt3.executeUpdate(update_sql3);
						try {update_stmt3.close();} catch (Exception e1) {}	
						*/
					}

					// if this is a denial action, then require reasons	
					if (action == 7 || action == 3) {
						
						sql5 = 	"SELECT mhrc.hmda_reason_description_txt "+
								"FROM config_decision_reasons cdr, credit_req_decision_reasons crdr, mstr_hmda_reason_codes mhrc "+
								"WHERE cdr.evaluator_id = ? AND cdr.evaluator_id = crdr.evaluator_id "+
								"AND crdr.reason_type_id = 1 "+
								"AND cdr.reason_id = crdr.reason_id AND	cdr.reason_type_id = crdr.reason_type_id "+
								"AND crdr.decision_ref_id = ? AND cdr.hmda_reason_id = mhrc.hmda_reason_id";
				
						ps5 = con.prepareStatement(sql5);
				
						ps5.setInt(1, rs4.getInt("evaluator_id"));
						ps5.setInt(2, rs4.getInt("decision_ref_id"));
						
						rs5 = ps5.executeQuery();
			
						if(rs5.next())
							denial_exists = true;	
					
						try {rs5.close();} catch (Exception e1) {}
						try {ps5.close();} catch (Exception e1) {}
					}	
					
					// check hmda requirements here
					if(rs3.getObject("purchaser_id") == null || rs3.getObject("hoepa_flg") == null || rs3.getObject("gross_income_num") == null || rs3.getObject("preapproval_id") == null ||  rs3.getObject("purpose_id") == null || rs3.getObject("lien_status_id") == null || rs3.getObject("loan_type_id") == null || rs3.getObject("property_type_id") == null || rs3.getObject("occupancy_id") == null || ((rs3.getInt("booking_status_id") == 2 || rs3.getInt("booking_status_id") == 3) && rs3.getObject("rate_spread_num") == null) || action == 0)
						complete_activity = false;
					else if ((action == 7 || action == 3) && denial_exists == false)
						complete_activity = false;	
				}
				else
					complete_activity = false;
			} catch (Exception e) {
			   e.printStackTrace();
			}
			finally {
				try{ if(rs3 != null) rs3.close(); }catch(Exception e1){e1.printStackTrace();}
				try{ if(ps3 != null) ps3.close(); }catch(Exception e1){e1.printStackTrace();}
				try{ if(rs4 != null) rs4.close(); }catch(Exception e1){e1.printStackTrace();}
				try{ if(ps4 != null) ps4.close(); }catch(Exception e1){e1.printStackTrace();}
			}

			
			if (complete_activity == true) {
				try {
					update_sql = "update credit_request_activity "+
							 "set activity_status_id = 3, audit_updated_user_id = 'SYSTEM', audit_last_updated_dt = sysdate "+
							 "where request_id=? and task_group_id='SYSTEM' and activity_id = 26";
					 pstmt = con.prepareStatement(update_sql);
					 pstmt.setLong(1, request_id);
					 pstmt.executeQuery();
					 pstmt.close();							  
								  
				}
				 catch (Exception e) {
					e.printStackTrace();
				}
				finally {
					try{if(pstmt !=null) pstmt.close();} catch(Exception ex) {ex.printStackTrace();}
				}		
							 
				/*update_stmt = con.createStatement();
				update_stmt.executeUpdate(update_sql);
				try {update_stmt.close();} catch (Exception e1) {}
				*/
				try {
					update_sql2 = "UPDATE credit_request_alerts "+
							  "SET status_txt = 'closed', close_dt = sysdate "+
							  "WHERE request_id = ? and alert_type_id = 9";
					 pstmt = con.prepareStatement(update_sql2);
					 pstmt.setLong(1, request_id);
					 pstmt.executeQuery();
					 pstmt.close();							  
								  
				}
				 catch (Exception e) {
					e.printStackTrace();
				}
				finally {
					try{if(pstmt !=null) pstmt.close();} catch(Exception ex) {ex.printStackTrace();}
				}
				/*update_stmt2 = con.createStatement();
				update_stmt2.executeUpdate(update_sql2);
				try {update_stmt2.close();} catch (Exception e1) {}
				*/
			}
			else {
				// set hmda activity incomplete			
				try {
					update_sql = "update credit_request_activity "+
							 "set activity_status_id = 1, audit_updated_user_id = 'SYSTEM', audit_last_updated_dt = sysdate "+
							 "where request_id=? and task_group_id='SYSTEM' and activity_id = 26";
					 pstmt = con.prepareStatement(update_sql);
					 pstmt.setLong(1, request_id);
					 pstmt.executeQuery();
					 pstmt.close();							  
								  
				}
				 catch (Exception e) {
					e.printStackTrace();
				}
				finally {
					try{if(pstmt !=null) pstmt.close();} catch(Exception ex) {ex.printStackTrace();}
				}
				
				/*update_stmt = con.createStatement();
				update_stmt.executeUpdate(update_sql);
				try {update_stmt.close();} catch (Exception e1) {}
				*/			
				try {
					update_sql2 = "MERGE INTO credit_request_alerts cra "+
							  "USING (select ? as request_id from dual) d "+
							  "ON (cra.request_id = d.request_id AND cra.alert_type_id = 9) "+
							  "WHEN MATCHED THEN UPDATE "+
							  "SET status_txt = 'open' "+
							  "WHEN NOT MATCHED THEN INSERT "+
							  "(request_id, seq_id,	alert_type_id, status_txt, open_dt,	close_dt, detail_txt) "+
							  "VALUES (?,(select nvl(max(seq_id),0)+1 from credit_request_alerts where request_id = ?), "+
							  "9,'open',sysdate,null,'HMDA Incomplete')";
					 pstmt = con.prepareStatement(update_sql2);
					 pstmt.setLong(1, request_id);
					 pstmt.setLong(2, request_id);
					 pstmt.setLong(3, request_id);
					 pstmt.executeQuery();
					 pstmt.close();
				}
				 catch (Exception e) {
					e.printStackTrace();
				}
				finally {
					try{if(pstmt !=null) pstmt.close();} catch(Exception ex) {ex.printStackTrace();}
				}
				/*update_stmt2 = con.createStatement();
				update_stmt2.executeUpdate(update_sql2);
				try {update_stmt2.close();} catch (Exception e1) {}*/
			}
		} 
    } catch (Exception e) {
	   e.printStackTrace();
	}
	finally {
		try{ if(rs != null) rs.close(); }catch(Exception e1){e1.printStackTrace();}
		try{ if(ps != null) ps.close(); }catch(Exception e1){e1.printStackTrace();}
	}    
  }

}