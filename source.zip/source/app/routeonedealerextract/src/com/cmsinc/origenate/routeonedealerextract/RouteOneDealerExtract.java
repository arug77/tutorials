/* Filename: RouteOneDealerExtract.java
 * Version: 
 * Creation Date: September 01, 2005
 * Author: Gautam Anand
 * Copyright (c) 2002. All rights reserved
 * Description: Refer Clientele #134775
 * This program would generate a dealer data extract for RouteOne
 * and save the data in a CSV format and ftp the file every night.
 */

package com.cmsinc.origenate.routeonedealerextract;

import com.cmsinc.origenate.util.*;
import com.cmsinc.origenate.crypto.*;
import java.io.*;
import java.net.*;
import java.security.SecureRandom;
import java.security.cert.X509Certificate;
import java.sql.Date;
import java.sql.*;
import java.util.*;
import javax.net.ssl.*;
import sun.net.TelnetOutputStream;
import sun.net.ftp.FtpClient;
import com.cmsinc.origenate.util.OWASPSecurity;

public class RouteOneDealerExtract {

	private static LogMsg log = new LogMsg(); // log

	private static RouteOneDealerExtract r1 = new RouteOneDealerExtract();

	private static String evaluator_id; // evaluator_id from commandline

	private static String destinationURL;

	private static String cleanupDays;
	
	private static Connection con; // db settings

	private static String ftpServer; // ftp settings

	private static String ftpUser; // ftp settings

	private static String ftpPass; // ftp settings

	private static String ftpDecPass; // ftp Decrypted Password
	
	private static String ftpDir; // ftp settings

	private static String routeoneFinanceId; // RouteOne FinanceSourceID

	/*Preferred File Transmission Mech. FTP/HTTP*/
	private static String fileTransmission = "FTP"; 

	private static boolean performFileDelete =false;
	
	private static String input_filename; // input filename.

	private static String header_filename; // header filename

	private static String finance_src_name; // Finance Source Name

	private static String header_file_data; // header file content

	private static String localfile_path;

	private static String s_iniFile;

	// private static String path = "C:\\temp\\";

	private static String header_filelocation;

	private static String input_filelocation;
	
	private static boolean encryption_flg = false;

	/*Vector to hold dealer data extract fields*/
	private static Vector v = new Vector(300,100); 
	
	/*Vector to hold the command line args*/
	private static Vector cmdargs = new Vector(10,10);	

	/**/
	private static String transmissionOptional;
	
	/*whether FTP should be performed*/
	private static boolean performFTP = true; 

	/*number of records in CSV input file*/
	private static int recordCount; 

	private PrintWriter dataFile = null;

	private static Character ch;
	
	private boolean append = true;

	/*whether FTP or HTTP file*/
	private static String FTPorHTTP; 
	
	/* whether to exclude AppOne sources */
	private static boolean excludeAppOne = false; 
	
	/* whether to exclude TX dealers */
	private static boolean exclTXDlr = false; 
	
	/* whether to use the other lender id for Indpendent Bank and extract TX dealers only */
	private static boolean secIndBankId = false; 

	private static final int MAX_BUFFER_SIZE = 1 * 1024 * 1024;
   	//private static final String NEWLINE = System.getProperty("line.separator");
	private static final String NEWLINE = "\r\n";
	private static final String FORM_BOUNDARY = "---------------------------7d2e2c76e104be";

	private static IniFile ini = new IniFile();

	/*
	 * Main method to call the getDBConnection method, getDataExtract method and
	 * retreive the command line parameters like evaluator id,
	 * ini file locn, file transmission mech.
	 */
	public static void main(String[] args) {

		String s_log_file = "";
		if (args.length > 0) {
			for (int i = 0; i < args.length; ++i) {
				if ((args[i].charAt(0) != '-') && (args[i].length() > 1)) {
					showUsageAndExit();
				}
				ch = Character.valueOf(args[i].charAt(1));
				cmdargs.add(ch);
				switch (args[i].charAt(1)) {
				case 'i':
					s_iniFile = args[i].substring(2); // ini file
					try {
						ini.readINIFile(s_iniFile);
						s_log_file = ini.getINIVar(
								"logs.ROdealer_extract_log_file", "");
						if (s_log_file.length() > 0) {
							log.openLogFile(s_log_file);
						}
						
						if(Integer.parseInt(ini.getINIVar("encryption.encryption_flg","0")) == 1) {
							encryption_flg = true;
						}
					} catch (Exception e) {
						log.FmtAndLogMsg("Caught exception reading ini file '"
								+ s_iniFile + "':" + e.toString());
					}
					log.FmtAndLogMsg("\r");
					log.FmtAndLogMsg("Starting RouteOne Dealer Extract Tool");
					log.FmtAndLogMsg("\r");
					log.FmtAndLogMsg("iniFile name: " + s_iniFile);
					break;
				case 'e':
					evaluator_id = args[i].substring(2); // evaluator id
					log.FmtAndLogMsg("evaluator id : " + evaluator_id);
					break;
				case 'l':
					localfile_path = args[i].substring(2); // location of input
															// and header files
															// on local machine
					log
							.FmtAndLogMsg("local location of the input & header files: "
									+ localfile_path);
					break;
				case 'd':
					ftpDir = args[i].substring(2); // directory location on ftp
													// server where file needs
													// to be sent
					log.FmtAndLogMsg("ftp server directory: " + ftpDir);
					break;
				case 'f':
					fileTransmission = args[i].substring(2); // file
																// transmission
																// method
					log.FmtAndLogMsg("file transmission method: "
							+ fileTransmission);
					break;
				case 'u':
					destinationURL = args[i].substring(2); // web server URL
					log.FmtAndLogMsg("web server URL: " + destinationURL);
					break;
				case 'n':
					cleanupDays = args[i].substring(2);
					log.FmtAndLogMsg("Number of days to keep the files" + cleanupDays);
					break;
				case 't':
					transmissionOptional = args[i].substring(2);
					log.FmtAndLogMsg("Do you want to transmit the file electronically: " + transmissionOptional);
					break;
				case 'a':
					excludeAppOne = ((args[i].substring(2).equalsIgnoreCase("yes"))?true:false);
					log.FmtAndLogMsg("Do you want to exclude AppOne sources: " + excludeAppOne);
					break;
				case 'x':
					exclTXDlr = ((args[i].substring(2).equalsIgnoreCase("yes"))?true:false);
					log.FmtAndLogMsg("Do you want to exclude TX dealers (for Independent Bank only): " + exclTXDlr);
					break;
				case 'z':
					secIndBankId = ((args[i].substring(2).equalsIgnoreCase("yes"))?true:false);
					log.FmtAndLogMsg("Do you want to use Independent Bank's secondary lender id and extract TX dealers only (for Independent Bank only): " + secIndBankId);
					break;
				default:
					log.FmtAndLogMsg("Unknown parameter: " + args[i]);
					showUsageAndExit();
					break;
				}
			}
		}
		
		 /* Check if the required command line args are present*/
		try {
			log.FmtAndLogMsg("********Calling checkCmdLineArgs Method********");
			checkCmdLineArgs();
		} catch (Exception e) {
			log.FmtAndLogMsg("Error in checkCmdLineArgs method of : "
					+ e.toString());
		}
		log.FmtAndLogMsg("********checkCmdLineArgs Method Completed********");

		if(transmissionOptional.equalsIgnoreCase("no")) {
			performFTP = false;
			performFileDelete = true;
		}
			
		if (fileTransmission.equalsIgnoreCase("FTP"))
			FTPorHTTP = "FTP";
		else if (fileTransmission.equalsIgnoreCase("HTTP"))
			FTPorHTTP = "HTTP";
		else if (fileTransmission.equals("HTTPS"))
			FTPorHTTP = "HTTPS";
		
		log.FmtAndLogMsg("File Transmission : " + FTPorHTTP);

		try {
			log.FmtAndLogMsg("********Calling getDBConnection Method********");
			getDBConnection(s_log_file);
		} catch (Exception e) {
			log.FmtAndLogMsg("Error in getDBConnection method of : "
					+ e.toString());
		}
		log.FmtAndLogMsg("********getDBConnection Method Completed********");
		try {
			if(fileTransmission.equals("FTP") && performFTP) {
				log.FmtAndLogMsg("********Calling getFTPSettings Method********");
				getFTPSettings(evaluator_id);
			}
		} catch (Exception e) {
			log.FmtAndLogMsg("Error in getFTPSettings method of : "
					+ e.toString());
		}
		if(fileTransmission.equals("FTP") && performFTP)
			log.FmtAndLogMsg("********getFTPSettings Method Completed********");
		try {
			log
					.FmtAndLogMsg("********Calling getRouteOneSourceFinanceID Method********");
					
			if(evaluator_id.trim().equals("129") && secIndBankId) {
			routeoneFinanceId = "F0CM23";
			finance_src_name = "Independent Dealer Services";
			} else { 
			routeoneFinanceId = getRouteOneSourceFinanceID(evaluator_id);}
		} catch (Exception e) {
			log.FmtAndLogMsg("Error in getRouteOneSourceFinanceID method of : "
					+ e.toString());
		}
		log
				.FmtAndLogMsg("********getRouteOneSourceFinanceID Method Completed********");

		log.FmtAndLogMsg("********Calling getFileName Method********");
		input_filename = getFileName("Input", routeoneFinanceId);
		header_filename = getFileName("Header", routeoneFinanceId);

		log.FmtAndLogMsg("********getFileName Method Completed********");

		try {
			log.FmtAndLogMsg("********Calling getDataExtract Method********");
			getDataExtract(evaluator_id, routeoneFinanceId);
		} catch (Exception e) {
			log.FmtAndLogMsg("Error in getDataExtract method of : "
					+ e.toString());
		}
		log.FmtAndLogMsg("********getDataExtract Method Completed********");
		log.FmtAndLogMsg("********RouteOne DealerExtract Tool Completed********");
	}

	/*
	 * Method to inform that expected values are missing on the command line.
	 */

	public static void showUsageAndExit() {
		System.out
		.println("Usage: java com.cmsinc.origenate.routeonedealerextract.RouteOneDealerExtract");
		System.out
		.println("-e<evaluator id> -i<ini file> -f<file transmission> -u<web server url> -l<localfile location> -d<ftp directory> -n<Cleanup Days> -t<Transmission Optional> -a<Exclude AppOne>");
		System.out
				.println("------------------------------------------------------------------------------");
		System.out.println("Parameter	Data Type	Required/Optional			Description");
		System.out.println("  -e 		 Integer		Required		Evaluator ID");
		System.out.println("  -i 		 String			Required		ini file name including the location");
		System.out.println("  -f 		 String			Optional		File Transmission Mechanism FTP/HTTP(S) FTP-Default");		
		System.out.println("  -u		 String 		Optional		Web Server URL if HTTP(S) method used");
		System.out.println("  -l		 String 		Required		location of input and header file on local machine");
		System.out.println("  -d		 String			Optional		FTP Directory to which the file needs to be FTP'ed");
		System.out.println("  -n 		 Integer		Required		Number of days to keep the files in local directory");
		System.out.println("  -t 		 String			Required		Do you want to electronically transmit the file or not; Yes/No");
		System.out.println("  -a 		 String			Optional		Do you want exclude AppOne sources; Yes/No (default No)");
		System.out.println("  -x 		 String			Optional		Do you want exclude TX dealers (for Independent Bank only); Yes/No (default No)");
		System.out.println("  -z 		 String			Optional		Do you want to use Independent Bank's secondary lender id and extract TX dealers only (for Independent Bank only) Yes/No (default No)");
		System.exit(0);
	}

	
	/*
	 * Method to report an error in a method. Mainly used in the getDataExtract
	 * method to report missing field values in the extract for required fields.
	 */

	public static void recordError(String methodName, Exception err)
			throws Exception {
		try {
			log.FmtAndLogMsg("Error occured in " + methodName + " method of : "
					+ err.toString());
			throw new Exception("Error occured in " + methodName
					+ " method of : " + err.toString());
		} catch (Exception e) {
			log
					.FmtAndLogMsg("Error in reportError method of : "
							+ e.toString());
		}

	}

	/*checks if the command line args are present*/
	
	public static void checkCmdLineArgs() {
		if(cmdargs.contains(Character.valueOf('i')) && cmdargs.contains(Character.valueOf('l')) && 
		   cmdargs.contains(Character.valueOf('e')) && cmdargs.contains(Character.valueOf('t'))&& 
		   cmdargs.contains(Character.valueOf('n'))) {
			log.FmtAndLogMsg("Required Command Line Parameters Present");
		}
		else {
			log.FmtAndLogMsg("Required Command Line Parameters Missing");
			log.FmtAndLogMsg("Calling showUsageAndExit() method to exit");
			showUsageAndExit();
		}
	}
	
	/* Gets the clause to exclude configured App1 dealers. This is a stripped down version of the selection query. */
	
	private static String getAppOneClause() {
		if(excludeAppOne) {
			return 	" AND eo.originator_code_txt NOT IN (" + 
					" SELECT DISTINCT eo2.originator_code_txt " + 
					"	 FROM    EVALUATOR_ORIGINATOR eo2, " + 
					"	 XREF_EVAL_ORIG_PRODUCT xeop2, config_xref_originator_source  cxos2, config_sources cs2 " + 
					"	 WHERE   eo2.evaluator_id  =  eo.evaluator_id " + // We use eo.evaluator_id from the outer query here to avoid using another bind variable
					"	 AND 	 eo2.evaluator_id  =  xeop2.evaluator_id " + 
					"	 AND	 eo2.ORIGINATOR_ID =	 xeop2.ORIGINATOR_ID " + 
					"	 AND 	 eo2.ORIGINATOR_TYPE_ID=1 " + 
					"	 AND 	 xeop2.product_id IN (1,2,7,8) " + 
					"	 AND     cs2.source_id = cxos2.source_id " + 
					"	 AND     eo2.active_flg = 1 " + 
					"	 AND     eo2.evaluator_id = cxos2.evaluator_id " + 
					"	 AND     eo2.originator_id = cxos2.originator_id " + 
					"	 AND     cxos2.active_flg = 1 " + 
					"	 AND     cs2.evaluator_id = eo2.evaluator_id " + 
					"	 AND     cs2.active_flg = 1 " + 
					"	 AND    UPPER(cs2.source_desc_txt) = 'APP1') ";
		}
		return "";
	}
	
	
	//129
		private static String getExclTXDlrClause() {
		if(evaluator_id.trim().equals("129") && exclTXDlr) {
			return 	" AND upper(oa.state_id) <> 'TX' ";
		}
		return "";
	}
	
	
		private static String getSecIndBankIdClause() {
		if(evaluator_id.trim().equals("129") && secIndBankId) {
		
			return 	" AND upper(oa.state_id) = 'TX' ";
		}
		return "";
	}
	
	/*get DB connection*/

	public static void getDBConnection(String s_log_file) throws Exception {

		try {
			// Get ini file values for DB connection

			String s_dbhost = ini.getINIVar("database.host").trim();
			log.FmtAndLogMsg("dbHost : " + s_dbhost);

			String s_dbport = ini.getINIVar("database.port").trim();
			log.FmtAndLogMsg("dbPort : " + s_dbport);

			String s_dbsid = ini.getINIVar("database.sid").trim();
			log.FmtAndLogMsg("dbSID : " + s_dbsid);

			String s_dbuser = ini.getINIVar("database.user").trim();
			log.FmtAndLogMsg("dbUser : " + s_dbuser);

			String s_dbpassword = ini.getINIVar("database.password").trim();
			
			String sTNSEntry = ini.getINIVar("database.TNSEntry");
			log.FmtAndLogMsg("TNSEntry : " + sTNSEntry);
			
			
			DBConnection DBConnect = new DBConnection();
			
			if (sTNSEntry == null) {
				con = DBConnect.getConnection(s_dbhost, s_dbsid, s_dbuser, s_dbpassword, s_log_file, s_dbport,"");
			} else {
				// use tns entry if available
				con = DBConnect.getConnectionTNS(sTNSEntry, s_dbuser,  s_dbpassword, s_log_file);
			}
		} catch (Exception e) {
			recordError("getDBConnection", e);
		}
	} // end getDBConnection method

	/*
	 * Method to obtain the ftp settings for FTP file transmission
	 */

	public static void getFTPSettings(String evaluator_id) throws Exception {
		PreparedStatement ps = null;
		ResultSet rs = null;
		String sql = "";

		try {

			/* Select ftp settings from the evaluator table */
			if (!evaluator_id.isEmpty()) {

				sql = " SELECT ROUTEONE_SERVERNAME_TXT,ROUTEONE_USERID_TXT,ROUTEONE_PSSWD_TXT"
						+ " FROM EVALUATOR" + " WHERE EVALUATOR_ID = ? "; // Preparing
																			// sql
																			// statement

				ps = con.prepareStatement(sql); // Prepare statement to execute

				ps.setInt(1, Integer.parseInt(evaluator_id)); // Set param
																// values
				rs = ps.executeQuery(); // Execute statement

				// Get value of ftp server,ftp userid and password.
				while (rs.next()) {
					ftpServer = rs.getString("ROUTEONE_SERVERNAME_TXT"); // FTP
																			// server
																			// name
					log.FmtAndLogMsg("ftpServer : " + ftpServer);
					ftpUser = rs.getString("ROUTEONE_USERID_TXT"); // FTP
																	// userid
					log.FmtAndLogMsg("ftpUser : " + ftpUser);
					ftpPass = rs.getString("ROUTEONE_PSSWD_TXT"); // FTP
					log.FmtAndLogMsg("********Calling getDecryptedPassword Method********");// password
					ftpPass = getDecryptedPassword(ftpPass);
					log.FmtAndLogMsg("********getDecryptedPassword Method Completed********");
				}
			}
			if (ftpServer == null || ftpUser == null || ftpPass == null) {
				log
						.FmtAndLogMsg("FTP Information Missing; The file would not be FTPed");
			}
		} catch (Exception e) {
			recordError("getFTPSettings", e);
		} finally {
			try {
				if (ps != null)
					ps.close();
				if (rs != null)
					rs.close();
			} catch (Exception e) {
				recordError("getFTPSettings", e);
			}
		} // end finally

	} // end getFTPSettings method.

	/*
	 * Method to decrypt the ftp password for FTP file transmission
	 */
	
	public static String getDecryptedPassword(String password) throws Exception {
		PreparedStatement ps = null;
		ResultSet rs = null;
		String sql = "";
		COLEncrypt col = new COLEncrypt();
		
		try {

			/* Select ftp settings from the evaluator table */
			if (!password.isEmpty()) {
				if(col.getEncryption_Flg().equals("1"))  { 
				// Pwd Encryption -  
					ftpDecPass = COLEncrypt.sCfgPwdDecrypt(password);
				
				System.out.println("password :  "+ password);
				} else {
					sql = " SELECT encrypt( ? ,'D') as e_psswd FROM dual "; // Preparing sql statement

					ps = con.prepareStatement(sql); // Prepare statement to execute
					ps.setString(1, password);

					rs = ps.executeQuery(); // Execute statement
					while (rs.next()) {
						ftpDecPass = rs.getString("e_psswd").trim(); // FTP
						log.FmtAndLogMsg("FTP Password Decrypted Successfully");
					}
				}			 
			}
			else {
				log.FmtAndLogMsg("FTP Server Password not present in database");
			}
		}	
		catch (Exception e) {
					recordError("getDecryptedPassword", e);
				} finally {
					try {
						if (ps != null)
							ps.close();
						if (rs != null)
							rs.close();
					} catch (Exception e) {
						recordError("getDecryptedPassword", e);
					}
				} // end finally
				return ftpDecPass;
	}
	
	/*
	 * Method to obtain the RouteOneSource FinanceID required to be part of the
	 * header and dataextract filename.
	 */

	public static String getRouteOneSourceFinanceID(String evaluator_id)
			throws Exception {
		PreparedStatement ps = null;
		ResultSet rs = null;
		String sql = "";
		try {

			/* Select RouteOne Finance Source Id from evaluator table. */
			sql = "SELECT Evaluator_Name_Txt,RouteOne_finance_source_txt"
					+ " FROM EVALUATOR" + " WHERE evaluator_id = ? ";

			ps = con.prepareStatement(sql); // Prepare statement to execute

			ps.setString(1, evaluator_id); // Set param values

			rs = ps.executeQuery(); // Execute statement

			if (rs.next()) {
				routeoneFinanceId = (rs
						.getString("RouteOne_finance_source_txt")).trim();
				log.FmtAndLogMsg("routeoneFinanceId : " + routeoneFinanceId);
				finance_src_name = (rs.getString("Evaluator_Name_Txt")).trim();
				log.FmtAndLogMsg("finance_src_name : " + finance_src_name);
			}

			if (routeoneFinanceId == null) {
				log.FmtAndLogMsg("RouteOneFinanceID not available");
			}
		} catch (Exception e) {
			recordError("getRouteOneSourceFinanceID", e);
		} finally {
			try {
				if (ps != null)
					ps.close();
				if (rs != null)
					rs.close();
			} catch (Exception e) {
				recordError("getRouteOneSourceFinanceID", e);
			}
		} // end finally
		return routeoneFinanceId;
	} // end getRouteOneSourceFinanceID method

	/*
	 * Method to create the dealer data extract and calling 
	 * getHeaderFileData and ftpfile methods and creating a
	 * CSV file of the data extract.
	 */

	public static void getDataExtract(String evaluator_id,
			String routeoneFinanceId) throws Exception {

		PreparedStatement ps = null;
		ResultSet rs = null;
		String sql = "";
		// declaring variables to hold the values of the data extract fields.
		String s_dealer_ac_no = "";
		String s_dealer_legal_name = "";
		String s_dba_name = "";
		String s_physical_addr_line1 = "";
		String s_physical_addr_line2 = "";
		String s_city = "";
		String s_state = "";
		String s_status = "";
		String s_contact_name = "";
		String s_brand_name = "";
		String s_fax_num = "";
		String s_dealer_tax_id = "";
		String s_contact_phone_num = "";
		String s_phone_num = "";
		String s_zipcode = "";
		String RouteOneFinId = "";
		String s_location = "";
		String newline = System.getProperty("line.separator");
		
		int i_status_flg;
		recordCount = 0;
		/*
		 * creating a DataExtract File object to open the CSV file for writing
		 * the field values
		 */
		r1.openCSVFile(input_filename);
		try {

			/*
			 * Select dealer extract from evaluator_originator and
			 * originator_address db tables.
			 */
			
			sql = " SELECT DISTINCT eo.originator_code_txt, "
			+ "                     eo.originator_name_txt, "
			+ "                     nvl(eo.dba_name_txt, eo.originator_name_txt) dba_name_txt,"
			+ "                     oa.address1_txt, "
			+ "                     oa.address2_txt, "
			+ "                     oa.city_txt, "
			+ "                     oa.state_id, "
			+ "                     oa.zipcode_txt,"
			+ "                     oa.phone_number_txt, "
			+ "                     eo.active_flg, "
			+ "                     eo.contact_txt, "
			+ "                     xeoc.comm_type_number_txt as fax_number_txt, "
			+ "                     eo.tax_id,"
			+ "                     eo.evaluator_id, "
			+ "                     e.evaluator_name_txt,"
			+ "                     cxos.source_id"
			+ " FROM    EVALUATOR_ORIGINATOR eo, ORIGINATOR_ADDRESS oa,XREF_EVAL_ORIG_PRODUCT xeop, config_xref_originator_source  cxos, evaluator e, config_sources cs, xref_eval_orig_comm_type xeoc"
			+ " WHERE   eo.evaluator_id  =  ?"
			+ " AND     eo.evaluator_id  =  oa.EVALUATOR_ID(+) "
			+ " AND     eo.ORIGINATOR_ID =  oa.ORIGINATOR_ID(+) "
			+ " AND 	 eo.evaluator_id  =  xeop.evaluator_id "
			+ " AND	 eo.ORIGINATOR_ID =	 xeop.ORIGINATOR_ID "
			+ " AND	 eo.evaluator_id = e.evaluator_id "
			+ " AND     oa.ADDRESS_TYPE_ID = 0 "
			+ " AND 	 eo.ORIGINATOR_TYPE_ID=1 " 
			+ " AND 	 xeop.product_id IN (1,2,7,8) "
			+ " AND     cs.source_id = cxos.source_id "			
			+ " AND     eo.active_flg = 1 "
			+ " AND     eo.evaluator_id = cxos.evaluator_id "
			+ " AND     eo.originator_id = cxos.originator_id " 
			+ " AND     cxos.active_flg = 1 "
			+ " AND     cs.evaluator_id = eo.evaluator_id "
			+ " AND     cs.active_flg = 1 "
			+ " AND    UPPER(cs.source_desc_txt) = 'RT1' "
			+ getAppOneClause() // If we want to exclude App1, then this will add a "not in" clause excluding any dealers configured for App1
			+ getExclTXDlrClause() // excludes TX dealers 
			+ getSecIndBankIdClause() // use seconday lender id for independent bank and extract TX dealers only
			+ "	AND xeoc.evaluator_id (+) = oa.evaluator_id "
			+ "	AND xeoc.originator_id (+) = oa.originator_id "
			+ "	AND xeoc.address_type_id (+) = oa.address_type_id "
			+ "	AND xeoc.comm_type_id (+) = 1 "
			+ "	AND xeoc.comm_id (+) = 1 "
			+ " ORDER BY eo.evaluator_id, originator_code_txt";
			
			ps = con.prepareStatement(sql); // Prepare statement to execute

			ps.setString(1, evaluator_id); // Set param values
			
			rs = ps.executeQuery(); // Execute statement

			RouteOneFinId = "\"" + routeoneFinanceId + "\"";
			
			while (rs.next()) {

				recordCount++;
				
			if(evaluator_id.trim().equals("129") && secIndBankId) {
			s_location = "Independent Dealer Services";
			} else {
				// location
				s_location = rs.getString("evaluator_name_txt");
				}
				if (s_location == null) {
					//log.FmtAndLogMsg("Location (evaluator name) value not present in the database");
					s_location = surroundWithQuotes("");
				} else {
					s_location = surroundWithQuotes(s_location.trim());
				}
				v.add(s_location);
				
				// Dealer Account Number(Required Field)
				s_dealer_ac_no = rs.getString("originator_code_txt");
				if (s_dealer_ac_no == null) {
					log.FmtAndLogMsg("Originator code value not present in the database");
					s_dealer_ac_no = surroundWithQuotes("");					
					performFTP = false;
				} else {
					s_dealer_ac_no = surroundWithQuotes(s_dealer_ac_no.trim());
				}
				v.add(s_dealer_ac_no);
				
				// Dealer Legal Name(Required Field)
				s_dealer_legal_name = rs.getString("originator_name_txt");
				if (s_dealer_legal_name == null) {
					log.FmtAndLogMsg("Dealer Legal Name value not present in the database");
					s_dealer_legal_name = surroundWithQuotes("");
					performFTP = false;
				} else {
					s_dealer_legal_name = surroundWithQuotes(s_dealer_legal_name.trim());
				}
				v.add(s_dealer_legal_name);
				
				// DBA Name(Required Field)
				s_dba_name = rs.getString("dba_name_txt");
				if (s_dba_name == null) {
					log
							.FmtAndLogMsg("DBA Name value not present in the database");
					s_dba_name = surroundWithQuotes("");
					performFTP = false;
				} else {
					s_dba_name = surroundWithQuotes(s_dba_name.trim());
				}
				v.add(s_dba_name);
				
				// Physical Address Line1(Required Field)
				s_physical_addr_line1 = rs.getString("address1_txt");
				if (s_physical_addr_line1 == null) {
					log
							.FmtAndLogMsg("Physical Address Line1 value not present in the database");
					s_physical_addr_line1 = surroundWithQuotes("");
					performFTP = false;
				} else {
					s_physical_addr_line1 = surroundWithQuotes(s_physical_addr_line1.trim());
				}
				v.add(s_physical_addr_line1);
				
				// Physical Address Line2(Optional Field)
				s_physical_addr_line2 = rs.getString("address2_txt");
				if (s_physical_addr_line2 == null) {
					s_physical_addr_line2 = surroundWithQuotes("");
					//log.FmtAndLogMsg("Optional Physical Address Line2 value not present in the database");
				} else {
					s_physical_addr_line2 = surroundWithQuotes(s_physical_addr_line2);
				}
				v.add(s_physical_addr_line2);
				
				// City(Required Field)
				s_city = rs.getString("city_txt");
				if (s_city == null) {
					log.FmtAndLogMsg("City value not present in the database");
					s_city = surroundWithQuotes("");
					performFTP = false;
				} else {
					s_city = surroundWithQuotes(s_city.trim());
				}
				v.add(s_city);
				
				// State(Required Field)
				s_state = rs.getString("state_id");
				if (s_state == null) {
					log.FmtAndLogMsg("State value not present in the database");
					s_state = surroundWithQuotes("");
					performFTP = false;
				} else {
					s_state = surroundWithQuotes(s_state.trim());
				}
				v.add(s_state);
				
				// ZipCode(First 5 digits- Required Field)
				s_zipcode = rs.getString("zipcode_txt");
				if (s_zipcode == null) {
					log
							.FmtAndLogMsg("Zipcode value not present in the database");
					s_zipcode = surroundWithQuotes("");
					performFTP = false;
				} else {
					s_zipcode = surroundWithQuotes(s_zipcode.trim());
				}
				v.add(s_zipcode);
				
				// Phone Number incl Area Code(Required Field)
				s_phone_num = rs.getString("phone_number_txt");
				if (s_phone_num == null) {
					log.FmtAndLogMsg("Phone Number value not present in the database");
					s_phone_num = surroundWithQuotes("");
					performFTP = false;
				} else {
					s_phone_num = surroundWithQuotes(s_phone_num.trim());
				}
				v.add(s_phone_num);
				
				// Status(Required Field)
				i_status_flg = rs.getInt("active_flg");
				if (i_status_flg == 1) {
					s_status = surroundWithQuotes("ACTIVE");
					//log.FmtAndLogMsg("Status flg value of 1 converted to string ACTIVE");
				}
				v.add(s_status);
				
				// Contact Name(Optional Field)
				s_contact_name = rs.getString("contact_txt");
				if (s_contact_name == null) {
					s_contact_name = surroundWithQuotes("");
					//log.FmtAndLogMsg("Contact Name Optional value not present in the database");
				} else {
					s_contact_name = surroundWithQuotes(s_contact_name);
				}
				v.add(s_contact_name);
				
				// Contact Phone Number(Optional Field - Assigning the Dealer
				// Phone Number)
				s_contact_phone_num = rs.getString("phone_number_txt");
				if (s_contact_phone_num == null) {
					s_contact_phone_num = surroundWithQuotes("");
					//log.FmtAndLogMsg("Phone Number value not present in the database");
				} else {
					s_contact_phone_num = surroundWithQuotes(s_contact_phone_num);
				}
				v.add(s_contact_phone_num);
				
				// Brand Name(Optional Field)(No Corresponding Column in the DB)
				s_brand_name = surroundWithQuotes("");
				v.add(s_brand_name);

				// Fax Number(Required Field)
				s_fax_num = rs.getString("fax_number_txt");
				if (s_fax_num == null) {
					log.FmtAndLogMsg("Fax Number value not present in the database");
					s_fax_num = surroundWithQuotes("");
					performFTP = false;
				} else {
					s_fax_num = surroundWithQuotes(s_fax_num.trim());
				}
				v.add(s_fax_num);
				
				// Dealer Tax ID(Optional Field)
				s_dealer_tax_id = rs.getString("tax_id");
				if (s_dealer_tax_id == null) {
					s_dealer_tax_id = surroundWithQuotes("");
					//log.FmtAndLogMsg("Tax ID value not present in the database");
				} else {
					s_dealer_tax_id = surroundWithQuotes(s_dealer_tax_id);
				}
				v.add(s_dealer_tax_id);
				
				// RouteOne Finance Source ID(Required Field)
				if (RouteOneFinId == null) {
					log
							.FmtAndLogMsg("FinanceSourceID value not present in the database");
					RouteOneFinId = "\"\"";;
					performFTP = false;
				} else {
				}
				v.add(RouteOneFinId);
				v.add(newline);
			} // end loop database records.

			ListIterator iter = v.listIterator();
			while (iter.hasNext()) {
				r1.writeDataExtract((String)iter.next());
			}
			r1.closeCSVFile();

			log
					.FmtAndLogMsg("********Input File Creation Completed Successfully********");
			log
					.FmtAndLogMsg("********Calling getHeaderFileData Method********");
			header_file_data = getHeaderFileData(routeoneFinanceId,
					recordCount, finance_src_name);
			log
					.FmtAndLogMsg("********getHeaderFileData Method Completed********");
			log
					.FmtAndLogMsg("********Calling openCSVFile Method for Header File********");
			r1.openCSVFile(header_filename);
			log
					.FmtAndLogMsg("********Calling writeDataExtract Method for Header File********");
			r1.writeDataExtract(header_file_data);
			r1.writeDataExtract(newline);
			log
					.FmtAndLogMsg("********Calling closeCSVFile Method for Header File********");
			r1.closeCSVFile();
			log
					.FmtAndLogMsg("********Header File Creation Completed Successfully********");

			input_filelocation = localfile_path.concat(input_filename);
			log.FmtAndLogMsg("input_filelocation : " + input_filelocation);
			header_filelocation = localfile_path.concat(header_filename);
			log.FmtAndLogMsg("header_filelocation : " + header_filelocation);


			if (FTPorHTTP.equals("FTP") && performFTP) {
				log.FmtAndLogMsg("********Calling FTPFile Method********");
				r1.ftpFile(header_filelocation, "Header");
				// r1.ftpFile(header_filename);
				r1.ftpFile(input_filelocation, "Input");
			} else if (FTPorHTTP.equals("HTTP")) {
				r1.httpFile(header_filelocation);
				r1.httpFile(input_filelocation);
			} else if (FTPorHTTP.equals("HTTPS")) {
				r1.httpsFile(header_filelocation);
				r1.httpsFile(input_filelocation);	
			}
			if (performFileDelete == true) {
				log.FmtAndLogMsg("********Calling Cleanup Files Method********");
				cleanupFiles();
				log.FmtAndLogMsg("********Cleanup Files Method Completed********");
			}
				
			
		} catch (Exception e) {
			recordError("getDataExtract", e);
		} finally {
			try {
				if (ps != null)
					ps.close();
				if (rs != null)
					rs.close();
			} catch (Exception e) {
				recordError("getDataExtract", e);
			} // end catch
		} // end finally
	} // end getDataExtract method

	/*
	 * method to ftp the file. Method taken from ConcatLetters Program author:
	 * Chuck Caplan
	 */

	public void ftpFile(String fileName, String fileType) throws Exception {
		if (performFTP == true && ftpPass != null
				&& ftpServer != null && ftpUser != null
				&& !ftpUser.trim().equals("")
				&& !ftpPass.trim().equals("") && !ftpServer.trim().equals("")) {
				
			log.FmtAndLogMsg("Uploading " + fileType + " File To Routing Queue for FTP");
			String passwordEncrypted = ftpPass;
			if(encryption_flg) {
				Crypto crypto = CryptoFactory.getCrypto();
				passwordEncrypted = crypto.encryptString("origenate","password",ftpPass);
			}
			String s_additional_data = "MODE,FTP,BINARY,1,FILE_LOCATION,"+fileName+",NEW_FILE_NAME,NONE,DELETE_FILE,0,"+ 
				"HOST_NAME,"+ftpServer+",USER_NAME,"+ftpUser+",PASSWORD,"+passwordEncrypted+",CERT_PATH,NONE,CLEANUP,"+
				(fileType.equals("Header")?"0":"1")+",CLEANUP_DIR,"+localfile_path+",CLEANUP_DAYS,"+cleanupDays+
				",CLEANUP_FILTER,"+routeoneFinanceId;
			
			SQLUpdate rqpInsert = new SQLUpdate();
			rqpInsert.SetPreparedUpdateStatement(con, "INSERT INTO routing_queue (request_id, queue_priority_num, routing_state_id, run_dt, tries_num, additional_data_txt, routing_queue_id, routing_state_subtype_txt) VALUES " + 
										"(0,0,35,sysdate,0,?,ROUTING_QUEUE_SEQ.nextval,'From Route One Dealer Extract')");
			rqpInsert.setString(1, s_additional_data);
			rqpInsert.RunPreparedUpdateStatement();
			
			log.FmtAndLogMsg("Finished Uploading " + fileType + " File");	
			performFileDelete = false;	
		} // end if
		else {
			performFileDelete = false;
			log.FmtAndLogMsg("Error FTPing " + fileType + " File");
			log.FmtAndLogMsg("One of the required FTP Parameters were missing");
		}
	} // end ftpFile method

	/** *************************************** */
	public void httpFile(String fileName) throws IOException {
		// Read dealer extract file
		String extractFileStr = "";
		String response = "";
		BufferedInputStream fis = null;
		try {

			/** OWASP Top 10 2010 - A4 path manipulation
			  * Change to the below code to fix vulnerabilities
			  * TTP 324955
			  */
			//File f = new File(fileName);
			File f = new File(OWASPSecurity.validationCheck(fileName, OWASPSecurity.DIRANDFILE));
			
			byte[] buffer = new byte[(int) f.length()];
			fis = new BufferedInputStream(new FileInputStream(f));
			int i = 0;
			int b = fis.read();

			while (b != -1) {
				buffer[i++] = (byte) b;
				b = fis.read();
			}

			extractFileStr = new String(buffer);

		} catch (Exception e) {
			System.out.println("Exception: " + e);
			System.exit(0);
		} finally {

			if (fis != null) {
				try {
					fis.close();
				} catch (IOException ioe) {
					// do nothing
				}
			}

		}

		// Post dealer extract file
		try {
			PostRequest postRequest = new PostRequest();
			postRequest.setHeaderProperty("Content-Type",
					"multipart/form-data; boundary=" + FORM_BOUNDARY);
			postRequest.setHeaderProperty("Cookie", "SMCHALLENGE=YES");
			response = postRequest.post(destinationURL, extractFileStr, 0);
		} catch (Exception e) {
			System.out.println("Exception: " + e);
			e.printStackTrace(System.out);
			System.exit(0);
		}

		System.out.println("Response: " + response);

	}

	/** **************************************** */
	/*
	 * Method to get the filenames for the header and input data extract file
	 */

	public static String getFileName(String filetype, String routeoneFinanceId) {

		Calendar cal = new GregorianCalendar(); // create a Calendar object
		String year = ""; // year
		String month = ""; // month
		String day = ""; // day
		String date = "";
		String s_filetype = filetype; // file type : input or header file
		String filename = "";
		try {

			// call the getRouteOneSourceFinanceID method in order to obtain the
			// RouteOneFinanceID
			// routeoneFinanceId = getRouteOneSourceFinanceID();

			// get date to append to the filename.
			if (routeoneFinanceId != null) {
				year = (Integer.toString(cal.get(Calendar.YEAR))).trim(); // 2002
				month = (Integer.toString((cal.get(Calendar.MONTH)) + 1))
						.trim(); // 0=Jan, 1=Feb, ...
				if (month.length() < 2) {
					month = "0".concat(month);
				}
				day = (Integer.toString(cal.get(Calendar.DAY_OF_MONTH))).trim(); // 1...
				if (day.length() < 2) {
					day = "0".concat(day);
				}
				date = month + day + year;
			} else {
				log.FmtAndLogMsg("RouteOneFinanceID not available");
				showUsageAndExit();
			}

			/*
			 * CSV Input file Format: RouteOneFinanceSourceID_Date_input.csv CSV
			 * Header file Format: RouteOneFinanceSourceID_Date_header.csv
			 */

			if (s_filetype.equalsIgnoreCase("Input"))
				// filename = routeoneFinanceId + "_" + date + "_input.csv";
				filename = ((routeoneFinanceId.concat("_")).concat(date))
						.concat("_input.csv");
			else if (s_filetype.equals("Header"))
				// filename = routeoneFinanceId + "_" + date + "_header.csv";
				filename = ((routeoneFinanceId.concat("_")).concat(date))
						.concat("_header.csv");

		} catch (Exception e) {
			try {
				recordError("setFileName", e);
			} catch (Exception ex) {
				log.FmtAndLogMsg("Error in getFileName method of : "
						+ ex.toString());
			}
		} // end catch
		return filename;
	} // end getFileName method

	/*
	 * Method to create the header file data.
	 */

	public static String getHeaderFileData(String financeSourceID,
		int recordCount, String financeSource) throws Exception {
		String RouteOneFinSourceID = "\"" + financeSourceID + "\"";
		String FinanceSourceName = "\"" + financeSource + "\"" + ",";
		String number_of_records = Integer.toString(recordCount) + ",";
		String headerFileData = "";
		String input_file = "\"" + input_filename + "\"" + ",";
		headerFileData = ((input_file.concat(number_of_records))
				.concat(FinanceSourceName)).concat(RouteOneFinSourceID);
		return headerFileData;
	}

	// try it and check if it works...

	public String getFileNameFromPath(String file) {
		return file.substring(file.lastIndexOf("\\") + 1, file.length());
	}

	/*
	 * Method to create the CVS fields. surround the fields with double qoutes.
	 */

	public static String surroundWithQuotes(String fieldName) {
		String s_field = fieldName;
		s_field = (("\"".concat(s_field)).concat("\"")).concat(",");
		return s_field;
	}


	/* 
	 * method to cleanup files older than n days(from Chuck Caplan) 
	 */

	public static void cleanupFiles() {

		int numOfDays = Integer.parseInt(cleanupDays);
		if (numOfDays >= 0) {
			// get list of all files in local dir
			
			/** OWASP Top 10 2010 - A4 path manipulation
			  * Change to the below code to fix vulnerabilities
			  * TTP 324955
			  */
			//File localDirFiles = new File(localfile_path);
			File localDirFiles=null;
			try
			{
			localDirFiles = new File(OWASPSecurity.validationCheck(localfile_path, OWASPSecurity.DIRANDFILE));
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			String[] localFiles = localDirFiles.list();
			
			FilenameFilter filter = new FilenameFilter() {
		        public boolean accept(File localDirFiles, String name) {
		            return name.startsWith(routeoneFinanceId);
		        }
		    };
		    localFiles = localDirFiles.list(filter);

			
			for (int i = 0; i < localFiles.length; i++) {
				File backupFile = new File(localDirFiles.getAbsolutePath() + "\\"
						+ localFiles[i]);
				Date lastModified = new Date(backupFile.lastModified());
				GregorianCalendar gc = new GregorianCalendar();
				gc.add(Calendar.DATE, 0 - numOfDays);
				java.util.Date cleanupDate = gc.getTime();
				if (cleanupDate.after(lastModified)) {
					log.FmtAndLogMsg("Deleted file " + localFiles[i] + ": "
							+ backupFile.delete());
				}
				backupFile = null;
			}
			localDirFiles = null;
		} else {
			log.FmtAndLogMsg("Not deleting any files since cleanupDays = "
					+ cleanupDays);
		}
		log.FmtAndLogMsg("Ended cleanup of files");

		
	}
	
	
	/*
	 * Opens a file for writing. If file exists the data would be appended by
	 * default.
	 */
	public void openCSVFile(String fileName) throws Exception {
		try {
			fileName = localfile_path.concat(fileName);
			
			/** OWASP Top 10 2010 - A4 path manipulation
			  * Change to the below code to fix vulnerabilities
			  * TTP 324955
			  */
			//dataFile = new PrintWriter(new BufferedWriter(new FileWriter(fileName, append)));
			dataFile = new PrintWriter(new BufferedWriter(new FileWriter(OWASPSecurity.validationCheck(fileName, OWASPSecurity.DIRANDFILE), append)));
			
		} catch (Exception e) {
			recordError("openCSVFile", e);
		}
	}

	public void writeDataExtract(String str) {
		if (dataFile != null) {
			dataFile.print(str);
			dataFile.flush();
		}
	}

	public void closeCSVFile() {
		if (dataFile != null) {
			dataFile.flush();
			dataFile.close();
			dataFile = null;
		}
	}

	
	
	/*
	 * Method to post a file via https
	 */
	public void httpsFile(String filename) {
    	byte[] buffer;
    	int bytesRead, bytesAvail, bufferSize;
    	HttpURLConnection conn = null;
    	DataOutputStream ostream = null;
		FileInputStream istream = null;
		BufferedReader breader = null;
    	
    	Authenticator.setDefault(new R1Authenticator());

		// create a trust manager that does not validate certificate chains
		TrustManager[] trustAllCerts = new TrustManager[] {
			new X509TrustManager() {
				public X509Certificate[] getAcceptedIssuers() {
					return null;
				}
				public void checkClientTrusted(X509Certificate[] certs, String authType) {}
				public void checkServerTrusted(X509Certificate[] certs, String authType) {}
			}
		};

		// hostname verifier to ignore bad urls from https
		HostnameVerifier hv = new HostnameVerifier() {
			public boolean verify(String hostname, SSLSession session) {
				System.out.println("URL Host: " + hostname + ", " + session.getPeerHost());
				return true;
			}
		};
		
		try {
			
			/** OWASP Top 10 2010 - A4 path manipulation
			  * Change to the below code to fix vulnerabilities
			  * TTP 324955
			  */
			//istream = new FileInputStream(new File(filename));
			istream = new FileInputStream(new File(OWASPSecurity.validationCheck(filename, OWASPSecurity.DIRANDFILE)));
			
			SSLContext sc = SSLContext.getInstance("SSL");
			URL url = new URL(destinationURL);
			
			sc.init(null, trustAllCerts, new SecureRandom());
			HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());
			HttpsURLConnection.setDefaultHostnameVerifier(hv);

			conn = (HttpURLConnection)url.openConnection();
			conn.setRequestMethod("POST");
			conn.setRequestProperty("Content-type", "multipart/form-data; boundary=" + FORM_BOUNDARY);
			conn.setDoOutput(true);
			
			ostream = new DataOutputStream (conn.getOutputStream ());
			ostream.writeBytes("--" + FORM_BOUNDARY + NEWLINE);
			ostream.writeBytes("content-disposition: form-data; name=\"File\";  filename=" + filename + NEWLINE);
			ostream.writeBytes(NEWLINE);
		
			bytesAvail = istream.available();
			bufferSize = Math.min(bytesAvail, MAX_BUFFER_SIZE);
			buffer = new byte[bufferSize];
			bytesRead = istream.read(buffer, 0, bufferSize);

			while (bytesRead > 0) {
				ostream.write(buffer, 0, bufferSize);
				bytesAvail = istream.available();
                bufferSize = Math.min(bytesAvail, MAX_BUFFER_SIZE);
                bytesRead = istream.read(buffer, 0, bufferSize);
            }

			// send multipart form data necessary after file data
			ostream.writeBytes(NEWLINE);
			ostream.writeBytes("--" + FORM_BOUNDARY + "--" + NEWLINE);

	        // get the response
	        breader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
	        String line;
        
	        while ((line = breader.readLine()) != null) {
	        	System.out.println(line);
        	}
	        
	        // close streams
	        istream.close();
	        ostream.flush();
	        ostream.close();
		}
		catch (Exception e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		} finally {
			try { if (istream != null) istream.close();} catch (Exception ex) {ex.printStackTrace();}
			try { if (ostream != null) ostream.flush();} catch (Exception ex)  {ex.printStackTrace();}
			try { if (ostream != null) ostream.close();} catch (Exception ex) {ex.printStackTrace();}
			try { if (breader != null) breader.close();} catch (Exception ex) {ex.printStackTrace();}
		}
    } // end httpsFile method
} // main class

class R1Authenticator extends Authenticator {
	protected PasswordAuthentication getPasswordAuthentication() {
	    String password = "r1dealerextract";
	    return new PasswordAuthentication("r1dealer", password.toCharArray());
	}
}