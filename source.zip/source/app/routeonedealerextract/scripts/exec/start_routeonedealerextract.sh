echo $ROUTEONEPARAM
nohup java -classpath .:../lib/common.jar:../lib/ojdbc6.jar:../lib/crypto.jar \
 com.cmsinc.origenate.routeonedealerextract.RouteOneDealerExtract $ROUTEONEPARAM &
