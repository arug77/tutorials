echo $ODEPARAM
nohup java -classpath .:../lib/common.jar:../lib/ojdbc6.jar:../lib/commons-io-1.3.1.jar:../lib/commons-net-3.3.jar \
 com.cmsinc.origenate.odedealerextract.ODEDealerExtract $ODEPARAM &
