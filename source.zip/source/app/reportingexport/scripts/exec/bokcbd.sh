#######################################################################################################################
# Program: bokcbd.sh
# Purpose: Generate CBD interface file for BOK
#
# Parameter: 1) <starting_date>: format = MM/DD/YYYY, requires 2 digits for month, 2 digits for day & 4 digits for year
#					Value is optional, if it is not passed a defaul to 1st day of previous month is used.
#					If value is passed, SQL query replaces DD's value with 1 (e.g. 03/15/2005 would be converted into
#					03/01/2005 by SQL query)
#
# Selection criteria: apps with last_access_date in between <starting_date> & <last day in the same month of starting_date>
# 					& has one of these statuses: BOOKED, COMPLETE, EXPIRED, DECISIONED, FAILED, WITHDRAWN. Application can
#					only qualify once in interface.
#
# Output File Name: output/bokcbd<starting_date>.xml
#					if rerun for same date previous result file is renamed to output/bokcbd<starting_date>.<mmddhhmmss>.xml
#					where <mmddhhmmss> is current month, current day & current time.
#
# Modifications:
#  12/14/2005 - Changed $XML assignment. ChrisN
#  12/15/2005 - Modified to run on tb60. ChrisN
#######################################################################################################################
. /opt/origenate/qs60/admin/javaset.sh


DIR=/opt/origenate/tb60/clients/scripts/reportingexport            # base directory for data extract
LOG=$DIR/bokcbd.log                                                # log file name (including full path)
OUT=$DIR/BOK_CBD_DATA_EXTRACT32                                    # directory for exported applications
STARTDATE=$1                                                       # MM/DD/YYYY format: 2 digits for month, 2 digits for day

## if starting date not passed use 1st date in previous month
if [ x"$STARTDATE" = x ]; then
	basemonth=`date +"%m"`
	baseyear=`date +"%Y"`

	if [ $basemonth = "01" -o $basemonth = "1" ]; then
		prevmonth=12
		prevyear=`expr $baseyear - 1`
	else
		prevmonth=`expr $basemonth - 1`
		prevmonth=`printf '%2.2d' $prevmonth`
		prevyear=$baseyear
	fi
	STARTDATE=$prevmonth/01/$prevyear
fi

## create result directory "output"
if [ ! -d $DIR/output ]
then
	mkdir -p $DIR/output
fi

STARTMDY=`echo $STARTDATE|tr -d '/'`                               # start date without dashes
#XML=$DIR/data/bokcbd$STARTMDY.xml                                  # result file name (including full path)
XML=$DIR/output/bokcbd$STARTMDY.xml                                # result file name (including full path)

## write log header
echo "`date` extract started."      >>$LOG 2>&1
echo " Starting date is" $STARTDATE >>$LOG 2>&1

cd $DIR

## Run data extract for CBD interface
java com.cmsinc.origenate.tool.exportReportDB -hajdbpd02 -p1521 -stestbed -uorigtb60 -aorigtb60 -e32 -d$STARTDATE -zLoanAppRq,InterAppRq -q1 >>$LOG 2>&1

## Dump result directory listing to log file
ls -C $OUT >>$LOG 2>&1

cd $OUT

if [ -r $XML ]
then
	XMLBAK=$DIR/output/bokcbd$STARTMDY.`date +'%m%d%H%M%S'`.xml
	mv $XML $XMLBAK
	echo " Renamed previous result file to" $XMLBAK  >>$LOG 2>&1
fi

## Create xml header & starting root for result file
echo "<?xml version=\00421.0\0042 encoding=\0042UTF-8\0042?>"    >  $XML
echo "<BOKCBD>"                                                  >> $XML

## Combine .xml files into one large xml
for i in *.xml;
do
  if [ ! -s $i ]; then  ## If zero length then
    :                   ## do nothing
  else
    ## remove xml header, append the rest to result file
    tail +40c $i  >> $XML
  fi

  ## remove xml for exclusion from future data extracts
  if [ -r $i ]; then
  	rm $i;
  fi
done

## create ending root for result file
echo "</BOKCBD>"  >> $XML


## write log footer
echo " Saved result file to" $XML >>$LOG 2>&1
echo "`date` extract ended."      >>$LOG 2>&1
echo                              >>$LOG 2>&1


