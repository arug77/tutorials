package com.cmsinc.origenate.tool;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.cmsinc.origenate.util.LogMsg;
import com.cmsinc.origenate.util.Query;

/**
 * DAO class for the CREDIT_REQUEST table and related DB entities.
 */
public class CreditRequestDAO {

    private Connection conn;
    private LogMsg log_obj;
    private int log_level;

    /**
     * Public constructor for creating an object of the class.
     * 
     * @param conn
     *            Database Connection Object
     * @param log_obj
     *            LogMsg object
     * @param log_level
     *            Log level from the ini
     */
    public CreditRequestDAO(Connection conn, LogMsg log_obj, int log_level) {
        this.conn = conn;
        this.log_obj = log_obj;
        this.log_level = log_level;
    }

    /**
     * Checks if the the application is in the DONE task
     * 
     * @param request_id
     *            Request ID of the application to check
     * @param evaluator_id
     *            The evaluator ID
     * @return Returns false if the task is DONE, otherwise returns true
     * @throws Exception
     *             Throws an exception if there is an issue with running the SQL commands
     */
    public boolean checkIfCurrentDetail(String request_id, int evaluator_id) throws Exception {
        String task = "";
        boolean currentRecord = true; // default to get current record details
        PreparedStatement ps = null;
        ResultSet rs = null;
        String updateSql =  "select task_id" + 
                            " from credit_request " + 
                            " where EVALUATOR_ID = ? AND request_id = ?";
        try {
            ps = conn.prepareStatement(updateSql);
            ps.setInt(1, evaluator_id);
            ps.setString(2, request_id);
            rs = ps.executeQuery();

            if (rs.next()) {
                task = getStringValue(rs, "task_id");
            }

            log(0, "Retrieved task:" + task + " for requestID# " + request_id);
        } catch (Exception e) {
            throw new Exception("Error occured checking if current details", e);
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }

                if (ps != null) {
                    ps.close();
                }
            } catch (Exception e) {
                log(0, "Unable to close PreparedStatement/ResultSet" + e.toString());
            }
        }

        if (task.equals("DONE")) { // closed record detail
            currentRecord = false;
        }

        return currentRecord;
    }

    /**
     * Get the selection query for the singlefeed process
     * 
     * @param evaluator_id
     *            Evaluator ID
     * @param export_id
     *            The export ID
     * @return The selection query
     * @throws Exception
     *             Throws an exception if there is an issue with running the SQL commands
     */
    public String getExportQuery(int evaluator_id, int export_id) throws Exception {
        String strExportQuery = "";

        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;

        try {
            String sql =    "SELECT cde.data_extract_name_txt, cdq.query_txt, nvl(cde.write_app_flg,0) as write_app_flg  " + 
                            "FROM config_data_extract cde, config_doc_queries cdq " + 
                            "WHERE cde.evaluator_id = ? " + 
                            "AND cde.data_extract_id = ? " + 
                            "AND cde.active_flg = 1 " + 
                            "AND cde.evaluator_id = cdq.evaluator_id " + 
                            "AND cde.selection_query_id = cdq.query_id";

            preparedStatement = conn.prepareStatement(sql);
            preparedStatement.setInt(1, evaluator_id);
            preparedStatement.setInt(2, export_id);

            resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                strExportQuery = resultSet.getString("query_txt");
            } else {
                throw new Exception("Error getting query_txt from config_data_extract");
            }
        } catch (Exception e) {
            throw new Exception("Error getting export details", e);
        } finally {
            try {
                if (resultSet != null) {
                    resultSet.close();
                }

                if (preparedStatement != null) {
                    preparedStatement.close();
                }
            } catch (Exception e) {
                log(0, "Unable to close PreparedStatement/ResultSet" + e.toString());
            }
        }

        return strExportQuery;
    }

    /**
     * Runs a provided query, this will be a selection query for the apps
     * 
     * @param s_sql
     *            Selection query string
     * @return The Query object populated with the results
     * @throws Exception
     *             Throws an exception if there is an issue with running the SQL commands
     */
    public Query getAppsToProcess(String s_sql) throws Exception {
        Query query;

        try {
            query = new Query(conn);
            query.executeQuery(s_sql);
        } catch (Exception e) {
            throw new Exception("Error running the app selection query", e);
        }

        return query;
    }

    /**
     * Gets the singlefeed data for this application
     * 
     * @param requestID
     *            The requestID of the app to get
     * @return Returns a CreditRequestDTO object populated with the singlefeed details
     * @throws Exception
     *             Throws an exception if an error occurs communicating with the database
     */
    public CreditRequestDTO getSingleFeedData(String requestID) throws Exception {
        CreditRequestDTO crDTO = new CreditRequestDTO();
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;

        try {
            String sql =    "SELECT cr.client_app_id, orig.originator_id, appid.value_txt, finance.orig_loan_amt_num, funding.tot_fund_amt_num, cr.initiation_dt, cr.app_status_id, cr.source_id, contra.term_num, finance.seller_name_txt " + 
                            "FROM credit_request cr, credit_request_originator orig, credit_request_app_ids appid, credit_request_finance finance, credit_request_funding funding, credit_req_contr_fin contra " +
                            "WHERE cr.request_id = ? and cr.request_id = orig.request_id AND cr.request_id = appid.request_id AND cr.request_id = finance.request_id " +
                            "AND cr.request_id = funding.request_id AND cr.request_id = contra.request_id AND appid.name_txt  = 'EVAL_148_REQ_APPID'";

            preparedStatement = conn.prepareStatement(sql);
            preparedStatement.setInt(1, Integer.parseInt(requestID));
            resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                crDTO.setReferenceNumber(resultSet.getString("client_app_id"));
                crDTO.setAgentID(resultSet.getString("originator_id"));
                crDTO.setApplicationID(resultSet.getString("value_txt"));
                crDTO.setReqeustedLoan(resultSet.getString("orig_loan_amt_num"));
                crDTO.setOriginalLoanBalance(resultSet.getString("tot_fund_amt_num"));
                crDTO.setDateAppReceived(resultSet.getString("initiation_dt"));
                crDTO.setCodeAction(resultSet.getString("app_status_id"));
                crDTO.setCodeOriginationSource(resultSet.getString("source_id"));
                crDTO.setTermNum(resultSet.getString("term_num"));
                crDTO.setDealerLienName(resultSet.getString("seller_name_txt"));
            } else {
                throw new Exception("Error getting singlefeed data");
            }
        } catch (Exception e) {
            throw new Exception("Error getting export details", e);
        } finally {
            try {
                if (resultSet != null) {
                    resultSet.close();
                }

                if (preparedStatement != null) {
                    preparedStatement.close();
                }
            } catch (Exception e) {
                log(0, "Unable to close PreparedStatement/ResultSet" + e.toString());
            }
        }

        return crDTO;
    }

    /**
     * 
     * @param rs
     *            The resultSet with columns
     * @param columnToRetrieve
     *            The column to retrieve
     * @return The value at the column
     * @throws Exception
     *             Throws an exception if there is an issue with running the SQL commands
     */
    public String getStringValue(ResultSet rs, String columnToRetrieve) throws Exception {
        String retrievedValue = "";
        try {
            retrievedValue = rs.getString(columnToRetrieve);
            if (retrievedValue == null) {
                retrievedValue = "";
            }
        } catch (Exception e) {
            throw new Exception("An error occured getting the value from the ResultSet", e);
        }
        return retrievedValue;
    }

    /**
     * Logging method for this class. We are using this wrapper because when it passes through this method, logs it will append the class name in
     * front of the log message.
     * 
     * @param msgLevel
     *            Level of the message
     * @param logMsg
     *            The message to log, as a string
     */
    public void log(int msgLevel, String logMsg) {
        if (LogMsg.isDebuggingEnabled(log_level, msgLevel)) {
            log_obj.FmtAndLogMsg("CreditRequestDAO: " + logMsg);
        }
    }
}