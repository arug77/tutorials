  package com.cmsinc.origenate.tool;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.cmsinc.origenate.tool.CreditDecisionsDTO.DecPTIDTI;
import com.cmsinc.origenate.tool.CreditDecisionsDTO.DecReasonTypeEnum;
import com.sf.bank.lue.util.DateFormatter;

/**
 * Builder for creating collection of SingleFeedBeans
 * 
 * <code>
 * 
 *  builder = new SingleFeedCSVByNameBuilderImpl().setCreditRequestInfo(dto).setCreditRequestorInfo(dto)
 *  and so on and call the builder.buildbeans();
 * </code>
 * @author DVJ2
 *
 */
public class SingleFeedCSVByNameBuilderImpl implements SingleFeedBuilder<SingleFeedCSVByNameBean>{

    
    private HashMap<String, SingleFeedCSVByNameBean> beanMap = new HashMap<String, SingleFeedCSVByNameBean>();
    
    private SingleFeedCSVByNameBean getBean(String requestId)
    {
        SingleFeedCSVByNameBean csvbean;
        if(beanMap.containsKey(requestId) )
        {
            csvbean =  beanMap.get(requestId);
             
        }else
        {
            csvbean =  new SingleFeedCSVByNameBean();
        }
        
        return csvbean;
    }

    /**
     * Sets the dto values to the corresponding field in the SingleFeedCSVByNameBean. 
     * 
     * @param csvbean
     * @param dto CreditRequestDTO values to be set in given SingleFeedCSVByNameBean
     */
    private void setCreditRequestInfo(SingleFeedCSVByNameBean csvbean, CreditRequestDTO dto)
    {
        csvbean.setAgentID(dto.getAgentID());
        csvbean.setApplicationID(dto.getApplicationID());
        csvbean.setReferenceNumber(dto.getReferenceNumber());
        csvbean.setReqeustedLoan(dto.getReqeustedLoan());
        csvbean.setOriginalLoanBalance(dto.getOriginalLoanBalance());
        csvbean.setDateAppReceived(dto.getDateAppReceived());
        csvbean.setCodeAction(dto.getCodeAction());
        csvbean.setCodeOriginationSource(dto.getCodeOriginationSource());
        csvbean.setDealerLienName(dto.getDealerLienName());
        
    }
    
    /**
     * Sets the dto values to the corresponding field in the SingleFeedCSVByNameBean. 
     * 
     * @param csvbean
     * @param dto CreditRequestorDTO values to be set in given SingleFeedCSVByNameBean
     */
    private void setCreditRequestorInfo(SingleFeedCSVByNameBean csvbean, List<CreditRequestorDTO> dto)
    {
        double ltv = 0.0;
        double pti = 0.0;
        
        for(CreditRequestorDTO requestor: dto )
        {
            if(ENTITY_APPLICANT_TXT.equalsIgnoreCase(requestor.getRequestorEntityTxt()))
            {
                csvbean.setApplicantFirstName(requestor.getFirstName());
                csvbean.setApplicantMiddleName(requestor.getMiddleName());
                csvbean.setApplicantLastname(requestor.getLastname());
                csvbean.setApplicantNumberTaxID(requestor.getTaxIDNumber());
                csvbean.setApplicantDOB(requestor.getDOB());
                csvbean.setApplicantIncome(requestor.getIncome());
                csvbean.setApplicantPhoneHome(requestor.getHomephone());
                csvbean.setApplicantAddressLine1(requestor.getAddressLine1());
                csvbean.setApplicantAddressCity(requestor.getAddressCity());
                csvbean.setApplicantAddressState(requestor.getAddressState());
                csvbean.setApplicantAddressZip(requestor.getAddressZip());
                csvbean.setApplicantCreditNumberInquiries(requestor.getCreditNumberInquiries());
                csvbean.setApplicantCreditNumberMajorTotalDelinquencies(requestor.getCreditNumberMajorTotalDelinquencies());
                csvbean.setApplicantCreditNumberMinorTotalDelinquencies(requestor.getCreditNumberMinorTotalDelinquencies());
                csvbean.setApplicantCreditNumberSatisfactoryAccounts(requestor.getCreditNumberSatisfactoryAccounts());
                csvbean.setApplicantCreditScore(requestor.getCreditScore());
                if( requestor.getRequestorRatioDebtServiceTotal() > 0.0 )
                {
                    pti = requestor.getRequestorRatioDebtServiceTotal();
                    ltv = requestor.getRequestorRatioLoantoValue(); 
                    csvbean.setApplicantRatioDebtServiceTotal(pti);
                    csvbean.setApplicantRatioLoantoValue(ltv);
                }
                    

            }else if (ENTITY_COAPPLICANT1_TXT.equalsIgnoreCase(requestor.getRequestorEntityTxt()))
            {
                csvbean.setCoApplicantFirstName(requestor.getFirstName());
                csvbean.setCoApplicantMiddleName(requestor.getMiddleName());
                csvbean.setCoApplicantLastname(requestor.getLastname());
                csvbean.setCoApplicantNumberTaxID(requestor.getTaxIDNumber());
                csvbean.setCoApplicantDOB(requestor.getDOB());
                csvbean.setCoApplicantIncome(requestor.getIncome());
                csvbean.setCoApplicantPhoneHome(requestor.getHomephone());
                csvbean.setCoApplicantAddressLine1(requestor.getAddressLine1());
                csvbean.setCoApplicantAddressCity(requestor.getAddressCity());
                csvbean.setCoApplicantAddressState(requestor.getAddressState());
                csvbean.setCoApplicantAddressZip(requestor.getAddressZip());
                csvbean.setCoApplicantCreditNumberInquiries(requestor.getCreditNumberInquiries());
                csvbean.setCoApplicantCreditNumberMajorTotalDelinquencies(requestor.getCreditNumberMajorTotalDelinquencies());
                csvbean.setCoApplicantCreditNumberMinorTotalDelinquencies(requestor.getCreditNumberMinorTotalDelinquencies());
                csvbean.setCoApplicantCreditNumberSatisfactoryAccounts(requestor.getCreditNumberSatisfactoryAccounts());
                csvbean.setCoApplicantCreditScore(requestor.getCreditScore());
                csvbean.setCoApplicantRatioDebtServiceTotal(pti);
                csvbean.setCoApplicantRatioLoantoValue(ltv);

                
            }else if (ENTITY_COAPPLICANT2_TXT.equalsIgnoreCase(requestor.getRequestorEntityTxt()))
            {
                csvbean.setCoApplicant2FirstName(requestor.getFirstName());
                csvbean.setCoApplicant2MiddleName(requestor.getMiddleName());
                csvbean.setCoApplicant2Lastname(requestor.getLastname());
                csvbean.setCoApplicant2NumberTaxID(requestor.getTaxIDNumber());
                csvbean.setCoApplicant2DOB(requestor.getDOB());
                csvbean.setCoApplicant2Income(requestor.getIncome());
                csvbean.setCoApplicant2PhoneHome(requestor.getHomephone());
                csvbean.setCoApplicant2AddressLine1(requestor.getAddressLine1());
                csvbean.setCoApplicant2AddressCity(requestor.getAddressCity());
                csvbean.setCoApplicant2AddressState(requestor.getAddressState());
                csvbean.setCoApplicant2AddressZip(requestor.getAddressZip());
                csvbean.setCoApplicant2CreditNumberInquiries(requestor.getCreditNumberInquiries());
                csvbean.setCoApplicant2CreditNumberMajorTotalDelinquencies(requestor.getCreditNumberMajorTotalDelinquencies());
                csvbean.setCoApplicant2CreditNumberMinorTotalDelinquencies(requestor.getCreditNumberMinorTotalDelinquencies());
                csvbean.setCoApplicant2CreditNumberSatisfactoryAccounts(requestor.getCreditNumberSatisfactoryAccounts());
                csvbean.setCoApplicant2CreditScore(requestor.getCreditScore());
                csvbean.setCoApplicant2RatioDebtServiceTotal(pti);
                csvbean.setCoApplicant2RatioLoantoValue(ltv);
                
            }else if (ENTITY_COSIGNER1_TXT.equalsIgnoreCase(requestor.getRequestorEntityTxt()))
            {
                csvbean.setCoSignerFirstName(requestor.getFirstName());
                csvbean.setCoSignerMiddleName(requestor.getMiddleName());
                csvbean.setCoSignerLastname(requestor.getLastname());
                csvbean.setCoSignerNumberTaxID(requestor.getTaxIDNumber());
                csvbean.setCoSignerDOB(requestor.getDOB());
                csvbean.setCoSignerIncome(requestor.getIncome());
                csvbean.setCoSignerPhoneHome(requestor.getHomephone());
                csvbean.setCoSignerAddressLine1(requestor.getAddressLine1());
                csvbean.setCoSignerAddressCity(requestor.getAddressCity());
                csvbean.setCoSignerAddressState(requestor.getAddressState());
                csvbean.setCoSignerAddressZip(requestor.getAddressZip());
                csvbean.setCoSignerCreditNumberInquiries(requestor.getCreditNumberInquiries());
                csvbean.setCoSignerCreditNumberMajorTotalDelinquencies(requestor.getCreditNumberMajorTotalDelinquencies());
                csvbean.setCoSignerCreditNumberMinorTotalDelinquencies(requestor.getCreditNumberMinorTotalDelinquencies());
                csvbean.setCoSignerCreditNumberSatisfactoryAccounts(requestor.getCreditNumberSatisfactoryAccounts());
                csvbean.setCoSignerCreditScore(requestor.getCreditScore());
                csvbean.setCoSignerRatioDebtServiceTotal(pti);
                csvbean.setCoSignerRatioLoantoValue(ltv);
                
            }else if (ENTITY_COSIGNER2_TXT.equalsIgnoreCase(requestor.getRequestorEntityTxt()))
            {
                csvbean.setCoSigner2FirstName(requestor.getFirstName());
                csvbean.setCoSigner2MiddleName(requestor.getMiddleName());
                csvbean.setCoSigner2Lastname(requestor.getLastname());
                csvbean.setCoSigner2NumberTaxID(requestor.getTaxIDNumber());
                csvbean.setCoSigner2DOB(requestor.getDOB());
                csvbean.setCoSigner2Income(requestor.getIncome());
                csvbean.setCoSigner2PhoneHome(requestor.getHomephone());
                csvbean.setCoSigner2AddressLine1(requestor.getAddressLine1());
                csvbean.setCoSigner2AddressCity(requestor.getAddressCity());
                csvbean.setCoSigner2AddressState(requestor.getAddressState());
                csvbean.setCoSigner2AddressZip(requestor.getAddressZip());
                csvbean.setCoSigner2CreditNumberInquiries(requestor.getCreditNumberInquiries());
                csvbean.setCoSigner2CreditNumberMajorTotalDelinquencies(requestor.getCreditNumberMajorTotalDelinquencies());
                csvbean.setCoSigner2CreditNumberMinorTotalDelinquencies(requestor.getCreditNumberMinorTotalDelinquencies());
                csvbean.setCoSigner2CreditNumberSatisfactoryAccounts(requestor.getCreditNumberSatisfactoryAccounts());
                csvbean.setCoSigner2CreditScore(requestor.getCreditScore());
                csvbean.setCoSigner2RatioDebtServiceTotal(pti);
                csvbean.setCoSigner2RatioLoantoValue(ltv);
            }
            
        }
        
    }

    /**
     * Sets the dto values to the corresponding field in the SingleFeedCSVByNameBean. 
     * 
     * @param csvbean
     * @param dto IntermediateValuesDTO values to be set in given SingleFeedCSVByNameBean
     */
    private void setIntermediateValues(SingleFeedCSVByNameBean csvbean, IntermediateValuesDTO dto)
    {
        csvbean.setCodeProduct(dto.getCodeProduct());
        csvbean.setCodeOfficer(dto.getCodeOfficer());
        csvbean.setBankID(dto.getBankID());
        csvbean.setUserid(dto.getUserid());
        csvbean.setTermLoanOriginal(dto.getOrigLoanTerm());
        csvbean.setCodeLoanType(dto.getCodeLoanType());
        csvbean.setApplicantTotalBankruptcies(dto.getApplicantTotalBankruptcies());
        csvbean.setApplicantTotalCollections(dto.getApplicantTotalCollections());
        csvbean.setCoApplicantTotalBankruptcies(dto.getCoApplicant1TotalBankruptcies());
        csvbean.setCoApplicantTotalCollections(dto.getCoApplicant1TotalCollections());
        csvbean.setCoApplicant2TotalBankruptcies(dto.getCoApplicant2TotalBankruptcies());
        csvbean.setCoApplicant2TotalCollections(dto.getCoApplicant2TotalCollections());
        csvbean.setCoSignerTotalBankruptcies(dto.getCoSigner1TotalBankruptcies());
        csvbean.setCoSignerTotalCollections(dto.getCoSigner1TotalCollections());
        csvbean.setCoSigner2TotalBankruptcies(dto.getCoSigner2TotalBankruptcies());
        csvbean.setCoSigner2TotalCollections(dto.getCoSigner2TotalCollections());
        
        
    }
    
    /**
     * Sets the dto values to the corresponding field in the SingleFeedCSVByNameBean. 
     * 
     * @param csvbean
     * @param dto CreditDecisionsDTO values to be set in given SingleFeedCSVByNameBean
     */
    
    private void setCreditDecisionReasons(SingleFeedCSVByNameBean csvbean, CreditDecisionsDTO dto)
    {
        int overrideCodeCntr = 0;
        for(CreditDecisionsDTO.DecReason reason : dto.getDecReasons())
        {
            if(DecReasonTypeEnum.Turndown == reason.getDecReasonTypeId())
            {
                if(reason.getDecReasonOrderPrecedence() == 9991)
                {
                    csvbean.setCodeDenial1(reason.getDecReasonCode());
                    csvbean.setDenialDescription1(reason.getDecReasonCode());
                    
                }else if(reason.getDecReasonOrderPrecedence() == 1)
                {
                    csvbean.setCodeDenial1(reason.getDecReasonCode());
                    csvbean.setDenialDescription1(reason.getDecReasonCode());
                }
                
                if(reason.getDecReasonOrderPrecedence() == 9992)
                {
                    csvbean.setCodeDenial2(reason.getDecReasonCode());
                    csvbean.setDenialDescription2(reason.getDecReasonCode());
 
                    
                }else if(reason.getDecReasonOrderPrecedence() == 2)
                {
                    csvbean.setCodeDenial2(reason.getDecReasonCode());
                    csvbean.setDenialDescription2(reason.getDecReasonCode());
                    
                }
                
                if(reason.getDecReasonOrderPrecedence() == 9993)
                {
                    csvbean.setCodeDenial3(reason.getDecReasonCode());
                    csvbean.setDenialDescription3(reason.getDecReasonCode());
 
                    
                }else if(reason.getDecReasonOrderPrecedence() == 3)
                {
                    csvbean.setCodeDenial3(reason.getDecReasonCode());
                    csvbean.setDenialDescription3(reason.getDecReasonCode());
 
                }
                
                if(reason.getDecReasonOrderPrecedence() == 9994)
                {
                    csvbean.setCodeDenial4(reason.getDecReasonCode());
                    csvbean.setDenialDescription4(reason.getDecReasonCode());
                    
                }else if(reason.getDecReasonOrderPrecedence() == 4)
                {

                    csvbean.setCodeDenial4(reason.getDecReasonCode());
                    csvbean.setDenialDescription4(reason.getDecReasonCode());

                }
                
            }
            
            if(DecReasonTypeEnum.Override == reason.getDecReasonTypeId())
            {
                overrideCodeCntr++;
                switch(overrideCodeCntr)
                {
                    case 1:
                        csvbean.setCodeOverride1(reason.getDecReasonCode());
                        csvbean.setReasonDescription1(reason.getDecReasonDescription());
                    break;
                    
                    case 2:
                        csvbean.setCodeOverride2(reason.getDecReasonCode());
                        csvbean.setReasonDescription2(reason.getDecReasonDescription());
                    break;
                    
                    case 3:
                        csvbean.setCodeOverride3(reason.getDecReasonCode());
                        csvbean.setReasonDescription3(reason.getDecReasonDescription());
                    break;
                    
                }
                
            }
            
             
        }
        
    }
    /**
     * Sets the list of DecPTIDTI values into the corresponding fields of SingleFeedCSVByNameBean
     * @param csvbean
     * @param dto
     */
    private void setCreditDecisionPTIDTI(SingleFeedCSVByNameBean csvbean, List<DecPTIDTI> dto)
    {
        for (String entityType : entityTypeList) {
            
            switch (entityType) {
            
            case ENTITY_APPLICANT_TXT:
                if (csvbean.getApplicantRatioDebtServiceHousing() == 0.0) {
                    for (DecPTIDTI ptidti : dto) {
                        switch (ptidti.getPtidti_txt()) {
                        case "DTI":
                            csvbean.setApplicantRatioDebtServiceTotal(ptidti.getPtidti_num());
                            break;

                        case "LTV":
                            csvbean.setApplicantRatioLoantoValue(ptidti.getPtidti_num());
                            break;

                        }
                    }
                }
                break;

            case ENTITY_COAPPLICANT1_TXT:
                if (csvbean.getCoApplicantRatioDebtServiceHousing() == 0.0) {
                    for (DecPTIDTI ptidti : dto) {
                        switch (ptidti.getPtidti_txt()) {
                        case "DTI":
                            csvbean.setCoApplicantRatioDebtServiceTotal(ptidti.getPtidti_num());
                            break;

                        case "LTV":
                            csvbean.setCoApplicantRatioLoantoValue(ptidti.getPtidti_num());
                            break;

                        }
                    }
                }
                break;
                
            case ENTITY_COAPPLICANT2_TXT:
                if (csvbean.getCoApplicant2RatioDebtServiceHousing() == 0.0) {
                    for (DecPTIDTI ptidti : dto) {
                        switch (ptidti.getPtidti_txt()) {
                        case "DTI":
                            csvbean.setCoApplicant2RatioDebtServiceTotal(ptidti.getPtidti_num());
                            break;

                        case "LTV":
                            csvbean.setCoApplicant2RatioLoantoValue(ptidti.getPtidti_num());
                            break;

                        }
                    }
                }
                break;

            case ENTITY_COSIGNER1_TXT:
                if (csvbean.getCoSignerRatioDebtServiceHousing() == 0.0 ) {
                    for (DecPTIDTI ptidti : dto) {
                        switch (ptidti.getPtidti_txt()) {
                        case "DTI":
                            csvbean.setCoSignerRatioDebtServiceTotal(ptidti.getPtidti_num());
                            break;

                        case "LTV":
                            csvbean.setCoSignerRatioLoantoValue(ptidti.getPtidti_num());
                            break;

                        }
                    }
                }
                break;

            case ENTITY_COSIGNER2_TXT:
                if (csvbean.getCoSigner2RatioDebtServiceHousing() == 0.0) {
                    for (DecPTIDTI ptidti : dto) {
                        switch (ptidti.getPtidti_txt()) {
                        case "DTI":
                            csvbean.setCoSigner2RatioDebtServiceTotal(ptidti.getPtidti_num());
                            break;

                        case "LTV":
                            csvbean.setCoSigner2RatioLoantoValue(ptidti.getPtidti_num());
                            break;

                        }
                    }
                }
                break;
            }

        }
    }
    
    /**
     * 
     * @param requestId of the credit_request 
     * @param dto CreditRequestDTO object for building SingleFeedCSVByNameBean for this request_id
     * @return this object instance
     */
    
    public SingleFeedCSVByNameBuilderImpl setCreditRequestInfo(String requestId, CreditRequestDTO dto)
    {
        SingleFeedCSVByNameBean csvbean = getBean(requestId);
        setCreditRequestInfo(csvbean,dto);
        beanMap.put(requestId, csvbean);
        return this;

    }
    
    /**
     * 
     * @param requestId of the credit_request 
     * @param dto CreditRequestorDTO object for building SingleFeedCSVByNameBean for this request_id
     * @return this object instance
     */
    
    public SingleFeedCSVByNameBuilderImpl setCreditRequestorInfo(String requestId, List<CreditRequestorDTO> dto)
    {
        SingleFeedCSVByNameBean csvbean = getBean(requestId);
        setCreditRequestorInfo(csvbean,dto);
        beanMap.put(requestId, csvbean);
        return this;
        
    }

    /**
     * 
     * @param requestId of the credit_request 
     * @param dto IntermediateValuesDTO object for building SingleFeedCSVByNameBean for this request_id
     * @return this object instance
     */
    public SingleFeedCSVByNameBuilderImpl setIntermediateValues(String requestId, IntermediateValuesDTO dto)
    {
        SingleFeedCSVByNameBean csvbean = getBean(requestId);
        setIntermediateValues(csvbean,dto);
        beanMap.put(requestId, csvbean);
        return this;
        
    }
    
    /**
     * 
     * @param requestId of the credit_request 
     * @param dto CreditDecisionsDTO object for building SingleFeedCSVByNameBean for this request_id
     * @return this object instance
     */
    
    public SingleFeedCSVByNameBuilderImpl setCreditDecisionReasons(String requestId, CreditDecisionsDTO dto)
    {
        SingleFeedCSVByNameBean csvbean = getBean(requestId); 
        
        csvbean.setDateAction(DateFormatter.formatDate(DateFormatter.FORMAT_MMDDYYY, dto.getReceivedDt()));
        setCreditDecisionReasons(csvbean,dto);
        setCreditDecisionPTIDTI(csvbean, dto.getDecPtiDti());

        beanMap.put(requestId, csvbean);
        return this;
        
        
    }
    
    /**
     * SingleFeedBuilder interface method to call and get the list of beans of type SingleFeedCSVByNameBean
     * 
     */
    @Override
    public List<SingleFeedCSVByNameBean> buildBeans() {
        
        return new ArrayList<SingleFeedCSVByNameBean>(beanMap.values());
    }


    
}
