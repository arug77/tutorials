package com.cmsinc.origenate.tool;

import java.beans.IntrospectionException;
import java.io.Writer;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import com.opencsv.CSVWriter;
import com.opencsv.bean.BeanToCsv;
import com.opencsv.bean.ColumnPositionMappingStrategy;
import com.opencsv.bean.HeaderColumnNameTranslateMappingStrategy;
import com.opencsv.bean.MappingStrategy;
/**
 * 
 * class to provide methods to accept list of beans and convert them as comma separated values
 * separator can be specified
 * 
 * @author DVJ2
 *
 */
public class SingleFeedCSVWriterImpl implements SingleFeedCSVWriter {

    public static final String[] columns = new String[]{"referenceNumber","bankID","userid","agentID","applicationID","applicantFirstName","applicantMiddleName","applicantLastname","applicantAddressLine1","applicantAddressCity","applicantAddressState","applicantAddressZip","applicantDOB","applicantPhoneHome","applicantIncome","applicantNumberTaxID",
        "coApplicantFirstName","coApplicantMiddleName","coApplicantLastname","coApplicantAddressLine1","coApplicantAddressCity","coApplicantAddressState","coApplicantAddressZip","coApplicantDOB","coApplicantPhoneHome","coApplicantIncome","coApplicantNumberTaxID",
        "coApplicant2FirstName","coApplicant2MiddleName","coApplicant2Lastname","coApplicant2AddressLine1","coApplicant2AddressCity","coApplicant2AddressState","coApplicant2AddressZip","coApplicant2DOB","coApplicant2PhoneHome","coApplicant2Income","coApplicant2NumberTaxID",
        "coSignerFirstName","coSignerMiddleName","coSignerLastname","coSignerAddressLine1","coSignerAddressCity","coSignerAddressState","coSignerAddressZip","coSignerDOB","coSignerPhoneHome","coSignerIncome","coSignerNumberTaxID",
        "coSigner2FirstName","coSigner2MiddleName","coSigner2Lastname","coSigner2AddressLine1","coSigner2AddressCity","coSigner2AddressState","coSigner2AddressZip","coSigner2DOB","coSigner2PhoneHome","coSigner2Income","coSigner2NumberTaxID",
        "reqeustedLoan","originalLoanBalance","dateAction","dateAppReceived","codeLoanType","codeAction","codeOriginationSource","codeDenial1","denialDescription1","codeDenial2","denialDescription2","codeDenial3","denialDescription3","codeDenial4","denialDescription4","codeProduct","codeOverride1","reasonDescription1","codeOverride2","reasonDescription2","codeOverride3","reasonDescription3","codeOfficer",
        "applicantCreditNumberInquiries","applicantCreditNumberMajorTotalDelinquencies","applicantCreditNumberMinorTotalDelinquencies","applicantCreditNumberSatisfactoryAccounts","applicantCreditScore","applicantTotalBankruptcies","applicantTotalCollections",
        "coApplicantCreditNumberInquiries","coApplicantCreditNumberMajorTotalDelinquencies","coApplicantCreditNumberMinorTotalDelinquencies","coApplicantCreditNumberSatisfactoryAccounts","coApplicantCreditScore","coApplicantTotalBankruptcies","coApplicantTotalCollections",
        "coApplicant2CreditNumberInquiries","coApplicant2CreditNumberMajorTotalDelinquencies","coApplicant2CreditNumberMinorTotalDelinquencies","coApplicant2CreditNumberSatisfactoryAccounts","coApplicant2CreditScore","coApplicant2TotalBankruptcies","coApplicant2TotalCollections","coSignerCreditNumberInquiries",
        "coSignerCreditNumberMajorTotalDelinquencies","coSignerCreditNumberMinorTotalDelinquencies","coSignerCreditNumberSatisfactoryAccounts","coSignerCreditScore","coSignerTotalBankruptcies","coSignerTotalCollections",
        "coSigner2CreditNumberInquiries","coSigner2CreditNumberMajorTotalDelinquencies","coSigner2CreditNumberMinorTotalDelinquencies","coSigner2CreditNumberSatisfactoryAccounts","coSigner2CreditScore","coSigner2TotalBankruptcies","coSigner2TotalCollections","rateInterestOriginal","termLoanOriginal","applicantRatioDebtServiceHousing","applicantRatioDebtServiceTotal","applicantRatioLoantoValue",
        "coApplicantRatioDebtServiceHousing","coApplicantRatioDebtServiceTotal","coApplicantRatioLoantoValue","coApplicant2RatioDebtServiceHousing","coApplicant2RatioDebtServiceTotal","coApplicant2RatioLoantoValue","coSignerRatioDebtServiceHousing","coSignerRatioDebtServiceTotal","coSignerRatioLoantoValue","coSigner2RatioDebtServiceHousing","coSigner2RatioDebtServiceTotal","coSigner2RatioLoantoValue","dealerLienName"};
    
    @Override
    public void writetoCSV(MappingStrategy strategy, List<SingleFeedCSVByNameBean> beans, Writer writer) {
       
        BeanToCsv<SingleFeedBean> csvwriter = new BeanToCsv<SingleFeedBean>();
        csvwriter.write(strategy, writer, beans);
         
    }

    @Override
    public void writetoCSVByColumnPosition(List<SingleFeedCSVByNameBean> beans, Writer writer, char separator) {
       
        ColumnPositionMappingStrategy<SingleFeedCSVByNameBean> strategy = new ColumnPositionMappingStrategy<>();
        strategy.setType(SingleFeedCSVByNameBean.class);
        strategy.setColumnMapping(columns);
        
        CSVWriter csvWriter = new CSVWriter(writer, separator);
        BeanToCsv<SingleFeedBean> beantoCSV = new BeanToCsv<SingleFeedBean>();
        beantoCSV.write((ColumnPositionMappingStrategy)strategy, csvWriter, beans);
         
    }
    
    public static Map getColumnMapping()
    {
        HashMap<String, String> map = new HashMap<String, String>();
        map.put("referenceNumber","referenceNumber");
        map.put("bankID","bankID");
        map.put("userid","userid");
        map.put("agentID","agentID");
        map.put("applicationID","applicationID");
        map.put("applicantFirstName","applicantFirstName");
        map.put("applicantMiddleName","applicantMiddleName");
        map.put("applicantLastname","applicantLastname");
        map.put("applicantAddressLine1","applicantAddressLine1");
        map.put("applicantAddressCity","applicantAddressCity");
        map.put("applicantAddressState","applicantAddressState");
        map.put("applicantAddressZip","applicantAddressZip");
        map.put("applicantDOB","applicantDOB");
        map.put("applicantPhoneHome","applicantPhoneHome");
        map.put("applicantIncome","applicantIncome");
        map.put("applicantNumberTaxID","applicantNumberTaxID");
        map.put("coApplicantFirstName","coApplicantFirstName");
        map.put("coApplicantMiddleName","coApplicantMiddleName");
        map.put("coApplicantLastname","coApplicantLastname");
        map.put("coApplicantAddressLine1","coApplicantAddressLine1");
        map.put("coApplicantAddressCity","coApplicantAddressCity");
        map.put("coApplicantAddressState","coApplicantAddressState");
        map.put("coApplicantAddressZip","coApplicantAddressZip");
        map.put("coApplicantDOB","coApplicantDOB");
        map.put("coApplicantPhoneHome","coApplicantPhoneHome");
        map.put("coApplicantIncome","coApplicantIncome");
        map.put("coApplicantNumberTaxID","coApplicantNumberTaxID");
        map.put("coApplicant2FirstName","coApplicant2FirstName");
        map.put("coApplicant2MiddleName","coApplicant2MiddleName");
        map.put("coApplicant2Lastname","coApplicant2Lastname");
        map.put("coApplicant2AddressLine1","coApplicant2AddressLine1");
        map.put("coApplicant2AddressCity","coApplicant2AddressCity");
        map.put("coApplicant2AddressState","coApplicant2AddressState");
        map.put("coApplicant2AddressZip","coApplicant2AddressZip");
        map.put("coApplicant2DOB","coApplicant2DOB");
        map.put("coApplicant2PhoneHome","coApplicant2PhoneHome");
        map.put("coApplicant2Income","coApplicant2Income");
        map.put("coApplicant2NumberTaxID","coApplicant2NumberTaxID");
        map.put("coSignerFirstName","coSignerFirstName");
        map.put("coSignerMiddleName","coSignerMiddleName");
        map.put("coSignerLastname","coSignerLastname");
        map.put("coSignerAddressLine1","coSignerAddressLine1");
        map.put("coSignerAddressCity","coSignerAddressCity");
        map.put("coSignerAddressState","coSignerAddressState");
        map.put("coSignerAddressZip","coSignerAddressZip");
        map.put("coSignerDOB","coSignerDOB");
        map.put("coSignerPhoneHome","coSignerPhoneHome");
        map.put("coSignerIncome","coSignerIncome");
        map.put("coSignerNumberTaxID","coSignerNumberTaxID");
        map.put("coSigner2FirstName","coSigner2FirstName");
        map.put("coSigner2MiddleName","coSigner2MiddleName");
        map.put("coSigner2Lastname","coSigner2Lastname");
        map.put("coSigner2AddressLine1","coSigner2AddressLine1");
        map.put("coSigner2AddressCity","coSigner2AddressCity");
        map.put("coSigner2AddressState","coSigner2AddressState");
        map.put("coSigner2AddressZip","coSigner2AddressZip");
        map.put("coSigner2DOB","coSigner2DOB");
        map.put("coSigner2PhoneHome","coSigner2PhoneHome");
        map.put("coSigner2Income","coSigner2Income");
        map.put("coSigner2NumberTaxID","coSigner2NumberTaxID");
        map.put("reqeustedLoan","reqeustedLoan");
        map.put("originalLoanBalance","originalLoanBalance");
        map.put("dateAction","dateAction");
        map.put("dateAppReceived","dateAppReceived");
        map.put("codeLoanType","codeLoanType");
        map.put("codeAction","codeAction");
        map.put("codeOriginationSource","codeOriginationSource");
        map.put("codeDenial1","codeDenial1");
        map.put("denialDescription1","denialDescription1");
        map.put("codeDenial2","codeDenial2");
        map.put("denialDescription2","denialDescription2");
        map.put("codeDenial3","codeDenial3");
        map.put("denialDescription3","denialDescription3");
        map.put("codeDenial4","codeDenial4");
        map.put("denialDescription4","denialDescription4");
        map.put("codeProduct","codeProduct");
        map.put("codeOverride1","codeOverride1");
        map.put("reasonDescription1","reasonDescription1");
        map.put("codeOverride2","codeOverride2");
        map.put("reasonDescription2","reasonDescription2");
        map.put("codeOverride3","codeOverride3");
        map.put("reasonDescription3","reasonDescription3");
        map.put("codeOfficer","codeOfficer");
        map.put("applicantCreditNumberInquiries","applicantCreditNumberInquiries");
        map.put("applicantCreditNumberMajorTotalDelinquencies","applicantCreditNumberMajorTotalDelinquencies");
        map.put("applicantCreditNumberMinorTotalDelinquencies","applicantCreditNumberMinorTotalDelinquencies");
        map.put("applicantCreditNumberSatisfactoryAccounts","applicantCreditNumberSatisfactoryAccounts");
        map.put("applicantCreditScore","applicantCreditScore");
        map.put("applicantTotalBankruptcies","applicantTotalBankruptcies");
        map.put("applicantTotalCollections","applicantTotalCollections");
        map.put("coApplicantCreditNumberInquiries","coApplicantCreditNumberInquiries");
        map.put("coApplicantCreditNumberMajorTotalDelinquencies","coApplicantCreditNumberMajorTotalDelinquencies");
        map.put("coApplicantCreditNumberMinorTotalDelinquencies","coApplicantCreditNumberMinorTotalDelinquencies");
        map.put("coApplicantCreditNumberSatisfactoryAccounts","coApplicantCreditNumberSatisfactoryAccounts");
        map.put("coApplicantCreditScore","coApplicantCreditScore");
        map.put("coApplicantTotalBankruptcies","coApplicantTotalBankruptcies");
        map.put("coApplicantTotalCollections","coApplicantTotalCollections");
        map.put("coApplicant2CreditNumberInquiries","coApplicant2CreditNumberInquiries");
        map.put("coApplicant2CreditNumberMajorTotalDelinquencies","coApplicant2CreditNumberMajorTotalDelinquencies");
        map.put("coApplicant2CreditNumberMinorTotalDelinquencies","coApplicant2CreditNumberMinorTotalDelinquencies");
        map.put("coApplicant2CreditNumberSatisfactoryAccounts","coApplicant2CreditNumberSatisfactoryAccounts");
        map.put("coApplicant2CreditScore","coApplicant2CreditScore");
        map.put("coApplicant2TotalBankruptcies","coApplicant2TotalBankruptcies");
        map.put("coApplicant2TotalCollections","coApplicant2TotalCollections");
        map.put("coSignerCreditNumberInquiries","coSignerCreditNumberInquiries");
        map.put("coSignerCreditNumberMajorTotalDelinquencies","coSignerCreditNumberMajorTotalDelinquencies");
        map.put("coSignerCreditNumberMinorTotalDelinquencies","coSignerCreditNumberMinorTotalDelinquencies");
        map.put("coSignerCreditNumberSatisfactoryAccounts","coSignerCreditNumberSatisfactoryAccounts");
        map.put("coSignerCreditScore","coSignerCreditScore");
        map.put("coSignerTotalBankruptcies","coSignerTotalBankruptcies");
        map.put("coSignerTotalCollections","coSignerTotalCollections");
        map.put("coSigner2CreditNumberInquiries","coSigner2CreditNumberInquiries");
        map.put("coSigner2CreditNumberMajorTotalDelinquencies","coSigner2CreditNumberMajorTotalDelinquencies");
        map.put("coSigner2CreditNumberMinorTotalDelinquencies","coSigner2CreditNumberMinorTotalDelinquencies");
        map.put("coSigner2CreditNumberSatisfactoryAccounts","coSigner2CreditNumberSatisfactoryAccounts");
        map.put("coSigner2CreditScore","coSigner2CreditScore");
        map.put("coSigner2TotalBankruptcies","coSigner2TotalBankruptcies");
        map.put("coSigner2TotalCollections","coSigner2TotalCollections");
        map.put("rateInterestOriginal","rateInterestOriginal");
        map.put("termLoanOriginal","termLoanOriginal");
        map.put("applicantRatioDebtServiceHousing","applicantRatioDebtServiceHousing");
        map.put("applicantRatioDebtServiceTotal","applicantRatioDebtServiceTotal");
        map.put("applicantRatioLoantoValue","applicantRatioLoantoValue");
        map.put("coApplicantRatioDebtServiceHousing","coApplicantRatioDebtServiceHousing");
        map.put("coApplicantRatioDebtServiceTotal","coApplicantRatioDebtServiceTotal");
        map.put("coApplicantRatioLoantoValue","coApplicantRatioLoantoValue");
        map.put("coApplicant2RatioDebtServiceHousing","coApplicant2RatioDebtServiceHousing");
        map.put("coApplicant2RatioDebtServiceTotal","coApplicant2RatioDebtServiceTotal");
        map.put("coApplicant2RatioLoantoValue","coApplicant2RatioLoantoValue");
        map.put("coSignerRatioDebtServiceHousing","coSignerRatioDebtServiceHousing");
        map.put("coSignerRatioDebtServiceTotal","coSignerRatioDebtServiceTotal");
        map.put("coSignerRatioLoantoValue","coSignerRatioLoantoValue");
        map.put("coSigner2RatioDebtServiceHousing","coSigner2RatioDebtServiceHousing");
        map.put("coSigner2RatioDebtServiceTotal","coSigner2RatioDebtServiceTotal");
        map.put("coSigner2RatioLoantoValue","coSigner2RatioLoantoValue");
        map.put("dealerLienName","dealerLienName");        
       return map;
        
    }
    
    public static class CustomStrategy<T> extends HeaderColumnNameTranslateMappingStrategy {

        @Override
        public void setColumnMapping(Map columnMapping) {
            super.setColumnMapping(columnMapping);
            header = new String[columnMapping.size()];
            int i = 0;
            Iterator it = columnMapping.entrySet().iterator();
            
            while (it.hasNext()) {
                header[i] = ((String)((Entry)it.next()).getKey()).toUpperCase();
                i++;
            }
        }

         public String[] getHeader() {
             return header;
         }
       }

       public static class CustomBeanToCsv<T> extends BeanToCsv {
         @Override
         protected String[] processHeader(MappingStrategy mapper) throws IntrospectionException {
             if (mapper instanceof CustomStrategy) {
                 return ((CustomStrategy) mapper).getHeader();
             } else {
                 return super.processHeader(mapper);
             }
         }
       }

    
}
