package com.cmsinc.origenate.tool;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.cmsinc.origenate.util.ConnectionUtils;
import com.cmsinc.origenate.util.LogMsg;


public class CreditRequestorDAO {

    private Connection conn;
    private LogMsg log_obj;
    private int log_level;

    /**
     * Public constructor for creating an object of the class.
     * 
     * @param conn
     *            Database Connection Object
     * @param log_obj
     *            LogMsg object
     * @param log_level
     *            Log level from the ini
     */
    public CreditRequestorDAO(Connection conn, LogMsg log_obj, int log_level) {
        this.conn = conn;
        this.log_obj = log_obj;
        this.log_level = log_level;
    }

    /**
     * Gets the singlefeed data for this application
     * 
     * @param requestID
     *            The requestID of the app to get
     * @return Returns a List<CreditRequestorDTO> object populated with the singlefeed details
     * @throws Exception
     *             Throws an exception if an error occurs communicating with the database
     */
    public List<CreditRequestorDTO> getSingleFeedData(String requestID) throws Exception {
        List<CreditRequestorDTO> listRequestors = getRequestorsList(requestID);

        for(int i=0; i<listRequestors.size();i++){
            CreditRequestorDTO requestor = listRequestors.get(i);

            // Note: When setting the value, we do not want to set it to the local variable created, make sure to set directly into array
            // Here we have all the scoreNums for the requestor, store it in the requestorInfo Object
            listRequestors.get(i).setCreditScore(getScoreNumForRequestor(requestID, requestor.getRequestorID()));

            // Now getting the DTI for requestor, store it in the requestorInfo Object
            listRequestors.get(i).setRequestorRatioDebtServiceTotal(getDtiLtvForRequestor("DTI" ,requestID, requestor.getRequestorID()));

            // Now getting the LTV for requestor, store it in the requestorInfo Object
            listRequestors.get(i).setRequestorRatioLoantoValue(getDtiLtvForRequestor("LTV" ,requestID, requestor.getRequestorID()));
        }

        return listRequestors;
    }

    /**
     * Gets the requestor list for this particular application
     * 
     * @param requestID
     *            Request ID
     * @return List of Requestors
     * @throws Exception
     *             Throws an exception if an error occurs communicating with the database
     */
    private List<CreditRequestorDTO> getRequestorsList(String requestID) throws Exception {
        List<CreditRequestorDTO> listRequestors = new ArrayList<CreditRequestorDTO>();

        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;

        try {
            String sql = "SELECT r.entity_txt, r.requestor_id,r.SOC_SEC_NUM_TXT,r.FIRST_NAME_TXT,r.MIDDLE_NAME_TXT,r.LAST_NAME_TXT,r.BIRTH_DT,r.PHONE_NUMBER_TXT,r.TOT_ADJUSTED_INCOME_NUM, " +
                    "ra.request_id, ra.requestor_id, ra.STREET_NUMBER_TXT || ' ' ||ra.STREET_NAME_TXT || ' ' ||ra.STREET_TYPE_ID || ' ' || ra.STREET_DIR_CODE_TXT || ' ' || ra.APT_SUITE_BOX_TXT street_address, ra.CITY_TXT, ra.STATE_ID, ra.ZIPCODE_TXT, " +
                    "rbs.request_id, rbs.requestor_id, rbs.INQUIRIES_PAST_6_MONTHS_NUM, rbs.MAJOR_DEROGATORY_NUM, rbs.MINOR_DEROGATORY_NUM, rbs.SATISFACTORY_NUM " +
                    "FROM REQUESTOR r, REQUESTOR_ADDRESS ra, REQUESTOR_BUREAU_SUMMARY rbs, requestor_bureau_header rbh " +
                    "WHERE r.request_id = ? AND r.request_id = ra.request_id and r.request_id = rbs.request_id  and r.request_id  = rbh.request_id " +
                    "AND r.requestor_id > 0 and r.requestor_id = ra.requestor_id and r.requestor_id = rbs.requestor_id and r.requestor_id = rbh.requestor_id " +
                    "and ra.address_type_id = 0 and rbs.BUREAU_ID = rbh.BUREAU_ID and rbh.BUREAU_OF_RECORD_FLG = 1";

            preparedStatement = conn.prepareStatement(sql);
            preparedStatement.setInt(1, Integer.parseInt(requestID));
            resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                CreditRequestorDTO currentRequestor = new CreditRequestorDTO();

                currentRequestor.setRequestorEntityTxt(resultSet.getString("ENTITY_TXT"));
                currentRequestor.setRequestorID(resultSet.getInt("REQUESTOR_ID"));
                currentRequestor.setFirstName(resultSet.getString("FIRST_NAME_TXT"));
                currentRequestor.setMiddleName(resultSet.getString("MIDDLE_NAME_TXT"));
                currentRequestor.setLastname(resultSet.getString("LAST_NAME_TXT"));
                currentRequestor.setAddressLine1(resultSet.getString("STREET_ADDRESS"));
                currentRequestor.setAddressCity(resultSet.getString("CITY_TXT"));
                currentRequestor.setAddressState(resultSet.getString("STATE_ID"));
                currentRequestor.setAddressZip(resultSet.getString("ZIPCODE_TXT"));
                currentRequestor.setDOB(resultSet.getString("BIRTH_DT"));
                currentRequestor.setHomephone(resultSet.getString("PHONE_NUMBER_TXT"));
                currentRequestor.setIncome(resultSet.getString("TOT_ADJUSTED_INCOME_NUM"));
                currentRequestor.setTaxIDNumber(resultSet.getString("SOC_SEC_NUM_TXT"));
                currentRequestor.setCreditNumberInquiries(resultSet.getInt("INQUIRIES_PAST_6_MONTHS_NUM"));
                currentRequestor.setCreditNumberMajorTotalDelinquencies(resultSet.getInt("MAJOR_DEROGATORY_NUM"));
                currentRequestor.setCreditNumberMinorTotalDelinquencies(resultSet.getInt("MINOR_DEROGATORY_NUM"));
                currentRequestor.setCreditNumberSatisfactoryAccounts(resultSet.getInt("SATISFACTORY_NUM"));

                listRequestors.add(currentRequestor);
            }
        } catch (Exception e) {
            throw new Exception("Error getting export details", e);
        } finally {
            ConnectionUtils.closePreparedStatement(preparedStatement);
            ConnectionUtils.closeResultSet(resultSet);
        }

        return listRequestors;
    }

    /**
     * Gets the xref.Score_Num for the requested Requestor
     * 
     * @param requestID
     *            Request ID
     * @param requestorID
     *            Requestor ID
     * @return The Score_Num as an int
     * @throws Exception
     *             Throws an exception if an error occurs communicating with the database
     */
    private int getScoreNumForRequestor(String requestID, int requestorID) throws Exception {
        int scoreNum = 0;

        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;

        try {
            String sql = "select xref.SCORE_NUM from XREF_BUREAU_SCORE xref, requestor_bureau_header rbh " +
                    "where xref.request_id = ? and xref.request_id = rbh.request_id and xref.requestor_id = ? and xref.requestor_id = rbh.requestor_id " +
                    "and xref.BUREAU_ID = rbh.BUREAU_ID and rbh.BUREAU_OF_RECORD_FLG = 1 and rownum = 1 order by xref.score_id";

            preparedStatement = conn.prepareStatement(sql);
            preparedStatement.setInt(1, Integer.parseInt(requestID));
            preparedStatement.setInt(2, requestorID);
            resultSet = preparedStatement.executeQuery();

            if(resultSet.next()) {
                //We will get the score_num and add it to the list
                scoreNum = resultSet.getInt("SCORE_NUM");
            }
        } catch (Exception e) {
            throw new Exception("Error getting score_num for requestID - " + requestID + " requestorID " + requestorID, e);
        } finally {
            ConnectionUtils.closePreparedStatement(preparedStatement);
            ConnectionUtils.closeResultSet(resultSet);
        }

        return scoreNum;
    }

    /**
     * Get the DTI/LTV for the requestor
     * 
     * @param variableType
     *            String value of "LTV" or "DTI"
     * @param requestID
     *            Request ID
     * @param requestorID
     *            Requestor ID
     * @return The double value for the requested variable
     * @throws Exception
     *             Throws an exception if an error occurs communicating with the database
     */
    private double getDtiLtvForRequestor(String variableType, String requestID, int requestorID) throws Exception {
        double numVal = 0.0;

        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;

        try {
            String sql = "select crp.ptidti_num, crp.ptidti_txt from CREDIT_REQ_PTIDTI crp, requestor_bureau_header rbh " +
                    "where crp.request_id = ? and crp.request_id = rbh.request_id " +
                    "and crp.requestor_id = ? and crp.requestor_id = rbh.requestor_id " +
                    "and crp.BUREAU_ID = rbh.BUREAU_ID and rbh.BUREAU_OF_RECORD_FLG = 1 " +
                    "and crp.CATEGORY_TXT = 'CON' and crp.ptidti_txt = '" + variableType + "'";

            preparedStatement = conn.prepareStatement(sql);
            preparedStatement.setInt(1, Integer.parseInt(requestID));
            preparedStatement.setInt(2, requestorID);
            resultSet = preparedStatement.executeQuery();

            if(resultSet.next()) {
                //Found the value, setting the variable
                numVal = resultSet.getDouble("PTIDTI_NUM");
            }
        } catch (Exception e) {
            throw new Exception("Error getting " + variableType + " for requestID - " + requestID + " requestorID " + requestorID, e);
        } finally {
            ConnectionUtils.closePreparedStatement(preparedStatement);
            ConnectionUtils.closeResultSet(resultSet);
        }

        return numVal;
    }

    /**
     * Logging method for this class. We are using this wrapper because when it passes through this method, logs it will append the class name in
     * front of the log message.
     * 
     * @param msgLevel
     *            Level of the message
     * @param logMsg
     *            The message to log, as a string
     */
    public void log(int msgLevel, String logMsg) {
        if (LogMsg.isDebuggingEnabled(log_level, msgLevel)) {
            log_obj.FmtAndLogMsg("CreditRequestorDAO: " + logMsg);
        }
    }

}