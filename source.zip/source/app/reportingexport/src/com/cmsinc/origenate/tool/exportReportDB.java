/*
 * exportReportDB.java
 *
 * Created 9/22/04 by B. Snyder
 *
 * Used to generate a list of applications eligible for reporting DB export.
 * XML representations of these apps are generated, then a stylesheet is applied
 * to put them in a format a DB loading utility can understand.
 * The resulting files (1 per app) are jarred and ftped to reporting DB's server
 * Upon successful completion, an event is written to db.
 *
 * organization as follows:  files are written to subdir 'reportingdbexport'+evaluator_id
 * so as not to intermingle different client apps.  the jar file created is named similarly:
 * 'reportingdbexport'+evaluator_id+current date/time+'.jar'.  once files are jarred, they are deleted.
 *
 * 3/3/05 b.s. changed to make generic enough to support any series of xml transactions and stylesheets
 *
 * 4/25/05 b.s. enhanced to use a configurable query to drive selection criteria (uses begin/end dates
 *              as tokens)
 */

package com.cmsinc.origenate.tool;

import java.sql.*;
import java.io.*;
import java.net.*;

import com.cmsinc.origenate.util.DBConnection;
import com.cmsinc.origenate.util.IniFile;
import com.cmsinc.origenate.util.Query;
import com.cmsinc.origenate.xmldbt.GenX;
import com.cmsinc.origenate.cp.mpe.Mpe;
import java.util.jar.*;
import java.util.zip.*;
import java.text.*;
import java.sql.PreparedStatement;
import com.cmsinc.origenate.util.OWASPSecurity;
import com.cmsinc.origenate.util.SQLSecurity;
public class exportReportDB {

	public static void main (String args[]) {
		System.out.println("GenX Version: " + GenX.getGenXVersion());
		String export_dt = "";
		String export_tm = "";
		String export_end_dt = "";
		String export_end_tm = "";
		String websvr = "localhost";
		String ftpsvr = "";
		String ftpuser = "";
		String ftppwd = "";
		String xsl_list = "";
		String xml_trans_list = "";
		String export_name = "";
		String sHost = "";
		String sSIDname = "";
		String sUser = "";
		String sPass = "";
		String sPort = "";
		String sTNSEntry = "";
		String sIniFile = "";
		boolean singleFile = false;
		int evaluator_id = 0;
		int export_id = 0;
		String protocol = "http";
		String selection_query = "";
		int log_app = 0;
		int jar_xml = 0;
		IniFile ini = new IniFile();
		boolean b_logging = false;
		int log_level = 0;
		int i;
		Connection conn = null;
		String dir = "";
		Statement update_stmt = null;
		Statement stmt = null;
		ResultSet rs = null;
		boolean audit_flg = false;
        PreparedStatement ps = null;

/////////////////////////////////////// get args /////////////////////////////////////////
		if(args.length >= 4) {
			for(i=0;i<args.length;++i) {
				if ((args[i].charAt(0) != '-') && (args[i].length() > 1)){

                                   System.out.println("Invalid parm: "+args[i]);
                                   showUsage();
                                }
				switch (args[i].charAt(1)) {
					case 'c':
						try {
							if (Integer.parseInt(args[i].substring(2)) == 1)
	                   			protocol = "http";
							else if (Integer.parseInt(args[i].substring(2)) == 2)
								protocol = "https";
						}
						catch (Exception e) {
							System.out.println("Exception: Could not determine integer value for web protocol.  see usage");
						}
	                    break;
					case 'w':
	                    websvr = args[i].substring(2);
	                    break;
					case 'e':
						try {
							// get evaluator
	                    	evaluator_id = Integer.parseInt(args[i].substring(2));
						}
						catch (Exception e) {
							System.out.println("Exception: Could not determine integer value of evaluator.  see usage");
						}
	                    break;
					case 'q':
						try {
							// get extract id to get query
	                    	export_id = Integer.parseInt(args[i].substring(2));
						}
						catch (Exception e) {
							System.out.println("Exception: Could not determine integer value of extract id.  see usage");
						}
	                    break;
                                case 's':
                                        try {
                                        singleFile = args[i].substring(2).equals("1");
                                        }
                                        catch (Exception e) {
                                           System.out.println("Single file option must be 0 or 1: "+e.toString());
                                           showUsage();
                                        }
                    break;
					case 'd':
	                    export_dt = args[i].substring(2);
	                    break;
					case 'l':
						try {
							// get extract id to get query
	                    	if(Integer.parseInt(args[i].substring(2)) == 1)
	                    		b_logging = true;
						}
						catch (Exception e) {
							System.out.println("Exception: Could not determine logging value; defaulting to 0.  see usage");
						}
	                    break;
					case 't':
	                    export_tm = args[i].substring(2);
	                    break;
					case 'g':
	                    export_end_dt = args[i].substring(2);
	                    break;
					case 'n':
	                    export_end_tm = args[i].substring(2);
	                    break;
					case 'f':
	                    ftpsvr = args[i].substring(2);
	                    break;
					case 'j':
	                    jar_xml = Integer.parseInt(args[i].substring(2));
	                    break;
					case 'r':
	                    ftpuser = args[i].substring(2);
	                    break;
					case 'b':
	                    ftppwd = args[i].substring(2);
	                    break;
					case 'x':
						xsl_list = args[i].substring(2);
						break;
					case 'z':
						xml_trans_list = args[i].substring(2);
						break;
					case 'i':
						sIniFile = args[i].substring(2);
                                                //System.out.println("ini file = "+sIniFile);
						try {
							ini.readINIFile(sIniFile);

							sHost = ini.getINIVar("database.host", "");
							sPort = ini.getINIVar("database.port", "");
							sUser = ini.getINIVar("database.user", "");
							sPass = ini.getINIVar("database.password", "");
							sSIDname = ini.getINIVar("database.sid", "");
							sTNSEntry = ini.getINIVar("database.TNSEntry", "");
							try {
								log_level = Integer.parseInt(ini.getINIVar("debug.genx_debug_lvl","0"));
							}
							catch (Exception ex) {
								System.out.println("Caught exception reading ini file '"+ sIniFile + "' value for debug.genx_debug_lvl:" + ex.toString());
								log_level = 0;
							}

						} catch (Exception e) {
							System.out.println("Caught exception reading ini file '"+ sIniFile + "':" + e.toString());
						}
						break;
					case 'a':
						try {
							audit_flg = args[i].substring(2).equals("1");
						}
						catch (Exception e) {
						   System.out.println("Audit file option must be 0 or 1: "+e.toString());
						   showUsage();
						}
	                    break;
					default:
                    	System.out.println("Unknown argument.  see usage");
	                    showUsage();
    	                break;
				}
			}

			try {
				// make db connection
				DBConnection DBConnect = new DBConnection();

				if (sTNSEntry.length() == 0) {
					conn = DBConnect.getConnection(sHost, sSIDname, sUser, sPass, null, sPort,"");
				} else {
					// use tns entry if available
					conn = DBConnect.getConnectionTNS(sTNSEntry, sUser,  sPass, null);
				}
			}
			catch(Exception e) {
	        	System.out.println("Exception: could not create a connection with db information in supplied ini file.  see usage");
				showUsage();
	      	}

			try {
				// if either dates exist, check to see if they are valid
				if(export_dt.length() > 0) {
					if(export_dt.length() == 10 && Integer.parseInt(export_dt.substring(0,2)) > 0 && export_dt.indexOf("/") == 2 && Integer.parseInt(export_dt.substring(3,5)) > 0 && export_dt.indexOf("/",5) == 5 && Integer.parseInt(export_dt.substring(6,10)) > 1900 && export_dt.length() == 10) {
						// get date/time
						// there is a time provided
						if(export_tm.length() == 7) {
							if(Integer.parseInt(export_tm.substring(0,2)) >= 0 && export_tm.indexOf(":") == 2 && Integer.parseInt(export_tm.substring(3,5)) >= 0 && (export_tm.substring(5,7).equals("AM") || export_tm.substring(5,7).equals("PM")))
								export_dt = export_dt+" "+export_tm.substring(0,5)+" "+export_tm.substring(5,7);
							else
								throw new Exception("bad time");
						}
					}
					else
						throw new Exception("bad date");
				}
				if(export_end_dt.length() > 0) {
					if(export_end_dt.length() == 10 && Integer.parseInt(export_end_dt.substring(0,2)) > 0 && export_end_dt.indexOf("/") == 2 && Integer.parseInt(export_end_dt.substring(3,5)) > 0 && export_end_dt.indexOf("/",5) == 5 && Integer.parseInt(export_end_dt.substring(6,10)) > 1900 && export_end_dt.length() == 10) {
						// get date/time
						// there is a time provided
						if(export_end_tm.length() == 7) {
							if(Integer.parseInt(export_end_tm.substring(0,2)) >= 0 && export_end_tm.indexOf(":") == 2 && Integer.parseInt(export_end_tm.substring(3,5)) >= 0 && (export_end_tm.substring(5,7).equals("AM") || export_end_tm.substring(5,7).equals("PM")))
								export_end_dt = export_end_dt+" "+export_end_tm.substring(0,5)+" "+export_end_tm.substring(5,7);
							else
								throw new Exception("bad time");
						}
					}
					else
						throw new Exception("bad date");
				}
			}
			catch (Exception e) {
				System.out.println("Exception: Could not determine a valid date/time format.  see usage "+e);
				showUsage();
			}

			if (evaluator_id == 0) {
				System.out.println("Evaluator not supplied.  see usage");
				showUsage();
			}

			if (export_id == 0) {
				System.out.println("Extract ID not supplied.  see usage");
				showUsage();
			}

			if (xml_trans_list.length() == 0) {
				System.out.println("XML transaction list not supplied.  see usage");
				showUsage();
			}
		}
		else {
                   System.out.println("Parm count must be >= 4");
			showUsage();
		}
//////////////////////////////////// end get args ////////////////////////////////////////

		// get details about export
		try {
		    String sql =  "SELECT cde.data_extract_name_txt, cdq.query_txt, nvl(cde.write_app_flg,0) as write_app_flg  " +
						  "FROM config_data_extract cde, config_doc_queries cdq " +
	                      "WHERE cde.evaluator_id = ? " +
						  "AND cde.data_extract_id = ? " +
						  "AND cde.active_flg = 1 " +
						  "AND cde.evaluator_id = cdq.evaluator_id " +
						  "AND cde.selection_query_id = cdq.query_id";

    		// prepare statement to execute
    		ps = conn.prepareStatement(sql);
    		ps.setInt(1, evaluator_id);
    		ps.setInt(2,export_id);

    		// execute statement
    		rs = ps.executeQuery();
		    /*
			stmt  = conn.createStatement();
			rs = null;


			rs = stmt.executeQuery( "SELECT cde.data_extract_name_txt, cdq.query_txt, nvl(cde.write_app_flg,0) as write_app_flg  " +
									"FROM config_data_extract cde, config_doc_queries cdq " +
	                       			"WHERE cde.evaluator_id = " + evaluator_id + " " +
									"AND cde.data_extract_id = " + export_id + " " +
									"AND cde.active_flg = 1 " +
									"AND cde.evaluator_id = cdq.evaluator_id " +
									"AND cde.selection_query_id = cdq.query_id");
			*/
			if(rs.next()) {
				// name the export (for writing file), get selection query, and determine if we should log which apps we wrote
				export_name = rs.getString("data_extract_name_txt");
				selection_query = rs.getString("query_txt");
				log_app = rs.getInt("write_app_flg");
			}
			else {
			    try { if (rs != null) rs.close();} catch (Exception e) {e.printStackTrace();}
			    try { if (ps != null) ps.close();} catch (Exception e) {e.printStackTrace();}
				throw new Exception("Export not configured or not active in table config_data_extract");
			}
	    }
		catch (Exception e) {
	    	System.out.println("Exception: error getting export details. "+e);
			try { if (rs != null) rs.close();} catch (Exception e1) {e.printStackTrace();}
			try { if (ps != null) ps.close();} catch (Exception e1) {e.printStackTrace();}
			System.exit(0);
	    }
		finally {
			try { if (rs != null) rs.close();} catch (Exception e2) {e2.printStackTrace();}
			try { if (ps != null) ps.close();} catch (Exception e2) {e2.printStackTrace();}
		}

		// setup xsl stylesheet list
		String s_xsl = "";
		if(xsl_list.length() != 0) {
			s_xsl = protocol+"://"+websvr+"/origenate/xml/xsl/"+xsl_list.replaceAll(",",","+protocol+"://"+websvr+"/origenate/xml/xsl/");
                        System.out.println("Stylesheets: "+s_xsl);
                }

		// if logging is set, use debug level when writing apps
		if (!b_logging)
			log_level = 0;




//////////////// generate xml apps and write to files, returns directory where the files reside //////////////

		dir = writeXMLApps(evaluator_id, export_dt, export_end_dt, conn, s_xsl, xml_trans_list, export_name, selection_query, log_app, export_id, jar_xml, log_level,singleFile,audit_flg,sUser);

		DateFormat dateFormat = new SimpleDateFormat("MMddyyyy_HHmmss");
		java.util.Date now = new java.util.Date();

		if (jar_xml == 1 && !singleFile) {
			/////////////////////// archive files and compress ///////////////////////////////
			try {
				JarOutputStream jos = new JarOutputStream(new FileOutputStream(dir+"_"+dateFormat.format(now)+".jar"));
				compressArchive(dir,jos);
				jos.close();
			}
			catch (Exception e) {
				System.out.println("Exception: error creating jar file. "+e);
			}

			/////////////////////// ftp file if server is supplied /////////////////////////////
			if(ftpsvr.length() > 0) {
				ftpArchive(ftpsvr, ftpuser, ftppwd, dir+"_"+dateFormat.format(now)+".jar");
			}
		}
/////////////////////// when everything is complete, log an event ////////////////////
		try {
		    String s_sql =  "insert into event (event_id,event_type_id,event_dt,evaluator_id,user_id,additional_desc_txt) "+
						   "values "+
						   "(event_id_seq.nextval,3,sysdate,?,'SYSTEM',?)";

    		// prepare statement to execute
    		ps = conn.prepareStatement(s_sql);
    		ps.setInt(1, evaluator_id);
    		ps.setString(2,export_name);

    		// execute statement
    		rs = ps.executeQuery();

		}
		catch (Exception e) {
			e.printStackTrace();
		}
		finally {
		    try { if (rs != null) rs.close();} catch (Exception e1) {e1.printStackTrace();}
		    try { if (ps != null) ps.close();} catch (Exception e1) {e1.printStackTrace();}
		}

		/*
		try {
			String s_sql =  "insert into event (event_id,event_type_id,event_dt,evaluator_id,user_id,additional_desc_txt) "+
							"values "+
							"(event_id_seq.nextval,3,sysdate,"+evaluator_id+",'SYSTEM','"+export_name+"')";
			update_stmt = conn.createStatement();
			update_stmt.executeUpdate(s_sql);
		}
		catch (Exception e) {
			System.out.println("Exception: error logging event. "+e);
		}
		finally {
		    try { if (update_stmt != null) update_stmt.close();} catch (Exception e) {e.printStackTrace();}
		}
		*/
	} // main()  program

	//////////////////////////////// WRITES FILES //////////////////////////////////////
	// create xml, apply stylesheet and write output to a file for every app in selection criteria

	public static String writeXMLApps(int evaluator_id, String export_dt, String export_end_dt, Connection conn, String s_xsl, String s_trans, String export_name, String selection_query, int log_app, int export_id, int jar_xml, int log_level,boolean singleFile,boolean audit_flg,String sUser) {

		GenX genx = null;
		Mpe mpe = null;
		SimpleDateFormat sdf = new SimpleDateFormat("M/d/yyyy HH:mm:ss");
		String taskGroup = "";
                // the following is used when we are genrating a single file of output
                StringBuffer singleFileBuffer = new StringBuffer();
                String  singleFileName = "";

		StringBuffer auditFileBuffer = new StringBuffer();
		String  auditFileName = "", endOfLine = "\r\n", audit_firstLine ="", audit_lastLine="", file_dateCreate = "", audit_dateCreate = "", pipe = "|";
		int countCurrentDetailRecords = 0,countTotalRecords =0, countCloseDetailRecords=0;

		if(log_level > 0)
                   if (singleFile)
			System.out.println(sdf.format(new java.util.Date())+" preparing to aggregate apps, apply stylesheet and gen single file");
                   else
                        System.out.println(sdf.format(new java.util.Date())+" preparing to write files");

		// create genx object to generate xml
		if (genx == null) {
			try {
				// pass connection, debug level 0, no log file...if logging is on, it will write to standard out
				//genx = new GenX(conn, log_level);
				genx = new GenX(conn, 0);
			}
			catch (Exception e) {
				System.out.println("Exception: error creating genX object. "+e);
			}
		}



		// create mpe object to add nlsu fields to xml
		if (mpe == null) {
			try {
				mpe = new Mpe(conn);
			}
			catch (Exception e) {
				System.out.println("Exception: error creating Mpe object. "+e);
			}
		}

		ResultSet rs = null;
		Statement stmt = null;
		Statement update_stmt = null;
		File dir = null;
        PrintWriter out=null;
        PrintWriter out1=null;
		PreparedStatement ps = null;
		// make sure dir exists to write files to
			try {
                                System.out.println("Export dir: "+export_name+evaluator_id);
                                /** OWASP Top 10 2010 - A4 path manipluation
                				 * Change to the below code to fix vulnerabilities
                				 * TTP 324955
                				 */
                               // dir = new File(export_name+evaluator_id);
                                dir = new File(OWASPSecurity.validationCheck(export_name+evaluator_id, OWASPSecurity.DIRANDFILE));
				dir.mkdir();
			}
			catch (Exception e) {
				System.out.println("Exception: error creating directory to store xml files. "+e);
			}


                /* If the singleFile parm is set then we will aggregate all apps into a single xml string, ie) multiple IFX tags under a parent tag
                and then apply the specified stylesheet to generate a single output file.
                */
				if(singleFile || audit_flg)
				{
					DateFormat dateFormat1 = new SimpleDateFormat("MMddyyyy_HHmm");
					java.util.Date now = new java.util.Date();
					file_dateCreate = dateFormat1.format(now);
					DateFormat audit_Date = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
					audit_dateCreate = audit_Date.format(now);
				}
                if (singleFile) {
                   singleFileName=dir+File.separator+file_dateCreate+".dat";
                   System.out.println("Single File name: "+singleFileName);
                   singleFileBuffer.append("<?xml version=\"1.0\" encoding=\"ISO-8859-1\"?><CMSI><HeaderInfo>");
                }
				if(audit_flg){
					String dt_last_audit_file_create = getDtLastSuccessfulAudit(conn,evaluator_id,export_id);
					auditFileName="audit_"+file_dateCreate+".txt";
					System.out.println("Audit File name: "+auditFileName);
					audit_firstLine = auditFileName+ pipe + audit_dateCreate + pipe + audit_dateCreate + pipe + dt_last_audit_file_create + endOfLine;

					auditFileBuffer.append(audit_firstLine);
				}

		// query to retrieve apps to export
		try {
                        Query query = new Query(conn);

			// using query object instead //stmt = conn.createStatement();

			update_stmt = conn.createStatement();

			String s_xml = "";
			String s_audit = "", s_audit_currentDetail= "", s_audit_closeDetail = "";

			// TTP 324955 Security Remediation Fortify Scan
			// replace date tokens in the selection query with actual date values passed into the program
			String s_sql = selection_query.replaceAll("\\[begin_date\\]","to_date('"+export_dt+"', 'MM/DD/YYYY HH:MI AM')");
			s_sql = s_sql.replaceAll("\\[end_date\\]","to_date('"+export_end_dt+"', 'MM/DD/YYYY HH:MI AM')");
			// uncomment to prune written files for this extract from selection criteria list
			//s_sql += " MINUS SELECT request_id FROM credit_request_data_extract WHERE evaluator_id=" + evaluator_id + " AND data_extract_id=" + export_id;

			// using query object instead //rs = stmt.executeQuery(s_sql);
						// TTP 324955 Security Remediation Fortify Scan -- modifications to above code may prevent Fortify warnings
                        query.executeQuery(SQLSecurity.basicSanitize(s_sql));

			s_xsl += ", ";

			if(log_level > 0)   {
				System.out.println(sdf.format(new java.util.Date())+" selection query run: "+s_sql);
				System.out.println(sdf.format(new java.util.Date())+" FOUND "+query.getRowCount()+" APPS TO EXPORT");
                        }

                        if (singleFile) singleFileBuffer.append("<appcount>"+query.getRowCount()+"</appcount></HeaderInfo><Apps>");

			// for each app, create xml, apply stylesheet, and write to its own file

                        // FOR EACH APP FOUND
                        // FOR EACH APP FOUND
                        // FOR EACH APP FOUND

			while(query.next()) {


				// reset output and params for each app
				try {
					s_xml = "";
					genx.ResetParams();
	                                genx.bSetParam("DEFAULT_NETWORK","ORIGENATE");
					genx.bSetParam("REQUEST_ID",query.getColValue("request_id"));

					// generates xml according to transactions fed in (expects loanapprq for mpe additions) and applies stylesheets
					try {
						if(log_level > 0)
							System.out.println(sdf.format(new java.util.Date())+" call to genx begin");
						genx.setEncryptionParms(sUser.toLowerCase(),"ssn"); //dont encrypt ssn when creating the outfile 
						s_xml = genx.sGetXMLorThrow(s_trans);
						if(log_level > 0)
							System.out.println(sdf.format(new java.util.Date())+" call to genx end");
					}
					catch (Exception e) {
						System.out.println("Exception: error creating xml in genx for request id "+rs.getString("request_id")+". "+e);
					}

					if(log_level > 0)
						System.out.println(sdf.format(new java.util.Date())+" replacing non-printable chars begin");
					// replace non-printable chars in the xml...genx encodes ascii char so match &#25; for example
					s_xml = s_xml.replaceAll("&#[0-3][0-9];","");
					s_xml = s_xml.replaceAll("&#xfffd;","");
					if(log_level > 0)
						System.out.println(sdf.format(new java.util.Date())+" replacing non-printable chars end");

					try {
						if(log_level > 0)
							System.out.println(sdf.format(new java.util.Date())+" adding mpe values");
						s_xml = mpe.addNLSUFields(s_xml,Integer.toString(evaluator_id),query.getColValue("request_id"),"NONE");
						if(log_level > 0)
							System.out.println(sdf.format(new java.util.Date())+" added nslu via mpe");
						s_xml = mpe.addAdditionalFields(s_xml,Integer.toString(evaluator_id),query.getColValue("request_id"),taskGroup);
						if(log_level > 0)
							System.out.println(sdf.format(new java.util.Date())+" added additional fields via mpe");
					}
					catch (Exception e) {
						System.out.println("Exception: error adding nlsu and additional fields to the xml for request id "+query.getColValue("request_id")+". "+e);
					}

					// if there are stylesheets, loop thru stylesheet list applying xml
					if(s_xsl.length() > 2 && !singleFile) {
                                               //System.out.println("Stylesheets: "+s_xsl);
						if(log_level > 0)
							System.out.println(sdf.format(new java.util.Date())+" apply xsl begin");
						int i = 0;
						while(s_xsl.indexOf(",",i) != -1) {
							s_xml = genx.sApplyXSL(s_xml, s_xsl.substring(i,s_xsl.indexOf(",",i)),true);
							i = s_xsl.indexOf(",",i)+1;
						}
						if(log_level > 0)
							System.out.println(sdf.format(new java.util.Date())+" apply xsl end");
					} // apply stylesheets

                                        if (singleFile) {
                                           // first strip off xml start tag because we are adding this content to an aggregate and not starting a new xml doc
                                           s_xml = s_xml.substring(s_xml.indexOf("?>")+2);
                                           singleFileBuffer.append(s_xml);
                                        }
										if(audit_flg){
											//run query to see if its closed or current
											boolean current = checkIfCurrentDetail(conn,query.getColValue("request_id"),evaluator_id);
											countTotalRecords++;
											if(current){
												s_audit_currentDetail += createAuditRecord(conn,query.getColValue("request_id"),evaluator_id,current);
												countCurrentDetailRecords++; //unused but tracking in case it needs to be used in the future
												}
											else{
												countCloseDetailRecords++;
												s_audit_closeDetail += createAuditRecord(conn,query.getColValue("request_id"),evaluator_id,current);
												}
										}

				}
				catch (Exception e) {
					System.out.println("Exception: error processing app for request id "+query.getColValue("request_id")+". "+e);
				}

				// write output to file, and delete files when program terminates
				int err_flg = 0;
                                if (!singleFile) // when generating a single file output we are aggregating apps in singleFileBuffer so don't write individual files
				try {
					if(log_level > 0)
						System.out.println(sdf.format(new java.util.Date())+" write file begin");
					/** OWASP Top 10 2010 - A4 path manipluation
					 * Change to the below code to fix vulnerabilities
					 * TTp 324955
					 */
					//File app_xml_file =	new File(dir, query.getColValue("request_id")+".xml");
					File app_xml_file =	new File(dir, OWASPSecurity.validationCheck(query.getColValue("request_id")+".xml", OWASPSecurity.DIRANDFILE));
					app_xml_file.createNewFile();
					BufferedWriter app_xml_stream = new BufferedWriter(new FileWriter(app_xml_file),2048);
					try {
					app_xml_stream.write(s_xml);
					}
					catch (Exception e) {
						System.out.println("Exception: error writing xml to file "+query.getColValue("request_id")+".xml. "+e);
						app_xml_file.deleteOnExit();
						err_flg = 1;
					}
					app_xml_stream.close();
					if (jar_xml == 1)
						app_xml_file.deleteOnExit();

					if(log_level > 0)
						System.out.println(sdf.format(new java.util.Date())+" write file end");
				}
				catch (Exception e) {
					System.out.println("Exception: error creating file "+query.getColValue("request_id")+".xml. "+e);
					err_flg = 1;
				}

				try {
					if (log_app == 1) {
						if(log_level > 0)
							System.out.println(sdf.format(new java.util.Date())+" audit begin");

						String s_sql1 = "MERGE INTO credit_request_data_extract crde " +
									   "USING (select ? request_id, ? evaluator_id, ? data_extract_id from dual) d " +
									   "ON (crde.request_id = d.request_id AND crde.evaluator_id = d.evaluator_id AND crde.data_extract_id = d.data_extract_id) " +
									   "WHEN MATCHED THEN UPDATE SET generated_dt = sysdate, error_flg = ? " +
									   "WHEN NOT MATCHED THEN INSERT " +
									   "(request_id, evaluator_id, data_extract_id, generated_dt, error_flg) " +
									   "VALUES " +
									   "(?,?,?,sysdate,?)";
						 ps = conn.prepareStatement(s_sql1);
						 ps.setString(1, query.getColValue("request_id"));
						 ps.setInt(2, evaluator_id);
						 ps.setInt(3, export_id);
						 ps.setInt(4, err_flg);
						 ps.setString(5, query.getColValue("request_id"));
						 ps.setInt(6, evaluator_id);
						 ps.setInt(7, export_id);
						 ps.setInt(8, err_flg);
						 ps.executeQuery();
						 ps.close();
						/*
						update_stmt.executeUpdate(	"MERGE INTO credit_request_data_extract crde " +
													"USING (select "+query.getColValue("request_id")+" request_id, "+evaluator_id+" evaluator_id, "+export_id+" data_extract_id from dual) d " +
													"ON (crde.request_id = d.request_id AND crde.evaluator_id = d.evaluator_id AND crde.data_extract_id = d.data_extract_id) " +
													"WHEN MATCHED THEN UPDATE SET generated_dt = sysdate, error_flg = "+err_flg+" " +
													"WHEN NOT MATCHED THEN INSERT " +
													"(request_id, evaluator_id, data_extract_id, generated_dt, error_flg) " +
													"VALUES " +
													"("+query.getColValue("request_id")+","+evaluator_id+","+export_id+",sysdate,"+err_flg+")");
						*/
						if(log_level > 0)
							System.out.println(sdf.format(new java.util.Date())+" audit end");
					}
				}
				catch (Exception e) {
					System.out.println("Exception: error writing credit_request_data_extract record for file "+query.getColValue("request_id")+".xml. "+e);
				}



			} // while more apps to dump


                        // SINGLE FILE PROCESSING
                        // SINGLE FILE PROCESSING
                        // SINGLE FILE PROCESSING

                        if (singleFile) {
                          singleFileBuffer.append("</Apps></CMSI>"); // end aggregating all apps, now apply stylesheet
                          s_xml=singleFileBuffer.toString();


                          if(log_level > 0)
                          try {
                          out1 = new PrintWriter(new FileWriter(singleFileName.substring(0,singleFileName.indexOf(".dat"))+".xml"));
                          out1.print(s_xml);
                          out1.flush();
                          out1.close();
                          }
                          catch (Exception e1) {
                             System.out.println("Can not write single file xml debug output, error = "+e1.toString());
                             throw new Exception(e1);
                          }
                          // apply the style sheet and then write out the file
                          if(s_xsl.length() > 2) {
                                 //System.out.println("Stylesheets: "+s_xsl);
                                  if(log_level > 0)
                                          System.out.println(sdf.format(new java.util.Date())+" apply xsl for single file  begin");
                                  int i = 0;
                                  while(s_xsl.indexOf(",",i) != -1) {
                                          s_xml = genx.sApplyXSL(s_xml, s_xsl.substring(i,s_xsl.indexOf(",",i)),true);
                                          i = s_xsl.indexOf(",",i)+1;
                                  }
                                  if(log_level > 0)
                                          System.out.println(sdf.format(new java.util.Date())+" apply xsl for single file  end");
                          } // apply stylesheets


                          try {
                          out = new PrintWriter(new FileWriter(singleFileName));
                          out.print(s_xml);
                          out.flush();
                          out.close();
                          }
                          catch (Exception e1) {
                             System.out.println("Can not write single file output, error = "+e1.toString());
                             throw new Exception(e1);
                          }

                        } // single file processing

						if (audit_flg) {
						  s_audit = s_audit_currentDetail +  s_audit_closeDetail;
						  auditFileBuffer.append(s_audit);
						  audit_lastLine = auditFileName+ pipe + audit_dateCreate +  pipe +audit_dateCreate + pipe + countTotalRecords + pipe + countCloseDetailRecords ;
                          auditFileBuffer.append(audit_lastLine); // end aggregating all apps, now apply stylesheet

                          s_audit=auditFileBuffer.toString();


                          PrintWriter audit_print=null;
                          File auditFileName_file =	new File(dir,auditFileName);
						  auditFileName_file.createNewFile();
                          if(log_level > 0)
                          try {
                          audit_print = new PrintWriter(new FileWriter(auditFileName_file));
                          audit_print.print(s_audit);
                          audit_print.flush();
                          audit_print.close();
                          }
                          catch (Exception e1) {
                             System.out.println("Can not write audit file debug output, error = "+e1.toString());
                             throw new Exception(e1);
                          }
                          finally {
						    try{ if(audit_print != null) audit_print.close(); }catch(Exception e){e.printStackTrace();}
                          }

                          // now write the file
                          //PrintWriter out=null;
                          try {
								out = new PrintWriter(new FileWriter(auditFileName_file));
								out.print(s_audit);
								out.flush();
								out.close();

                          }
                          catch (Exception e1) {
                             System.out.println("Can not write audit file output, error = "+e1.toString());
                             throw new Exception(e1);
                          }
							updateDtLastSuccessfulAudit(conn,evaluator_id,export_id);
						if (jar_xml == 1 && !singleFile)
							auditFileName_file.deleteOnExit();
                        } // audit file processing


		}
		catch(Exception e) {
	    	System.out.println("Exception: error retrieving request_id resultset. "+e);
	    }
		finally {
			// close db connection when finished
			try{ if(out != null) out.close(); }catch(Exception e){e.printStackTrace();}
			try{ if(out1 != null) out1.close(); }catch(Exception e){e.printStackTrace();}
			try{ if(rs != null) rs.close(); }catch(Exception e){e.printStackTrace();}
	        try{ if(stmt != null) stmt.close(); }catch(Exception e){e.printStackTrace();}
	        try{ if(update_stmt != null) update_stmt.close(); }catch(Exception e){e.printStackTrace();}
			try{ if(ps != null) ps.close(); }catch(Exception e){e.printStackTrace();}
			if (genx != null) {
				try {genx = null;} catch (Exception e) {}
			}
			if (mpe != null) {
				try {mpe = null;} catch (Exception e) {}
			}
		}
		return dir.toString();
	}
	///////////////////////////////// END WRITE FILES //////////////////////////////////

	/////////////////////////////////// COMPRESS ////////////////////////////////////////
	// jars and compresses dir
	public static void compressArchive(String filename, JarOutputStream jos) {
		FileInputStream fis = null;
		try {
			File file = new File(filename);
			if (file.isDirectory()) {
				String directory = filename + "/";
				String[] files = file.list();
				for (int i = 0; i < files.length; i++)
					compressArchive(directory+files[i], jos);
				}
			else if (file.isFile()) {
				fis = new FileInputStream(file);
				int n = (int) file.length();
				byte[] b = new byte[n];
				fis.read(b, 0, n);
				fis.close();
				CRC32 crc = new CRC32();
				crc.update(b);
				JarEntry entry = new JarEntry(filename);
				entry.setMethod(ZipEntry.DEFLATED); // to not compress: entry.setMethod(ZipEntry.STORED);
				entry.setSize(n);
				entry.setCompressedSize(entry.getCompressedSize()); // to not compress: entry.setCompressedSize(n);
				entry.setCrc(crc.getValue());
				jos.putNextEntry(entry);
				jos.write(b, 0, n);
			}
		}
		catch (Exception e) {
			System.out.println("Exception: error jarring files. "+e);
		}
		finally {
		    try{ if(fis != null) fis.close(); }catch(Exception e1){e1.printStackTrace();}
		}
	}
	/////////////////////////////////// END COMPRESS ////////////////////////////////////////

	////////////////////////////////// XFER FILE ///////////////////////////////////////////
	// ftp a file in binary
	public static void ftpArchive(String svr, String usr, String pwd, String ftpfilename) {
		BufferedInputStream bis = null;
		BufferedOutputStream bos = null;
		try {
			// create ftp connection string

			URL url = new URL("ftp://"+usr+":"+pwd+"@"+svr+"/"+ftpfilename+";type=i");
			URLConnection ftp_conn = url.openConnection();
			bos = new BufferedOutputStream(ftp_conn.getOutputStream());
			bis = new BufferedInputStream(new FileInputStream(ftpfilename));
			int i;

			while ((i = bis.read()) != -1) {
				bos.write(i);
			}
		}
		catch(Exception e){
        	System.out.println("Exception: error ftping file. "+e);
      	}
		finally {
			if (bis != null) {
				try {bis.close();} catch (Exception e) {}
			}
			if (bos != null) {
				try {bos.close();} catch (Exception e) {}
			}
		}
	}
	////////////////////////////////// END XFER FILE ////////////////////////////////////////

	///////////////////////////////// USAGE ///////////////////////////////////////////////
	public static void showUsage() {
		System.out.println("Usage:");
        System.out.println("exportReportDB -w<webserver> -c<webprotocol> -f<ftpserver> -r<ftpusername> -b<ftppassword> -e<evaluator id> -d<begin date> -t<begin time> -g<end date> -n<end time> -x<stylesheets> -z<transactions> -q<extract id> -j<jar results> -i<ini file> -l<logging> -s0|1 (generate single file if 1, default 0)");
        System.out.println("------------------------------------------------------------------------------");
        System.out.println("webserver - web server name ([:port number] if necessary)");
		System.out.println("webprotocol - 1:http, 2:https; default is http");
		System.out.println("ftpserver - ftp server name (only ftps jar file, so jar must equal 1!)");
		System.out.println("ftpuser - ftp user");
		System.out.println("ftppassword - ftp password");
		System.out.println("evaluator id - Origenate's numeric id of evaluator to export");
		System.out.println("begin date - apps newer than this date/time will be exported (mask:  MM/DD/YYYY)");
		System.out.println("begin time - apps newer than this date/time will be exported (mask: HH:MM[AM/PM]) default is 12:00AM");
		System.out.println("end date - apps older than this date/time will be exported (mask:  MM/DD/YYYY)");
		System.out.println("end time - apps older than this date/time will be exported (mask: HH:MM[AM/PM]) default is 12:00AM");
		System.out.println("stylesheets - comma delimited list of stylesheets to apply (expected to live under protocol://websvr/origenate/xml/xsl/ directory)");
		System.out.println("transactions - comma delimited list of xml transactions to generate (must be valid as described by mstr_xml_transactions table)");
		System.out.println("extract id - identifier of the data extract to determine query for selection criteria and transaction name (in config_data_extract)");
		System.out.println("jar - 1:compress xml files into a java archive, 0:do not jar; default is 0");
		System.out.println("ini - path to origenate.ini file to use for configuration");
		System.out.println("logging - 1 to log, 0 to not log.  defaults to 0.  log level will be determined by origenate.ini");
		System.out.println("-s - aggregate all apps into a single xml file and then apply stylesheet to generate outputfile in styled format. Overrides ftp, jar");
		System.out.println("-a - if set to 1 we will create an audit file");
        System.exit(1);
	}
	///////////////////////////////////// END USAGE ///////////////////////////////////////////////

	public static String createAuditRecord(Connection conn, String request_id, int evaluator_id, boolean current){
		String audit_txt = "",endOfLine = "\r\n", pipe = "|", sql = "", detailRecordType ="2", client_app_id = "", app_status_id="", app_status_txt = "", init_dt ="", decision_status_id="", decision_status_txt="", booked_dt= "", total_verif_income = "", decision_ltv = "", decision_bureau_score = "", collat_total_value ="", contr_mature_dt = "", count_applicants = "", count_decisions = "", count_journal_items = "", count_checklist_items = "";

		//interim values not printed to audit file
		String latest_decision_ref_id = "", appseqno = "", bureau_of_record = "", bor_requestor_id ="" ;

		//only used for detail record type of 2
		String app_closed_dt = "";

		PreparedStatement ps = null;
		ResultSet rs = null;
		CallableStatement cs = null;

		if(current){
			detailRecordType = "1";
		}
		try {
			//1st query: CREDIT_REQUEST
			sql = "select CR.CLIENT_APP_ID, cr.App_status_id , "+
			" TO_CHAR(CR.INITIATION_DT,'MM/DD/YYYY') INITIATION_DT, " +
			" CR.DECISION_STATUS_ID , nvl(CR.LATEST_DEC_REF_ID,'') LATEST_DEC_REF_ID, CR.APPSEQNO, TO_CHAR(CR.AUDIT_LAST_UPDATED_DT,'MM/DD/YYYY') AUDIT_LAST_UPDATED_DT " +
			" from CREDIT_REQUEST CR " +
			" where CR.REQUEST_ID = ? and evaluator_id = ?  " ;

			ps = conn.prepareStatement(sql);
			ps.setString(1, request_id);
			ps.setInt(2,evaluator_id);
			rs = ps.executeQuery();
			if(rs.next()) {
				client_app_id = getStringValue(rs,"CLIENT_APP_ID");
				app_status_id = getStringValue(rs,"App_status_id");
				init_dt = getStringValue(rs,"INITIATION_DT");
				decision_status_id = getStringValue(rs,"DECISION_STATUS_ID");
				latest_decision_ref_id = getStringValue(rs,"LATEST_DEC_REF_ID"); ////interim value not printed to audit file - used for querying credit_req_decisions_ptidti
				appseqno = getStringValue(rs,"APPSEQNO");//interim value not printed to audit file
				app_closed_dt = getStringValue(rs,"AUDIT_LAST_UPDATED_DT"); //used for closed record
			}

			try { if (rs != null) rs.close();} catch (Exception e) {e.printStackTrace();}
			try { if (ps != null) ps.close();} catch (Exception e) {e.printStackTrace();}

			//extension of 1st query

			sql = "select mas.STATUS_CODE from MSTR_APP_STATUS MAS where mas.status_id = ?";
			ps = conn.prepareStatement(sql);
			ps.setString(1, app_status_id);
			rs = ps.executeQuery();
			if(rs.next()) {
				app_status_txt = getStringValue(rs,"STATUS_CODE");
			}

			try { if (rs != null) rs.close();} catch (Exception e) {e.printStackTrace();}
			try { if (ps != null) ps.close();} catch (Exception e) {e.printStackTrace();}

			//extension of 1st query
			sql = "select med.DECISION_TXT from MSTR_EVALUATOR_DECISION med where med.DECISION_ID = ?";
			ps = conn.prepareStatement(sql);
			ps.setString(1, decision_status_id);
			rs = ps.executeQuery();
			if(rs.next()) {
				decision_status_txt = getStringValue(rs,"DECISION_TXT");
			}

			try { if (rs != null) rs.close();} catch (Exception e) {e.printStackTrace();}
			try { if (ps != null) ps.close();} catch (Exception e) {e.printStackTrace();}

			if(current){ //if its not a current record detail don't run these queries
				//2nd query: CREDIT_REQUEST_ACTIVITY
				sql = "select  TO_CHAR(CRA.AUDIT_LAST_UPDATED_DT,'MM/DD/YYYY') date_booked " +
					" from CREDIT_REQUEST_ACTIVITY CRA " +
					" where CRA.ACTIVITY_STATUS_ID = 3 " + //-- (complete)
					" and CRA.ACTIVITY_ID= 23 " +// --(booked)
					" and CRA.REQUEST_ID = ? " +
					" and cra.task_group_id = 'CONTRACTADMIN' " ;
				ps = conn.prepareStatement(sql);
				ps.setString(1, request_id);
				rs = ps.executeQuery();
				if(rs.next()) {
					booked_dt = getStringValue(rs,"date_booked");
				}

				try { if (rs != null) rs.close();} catch (Exception e) {e.printStackTrace();}
			    try { if (ps != null) ps.close();} catch (Exception e) {e.printStackTrace();}

				//3rd query get ltv
				sql = "select VARIABLEVALUE from evapp_intermediate_value where variablename = 'Inter!LTV' and APPENTITY= 'ALL' and appseqno = ?" ;
				ps = conn.prepareStatement(sql);
				ps.setString(1, appseqno);
				rs = ps.executeQuery();
				if(rs.next()) {
					decision_ltv = getStringValue(rs,"VARIABLEVALUE");
				}
				try { if (rs != null) rs.close();} catch (Exception e) {e.printStackTrace();}
			    try { if (ps != null) ps.close();} catch (Exception e) {e.printStackTrace();}

					// interim query
				sql = " SELECT nvl(rbh.BUREAU_ID, '') BUREAU_ID,  app.requestor_type_id, nvl(app.requestor_id,'') requestor_id " +
					" FROM credit_request cr, REQUESTOR_BUREAU_HEADER rbh, requestor app " +
					" WHERE cr.request_id =  ? " +
					" AND cr.request_id = rbh.request_id " +
					" AND cr.request_id = app.request_id " +
					" AND app.requestor_id = rbh.requestor_id " +
					" AND 	  rbh.bureau_of_record_flg   = 1 " +
					" AND     app.requestor_type_id in (-1,0) " +
					" ORDER BY app.requestor_type_id asc " ;
				ps = conn.prepareStatement(sql);
				ps.setString(1, request_id);
				rs = ps.executeQuery();
				if(rs.next()) {
					bureau_of_record = getStringValue(rs,"BUREAU_ID"); //interim value not printed to audit file
					bor_requestor_id = getStringValue(rs,"requestor_id"); //interim value not printed to audit file

				}

				try { if (rs != null) rs.close();} catch (Exception e) {e.printStackTrace();}
			    try { if (ps != null) ps.close();} catch (Exception e) {e.printStackTrace();}

				if(!bureau_of_record.equals("") && !bor_requestor_id.equals("")) {
					//4th query: REQUESTOR_BUREAU_SUMMARY
					sql = "select SCORE_OF_GRADE_NUM " +
						" from REQUESTOR_BUREAU_SUMMARY " +
						" where request_id = ? " +
						" and BUREAU_ID = ? " +
						" and requestor_id = ? " ;
					ps = conn.prepareStatement(sql);
					ps.setString(1, request_id);
					ps.setString(2, bureau_of_record);
					ps.setString(3, bor_requestor_id);
					rs = ps.executeQuery();
					if(rs.next()) {
						decision_bureau_score = getStringValue(rs,"SCORE_OF_GRADE_NUM");
					}
					try { if (rs != null) rs.close();} catch (Exception e) {e.printStackTrace();}
			        try { if (ps != null) ps.close();} catch (Exception e) {e.printStackTrace();}
				}

				//5th query: CREDIT_REQ_CONTR_FIN
				sql = "select TO_CHAR(MATURITY_DT,'MM/DD/YYYY') MATURITY_DT " +
					" from CREDIT_REQ_CONTR_FIN " +
					" where request_id = ? " +
					" and appseqno = ? " ;
				ps = conn.prepareStatement(sql);
				ps.setString(1, request_id);
				ps.setString(2, appseqno);
				rs = ps.executeQuery();
				if(rs.next()) {
					contr_mature_dt = getStringValue(rs,"MATURITY_DT");
				}

				try { if (rs != null) rs.close();} catch (Exception e) {e.printStackTrace();}
			    try { if (ps != null) ps.close();} catch (Exception e) {e.printStackTrace();}

				//6th query count on requestor_header
				sql = "select COUNT(1) count_applicants from requestor_header where request_id = ? and requestor_type_id >=0";
				ps = conn.prepareStatement(sql);
				ps.setString(1, request_id);
				rs = ps.executeQuery();
				if(rs.next()) {
					count_applicants = getStringValue(rs,"count_applicants");
				}

				try { if (rs != null) rs.close();} catch (Exception e) {e.printStackTrace();}
			    try { if (ps != null) ps.close();} catch (Exception e) {e.printStackTrace();}

				//7th query count on CREDIT_REQ_DECISIONS_EVALUATOR
				sql = "select COUNT(1) count_decisions from CREDIT_REQ_DECISIONS_EVALUATOR where request_id = ?";
				ps = conn.prepareStatement(sql);
				ps.setString(1, request_id);
				rs = ps.executeQuery();
				if(rs.next()) {
					count_decisions = getStringValue(rs,"count_decisions");
				}

				try { if (rs != null) rs.close();} catch (Exception e) {e.printStackTrace();}
			    try { if (ps != null) ps.close();} catch (Exception e) {e.printStackTrace();}

				//8th query count on CREDIT_REQUEST_JOURNAL
				sql = "select COUNT(1) count_journal_items from CREDIT_REQUEST_JOURNAL where request_id = ?";
				ps = conn.prepareStatement(sql);
				ps.setString(1, request_id);
				rs = ps.executeQuery();
				if(rs.next()) {
					count_journal_items = getStringValue(rs,"count_journal_items");
				}

				try { if (rs != null) rs.close();} catch (Exception e) {e.printStackTrace();}
			    try { if (ps != null) ps.close();} catch (Exception e) {e.printStackTrace();}

				//9th query count on CREDIT_REQ_CHECKLIST_ITEM
				sql = "select COUNT(1) count_checklist_items from CREDIT_REQ_CHECKLIST_ITEM where request_id = ? and evaluator_id = ?";
				ps = conn.prepareStatement(sql);
				ps.setString(1, request_id);
				ps.setInt(2, evaluator_id);
				rs = ps.executeQuery();
				if(rs.next()) {
					count_checklist_items = getStringValue(rs,"count_checklist_items");
				}

				try { if (rs != null) rs.close();} catch (Exception e) {e.printStackTrace();}
			    try { if (ps != null) ps.close();} catch (Exception e) {e.printStackTrace();}


				//10th query get total_verif_income
				sql = "select VARIABLEVALUE from evapp_intermediate_value where appseqno = ? and VARIABLENAME = 'Inter!TotalVerifIncome' and appentity = 'ALL'";
				ps = conn.prepareStatement(sql);
				ps.setString(1, appseqno);
				rs = ps.executeQuery();
				if(rs.next()) {
					total_verif_income = getStringValue(rs,"VARIABLEVALUE");
				}

				try { if (rs != null) rs.close();} catch (Exception e) {e.printStackTrace();}
			    try { if (ps != null) ps.close();} catch (Exception e) {e.printStackTrace();}


				//call function to set collat_total_value
				cs = conn.prepareCall("{? = call GET_COLLATERAL_TOTAL_VALUE(?, ?)}");
				cs.registerOutParameter(1, Types.VARCHAR);
				cs.setInt(2, Integer.parseInt(request_id));
				cs.setInt(3, evaluator_id);
				cs.execute();
				collat_total_value = cs.getString(1);
				if(collat_total_value == null)
					collat_total_value = "";

				try {cs.close();} catch (Exception e) {}
			}

		}
		catch (Exception e) {
	    	System.out.println("Exception caught in exportReportDB.java function createAuditRecord "+e);
	    }
		finally {
			try { if (rs != null) rs.close();} catch (Exception e) {e.printStackTrace();}
			try { if (ps != null) ps.close();} catch (Exception e) {e.printStackTrace();}
			try { if (cs != null) cs.close();} catch (Exception e) {e.printStackTrace();}
		}

		audit_txt = detailRecordType + pipe + request_id + pipe + client_app_id + pipe + app_status_txt + pipe;
		if(current){
			audit_txt += init_dt + pipe + booked_dt + pipe + total_verif_income + pipe;
			audit_txt += decision_ltv + pipe + decision_status_txt + pipe + decision_bureau_score + pipe;
			audit_txt += collat_total_value + pipe + contr_mature_dt + pipe + count_applicants + pipe;
			audit_txt += count_decisions + pipe + count_journal_items + pipe + count_checklist_items;
			audit_txt += endOfLine;
		}
		else{
			audit_txt += app_closed_dt + endOfLine;
		}
		//System.out.println(audit_txt);
		return audit_txt;
	}
	public static void updateDtLastSuccessfulAudit(Connection conn, int evaluator_id, int export_id){
		PreparedStatement ps = null;
		String updateSql = "update config_data_extract " +
			" set audit_file_last_create_dt = sysdate " +
			" where EVALUATOR_ID = ? AND data_extract_id = ?";
		try {
			ps = conn.prepareStatement(updateSql);
			ps.setInt(1, evaluator_id);
			ps.setInt(2, export_id);
			ps.execute();
			try { if (ps != null) ps.close();} catch (Exception e) {e.printStackTrace();}
		}
		catch (Exception e) {
	    	System.out.println("Exception caught in exportReportDB.java function updateDtLastSuccessfulAudit "+e);
	    }
		finally {
			try { if (ps != null) ps.close();} catch (Exception e) {e.printStackTrace();}
		}
	}
	public static String getDtLastSuccessfulAudit(Connection conn, int evaluator_id, int export_id){
		String audit_file_last_create_dt ="";
		PreparedStatement ps = null;
		ResultSet rs = null;
		String sql = "Select nvl(TO_CHAR(audit_file_last_create_dt,'MM/DD/YYYY HH24:MI:SS'),'') audit_file_last_create_dt " +
			" from config_data_extract " +
			" where EVALUATOR_ID = ? AND data_extract_id = ?";
		try {
			ps = conn.prepareStatement(sql);
			ps.setInt(1, evaluator_id);
			ps.setInt(2, export_id);
			rs = ps.executeQuery();
			if(rs.next()) {
				audit_file_last_create_dt = getStringValue(rs,"audit_file_last_create_dt");
			}
			try { if (rs != null) rs.close();} catch (Exception e) {e.printStackTrace();}
			try { if (ps != null) ps.close();} catch (Exception e) {e.printStackTrace();}
		}
		catch (Exception e) {
	    	System.out.println("Exception caught in exportReportDB.java function getDtLastSuccessfulAudit "+e);
	    }
		finally {
			try { if (rs != null) rs.close();} catch (Exception e) {e.printStackTrace();}
			try { if (ps != null) ps.close();} catch (Exception e) {e.printStackTrace();}
		}

		return audit_file_last_create_dt;
	}
	public static String getStringValue(ResultSet rs, String columnToRetrieve){
		//method returns a blank string if the value returned was null
		String retrievedValue ="";
		try{
			retrievedValue = rs.getString(columnToRetrieve);
			if(retrievedValue == null)
				retrievedValue ="";
		}
		catch (Exception e) {
	    	System.out.println("Exception caught in exportReportDB.java function getStringValue: "+e);
	    }
		return retrievedValue;
	}

	public static boolean checkIfCurrentDetail(Connection conn, String request_id, int evaluator_id){
		String task ="";
		boolean currentRecord = true; //default to get current record details
		PreparedStatement ps = null;
		ResultSet rs = null;
		String updateSql = "select task_id" +
			" from credit_request " +
			" where EVALUATOR_ID = ? AND request_id = ?";
		try {
			ps = conn.prepareStatement(updateSql);
			ps.setInt(1, evaluator_id);
			ps.setString(2, request_id);
			rs = ps.executeQuery();
			if(rs.next()) {
				task = getStringValue(rs,"task_id");
			}
			try { if (rs != null) rs.close();} catch (Exception e) {e.printStackTrace();}
			try { if (ps != null) ps.close();} catch (Exception e) {e.printStackTrace();}
		}
		catch (Exception e) {
	    	System.out.println("Exception caught in exportReportDB.java function checkIfCurrentDetail "+e);
	    }
		finally {
			try { if (rs != null) rs.close();} catch (Exception e) {e.printStackTrace();}
			try { if (ps != null) ps.close();} catch (Exception e) {e.printStackTrace();}
		}

		 if(task.equals("DONE")){ //closed record detail
			currentRecord = false;
		 }

		return currentRecord;
	}
}

