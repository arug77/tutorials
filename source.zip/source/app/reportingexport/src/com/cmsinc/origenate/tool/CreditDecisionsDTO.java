package com.cmsinc.origenate.tool;

import java.util.Date;
import java.util.List;



public class CreditDecisionsDTO {
    private String contractltv;
    private String contractdti;
    private Date receivedDt;
    private List<DecReason> decReasons;
    private List<DecPTIDTI> decPtiDti;
    
    public static class DecReason
    {
        private String decReasonCode;
        private String decReasonDescription;
        private DecReasonTypeEnum decReasonTypeId;
        private int decReasonOrderPrecedence;
        
        public String getDecReasonCode() {
            return decReasonCode;
        }
        
        public void setDecReasonCode(String decReasonCode) {
            this.decReasonCode = decReasonCode;
        }
        
        public String getDecReasonDescription() {
            return decReasonDescription;
        }
        
        public void setDecReasonDescription(String decReasonDescription) {
            this.decReasonDescription = decReasonDescription;
        }
        
        public DecReasonTypeEnum getDecReasonTypeId() {
            return decReasonTypeId;
        }
        
        public void setDecReasonTypeId(DecReasonTypeEnum decReasonTypeId) {
            this.decReasonTypeId = decReasonTypeId;
        }

        
        public int getDecReasonOrderPrecedence() {
            return decReasonOrderPrecedence;
        }

        
        public void setDecReasonOrderPrecedence(int decReasonOrderPrecedence) {
            this.decReasonOrderPrecedence = decReasonOrderPrecedence;
        }
        
        
    }
    
    public enum DecReasonTypeEnum{
        
        Turndown(1, "Turndown"),
        Override(2, "Override");
        
        DecReasonTypeEnum(int Id, String txt)
        {
            this.id = Id;
            this.txt = txt;
        }
        
        private String txt;
        private int id;
        
    }
    
    
    
    public String getContractltv() {
        return contractltv;
    }

    
    public void setContractltv(String contractltv) {
        this.contractltv = contractltv;
    }

    
    public String getContractdti() {
        return contractdti;
    }

    
    public void setContractdti(String contractdti) {
        this.contractdti = contractdti;
    }

    
    public Date getReceivedDt() {
        return receivedDt;
    }

    
    public void setReceivedDt(Date receivedDt) {
        this.receivedDt = receivedDt;
    }

    
    public List<DecReason> getDecReasons() {
        return decReasons;
    }

    
    public void setDecReasons(List<DecReason> decReasons) {
        this.decReasons = decReasons;
    }
    
    
    public static class DecPTIDTI{
        
        private String categoryTxt;
        private String ptidti_txt;
        private int ptidti_num;
        
        public String getCategoryTxt() {
            return categoryTxt;
        }
        
        public void setCategoryTxt(String categoryTxt) {
            this.categoryTxt = categoryTxt;
        }
        
        public String getPtidti_txt() {
            return ptidti_txt;
        }
        
        public void setPtidti_txt(String ptidti_txt) {
            this.ptidti_txt = ptidti_txt;
        }

        public int getPtidti_num() {
            return ptidti_num;
        }

        public void setPtidti_num(int ptidti_num) {
            this.ptidti_num = ptidti_num;
        }
    
    }
   
    public List<DecPTIDTI> getDecPtiDti() {
        return decPtiDti;
    }


    
    public void setDecPtiDti(List<DecPTIDTI> decPtiDti) {
        this.decPtiDti = decPtiDti;
    }
}
