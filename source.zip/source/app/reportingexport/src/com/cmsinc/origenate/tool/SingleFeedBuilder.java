package com.cmsinc.origenate.tool;

import java.util.List;


public interface SingleFeedBuilder<T> {
    
    public static final String ENTITY_APPLICANT_TXT = "A1";
    public static final String ENTITY_COAPPLICANT1_TXT = "C1";
    public static final String ENTITY_COAPPLICANT2_TXT = "C2";
    public static final String ENTITY_COSIGNER1_TXT = "S1";
    public static final String ENTITY_COSIGNER2_TXT = "S2";
    
    public static final String entityTypeList[] = {ENTITY_APPLICANT_TXT, ENTITY_COAPPLICANT1_TXT, ENTITY_COAPPLICANT2_TXT, ENTITY_COSIGNER1_TXT, ENTITY_COSIGNER2_TXT };
    
    public List<T> buildBeans();
    

    
}


