package com.cmsinc.origenate.tool;
/**
 * Class is a task that can be submitted and executed. 
 * 
 */

import java.sql.Connection;
import java.util.List;
import java.util.concurrent.Callable;

import com.cmsinc.origenate.cp.mpe.Mpe;
import com.cmsinc.origenate.util.DBConnection;
import com.cmsinc.origenate.util.LogMsg;
import com.cmsinc.origenate.util.RowData;
import com.cmsinc.origenate.xmldbt.GenX;
import com.cmsinc.origenate.xmldbt.TransformerUtils;
import com.sf.bank.lue.util.ConnectionInfo;

public class XMLCreator implements Callable<XMLResult> {
    
    private static final String EVALUATOR_ID_STATEFARM = "148";

    private ConnectionInfo connectionInfo;
    private List<RowData> data;
    private int log_level;
    private String logFileName;
    private LogMsg log_obj;
    private String xslPath = "";
    private static final String XML_TRANS_LIST = "AppActivityRq,AppJournalRq,AllAppCommentsRq,BureauAppInfoRq,ChecklistRs,InterAppRq,LoanAppRq,LoanAppRs,LoanVerifRq,ReportingExportRq";
    private Connection connection;

    /**
     * Creates an instance of XMLCreator, so we can write the app xmls for SingleFeed
     * 
     * @param connectionInfo
     *            Database connection information
     * @param data
     *            The list of apps to process in this batch
     * @param logLevel
     *            Log level
     * @param logFileName
     *            Log file name
     * @param xslPath
     *            The XSL path
     */
    XMLCreator(ConnectionInfo connectionInfo, List<RowData> data, int logLevel, String logFileName, String xslPath) {
        this.connectionInfo = connectionInfo;
        this.data = data;
        this.log_level = logLevel;
        this.logFileName = logFileName;
        this.xslPath = xslPath;
    }

    /**
     * The main method of XMLCreator. This process all the tasks, delegates to additional methods as need be
     */
    @Override
    public XMLResult call() throws Exception {

        String threadName = Thread.currentThread().getName();
        log_obj = new LogMsg();
        log_obj.openLogFile(logFileName);
        log_obj.setLogID("THREAD "+threadName+": ");

        connection = getDBConnection();

        XMLResult results = new XMLResult();
        StringBuilder xmlBuffer = new StringBuilder();
        xmlBuffer.append("<?xml version=\"1.0\" encoding=\"ISO-8859-1\"?><CMSI><HeaderInfo>");
        xmlBuffer.append("<appcount>" + data.size() + "</appcount></HeaderInfo><Apps>");

        for (RowData row : data) {
            String requestId = row.getColValue(1);
            String s_xml = callGenX(requestId);
            s_xml = s_xml.substring(s_xml.indexOf("?>") + 2);
            xmlBuffer.append(s_xml);
        }

        xmlBuffer.append("</Apps></CMSI>"); // end aggregating all apps, now apply stylesheet
        xslPath += ", ";
        String output = applyXSL(xmlBuffer.toString(), xslPath);

        results.setStyledOutput(output);
        results.setXml(xmlBuffer.toString());

        return results;
    }

    /**
     * Calls the existing framework: GenX
     * @param requestId RequestID to process
     * @return The string output after the call to GenX
     * @throws Exception
     */
    private String callGenX(String requestId) throws Exception {
        String s_xml = "";

        try {

            GenX genx = null;
            Mpe mpe = null;
            
            genx = new GenX(connection, 0);
            genx.ResetParams();
            genx.bSetParam("DEFAULT_NETWORK", "ORIGENATE");
            genx.bSetParam("REQUEST_ID", requestId);

            // generates xml according to transactions fed in (expects loanapprq for mpe additions)
            try {
                log(0, "RequestID: " + requestId + " - Call to genx begin");
                genx.setEncryptionParms(connectionInfo.getUserName().toLowerCase(), "ssn"); // dont encrypt ssn when creating the outfile
                s_xml = genx.sGetXMLorThrow(XML_TRANS_LIST);                
                log(0, "RequestID: " + requestId + " - Call to genx end");
            } catch (Exception e) {
                throw new Exception("Error creating xml in GENX for request id " + requestId + ". " , e);
            }

            log(0, "Replacing non-printable chars begin");
            // replace non-printable chars in the xml...genx encodes ascii char so match &#25; for example
            s_xml = s_xml.replaceAll("&#[0-3][0-9];", "");
            s_xml = s_xml.replaceAll("&#xfffd;", "");

            log(0, "Replacing non-printable chars end");

            mpe = new Mpe(connection);

            try {
                log(0, "Adding mpe values");
                s_xml = mpe.addNLSUFields(s_xml, EVALUATOR_ID_STATEFARM, requestId, "NONE");
                log(0, "Added nslu via mpe");
                s_xml = mpe.addAdditionalFields(s_xml, EVALUATOR_ID_STATEFARM, requestId, "");
                log(0, "Added additional fields via mpe");
            } catch (Exception e) {
                throw new Exception("Error adding nlsu and additional fields to the xml for request id " + requestId + ". " , e);
            }
          
        } catch (Exception e) {
            throw new Exception("Error processing app for request id " + requestId + ". " , e);
        }

        return s_xml;
    }

    /**
     * Creates a DB connection, if one already exists, it will return the existing.
     * @throws Exception Throws an exception if there is an error getting a DBConnection
     */
    private Connection getDBConnection() throws Exception {

        Connection conn = null;

        if ((conn == null) || (conn.isClosed())) {
            DBConnection DBConnect = new DBConnection();

            if (connectionInfo.getTnsEntry().length() == 0) {
                conn = DBConnect.getConnection(connectionInfo.getHostname(), connectionInfo.getSid(), connectionInfo.getUserName(), connectionInfo.getPassword(), null, Integer.toString(connectionInfo.getPort()), "");
            } else {
                // use tns entry if available
                conn = DBConnect.getConnectionTNS(connectionInfo.getTnsEntry(), connectionInfo.getUserName(), connectionInfo.getPassword(), null);
            }

        }

        return conn;
    }

    /**
     * Applies the XSL to the provided XML
     * @param xml XML
     * @param xsl XSL Stylesheet
     * @return Styled XML output
     * @throws Exception
     */
    protected String applyXSL(String xml, String xsl) throws Exception {
        // if there are stylesheets, loop thru stylesheet list applying xml
        if (xsl.length() > 2) {
            log(0, "Apply xsl begin");
            int i = 0;
            while (xsl.indexOf(",", i) != -1) {
                xml = TransformerUtils.toString(xml, xsl.substring(i, xsl.indexOf(",",i)) );
                i = xsl.indexOf(",", i) + 1;
            }
            log(0, "Apply xsl end");
        }

        return xml;
    }

    /**
     * Logging method for XMLCreator. Always call this method when logging in this class, it will log using the universal LogMsg class,
     * this is so we can swap out logging on the fly if need be
     * 
     * @param msgLevel The log level of this message
     * @param logMsg The message string
     */
    public void log(int msgLevel, String logMsg) {
        if (LogMsg.isDebuggingEnabled(log_level, msgLevel)) {
            log_obj.FmtAndLogMsg("XMLCreator: " + logMsg);
        }
    }

    /**
     * Getting the log object. Used for unit testing.
     */
    public LogMsg getLog_obj() {
        return log_obj;
    }

    /**
     * Setting the log object. Used for unit testing.
     */
    public void setLog_obj(LogMsg log_obj) {
        this.log_obj = log_obj;
    }
}