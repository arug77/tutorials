package com.cmsinc.origenate.tool;

import java.beans.IntrospectionException;
import java.util.Map;

import com.opencsv.bean.BeanToCsv;
import com.opencsv.bean.CsvBindByName;
import com.opencsv.bean.HeaderColumnNameTranslateMappingStrategy;
import com.opencsv.bean.MappingStrategy;


public class SingleFeedCSVByNameBean {
    
    @CsvBindByName
    private String referenceNumber;

    @CsvBindByName
    private String bankID;

    @CsvBindByName
    private String userid;

    @CsvBindByName
    private String agentID;

    @CsvBindByName
    private String applicationID;

    @CsvBindByName
    private String applicantFirstName;

    @CsvBindByName
    private String applicantMiddleName;

    @CsvBindByName
    private String applicantLastname;

    @CsvBindByName
    private String applicantAddressLine1;

    @CsvBindByName
    private String applicantAddressCity;

    @CsvBindByName
    private String applicantAddressState;

    @CsvBindByName
    private String applicantAddressZip;

    @CsvBindByName
    private String applicantDOB;

    @CsvBindByName
    private String applicantPhoneHome;

    @CsvBindByName
    private String applicantIncome;

    @CsvBindByName
    private String applicantNumberTaxID;

    @CsvBindByName
    private String coApplicantFirstName;

    @CsvBindByName
    private String coApplicantMiddleName;

    @CsvBindByName
    private String coApplicantLastname;

    @CsvBindByName
    private String coApplicantAddressLine1;

    @CsvBindByName
    private String coApplicantAddressCity;

    @CsvBindByName
    private String coApplicantAddressState;

    @CsvBindByName
    private String coApplicantAddressZip;

    @CsvBindByName
    private String coApplicantDOB;

    @CsvBindByName
    private String coApplicantPhoneHome;

    @CsvBindByName
    private String coApplicantIncome;

    @CsvBindByName
    private String coApplicantNumberTaxID;

    @CsvBindByName
    private String coApplicant2FirstName;

    @CsvBindByName
    private String coApplicant2MiddleName;

    @CsvBindByName
    private String coApplicant2Lastname;

    @CsvBindByName
    private String coApplicant2AddressLine1;

    @CsvBindByName
    private String coApplicant2AddressCity;

    @CsvBindByName
    private String coApplicant2AddressState;

    @CsvBindByName
    private String coApplicant2AddressZip;

    @CsvBindByName
    private String coApplicant2DOB;

    @CsvBindByName
    private String coApplicant2PhoneHome;

    @CsvBindByName
    private String coApplicant2Income;

    @CsvBindByName
    private String coApplicant2NumberTaxID;

    @CsvBindByName
    private String coSignerFirstName;

    @CsvBindByName
    private String coSignerMiddleName;

    @CsvBindByName
    private String coSignerLastname;

    @CsvBindByName
    private String coSignerAddressLine1;

    @CsvBindByName
    private String coSignerAddressCity;

    @CsvBindByName
    private String coSignerAddressState;

    @CsvBindByName
    private String coSignerAddressZip;

    @CsvBindByName
    private String coSignerDOB;

    @CsvBindByName
    private String coSignerPhoneHome;

    @CsvBindByName
    private String coSignerIncome;

    @CsvBindByName
    private String coSignerNumberTaxID;

    @CsvBindByName
    private String coSigner2FirstName;

    @CsvBindByName
    private String coSigner2MiddleName;

    @CsvBindByName
    private String coSigner2Lastname;

    @CsvBindByName
    private String coSigner2AddressLine1;

    @CsvBindByName
    private String coSigner2AddressCity;

    @CsvBindByName
    private String coSigner2AddressState;

    @CsvBindByName
    private String coSigner2AddressZip;

    @CsvBindByName
    private String coSigner2DOB;

    @CsvBindByName
    private String coSigner2PhoneHome;

    @CsvBindByName
    private String coSigner2Income;

    @CsvBindByName
    private String coSigner2NumberTaxID;

    @CsvBindByName
    private String reqeustedLoan;

    @CsvBindByName
    private String originalLoanBalance;

    @CsvBindByName
    private String dateAction;

    @CsvBindByName
    private String dateAppReceived;

    @CsvBindByName
    private String codeLoanType;

    @CsvBindByName
    private String codeAction;

    @CsvBindByName
    private String codeOriginationSource;

    @CsvBindByName
    private String codeDenial1;

    @CsvBindByName
    private String denialDescription1;

    @CsvBindByName
    private String codeDenial2;

    @CsvBindByName
    private String denialDescription2;

    @CsvBindByName
    private String codeDenial3;

    @CsvBindByName
    private String denialDescription3;

    @CsvBindByName
    private String codeDenial4;

    @CsvBindByName
    private String denialDescription4;

    @CsvBindByName
    private String codeProduct;

    @CsvBindByName
    private String codeOverride1;

    @CsvBindByName
    private String reasonDescription1;

    @CsvBindByName
    private String codeOverride2;

    @CsvBindByName
    private String reasonDescription2;

    @CsvBindByName
    private String codeOverride3;

    @CsvBindByName
    private String reasonDescription3;

    @CsvBindByName
    private String codeOfficer;

    @CsvBindByName
    private int applicantCreditNumberInquiries;

    @CsvBindByName
    private int applicantCreditNumberMajorTotalDelinquencies;

    @CsvBindByName
    private int applicantCreditNumberMinorTotalDelinquencies;

    @CsvBindByName
    private int applicantCreditNumberSatisfactoryAccounts;

    @CsvBindByName
    private double applicantCreditScore;

    @CsvBindByName
    private int applicantTotalBankruptcies;

    @CsvBindByName
    private int applicantTotalCollections;

    @CsvBindByName
    private int coApplicantCreditNumberInquiries;

    @CsvBindByName
    private int coApplicantCreditNumberMajorTotalDelinquencies;

    @CsvBindByName
    private int coApplicantCreditNumberMinorTotalDelinquencies;

    @CsvBindByName
    private int coApplicantCreditNumberSatisfactoryAccounts;

    @CsvBindByName
    private double coApplicantCreditScore;

    @CsvBindByName
    private int coApplicantTotalBankruptcies;

    @CsvBindByName
    private int coApplicantTotalCollections;

    @CsvBindByName
    private int coApplicant2CreditNumberInquiries;

    @CsvBindByName
    private int coApplicant2CreditNumberMajorTotalDelinquencies;

    @CsvBindByName
    private int coApplicant2CreditNumberMinorTotalDelinquencies;

    @CsvBindByName
    private int coApplicant2CreditNumberSatisfactoryAccounts;

    @CsvBindByName
    private double coApplicant2CreditScore;

    @CsvBindByName
    private int coApplicant2TotalBankruptcies;

    @CsvBindByName
    private int coApplicant2TotalCollections;

    @CsvBindByName
    private int coSignerCreditNumberInquiries;

    @CsvBindByName
    private int coSignerCreditNumberMajorTotalDelinquencies;

    @CsvBindByName
    private int coSignerCreditNumberMinorTotalDelinquencies;

    @CsvBindByName
    private int coSignerCreditNumberSatisfactoryAccounts;

    @CsvBindByName
    private double coSignerCreditScore;

    @CsvBindByName
    private int coSignerTotalBankruptcies;

    @CsvBindByName
    private int coSignerTotalCollections;

    @CsvBindByName
    private int coSigner2CreditNumberInquiries;

    @CsvBindByName
    private int coSigner2CreditNumberMajorTotalDelinquencies;

    @CsvBindByName
    private int coSigner2CreditNumberMinorTotalDelinquencies;

    @CsvBindByName
    private int coSigner2CreditNumberSatisfactoryAccounts;

    @CsvBindByName
    private double coSigner2CreditScore;

    @CsvBindByName
    private int coSigner2TotalBankruptcies;

    @CsvBindByName
    private int coSigner2TotalCollections;

    @CsvBindByName
    private double rateInterestOriginal;

    @CsvBindByName
    private int termLoanOriginal;

    @CsvBindByName
    private double applicantRatioDebtServiceHousing;

    @CsvBindByName
    private double applicantRatioDebtServiceTotal;

    @CsvBindByName
    private double applicantRatioLoantoValue;

    @CsvBindByName
    private double coApplicantRatioDebtServiceHousing;

    @CsvBindByName
    private double coApplicantRatioDebtServiceTotal;

    @CsvBindByName
    private double coApplicantRatioLoantoValue;

    @CsvBindByName
    private double coApplicant2RatioDebtServiceHousing;

    @CsvBindByName
    private double coApplicant2RatioDebtServiceTotal;

    @CsvBindByName
    private double coApplicant2RatioLoantoValue;

    @CsvBindByName
    private double coSignerRatioDebtServiceHousing;

    @CsvBindByName
    private double coSignerRatioDebtServiceTotal;

    @CsvBindByName
    private double coSignerRatioLoantoValue;

    @CsvBindByName
    private double coSigner2RatioDebtServiceHousing;

    @CsvBindByName
    private double coSigner2RatioDebtServiceTotal;

    @CsvBindByName
    private double coSigner2RatioLoantoValue;

    @CsvBindByName
    private String dealerLienName;

    /**
     * Empty public constructor for CSVReader/ CSVWriter
     */
    public SingleFeedCSVByNameBean() { }
    
    
    
    public SingleFeedCSVByNameBean(String referenceNumber, String bankID, String userid, String agentID, String applicationID, String applicantFirstName, String applicantMiddleName, String applicantLastname, String applicantAddressLine1, String applicantAddressCity,
            String applicantAddressState, String applicantAddressZip, String applicantDOB, String applicantPhoneHome, String applicantIncome, String applicantNumberTaxID, String coApplicantFirstName, String coApplicantMiddleName, String coApplicantLastname,
            String coApplicantAddressLine1, String coApplicantAddressCity, String coApplicantAddressState, String coApplicantAddressZip, String coApplicantDOB, String coApplicantPhoneHome, String coApplicantIncome, String coApplicantNumberTaxID, String coApplicant2FirstName,
            String coApplicant2MiddleName, String coApplicant2Lastname, String coApplicant2AddressLine1, String coApplicant2AddressCity, String coApplicant2AddressState, String coApplicant2AddressZip, String coApplicant2DOB, String coApplicant2PhoneHome,
            String coApplicant2Income, String coApplicant2NumberTaxID, String coSignerFirstName, String coSignerMiddleName, String coSignerLastname, String coSignerAddressLine1, String coSignerAddressCity, String coSignerAddressState, String coSignerAddressZip,
            String coSignerDOB, String coSignerPhoneHome, String coSignerIncome, String coSignerNumberTaxID, String coSigner2FirstName, String coSigner2MiddleName, String coSigner2Lastname, String coSigner2AddressLine1, String coSigner2AddressCity, String coSigner2AddressState,
            String coSigner2AddressZip, String coSigner2DOB, String coSigner2PhoneHome, String coSigner2Income, String coSigner2NumberTaxID, String reqeustedLoan, String originalLoanBalance, String dateAction, String dateAppReceived, String codeLoanType, String codeAction,
            String codeOriginationSource, String codeDenial1, String denialDescription1, String codeDenial2, String denialDescription2, String codeDenial3, String denialDescription3, String codeDenial4, String denialDescription4, String codeProduct, String codeOverride1,
            String reasonDescription1, String codeOverride2, String reasonDescription2, String codeOverride3, String reasonDescription3, String codeOfficer, int applicantCreditNumberInquiries, int applicantCreditNumberMajorTotalDelinquencies,
            int applicantCreditNumberMinorTotalDelinquencies, int applicantCreditNumberSatisfactoryAccounts, double applicantCreditScore, int applicantTotalBankruptcies, int applicantTotalCollections, int coApplicantCreditNumberInquiries,
            int coApplicantCreditNumberMajorTotalDelinquencies, int coApplicantCreditNumberMinorTotalDelinquencies, int coApplicantCreditNumberSatisfactoryAccounts, double coApplicantCreditScore, int coApplicantTotalBankruptcies, int coApplicantTotalCollections,
            int coApplicant2CreditNumberInquiries, int coApplicant2CreditNumberMajorTotalDelinquencies, int coApplicant2CreditNumberMinorTotalDelinquencies, int coApplicant2CreditNumberSatisfactoryAccounts, double coApplicant2CreditScore, int coApplicant2TotalBankruptcies,
            int coApplicant2TotalCollections, int coSignerCreditNumberInquiries, int coSignerCreditNumberMajorTotalDelinquencies, int coSignerCreditNumberMinorTotalDelinquencies, int coSignerCreditNumberSatisfactoryAccounts, double coSignerCreditScore,
            int coSignerTotalBankruptcies, int coSignerTotalCollections, int coSigner2CreditNumberInquiries, int coSigner2CreditNumberMajorTotalDelinquencies, int coSigner2CreditNumberMinorTotalDelinquencies, int coSigner2CreditNumberSatisfactoryAccounts,
            double coSigner2CreditScore, int coSigner2TotalBankruptcies, int coSigner2TotalCollections, double rateInterestOriginal, int termLoanOriginal, double applicantRatioDebtServiceHousing, double applicantRatioDebtServiceTotal, double applicantRatioLoantoValue,
            double coApplicantRatioDebtServiceHousing, double coApplicantRatioDebtServiceTotal, double coApplicantRatioLoantoValue, double coApplicant2RatioDebtServiceHousing, double coApplicant2RatioDebtServiceTotal, double coApplicant2RatioLoantoValue,
            double coSignerRatioDebtServiceHousing, double coSignerRatioDebtServiceTotal, double coSignerRatioLoantoValue, double coSigner2RatioDebtServiceHousing, double coSigner2RatioDebtServiceTotal, double coSigner2RatioLoantoValue, String dealerLienName) {
        super();
        this.referenceNumber = referenceNumber;
        this.bankID = bankID;
        this.userid = userid;
        this.agentID = agentID;
        this.applicationID = applicationID;
        this.applicantFirstName = applicantFirstName;
        this.applicantMiddleName = applicantMiddleName;
        this.applicantLastname = applicantLastname;
        this.applicantAddressLine1 = applicantAddressLine1;
        this.applicantAddressCity = applicantAddressCity;
        this.applicantAddressState = applicantAddressState;
        this.applicantAddressZip = applicantAddressZip;
        this.applicantDOB = applicantDOB;
        this.applicantPhoneHome = applicantPhoneHome;
        this.applicantIncome = applicantIncome;
        this.applicantNumberTaxID = applicantNumberTaxID;
        this.coApplicantFirstName = coApplicantFirstName;
        this.coApplicantMiddleName = coApplicantMiddleName;
        this.coApplicantLastname = coApplicantLastname;
        this.coApplicantAddressLine1 = coApplicantAddressLine1;
        this.coApplicantAddressCity = coApplicantAddressCity;
        this.coApplicantAddressState = coApplicantAddressState;
        this.coApplicantAddressZip = coApplicantAddressZip;
        this.coApplicantDOB = coApplicantDOB;
        this.coApplicantPhoneHome = coApplicantPhoneHome;
        this.coApplicantIncome = coApplicantIncome;
        this.coApplicantNumberTaxID = coApplicantNumberTaxID;
        this.coApplicant2FirstName = coApplicant2FirstName;
        this.coApplicant2MiddleName = coApplicant2MiddleName;
        this.coApplicant2Lastname = coApplicant2Lastname;
        this.coApplicant2AddressLine1 = coApplicant2AddressLine1;
        this.coApplicant2AddressCity = coApplicant2AddressCity;
        this.coApplicant2AddressState = coApplicant2AddressState;
        this.coApplicant2AddressZip = coApplicant2AddressZip;
        this.coApplicant2DOB = coApplicant2DOB;
        this.coApplicant2PhoneHome = coApplicant2PhoneHome;
        this.coApplicant2Income = coApplicant2Income;
        this.coApplicant2NumberTaxID = coApplicant2NumberTaxID;
        this.coSignerFirstName = coSignerFirstName;
        this.coSignerMiddleName = coSignerMiddleName;
        this.coSignerLastname = coSignerLastname;
        this.coSignerAddressLine1 = coSignerAddressLine1;
        this.coSignerAddressCity = coSignerAddressCity;
        this.coSignerAddressState = coSignerAddressState;
        this.coSignerAddressZip = coSignerAddressZip;
        this.coSignerDOB = coSignerDOB;
        this.coSignerPhoneHome = coSignerPhoneHome;
        this.coSignerIncome = coSignerIncome;
        this.coSignerNumberTaxID = coSignerNumberTaxID;
        this.coSigner2FirstName = coSigner2FirstName;
        this.coSigner2MiddleName = coSigner2MiddleName;
        this.coSigner2Lastname = coSigner2Lastname;
        this.coSigner2AddressLine1 = coSigner2AddressLine1;
        this.coSigner2AddressCity = coSigner2AddressCity;
        this.coSigner2AddressState = coSigner2AddressState;
        this.coSigner2AddressZip = coSigner2AddressZip;
        this.coSigner2DOB = coSigner2DOB;
        this.coSigner2PhoneHome = coSigner2PhoneHome;
        this.coSigner2Income = coSigner2Income;
        this.coSigner2NumberTaxID = coSigner2NumberTaxID;
        this.reqeustedLoan = reqeustedLoan;
        this.originalLoanBalance = originalLoanBalance;
        this.dateAction = dateAction;
        this.dateAppReceived = dateAppReceived;
        this.codeLoanType = codeLoanType;
        this.codeAction = codeAction;
        this.codeOriginationSource = codeOriginationSource;
        this.codeDenial1 = codeDenial1;
        this.denialDescription1 = denialDescription1;
        this.codeDenial2 = codeDenial2;
        this.denialDescription2 = denialDescription2;
        this.codeDenial3 = codeDenial3;
        this.denialDescription3 = denialDescription3;
        this.codeDenial4 = codeDenial4;
        this.denialDescription4 = denialDescription4;
        this.codeProduct = codeProduct;
        this.codeOverride1 = codeOverride1;
        this.reasonDescription1 = reasonDescription1;
        this.codeOverride2 = codeOverride2;
        this.reasonDescription2 = reasonDescription2;
        this.codeOverride3 = codeOverride3;
        this.reasonDescription3 = reasonDescription3;
        this.codeOfficer = codeOfficer;
        this.applicantCreditNumberInquiries = applicantCreditNumberInquiries;
        this.applicantCreditNumberMajorTotalDelinquencies = applicantCreditNumberMajorTotalDelinquencies;
        this.applicantCreditNumberMinorTotalDelinquencies = applicantCreditNumberMinorTotalDelinquencies;
        this.applicantCreditNumberSatisfactoryAccounts = applicantCreditNumberSatisfactoryAccounts;
        this.applicantCreditScore = applicantCreditScore;
        this.applicantTotalBankruptcies = applicantTotalBankruptcies;
        this.applicantTotalCollections = applicantTotalCollections;
        this.coApplicantCreditNumberInquiries = coApplicantCreditNumberInquiries;
        this.coApplicantCreditNumberMajorTotalDelinquencies = coApplicantCreditNumberMajorTotalDelinquencies;
        this.coApplicantCreditNumberMinorTotalDelinquencies = coApplicantCreditNumberMinorTotalDelinquencies;
        this.coApplicantCreditNumberSatisfactoryAccounts = coApplicantCreditNumberSatisfactoryAccounts;
        this.coApplicantCreditScore = coApplicantCreditScore;
        this.coApplicantTotalBankruptcies = coApplicantTotalBankruptcies;
        this.coApplicantTotalCollections = coApplicantTotalCollections;
        this.coApplicant2CreditNumberInquiries = coApplicant2CreditNumberInquiries;
        this.coApplicant2CreditNumberMajorTotalDelinquencies = coApplicant2CreditNumberMajorTotalDelinquencies;
        this.coApplicant2CreditNumberMinorTotalDelinquencies = coApplicant2CreditNumberMinorTotalDelinquencies;
        this.coApplicant2CreditNumberSatisfactoryAccounts = coApplicant2CreditNumberSatisfactoryAccounts;
        this.coApplicant2CreditScore = coApplicant2CreditScore;
        this.coApplicant2TotalBankruptcies = coApplicant2TotalBankruptcies;
        this.coApplicant2TotalCollections = coApplicant2TotalCollections;
        this.coSignerCreditNumberInquiries = coSignerCreditNumberInquiries;
        this.coSignerCreditNumberMajorTotalDelinquencies = coSignerCreditNumberMajorTotalDelinquencies;
        this.coSignerCreditNumberMinorTotalDelinquencies = coSignerCreditNumberMinorTotalDelinquencies;
        this.coSignerCreditNumberSatisfactoryAccounts = coSignerCreditNumberSatisfactoryAccounts;
        this.coSignerCreditScore = coSignerCreditScore;
        this.coSignerTotalBankruptcies = coSignerTotalBankruptcies;
        this.coSignerTotalCollections = coSignerTotalCollections;
        this.coSigner2CreditNumberInquiries = coSigner2CreditNumberInquiries;
        this.coSigner2CreditNumberMajorTotalDelinquencies = coSigner2CreditNumberMajorTotalDelinquencies;
        this.coSigner2CreditNumberMinorTotalDelinquencies = coSigner2CreditNumberMinorTotalDelinquencies;
        this.coSigner2CreditNumberSatisfactoryAccounts = coSigner2CreditNumberSatisfactoryAccounts;
        this.coSigner2CreditScore = coSigner2CreditScore;
        this.coSigner2TotalBankruptcies = coSigner2TotalBankruptcies;
        this.coSigner2TotalCollections = coSigner2TotalCollections;
        this.rateInterestOriginal = rateInterestOriginal;
        this.termLoanOriginal = termLoanOriginal;
        this.applicantRatioDebtServiceHousing = applicantRatioDebtServiceHousing;
        this.applicantRatioDebtServiceTotal = applicantRatioDebtServiceTotal;
        this.applicantRatioLoantoValue = applicantRatioLoantoValue;
        this.coApplicantRatioDebtServiceHousing = coApplicantRatioDebtServiceHousing;
        this.coApplicantRatioDebtServiceTotal = coApplicantRatioDebtServiceTotal;
        this.coApplicantRatioLoantoValue = coApplicantRatioLoantoValue;
        this.coApplicant2RatioDebtServiceHousing = coApplicant2RatioDebtServiceHousing;
        this.coApplicant2RatioDebtServiceTotal = coApplicant2RatioDebtServiceTotal;
        this.coApplicant2RatioLoantoValue = coApplicant2RatioLoantoValue;
        this.coSignerRatioDebtServiceHousing = coSignerRatioDebtServiceHousing;
        this.coSignerRatioDebtServiceTotal = coSignerRatioDebtServiceTotal;
        this.coSignerRatioLoantoValue = coSignerRatioLoantoValue;
        this.coSigner2RatioDebtServiceHousing = coSigner2RatioDebtServiceHousing;
        this.coSigner2RatioDebtServiceTotal = coSigner2RatioDebtServiceTotal;
        this.coSigner2RatioLoantoValue = coSigner2RatioLoantoValue;
        this.dealerLienName = dealerLienName;
    }



    public String getReferenceNumber() {
        return referenceNumber;
    }

    
    public void setReferenceNumber(String referenceNumber) {
        this.referenceNumber = referenceNumber;
    }

    
    public String getBankID() {
        return bankID;
    }

    
    public void setBankID(String bankID) {
        this.bankID = bankID;
    }

    
    public String getUserid() {
        return userid;
    }

    
    public void setUserid(String userid) {
        this.userid = userid;
    }

    
    public String getAgentID() {
        return agentID;
    }

    
    public void setAgentID(String agentID) {
        this.agentID = agentID;
    }

    
    public String getApplicationID() {
        return applicationID;
    }

    
    public void setApplicationID(String applicationID) {
        this.applicationID = applicationID;
    }

    
    public String getApplicantFirstName() {
        return applicantFirstName;
    }

    
    public void setApplicantFirstName(String applicantFirstName) {
        this.applicantFirstName = applicantFirstName;
    }

    
    public String getApplicantMiddleName() {
        return applicantMiddleName;
    }

    
    public void setApplicantMiddleName(String applicantMiddleName) {
        this.applicantMiddleName = applicantMiddleName;
    }

    
    public String getApplicantLastname() {
        return applicantLastname;
    }

    
    public void setApplicantLastname(String applicantLastname) {
        this.applicantLastname = applicantLastname;
    }

    
    public String getApplicantAddressLine1() {
        return applicantAddressLine1;
    }

    
    public void setApplicantAddressLine1(String applicantAddressLine1) {
        this.applicantAddressLine1 = applicantAddressLine1;
    }

    
    public String getApplicantAddressCity() {
        return applicantAddressCity;
    }

    
    public void setApplicantAddressCity(String applicantAddressCity) {
        this.applicantAddressCity = applicantAddressCity;
    }

    
    public String getApplicantAddressState() {
        return applicantAddressState;
    }

    
    public void setApplicantAddressState(String applicantAddressState) {
        this.applicantAddressState = applicantAddressState;
    }

    
    public String getApplicantAddressZip() {
        return applicantAddressZip;
    }

    
    public void setApplicantAddressZip(String applicantAddressZip) {
        this.applicantAddressZip = applicantAddressZip;
    }

    
    public String getApplicantDOB() {
        return applicantDOB;
    }

    
    public void setApplicantDOB(String applicantDOB) {
        this.applicantDOB = applicantDOB;
    }

    
    public String getApplicantPhoneHome() {
        return applicantPhoneHome;
    }

    
    public void setApplicantPhoneHome(String applicantPhoneHome) {
        this.applicantPhoneHome = applicantPhoneHome;
    }

    
    public String getApplicantIncome() {
        return applicantIncome;
    }

    
    public void setApplicantIncome(String applicantIncome) {
        this.applicantIncome = applicantIncome;
    }

    
    public String getApplicantNumberTaxID() {
        return applicantNumberTaxID;
    }

    
    public void setApplicantNumberTaxID(String applicantNumberTaxID) {
        this.applicantNumberTaxID = applicantNumberTaxID;
    }

    
    public String getCoApplicantFirstName() {
        return coApplicantFirstName;
    }

    
    public void setCoApplicantFirstName(String coApplicantFirstName) {
        this.coApplicantFirstName = coApplicantFirstName;
    }

    
    public String getCoApplicantMiddleName() {
        return coApplicantMiddleName;
    }

    
    public void setCoApplicantMiddleName(String coApplicantMiddleName) {
        this.coApplicantMiddleName = coApplicantMiddleName;
    }

    
    public String getCoApplicantLastname() {
        return coApplicantLastname;
    }

    
    public void setCoApplicantLastname(String coApplicantLastname) {
        this.coApplicantLastname = coApplicantLastname;
    }

    
    public String getCoApplicantAddressLine1() {
        return coApplicantAddressLine1;
    }

    
    public void setCoApplicantAddressLine1(String coApplicantAddressLine1) {
        this.coApplicantAddressLine1 = coApplicantAddressLine1;
    }

    
    public String getCoApplicantAddressCity() {
        return coApplicantAddressCity;
    }

    
    public void setCoApplicantAddressCity(String coApplicantAddressCity) {
        this.coApplicantAddressCity = coApplicantAddressCity;
    }

    
    public String getCoApplicantAddressState() {
        return coApplicantAddressState;
    }

    
    public void setCoApplicantAddressState(String coApplicantAddressState) {
        this.coApplicantAddressState = coApplicantAddressState;
    }

    
    public String getCoApplicantAddressZip() {
        return coApplicantAddressZip;
    }

    
    public void setCoApplicantAddressZip(String coApplicantAddressZip) {
        this.coApplicantAddressZip = coApplicantAddressZip;
    }

    
    public String getCoApplicantDOB() {
        return coApplicantDOB;
    }

    
    public void setCoApplicantDOB(String coApplicantDOB) {
        this.coApplicantDOB = coApplicantDOB;
    }

    
    public String getCoApplicantPhoneHome() {
        return coApplicantPhoneHome;
    }

    
    public void setCoApplicantPhoneHome(String coApplicantPhoneHome) {
        this.coApplicantPhoneHome = coApplicantPhoneHome;
    }

    
    public String getCoApplicantIncome() {
        return coApplicantIncome;
    }

    
    public void setCoApplicantIncome(String coApplicantIncome) {
        this.coApplicantIncome = coApplicantIncome;
    }

    
    public String getCoApplicantNumberTaxID() {
        return coApplicantNumberTaxID;
    }

    
    public void setCoApplicantNumberTaxID(String coApplicantNumberTaxID) {
        this.coApplicantNumberTaxID = coApplicantNumberTaxID;
    }

    
    public String getCoApplicant2FirstName() {
        return coApplicant2FirstName;
    }

    
    public void setCoApplicant2FirstName(String coApplicant2FirstName) {
        this.coApplicant2FirstName = coApplicant2FirstName;
    }

    
    public String getCoApplicant2MiddleName() {
        return coApplicant2MiddleName;
    }

    
    public void setCoApplicant2MiddleName(String coApplicant2MiddleName) {
        this.coApplicant2MiddleName = coApplicant2MiddleName;
    }

    
    public String getCoApplicant2Lastname() {
        return coApplicant2Lastname;
    }

    
    public void setCoApplicant2Lastname(String coApplicant2Lastname) {
        this.coApplicant2Lastname = coApplicant2Lastname;
    }

    
    public String getCoApplicant2AddressLine1() {
        return coApplicant2AddressLine1;
    }

    
    public void setCoApplicant2AddressLine1(String coApplicant2AddressLine1) {
        this.coApplicant2AddressLine1 = coApplicant2AddressLine1;
    }

    
    public String getCoApplicant2AddressCity() {
        return coApplicant2AddressCity;
    }

    
    public void setCoApplicant2AddressCity(String coApplicant2AddressCity) {
        this.coApplicant2AddressCity = coApplicant2AddressCity;
    }

    
    public String getCoApplicant2AddressState() {
        return coApplicant2AddressState;
    }

    
    public void setCoApplicant2AddressState(String coApplicant2AddressState) {
        this.coApplicant2AddressState = coApplicant2AddressState;
    }

    
    public String getCoApplicant2AddressZip() {
        return coApplicant2AddressZip;
    }

    
    public void setCoApplicant2AddressZip(String coApplicant2AddressZip) {
        this.coApplicant2AddressZip = coApplicant2AddressZip;
    }

    
    public String getCoApplicant2DOB() {
        return coApplicant2DOB;
    }

    
    public void setCoApplicant2DOB(String coApplicant2DOB) {
        this.coApplicant2DOB = coApplicant2DOB;
    }

    
    public String getCoApplicant2PhoneHome() {
        return coApplicant2PhoneHome;
    }

    
    public void setCoApplicant2PhoneHome(String coApplicant2PhoneHome) {
        this.coApplicant2PhoneHome = coApplicant2PhoneHome;
    }

    
    public String getCoApplicant2Income() {
        return coApplicant2Income;
    }

    
    public void setCoApplicant2Income(String coApplicant2Income) {
        this.coApplicant2Income = coApplicant2Income;
    }

    
    public String getCoApplicant2NumberTaxID() {
        return coApplicant2NumberTaxID;
    }

    
    public void setCoApplicant2NumberTaxID(String coApplicant2NumberTaxID) {
        this.coApplicant2NumberTaxID = coApplicant2NumberTaxID;
    }

    
    public String getCoSignerFirstName() {
        return coSignerFirstName;
    }

    
    public void setCoSignerFirstName(String coSignerFirstName) {
        this.coSignerFirstName = coSignerFirstName;
    }

    
    public String getCoSignerMiddleName() {
        return coSignerMiddleName;
    }

    
    public void setCoSignerMiddleName(String coSignerMiddleName) {
        this.coSignerMiddleName = coSignerMiddleName;
    }

    
    public String getCoSignerLastname() {
        return coSignerLastname;
    }

    
    public void setCoSignerLastname(String coSignerLastname) {
        this.coSignerLastname = coSignerLastname;
    }

    
    public String getCoSignerAddressLine1() {
        return coSignerAddressLine1;
    }

    
    public void setCoSignerAddressLine1(String coSignerAddressLine1) {
        this.coSignerAddressLine1 = coSignerAddressLine1;
    }

    
    public String getCoSignerAddressCity() {
        return coSignerAddressCity;
    }

    
    public void setCoSignerAddressCity(String coSignerAddressCity) {
        this.coSignerAddressCity = coSignerAddressCity;
    }

    
    public String getCoSignerAddressState() {
        return coSignerAddressState;
    }

    
    public void setCoSignerAddressState(String coSignerAddressState) {
        this.coSignerAddressState = coSignerAddressState;
    }

    
    public String getCoSignerAddressZip() {
        return coSignerAddressZip;
    }

    
    public void setCoSignerAddressZip(String coSignerAddressZip) {
        this.coSignerAddressZip = coSignerAddressZip;
    }

    
    public String getCoSignerDOB() {
        return coSignerDOB;
    }

    
    public void setCoSignerDOB(String coSignerDOB) {
        this.coSignerDOB = coSignerDOB;
    }

    
    public String getCoSignerPhoneHome() {
        return coSignerPhoneHome;
    }

    
    public void setCoSignerPhoneHome(String coSignerPhoneHome) {
        this.coSignerPhoneHome = coSignerPhoneHome;
    }

    
    public String getCoSignerIncome() {
        return coSignerIncome;
    }

    
    public void setCoSignerIncome(String coSignerIncome) {
        this.coSignerIncome = coSignerIncome;
    }

    
    public String getCoSignerNumberTaxID() {
        return coSignerNumberTaxID;
    }

    
    public void setCoSignerNumberTaxID(String coSignerNumberTaxID) {
        this.coSignerNumberTaxID = coSignerNumberTaxID;
    }

    
    public String getCoSigner2FirstName() {
        return coSigner2FirstName;
    }

    
    public void setCoSigner2FirstName(String coSigner2FirstName) {
        this.coSigner2FirstName = coSigner2FirstName;
    }

    
    public String getCoSigner2MiddleName() {
        return coSigner2MiddleName;
    }

    
    public void setCoSigner2MiddleName(String coSigner2MiddleName) {
        this.coSigner2MiddleName = coSigner2MiddleName;
    }

    
    public String getCoSigner2Lastname() {
        return coSigner2Lastname;
    }

    
    public void setCoSigner2Lastname(String coSigner2Lastname) {
        this.coSigner2Lastname = coSigner2Lastname;
    }

    
    public String getCoSigner2AddressLine1() {
        return coSigner2AddressLine1;
    }

    
    public void setCoSigner2AddressLine1(String coSigner2AddressLine1) {
        this.coSigner2AddressLine1 = coSigner2AddressLine1;
    }

    
    public String getCoSigner2AddressCity() {
        return coSigner2AddressCity;
    }

    
    public void setCoSigner2AddressCity(String coSigner2AddressCity) {
        this.coSigner2AddressCity = coSigner2AddressCity;
    }

    
    public String getCoSigner2AddressState() {
        return coSigner2AddressState;
    }

    
    public void setCoSigner2AddressState(String coSigner2AddressState) {
        this.coSigner2AddressState = coSigner2AddressState;
    }

    
    public String getCoSigner2AddressZip() {
        return coSigner2AddressZip;
    }

    
    public void setCoSigner2AddressZip(String coSigner2AddressZip) {
        this.coSigner2AddressZip = coSigner2AddressZip;
    }

    
    public String getCoSigner2DOB() {
        return coSigner2DOB;
    }

    
    public void setCoSigner2DOB(String coSigner2DOB) {
        this.coSigner2DOB = coSigner2DOB;
    }

    
    public String getCoSigner2PhoneHome() {
        return coSigner2PhoneHome;
    }

    
    public void setCoSigner2PhoneHome(String coSigner2PhoneHome) {
        this.coSigner2PhoneHome = coSigner2PhoneHome;
    }

    
    public String getCoSigner2Income() {
        return coSigner2Income;
    }

    
    public void setCoSigner2Income(String coSigner2Income) {
        this.coSigner2Income = coSigner2Income;
    }

    
    public String getCoSigner2NumberTaxID() {
        return coSigner2NumberTaxID;
    }

    
    public void setCoSigner2NumberTaxID(String coSigner2NumberTaxID) {
        this.coSigner2NumberTaxID = coSigner2NumberTaxID;
    }

    
    public String getReqeustedLoan() {
        return reqeustedLoan;
    }

    
    public void setReqeustedLoan(String reqeustedLoan) {
        this.reqeustedLoan = reqeustedLoan;
    }

    
    public String getOriginalLoanBalance() {
        return originalLoanBalance;
    }

    
    public void setOriginalLoanBalance(String originalLoanBalance) {
        this.originalLoanBalance = originalLoanBalance;
    }

    
    public String getDateAction() {
        return dateAction;
    }

    
    public void setDateAction(String dateAction) {
        this.dateAction = dateAction;
    }

    
    public String getDateAppReceived() {
        return dateAppReceived;
    }

    
    public void setDateAppReceived(String dateAppReceived) {
        this.dateAppReceived = dateAppReceived;
    }

    
    public String getCodeLoanType() {
        return codeLoanType;
    }

    
    public void setCodeLoanType(String codeLoanType) {
        this.codeLoanType = codeLoanType;
    }

    
    public String getCodeAction() {
        return codeAction;
    }

    
    public void setCodeAction(String codeAction) {
        this.codeAction = codeAction;
    }

    
    public String getCodeOriginationSource() {
        return codeOriginationSource;
    }

    
    public void setCodeOriginationSource(String codeOriginationSource) {
        this.codeOriginationSource = codeOriginationSource;
    }

    
    public String getCodeDenial1() {
        return codeDenial1;
    }

    
    public void setCodeDenial1(String codeDenial1) {
        this.codeDenial1 = codeDenial1;
    }

    
    public String getDenialDescription1() {
        return denialDescription1;
    }

    
    public void setDenialDescription1(String denialDescription1) {
        this.denialDescription1 = denialDescription1;
    }

    
    public String getCodeDenial2() {
        return codeDenial2;
    }

    
    public void setCodeDenial2(String codeDenial2) {
        this.codeDenial2 = codeDenial2;
    }

    
    public String getDenialDescription2() {
        return denialDescription2;
    }

    
    public void setDenialDescription2(String denialDescription2) {
        this.denialDescription2 = denialDescription2;
    }

    
    public String getCodeDenial3() {
        return codeDenial3;
    }

    
    public void setCodeDenial3(String codeDenial3) {
        this.codeDenial3 = codeDenial3;
    }

    
    public String getDenialDescription3() {
        return denialDescription3;
    }

    
    public void setDenialDescription3(String denialDescription3) {
        this.denialDescription3 = denialDescription3;
    }

    
    public String getCodeDenial4() {
        return codeDenial4;
    }

    
    public void setCodeDenial4(String codeDenial4) {
        this.codeDenial4 = codeDenial4;
    }

    
    public String getDenialDescription4() {
        return denialDescription4;
    }

    
    public void setDenialDescription4(String denialDescription4) {
        this.denialDescription4 = denialDescription4;
    }

    
    public String getCodeProduct() {
        return codeProduct;
    }

    
    public void setCodeProduct(String codeProduct) {
        this.codeProduct = codeProduct;
    }

    
    public String getCodeOverride1() {
        return codeOverride1;
    }

    
    public void setCodeOverride1(String codeOverride1) {
        this.codeOverride1 = codeOverride1;
    }

    
    public String getReasonDescription1() {
        return reasonDescription1;
    }

    
    public void setReasonDescription1(String reasonDescription1) {
        this.reasonDescription1 = reasonDescription1;
    }

    
    public String getCodeOverride2() {
        return codeOverride2;
    }

    
    public void setCodeOverride2(String codeOverride2) {
        this.codeOverride2 = codeOverride2;
    }

    
    public String getReasonDescription2() {
        return reasonDescription2;
    }

    
    public void setReasonDescription2(String reasonDescription2) {
        this.reasonDescription2 = reasonDescription2;
    }

    
    public String getCodeOverride3() {
        return codeOverride3;
    }

    
    public void setCodeOverride3(String codeOverride3) {
        this.codeOverride3 = codeOverride3;
    }

    
    public String getReasonDescription3() {
        return reasonDescription3;
    }

    
    public void setReasonDescription3(String reasonDescription3) {
        this.reasonDescription3 = reasonDescription3;
    }

    
    public String getCodeOfficer() {
        return codeOfficer;
    }

    
    public void setCodeOfficer(String codeOfficer) {
        this.codeOfficer = codeOfficer;
    }

    
    public int getApplicantCreditNumberInquiries() {
        return applicantCreditNumberInquiries;
    }

    
    public void setApplicantCreditNumberInquiries(int applicantCreditNumberInquiries) {
        this.applicantCreditNumberInquiries = applicantCreditNumberInquiries;
    }

    
    public int getApplicantCreditNumberMajorTotalDelinquencies() {
        return applicantCreditNumberMajorTotalDelinquencies;
    }

    
    public void setApplicantCreditNumberMajorTotalDelinquencies(int applicantCreditNumberMajorTotalDelinquencies) {
        this.applicantCreditNumberMajorTotalDelinquencies = applicantCreditNumberMajorTotalDelinquencies;
    }

    
    public int getApplicantCreditNumberMinorTotalDelinquencies() {
        return applicantCreditNumberMinorTotalDelinquencies;
    }

    
    public void setApplicantCreditNumberMinorTotalDelinquencies(int applicantCreditNumberMinorTotalDelinquencies) {
        this.applicantCreditNumberMinorTotalDelinquencies = applicantCreditNumberMinorTotalDelinquencies;
    }

    
    public int getApplicantCreditNumberSatisfactoryAccounts() {
        return applicantCreditNumberSatisfactoryAccounts;
    }

    
    public void setApplicantCreditNumberSatisfactoryAccounts(int applicantCreditNumberSatisfactoryAccounts) {
        this.applicantCreditNumberSatisfactoryAccounts = applicantCreditNumberSatisfactoryAccounts;
    }

    
    public double getApplicantCreditScore() {
        return applicantCreditScore;
    }

    
    public void setApplicantCreditScore(double applicantCreditScore) {
        this.applicantCreditScore = applicantCreditScore;
    }

    
    public int getApplicantTotalBankruptcies() {
        return applicantTotalBankruptcies;
    }

    
    public void setApplicantTotalBankruptcies(int applicantTotalBankruptcies) {
        this.applicantTotalBankruptcies = applicantTotalBankruptcies;
    }

    
    public int getApplicantTotalCollections() {
        return applicantTotalCollections;
    }

    
    public void setApplicantTotalCollections(int applicantTotalCollections) {
        this.applicantTotalCollections = applicantTotalCollections;
    }

    
    public int getCoApplicantCreditNumberInquiries() {
        return coApplicantCreditNumberInquiries;
    }

    
    public void setCoApplicantCreditNumberInquiries(int coApplicantCreditNumberInquiries) {
        this.coApplicantCreditNumberInquiries = coApplicantCreditNumberInquiries;
    }

    
    public int getCoApplicantCreditNumberMajorTotalDelinquencies() {
        return coApplicantCreditNumberMajorTotalDelinquencies;
    }

    
    public void setCoApplicantCreditNumberMajorTotalDelinquencies(int coApplicantCreditNumberMajorTotalDelinquencies) {
        this.coApplicantCreditNumberMajorTotalDelinquencies = coApplicantCreditNumberMajorTotalDelinquencies;
    }

    
    public int getCoApplicantCreditNumberMinorTotalDelinquencies() {
        return coApplicantCreditNumberMinorTotalDelinquencies;
    }

    
    public void setCoApplicantCreditNumberMinorTotalDelinquencies(int coApplicantCreditNumberMinorTotalDelinquencies) {
        this.coApplicantCreditNumberMinorTotalDelinquencies = coApplicantCreditNumberMinorTotalDelinquencies;
    }

    
    public int getCoApplicantCreditNumberSatisfactoryAccounts() {
        return coApplicantCreditNumberSatisfactoryAccounts;
    }

    
    public void setCoApplicantCreditNumberSatisfactoryAccounts(int coApplicantCreditNumberSatisfactoryAccounts) {
        this.coApplicantCreditNumberSatisfactoryAccounts = coApplicantCreditNumberSatisfactoryAccounts;
    }

    
    public double getCoApplicantCreditScore() {
        return coApplicantCreditScore;
    }

    
    public void setCoApplicantCreditScore(double coApplicantCreditScore) {
        this.coApplicantCreditScore = coApplicantCreditScore;
    }

    
    public int getCoApplicantTotalBankruptcies() {
        return coApplicantTotalBankruptcies;
    }

    
    public void setCoApplicantTotalBankruptcies(int coApplicantTotalBankruptcies) {
        this.coApplicantTotalBankruptcies = coApplicantTotalBankruptcies;
    }

    
    public int getCoApplicantTotalCollections() {
        return coApplicantTotalCollections;
    }

    
    public void setCoApplicantTotalCollections(int coApplicantTotalCollections) {
        this.coApplicantTotalCollections = coApplicantTotalCollections;
    }

    
    public int getCoApplicant2CreditNumberInquiries() {
        return coApplicant2CreditNumberInquiries;
    }

    
    public void setCoApplicant2CreditNumberInquiries(int coApplicant2CreditNumberInquiries) {
        this.coApplicant2CreditNumberInquiries = coApplicant2CreditNumberInquiries;
    }

    
    public int getCoApplicant2CreditNumberMajorTotalDelinquencies() {
        return coApplicant2CreditNumberMajorTotalDelinquencies;
    }

    
    public void setCoApplicant2CreditNumberMajorTotalDelinquencies(int coApplicant2CreditNumberMajorTotalDelinquencies) {
        this.coApplicant2CreditNumberMajorTotalDelinquencies = coApplicant2CreditNumberMajorTotalDelinquencies;
    }

    
    public int getCoApplicant2CreditNumberMinorTotalDelinquencies() {
        return coApplicant2CreditNumberMinorTotalDelinquencies;
    }

    
    public void setCoApplicant2CreditNumberMinorTotalDelinquencies(int coApplicant2CreditNumberMinorTotalDelinquencies) {
        this.coApplicant2CreditNumberMinorTotalDelinquencies = coApplicant2CreditNumberMinorTotalDelinquencies;
    }

    
    public int getCoApplicant2CreditNumberSatisfactoryAccounts() {
        return coApplicant2CreditNumberSatisfactoryAccounts;
    }

    
    public void setCoApplicant2CreditNumberSatisfactoryAccounts(int coApplicant2CreditNumberSatisfactoryAccounts) {
        this.coApplicant2CreditNumberSatisfactoryAccounts = coApplicant2CreditNumberSatisfactoryAccounts;
    }

    
    public double getCoApplicant2CreditScore() {
        return coApplicant2CreditScore;
    }

    
    public void setCoApplicant2CreditScore(double coApplicant2CreditScore) {
        this.coApplicant2CreditScore = coApplicant2CreditScore;
    }

    
    public int getCoApplicant2TotalBankruptcies() {
        return coApplicant2TotalBankruptcies;
    }

    
    public void setCoApplicant2TotalBankruptcies(int coApplicant2TotalBankruptcies) {
        this.coApplicant2TotalBankruptcies = coApplicant2TotalBankruptcies;
    }

    
    public int getCoApplicant2TotalCollections() {
        return coApplicant2TotalCollections;
    }

    
    public void setCoApplicant2TotalCollections(int coApplicant2TotalCollections) {
        this.coApplicant2TotalCollections = coApplicant2TotalCollections;
    }

    
    public int getCoSignerCreditNumberInquiries() {
        return coSignerCreditNumberInquiries;
    }

    
    public void setCoSignerCreditNumberInquiries(int coSignerCreditNumberInquiries) {
        this.coSignerCreditNumberInquiries = coSignerCreditNumberInquiries;
    }

    
    public int getCoSignerCreditNumberMajorTotalDelinquencies() {
        return coSignerCreditNumberMajorTotalDelinquencies;
    }

    
    public void setCoSignerCreditNumberMajorTotalDelinquencies(int coSignerCreditNumberMajorTotalDelinquencies) {
        this.coSignerCreditNumberMajorTotalDelinquencies = coSignerCreditNumberMajorTotalDelinquencies;
    }

    
    public int getCoSignerCreditNumberMinorTotalDelinquencies() {
        return coSignerCreditNumberMinorTotalDelinquencies;
    }

    
    public void setCoSignerCreditNumberMinorTotalDelinquencies(int coSignerCreditNumberMinorTotalDelinquencies) {
        this.coSignerCreditNumberMinorTotalDelinquencies = coSignerCreditNumberMinorTotalDelinquencies;
    }

    
    public int getCoSignerCreditNumberSatisfactoryAccounts() {
        return coSignerCreditNumberSatisfactoryAccounts;
    }

    
    public void setCoSignerCreditNumberSatisfactoryAccounts(int coSignerCreditNumberSatisfactoryAccounts) {
        this.coSignerCreditNumberSatisfactoryAccounts = coSignerCreditNumberSatisfactoryAccounts;
    }

    
    public double getCoSignerCreditScore() {
        return coSignerCreditScore;
    }

    
    public void setCoSignerCreditScore(double coSignerCreditScore) {
        this.coSignerCreditScore = coSignerCreditScore;
    }

    
    public int getCoSignerTotalBankruptcies() {
        return coSignerTotalBankruptcies;
    }

    
    public void setCoSignerTotalBankruptcies(int coSignerTotalBankruptcies) {
        this.coSignerTotalBankruptcies = coSignerTotalBankruptcies;
    }

    
    public int getCoSignerTotalCollections() {
        return coSignerTotalCollections;
    }

    
    public void setCoSignerTotalCollections(int coSignerTotalCollections) {
        this.coSignerTotalCollections = coSignerTotalCollections;
    }

    
    public int getCoSigner2CreditNumberInquiries() {
        return coSigner2CreditNumberInquiries;
    }

    
    public void setCoSigner2CreditNumberInquiries(int coSigner2CreditNumberInquiries) {
        this.coSigner2CreditNumberInquiries = coSigner2CreditNumberInquiries;
    }

    
    public int getCoSigner2CreditNumberMajorTotalDelinquencies() {
        return coSigner2CreditNumberMajorTotalDelinquencies;
    }

    
    public void setCoSigner2CreditNumberMajorTotalDelinquencies(int coSigner2CreditNumberMajorTotalDelinquencies) {
        this.coSigner2CreditNumberMajorTotalDelinquencies = coSigner2CreditNumberMajorTotalDelinquencies;
    }

    
    public int getCoSigner2CreditNumberMinorTotalDelinquencies() {
        return coSigner2CreditNumberMinorTotalDelinquencies;
    }

    
    public void setCoSigner2CreditNumberMinorTotalDelinquencies(int coSigner2CreditNumberMinorTotalDelinquencies) {
        this.coSigner2CreditNumberMinorTotalDelinquencies = coSigner2CreditNumberMinorTotalDelinquencies;
    }

    
    public int getCoSigner2CreditNumberSatisfactoryAccounts() {
        return coSigner2CreditNumberSatisfactoryAccounts;
    }

    
    public void setCoSigner2CreditNumberSatisfactoryAccounts(int coSigner2CreditNumberSatisfactoryAccounts) {
        this.coSigner2CreditNumberSatisfactoryAccounts = coSigner2CreditNumberSatisfactoryAccounts;
    }

    
    public double getCoSigner2CreditScore() {
        return coSigner2CreditScore;
    }

    
    public void setCoSigner2CreditScore(double coSigner2CreditScore) {
        this.coSigner2CreditScore = coSigner2CreditScore;
    }

    
    public int getCoSigner2TotalBankruptcies() {
        return coSigner2TotalBankruptcies;
    }

    
    public void setCoSigner2TotalBankruptcies(int coSigner2TotalBankruptcies) {
        this.coSigner2TotalBankruptcies = coSigner2TotalBankruptcies;
    }

    
    public int getCoSigner2TotalCollections() {
        return coSigner2TotalCollections;
    }

    
    public void setCoSigner2TotalCollections(int coSigner2TotalCollections) {
        this.coSigner2TotalCollections = coSigner2TotalCollections;
    }

    
    public double getRateInterestOriginal() {
        return rateInterestOriginal;
    }

    
    public void setRateInterestOriginal(double rateInterestOriginal) {
        this.rateInterestOriginal = rateInterestOriginal;
    }

    
    public int getTermLoanOriginal() {
        return termLoanOriginal;
    }

    
    public void setTermLoanOriginal(int termLoanOriginal) {
        this.termLoanOriginal = termLoanOriginal;
    }

    
    public double getApplicantRatioDebtServiceHousing() {
        return applicantRatioDebtServiceHousing;
    }

    
    public void setApplicantRatioDebtServiceHousing(double applicantRatioDebtServiceHousing) {
        this.applicantRatioDebtServiceHousing = applicantRatioDebtServiceHousing;
    }

    
    public double getApplicantRatioDebtServiceTotal() {
        return applicantRatioDebtServiceTotal;
    }

    
    public void setApplicantRatioDebtServiceTotal(double applicantRatioDebtServiceTotal) {
        this.applicantRatioDebtServiceTotal = applicantRatioDebtServiceTotal;
    }

    
    public double getApplicantRatioLoantoValue() {
        return applicantRatioLoantoValue;
    }

    
    public void setApplicantRatioLoantoValue(double applicantRatioLoantoValue) {
        this.applicantRatioLoantoValue = applicantRatioLoantoValue;
    }

    
    public double getCoApplicantRatioDebtServiceHousing() {
        return coApplicantRatioDebtServiceHousing;
    }

    
    public void setCoApplicantRatioDebtServiceHousing(double coApplicantRatioDebtServiceHousing) {
        this.coApplicantRatioDebtServiceHousing = coApplicantRatioDebtServiceHousing;
    }

    
    public double getCoApplicantRatioDebtServiceTotal() {
        return coApplicantRatioDebtServiceTotal;
    }

    
    public void setCoApplicantRatioDebtServiceTotal(double coApplicantRatioDebtServiceTotal) {
        this.coApplicantRatioDebtServiceTotal = coApplicantRatioDebtServiceTotal;
    }

    
    public double getCoApplicantRatioLoantoValue() {
        return coApplicantRatioLoantoValue;
    }

    
    public void setCoApplicantRatioLoantoValue(double coApplicantRatioLoantoValue) {
        this.coApplicantRatioLoantoValue = coApplicantRatioLoantoValue;
    }

    
    public double getCoApplicant2RatioDebtServiceHousing() {
        return coApplicant2RatioDebtServiceHousing;
    }

    
    public void setCoApplicant2RatioDebtServiceHousing(double coApplicant2RatioDebtServiceHousing) {
        this.coApplicant2RatioDebtServiceHousing = coApplicant2RatioDebtServiceHousing;
    }

    
    public double getCoApplicant2RatioDebtServiceTotal() {
        return coApplicant2RatioDebtServiceTotal;
    }

    
    public void setCoApplicant2RatioDebtServiceTotal(double coApplicant2RatioDebtServiceTotal) {
        this.coApplicant2RatioDebtServiceTotal = coApplicant2RatioDebtServiceTotal;
    }

    
    public double getCoApplicant2RatioLoantoValue() {
        return coApplicant2RatioLoantoValue;
    }

    
    public void setCoApplicant2RatioLoantoValue(double coApplicant2RatioLoantoValue) {
        this.coApplicant2RatioLoantoValue = coApplicant2RatioLoantoValue;
    }

    
    public double getCoSignerRatioDebtServiceHousing() {
        return coSignerRatioDebtServiceHousing;
    }

    
    public void setCoSignerRatioDebtServiceHousing(double coSignerRatioDebtServiceHousing) {
        this.coSignerRatioDebtServiceHousing = coSignerRatioDebtServiceHousing;
    }

    
    public double getCoSignerRatioDebtServiceTotal() {
        return coSignerRatioDebtServiceTotal;
    }

    
    public void setCoSignerRatioDebtServiceTotal(double coSignerRatioDebtServiceTotal) {
        this.coSignerRatioDebtServiceTotal = coSignerRatioDebtServiceTotal;
    }

    
    public double getCoSignerRatioLoantoValue() {
        return coSignerRatioLoantoValue;
    }

    
    public void setCoSignerRatioLoantoValue(double coSignerRatioLoantoValue) {
        this.coSignerRatioLoantoValue = coSignerRatioLoantoValue;
    }

    
    public double getCoSigner2RatioDebtServiceHousing() {
        return coSigner2RatioDebtServiceHousing;
    }

    
    public void setCoSigner2RatioDebtServiceHousing(double coSigner2RatioDebtServiceHousing) {
        this.coSigner2RatioDebtServiceHousing = coSigner2RatioDebtServiceHousing;
    }

    
    public double getCoSigner2RatioDebtServiceTotal() {
        return coSigner2RatioDebtServiceTotal;
    }

    
    public void setCoSigner2RatioDebtServiceTotal(double coSigner2RatioDebtServiceTotal) {
        this.coSigner2RatioDebtServiceTotal = coSigner2RatioDebtServiceTotal;
    }

    
    public double getCoSigner2RatioLoantoValue() {
        return coSigner2RatioLoantoValue;
    }

    
    public void setCoSigner2RatioLoantoValue(double coSigner2RatioLoantoValue) {
        this.coSigner2RatioLoantoValue = coSigner2RatioLoantoValue;
    }

    
    public String getDealerLienName() {
        return dealerLienName;
    }

    
    public void setDealerLienName(String dealerLienName) {
        this.dealerLienName = dealerLienName;
    }



    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((agentID == null) ? 0 : agentID.hashCode());
        result = prime * result + ((applicantAddressCity == null) ? 0 : applicantAddressCity.hashCode());
        result = prime * result + ((applicantAddressLine1 == null) ? 0 : applicantAddressLine1.hashCode());
        result = prime * result + ((applicantAddressState == null) ? 0 : applicantAddressState.hashCode());
        result = prime * result + ((applicantAddressZip == null) ? 0 : applicantAddressZip.hashCode());
        result = prime * result + applicantCreditNumberInquiries;
        result = prime * result + applicantCreditNumberMajorTotalDelinquencies;
        result = prime * result + applicantCreditNumberMinorTotalDelinquencies;
        result = prime * result + applicantCreditNumberSatisfactoryAccounts;
        long temp;
        temp = Double.doubleToLongBits(applicantCreditScore);
        result = prime * result + (int) (temp ^ (temp >>> 32));
        result = prime * result + ((applicantDOB == null) ? 0 : applicantDOB.hashCode());
        result = prime * result + ((applicantFirstName == null) ? 0 : applicantFirstName.hashCode());
        result = prime * result + ((applicantIncome == null) ? 0 : applicantIncome.hashCode());
        result = prime * result + ((applicantLastname == null) ? 0 : applicantLastname.hashCode());
        result = prime * result + ((applicantMiddleName == null) ? 0 : applicantMiddleName.hashCode());
        result = prime * result + ((applicantNumberTaxID == null) ? 0 : applicantNumberTaxID.hashCode());
        result = prime * result + ((applicantPhoneHome == null) ? 0 : applicantPhoneHome.hashCode());
        temp = Double.doubleToLongBits(applicantRatioDebtServiceHousing);
        result = prime * result + (int) (temp ^ (temp >>> 32));
        temp = Double.doubleToLongBits(applicantRatioDebtServiceTotal);
        result = prime * result + (int) (temp ^ (temp >>> 32));
        temp = Double.doubleToLongBits(applicantRatioLoantoValue);
        result = prime * result + (int) (temp ^ (temp >>> 32));
        result = prime * result + applicantTotalBankruptcies;
        result = prime * result + applicantTotalCollections;
        result = prime * result + ((applicationID == null) ? 0 : applicationID.hashCode());
        result = prime * result + ((bankID == null) ? 0 : bankID.hashCode());
        result = prime * result + ((coApplicant2AddressCity == null) ? 0 : coApplicant2AddressCity.hashCode());
        result = prime * result + ((coApplicant2AddressLine1 == null) ? 0 : coApplicant2AddressLine1.hashCode());
        result = prime * result + ((coApplicant2AddressState == null) ? 0 : coApplicant2AddressState.hashCode());
        result = prime * result + ((coApplicant2AddressZip == null) ? 0 : coApplicant2AddressZip.hashCode());
        result = prime * result + coApplicant2CreditNumberInquiries;
        result = prime * result + coApplicant2CreditNumberMajorTotalDelinquencies;
        result = prime * result + coApplicant2CreditNumberMinorTotalDelinquencies;
        result = prime * result + coApplicant2CreditNumberSatisfactoryAccounts;
        temp = Double.doubleToLongBits(coApplicant2CreditScore);
        result = prime * result + (int) (temp ^ (temp >>> 32));
        result = prime * result + ((coApplicant2DOB == null) ? 0 : coApplicant2DOB.hashCode());
        result = prime * result + ((coApplicant2FirstName == null) ? 0 : coApplicant2FirstName.hashCode());
        result = prime * result + ((coApplicant2Income == null) ? 0 : coApplicant2Income.hashCode());
        result = prime * result + ((coApplicant2Lastname == null) ? 0 : coApplicant2Lastname.hashCode());
        result = prime * result + ((coApplicant2MiddleName == null) ? 0 : coApplicant2MiddleName.hashCode());
        result = prime * result + ((coApplicant2NumberTaxID == null) ? 0 : coApplicant2NumberTaxID.hashCode());
        result = prime * result + ((coApplicant2PhoneHome == null) ? 0 : coApplicant2PhoneHome.hashCode());
        temp = Double.doubleToLongBits(coApplicant2RatioDebtServiceHousing);
        result = prime * result + (int) (temp ^ (temp >>> 32));
        temp = Double.doubleToLongBits(coApplicant2RatioDebtServiceTotal);
        result = prime * result + (int) (temp ^ (temp >>> 32));
        temp = Double.doubleToLongBits(coApplicant2RatioLoantoValue);
        result = prime * result + (int) (temp ^ (temp >>> 32));
        result = prime * result + coApplicant2TotalBankruptcies;
        result = prime * result + coApplicant2TotalCollections;
        result = prime * result + ((coApplicantAddressCity == null) ? 0 : coApplicantAddressCity.hashCode());
        result = prime * result + ((coApplicantAddressLine1 == null) ? 0 : coApplicantAddressLine1.hashCode());
        result = prime * result + ((coApplicantAddressState == null) ? 0 : coApplicantAddressState.hashCode());
        result = prime * result + ((coApplicantAddressZip == null) ? 0 : coApplicantAddressZip.hashCode());
        result = prime * result + coApplicantCreditNumberInquiries;
        result = prime * result + coApplicantCreditNumberMajorTotalDelinquencies;
        result = prime * result + coApplicantCreditNumberMinorTotalDelinquencies;
        result = prime * result + coApplicantCreditNumberSatisfactoryAccounts;
        temp = Double.doubleToLongBits(coApplicantCreditScore);
        result = prime * result + (int) (temp ^ (temp >>> 32));
        result = prime * result + ((coApplicantDOB == null) ? 0 : coApplicantDOB.hashCode());
        result = prime * result + ((coApplicantFirstName == null) ? 0 : coApplicantFirstName.hashCode());
        result = prime * result + ((coApplicantIncome == null) ? 0 : coApplicantIncome.hashCode());
        result = prime * result + ((coApplicantLastname == null) ? 0 : coApplicantLastname.hashCode());
        result = prime * result + ((coApplicantMiddleName == null) ? 0 : coApplicantMiddleName.hashCode());
        result = prime * result + ((coApplicantNumberTaxID == null) ? 0 : coApplicantNumberTaxID.hashCode());
        result = prime * result + ((coApplicantPhoneHome == null) ? 0 : coApplicantPhoneHome.hashCode());
        temp = Double.doubleToLongBits(coApplicantRatioDebtServiceHousing);
        result = prime * result + (int) (temp ^ (temp >>> 32));
        temp = Double.doubleToLongBits(coApplicantRatioDebtServiceTotal);
        result = prime * result + (int) (temp ^ (temp >>> 32));
        temp = Double.doubleToLongBits(coApplicantRatioLoantoValue);
        result = prime * result + (int) (temp ^ (temp >>> 32));
        result = prime * result + coApplicantTotalBankruptcies;
        result = prime * result + coApplicantTotalCollections;
        result = prime * result + ((coSigner2AddressCity == null) ? 0 : coSigner2AddressCity.hashCode());
        result = prime * result + ((coSigner2AddressLine1 == null) ? 0 : coSigner2AddressLine1.hashCode());
        result = prime * result + ((coSigner2AddressState == null) ? 0 : coSigner2AddressState.hashCode());
        result = prime * result + ((coSigner2AddressZip == null) ? 0 : coSigner2AddressZip.hashCode());
        result = prime * result + coSigner2CreditNumberInquiries;
        result = prime * result + coSigner2CreditNumberMajorTotalDelinquencies;
        result = prime * result + coSigner2CreditNumberMinorTotalDelinquencies;
        result = prime * result + coSigner2CreditNumberSatisfactoryAccounts;
        temp = Double.doubleToLongBits(coSigner2CreditScore);
        result = prime * result + (int) (temp ^ (temp >>> 32));
        result = prime * result + ((coSigner2DOB == null) ? 0 : coSigner2DOB.hashCode());
        result = prime * result + ((coSigner2FirstName == null) ? 0 : coSigner2FirstName.hashCode());
        result = prime * result + ((coSigner2Income == null) ? 0 : coSigner2Income.hashCode());
        result = prime * result + ((coSigner2Lastname == null) ? 0 : coSigner2Lastname.hashCode());
        result = prime * result + ((coSigner2MiddleName == null) ? 0 : coSigner2MiddleName.hashCode());
        result = prime * result + ((coSigner2NumberTaxID == null) ? 0 : coSigner2NumberTaxID.hashCode());
        result = prime * result + ((coSigner2PhoneHome == null) ? 0 : coSigner2PhoneHome.hashCode());
        temp = Double.doubleToLongBits(coSigner2RatioDebtServiceHousing);
        result = prime * result + (int) (temp ^ (temp >>> 32));
        temp = Double.doubleToLongBits(coSigner2RatioDebtServiceTotal);
        result = prime * result + (int) (temp ^ (temp >>> 32));
        temp = Double.doubleToLongBits(coSigner2RatioLoantoValue);
        result = prime * result + (int) (temp ^ (temp >>> 32));
        result = prime * result + coSigner2TotalBankruptcies;
        result = prime * result + coSigner2TotalCollections;
        result = prime * result + ((coSignerAddressCity == null) ? 0 : coSignerAddressCity.hashCode());
        result = prime * result + ((coSignerAddressLine1 == null) ? 0 : coSignerAddressLine1.hashCode());
        result = prime * result + ((coSignerAddressState == null) ? 0 : coSignerAddressState.hashCode());
        result = prime * result + ((coSignerAddressZip == null) ? 0 : coSignerAddressZip.hashCode());
        result = prime * result + coSignerCreditNumberInquiries;
        result = prime * result + coSignerCreditNumberMajorTotalDelinquencies;
        result = prime * result + coSignerCreditNumberMinorTotalDelinquencies;
        result = prime * result + coSignerCreditNumberSatisfactoryAccounts;
        temp = Double.doubleToLongBits(coSignerCreditScore);
        result = prime * result + (int) (temp ^ (temp >>> 32));
        result = prime * result + ((coSignerDOB == null) ? 0 : coSignerDOB.hashCode());
        result = prime * result + ((coSignerFirstName == null) ? 0 : coSignerFirstName.hashCode());
        result = prime * result + ((coSignerIncome == null) ? 0 : coSignerIncome.hashCode());
        result = prime * result + ((coSignerLastname == null) ? 0 : coSignerLastname.hashCode());
        result = prime * result + ((coSignerMiddleName == null) ? 0 : coSignerMiddleName.hashCode());
        result = prime * result + ((coSignerNumberTaxID == null) ? 0 : coSignerNumberTaxID.hashCode());
        result = prime * result + ((coSignerPhoneHome == null) ? 0 : coSignerPhoneHome.hashCode());
        temp = Double.doubleToLongBits(coSignerRatioDebtServiceHousing);
        result = prime * result + (int) (temp ^ (temp >>> 32));
        temp = Double.doubleToLongBits(coSignerRatioDebtServiceTotal);
        result = prime * result + (int) (temp ^ (temp >>> 32));
        temp = Double.doubleToLongBits(coSignerRatioLoantoValue);
        result = prime * result + (int) (temp ^ (temp >>> 32));
        result = prime * result + coSignerTotalBankruptcies;
        result = prime * result + coSignerTotalCollections;
        result = prime * result + ((codeAction == null) ? 0 : codeAction.hashCode());
        result = prime * result + ((codeDenial1 == null) ? 0 : codeDenial1.hashCode());
        result = prime * result + ((codeDenial2 == null) ? 0 : codeDenial2.hashCode());
        result = prime * result + ((codeDenial3 == null) ? 0 : codeDenial3.hashCode());
        result = prime * result + ((codeDenial4 == null) ? 0 : codeDenial4.hashCode());
        result = prime * result + ((codeLoanType == null) ? 0 : codeLoanType.hashCode());
        result = prime * result + ((codeOfficer == null) ? 0 : codeOfficer.hashCode());
        result = prime * result + ((codeOriginationSource == null) ? 0 : codeOriginationSource.hashCode());
        result = prime * result + ((codeOverride1 == null) ? 0 : codeOverride1.hashCode());
        result = prime * result + ((codeOverride2 == null) ? 0 : codeOverride2.hashCode());
        result = prime * result + ((codeOverride3 == null) ? 0 : codeOverride3.hashCode());
        result = prime * result + ((codeProduct == null) ? 0 : codeProduct.hashCode());
        result = prime * result + ((dateAction == null) ? 0 : dateAction.hashCode());
        result = prime * result + ((dateAppReceived == null) ? 0 : dateAppReceived.hashCode());
        result = prime * result + ((dealerLienName == null) ? 0 : dealerLienName.hashCode());
        result = prime * result + ((denialDescription1 == null) ? 0 : denialDescription1.hashCode());
        result = prime * result + ((denialDescription2 == null) ? 0 : denialDescription2.hashCode());
        result = prime * result + ((denialDescription3 == null) ? 0 : denialDescription3.hashCode());
        result = prime * result + ((denialDescription4 == null) ? 0 : denialDescription4.hashCode());
        result = prime * result + ((originalLoanBalance == null) ? 0 : originalLoanBalance.hashCode());
        temp = Double.doubleToLongBits(rateInterestOriginal);
        result = prime * result + (int) (temp ^ (temp >>> 32));
        result = prime * result + ((reasonDescription1 == null) ? 0 : reasonDescription1.hashCode());
        result = prime * result + ((reasonDescription2 == null) ? 0 : reasonDescription2.hashCode());
        result = prime * result + ((reasonDescription3 == null) ? 0 : reasonDescription3.hashCode());
        result = prime * result + ((referenceNumber == null) ? 0 : referenceNumber.hashCode());
        result = prime * result + ((reqeustedLoan == null) ? 0 : reqeustedLoan.hashCode());
        result = prime * result + termLoanOriginal;
        result = prime * result + ((userid == null) ? 0 : userid.hashCode());
        return result;
    }



    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        SingleFeedCSVByNameBean other = (SingleFeedCSVByNameBean) obj;
        if (agentID == null) {
            if (other.agentID != null)
                return false;
        } else if (!agentID.equals(other.agentID))
            return false;
        if (applicantAddressCity == null) {
            if (other.applicantAddressCity != null)
                return false;
        } else if (!applicantAddressCity.equals(other.applicantAddressCity))
            return false;
        if (applicantAddressLine1 == null) {
            if (other.applicantAddressLine1 != null)
                return false;
        } else if (!applicantAddressLine1.equals(other.applicantAddressLine1))
            return false;
        if (applicantAddressState == null) {
            if (other.applicantAddressState != null)
                return false;
        } else if (!applicantAddressState.equals(other.applicantAddressState))
            return false;
        if (applicantAddressZip == null) {
            if (other.applicantAddressZip != null)
                return false;
        } else if (!applicantAddressZip.equals(other.applicantAddressZip))
            return false;
        if (applicantCreditNumberInquiries != other.applicantCreditNumberInquiries)
            return false;
        if (applicantCreditNumberMajorTotalDelinquencies != other.applicantCreditNumberMajorTotalDelinquencies)
            return false;
        if (applicantCreditNumberMinorTotalDelinquencies != other.applicantCreditNumberMinorTotalDelinquencies)
            return false;
        if (applicantCreditNumberSatisfactoryAccounts != other.applicantCreditNumberSatisfactoryAccounts)
            return false;
        if (Double.doubleToLongBits(applicantCreditScore) != Double.doubleToLongBits(other.applicantCreditScore))
            return false;
        if (applicantDOB == null) {
            if (other.applicantDOB != null)
                return false;
        } else if (!applicantDOB.equals(other.applicantDOB))
            return false;
        if (applicantFirstName == null) {
            if (other.applicantFirstName != null)
                return false;
        } else if (!applicantFirstName.equals(other.applicantFirstName))
            return false;
        if (applicantIncome == null) {
            if (other.applicantIncome != null)
                return false;
        } else if (!applicantIncome.equals(other.applicantIncome))
            return false;
        if (applicantLastname == null) {
            if (other.applicantLastname != null)
                return false;
        } else if (!applicantLastname.equals(other.applicantLastname))
            return false;
        if (applicantMiddleName == null) {
            if (other.applicantMiddleName != null)
                return false;
        } else if (!applicantMiddleName.equals(other.applicantMiddleName))
            return false;
        if (applicantNumberTaxID == null) {
            if (other.applicantNumberTaxID != null)
                return false;
        } else if (!applicantNumberTaxID.equals(other.applicantNumberTaxID))
            return false;
        if (applicantPhoneHome == null) {
            if (other.applicantPhoneHome != null)
                return false;
        } else if (!applicantPhoneHome.equals(other.applicantPhoneHome))
            return false;
        if (Double.doubleToLongBits(applicantRatioDebtServiceHousing) != Double.doubleToLongBits(other.applicantRatioDebtServiceHousing))
            return false;
        if (Double.doubleToLongBits(applicantRatioDebtServiceTotal) != Double.doubleToLongBits(other.applicantRatioDebtServiceTotal))
            return false;
        if (Double.doubleToLongBits(applicantRatioLoantoValue) != Double.doubleToLongBits(other.applicantRatioLoantoValue))
            return false;
        if (applicantTotalBankruptcies != other.applicantTotalBankruptcies)
            return false;
        if (applicantTotalCollections != other.applicantTotalCollections)
            return false;
        if (applicationID == null) {
            if (other.applicationID != null)
                return false;
        } else if (!applicationID.equals(other.applicationID))
            return false;
        if (bankID == null) {
            if (other.bankID != null)
                return false;
        } else if (!bankID.equals(other.bankID))
            return false;
        if (coApplicant2AddressCity == null) {
            if (other.coApplicant2AddressCity != null)
                return false;
        } else if (!coApplicant2AddressCity.equals(other.coApplicant2AddressCity))
            return false;
        if (coApplicant2AddressLine1 == null) {
            if (other.coApplicant2AddressLine1 != null)
                return false;
        } else if (!coApplicant2AddressLine1.equals(other.coApplicant2AddressLine1))
            return false;
        if (coApplicant2AddressState == null) {
            if (other.coApplicant2AddressState != null)
                return false;
        } else if (!coApplicant2AddressState.equals(other.coApplicant2AddressState))
            return false;
        if (coApplicant2AddressZip == null) {
            if (other.coApplicant2AddressZip != null)
                return false;
        } else if (!coApplicant2AddressZip.equals(other.coApplicant2AddressZip))
            return false;
        if (coApplicant2CreditNumberInquiries != other.coApplicant2CreditNumberInquiries)
            return false;
        if (coApplicant2CreditNumberMajorTotalDelinquencies != other.coApplicant2CreditNumberMajorTotalDelinquencies)
            return false;
        if (coApplicant2CreditNumberMinorTotalDelinquencies != other.coApplicant2CreditNumberMinorTotalDelinquencies)
            return false;
        if (coApplicant2CreditNumberSatisfactoryAccounts != other.coApplicant2CreditNumberSatisfactoryAccounts)
            return false;
        if (Double.doubleToLongBits(coApplicant2CreditScore) != Double.doubleToLongBits(other.coApplicant2CreditScore))
            return false;
        if (coApplicant2DOB == null) {
            if (other.coApplicant2DOB != null)
                return false;
        } else if (!coApplicant2DOB.equals(other.coApplicant2DOB))
            return false;
        if (coApplicant2FirstName == null) {
            if (other.coApplicant2FirstName != null)
                return false;
        } else if (!coApplicant2FirstName.equals(other.coApplicant2FirstName))
            return false;
        if (coApplicant2Income == null) {
            if (other.coApplicant2Income != null)
                return false;
        } else if (!coApplicant2Income.equals(other.coApplicant2Income))
            return false;
        if (coApplicant2Lastname == null) {
            if (other.coApplicant2Lastname != null)
                return false;
        } else if (!coApplicant2Lastname.equals(other.coApplicant2Lastname))
            return false;
        if (coApplicant2MiddleName == null) {
            if (other.coApplicant2MiddleName != null)
                return false;
        } else if (!coApplicant2MiddleName.equals(other.coApplicant2MiddleName))
            return false;
        if (coApplicant2NumberTaxID == null) {
            if (other.coApplicant2NumberTaxID != null)
                return false;
        } else if (!coApplicant2NumberTaxID.equals(other.coApplicant2NumberTaxID))
            return false;
        if (coApplicant2PhoneHome == null) {
            if (other.coApplicant2PhoneHome != null)
                return false;
        } else if (!coApplicant2PhoneHome.equals(other.coApplicant2PhoneHome))
            return false;
        if (Double.doubleToLongBits(coApplicant2RatioDebtServiceHousing) != Double.doubleToLongBits(other.coApplicant2RatioDebtServiceHousing))
            return false;
        if (Double.doubleToLongBits(coApplicant2RatioDebtServiceTotal) != Double.doubleToLongBits(other.coApplicant2RatioDebtServiceTotal))
            return false;
        if (Double.doubleToLongBits(coApplicant2RatioLoantoValue) != Double.doubleToLongBits(other.coApplicant2RatioLoantoValue))
            return false;
        if (coApplicant2TotalBankruptcies != other.coApplicant2TotalBankruptcies)
            return false;
        if (coApplicant2TotalCollections != other.coApplicant2TotalCollections)
            return false;
        if (coApplicantAddressCity == null) {
            if (other.coApplicantAddressCity != null)
                return false;
        } else if (!coApplicantAddressCity.equals(other.coApplicantAddressCity))
            return false;
        if (coApplicantAddressLine1 == null) {
            if (other.coApplicantAddressLine1 != null)
                return false;
        } else if (!coApplicantAddressLine1.equals(other.coApplicantAddressLine1))
            return false;
        if (coApplicantAddressState == null) {
            if (other.coApplicantAddressState != null)
                return false;
        } else if (!coApplicantAddressState.equals(other.coApplicantAddressState))
            return false;
        if (coApplicantAddressZip == null) {
            if (other.coApplicantAddressZip != null)
                return false;
        } else if (!coApplicantAddressZip.equals(other.coApplicantAddressZip))
            return false;
        if (coApplicantCreditNumberInquiries != other.coApplicantCreditNumberInquiries)
            return false;
        if (coApplicantCreditNumberMajorTotalDelinquencies != other.coApplicantCreditNumberMajorTotalDelinquencies)
            return false;
        if (coApplicantCreditNumberMinorTotalDelinquencies != other.coApplicantCreditNumberMinorTotalDelinquencies)
            return false;
        if (coApplicantCreditNumberSatisfactoryAccounts != other.coApplicantCreditNumberSatisfactoryAccounts)
            return false;
        if (Double.doubleToLongBits(coApplicantCreditScore) != Double.doubleToLongBits(other.coApplicantCreditScore))
            return false;
        if (coApplicantDOB == null) {
            if (other.coApplicantDOB != null)
                return false;
        } else if (!coApplicantDOB.equals(other.coApplicantDOB))
            return false;
        if (coApplicantFirstName == null) {
            if (other.coApplicantFirstName != null)
                return false;
        } else if (!coApplicantFirstName.equals(other.coApplicantFirstName))
            return false;
        if (coApplicantIncome == null) {
            if (other.coApplicantIncome != null)
                return false;
        } else if (!coApplicantIncome.equals(other.coApplicantIncome))
            return false;
        if (coApplicantLastname == null) {
            if (other.coApplicantLastname != null)
                return false;
        } else if (!coApplicantLastname.equals(other.coApplicantLastname))
            return false;
        if (coApplicantMiddleName == null) {
            if (other.coApplicantMiddleName != null)
                return false;
        } else if (!coApplicantMiddleName.equals(other.coApplicantMiddleName))
            return false;
        if (coApplicantNumberTaxID == null) {
            if (other.coApplicantNumberTaxID != null)
                return false;
        } else if (!coApplicantNumberTaxID.equals(other.coApplicantNumberTaxID))
            return false;
        if (coApplicantPhoneHome == null) {
            if (other.coApplicantPhoneHome != null)
                return false;
        } else if (!coApplicantPhoneHome.equals(other.coApplicantPhoneHome))
            return false;
        if (Double.doubleToLongBits(coApplicantRatioDebtServiceHousing) != Double.doubleToLongBits(other.coApplicantRatioDebtServiceHousing))
            return false;
        if (Double.doubleToLongBits(coApplicantRatioDebtServiceTotal) != Double.doubleToLongBits(other.coApplicantRatioDebtServiceTotal))
            return false;
        if (Double.doubleToLongBits(coApplicantRatioLoantoValue) != Double.doubleToLongBits(other.coApplicantRatioLoantoValue))
            return false;
        if (coApplicantTotalBankruptcies != other.coApplicantTotalBankruptcies)
            return false;
        if (coApplicantTotalCollections != other.coApplicantTotalCollections)
            return false;
        if (coSigner2AddressCity == null) {
            if (other.coSigner2AddressCity != null)
                return false;
        } else if (!coSigner2AddressCity.equals(other.coSigner2AddressCity))
            return false;
        if (coSigner2AddressLine1 == null) {
            if (other.coSigner2AddressLine1 != null)
                return false;
        } else if (!coSigner2AddressLine1.equals(other.coSigner2AddressLine1))
            return false;
        if (coSigner2AddressState == null) {
            if (other.coSigner2AddressState != null)
                return false;
        } else if (!coSigner2AddressState.equals(other.coSigner2AddressState))
            return false;
        if (coSigner2AddressZip == null) {
            if (other.coSigner2AddressZip != null)
                return false;
        } else if (!coSigner2AddressZip.equals(other.coSigner2AddressZip))
            return false;
        if (coSigner2CreditNumberInquiries != other.coSigner2CreditNumberInquiries)
            return false;
        if (coSigner2CreditNumberMajorTotalDelinquencies != other.coSigner2CreditNumberMajorTotalDelinquencies)
            return false;
        if (coSigner2CreditNumberMinorTotalDelinquencies != other.coSigner2CreditNumberMinorTotalDelinquencies)
            return false;
        if (coSigner2CreditNumberSatisfactoryAccounts != other.coSigner2CreditNumberSatisfactoryAccounts)
            return false;
        if (Double.doubleToLongBits(coSigner2CreditScore) != Double.doubleToLongBits(other.coSigner2CreditScore))
            return false;
        if (coSigner2DOB == null) {
            if (other.coSigner2DOB != null)
                return false;
        } else if (!coSigner2DOB.equals(other.coSigner2DOB))
            return false;
        if (coSigner2FirstName == null) {
            if (other.coSigner2FirstName != null)
                return false;
        } else if (!coSigner2FirstName.equals(other.coSigner2FirstName))
            return false;
        if (coSigner2Income == null) {
            if (other.coSigner2Income != null)
                return false;
        } else if (!coSigner2Income.equals(other.coSigner2Income))
            return false;
        if (coSigner2Lastname == null) {
            if (other.coSigner2Lastname != null)
                return false;
        } else if (!coSigner2Lastname.equals(other.coSigner2Lastname))
            return false;
        if (coSigner2MiddleName == null) {
            if (other.coSigner2MiddleName != null)
                return false;
        } else if (!coSigner2MiddleName.equals(other.coSigner2MiddleName))
            return false;
        if (coSigner2NumberTaxID == null) {
            if (other.coSigner2NumberTaxID != null)
                return false;
        } else if (!coSigner2NumberTaxID.equals(other.coSigner2NumberTaxID))
            return false;
        if (coSigner2PhoneHome == null) {
            if (other.coSigner2PhoneHome != null)
                return false;
        } else if (!coSigner2PhoneHome.equals(other.coSigner2PhoneHome))
            return false;
        if (Double.doubleToLongBits(coSigner2RatioDebtServiceHousing) != Double.doubleToLongBits(other.coSigner2RatioDebtServiceHousing))
            return false;
        if (Double.doubleToLongBits(coSigner2RatioDebtServiceTotal) != Double.doubleToLongBits(other.coSigner2RatioDebtServiceTotal))
            return false;
        if (Double.doubleToLongBits(coSigner2RatioLoantoValue) != Double.doubleToLongBits(other.coSigner2RatioLoantoValue))
            return false;
        if (coSigner2TotalBankruptcies != other.coSigner2TotalBankruptcies)
            return false;
        if (coSigner2TotalCollections != other.coSigner2TotalCollections)
            return false;
        if (coSignerAddressCity == null) {
            if (other.coSignerAddressCity != null)
                return false;
        } else if (!coSignerAddressCity.equals(other.coSignerAddressCity))
            return false;
        if (coSignerAddressLine1 == null) {
            if (other.coSignerAddressLine1 != null)
                return false;
        } else if (!coSignerAddressLine1.equals(other.coSignerAddressLine1))
            return false;
        if (coSignerAddressState == null) {
            if (other.coSignerAddressState != null)
                return false;
        } else if (!coSignerAddressState.equals(other.coSignerAddressState))
            return false;
        if (coSignerAddressZip == null) {
            if (other.coSignerAddressZip != null)
                return false;
        } else if (!coSignerAddressZip.equals(other.coSignerAddressZip))
            return false;
        if (coSignerCreditNumberInquiries != other.coSignerCreditNumberInquiries)
            return false;
        if (coSignerCreditNumberMajorTotalDelinquencies != other.coSignerCreditNumberMajorTotalDelinquencies)
            return false;
        if (coSignerCreditNumberMinorTotalDelinquencies != other.coSignerCreditNumberMinorTotalDelinquencies)
            return false;
        if (coSignerCreditNumberSatisfactoryAccounts != other.coSignerCreditNumberSatisfactoryAccounts)
            return false;
        if (Double.doubleToLongBits(coSignerCreditScore) != Double.doubleToLongBits(other.coSignerCreditScore))
            return false;
        if (coSignerDOB == null) {
            if (other.coSignerDOB != null)
                return false;
        } else if (!coSignerDOB.equals(other.coSignerDOB))
            return false;
        if (coSignerFirstName == null) {
            if (other.coSignerFirstName != null)
                return false;
        } else if (!coSignerFirstName.equals(other.coSignerFirstName))
            return false;
        if (coSignerIncome == null) {
            if (other.coSignerIncome != null)
                return false;
        } else if (!coSignerIncome.equals(other.coSignerIncome))
            return false;
        if (coSignerLastname == null) {
            if (other.coSignerLastname != null)
                return false;
        } else if (!coSignerLastname.equals(other.coSignerLastname))
            return false;
        if (coSignerMiddleName == null) {
            if (other.coSignerMiddleName != null)
                return false;
        } else if (!coSignerMiddleName.equals(other.coSignerMiddleName))
            return false;
        if (coSignerNumberTaxID == null) {
            if (other.coSignerNumberTaxID != null)
                return false;
        } else if (!coSignerNumberTaxID.equals(other.coSignerNumberTaxID))
            return false;
        if (coSignerPhoneHome == null) {
            if (other.coSignerPhoneHome != null)
                return false;
        } else if (!coSignerPhoneHome.equals(other.coSignerPhoneHome))
            return false;
        if (Double.doubleToLongBits(coSignerRatioDebtServiceHousing) != Double.doubleToLongBits(other.coSignerRatioDebtServiceHousing))
            return false;
        if (Double.doubleToLongBits(coSignerRatioDebtServiceTotal) != Double.doubleToLongBits(other.coSignerRatioDebtServiceTotal))
            return false;
        if (Double.doubleToLongBits(coSignerRatioLoantoValue) != Double.doubleToLongBits(other.coSignerRatioLoantoValue))
            return false;
        if (coSignerTotalBankruptcies != other.coSignerTotalBankruptcies)
            return false;
        if (coSignerTotalCollections != other.coSignerTotalCollections)
            return false;
        if (codeAction == null) {
            if (other.codeAction != null)
                return false;
        } else if (!codeAction.equals(other.codeAction))
            return false;
        if (codeDenial1 == null) {
            if (other.codeDenial1 != null)
                return false;
        } else if (!codeDenial1.equals(other.codeDenial1))
            return false;
        if (codeDenial2 == null) {
            if (other.codeDenial2 != null)
                return false;
        } else if (!codeDenial2.equals(other.codeDenial2))
            return false;
        if (codeDenial3 == null) {
            if (other.codeDenial3 != null)
                return false;
        } else if (!codeDenial3.equals(other.codeDenial3))
            return false;
        if (codeDenial4 == null) {
            if (other.codeDenial4 != null)
                return false;
        } else if (!codeDenial4.equals(other.codeDenial4))
            return false;
        if (codeLoanType == null) {
            if (other.codeLoanType != null)
                return false;
        } else if (!codeLoanType.equals(other.codeLoanType))
            return false;
        if (codeOfficer == null) {
            if (other.codeOfficer != null)
                return false;
        } else if (!codeOfficer.equals(other.codeOfficer))
            return false;
        if (codeOriginationSource == null) {
            if (other.codeOriginationSource != null)
                return false;
        } else if (!codeOriginationSource.equals(other.codeOriginationSource))
            return false;
        if (codeOverride1 == null) {
            if (other.codeOverride1 != null)
                return false;
        } else if (!codeOverride1.equals(other.codeOverride1))
            return false;
        if (codeOverride2 == null) {
            if (other.codeOverride2 != null)
                return false;
        } else if (!codeOverride2.equals(other.codeOverride2))
            return false;
        if (codeOverride3 == null) {
            if (other.codeOverride3 != null)
                return false;
        } else if (!codeOverride3.equals(other.codeOverride3))
            return false;
        if (codeProduct == null) {
            if (other.codeProduct != null)
                return false;
        } else if (!codeProduct.equals(other.codeProduct))
            return false;
        if (dateAction == null) {
            if (other.dateAction != null)
                return false;
        } else if (!dateAction.equals(other.dateAction))
            return false;
        if (dateAppReceived == null) {
            if (other.dateAppReceived != null)
                return false;
        } else if (!dateAppReceived.equals(other.dateAppReceived))
            return false;
        if (dealerLienName == null) {
            if (other.dealerLienName != null)
                return false;
        } else if (!dealerLienName.equals(other.dealerLienName))
            return false;
        if (denialDescription1 == null) {
            if (other.denialDescription1 != null)
                return false;
        } else if (!denialDescription1.equals(other.denialDescription1))
            return false;
        if (denialDescription2 == null) {
            if (other.denialDescription2 != null)
                return false;
        } else if (!denialDescription2.equals(other.denialDescription2))
            return false;
        if (denialDescription3 == null) {
            if (other.denialDescription3 != null)
                return false;
        } else if (!denialDescription3.equals(other.denialDescription3))
            return false;
        if (denialDescription4 == null) {
            if (other.denialDescription4 != null)
                return false;
        } else if (!denialDescription4.equals(other.denialDescription4))
            return false;
        if (originalLoanBalance == null) {
            if (other.originalLoanBalance != null)
                return false;
        } else if (!originalLoanBalance.equals(other.originalLoanBalance))
            return false;
        if (Double.doubleToLongBits(rateInterestOriginal) != Double.doubleToLongBits(other.rateInterestOriginal))
            return false;
        if (reasonDescription1 == null) {
            if (other.reasonDescription1 != null)
                return false;
        } else if (!reasonDescription1.equals(other.reasonDescription1))
            return false;
        if (reasonDescription2 == null) {
            if (other.reasonDescription2 != null)
                return false;
        } else if (!reasonDescription2.equals(other.reasonDescription2))
            return false;
        if (reasonDescription3 == null) {
            if (other.reasonDescription3 != null)
                return false;
        } else if (!reasonDescription3.equals(other.reasonDescription3))
            return false;
        if (referenceNumber == null) {
            if (other.referenceNumber != null)
                return false;
        } else if (!referenceNumber.equals(other.referenceNumber))
            return false;
        if (reqeustedLoan == null) {
            if (other.reqeustedLoan != null)
                return false;
        } else if (!reqeustedLoan.equals(other.reqeustedLoan))
            return false;
        if (termLoanOriginal != other.termLoanOriginal)
            return false;
        if (userid == null) {
            if (other.userid != null)
                return false;
        } else if (!userid.equals(other.userid))
            return false;
        return true;
    }

       
}
