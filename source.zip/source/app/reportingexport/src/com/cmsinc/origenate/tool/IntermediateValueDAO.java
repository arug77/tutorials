package com.cmsinc.origenate.tool;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.HashMap;
import java.util.Map;

import com.cmsinc.origenate.util.ConnectionUtils;
import com.cmsinc.origenate.util.LogMsg;


public class IntermediateValueDAO {

    private Connection conn;
    private LogMsg log_obj;
    private int log_level;

    /**
     * Public constructor for creating an object of the class.
     * 
     * @param conn
     *            Database Connection Object
     * @param log_obj
     *            LogMsg object
     * @param log_level
     *            Log level from the ini
     */
    public IntermediateValueDAO(Connection conn, LogMsg log_obj, int log_level) {
        this.conn = conn;
        this.log_obj = log_obj;
        this.log_level = log_level;
    }

    /**
     * Gets the data required by singlefeed
     * 
     * @param requestID
     *            The requestID to generate the data for
     * @return Will return the IntermediateValueDTO object
     * @throws Exception
     *             Throws an exception if an error with the database connection occurs
     */
    public IntermediateValuesDTO getSingleFeedData(String requestID) throws Exception {
        Map<String, Map<String, String>> mapInterValues = getValues(requestID);
        return buildDTO(mapInterValues);
    }

    /**
     * Gets the singlefeed specific values for this requestID. The Map<String, Map<String, String>> returned is set up like this: 
     * [Key = EntityTxt, Value = [Key = VariableName, Value = VariableValue]]
     * 
     * @param requestID The requestID to get the data for
     * @return A Map<String, Map<String, String>> of the inter! values, grouped by the requestor entity text
     * @throws Exception Throws an exception if an error occurs with the database connection
     */
    public Map<String, Map<String, String>> getValues(String requestID) throws Exception {
        Map<String, Map<String, String>> mapOuterInterValues = new HashMap<String, Map<String, String>>();
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;

        try {
            String sql =    "SELECT r.request_id, r.entity_txt, cri.variable_name_txt, variable_value_txt " +
                            "FROM requestor r, credit_req_intermediate_value cri " +
                            "WHERE cri.request_id = ? AND r.request_id = cri.request_id " +
                            "AND cri.requestor_id > 0 AND cri.requestor_id = r.requestor_id " +
                            "AND cri.variable_name_txt IN ('Inter!ICDICode','Inter!SFFUserIDQuery', 'Inter!UploadIBS', 'Inter!OfficerNumber', 'Inter!MaxTerm', 'Inter!TotBankruptcyA1', 'Inter!TotBankruptcyC1','Inter!TotBankruptcyC2','Inter!TotBankruptcyS1','Inter!TotBankruptcyS2', 'Inter!TotCollectionA1','Inter!TotCollectionC1','Inter!TotCollectionC2','Inter!TotCollectionS1','Inter!TotCollectionS2');";

            preparedStatement = conn.prepareStatement(sql);
            preparedStatement.setInt(1, Integer.parseInt(requestID));
            resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                String entity = resultSet.getString("entity_txt");
                String varName = resultSet.getString("variable_name_txt");
                String varValue = resultSet.getString("variable_value_txt");

                if (mapOuterInterValues.containsKey(entity)) {
                    mapOuterInterValues.get(entity).put(varName, varValue);
                } else {
                    Map<String, String> mapInnerVar = new HashMap<String, String>();
                    mapInnerVar.put(varName, varValue);
                    mapOuterInterValues.put(entity, mapInnerVar);
                }
            }
        } catch (Exception e) {
            throw new Exception("Error getting singlefeed intermediate values", e);
        } finally {
            ConnectionUtils.closePreparedStatement(preparedStatement);
            ConnectionUtils.closeResultSet(resultSet);
        }

        return mapOuterInterValues;
    }

    /**
     * Builds the DTO object here. Goes through the map and sets each variable appropriately
     * 
     * @param mapOutter
     *            The Map<String, Map<String, String>> housing the Entities, VariableNames, and VariableValues
     */
    private IntermediateValuesDTO buildDTO(Map<String, Map<String, String>> mapOutter) {
        IntermediateValuesDTO interDto = new IntermediateValuesDTO();

        for (String entity : mapOutter.keySet()) {
            Map<String, String> mapInner = mapOutter.get(entity);
            for (String varName : mapInner.keySet()) {
                if (isEntitySpecificVariable(varName)) {
                    interDto = assignProperEntityVariable(interDto, entity, varName, mapInner.get(varName));
                } else {
                    interDto = setDTOVariable(interDto, varName, mapInner.get(varName));
                }
            }
        }

        return interDto;
    }

    /**
     * Checks if the provided variable is an entity specific variable
     * 
     * @param varName
     *            Variable name to check
     * @return True if variable is entity specific, false otherwise
     */
    private boolean isEntitySpecificVariable(String varName) {
        boolean entitySpecific = false;

        if (varName.contains("A1") || varName.contains("C1") || varName.contains("C2") || varName.contains("S1") || varName.contains("S2")) {
            entitySpecific = true;
        }

        return entitySpecific;
    }

    /**
     * Assigns the value to the variable in the DTO. This is for variables that have entity specific names. Ex. 'Inter!TotBankruptcyA1'
     * 
     * @param entity
     *            Entity text
     * @param varName
     *            Variable Name
     * @param varValue
     *            Variable Value
     */
    private IntermediateValuesDTO assignProperEntityVariable(IntermediateValuesDTO interDto, String entity, String varName, String varValue) {
        IntermediateValuesDTO modifiedDto = interDto;
        if (varName.contains(entity)) {
            modifiedDto = setDTOVariable(modifiedDto, varName, varValue);
        }
        return modifiedDto;
    }

    /**
     * Sets the variable of the dto to the correct value
     * 
     * @param varName
     *            Name of the variable
     * @param varVal
     *            Value of the variable
     */
    private IntermediateValuesDTO setDTOVariable(IntermediateValuesDTO interDto, String varName, String varVal) {
        IntermediateValuesDTO modifiedDTO = interDto;

        switch (varName) {
        case "Inter!ICDICode":
            modifiedDTO.setBankID(varVal);
            break;
        case "Inter!SFFUserIDQuery":
            modifiedDTO.setUserid(varVal);
            break;
        case "Inter!UploadIBS":
            modifiedDTO.setCodeLoanType(varVal);
            break;
        case "Inter!OfficerNumber":
            modifiedDTO.setCodeOfficer(varVal);
            break;
        case "Inter!MaxTerm":
            modifiedDTO.setOrigLoanTerm(Integer.parseInt(varVal));
            break;
        case "Inter!TotBankruptcyA1":
            modifiedDTO.setApplicantTotalBankruptcies(Integer.parseInt(varVal));
            break;
        case "Inter!TotCollectionA1":
            modifiedDTO.setApplicantTotalCollections(Integer.parseInt(varVal));
            break;
        case "Inter!TotBankruptcyC1":
            modifiedDTO.setCoApplicant1TotalBankruptcies(Integer.parseInt(varVal));
            break;
        case "Inter!TotCollectionC1":
            modifiedDTO.setCoApplicant1TotalCollections(Integer.parseInt(varVal));
            break;
        case "Inter!TotBankruptcyC2":
            modifiedDTO.setCoApplicant2TotalBankruptcies(Integer.parseInt(varVal));
            break;
        case "Inter!TotCollectionC2":
            modifiedDTO.setCoApplicant2TotalCollections(Integer.parseInt(varVal));
            break;
        case "Inter!TotBankruptcyS1":
            modifiedDTO.setCoSigner1TotalBankruptcies(Integer.parseInt(varVal));
            break;
        case "Inter!TotCollectionS1":
            modifiedDTO.setCoSigner1TotalCollections(Integer.parseInt(varVal));
            break;
        case "Inter!TotBankruptcyS2":
            modifiedDTO.setCoSigner2TotalBankruptcies(Integer.parseInt(varVal));
            break;
        case "Inter!TotCollectionS2":
            modifiedDTO.setCoSigner2TotalCollections(Integer.parseInt(varVal));
            break;
        default:
            break;
        }

        return modifiedDTO;
    }

    /**
     * Logging method for this class. We are using this wrapper because when it passes through this method, logs it will append the class name in
     * front of the log message.
     * 
     * @param msgLevel
     *            Level of the message
     * @param logMsg
     *            The message to log, as a string
     */
    public void log(int msgLevel, String logMsg) {
        if (LogMsg.isDebuggingEnabled(log_level, msgLevel)) {
            log_obj.FmtAndLogMsg("IntermediateValueDAO: " + logMsg);
        }
    }
}