/*
 * SFSingleFeed.java
 *
 * Used to generate a list of applications eligible for reporting DB export.
 * XML representations of these apps are generated, then a stylesheet is applied
 * to put them in a format a DB loading utility can understand.
 * The resulting files (1 per app) are jarred and ftped to reporting DB's server
 * Upon successful completion, an event is written to db.
 *
 * organization as follows:  files are written to subdir 'reportingdbexport'+evaluator_id
 * so as not to intermingle different client apps.  the jar file created is named similarly:
 * 'reportingdbexport'+evaluator_id+current date/time+'.jar'.  once files are jarred, they are deleted.
 */

package com.cmsinc.origenate.tool;

import java.sql.*;
import java.io.*;
import com.cmsinc.origenate.util.DBConnection;
import com.cmsinc.origenate.util.IniFile;
import com.cmsinc.origenate.util.LogMsg;
import com.cmsinc.origenate.util.Query;
import com.cmsinc.origenate.util.RowData;
import com.sf.bank.lue.util.ConnectionInfo;
import com.sf.bank.lue.util.DateFormatter;
import com.sf.bank.lue.util.DateValidator;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorCompletionService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.ThreadPoolExecutor;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;

/**
 * The StateFarm built SingleFeed batch job. This is the main file for this process.
 *
 */
public class SingleFeedFileProcessor {

    private static final int EVALUATOR_ID_STATEFARM = 148;
    private static final String EXPORT_NAME = "SingleFeedFile";
    private final String PROTOCOL = "https";
    private final int EXPORT_ID = 1;

    // Argument Parameters
    private String websvr;
    private String export_dt;
    private String export_end_dt;
    private boolean xslData;

    //******* INI Parameters *******//
    private ConnectionInfo conInfo;
    private int log_level = 0;
    private String logFile = "";
    private LogMsg log_obj = new LogMsg();
    private String outputDir;

    // Default values, these can be configured via the program arguments
    private int threadCount = 10;
    private int batchSize = 10;

    // Connection created using arg values
    private Connection conn = null;
    private AuditDAO daoAudit;
    private CreditRequestDAO daoCreditRequest;

    /**
     * Main method to run this java process. In production this will be invoked by an external job.
     * @param args The arguments to be passed in to the process.
     */
    public static void main(String args[]) {
        SingleFeedFileProcessor sfSingleFeed = new SingleFeedFileProcessor();

        if (sfSingleFeed.run(args)) {
            System.exit(0);
        } else {
            System.exit(1);
        }
    }

    /**
     * The primary method for SingleFeedFileProcessor. This will delegate out all tasks to other methods/classes.
     * @param args Arguments for the process to use.
     * @return Boolean. True if run() executed without errors, false otherwise.
     */
    protected boolean run(String[] args) {
        boolean successfulExecution = true;

        try {
            getArgs(args);
            getDBConnection(conInfo);
            String queryAppSelection = daoCreditRequest.getExportQuery(EVALUATOR_ID_STATEFARM, EXPORT_ID);
            log(0, "<<App Selection Query>>: " + queryAppSelection);

            String pathXSL = getXSLPath();
            writeXMLApps(queryAppSelection, pathXSL);

            daoAudit.logFinishEvent(EVALUATOR_ID_STATEFARM, EXPORT_NAME);
            log(0, "Singlefeed processing done");
        } catch (Exception e) {
            log(0, ExceptionUtils.getStackTrace(e));
            successfulExecution = false;
        } finally {
            // If we have an open database connection close it before we exit.
            try {
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception e) {
                log(0, "Failure closing database connection: " + e.toString());
            }
        }

        return successfulExecution;
    }

    /**
     * Resolves the arguments passed in to their respective instance variables.
     * @param args The arguments for the process to use.
     * @throws Exception Throws an exception if there was a problem resolving the arguments
     */
    protected void getArgs(String[] args) throws Exception {
        checkArgsLength(args);

        for (String argument : args) {

            if ((argument.charAt(0) != '-') && (argument.length() > 1)) {
                System.out.println("Invalid parm: " + argument);
                showUsage();
                return;
            }

            switch (argument.charAt(1)) {
            case 'g':
                export_end_dt = argument.substring(2);

                if (StringUtils.isNotEmpty(export_end_dt)) {
                    if (!DateValidator.isValidDate(export_end_dt)) {
                        throw new Exception("Error with export end date format. See usage.");
                    }
                }

                break;
            case 'x':
                xslData = Boolean.parseBoolean(argument.substring(2));
                break;
            case 'o':
                outputDir = argument.substring(2);
                break;
            case 'n':
                threadCount = Integer.parseInt(argument.substring(2));
                break;
            case 'p':
                batchSize = Integer.parseInt(argument.substring(2));
                break;
            case 'w':
                websvr = argument.substring(2);
                break;
            case 'd':
                export_dt = argument.substring(2);

                if (StringUtils.isNotEmpty(export_dt)) {
                    if (!DateValidator.isValidDate(export_dt)) {
                        throw new Exception("Error with export date format. See usage.");
                    }
                }

                break;
            case 'i':
                String sIniFile = argument.substring(2);
                try {
                    readINIFile(sIniFile);
                } catch (Exception e) {
                    throw new Exception("Caught exception reading ini file '" + sIniFile, e);
                }
                break;
            default:
                showUsage();
                throw new RuntimeException("Argument provided not recognized");
            }
        }
    }

    /**
     * Checks the length of arguments provided.
     * @param args The arguments for the process to use.
     */
    protected void checkArgsLength(String[] args) {
        if (args.length < 7) {
            showUsage();
            throw new RuntimeException("Less than seven arguments provided!");
        }
    }

    /**
     * Sets up the INI file
     * @param sIniFile Path to the INI file
     * @throws Exception Throws an exception if there is a problem reading the ini file
     */
    protected void readINIFile(String sIniFile) throws Exception {
        IniFile ini = new IniFile();
        ini.readINIFile(sIniFile);

        logFile = ini.getINIVar("logs.singlefeed_log_file", "");
        if (!StringUtils.isEmpty(logFile)) {
            log_obj.openLogFile(logFile);
        }

        log(0, "IniFile is '" + sIniFile + "'");
        log(0, "SingleFeed initializing...");

        String sHost = ini.getINIVar("database.host", "");
        String sPort = ini.getINIVar("database.port", "");
        String sUser = ini.getINIVar("database.user", "");
        String sPass = ini.getINIVar("database.password", "");
        String sSIDname = ini.getINIVar("database.sid", "");
        String sTNSEntry = ini.getINIVar("database.TNSEntry", "");
        
        conInfo = new ConnectionInfo(sHost, Integer.parseInt(sPort), sSIDname, sTNSEntry, sUser, sPass);

        try {
            log_level = Integer.parseInt(ini.getINIVar("debug.genx_debug_lvl", "0"));
        } catch (Exception ex) {
            System.out.println("Caught exception reading ini file '" + sIniFile + "' value for debug.genx_debug_lvl, defaulting to 0. " + ex.toString());
            log_level = 0;
        }
    }

    /**
     * Creates a DB connection, if one already exists, it will return the existing.
     * @throws Exception Throws an exception if there is an error getting a DBConnection
     */
    protected void getDBConnection(ConnectionInfo conInfo) throws Exception {
        try {
            if ((conn == null) || (conn.isClosed())) {
                DBConnection DBConnect = new DBConnection();

                if (conInfo.getTnsEntry().length() == 0) {
                    conn = DBConnect.getConnection(conInfo.getHostname(), conInfo.getSid(), conInfo.getUserName(), conInfo.getPassword(), null, String.valueOf(conInfo.getPort()), "");
                } else {
                    // use tns entry if available
                    conn = DBConnect.getConnectionTNS(conInfo.getTnsEntry(), conInfo.getUserName(), conInfo.getPassword(), null);
                }

                daoAudit = new AuditDAO(conn, log_obj, log_level);
                daoCreditRequest = new CreditRequestDAO(conn, log_obj, log_level);
            }
        } catch (Exception e) {
            throw new Exception("Could not create a connection with db information in supplied ini file. See usage", e);
        }
    }

    /**
     * Gets the XSL file Path
     * @return XSL Path
     */
    protected String getXSLPath() {
        String xsl_list = "singlefeed_sf.xsl";
        String pathXSL = "";
        if (xsl_list.length() != 0) {
            pathXSL = PROTOCOL + "://" + websvr + "/origenate/xml/xsl/" + xsl_list.replaceAll(",", "," + PROTOCOL + "://" + websvr + "/origenate/xml/xsl/");
            log(0, "Stylesheets: " + pathXSL);
        }

        return pathXSL;
    }

    /**
     * Logging method for SingleFeedFileProcess. Always call this method when logging in this class, it will log using the universal LogMsg class,
     * this is so we can swap out logging on the fly if need be
     * 
     * @param msgLevel The log level of this message
     * @param logMsg The message string
     */
    protected void log(int msgLevel, String logMsg) {
        if (LogMsg.isDebuggingEnabled(log_level, msgLevel)) {
            log_obj.FmtAndLogMsg(logMsg);
        }
    }

    /**
     * Used for unit testing
     */
    protected void setLogObj(LogMsg log_obj) {
        this.log_obj = log_obj;
    }

    /**
     * Used for unit testing
     */
    protected void setDAOs(CreditRequestDAO crDAO, AuditDAO auditDAO) {
        this.daoCreditRequest = crDAO;
        this.daoAudit = auditDAO;
    }

    /**
     * Processes the applications to get an XML output, then writes this out to file
     * @param queryAppSelection 
     * @param s_xsl
     * @throws Exception
     */
    protected void writeXMLApps(String queryAppSelection, String s_xsl) throws Exception
	{
	    String singleFileName = "";
	    String file_dateCreate = "";

	    StringBuffer singleFileBuffer = new StringBuffer();

        log(0, DateFormatter.formatDate(DateFormatter.FORMAT_LOGS) + " preparing to aggregate apps, apply stylesheet and gen single file");
        file_dateCreate = DateFormatter.formatDate(DateFormatter.FORMAT_FILE);

	    singleFileName = outputDir + File.separator + file_dateCreate + ".dat";
        log(0, "Single File name: " + singleFileName);
        // replace date tokens in the selection query with actual date values passed into the program
        String s_sql = queryAppSelection.replaceAll("\\[begin_date\\]", "to_date('" + export_dt + "', 'MM/DD/YYYY HH:MI AM')");
        s_sql = s_sql.replaceAll("\\[end_date\\]", "to_date('" + export_end_dt + "', 'MM/DD/YYYY HH:MI AM')");

        log(0, "<<App Selection Query Replaced>>:" + s_sql);

        if(xslData){
            // Fetch data using orignal XSL method
            runThreadExecuter(s_xsl, s_sql, singleFileBuffer);
        } else {
            // Fetch data using custom database method
        }
        writeToFile(singleFileName, singleFileBuffer);
        log(0, "Successfully wrote results to file " + singleFileName);
    }

    /**
     * Executes the threads
     * @param s_xsl XSL List
     * @param s_sql Selection query for apps
     * @param singleFileBuffer The StringBuffer for the output
     * @throws Exception Throws an exception if an issue with the threads or DB comes up
     */
    protected void runThreadExecuter(String s_xsl, String s_sql, StringBuffer singleFileBuffer) throws Exception {

        Query query = daoCreditRequest.getAppsToProcess(s_sql);
        log(0, "Total Count:" + query.getRowCount());
        log(0, "Batch Size:" + batchSize);

        ThreadPoolExecutor executor = (ThreadPoolExecutor) Executors.newFixedThreadPool(threadCount);

        ExecutorCompletionService<XMLResult> completionService = new ExecutorCompletionService<XMLResult>(executor);
        List<Future<XMLResult>> resultsFuture = new ArrayList<Future<XMLResult>>();
        int rowCount = 0;
        while (true) {
            List<RowData> list = query.getNextBatch(batchSize);
            rowCount += list.size();

            if (list.isEmpty()) {
                break;
            }

            XMLCreator task = new XMLCreator(conInfo, list, log_level, logFile, s_xsl );
            resultsFuture.add(completionService.submit(task));
        }

        log(0, "All tasks are submitted, Total Records:" + rowCount);

        appendResults(resultsFuture, completionService, singleFileBuffer);
        log(0, "Successfully appended results");
    }

    /**
     * Appends the results of the futures to the StringBuffer
     * @param resultsFuture List of futures
     * @param completionService ExecutorCompletionService
     * @param singleFileBuffer The StringBuffer to write the output to
     * @throws Exception Throws an exception if there is an issue with the futures
     */
    protected void appendResults(List<Future<XMLResult>> resultsFuture, ExecutorCompletionService<XMLResult> completionService, StringBuffer singleFileBuffer) throws Exception {
        int results = 0;
        while (results < resultsFuture.size()) {
            Future<XMLResult> resultFuture = completionService.take();
            try {
                XMLResult result = resultFuture.get();

                singleFileBuffer.append(result.getStyledOutput());
                results++;

                log(0, "No of tasks completed: " + results);
            } catch (InterruptedException | ExecutionException e) {
                throw new Exception("Error occured appending results", e);
            }
        }
	}

    /**
     * Writes out the contents of the StringBuffer to the output file
     * @param singleFileName File name to use
     * @param singleFileBuffer The StringBuffer to write the output to 
     * @throws Exception Throws an exception if an error occurs writing to the file
     */
    protected void writeToFile(String singleFileName, StringBuffer singleFileBuffer) throws Exception {
        try {
            PrintWriter out = new PrintWriter(new FileWriter(singleFileName));
            out.print(singleFileBuffer.toString());
            out.flush();
            out.close();
        } catch (Exception e) {
            throw new Exception("Can not write single file output", e);
        }
    }

    /**
     * Prints out the argument usage of this process
     */
    protected static void showUsage() {
        System.out.println("Usage:");
        System.out.println("SingleFeedFileProcessor -x<xslData> -o<outputDir> -n<threadCount> -p<batchSize> -w<webserver> -d<begin date> -i<ini file>");
        System.out.println("------------------------------------------------------------------------------");
        System.out.println("-x xslData - true: Use XSL for data gathering. false: Use database for data gathering");
        System.out.println("-o outputDir - Directory of output");
        System.out.println("-n threadCount - Number of threads to use for processing");
        System.out.println("-p batchSize - Number of apps to process per thread");
        System.out.println("-w webserver - web server name ([:port number] if necessary)");
        System.out.println("-d begin date - apps newer than this date/time will be exported (mask:  MM/DD/YYYY)");
        System.out.println("-i ini - path to origenate.ini file to use for configuration");
    }
}