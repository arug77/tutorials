package com.cmsinc.origenate.tool;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Types;

import com.cmsinc.origenate.util.LogMsg;

public class AuditDAO {

    private Connection conn;
    private LogMsg log_obj;
    private int log_level;

    public AuditDAO(Connection conn, LogMsg log_obj, int log_level) {
        this.conn = conn;
        this.log_obj = log_obj;
        this.log_level = log_level;
    }

    public String getDTLastSuccessfulAudit(int evaluator_id, int export_id) throws Exception {
        String audit_file_last_create_dt = "";
        PreparedStatement ps = null;
        ResultSet rs = null;
        String sql = "Select nvl(TO_CHAR(audit_file_last_create_dt,'MM/DD/YYYY HH24:MI:SS'),'') audit_file_last_create_dt " +
            " from config_data_extract " +
            " where EVALUATOR_ID = ? AND data_extract_id = ?";
        try {
            ps = conn.prepareStatement(sql);
            ps.setInt(1, evaluator_id);
            ps.setInt(2, export_id);
            rs = ps.executeQuery();

            if (rs.next()) {
                audit_file_last_create_dt = getStringValue(rs, "audit_file_last_create_dt");
            }

        } catch (Exception e) {
            throw new Exception("Error getting audit_file_last_create_dt", e);
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }

                if (ps != null) {
                    ps.close();
                }
            } catch (Exception e) {
                log(0, "Unable to close PreparedStatement/ResultSet" + e.toString());
            }
        }

        return audit_file_last_create_dt;
    }

    public void updateDTLastSuccessfulAudit(int evaluator_id, int export_id) throws Exception {
        PreparedStatement ps = null;
        String updateSql = "update config_data_extract " +
            " set audit_file_last_create_dt = sysdate " +
            " where EVALUATOR_ID = ? AND data_extract_id = ?";
        try {
            ps = conn.prepareStatement(updateSql);
            ps.setInt(1, evaluator_id);
            ps.setInt(2, export_id);
            ps.execute();
        } catch (Exception e) {
            throw new Exception("Error updating audit_file_last_create_dt", e);
        } finally {
            try {
                if (ps != null){
                    ps.close();
                }
            } catch (Exception e) {
                log(0, "Unable to close PreparedStatement" + e.toString());
            }
        }
    }

    public String createAuditRecord(String request_id, int evaluator_id, boolean current) throws Exception {

        String audit_txt = "";
        String endOfLine = "\r\n";
        String pipe = "|";
        String sql = "";
        String detailRecordType = "2";
        String client_app_id = "";
        String app_status_id = "";
        String app_status_txt = "";
        String init_dt = "";
        String decision_status_id = "";
        String decision_status_txt = "";
        String booked_dt = "";
        String total_verif_income = "";
        String decision_ltv = "";
        String decision_bureau_score = "";
        String collat_total_value = "";
        String contr_mature_dt = "";
        String count_applicants = "";
        String count_decisions = "";
        String count_journal_items = "";
        String count_checklist_items = "";

        //interim values not printed to audit file
        String latest_decision_ref_id = "";
        String appseqno = "";
        String bureau_of_record = "";
        String bor_requestor_id ="" ;

        //only used for detail record type of 2
        String app_closed_dt = "";

        PreparedStatement ps = null;
        ResultSet rs = null;
        CallableStatement cs = null;

        if(current){
            detailRecordType = "1";
        }

        try {
            //1st query: CREDIT_REQUEST
            sql = "select CR.CLIENT_APP_ID, cr.App_status_id , TO_CHAR(CR.INITIATION_DT,'MM/DD/YYYY') INITIATION_DT, CR.DECISION_STATUS_ID , nvl(CR.LATEST_DEC_REF_ID,'') LATEST_DEC_REF_ID, CR.APPSEQNO, TO_CHAR(CR.AUDIT_LAST_UPDATED_DT,'MM/DD/YYYY') AUDIT_LAST_UPDATED_DT " +
                    " from CREDIT_REQUEST CR " +
                    " where CR.REQUEST_ID = ? and evaluator_id = ?  " ;

            ps = conn.prepareStatement(sql);
            ps.setString(1, request_id);
            ps.setInt(2, evaluator_id);
            rs = ps.executeQuery();
            
            if (rs.next()) {
                client_app_id = getStringValue(rs, "CLIENT_APP_ID");
                app_status_id = getStringValue(rs, "App_status_id");
                init_dt = getStringValue(rs, "INITIATION_DT");
                decision_status_id = getStringValue(rs, "DECISION_STATUS_ID");
                latest_decision_ref_id = getStringValue(rs, "LATEST_DEC_REF_ID"); // //interim value not printed to audit file - used for querying credit_req_decisions_ptidti
                appseqno = getStringValue(rs, "APPSEQNO");// interim value not printed to audit file
                app_closed_dt = getStringValue(rs, "AUDIT_LAST_UPDATED_DT"); // used for closed record
            }

            try {
                if (rs != null) {
                    rs.close();
                }

                if (ps != null) {
                    ps.close();
                }
            } catch (Exception e) {
                log(0, "Unable to close PreparedStatement/ResultSet" + e.toString());
            }

            //extension of 1st query

            sql = "select mas.STATUS_CODE from MSTR_APP_STATUS MAS where mas.status_id = ?";
            ps = conn.prepareStatement(sql);
            ps.setString(1, app_status_id);
            rs = ps.executeQuery();
            if(rs.next()) {
                app_status_txt = getStringValue(rs,"STATUS_CODE");
            }

            try {
                if (rs != null) {
                    rs.close();
                }

                if (ps != null) {
                    ps.close();
                }
            } catch (Exception e) {
                log(0, "Unable to close PreparedStatement/ResultSet" + e.toString());
            }

            //extension of 1st query
            sql = "select med.DECISION_TXT from MSTR_EVALUATOR_DECISION med where med.DECISION_ID = ?";
            ps = conn.prepareStatement(sql);
            ps.setString(1, decision_status_id);
            rs = ps.executeQuery();
            if(rs.next()) {
                decision_status_txt = getStringValue(rs,"DECISION_TXT");
            }

            try {
                if (rs != null) {
                    rs.close();
                }

                if (ps != null) {
                    ps.close();
                }
            } catch (Exception e) {
                log(0, "Unable to close PreparedStatement/ResultSet" + e.toString());
            }

            if (current) { // if its not a current record detail don't run these queries
                //2nd query: CREDIT_REQUEST_ACTIVITY
                sql = "select  TO_CHAR(CRA.AUDIT_LAST_UPDATED_DT,'MM/DD/YYYY') date_booked " +
                        " from CREDIT_REQUEST_ACTIVITY CRA " +
                        " where CRA.ACTIVITY_STATUS_ID = 3 " + //-- (complete)
                        " and CRA.ACTIVITY_ID= 23 " +// --(booked)
                        " and CRA.REQUEST_ID = ? " +
                        " and cra.task_group_id = 'CONTRACTADMIN' " ;
                ps = conn.prepareStatement(sql);
                ps.setString(1, request_id);
                rs = ps.executeQuery();

                if(rs.next()) {
                    booked_dt = getStringValue(rs,"date_booked");
                }

                try {
                    if (rs != null) {
                        rs.close();
                    }

                    if (ps != null) {
                        ps.close();
                    }
                } catch (Exception e) {
                    log(0, "Unable to close PreparedStatement/ResultSet" + e.toString());
                }

                //3rd query get ltv
                sql = "select VARIABLEVALUE from evapp_intermediate_value where variablename = 'Inter!LTV' and APPENTITY= 'ALL' and appseqno = ?" ;
                ps = conn.prepareStatement(sql);
                ps.setString(1, appseqno);
                rs = ps.executeQuery();

                if(rs.next()) {
                    decision_ltv = getStringValue(rs,"VARIABLEVALUE");
                }

                try {
                    if (rs != null)
                        rs.close();

                    if (ps != null)
                        ps.close();
                } catch (Exception e) {
                    log(0, "Unable to close PreparedStatement/ResultSet" + e.toString());
                }

                    // interim query
                sql = " SELECT nvl(rbh.BUREAU_ID, '') BUREAU_ID,  app.requestor_type_id, nvl(app.requestor_id,'') requestor_id " +
                        " FROM credit_request cr, REQUESTOR_BUREAU_HEADER rbh, requestor app " +
                        " WHERE cr.request_id =  ? " +
                        " AND cr.request_id = rbh.request_id " +
                        " AND cr.request_id = app.request_id " +
                        " AND app.requestor_id = rbh.requestor_id " +
                        " AND     rbh.bureau_of_record_flg   = 1 " +
                        " AND     app.requestor_type_id in (-1,0) " +
                        " ORDER BY app.requestor_type_id asc " ;
                ps = conn.prepareStatement(sql);
                ps.setString(1, request_id);
                rs = ps.executeQuery();

                if(rs.next()) {
                    bureau_of_record = getStringValue(rs,"BUREAU_ID"); //interim value not printed to audit file
                    bor_requestor_id = getStringValue(rs,"requestor_id"); //interim value not printed to audit file
                }

                try {
                    if (rs != null) {
                        rs.close();
                    }

                    if (ps != null) {
                        ps.close();
                    }
                } catch (Exception e) {
                    log(0, "Unable to close PreparedStatement/ResultSet" + e.toString());
                }

                if (!bureau_of_record.equals("") && !bor_requestor_id.equals("")) {
                    //4th query: REQUESTOR_BUREAU_SUMMARY
                    sql = "select SCORE_OF_GRADE_NUM " +
                            " from REQUESTOR_BUREAU_SUMMARY " +
                            " where request_id = ? " +
                            " and BUREAU_ID = ? " +
                            " and requestor_id = ? " ;
                    ps = conn.prepareStatement(sql);
                    ps.setString(1, request_id);
                    ps.setString(2, bureau_of_record);
                    ps.setString(3, bor_requestor_id);
                    rs = ps.executeQuery();

                    if(rs.next()) {
                        decision_bureau_score = getStringValue(rs,"SCORE_OF_GRADE_NUM");
                    }

                    try {
                        if (rs != null) {
                            rs.close();
                        }

                        if (ps != null) {
                            ps.close();
                        }
                    } catch (Exception e) {
                        log(0, "Unable to close PreparedStatement/ResultSet" + e.toString());
                    }
                }

                //5th query: CREDIT_REQ_CONTR_FIN
                sql = "select TO_CHAR(MATURITY_DT,'MM/DD/YYYY') MATURITY_DT " +
                        " from CREDIT_REQ_CONTR_FIN " +
                        " where request_id = ? " +
                        " and appseqno = ? " ;
                ps = conn.prepareStatement(sql);
                ps.setString(1, request_id);
                ps.setString(2, appseqno);
                rs = ps.executeQuery();

                if (rs.next()) {
                    contr_mature_dt = getStringValue(rs, "MATURITY_DT");
                }

                try {
                    if (rs != null)
                        rs.close();

                    if (ps != null)
                        ps.close();
                } catch (Exception e) {
                    log(0, "Unable to close PreparedStatement/ResultSet" + e.toString());
                }

                //6th query count on requestor_header
                sql = "select COUNT(1) count_applicants from requestor_header where request_id = ? and requestor_type_id >=0";
                ps = conn.prepareStatement(sql);
                ps.setString(1, request_id);
                rs = ps.executeQuery();

                if(rs.next()) {
                    count_applicants = getStringValue(rs,"count_applicants");
                }

                try {
                    if (rs != null) {
                        rs.close();
                    }

                    if (ps != null) {
                        ps.close();
                    }
                } catch (Exception e) {
                    log(0, "Unable to close PreparedStatement/ResultSet" + e.toString());
                }

                //7th query count on CREDIT_REQ_DECISIONS_EVALUATOR
                sql = "select COUNT(1) count_decisions from CREDIT_REQ_DECISIONS_EVALUATOR where request_id = ?";
                ps = conn.prepareStatement(sql);
                ps.setString(1, request_id);
                rs = ps.executeQuery();

                if(rs.next()) {
                    count_decisions = getStringValue(rs,"count_decisions");
                }

                try {
                    if (rs != null) {
                        rs.close();
                    }

                    if (ps != null) {
                        ps.close();
                    }
                } catch (Exception e) {
                    log(0, "Unable to close PreparedStatement/ResultSet" + e.toString());
                }

                //8th query count on CREDIT_REQUEST_JOURNAL
                sql = "select COUNT(1) count_journal_items from CREDIT_REQUEST_JOURNAL where request_id = ?";
                ps = conn.prepareStatement(sql);
                ps.setString(1, request_id);
                rs = ps.executeQuery();

                if(rs.next()) {
                    count_journal_items = getStringValue(rs,"count_journal_items");
                }

                try {
                    if (rs != null) {
                        rs.close();
                    }

                    if (ps != null) {
                        ps.close();
                    }
                } catch (Exception e) {
                    log(0, "Unable to close PreparedStatement/ResultSet" + e.toString());
                }

                //9th query count on CREDIT_REQ_CHECKLIST_ITEM
                sql = "select COUNT(1) count_checklist_items from CREDIT_REQ_CHECKLIST_ITEM where request_id = ? and evaluator_id = ?";
                ps = conn.prepareStatement(sql);
                ps.setString(1, request_id);
                ps.setInt(2, evaluator_id);
                rs = ps.executeQuery();

                if(rs.next()) {
                    count_checklist_items = getStringValue(rs,"count_checklist_items");
                }

                try {
                    if (rs != null) {
                        rs.close();
                    }

                    if (ps != null) {
                        ps.close();
                    }
                } catch (Exception e) {
                    log(0, "Unable to close PreparedStatement/ResultSet" + e.toString());
                }

                //10th query get total_verif_income
                sql = "select VARIABLEVALUE from evapp_intermediate_value where appseqno = ? and VARIABLENAME = 'Inter!TotalVerifIncome' and appentity = 'ALL'";
                ps = conn.prepareStatement(sql);
                ps.setString(1, appseqno);
                rs = ps.executeQuery();

                if (rs.next()) {
                    total_verif_income = getStringValue(rs, "VARIABLEVALUE");
                }

                try {
                    if (rs != null) {
                        rs.close();
                    }

                    if (ps != null) {
                        ps.close();
                    }
                } catch (Exception e) {
                    log(0, "Unable to close PreparedStatement/ResultSet" + e.toString());
                }


                //call function to set collat_total_value
                cs = conn.prepareCall("{? = call GET_COLLATERAL_TOTAL_VALUE(?, ?)}");
                cs.registerOutParameter(1, Types.VARCHAR);
                cs.setInt(2, Integer.parseInt(request_id));
                cs.setInt(3, evaluator_id);
                cs.execute();
                collat_total_value = cs.getString(1);
                
                if (collat_total_value == null) {
                    collat_total_value = "";
                }

                try {
                    cs.close();
                } catch (Exception e) {
                    log(0, "Unable to close CallableStatement" + e.toString());
                }
            }
        } catch (Exception e) {
            throw new Exception("Error occured in createAuditRecord", e);
        } finally {
            try {
                if (rs != null)
                    rs.close();

                if (ps != null)
                    ps.close();

                if (cs != null)
                    cs.close();
            } catch (Exception e) {
                log(0, "Unable to close PreparedStatement/ResultSet/CallableStatement" + e.toString());
            }
        }

        audit_txt = detailRecordType + pipe + request_id + pipe + client_app_id + pipe + app_status_txt + pipe;

        if (current) {
            audit_txt += init_dt + pipe + booked_dt + pipe + total_verif_income + pipe;
            audit_txt += decision_ltv + pipe + decision_status_txt + pipe + decision_bureau_score + pipe;
            audit_txt += collat_total_value + pipe + contr_mature_dt + pipe + count_applicants + pipe;
            audit_txt += count_decisions + pipe + count_journal_items + pipe + count_checklist_items;
            audit_txt += endOfLine;
        } else {
            audit_txt += app_closed_dt + endOfLine;
        }

        return audit_txt;
    }

    public void logFinishEvent(int evalID, String exportName) throws Exception {
        try {
            PreparedStatement preparedStatement = null;
            ResultSet resultSet = null;

            String s_sql = "insert into event (event_id,event_type_id,event_dt,evaluator_id,user_id,additional_desc_txt) " + "values " + "(event_id_seq.nextval,3,sysdate,?,'SYSTEM',?)";

            preparedStatement = conn.prepareStatement(s_sql);
            preparedStatement.setInt(1, evalID);
            preparedStatement.setString(2, exportName);

            resultSet = preparedStatement.executeQuery();

            if (resultSet != null) {
                resultSet.close();
            }

            if (preparedStatement != null) {
                preparedStatement.close();
            }
        } catch (Exception e) {
            throw new Exception("An error occured logging the finish event into the table EVENT", e);
        }
    }

    public String getStringValue(ResultSet rs, String columnToRetrieve) throws Exception {
        String retrievedValue = "";
        try {
            retrievedValue = rs.getString(columnToRetrieve);
            if (retrievedValue == null) {
                retrievedValue = "";
            }
        } catch (Exception e) {
            throw new Exception("An error occured getting the value from the ResultSet", e);
        }
        return retrievedValue;
    }

    public void log(int msgLevel, String logMsg) {
        if (LogMsg.isDebuggingEnabled(log_level, msgLevel)) {
            log_obj.FmtAndLogMsg("AuditDAO: " + logMsg);
        }
    }
}