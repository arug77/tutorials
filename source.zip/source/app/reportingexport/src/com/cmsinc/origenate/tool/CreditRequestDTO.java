package com.cmsinc.origenate.tool;

public class CreditRequestDTO {

    private String referenceNumber;

    private String agentID;

    private String applicationID;

    private String reqeustedLoan;

    private String originalLoanBalance;

    private String dateAppReceived;

    private String codeAction;

    private String codeOriginationSource;

    private String termNum;

    private String dealerLienName;

    public String getApplicationID() {
        return applicationID;
    }

    public void setApplicationID(String applicationID) {
        this.applicationID = applicationID;
    }

    public String getAgentID() {
        return agentID;
    }

    public void setAgentID(String agentID) {
        this.agentID = agentID;
    }

    public String getReferenceNumber() {
        return referenceNumber;
    }

    public void setReferenceNumber(String referenceNumber) {
        this.referenceNumber = referenceNumber;
    }

    public String getReqeustedLoan() {
        return reqeustedLoan;
    }

    public void setReqeustedLoan(String reqeustedLoan) {
        this.reqeustedLoan = reqeustedLoan;
    }

    public String getOriginalLoanBalance() {
        return originalLoanBalance;
    }

    public void setOriginalLoanBalance(String originalLoanBalance) {
        this.originalLoanBalance = originalLoanBalance;
    }

    public String getDateAppReceived() {
        return dateAppReceived;
    }

    public void setDateAppReceived(String dateAppReceived) {
        this.dateAppReceived = dateAppReceived;
    }

    public String getCodeAction() {
        return codeAction;
    }

    public void setCodeAction(String codeAction) {
        this.codeAction = codeAction;
    }

    public String getCodeOriginationSource() {
        return codeOriginationSource;
    }

    public void setCodeOriginationSource(String codeOriginationSource) {
        this.codeOriginationSource = codeOriginationSource;
    }

    public String getTermNum() {
        return termNum;
    }

    public void setTermNum(String termNum) {
        this.termNum = termNum;
    }

    public String getDealerLienName() {
        return dealerLienName;
    }

    public void setDealerLienName(String dealerLienName) {
        this.dealerLienName = dealerLienName;
    }

}