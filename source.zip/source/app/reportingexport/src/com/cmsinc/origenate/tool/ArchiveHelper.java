package com.cmsinc.origenate.tool;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.net.URL;
import java.net.URLConnection;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.jar.JarEntry;
import java.util.jar.JarOutputStream;
import java.util.zip.CRC32;
import java.util.zip.ZipEntry;

import com.cmsinc.origenate.util.LogMsg;

public class ArchiveHelper {

    private LogMsg log_obj;
    private int log_level;

    public ArchiveHelper(LogMsg log_obj, int log_level) {
        this.log_obj = log_obj;
        this.log_level = log_level;
    }

    public void archiveAndCompress(String dir, String ftpsvr, String ftpuser, String ftppwd) throws Exception {
        DateFormat dateFormat = new SimpleDateFormat("MMddyyyy_HHmmss");
        java.util.Date now = new java.util.Date();

        try {
            JarOutputStream jos = new JarOutputStream(new FileOutputStream(dir + "_" + dateFormat.format(now) + ".jar"));
            log(0, "Starting archive compression");
            compressArchive(dir, jos);
            log(0, "Finished archive compression");
            jos.close();
        } catch (Exception e) {
            throw new Exception("Error creating jar file. ", e);
        }

        /////////////////////// ftp file if server is supplied /////////////////////////////
        if (ftpsvr.length() > 0) {
            log(0, "Transfering archive via FTP");
            ftpArchive(ftpsvr, ftpuser, ftppwd, dir + "_" + dateFormat.format(now) + ".jar");
            log(0, "Finished transfering archive via FTP");
        }
    }

    /**
     * Archives and Compresses dir
     * 
     * @param filename
     * @param jos
     */
    public void compressArchive(String filename, JarOutputStream jos) throws Exception {
        FileInputStream fis = null;
        try {
            File file = new File(filename);
            if (file.isDirectory()) {
                String directory = filename + "/";
                String[] files = file.list();
                for (int i = 0; i < files.length; i++) {
                    compressArchive(directory + files[i], jos);
                }
            } else if (file.isFile()) {
                fis = new FileInputStream(file);
                int n = (int) file.length();
                byte[] b = new byte[n];
                fis.read(b, 0, n);
                fis.close();
                CRC32 crc = new CRC32();
                crc.update(b);
                JarEntry entry = new JarEntry(filename);
                entry.setMethod(ZipEntry.DEFLATED); // to not compress: entry.setMethod(ZipEntry.STORED);
                entry.setSize(n);
                entry.setCompressedSize(entry.getCompressedSize()); // to not compress: entry.setCompressedSize(n);
                entry.setCrc(crc.getValue());
                jos.putNextEntry(entry);
                jos.write(b, 0, n);
            }
        } catch (Exception e) {
            throw new Exception("Error jarring files", e);
        } finally {
            try {
                if (fis != null) {
                    fis.close();
                }
            } catch (Exception e) {
                log(0, "Unable to close FileInputStream" + e.toString());
            }
        }
    }

    /**
     * FTP a file in binary
     * 
     * @param svr
     * @param usr
     * @param pwd
     * @param ftpfilename
     */
    public void ftpArchive(String svr, String usr, String pwd, String ftpfilename) throws Exception {
        BufferedInputStream bis = null;
        BufferedOutputStream bos = null;

        try {
            // create ftp connection string
            URL url = new URL("ftp://" + usr + ":" + pwd + "@" + svr + "/" + ftpfilename + ";type=i");
            log(0, "URL for FTP Connection: " + url);
            URLConnection ftp_conn = url.openConnection();
            bos = new BufferedOutputStream(ftp_conn.getOutputStream());
            bis = new BufferedInputStream(new FileInputStream(ftpfilename));
            int i;

            while ((i = bis.read()) != -1) {
                bos.write(i);
            }
        } catch (Exception e) {
            throw new Exception("Error ftping file", e);
        } finally {
            try {
                if (bis != null) {
                    bis.close();
                }
                if (bos != null) {
                    bos.close();
                }
            } catch (Exception e) {
                log(0, "Unable to close BufferedInput/BufferedOutput Stream" + e.toString());
            }
        }
    }

    public void log(int msgLevel, String logMsg) {
        if (LogMsg.isDebuggingEnabled(log_level, msgLevel)) {
            log_obj.FmtAndLogMsg("ArchiveHelper: " + logMsg);
        }
    }
}