package com.cmsinc.origenate.tool;

import com.opencsv.bean.CsvBindByName;

public class CreditRequestorDTO {

    private String FirstName;

    private String MiddleName;

    private String Lastname;

    private String AddressLine1;

    private String AddressCity;

    private String AddressState;

    private String AddressZip;

    private String DOB;

    private String Homephone;

    private String income;

    private String taxIDNumber;

    private int requestorID;

    private int creditNumberInquiries;

    private int creditNumberMajorTotalDelinquencies;

    private int creditNumberMinorTotalDelinquencies;

    private int creditNumberSatisfactoryAccounts;

    private double creditScore;

    private String requestorEntityTxt;

    private double requestorRatioDebtServiceTotal;

    private double requestorRatioLoantoValue;

    public int getRequestorID() {
        return creditNumberMajorTotalDelinquencies;
    }

    public void setRequestorID(int requestorID) {
        this.requestorID = requestorID;
    }

    public String getFirstName() {
        return FirstName;
    }

    public void setFirstName(String firstName) {
        FirstName = firstName;
    }

    public String getMiddleName() {
        return MiddleName;
    }

    public void setMiddleName(String middleName) {
        MiddleName = middleName;
    }

    public String getLastname() {
        return Lastname;
    }

    public void setLastname(String lastname) {
        Lastname = lastname;
    }

    public String getAddressLine1() {
        return AddressLine1;
    }

    public void setAddressLine1(String addressLine1) {
        AddressLine1 = addressLine1;
    }

    public String getAddressCity() {
        return AddressCity;
    }

    public void setAddressCity(String addressCity) {
        AddressCity = addressCity;
    }

    public String getAddressState() {
        return AddressState;
    }

    public void setAddressState(String addressState) {
        AddressState = addressState;
    }

    public String getAddressZip() {
        return AddressZip;
    }

    public void setAddressZip(String addressZip) {
        AddressZip = addressZip;
    }

    public String getDOB() {
        return DOB;
    }

    public void setDOB(String dOB) {
        DOB = dOB;
    }

    public String getHomephone() {
        return Homephone;
    }

    public void setHomephone(String homephone) {
        Homephone = homephone;
    }

    public String getIncome() {
        return income;
    }

    public void setIncome(String income) {
        this.income = income;
    }

    public String getTaxIDNumber() {
        return taxIDNumber;
    }

    public void setTaxIDNumber(String taxIDNumber) {
        this.taxIDNumber = taxIDNumber;
    }

    public int getCreditNumberInquiries() {
        return creditNumberInquiries;
    }

    public void setCreditNumberInquiries(int creditNumberInquiries) {
        this.creditNumberInquiries = creditNumberInquiries;
    }

    public int getCreditNumberMajorTotalDelinquencies() {
        return creditNumberMajorTotalDelinquencies;
    }

    public void setCreditNumberMajorTotalDelinquencies(int creditNumberMajorTotalDelinquencies) {
        this.creditNumberMajorTotalDelinquencies = creditNumberMajorTotalDelinquencies;
    }

    public int getCreditNumberMinorTotalDelinquencies() {
        return creditNumberMinorTotalDelinquencies;
    }

    public void setCreditNumberMinorTotalDelinquencies(int creditNumberMinorTotalDelinquencies) {
        this.creditNumberMinorTotalDelinquencies = creditNumberMinorTotalDelinquencies;
    }

    public int getCreditNumberSatisfactoryAccounts() {
        return creditNumberSatisfactoryAccounts;
    }

    public void setCreditNumberSatisfactoryAccounts(int creditNumberSatisfactoryAccounts) {
        this.creditNumberSatisfactoryAccounts = creditNumberSatisfactoryAccounts;
    }

    public double getCreditScore() {
        return creditScore;
    }

    public void setCreditScore(double creditScore) {
        this.creditScore = creditScore;
    }

    public String getRequestorEntityTxt() {
        return requestorEntityTxt;
    }

    public void setRequestorEntityTxt(String requestorEntityTxt) {
        this.requestorEntityTxt = requestorEntityTxt;
    }

    public double getRequestorRatioDebtServiceTotal() {
        return requestorRatioDebtServiceTotal;
    }

    public void setRequestorRatioDebtServiceTotal(double requestorRatioDebtServiceTotal) {
        this.requestorRatioDebtServiceTotal = requestorRatioDebtServiceTotal;
    }

    public double getRequestorRatioLoantoValue() {
        return requestorRatioLoantoValue;
    }

    public void setRequestorRatioLoantoValue(double requestorRatioLoantoValue) {
        this.requestorRatioLoantoValue = requestorRatioLoantoValue;
    }
}