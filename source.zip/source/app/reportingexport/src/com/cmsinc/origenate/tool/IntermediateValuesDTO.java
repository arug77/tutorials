package com.cmsinc.origenate.tool;

public class IntermediateValuesDTO {

    public String codeOfficer;

    private String bankID;

    private String userid;

    private int origLoanTerm;

    private String codeLoanType;
    
    private String codeProduct;

    // Applicant Specific Variables
    private int applicantTotalBankruptcies;

    private int applicantTotalCollections;

    private int coApplicant1TotalBankruptcies;

    private int coApplicant1TotalCollections;

    private int coApplicant2TotalBankruptcies;

    private int coApplicant2TotalCollections;

    private int coSigner1TotalBankruptcies;

    private int coSigner1TotalCollections;

    private int coSigner2TotalBankruptcies;

    private int coSigner2TotalCollections;

    public String getCodeOfficer() {
        return codeOfficer;
    }

    public void setCodeOfficer(String codeOfficer) {
        this.codeOfficer = codeOfficer;
    }

    public String getBankID() {
        return bankID;
    }

    public void setBankID(String bankID) {
        this.bankID = bankID;
    }

    public String getUserid() {
        return userid;
    }

    public void setUserid(String userid) {
        this.userid = userid;
    }

    public int getOrigLoanTerm() {
        return origLoanTerm;
    }

    public void setOrigLoanTerm(int origLoanTerm) {
        this.origLoanTerm = origLoanTerm;
    }

    public String getCodeLoanType() {
        return codeLoanType;
    }

    public void setCodeLoanType(String codeLoanType) {
        this.codeLoanType = codeLoanType;
    }

    
    public String getCodeProduct() {
        return codeProduct;
    }

    
    public void setCodeProduct(String codeProduct) {
        this.codeProduct = codeProduct;
    }

    public int getApplicantTotalBankruptcies() {
        return applicantTotalBankruptcies;
    }

    public void setApplicantTotalBankruptcies(int applicantTotalBankruptcies) {
        this.applicantTotalBankruptcies = applicantTotalBankruptcies;
    }

    public int getApplicantTotalCollections() {
        return applicantTotalCollections;
    }

    public void setApplicantTotalCollections(int applicantTotalCollections) {
        this.applicantTotalCollections = applicantTotalCollections;
    }

    public int getCoApplicant1TotalBankruptcies() {
        return coApplicant1TotalBankruptcies;
    }

    public void setCoApplicant1TotalBankruptcies(int coApplicantTotalBankruptcies) {
        this.coApplicant1TotalBankruptcies = coApplicantTotalBankruptcies;
    }

    public int getCoApplicant1TotalCollections() {
        return coApplicant1TotalCollections;
    }

    public void setCoApplicant1TotalCollections(int coApplicantTotalCollections) {
        this.coApplicant1TotalCollections = coApplicantTotalCollections;
    }

    public int getCoApplicant2TotalBankruptcies() {
        return coApplicant2TotalBankruptcies;
    }

    public void setCoApplicant2TotalBankruptcies(int coApplicant2TotalBankruptcies) {
        this.coApplicant2TotalBankruptcies = coApplicant2TotalBankruptcies;
    }

    public int getCoApplicant2TotalCollections() {
        return coApplicant2TotalCollections;
    }

    public void setCoApplicant2TotalCollections(int coApplicant2TotalCollections) {
        this.coApplicant2TotalCollections = coApplicant2TotalCollections;
    }

    public int getCoSigner1TotalBankruptcies() {
        return coSigner1TotalBankruptcies;
    }

    public void setCoSigner1TotalBankruptcies(int coSigner1TotalBankruptcies) {
        this.coSigner1TotalBankruptcies = coSigner1TotalBankruptcies;
    }

    public int getCoSigner1TotalCollections() {
        return coSigner1TotalCollections;
    }

    public void setCoSigner1TotalCollections(int coSigner1TotalCollections) {
        this.coSigner1TotalCollections = coSigner1TotalCollections;
    }

    public int getCoSigner2TotalBankruptcies() {
        return coSigner2TotalBankruptcies;
    }

    public void setCoSigner2TotalBankruptcies(int coSigner2TotalBankruptcies) {
        this.coSigner2TotalBankruptcies = coSigner2TotalBankruptcies;
    }

    public int getCoSigner2TotalCollections() {
        return coSigner2TotalCollections;
    }

    public void setCoSigner2TotalCollections(int coSigner2TotalCollections) {
        this.coSigner2TotalCollections = coSigner2TotalCollections;
    }
}