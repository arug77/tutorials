package com.cmsinc.origenate.tool;


public abstract class SingleFeedBean {

}
