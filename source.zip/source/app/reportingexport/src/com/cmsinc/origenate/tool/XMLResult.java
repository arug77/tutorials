package com.cmsinc.origenate.tool;

/**
 * Class to hold results to return
 * 
 * @author DVJ2
 * 
 */

public class XMLResult {

    String xml;
    String styledOutput;

    public String getXml() {
        return xml;
    }

    public void setXml(String xml) {
        this.xml = xml;
    }

    public String getStyledOutput() {
        return styledOutput;
    }

    public void setStyledOutput(String styledOutput) {
        this.styledOutput = styledOutput;
    }
}