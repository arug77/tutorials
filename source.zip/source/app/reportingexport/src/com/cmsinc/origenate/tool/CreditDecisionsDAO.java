package com.cmsinc.origenate.tool;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.cmsinc.origenate.util.ConnectionUtils;
import com.cmsinc.origenate.util.LogMsg;


public class CreditDecisionsDAO {
    private Connection conn;
    private LogMsg log_obj;
    private int log_level;

    /**
     * Public constructor for creating an object of the class.
     * 
     * @param conn
     *            Database Connection Object
     * @param log_obj
     *            LogMsg object
     * @param log_level
     *            Log level from the ini
     */
    public CreditDecisionsDAO(Connection conn, LogMsg log_obj, int log_level) {
        this.conn = conn;
        this.log_obj = log_obj;
        this.log_level = log_level;
    }

    /**
     * Gets the singlefeed data for this application
     * 
     * @param requestID
     *            The requestID of the app to get
     * @return Returns a CreditDecisionsDTO object populated with the singlefeed details
     * @throws Exception
     *             Throws an exception if an error occurs communicating with the database
     */
    public CreditDecisionsDTO getSingleFeedData(String requestID) throws Exception {
        CreditDecisionsDTO decisionDTO = getDecisionDetail(requestID);

        decisionDTO.setDecReasons(getReasons(decisionDTO.getDecisionRefID()));
        decisionDTO.setDecPtiDti(getDtiLtv(decisionDTO.getRequestID(), decisionDTO.getDecisionRefID()));

        return decisionDTO;
    }

    /**
     * Gets the main decision detail for the app. This will be info from the latest decisionRefID
     * 
     * @param requestID
     *            The requestID of the application to get information for
     * @return The CreditDecisionsDTO object populated with the decision details
     * @throws Exception
     *             Throws an exception if an error occurs communicating with the database
     */
    private CreditDecisionsDTO getDecisionDetail(String requestID) throws Exception {
        CreditDecisionsDTO decisionDTO = new CreditDecisionsDTO();

        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;

        try {
            String sql =    "SELECT decision_ref_id, request_id, received_dt, APPROVED_TERM_NUM " +
            		        "FROM credit_req_decisions_evaluator " +
            		        "WHERE request_id = ? " +
            		        "AND decision_ref_id = (SELECT MAX(decision_ref_id) FROM credit_req_decisions_evaluator WHERE request_id = ? )";

            preparedStatement = conn.prepareStatement(sql);
            preparedStatement.setInt(1, Integer.parseInt(requestID));
            preparedStatement.setInt(2, Integer.parseInt(requestID));
            resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                decisionDTO.setDecisionRefID(resultSet.getInt("decision_ref_id"));
                decisionDTO.setRequestID(resultSet.getInt("request_id"));
                decisionDTO.setReceivedDt(resultSet.getDate("received_dt"));
                decisionDTO.setApprovedTermNum(resultSet.getInt("APPROVED_TERM_NUM"));
            }
        } catch (Exception e) {
            throw new Exception("Error getting decision details", e);
        } finally {
            ConnectionUtils.closePreparedStatement(preparedStatement);
            ConnectionUtils.closeResultSet(resultSet);
        }

        return decisionDTO;
    }

    /**
     * Gets the decision reasons for this app
     * 
     * @param decRefID
     *            The decision ref id
     * @return A list filled with DecReason objects
     * @throws Exception
     *             Throws an exception if an error occurs communicating with the database
     */
    private List<CreditDecisionsDTO.DecReason> getReasons(int decRefID) throws Exception {
        List<CreditDecisionsDTO.DecReason> listReasons = new ArrayList<CreditDecisionsDTO.DecReason>();

        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;

        try {
            String sql = "SELECT crdr.DECISION_REF_ID,mdr.REASON_TYPE_ID , mdr.REASON_TYPE_TXT FROM CREDIT_REQ_DECISION_REASONS crdr, mstr_decision_reason_types mdr " +
            		"Where crdr.decision_ref_id = ? " +
            		"and ((mdr.REASON_TYPE_ID = crdr.REASON_TYPE_ID and mdr.REASON_TYPE_TXT = 'Turndown' and crdr.ORDER_PRECEDENCE_NUM in (1,2,3,4,9991,9992,9993,9994)) " +
            		"or (mdr.REASON_TYPE_ID = crdr.REASON_TYPE_ID and mdr.REASON_TYPE_TXT = 'Override'))";

            preparedStatement = conn.prepareStatement(sql);
            preparedStatement.setInt(1, decRefID);
            resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                CreditDecisionsDTO.DecReason decReason = new CreditDecisionsDTO.DecReason();
                
                decReason.setDecReasonCode(resultSet.getString("REASON_ID"));
                decReason.setDecReasonDescription(resultSet.getString("DESCRIPTION_TXT"));
                decReason.setDecReasonOrderPrecedence(resultSet.getInt("ORDER_PRECEDENCE_NUM"));

                int reasonTypeID = resultSet.getInt("REASON_TYPE_ID");

                switch (reasonTypeID) {
                case 1:
                    decReason.setDecReasonTypeId(CreditDecisionsDTO.DecReasonTypeEnum.Turndown);
                    break;
                case 2:
                    decReason.setDecReasonTypeId(CreditDecisionsDTO.DecReasonTypeEnum.Override);
                    break;
                default:
                    break;
                }

                listReasons.add(decReason);
            }
        } catch (Exception e) {
            throw new Exception("Error getting reasons details", e);
        } finally {
            ConnectionUtils.closePreparedStatement(preparedStatement);
            ConnectionUtils.closeResultSet(resultSet);
        }

        return listReasons;
    }

    /**
     * Gets the DTI/LTV for this decision
     * 
     * @param requestID
     *            Request ID of the application
     * @param decRefID
     *            Decision Ref ID
     * @return A list filled with DecPtiDti objects
     * @throws Exception
     *             Throws an exception if an error occurs communicating with the database
     */
    private List<CreditDecisionsDTO.DecPTIDTI> getDtiLtv(int requestID, int decRefID) throws Exception {
        List<CreditDecisionsDTO.DecPTIDTI> listPTIDTI = new ArrayList<CreditDecisionsDTO.DecPTIDTI>();

        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;

        try {
            String sql =    "SELECT category_txt, PTIDTI_TXT, PTIDTI_NUM, bureau_id " +
                            "FROM CREDIT_REQ_DECISIONS_PTIDTI " +
                            "where decision_ref_id = ? " +
                            "and ((category_txt in ('APP', 'REC') and ptidti_txt = 'DTI') or (category_txt in ('APP', 'REC') and ptidti_txt = 'LTV')) " +
                            "and bureau_id = (" +
                                "select bureau_id from requestor_bureau_header rbh where request_id = ? " +
                                "and requestor_id = (select requestor_id from credit_req_decisions_evaluator where decision_ref_id = ?) " +
                                "and BUREAU_OF_RECORD_FLG = 1)";

            preparedStatement = conn.prepareStatement(sql);
            preparedStatement.setInt(1, decRefID);
            preparedStatement.setInt(2, requestID);
            preparedStatement.setInt(3, decRefID);
            resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                CreditDecisionsDTO.DecPTIDTI decPTIDTI = new CreditDecisionsDTO.DecPTIDTI();

                decPTIDTI.setCategoryTxt(resultSet.getString("CATEGORY_TXT"));
                decPTIDTI.setPtidti_txt(resultSet.getString("PTIDTI_TXT"));
                decPTIDTI.setPtidti_num(Integer.parseInt(resultSet.getString("PTIDTI_NUM")));

                listPTIDTI.add(decPTIDTI);
            }
        } catch (Exception e) {
            throw new Exception("Error getting DTI_PTI details", e);
        } finally {
            ConnectionUtils.closePreparedStatement(preparedStatement);
            ConnectionUtils.closeResultSet(resultSet);
        }

        return listPTIDTI;
    }

    /**
     * Logging method for this class. We are using this wrapper because when it passes through this method,
     * logs it will append the class name in front of the log message.
     * @param msgLevel Level of the message
     * @param logMsg The message to log, as a string
     */
    public void log(int msgLevel, String logMsg) {
        if (LogMsg.isDebuggingEnabled(log_level, msgLevel)) {
            log_obj.FmtAndLogMsg("CreditDecisionsDAO: " + logMsg);
        }
    }
}
