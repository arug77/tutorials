package com.cmsinc.origenate.tool;

import java.io.Writer;
import java.util.List;

import com.opencsv.bean.MappingStrategy;


public interface SingleFeedCSVWriter {
    
    public void writetoCSV(MappingStrategy strategy, List<SingleFeedCSVByNameBean> beans, Writer csvWriter);

    public void writetoCSVByColumnPosition(List<SingleFeedCSVByNameBean> beans, Writer writer, char separator);

}