/* Filename: PurgeAuditConfig.java
 * Version: 
 * Creation Date: September 11, 2005
 * Author: Gautam Anand
 * Copyright (c) 2002. All rights reserved
 * Description: Refer Clientele #134977
 * This program would archive the Audit Config Maintenance table 
 * records older than n days in a CSV file and then delete them from 
 * the audit table.
 */

package com.cmsinc.origenate.purgeauditconfig;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.ListIterator;
import java.util.Vector;

import com.cmsinc.origenate.util.OWASPSecurity;

import com.cmsinc.origenate.util.DBConnection;
import com.cmsinc.origenate.util.IniFile;
import com.cmsinc.origenate.util.LogMsg;
import com.cmsinc.origenate.util.SQLUpdate;

public class PurgeAuditConfig {

	private static LogMsg log = new LogMsg(); // log

	/*PurgeAudit Object Instantiation*/
	private static PurgeAuditConfig pg = new PurgeAuditConfig(); 
																
	/*Days to keep the Audit_Config_Maint. Table Records File */
	private static String cleanupDays; 

	private static Connection con; // db settings

	private static String input_filename; // input filename.

	private static String header_filename; // header filename

	private static String localfile_path; // input and header file localpath

	private static String input_filelocation; // input file location

	private static String header_file_data; // header file content

	/*whether to delete input/header files.*/
	private static boolean performFileDelete = false; 
														
	/*Determines days to keep records in Audit_Config_Maint table*/
	private static String cleanupRecordsDate; 
												
	/*determines date before which records should be deleted from Aud_Config_Main.*/
	private static String deleteRecordsDays;

	/*whether the Audit_Config_Main table records be deleted*/
	private static boolean performDBRecordDelete = false; 
															
	/*whether Audit_Config_Main. table be archived*/
	private static String performArchive ="yes";
	
	private static String s_iniFile; // ini filename

	private static int recordCount; // number of records in CSV input file

	private static Character ch;
	
	private static Vector v = new Vector(300,100);

	private static Vector cmdargs = new Vector(10,10);
	
	private PrintWriter dataFile = null;

	private boolean append = true;

	private static IniFile ini = new IniFile();

	/*
	 * Main method to call the getDBConnection method, getAuditConfigDataExtract
	 * method and retreive the command line parameters like ini file locn,input/header
	 * file, days to keep records in Audit table.
	 */
	public static void main(String[] args) {

		String s_log_file = "";
		if (args.length > 0) {
			for (int i = 0; i < args.length; ++i) {
				if ((args[i].charAt(0) != '-') && (args[i].length() > 1)) {
					showUsageAndExit();
				}
				ch = Character.valueOf(args[i].charAt(1));
				cmdargs.add(ch);
				switch (args[i].charAt(1)) {
				case 'i':
					s_iniFile = args[i].substring(2);
					try {
						ini.readINIFile(s_iniFile);
						s_log_file = ini.getINIVar(
								"logs.PurgeAuditConfig_log_file", "");
						if (s_log_file.length() > 0) {
							log.openLogFile(s_log_file);
						}
					} catch (Exception e) {
						log.FmtAndLogMsg("Caught exception reading ini file '"
								+ s_iniFile + "':" + e.toString());
					}
					log.FmtAndLogMsg("\r");
					log.FmtAndLogMsg("Starting Purge Audit Config Tool");
					log.FmtAndLogMsg("\r");
					log.FmtAndLogMsg("iniFile name: " + s_iniFile);
					break;
				case 'l':
					localfile_path = args[i].substring(2);
					log
							.FmtAndLogMsg("local location of the input & header files: "
									+ localfile_path);
					break;
				case 'd':
					deleteRecordsDays = args[i].substring(2);
					log.FmtAndLogMsg("The records older than "
							+ deleteRecordsDays + " days should be deleted");
					break;
				case 'n':
					cleanupDays = args[i].substring(2);
					log.FmtAndLogMsg("Number of days to keep the files"
							+ cleanupDays);
					break;
				case 'a':
					performArchive = args[i].substring(2);
					log.FmtAndLogMsg("Should the Event Table data be archived "
							+ performArchive);
					break;
				default:
					log.FmtAndLogMsg("Unknown parameter: " + args[i]);
					showUsageAndExit();
					break;
				}
			}
		}

		 /* Check if the required command line args are present*/
		try {
			log.FmtAndLogMsg("********Calling checkCmdLineArgs Method********");
			checkCmdLineArgs();
		} catch (Exception e) {
			log.FmtAndLogMsg("Error in checkCmdLineArgs method of : "
					+ e.toString());
		}
		log.FmtAndLogMsg("********checkCmdLineArgs Method Completed********");

		/* Creating a DB Connection */

		try {
			log.FmtAndLogMsg("********Calling getDBConnection Method********");
			getDBConnection(s_log_file);
		} catch (Exception e) {
			log.FmtAndLogMsg("Error in getDBConnection method of : "
					+ e.toString());
		}
		log.FmtAndLogMsg("********getDBConnection Method Completed********");

		/*determining date before which the Aud_Conf_Main records be deleted*/

		try {
			log.FmtAndLogMsg("********Calling getCleanupDate Method********");
			getRecordDeletionDate(deleteRecordsDays);
		} catch (Exception e) {
			log.FmtAndLogMsg("Error in getCleanupDate method of : "
					+ e.toString());
		}
		log.FmtAndLogMsg("********getCleanupDate Method Completed********");

		
		/*Checking if Audit table be archived;calling methods needed for archiving*/
		if(performArchive.equalsIgnoreCase("YES")){

			/* Calling method to retreive the input and header filenames */
	
			log.FmtAndLogMsg("********Calling getFileName Method********");
			input_filename = getFileName("Input");
			System.out.println("input_filename" + input_filename);
			header_filename = getFileName("Header");
			System.out.println("header_filename" + header_filename);
			log.FmtAndLogMsg("********getFileName Method Completed********");
	
	
			/* Calling method to archive Aud. Config. Main. Table Records */
			try {
				log
						.FmtAndLogMsg("********Calling getAuditConfigDataExtract Method********");
				getAuditConfigDataExtract();
			} catch (Exception e) {
				log.FmtAndLogMsg("Error in getAuditConfigDataExtract method of : "
						+ e.toString());
			}
			log
					.FmtAndLogMsg("********getAuditConfigDataExtract Method Completed********");
	
		}
		else {
			delete_from_audconfmain_table();
		}

		log.FmtAndLogMsg("********Purge Audit Config Tool Completed********");
	}

	/*
	 * Method to inform that expected values are missing on the command line.
	 */

	public static void showUsageAndExit() {
		System.out
				.println("Usage: java com.cmsinc.origenate.purgeauditconfig.PurgeAuditConfig");
		System.out
				.println("-i<ini file> -l<localfile location> -d<deleteRecordsDays> -n<Cleanup Days> -a<Perform Archive>");
		System.out
				.println("------------------------------------------------------------------------------");
		System.out.println("Parameter	Data Type	Required/Optional			Description");
		System.out.println("  -i 		 String			Required		ini file name including the location");
		System.out.println("  -l		 String 		Required		location of input and header file on local machine");
		System.out.println("  -d		 Integer		Required		Number of days before which all records in Event table should be deleted");
		System.out.println("  -n 		 Integer		Required		Number of days to keep the files in local directory");
		System.out.println("  -a 		 String			Optional		Should the Event Table data be archived YES/NO; YES-Default");
		System.exit(0);
	}

	/*
	 * Method to report an error in a method. Mainly used in the
	 * getAuditConfigDataExtract method to report missing field values in the
	 * extract for required fields.
	 */

	public static void recordError(String methodName, Exception err)
			throws Exception {
		try {
			log.FmtAndLogMsg("Error occured in " + methodName + " method of : "
					+ err.toString());
			throw new Exception("Error occured in " + methodName
					+ " method of : " + err.toString());
		} catch (Exception e) {
			log
					.FmtAndLogMsg("Error in reportError method of : "
							+ e.toString());
		}

	}

	/*checks if the command line args are present*/
	
	public static void checkCmdLineArgs() {
		if(cmdargs.contains(Character.valueOf('i')) && cmdargs.contains(Character.valueOf('l')) && 
		   cmdargs.contains(Character.valueOf('d')) && cmdargs.contains(Character.valueOf('n'))) {
			log.FmtAndLogMsg("Required Command Line Parameters Present");
		}
		else {
			log.FmtAndLogMsg("Required Command Line Parameters Missing");
			log.FmtAndLogMsg("Calling showUsageAndExit() method to exit");
			showUsageAndExit();
		}
	}
	
	
	/*
	 * Create PurgeAuditConfig object and get DB connection
	 */

	public static void getDBConnection(String s_log_file) throws Exception {

		try {
			// Get ini file values for DB connection

			String s_dbhost = ini.getINIVar("database.host").trim();
			log.FmtAndLogMsg("dbHost : " + s_dbhost);

			String s_dbport = ini.getINIVar("database.port").trim();
			log.FmtAndLogMsg("dbPort : " + s_dbport);

			String s_dbsid = ini.getINIVar("database.sid").trim();
			log.FmtAndLogMsg("dbSID : " + s_dbsid);

			String s_dbuser = ini.getINIVar("database.user").trim();
			log.FmtAndLogMsg("dbUser : " + s_dbuser);

			String s_dbpassword = ini.getINIVar("database.password").trim();

			String sTNSEntry = ini.getINIVar("database.TNSEntry", "");
			log.FmtAndLogMsg("TNS Entry : " + sTNSEntry);
			
			DBConnection DBConnect = new DBConnection();
			
			if (sTNSEntry.length() == 0) {
//				 Get DB connection
				con = DBConnect.getConnection(s_dbhost, s_dbsid, s_dbuser,
						s_dbpassword, s_log_file, s_dbport,"");
			} else {
				// use tns entry if available
				con = DBConnect.getConnectionTNS(sTNSEntry, s_dbuser,  s_dbpassword, s_log_file);
			}
		} catch (Exception e) {
			recordError("getDBConnection", e);
		}
	} // end getDBConnection method

	/*
	 * Method to archive the Audit Config Main. table records and create a CSV
	 * file.
	 */

	public static void getAuditConfigDataExtract() throws Exception {

		PreparedStatement ps = null;
		ResultSet rs = null;
		String sql = "";

		/*variables to hold the values of the Audit_Config_Main table*/

		String s_audit_id = "";
		String s_audit_last_updated_dt = "";
		String s_audit_updated_userid = "";
		String s_table_name = "";
		String s_column_name = "";
		String s_old_value = "";
		String s_new_value = "";
		String s_system_date = "";
		String s_db_username = "";
		String s_os_user = "";
		String s_process = "";
		String s_machine = "";
		String s_terminal = "";
		String s_program = "";
		boolean bArchiving = performArchive.equalsIgnoreCase("YES");
		recordCount = 0;
		
		if (bArchiving)
		{
			log.FmtAndLogMsg("********Archiving has been enabled ********");
			log.FmtAndLogMsg("********Input File Creation Method Called********");
			/* opening a file for writing the field values */
			pg.openCSVFile(input_filename);
			
		}
		else
		{
			log.FmtAndLogMsg("********Archiving has been disabled ********");
		}
		
		try {

			/* Select records from Audit Config Main db table */

			sql = "SELECT audit_id,audit_last_updated_dt,"
					+ "audit_updated_user_id,table_name_txt,column_name_txt,"
					+ "old_value_txt,new_value_txt,system_dt,db_username,"
					+ "osuser,process,machine,terminal,program "
					+ "FROM AUDIT_CONFIG_MAINTENANCE "
					+ "WHERE audit_last_updated_dt < to_date( ? ,'MM/DD/YYYY') "
					+ "ORDER BY audit_id";

			ps = con.prepareStatement(sql); // Prepare statement to execute

			ps.setString(1, cleanupRecordsDate); // Set param values

			rs = ps.executeQuery(); // Execute statement

			while (rs.next()) {

				recordCount++;
			
				// Audit ID
				s_audit_id = rs.getString("audit_id");
				if (s_audit_id == null) {
					s_audit_id = surroundWithQuotes("");
					pg.writeDataExtract(s_audit_id);
					log
							.FmtAndLogMsg("Audit ID value not present in the database");

				} else {
					s_audit_id = surroundWithQuotes(s_audit_id);
					System.out.println("s_audit_id: " + s_audit_id);
					pg.writeDataExtract(s_audit_id);
				}

				// Audit Last Updated Date
				s_audit_last_updated_dt = rs.getString("audit_last_updated_dt");
				if (s_audit_last_updated_dt == null) {
					s_audit_last_updated_dt = surroundWithQuotes("");
					pg.writeDataExtract(s_audit_last_updated_dt);
					log
							.FmtAndLogMsg("Audit Last Updated Date value not present in the database");

				} else {
					s_audit_last_updated_dt = surroundWithQuotes(s_audit_last_updated_dt);
					System.out.println("s_audit_last_updated_dt: "
							+ s_audit_last_updated_dt);
					pg.writeDataExtract(s_audit_last_updated_dt);
				}

				// Audit Update User ID
				s_audit_updated_userid = rs.getString("audit_updated_user_id");
				if (s_audit_updated_userid == null) {
					s_audit_updated_userid = surroundWithQuotes("");
					pg.writeDataExtract(s_audit_updated_userid);
					log
							.FmtAndLogMsg("Audit Update User ID value not present in the database");

				} else {
					s_audit_updated_userid = surroundWithQuotes(s_audit_updated_userid);
					System.out.println("s_audit_updated_userid: "
							+ s_audit_updated_userid);
					pg.writeDataExtract(s_audit_updated_userid);
				}

				// Table Name
				s_table_name = rs.getString("table_name_txt");
				if (s_table_name == null) {
					s_table_name = surroundWithQuotes("");
					System.out.println("s_table_name: " + s_table_name);
					pg.writeDataExtract(s_table_name);
					log
							.FmtAndLogMsg("Table Name value not present in the database");

				} else {
					s_table_name = surroundWithQuotes(s_table_name);
					System.out.println("s_table_name: " + s_table_name);
					pg.writeDataExtract(s_table_name);
				}

				// Column Name
				s_column_name = rs.getString("column_name_txt");
				if (s_column_name == null) {
					s_column_name = surroundWithQuotes("");
					System.out.println("s_column_name: " + s_column_name);
					pg.writeDataExtract(s_column_name);
					log
							.FmtAndLogMsg("Column Name value not present in the database");
				} else {
					s_column_name = surroundWithQuotes(s_column_name);
					System.out.println("s_column_name: " + s_column_name);
					pg.writeDataExtract(s_column_name);
				}

				// Old Value
				s_old_value = rs.getString("old_value_txt");
				if (s_old_value == null) {
					s_old_value = surroundWithQuotes("");
					System.out.println("s_old_value: " + s_old_value);
					pg.writeDataExtract(s_old_value);
					log.FmtAndLogMsg("Old value not present in the database");

				} else {
					s_old_value = surroundWithQuotes(s_old_value);
					System.out.println("s_old_value: " + s_old_value);
					pg.writeDataExtract(s_old_value);
				}

				// New Value
				s_new_value = rs.getString("new_value_txt");
				if (s_new_value == null) {
					s_new_value = surroundWithQuotes("");
					System.out.println("s_new_value: " + s_new_value);
					pg.writeDataExtract(s_new_value);
					log.FmtAndLogMsg("New value not present in the database");

				} else {
					s_new_value = surroundWithQuotes(s_new_value);
					System.out.println("s_new_value: " + s_new_value);
					pg.writeDataExtract(s_new_value);
				}

				// System Date
				s_system_date = rs.getString("system_dt");
				if (s_system_date == null) {
					s_system_date = surroundWithQuotes("");
					System.out.println("s_system_date: " + s_system_date);
					pg.writeDataExtract(s_system_date);
					log.FmtAndLogMsg("System Date not present in the database");

				} else {
					s_system_date = surroundWithQuotes(s_system_date);
					System.out.println("s_system_date: " + s_system_date);
					pg.writeDataExtract(s_system_date);
				}

				// DB Username
				s_db_username = rs.getString("db_username");
				if (s_db_username == null) {
					s_db_username = surroundWithQuotes("");
					System.out.println("s_db_username: " + s_db_username);
					pg.writeDataExtract(s_db_username);
					log.FmtAndLogMsg("DB Username not present in the database");

				} else {
					s_db_username = surroundWithQuotes(s_db_username);
					System.out.println("s_db_username: " + s_db_username);
					pg.writeDataExtract(s_db_username);
				}

				// Operating System User
				s_os_user = rs.getString("osuser");
				if (s_os_user == null) {
					s_os_user = surroundWithQuotes("");
					System.out.println("s_os_user: " + s_os_user);
					pg.writeDataExtract(s_os_user);
					log
							.FmtAndLogMsg("Operating System User value not present in the database");

				} else {
					s_os_user = surroundWithQuotes(s_os_user);
					System.out.println("s_os_user: " + s_os_user);
					pg.writeDataExtract(s_os_user);
				}

				// Process
				s_process = rs.getString("process");
				if (s_process == null) {
					s_process = surroundWithQuotes("");
					System.out.println("s_process: " + s_process);
					pg.writeDataExtract(s_process);
					log
							.FmtAndLogMsg("Process value not present in the database");

				} else {
					s_process = surroundWithQuotes(s_process);
					System.out.println("s_process: " + s_process);
					pg.writeDataExtract(s_process);
				}

				// Machine
				s_machine = rs.getString("machine");
				if (s_machine == null) {
					s_machine = surroundWithQuotes("");
					System.out.println("s_machine: " + s_machine);
					pg.writeDataExtract(s_machine);
					log
							.FmtAndLogMsg("Machine value not present in the database");

				} else {
					s_machine = surroundWithQuotes(s_machine);
					System.out.println("s_machine: " + s_machine);
					pg.writeDataExtract(s_machine);
				}

				// Terminal
				s_terminal = rs.getString("terminal");
				if (s_terminal == null) {
					s_terminal = surroundWithQuotes("");
					System.out.println("s_terminal: " + s_terminal);
					pg.writeDataExtract(s_terminal);
					log
							.FmtAndLogMsg("Terminal value not present in the database");

				} else {
					s_terminal = surroundWithQuotes(s_terminal);
					System.out.println("s_terminal: " + s_terminal);
					pg.writeDataExtract(s_terminal);
				}

				// Program
				s_program = rs.getString("program");
				if (s_program == null) {
					s_program = surroundWithQuotesWithoutComma("");
					System.out.println("s_program: " + s_program);
					pg.writeDataExtract(s_program);
					log
							.FmtAndLogMsg("Program value not present in the database");

				} else {
					s_program = surroundWithQuotesWithoutComma(s_program);
					System.out.println("s_program: " + s_program);
					pg.writeDataExtract(s_program);
				}
				pg.writeDataExtract("\r");
			} // end loop database records.
			log.FmtAndLogMsg("Total Record Count : " + recordCount);
			
			/* Checking if archiving the data is required */
			if(bArchiving){
				pg.closeCSVFile();
				
				log
				.FmtAndLogMsg("********Calling fileExistsCheck Method********");
				fileExistsCheck();
				log
				.FmtAndLogMsg("********fileExistsCheck Method Completed********");

				/* Calling method to generated header file data */

				log
						.FmtAndLogMsg("********Calling getHeaderFileData Method********");
				header_file_data = getHeaderFileData();
				log
						.FmtAndLogMsg("********getHeaderFileData Method Completed********");
				log
						.FmtAndLogMsg("********Calling openCSVFile Method for Header File********");

				/* Opening a new file for writing header data */

				pg.openCSVFile(header_filename);
				log
						.FmtAndLogMsg("********Calling writeDataExtract Method for Header File********");

				/* Writing headerfile data */
				pg.writeDataExtract(header_file_data);
				pg.writeDataExtract("\r");
				log
						.FmtAndLogMsg("********Calling closeCSVFile Method for Header File********");

				/* Closing Header File */
				pg.closeCSVFile();
				log
						.FmtAndLogMsg("********Header File Creation Completed Successfully********");
			}
			else{
				log
				.FmtAndLogMsg("********Archiving Not Required********");
			}	
			
			/* Calling method to Delete Audit Conf Main Table Records */

			if (performDBRecordDelete == true) {
				log
						.FmtAndLogMsg("********Calling Delete From Audit Config Main Table Method********");
				delete_from_audconfmain_table();
				log
						.FmtAndLogMsg("********Delete From Audit Config Main Table Method Completed********");
			} else {
				log
						.FmtAndLogMsg("Audit Config Main Table data cannot be deleted");
			}

			/* Calling method to cleanup the input and header files */

			if (performFileDelete == true) {
				log
						.FmtAndLogMsg("********Calling Cleanup Files Method********");
				cleanupFiles();
				log
						.FmtAndLogMsg("********Cleanup Files Method Completed********");
			}

		} catch (Exception e) {
			recordError("getAuditConfigDataExtract", e);
		} finally {
			try {
				if (ps != null)
					ps.close();
				if (rs != null)
					rs.close();
			} catch (Exception e) {
				recordError("getAuditConfigDataExtract", e);
			} // end catch
		} // end finally
	} // end getAuditConfigDataExtract method

	/* Method to generate header file data */
	public static String getHeaderFileData() throws Exception {
		String headerFileData = "";
		String number_of_records = surroundWithQuotes(Integer
				.toString(recordCount));
		String input_file = surroundWithQuotes(input_filename);
		String recordDeletionDate = cleanupRecordsDate;
		headerFileData = (((input_file.concat(number_of_records))
				.concat("\"Audit_Config_Maintenance Table Records Before "))
				.concat(recordDeletionDate)).concat(" would be deleted\"");
		return headerFileData;
	}

	/*
	 * Method to determine the date before which the Aud Config Main table
	 * records should be deleted
	 */
	public static void getRecordDeletionDate(String deleteRecordsDays) {
		int numOfDays = Integer.parseInt(deleteRecordsDays);
		String year = ""; // year
		String month = ""; // month
		String day = ""; // day

		if (numOfDays >= 0) {
			GregorianCalendar gc = new GregorianCalendar();
			gc.add(Calendar.DATE, 0 - numOfDays);

			day = (Integer.toString(gc.get(Calendar.DATE))).trim();
			if (day.length() < 2) {
				day = "0".concat(day);
			}
			month = (Integer.toString((gc.get(Calendar.MONTH)) + 1)).trim();
			if (month.length() < 2) {
				month = "0".concat(month);
			}
			year = (Integer.toString(gc.get(Calendar.YEAR))).trim();
			cleanupRecordsDate = month + "/" + day + "/" + year;
			System.out.println(cleanupRecordsDate);
			log.FmtAndLogMsg("Cleanup date : " + cleanupRecordsDate);
		}
	}

	/* Method to Delete Audit Config Maintenance Table Records */

	public static void delete_from_audconfmain_table() {
		try {
			String sql = "DELETE FROM AUDIT_CONFIG_MAINTENANCE WHERE AUDIT_LAST_UPDATED_DT < TO_DATE('"
					+ cleanupRecordsDate + "','MM/DD,YYYY')";
			SQLUpdate.RunUpdateStatement(con, sql);
			log
					.FmtAndLogMsg("Deleted rows in AUDIT_CONFIG_MAINTENANCE with AUDIT_LAST_UPDATED_DT before "
							+ cleanupRecordsDate);
		} catch (Exception e) {
			log
					.FmtAndLogMsg("Error deleting rows in AUDIT_CONFIG_MAINTENANCE with AUDIT_LAST_UPDATED_DT before "
							+ cleanupRecordsDate + e);
		}
	}

	/*
	 * Method to get the filenames for the header and input data extract file
	 */

	public static String getFileName(String filetype) {

		Calendar cal = new GregorianCalendar(); // create a Calendar object
		String year = ""; // year
		String month = ""; // month
		String day = ""; // day
		String date = "";
		String s_filetype = filetype; // file type : input or header file
		String filename = "";
		try {

			// get date to append to the filename.
			year = (Integer.toString(cal.get(Calendar.YEAR))).trim(); // 2002
			month = (Integer.toString((cal.get(Calendar.MONTH)) + 1)).trim(); // 0=Jan,
																				// 1=Feb,
																				// ...
			if (month.length() < 2) {
				month = "0".concat(month);
			}
			day = (Integer.toString(cal.get(Calendar.DAY_OF_MONTH))).trim(); // 1...
			if (day.length() < 2) {
				day = "0".concat(day);
			}
			System.out.println("Current Month: " + month);
			System.out.println("Current Year: " + year);
			System.out.println("Current Day: " + day);
			date = month + day + year;

			/*
			 * CSV Input file Format: PurgeAuditConfigInputFile_Date_input.csv
			 * CSV Header file Format: PurgeAuditConfig_Date_header.csv
			 */

			if (s_filetype.equalsIgnoreCase("Input"))
				filename = (("PurgeAuditConfig".concat("_")).concat(date))
						.concat("_input.csv");
			else if (s_filetype.equals("Header"))
				filename = (("PurgeAuditConfig".concat("_")).concat(date))
						.concat("_header.csv");

		} catch (Exception e) {
			try {
				recordError("setFileName", e);
			} catch (Exception ex) {
				log.FmtAndLogMsg("Error in getFileName method of : "
						+ ex.toString());
			}
		} // end catch
		return filename;
	} // end getFileName method

	/*
	 * Performing check on the Input File Created before 
	 * deleting db event table records
	 */

	public static void fileExistsCheck(){

		input_filelocation = localfile_path.concat(input_filename);
		System.out.println("input filelocation" + input_filelocation);
		log.FmtAndLogMsg("input_filelocation : " + input_filelocation);
		
		/**		
         * OWASP TOP 10 2010 - A4 Path Manipulation
	     * Changes to the below code to fix vulnerabilities
	     * TTP 324955
	     **/		
		//File file = new File(input_filelocation);
		File file=null;
		try
		{
		 file = new File(OWASPSecurity.validationCheck(input_filelocation, OWASPSecurity.DIRANDFILE));
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		long length = file.length();
		System.out.println("inputfile length: " + length);
		log.FmtAndLogMsg("inputfile length : " + length);
		boolean fileExists = file.exists();
		System.out.println("fileExists" + fileExists);
		if (fileExists && length > recordCount) {
			performDBRecordDelete = true;
			log
					.FmtAndLogMsg("Input File Created Successfully; Database Audit Config Maintenance Table Records can be deleted");
		} else {
			performDBRecordDelete = false;
			log
					.FmtAndLogMsg("Error Creating input file; Database Audit Config Maintenance Table records would not be deleted");
		}
	}

	
	public static void eventDataArchive() throws Exception{
		log.FmtAndLogMsg("********Input File Creation Method Called********");
		
		/* opening a file for writing the field values */
		pg.openCSVFile(input_filename);
		
		ListIterator iter = v.listIterator();
		while (iter.hasNext()) {
			pg.writeDataExtract((String)iter.next());
		}
		pg.closeCSVFile();
		log.FmtAndLogMsg("********Input File Creation Completed Successfully********");
	}

	
	/*
	 * Method to retreive the filename from path.
	 */

	public static String getFileNameFromPath(String file) {
		return file.substring(file.lastIndexOf("\\") + 1, file.length());
	}

	/*
	 * Method to create the CVS fields. surround the fields with double qoutes.
	 */

	public static String surroundWithQuotes(String fieldName) {
		String s_field = fieldName;
		s_field = (("\"".concat(s_field)).concat("\"")).concat(",");
		return s_field;
	}

	/* Surround the fields with double qoutes but wihout an ending comma */
	public static String surroundWithQuotesWithoutComma(String fieldName) {
		String s_field = fieldName;
		s_field = (("\"".concat(s_field)).concat("\""));
		return s_field;
	}

	/*
	 * method to cleanup files older than n days(from Chuck Caplan)
	 */

	public static void cleanupFiles() {

		int numOfDays = Integer.parseInt(cleanupDays);
		if (numOfDays >= 0) {
			// get list of all files in local dir
			
			/**		
	         * OWASP TOP 10 2010 - A4 Path Manipulation
		     * Changes to the below code to fix vulnerabilities
		     * TTP 324955
		     **/		
			//File localDirFiles = new File(localfile_path);
			File localDirFiles=null;
			try
			{				
			localDirFiles = new File(OWASPSecurity.validationCheck(localfile_path, OWASPSecurity.DIRANDFILE));
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			String[] localFiles = localDirFiles.list();
			for (int i = 0; i < localFiles.length; i++) {
				File backupFile = new File(localDirFiles.getAbsolutePath()
						+ "\\" + localFiles[i]);
				Date lastModified = new Date(backupFile.lastModified());
				GregorianCalendar gc = new GregorianCalendar();
				gc.add(Calendar.DATE, 0 - numOfDays);
				java.util.Date cleanupDate = gc.getTime();
				if (cleanupDate.after(lastModified)) {
					log.FmtAndLogMsg("Deleted file " + localFiles[i] + ": "
							+ backupFile.delete());
				}
				backupFile = null;
			}
			localDirFiles = null;
		} else {
			log.FmtAndLogMsg("Not deleting any files since cleanupDays = "
					+ cleanupDays);
		}
		log.FmtAndLogMsg("Ended cleanup of files");

	}

	/*
	 * Opens a file for writing. If file exists the data would be appended by
	 * default.
	 */
	public void openCSVFile(String fileName) throws Exception {
		try {
			fileName = localfile_path.concat(fileName);
			
			/**		
	         * OWASP TOP 10 2010 - A4 Path Manipulation
		     * Changes to the below code to fix vulnerabilities
		     * TTP 324955
		     **/		
			//dataFile = new PrintWriter(new BufferedWriter(new FileWriter(fileName, append)));
			dataFile = new PrintWriter(new BufferedWriter(new FileWriter(OWASPSecurity.validationCheck(fileName, OWASPSecurity.DIRANDFILE), append)));
			
		} catch (Exception e) {
			recordError("openCSVFile", e);
		}
	}

	public void writeDataExtract(String str) {
		if (dataFile != null) {
			dataFile.print(str);
		}
	}

	public void closeCSVFile() {
		if (dataFile != null) {
			dataFile.close();
			dataFile = null;
		}
	}

} // main class
