/**
 * Author: Todd Mackall and Jon Miller
 * Date: 7/17/2003
 * Description: Program extracts dealer information and posts it to DT
 **/

package com.cmsinc.origenate.tool;

import java.io.*;
import java.util.*;

import com.cmsinc.origenate.util.IniFile;
import com.cmsinc.origenate.util.PostRequest;

import com.cmsinc.origenate.util.OWASPSecurity;

public class DealerExtract{

   private static final String FORM_BOUNDARY = "---------------------------7d2e2c76e104be";


   /**
    * Method initiates dealer extract process
    **/
   public static void main (String args[]){

      System.out.println("Dealer Extraction Tool v1.0\n");

      if(args.length < 3){
         System.out.println("usage: DealerExtract <ini file path> <dealer extract file> <destination url>");
         System.exit(0);
      }

      IniFile ini = new IniFile();
      String extractFileStr = "";
      String response = "";
      BufferedInputStream fis = null;

      // Read ini file
      try{
         ini.readINIFile(args[0]);
      }
      catch(Exception e){
         System.out.println("Exception: " + e);
         System.exit(0);
      }

      // Read dealer extract file

      try{
    	  /** OWASP Top 10 2010 - A4 path manipluation
    	   * Change to the below code to fix vulnerabilities
         * TTP 324955
    	   */
         //File f = new File(args[1]);
         //File f = new File(Encode.forJava(args[1]));
        File f = new File(OWASPSecurity.validationCheck(args[1], OWASPSecurity.DIRANDFILE));
         byte[] buffer = new byte[(int) f.length()];
         fis = new BufferedInputStream(new FileInputStream(f));
         int i = 0;
         int b = fis.read();

         while(b != -1){
            buffer[i++] = (byte) b;
            b = fis.read();
         }

         extractFileStr = new String(buffer);

      }
      catch(Exception e) {
         System.out.println("Exception: " + e);
         System.exit(0);
      }
      finally{

         if(fis != null){
            try{
               fis.close();
            }
            catch(IOException ioe){
               // do nothing
            }
         }

      }


      // Post dealer extract file
      try{
         PostRequest postRequest = new PostRequest();
         postRequest.setHeaderProperty ("Content-Type", "multipart/form-data; boundary=" + FORM_BOUNDARY);
         postRequest.setHeaderProperty ("Cookie", "SMCHALLENGE=YES");
	     response = postRequest.post(args[2],extractFileStr,0);
      }
      catch(Exception e){
         System.out.println("Exception: " + e);
         e.printStackTrace(System.out);
         System.exit(0);
      }

      System.out.println("Response: " + response);

      System.exit(0);

   }

}
