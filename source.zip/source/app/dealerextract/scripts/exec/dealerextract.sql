DEFINE ORIGPATH = &1; 
DEFINE ORIGFILE = &2; 
DEFINE ORIGEVALID = &3; 
DEFINE ORIGSRC = &4; 

  set linesize 132;
  set trimspool on;
  set head off;
  set feed off;
  set linesize 800;
  SET SERVEROUTPUT ON SIZE 1000000;
  
  EXECUTE DEALER_CSV('&ORIGPATH', '&ORIGFILE', &ORIGEVALID, &ORIGSRC) ;
  exit; 
