#!/bin/ksh
#
#     File          dealerextract.sh
#     Path          /
#     Created       Tue July  2003
#     Author        Todd Mackall
#     Purpose       Performs Origenate daily Dealer Extract process to create a text file for clients.
#
#     Parameters:
#	$1 = Database username/password
#	$2 = Debug Switch - Reduces PROCESS_CONTROL_DETAIL logging if not = "DEBUG" #

if [ "$USER_PASS_DB1" = "" ]
then
   echo
   echo "Missing Client $ORIGCLIENT username and password."
   echo
   echo "Command: Dealer Extract.sh $1 $2 $3 $4 $5 $6 $7 "
   echo "has been aborted."
   echo
   return 1
fi

umask 000

echo "GENERATING $ORIGCLIENT Extract File  ..."

echo "Running File Creation Procedure ..."
$ORACLE_HOME/bin/sqlplus -s $USER_PASS_DB1 @$ORAPPS/dealerextract/dealerextract.sql $ORACLE_DTEXPORT_DIR $ORIGOWNER.txt $ORIGEVALID $ORIGSRC

cd $ORDATA/dealerextract

echo "Beginning FTP..."
/usr/bin/ftp -n $ORACLE_DTEXPORT_HOST  <<E_O_F >>$LOG 2>&1
user $ORACLE_DTFTP_USER $ORACLE_DTFTP_PASSWD
prompt
ascii
cd $ORACLE_DTEXPORT_DIR
get $ORIGOWNER.txt Dealer.txt
bye
E_O_F

cd $ORAPPS/dealerextract

echo "Ready to Post the File ...."
java com.cmsinc.origenate.tool.DealerExtract $ORIGCONFIG/origenate.ini $ORDATA/dealerextract/Dealer.txt $DTURL
