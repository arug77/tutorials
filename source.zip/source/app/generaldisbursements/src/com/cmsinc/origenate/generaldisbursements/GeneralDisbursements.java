package com.cmsinc.origenate.generaldisbursements;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.FilenameFilter;
import java.sql.Connection;
import java.util.Date;
import java.util.StringTokenizer;

import com.cmsinc.origenate.event.CommentEvents;
import com.cmsinc.origenate.util.DBConnection;
import com.cmsinc.origenate.util.IniFile;
import com.cmsinc.origenate.util.LogMsg;
import com.cmsinc.origenate.util.Query;
import com.cmsinc.origenate.util.SendNotification;
import com.cmsinc.origenate.util.OWASPSecurity;

public class GeneralDisbursements {

	private LogMsg log = new LogMsg(); // log

	private String datDir;

	// this variable says whether or not to print a header in the unknown app
	// log
	private boolean headerWritten = false;

	private String evaluator_id;

	private String dbHost; // db settings

	private String dbUser; // db settings

	private String dbPass; // db settings

	private String dbPort; // db settings

	private String dbSID; // db settings
	
	private String sTNSEntry;

	private Connection con; // db settings

	private String unknownAppLog; // For unknown apps

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		if (args.length != 2) {
			showUsageAndExit();
		}
		new GeneralDisbursements().runDisbursements(args);
	}

	private void runDisbursements(String[] args) {
		String iniFile = args[0];
		init(iniFile, args[1]);
		String[] datFileList = getDatFileList();
		for (int i = 0; i < datFileList.length; i++) {
			processFile(datDir + datFileList[i]);
			renameToDone(datDir + datFileList[i]);
		}
	}

	private void renameToDone(String fileName) {
		
		/**		
         * OWASP TOP 10 2010 - A4 Path Manipulation
	     * Changes to the below code to fix vulnerabilities
	     * TTP 324955
	     **/
		//new File(fileName).renameTo(new File(fileName + ".done"));
		try
		{


		new File(OWASPSecurity.validationCheck(fileName, OWASPSecurity.DIRANDFILE)).renameTo(new File(OWASPSecurity.validationCheck(fileName, OWASPSecurity.DIRANDFILE) + ".done"));
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}

	private void processFile(String fileName) {
		int lineCount = 0;
		FileReader fileReader = null;
		BufferedReader in = null;
		try {
			
			/**		
	         * OWASP TOP 10 2010 - A4 Path Manipulation
		     * Changes to the below code to fix vulnerabilities
		     * TTP 324955
		     **/			
			//fileReader = new FileReader(fileName);
			fileReader = new FileReader(OWASPSecurity.validationCheck(fileName, OWASPSecurity.DIRANDFILE));
			in = new BufferedReader(fileReader);
			String line;
			do {
				line = in.readLine();
				if (line != null) {
					line = line.trim();
					if (!line.equals("")) {
						lineCount++;
						String appNo;
						String comment;
						String commentDate;
						StringTokenizer st = new StringTokenizer(line, "\"");
						appNo = st.nextToken().trim();
						st.nextToken();
						comment = st.nextToken().trim();
						st.nextToken();
						commentDate = st.nextToken().trim();
						String request_id = getRequestID(appNo);
						boolean appExists = request_id == null
								|| request_id.equals("UNKNOWN")
								|| request_id.equals("UNKNOWN2") ? false : true;
						int status = 0;
						if (appExists) {
							status = getBookingStatus(request_id);
							writeComment(request_id, comment, commentDate);
						} else {
							appendToErrorFile(appNo, comment, commentDate);
						}
						if (status == 2 || status == 3) {
							int intRequest_id = Integer.parseInt(request_id);
							int intEvaluator_id = Integer
									.parseInt(evaluator_id);
							SendNotification.generateDTDSBTransaction(
									intRequest_id, intEvaluator_id, con, log); // DTDSB
							// Type
							// (Dealer
							// Disbursement Segment)
						}
					}
				}
			} while (line != null);
			fileReader.close();
			in.close();
			if (lineCount == 0) {
				log
						.FmtAndLogMsg("Warning, no lines found for file "
								+ fileName);
			}
		} catch (Exception e) {
			log.FmtAndLogMsg("ERROR in processFile for file " + fileName
					+ ", line " + lineCount + "  - " + e);
		} finally {
			try { if (fileReader != null) fileReader.close();} catch (Exception ex) {ex.printStackTrace();}
			try { if (in != null) in.close();} catch (Exception ex) {ex.printStackTrace();}
		}
	}

	private String getRequestID(String appNo) {
		Query query = new Query(con);
		try {
			String select = "select REQUEST_ID from credit_request where client_app_id = ? and evaluator_id = ? ";
			query.prepareStatement(select);
			query.setInt(1, appNo);
			query.setInt(2, evaluator_id);
			query.executePreparedQuery();
			while (query.next())
				return query.getColValue("REQUEST_ID");
		} catch (Exception e) {
			log.FmtAndLogMsg("Error retrieving REQUEST_ID for AppNo " + appNo
					+ " with evaluator_id of " + evaluator_id + " Error: " + e);
			return "UNKNOWN";
		}
		return "UNKNOWN2";
	}

	private int getBookingStatus(String request_id) {
		Query query = new Query(con);
		try {
			String select = "select BOOKING_STATUS_ID from credit_request where request_id = ? ";
			query.prepareStatement(select);
			query.setInt(1, request_id);
			query.executePreparedQuery();
			while (query.next()) {
				String col = query.getColValue("BOOKING_STATUS_ID");
				if (col != null && !col.trim().equals("")
						&& !col.trim().equals("null")) {
					return Integer.parseInt(col);
				} else {
					return -1;
				}
			}
		} catch (Exception e) {
			log
					.FmtAndLogMsg("Error retrieving BOOKING_STATUS_ID for request_id "
							+ request_id
							+ " with evaluator_id of "
							+ evaluator_id + " Error: " + e);
			return -1;
		}
		return -2;
	}

	private void appendToErrorFile(String appNo, String comment,
			String commentDate) {
		FileWriter fw = null;
		try {
			
			/**		
	         * OWASP TOP 10 2010 - A4 Path Manipulation
		     * Changes to the below code to fix vulnerabilities
		     * TTP 324955
		     **/
			//fw = new FileWriter(unknownAppLog, true);
			fw = new FileWriter(OWASPSecurity.validationCheck(unknownAppLog, OWASPSecurity.DIRANDFILE), true);
			if (!headerWritten) {
				fw.write(System.getProperty("line.separator")
						+ System.getProperty("line.separator")
						+ "****Adding unknown apps for program run "
						+ new Date() + "****"
						+ System.getProperty("line.separator"));
				headerWritten = true;
			}
			fw.write("Application Not Found: App ID - " + appNo
					+ ", Comment - " + comment + ", Comment Date - "
					+ commentDate + System.getProperty("line.separator"));
			fw.close();
		} catch (Exception e) {
			log
					.FmtAndLogMsg("Error in appendToErrorFile, could not append to error file - "
							+ "Application Not Found: App ID - "
							+ appNo
							+ ", Comment - "
							+ comment
							+ ", Comment Date - "
							+ commentDate + " - " + e);
		}
		finally {
		    try{ if(fw != null) fw.close(); }catch(Exception e1){e1.printStackTrace();}
		}
	}

	private void writeComment(String request_id, String comment,
			String commentDate) {
		try {
			CommentEvents objComment = new CommentEvents(con, log);
			objComment.addComment((int) Integer.parseInt(request_id), 64,
					"General Disbursement",
					comment + " - Date: " + commentDate, "SYSTEM", "", "");
		} catch (Exception e) {
			log.FmtAndLogMsg("Error inserting comment for request_id "
					+ request_id + ", comment " + comment + ", commentdate "
					+ commentDate);
		}
	}


	private String[] getDatFileList() {
		
		/**		
         * OWASP TOP 10 2010 - A4 Path Manipulation
	     * Changes to the below code to fix vulnerabilities
	     * TTP 324955
	     **/
		//File f = new File(datDir);
		File f=null;
		try
		{
		 f = new File(OWASPSecurity.validationCheck(datDir, OWASPSecurity.DIRANDFILE));
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		String[] list = f.list(new GDFilter());
		f = null;
		return list;
		
	
	}
		
	private void init(String iniFile, String evaluator_id) {
		IniFile ini = new IniFile();
		try {
			this.evaluator_id = evaluator_id;
			ini.readINIFile(iniFile);
			
			String s_log_file = ini.getINIVar("logs.general_disbursements_log_file", "");
			
			// log location
			log.openLogFile(s_log_file);

			log.FmtAndLogMsg(System.getProperty("line.separator")
					+ System.getProperty("line.separator")
					+ "*****General Disbursements - " + new Date() + "*****");
			log.FmtAndLogMsg("logLocationAndName - "
					+ ini.getINIVar("logs.general_disbursements_log_file")
							.trim());

			log.FmtAndLogMsg("iniFile - " + iniFile);

			log.FmtAndLogMsg("evaluator_id - " + evaluator_id);

			// Unknown app log
			unknownAppLog = ini.getINIVar(
					"logs.general_disbursements_unknown_apps").trim();

			// connect to the DB
			dbHost = ini.getINIVar("database.host", "").trim();
			log.FmtAndLogMsg("dbHost - " + dbHost);
			dbPort = ini.getINIVar("database.port", "").trim();
			log.FmtAndLogMsg("dbPort - " + dbPort);
			dbUser = ini.getINIVar("database.user", "").trim();
			log.FmtAndLogMsg("dbUser - " + dbUser);
			dbPass = ini.getINIVar("database.password", "").trim();
			dbSID = ini.getINIVar("database.sid", "").trim();
			log.FmtAndLogMsg("dbSID = " + dbSID);
			sTNSEntry = ini.getINIVar("database.TNSEntry", "");
			log.FmtAndLogMsg("TNS Entry = " + sTNSEntry);
			
			DBConnection DBConnect = new DBConnection();

			if (sTNSEntry.length() == 0) {
				con = DBConnect.getConnection(dbHost, dbSID, dbUser, dbPass, s_log_file, dbPort,"");
			} else {
				// use tns entry if available
				con = DBConnect.getConnectionTNS(sTNSEntry, dbUser,  dbPass, s_log_file);
			}
			
			log.FmtAndLogMsg("Connected to DB");

			// .dat dir
			datDir = ini.getINIVar("generaldisbursements.dat_file_location")
					.trim();
			if (datDir.charAt(datDir.length() - 1) != System.getProperty(
					"file.separator").charAt(0)) {
				datDir = datDir + System.getProperty("file.separator");
			}
			log.FmtAndLogMsg("datDir - " + datDir);

		} catch (Exception e) {
			System.out.println("Error in init() method.  Exiting - " + e);
			System.exit(-1);
		}
	}

	private static void showUsageAndExit() {
		System.out
				.println("General Disbursements - \nUsage: java com.cmsinc.origenate.generaldisbursements.GeneralDisbursements <INI Location> <evaluator_id>");
		System.exit(0);
	}

	class GDFilter implements FilenameFilter {
		public boolean accept(File dir, String name) {
			if (name.endsWith(".dat")) {
				return true;
			} else {
				return false;
			}
		}

	}

}
