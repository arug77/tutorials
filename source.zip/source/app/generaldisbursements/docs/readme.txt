The General Disbursements program takes a directory of quote delimited .dat files from generaldisbursements.dat_file_location and writes an application comment for each line found in each .dat file.  If the application is in a BOOKED, or BOOKEX status, it also sends a transaction to DealerTrack.  If the application cannot be found, an error is appended to logs.general_disbursements_unknown_apps.  The .dat file is then renamed to .dat.done.

To use this program, add the following to origenate.ini:

Under [logs]
general_disbursements_log_file = path_to_log_file
general_disbursements_unknown_apps = path_to_unknown_app_log_file

Create [generaldisbursements] and add:
dat_file_location = path_to_dat_files

To run the program, type:
./start_generaldisbursements.sh <location_of_origenate.ini> <evaluator_id>
i.e.
./start_generaldisbursements.sh /opt/origenate/whatever/origenate.ini 99