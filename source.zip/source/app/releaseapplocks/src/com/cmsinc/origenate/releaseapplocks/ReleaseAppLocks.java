/* Filename: ReleaseAppLocks.java
 * Version:
 * Creation Date: September 18, 2005
 * Author: Gautam Anand
 * Copyright (c) 2002. All rights reserved
 * Description: Refer Clientele #134985
 * This program would release all the application locks for a
 * given evaluator.
 */

package com.cmsinc.origenate.releaseapplocks;

import java.sql.Connection;
import java.util.Vector;

import com.cmsinc.origenate.util.DBConnection;
import com.cmsinc.origenate.util.IniFile;
import com.cmsinc.origenate.util.LogMsg;
import com.cmsinc.origenate.util.SQLUpdate;

public class ReleaseAppLocks {

	private static LogMsg log = new LogMsg(); // log

	/*ReleaseAppLocks Object Instantiation*/
	private static ReleaseAppLocks ra = new ReleaseAppLocks();

	private static Connection con; // db settings

	private static Character ch;

	private static String s_iniFile; // ini filename

	private static String evaluator_id; // Evaluator ID

	private static int log_off_flg=0; //set if all users should be logged off

	private static IniFile ini = new IniFile();

	private static Vector cmdargs = new Vector(10,10);

	/*
	 * Main method to call the getDBConnection method,
	 * delete_from_concurrency_control_table method and
	 * retreive the command line parameters ini file loc
	 * and evaluator id.
	 */
	public static void main(String[] args) {

		String s_log_file = "";
		if (args.length > 0) {
			for (int i = 0; i < args.length; ++i) {
				if ((args[i].charAt(0) != '-') && (args[i].length() > 1)) {
					showUsageAndExit();
				}
				ch = Character.valueOf(args[i].charAt(1));
				cmdargs.add(ch);

				switch (args[i].charAt(1)) {
				case 'i':
					s_iniFile = args[i].substring(2); // ini file
					try {
						ini.readINIFile(s_iniFile);
						s_log_file = ini.getINIVar(
								"logs.ReleaseAppLocks_log_file", "");
						if (s_log_file.length() > 0) {
							log.openLogFile(s_log_file);
						}
					} catch (Exception e)  {
						log.FmtAndLogMsg("Caught exception reading ini file '"
								+ s_iniFile + "':" + e.toString());
					}
					log.FmtAndLogMsg("\r");
					log.FmtAndLogMsg("Starting Release App Locks Tool");
					log.FmtAndLogMsg("\r");
					log.FmtAndLogMsg("iniFile name: " + s_iniFile);
					break;
				case 'e':
					evaluator_id = args[i].substring(2); // Evaluator ID
					log.FmtAndLogMsg("Evaluator Id: " + evaluator_id);
					break;
				case 'l':
				    log_off_flg=1; //Log Off Flag
				    log.FmtAndLogMsg("Log Off Users Flag Set");
				    break;
				default:
					log.FmtAndLogMsg("Unknown parameter: " + args[i]);
					showUsageAndExit();
					break;
				}
			}
		}


		 /* Check if the required command line args are present*/

		try {
			log.FmtAndLogMsg("********Calling checkCmdLineArgs Method********");
			checkCmdLineArgs();
		} catch (Exception e) {
			log.FmtAndLogMsg("Error in checkCmdLineArgs method of : "
					+ e.toString());
		}
		log.FmtAndLogMsg("********checkCmdLineArgs Method Completed********");

		/* Creating a DB Connection */

		try {
			log.FmtAndLogMsg("********Calling getDBConnection Method********");
			getDBConnection(s_log_file);
		} catch (Exception e) {
			log.FmtAndLogMsg("Error in getDBConnection method of : "
					+ e.toString());
		}
		log.FmtAndLogMsg("********getDBConnection Method Completed********");

		/*Calling method to Release App Locks for the given evaluator*/

		try {
			log
					.FmtAndLogMsg("********Calling delete_from_concurrency_control_table Method********");
			ra.delete_from_concurrency_control_table();
		} catch (Exception e) {
			log
					.FmtAndLogMsg("Error in delete_from_concurrency_control_table method of : "
							+ e.toString());
		}
		log
				.FmtAndLogMsg("********delete_from_concurrency_control_table Method Completed********");

		/*Calling method to Log off all users for given Evaluator_ID*/
		if(log_off_flg==1){
			try {
				log
						.FmtAndLogMsg("********Calling Log_Off_All_Users Method********");
				ra.log_off_all_users();
			} catch (Exception e) {
				log
					.FmtAndLogMsg("Error in Log_Off_All_Users Method of : "
						+ e.toString());
				}
				log
					.FmtAndLogMsg("********Log_Off_All_Users Method Completed********");
			}

		log.FmtAndLogMsg("********Release App Locks Tool Completed********");
	}

	/*Method to inform that expected values are missing on the command line*/

	public static void showUsageAndExit() {
		System.out
				.println("Usage: java com.cmsinc.origenate.releaseapplocks.ReleaseAppLocks");
		System.out
				.println("-i<ini file> -e<evaluator_id>");
		System.out
				.println("------------------------------------------------------------------------------");
		System.out.println("Parameter	Data Type	Required/Optional			Description");
		System.out.println("  -i 		 String			Required		ini file name including the location");
		System.out.println("  -e		 Integer 		Required		Evaluator ID");
		System.out.println("  -l		 N/A	 		Optional		Include -l to log off all users");
		System.exit(0);
	}

	/* Method to report an error in a method. */

	public static void recordError(String methodName, Exception err)
			throws Exception {
		try {
			log.FmtAndLogMsg("Error occured in " + methodName + " method of : "
					+ err.toString());
			throw new Exception("Error occured in " + methodName
					+ " method of : " + err.toString());
		} catch (Exception e) {
			log
					.FmtAndLogMsg("Error in reportError method of : "
							+ e.toString());
		}

	}

	/*checks if the command line args are present*/

	public static void checkCmdLineArgs() {
		if(cmdargs.contains(Character.valueOf('i')) && cmdargs.contains(Character.valueOf('e'))) {
			log.FmtAndLogMsg("Required Command Line Parameters Present");
		}
		else {
			log.FmtAndLogMsg("Required Command Line Parameters Missing");
			log.FmtAndLogMsg("Calling showUsageAndExit() method to exit");
			showUsageAndExit();
		}
	}


	/* Get Database connection */

	public static void getDBConnection(String s_log_file) throws Exception {

		try {
			// Get ini file values for DB connection

			String s_dbhost = ini.getINIVar("database.host").trim();
			log.FmtAndLogMsg("dbHost : " + s_dbhost);

			String s_dbport = ini.getINIVar("database.port").trim();
			log.FmtAndLogMsg("dbPort : " + s_dbport);

			String s_dbsid = ini.getINIVar("database.sid").trim();
			log.FmtAndLogMsg("dbSID : " + s_dbsid);

			String s_dbuser = ini.getINIVar("database.user").trim();
			log.FmtAndLogMsg("dbUser : " + s_dbuser);

			String s_dbpassword = ini.getINIVar("database.password").trim();

			String sTNSEntry = ini.getINIVar("database.TNSEntry", "");
			log.FmtAndLogMsg("TNS Entry : " + sTNSEntry);

			DBConnection DBConnect = new DBConnection();

			if (sTNSEntry.length() == 0) {
				// Get DB connection
				con = DBConnect.getConnection(s_dbhost, s_dbsid, s_dbuser,
						s_dbpassword, s_log_file, s_dbport,"");
			} else {
				// use tns entry if available
				con = DBConnect.getConnectionTNS(sTNSEntry, s_dbuser,  s_dbpassword, s_log_file);
			}
		} catch (Exception e) {
			recordError("getDBConnection", e);
		}
	} // end getDBConnection method

	/* Method to Delete Concurrency Control Table Records */

	public void delete_from_concurrency_control_table() {
		try {
			String sql = "DELETE FROM CONCURRENCY_CONTROL"
					+ " WHERE REQUEST_ID IN (SELECT CC.REQUEST_ID"
					+ " FROM CONCURRENCY_CONTROL CC, CREDIT_REQUEST CR"
					+ " WHERE EVALUATOR_ID = ?"
					+ " AND CC.REQUEST_ID=CR.REQUEST_ID)";
			//TTP 324955 Security Remediation Fortify Scan
			SQLUpdate sqlup1 = new SQLUpdate();
			sqlup1.SetPreparedUpdateStatement(con, sql);
			sqlup1.setInt(1, evaluator_id);
			sqlup1.RunPreparedUpdateStatement();
			log
					.FmtAndLogMsg("Deleted rows in CONCURRENCY_CONTROL table with Evaluator_ID "
							+ evaluator_id);
		} catch (Exception e) {
			log
					.FmtAndLogMsg("Error deleting rows in CONCURRENCY_CONTROL table with Evaluator_ID "
							+ evaluator_id + e);
		}
	}

    /* Method to Delete Concurrency Control Table Records */

	public void log_off_all_users() {
		try {
			String sql = "UPDATE USERS"
					+ " SET CONCURRENCY_FLG = 0"
					+ " WHERE EVALUATOR_ID = ?"
					+ " AND ACTIVE_FLG= 1"
					+ " AND CONCURRENCY_FLG = 1";
			//TTP 324955 Security Remediation Fortify Scan
			SQLUpdate sqlup1 = new SQLUpdate();
			sqlup1.SetPreparedUpdateStatement(con, sql);
			sqlup1.setInt(1, evaluator_id);
			sqlup1.RunPreparedUpdateStatement();

			SQLUpdate.RunUpdateStatement(con, sql);
			log
					.FmtAndLogMsg("Updated CONCURRENCY_FLG in USERS to zero for all active users with Evaluator_ID "
							+ evaluator_id);
		} catch (Exception e) {
			log
					.FmtAndLogMsg("Error Updating CONCURRENCY_FLG in USERS with Evaluator_ID "
							+ evaluator_id + e);
		}
	}
} // main class
