#!/bin/ksh

. ../../config/usrconfig.sh

java -classpath .:../lib/evidl.jar::../lib/common.jar:../lib/ojdbc6.jar:../lib/crypto.jar:../lib/IngrianNAE-8.3.1.000.jar:../lib/Ingrianlog4j-api-2.1.jar:../lib/Ingrianlog4j-core-2.1.jar:../lib/commons-codec-1.6.jar:../lib/cryptix-jce-api.jar com.cmsinc.origenate.tool.deactivateUser -i/opt/jrun4/servers/$ENV/cfusion-ear/cfusion-war/config/origenate.ini -e$EVALUATOR
