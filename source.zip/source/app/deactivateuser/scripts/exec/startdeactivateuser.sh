#!/bin/ksh
. /opt/origenate/$1/config/usrconfig.sh
export EVALUATOR=$2

if [ "$EVALUATOR" = "" ]
then
	echo "Evaluator ID not specified -- Fetching Evaluator ID from usrconfig.sh"
	export EVALUATOR=$ORIGEVALID
fi	
cd $ORAPPS/deactivateuser; ./start_deactivateuser.sh
