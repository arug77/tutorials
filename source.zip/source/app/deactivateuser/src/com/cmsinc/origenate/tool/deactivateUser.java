/*
 * deactivateUser.java
 *
 * Created on December 21, 2011
 *
 * @author Dhaval Tamboli
 *
 * @version
 *
 * CL156958
 * Deactivate User from Users table, who have not logged in to origenate for specific number of days
 * Check this days with current date - Users.last_login_dt with Evaluator.User_deactivation_days_num
 *
 */

package com.cmsinc.origenate.tool;

import java.sql.*;

import com.cmsinc.origenate.util.DBConnection;
import com.cmsinc.origenate.util.LogMsg;
import com.cmsinc.origenate.util.IniFile;

public class deactivateUser {

	private java.sql.Connection con;
	private String sHost = "";
	private String sSIDname = "";
	private String sUser = "";
	private String sPass = "";
	private String sPort = "";
	private String sTNSEntry = "";
	private String sIniFile = "";
	private String evaluator = "";
	private IniFile ini = new IniFile();
	private LogMsg log = new LogMsg();
	private String log_file = "";
	private LogMsg log_obj = new LogMsg();

	// default constructor
	public deactivateUser() {
	}

	/** ************************************************************ */
	/* Main method to call Deactivate User app process */
	/** ************************************************************ */
	public static void main(String args[]) throws Exception {
		deactivateUser du = new deactivateUser();

		du.getArgs(args);

		du.deactivateUsers();

		du.closeConnection();
	}

	private void getArgs(String args[]) {
		if (args.length > 0) {
			for (int ix = 0; ix < args.length; ix++) {
				if ((args[ix].charAt(0) != '-') && (args[ix].length() > 1))
					showUsage();
				switch (args[ix].charAt(1)) {
				case 'i': // ini file
					sIniFile = args[ix].substring(2);
					try {
						//
						// Read host, user, sid and password from ini file
						//
						ini.readINIFile(sIniFile);

						sHost = ini.getINIVar("database.host", "");
						sPort = ini.getINIVar("database.port", "");
						sUser = ini.getINIVar("database.user", "");
						sPass = ini.getINIVar("database.password", "");
						sSIDname = ini.getINIVar("database.sid", "");
						sTNSEntry = ini.getINIVar("database.TNSEntry", "");

					} catch (Exception e) {
						log_obj.FmtAndLogMsg("Caught exception reading ini file '"+ sIniFile + "':" + e.toString(), e);
					}
					break;
				case 'e': // evaluator
					evaluator = args[ix].substring(2);
					break;
				default:
					log_obj.FmtAndLogMsg("Unknown parameter: " + args[ix]);
					showUsage();
					break;
				}
			}

			// check for evaluator
			if (evaluator.length() == 0) {
				log_obj.FmtAndLogMsg("Evaluator not supplied");
				showUsage();
			}

			try {
			// open worflow log file
			log_file = ini.getINIVar("logs.workflow_log_file", "");
			log.openLogFile(log_file);
			}
			catch (Exception e) {
				log_obj.FmtAndLogMsg("Error creating logfile: "+log_file+".  "+ e.toString(), e);
			}

			try {
				// open deactivateUser log file
				log_file = ini.getINIVar("logs.deactivateUser_log_file", "");
				log_obj.openLogFile(log_file);
			}
			catch (Exception e) {
				log_obj.FmtAndLogMsg("Error creating logfile: "+log_file+".  "+ e.toString(), e);
			}

			if (((sHost.length() == 0) || (sUser.length() == 0) || (sSIDname.length() == 0) || (sPort.length() == 0)) && sTNSEntry.length() == 0) {
				log_obj.FmtAndLogMsg("Host,User,Pwd,SID or Port not specified in INI file");
				showUsage();
			}

			try {
				DBConnection DBConnect = new DBConnection();

				if (sTNSEntry.length() == 0) {
					con = DBConnect.getConnection(sHost, sSIDname, sUser, sPass, log_file, sPort,"");
				} else {
					// use tns entry if available
					con = DBConnect.getConnectionTNS(sTNSEntry, sUser,  sPass, log_file);
				}
			}
			catch (Exception e) {
				log_obj.FmtAndLogMsg("Error connecting to database: "+ e.toString(), e);
			}
		} else
			showUsage();
	}

	private void showUsage() {
		System.out.println("");
		System.out.println("Usage: java deactivateUser -i<inifile> -e<evalID>");
		System.out.println("---------------------");
		System.out.println("-i - required: INI file to use for configuration");
		System.out.println("-e - required: evaluator ID");
		System.out.println("example: java deactivateUser -ic:/development/origenatebin/origenate.ini -e37");
		System.exit(1);
	}

	private void closeConnection() {
		try {
			if (con != null)
				con.close();
		}
		catch (SQLException e) {
		}
		con = null;
	}

	private void deactivateUsers() {
		PreparedStatement pstmt = null, pstmt1 = null;
		ResultSet rs = null, rs1 = null;
		String sql, sqlUpdate, eventMsg="";
		// get apps qualified for automatic withdrawal...assumes hrs and days will be integer values (not null)
		try {
		
			// If Evaluator_ID is -1, that indicates system user. and system users are not included in this process
			if(evaluator.equals("-1")) {
				log_obj.FmtAndLogMsg("Received System User as Evaluator, which are not included in this process");
				System.exit(0);
			}
				
			// Deactivate Users by changing active_flg to 0, if it falls under specified criteria
			// Criteria- 1)  User has not logged in for equal or more than user_deactivation_days from evaluator table.
			//			  2) Exclude users where the user record is locked indicating that the record is in use
			sql = "SELECT U.USER_ID as USER_ID "+
					"FROM USERS U, EVALUATOR E "+
					 "WHERE U.EVALUATOR_ID = ? "+
					 "AND U.ACTIVE_FLG = 1 "+
					 "AND U.EVALUATOR_ID = E.EVALUATOR_ID "+
					 "AND U.USER_ID NOT IN (SELECT USER_ID from CONCURRENCY_CONTROL) "+
					 "AND (SYSDATE - U.LAST_LOGIN_DT) >= E.USER_DEACTIVATION_DAYS_NUM ";
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, Integer.parseInt(evaluator));
			rs = pstmt.executeQuery();

			log_obj.FmtAndLogMsg("Used Selection Query:  "+sql);

			// Deactivate All users which are selected from above query
			while (rs.next()) {
				
				eventMsg = "Deactivating User: "+rs.getString("USER_ID")+" From Scheduled Process ";
				log_obj.FmtAndLogMsg(eventMsg);
				//DEACTIVATE USER
				try {
	            	 sqlUpdate = "UPDATE USERS SET ACTIVE_FLG = 0,STATUS_TXT='D' WHERE USER_ID = ?";
					 pstmt1 = con.prepareStatement(sqlUpdate);
					 pstmt1.setString(1, rs.getString("USER_ID"));
					 pstmt1.executeUpdate();	
					 pstmt1.close();
	            }
	           	catch (Exception e) {
	           		log_obj.FmtAndLogMsg("Error occured while Deactivating User: "+e, e);
					eventMsg = "Error Occured while Deactivating User from Scheduled Process: "+e.toString();
		            try{ if(pstmt1 != null) pstmt1.close(); }catch(Exception e1){e1.printStackTrace();}
	            }
				
				// SAVE DEACTIVATING MESSAGE IN EVENT TABLE
	            try {
				
					//Finds next Event_ID
					pstmt1 = con.prepareStatement("select event_id_seq.nextval event_id from dual");
					rs1 = pstmt1.executeQuery();
					int event_id=0;
					if (rs1.next()) 
						event_id = rs1.getInt(1);					
					
					//Close preparedstatement and resultsets
					try{ if(rs1 != null) rs1.close(); }catch(Exception e1){e1.printStackTrace();}
		            try{ if(pstmt1 != null) pstmt1.close(); }catch(Exception e1){e1.printStackTrace();}
					
	            	String insertEvent = "INSERT INTO EVENT(event_id, event_type_id, event_dt, evaluator_id, user_id,	additional_desc_txt) values (?, 7, sysdate, ?, ?, ?)";
					pstmt1 = con.prepareStatement(insertEvent);
					pstmt1.setInt(1,event_id);
					pstmt1.setInt(2,Integer.parseInt(evaluator));
					pstmt1.setString(3,rs.getString("USER_ID"));
					pstmt1.setString(4,eventMsg);
					pstmt1.executeUpdate();
					
					log_obj.FmtAndLogMsg("Entered new Event with Event ID: "+event_id);		            
	            }
	            catch (Exception e) {
	            	log_obj.FmtAndLogMsg("Error Occured while Saving Event: "+e, e);					
	            }
				finally {
				    try{ if(rs1 != null) rs1.close(); }catch(Exception e1){e1.printStackTrace();}
		            try{ if(pstmt1 != null) pstmt1.close(); }catch(Exception e1){e1.printStackTrace();}
				}
				
			}

		}
		catch (Exception e) {
			log_obj.FmtAndLogMsg("Error: Exception Deactivating  users.  "+e, e);
			System.exit(0);

	    }
		finally {
			try{ if(rs != null) rs.close(); }catch(Exception e1){e1.printStackTrace();}
		    try{ if(pstmt != null) pstmt.close(); }catch(Exception e1){e1.printStackTrace();}
		}
	}
}