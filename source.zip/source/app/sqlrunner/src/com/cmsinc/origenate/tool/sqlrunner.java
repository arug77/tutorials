/*
 * Filename: sqlrunner.java
 * Version: 1.0
 * Creation Date: July 26, 2011
 * Author: Michael Swain
 * Description:
 * Standalone application to run SQL queries from a file.
 * Uses origenate.ini file for DB Connection, then runs
 * queries in file and outputs to separate file (ini, 
 * sql, and output file names specified on command line).
 * Capable of running DML and DDL, as well as inline procedures
 * beginning with DECLARE keyword and executing stored procedures.
 * Comments of the format --.....(single line) and /*..... * / (without space
 * between * and /) are stripped from the file before processing.
 * SQL*Plus commands should not be part of the SQL File. SET commands
 * are removed and EXEC procedure commands are replaced with CALL procedure.
 * For SELECT statements, result of query is output to file. For procedures,
 * the DBMS_OUTPUT is output to file. Other DML and DDL outputs the
 * number of rows affected. CALLing stored procedures prints successful
 * on success and throws exception otherwise.
 */

package com.cmsinc.origenate.tool;

import java.io.*;
import java.sql.*;
import java.util.Scanner;
import org.apache.commons.cli.*;

import com.cmsinc.origenate.util.DBConnection;
import com.cmsinc.origenate.util.IniFile;
import com.cmsinc.origenate.util.LogMsg;

public class sqlrunner {
	private Connection conn = null;
	private String sqlFileName = null;
	private String outFileName = null;
	private Scanner scan = null;
	private PrintWriter out = null;
	private Options options = null;
	private LogMsg log = new LogMsg();
	
	// Types of SQL Statements supported (will be explained
	// in more detail later in code why there are only 5).
	private enum QueryType { SELECT, UPDATE, SET, PROCEDURE, CALL };
	private QueryType qt = null;
	
	public static void main(String[] args) {
		sqlrunner sr = new sqlrunner();
		
		// Get arguments
		sr.getArgsCLI(args);
		
		// Initialize the reader and writer
		sr.initFileReader();
		sr.initFileWriter();
		
		// Kick off the queries
		sr.runQueries();
		
		// Close everything
		try {
			sr.conn.close();
			sr.scan.close();
			sr.out.close();
		}
		catch(Exception e){}
	}
	
	/**
	 * sqlrunner constructor
	 * Usage:
	 * 1. call getArgs with arguments for sqlrunner
	 * 2. call initFileReader and initFileWriter
	 * 3. call runQueries to run
	 * 4. close conn, scan, and out
	 */
	public sqlrunner() {
		
	}
	
	/**
	 * Runs the queries found in sqlFileName
	 * <br />QueryType object qt, set from call to getNextStatement
	 * in this method, has meaning:
	 * <ul>
	 * <li>PROCEDURE for procedures</li>
	 * <li>SELECT for select statements</li>
	 * <li>UPDATE for anything that will change DB. For example:</li>
	 * <ul><li>Update</li><li>Insert</li><li>Delete</li>
	 * <li>Alter</li><li>Create</li><li>etc.</li></ul>
	 * <li>SET for any SQL*Plus Set statements (ignored)</li>
	 * <li>CALL for any stored procedure calls</li></ul>
	 */
	private void runQueries() {
		String sql = null;
		PreparedStatement stmt = null;
		CallableStatement cstmt = null;
		int res = 0;
		
		// While there are more queries
		while((sql = getNextStatement()) != null) {
			if(!sql.isEmpty()) {
				try {
					// Print query to file
					out.println(sql);
					
					log.FmtAndLogMsg("Starting SQL Query");
					log.FmtAndLogMsg("--Query base type: " + qt.toString());
					log.FmtAndLogMsg("--Query: "+ sql);
					
					// Handle query type with appropriate JDBC
					// method and output results to file
					switch(qt) {
					case SELECT:
						stmt = conn.prepareStatement(sql);
						ResultSet rs = stmt.executeQuery();
						showColumnHeaders(rs);
						while(rs.next()) {
							showNextSelect(rs);
						}
						break;
					case UPDATE:
						stmt = conn.prepareStatement(sql);
						res = stmt.executeUpdate();
						out.println(res + " " + (res==1?"row":"rows") + " changed.");
						break;
					case PROCEDURE:
						enableDBOutput();
						cstmt = conn.prepareCall(sql);
						res = cstmt.executeUpdate();
						out.println(retrieveDBOutput());
						break;
					case CALL:
						cstmt = conn.prepareCall(sql);
						cstmt.execute();
						out.println("Call was successful");
						break;
					default:
						throw new Exception();	
					}
					
					try {stmt.close();} catch (Exception e) {}
					try {cstmt.close();} catch (Exception e) {}
					
				}
				catch(SQLException e) {
					out.println(e.getMessage());
					log.FmtAndLogMsg("--SQL Exception");
					log.FmtAndLogMsg(e.getMessage());
				}
				catch(Exception e) {
					log.FmtAndLogMsg("--Error running statement: " + sql);
					log.FmtAndLogMsg(e.getMessage());
				}
				
				log.FmtAndLogMsg("Completed SQL Query");
			}
		}
	}
	
	/**
	 * Get the next SQL statement or procedure in the file.
	 * SQL statements start with one of the keywords, like
	 * SELECT. Procedures must start with the keyword DECLARE
	 * (case insensitive). For queries, the trailing
	 * semicolon is removed. For procedures, the trailing
	 * forward slash is removed. This allows it to comply
	 * with JDBC standards.
	 * @return String containing SQL for JDBC Statement
	 */
	private String getNextStatement() {
		log.FmtAndLogMsg("-------------------------------");
		log.FmtAndLogMsg("Getting Next Query");
		
		// Use "while" instead of "if" to read through blank lines
		while(scan.hasNextLine()) {
			String next = scan.nextLine();
			
			// Get rid of leading whitespace, otherwise
			// it will fall into "else" category below.
			// Also get rid of extraneous whitespace.
			next = next.replaceAll("^[ \t]*", "");
			next = next.replaceAll("[ \t\n\r]+", " ");
			
			// If the next line is not only whitespace
			if(next.replaceAll("[ \t\n\r]+", "").length() > 0) {
				
				// Define a procedure as anything that is forward slash terminated, not semicolon terminated
				if((next.toLowerCase().indexOf("declare") == 0)
						|| (next.toLowerCase().indexOf("begin") == 0)
						|| (next.toLowerCase().indexOf("procedure") == 0)
						|| (next.toLowerCase().indexOf("function") == 0)
						|| (next.toLowerCase().replaceAll("[ \t\n\r]+", "").indexOf("createorreplaceprocedure") == 0)
						|| (next.toLowerCase().replaceAll("[ \t\n\r]+", "").indexOf("createorreplacefunction") == 0)
						|| (next.toLowerCase().replaceAll("[ \t\n\r]+", "").indexOf("createprocedure") == 0)
						|| (next.toLowerCase().replaceAll("[ \t\n\r]+", "").indexOf("createfunction") == 0)) {
					log.FmtAndLogMsg("--Query Type: Procedure");
					
					qt = QueryType.PROCEDURE;
					
					return parseProcedure(next);
				}
				
				// The next two are for procedure/function calls.
				// Exec is a SQL*Plus command, so replace it with call.
				else if((next.toLowerCase().indexOf("exec") == 0)
						|| (next.toLowerCase().indexOf("call") == 0)) {
					log.FmtAndLogMsg("--Query Type: Call");
					
					qt = QueryType.CALL;
					
					// Replace exec with call
					next = "call" + next.substring(4);
					
					// Even though we removed leading white space earlier,
					// use parseNextStatement as a last check, including
					// removing the semicolon at the end of the query.
					return parseNextStatement(next);
				}
					
				else if(next.toLowerCase().indexOf("execute") == 0) {
					log.FmtAndLogMsg("--Query Type: Call");
					
					qt = QueryType.CALL;
					
					// Replace execute with call
					next = "call" + next.substring(7);
					
					return parseNextStatement(next);
				}	
				
				// SQL*Plus command set should be ignored
				else if(next.toLowerCase().indexOf("set") == 0) {
					log.FmtAndLogMsg("--Query Type: Set (SQL*Plus statement ignored)");
					
					/*-------------------------------
					NOTE: SET IS ACTUALLY A SQL*PLUS
					COMMAND, SO USE A WAY TO
					ENABLE OUTPUT AND GET IT THAT
					WAY INSTEAD - CURRENTLY 
					AUTOMATICALLY ENABLING OUTPUT
					WHEN DOING PROCEDURE
					--------------------------------*/
					qt = QueryType.SET;
					
					return "";
				}
				
				// Select statement
				else if(next.toLowerCase().indexOf("select") == 0) {
					log.FmtAndLogMsg("--Query Type: Select");
					
					qt = QueryType.SELECT;
					
					return parseNextStatement(next);
				}
				
				// Define Update as any single statement that makes changes
				// to the DB. This can be DML, DDL, etc.
				else {
					log.FmtAndLogMsg("--Query Type: Update");
					
					qt = QueryType.UPDATE;
					
					return parseNextStatement(next);
				}
			}
		}
		
		log.FmtAndLogMsg("No Next Query");
		
		return null;
	}
	
	/**
	 * Gets procedure from predefined Scanner object, with the first line
	 * already read from the Scanner and passed in as a parameter.
	 * @param firstLine - The first line of the procedure (usually just the
	 * keyword 'declare')
	 * @return String containing procedure up until trailing forward slash <b>/</b>
	 * <br />Returns empty string if no forward slash <b>/</b> found
	 */
	private String parseProcedure(String firstLine) {
        StringBuilder temp_builder = new StringBuilder(firstLine);
		boolean foundEnd = false;
		
		// Run through the statements in the scanner until reaching
		// a forward slash on a line of its own.
		while(scan.hasNextLine()) {
			String next = scan.nextLine();
			
			// If the next line is a forward slash on its own
			if(next.replaceAll("[ \t]+", "").equals("/")) {
				foundEnd = true;
				break;
			}
			
			// Otherwise, continue to build procedure
			else {
				temp_builder.append(" "+next);
			}
		}
        String procedure = temp_builder.toString();

		// If we found the procedure, log message and return
		// the sql. Otherwise, log error and return empty,
		// which means it will simply be skipped (and also
		// end processing, because it means it looked all the
		// way to the end of the file without finding an end
		// to the procedure).
		if(foundEnd) {
			log.FmtAndLogMsg("Query Successfully Retrieved");
			
			return procedure;
		}
		else {
			log.FmtAndLogMsg("--Could not find end of procedure, returning empty query");
			
			return "";
		}		
	}
	
	/**
	 * Removes the trailing semicolon, replaces newlines,
	 * tabs, and carriage returns with spaces, and removes
	 * a possible leading space or tab from the string.
	 * @param next - String to parse
	 * @return String parsed for use with JDBC Statement
	 */
	private String parseNextStatement(String next) {
		next = next.replaceAll(";", "");
		next = next.replaceAll("[\r\n\t]", " ");
		next = next.replaceAll(" [ \r\n\t]*", " ");
		next = next.replaceAll("^[ \t]*", "");
		
		log.FmtAndLogMsg("Query Successfully Retrieved");
		
		return next;
	}
	
	/**
	 * Displays the column headers of a select statement
	 * @param rs - the ResultSet to display
	 * @throws SQLException
	 * @throws Exception
	 */
	private void showColumnHeaders(ResultSet rs) throws SQLException, Exception {
		int i;
		ResultSetMetaData rsmd = rs.getMetaData();
		int numCols = rsmd.getColumnCount();
		for(i = 1; i <= numCols; i++) {
			out.print(rsmd.getColumnName(i)+"|");
		}
		out.println();
	}
	
	/**
	 * Displays the results of a select statement
	 * @param rs - the ResultSet to display
	 * @throws SQLException
	 * @throws Exception
	 */
	private void showNextSelect(ResultSet rs) throws SQLException, Exception {
		int i;
		int numCols = rs.getMetaData().getColumnCount();
		for(i = 1; i <= numCols; i++) {
			out.print(rs.getString(i)+"|");
		}
		out.println();
	}
	
	/**
	 * Initialize Scanner to read from sqlFileName
	 */
	private void initFileReader() {
		log.FmtAndLogMsg("Initializing File Reader");
		if(sqlFileName == null || sqlFileName.isEmpty()) {
			log.FmtAndLogMsg("--No file found. File name may be empty in command line.");
			System.exit(0);
		}
			
		try {
			scan = new Scanner(new FileInputStream(sqlFileName));
			
			removeComments();
		}
		catch(Exception e) {
			log.FmtAndLogMsg("--No SQL file found with specified file name.");
			System.exit(0);
		}
		log.FmtAndLogMsg("File Reader Initialized");
	}
	
	/**
	 * Initialize the file writer to print to outFileName
	 */
	private void initFileWriter() {
		log.FmtAndLogMsg("Initializing File Writer");
		try {
			out = new PrintWriter(new FileWriter(outFileName));
		}
		catch(Exception e) {
			log.FmtAndLogMsg("--No output file found with specified file name.");
			System.exit(0);
		}
		log.FmtAndLogMsg("File Writer Initialized");
	}
	
	/**
	 * Strips out comments and separates SQL queries by newlines.
	 * Creates a new string from the Scanner object and then
	 * assigns the Scanner to this new string.
	 */
	private void removeComments() {
		log.FmtAndLogMsg("Removing comments for query parsing");
		try {
            StringBuilder temp_builder = new StringBuilder("");
			
			// Read in the file
			while(scan.hasNextLine())
				temp_builder.append(scan.nextLine()+"\n");
            String str = temp_builder.toString();
			
			// Strip out comments
			str = str.replaceAll("(/\\*[^+]([^*]|[\r\n]|(\\*+([^*/]|[\r\n])))*\\*+/)|(//.*)|(--.*[\n\r]*)", " ");
			
			// Ensure that all statements are on separate lines (will be important for parsing)
			// Everything up to a semicolon will be on a line. This will make recognizing
			// the type of statement easier. Also make sure that the forward slash to
			// end a procedure is on a separate line.
			str = str.replaceAll("[\r\n]+", " ");
			str = str.replaceAll(";", ";\n");
			str = str.replaceAll(";\n[ \t]*/",";\n/\n");
			
			// Close file
			scan.close();
			
			// Replace the scanner with scanner of new string
			scan = new Scanner(str);
		}
		catch(Exception e)
		{
			log.FmtAndLogMsg("--Error removing comments: ");
			log.FmtAndLogMsg(e.getMessage());
			System.exit(0);
		}
		log.FmtAndLogMsg("Comments successfully removed");
	}
	
	/**
	 * Enables dbms_output
	 */
	private void enableDBOutput() {
		log.FmtAndLogMsg("Turning DB Output On");
		
		try {
			CallableStatement enableStatement = conn.prepareCall("begin dbms_output.enable(:1); end;");
			enableStatement.setLong(1, 1024);
			enableStatement.executeUpdate();
			enableStatement.close();
		}
		catch (SQLException e) {
			log.FmtAndLogMsg("--Error Enabling DB Output");
			log.FmtAndLogMsg(e.getMessage());
		}
		
		log.FmtAndLogMsg("DB Output Turned On");
	}
	
	/**
	 * Gets the buffered output from dbms_output
	 * @return String with output
	 */
	private String retrieveDBOutput() {
		log.FmtAndLogMsg("Getting DB Output");
		
		// Found this code and above method code online. It
		// uses a procedure to get the buffered output
		// from dbms_output.
		CallableStatement showOutputStatement = null;
		StringBuffer result = null;
		try {
			showOutputStatement = conn.prepareCall(
					"declare " +
					"    l_line varchar2(255); " +
					"    l_done number; " +
					"    l_buffer long; " +
					"begin " +
					"  loop " +
					"    exit when length(l_buffer)+255 > :maxbytes OR l_done = 1; " +
					"    dbms_output.get_line( l_line, l_done ); " +
					"    l_buffer := l_buffer || l_line || chr(10); " +
					"  end loop; " +
					" :done := l_done; " +
					" :buffer := l_buffer; " +
					"end;");

			showOutputStatement.registerOutParameter(2, Types.INTEGER);
			showOutputStatement.registerOutParameter(3, Types.VARCHAR);
			result = new StringBuffer(1024);
			while(true) {
				showOutputStatement.setInt(1, 32000);
				showOutputStatement.executeUpdate();
				result.append(showOutputStatement.getString(3).trim());
				if (showOutputStatement.getInt(2) == 1) {
					break;
				}
			}
			showOutputStatement.close();
		}
		catch(SQLException e) {
			log.FmtAndLogMsg("--Error getting DB Output");
			log.FmtAndLogMsg(e.getMessage());
		}
		finally {
		   try{if(showOutputStatement !=null) showOutputStatement.close();} catch(Exception e1) {e1.printStackTrace();}
		}
		log.FmtAndLogMsg("DB Output Successfully Retrieved");
		
		return result.toString();
	}
	
	/**
	 * Connects to a DB with information from ini file.
	 * Uses Connection variable conn
	 * @param ini - IniFile object
	 */
	private void connectToDB(IniFile ini) {
		String dbhost="", dbport="", dbsid="", dbuser="", dbpwd="", sTNSEntry="";
		dbhost = ini.getINIVar("database.host", "");
		dbport = ini.getINIVar("database.port", "");
		dbuser = ini.getINIVar("database.user", "");
		dbpwd = ini.getINIVar("database.password", "");
		dbsid = ini.getINIVar("database.sid", "");
		sTNSEntry = ini.getINIVar("database.TNSEntry", "");
		
		log.FmtAndLogMsg("Connecting to DB");
		
		try {
			DBConnection DBConnect = new DBConnection();

			if (sTNSEntry.length() == 0) {
				conn = DBConnect.getConnection(dbhost, dbsid, dbuser, dbpwd, null, dbport,"");
			} else {
				// use TNS entry if available
				conn = DBConnect.getConnectionTNS(sTNSEntry, dbuser,  dbpwd, null);
			}
		}	
		catch(Exception e) {
			log.FmtAndLogMsg("--Exception: supplied db information could not create a connection. See usage");
			showUsage();
      	}
		
		log.FmtAndLogMsg("Successfully Connected to DB");
	}
	
	/**
	 * Requires at least 3, maximum 5, arguments for sqlrunner
	 * ini file - path to origenate.ini file to use for configuration
     * sql file - path to the script or series of queries to run
     * output file - path to the output file to write results to
     * debug(optional) - 1=on/0=off; default is off; denotes whether to write intermediate results to log
	 * help - print usage info
	 * @param args - The arguments to sqlrunner
	 */
	@SuppressWarnings("static-access")
	public void getArgsCLI(String[] args)
	{	
		IniFile ini = new IniFile();
		String inifile="",sLogFile="";
		
		CommandLineParser parser = new GnuParser();
		options = new Options();
		options.addOption("h","help",false,"Print usage information");
		Option iniFile = OptionBuilder.withArgName("file").hasArg()
						.withDescription("Path to origenate.ini file to use for configuration (required)")
						.create("i");
		Option sqlFile = OptionBuilder.withArgName("file").hasArg()
						.withDescription("Path to the script or series of queries to be run (required)")
						.create("s");
		Option outFile = OptionBuilder.withArgName("file").hasArg()
						.withDescription("Path to the output file to write results to (required)")
						.create("o");
		options.addOption(iniFile);
		options.addOption(sqlFile);
		options.addOption(outFile);
		
		CommandLine cmdLine = null;
		try {
			cmdLine = parser.parse(options, args);
		}
		catch(ParseException e) {
			System.err.println("Error parsing arguments.");
			showUsage();
		}
		
		if(cmdLine.hasOption('h')) {
			showUsage();
		}
		
		if(cmdLine.hasOption('i')) {
			inifile = cmdLine.getOptionValue('i');
			
            try {
				ini.readINIFile(inifile);
				sLogFile = ini.getINIVar("logs.sqlrunner_log_file","");
				if(sLogFile.length() > 0) {
					log.openLogFile(sLogFile);
				}
			} catch (Exception e) {
				System.out.println("Caught exception reading ini file '"+ inifile + "':" + e.toString());
			}
			
			log.FmtAndLogMsg("Finished reading from INI file");
		}
		else {
			showUsage();
		}
		
		if(cmdLine.hasOption('s')) {
			sqlFileName = cmdLine.getOptionValue('s');
			
			log.FmtAndLogMsg("SQL File name: " + sqlFileName);
			
			if(sqlFileName.length() <= 0) {
				log.FmtAndLogMsg("Need to specify SQL file");
				showUsage();
			}
		}
		else {
			showUsage();
		}
		
		if(cmdLine.hasOption('o')) {
			outFileName = cmdLine.getOptionValue('o');
			
			log.FmtAndLogMsg("Output File name: " + outFileName);
			
			if(outFileName.length() <= 0) {
				log.FmtAndLogMsg("Need to specify output file");
				showUsage();
			}
		}
		else {
			showUsage();
		}
		
		// If no errors in args, try to connect to DB
		connectToDB(ini);
	}
	
	/**
	 * Shows the usage information for sqlrunner
	 */
	public void showUsage() {
		HelpFormatter formatter = new HelpFormatter();
		formatter.printHelp("sqlrunner", options);
		System.exit(1);
	} 	
}