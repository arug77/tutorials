#!/bin/ksh
#
#   Daybreak Script
#   Description:
#     Origenate creates a File for an application that holds data segments. Each segement is delimited using a tag name.
#     This script:
#     1) Looks in a directory ($DAYBREAK_SRC_DIR) for files ($DAYBREAK_PATTERN) 
#     2) Run thru once. If $DAYBREAK_SLEEP_SECS > 0, will loop every X seconds ($DAYBREAK_SLEEP_SECS).  
#     3) Moves Source File to a save directory ($DAYBREAK_SAVE).
#     4) Extracts data segments ($DAYBREAK_SEGMENTS) from the source file and appends them to a data file for that segment.
#     5) Data file is named segment.YYYYMMDD.HHMMSS.dat  (new 9/2/2005)
#
#  Author:  Michael Fitzsimmons 07/25/2005
#
#  Default Mode:
#  1) Supporting files reside in same directory as script.  MYDIR is set to this directory
#  2) Variables can be set using env vars:
#    +) DAYBREAK_PROC_DIR: Directory for Process and temp files.  Defaults to $MYDIR/PROCESS.
#    +) DAYBREAK_SRC_DIR:  Directory holding application data files for import. Defaults to MYDIR.
#    +) DAYBREAK_DEST_DIR: Directory holding data files. Defaults to MYDIR.
#    +) DAYBREAK_LOG: log entries to this file.  File is overwritten.  Defaults to file $MYDIR/daybreak.log
#    +) DAYBREAK_SAVE:  Holds processed data files.  Defaults to child directory under MYDIR named "SAVE". 
#       Directory will be created if it does not exist.  

# Modifications
# 04/16/2008: Replaced whoami command with id -un logic.  Corrected spelling of "Summarizing" -Fitz
# 06/18/2008: Changes to Log messages: Show START instead of Start. Log command and dirs. Show log file name to user. -Fitz

##############################################################################################################

MY_PID=$$
TASK="Daybreak Consolidator:"  # Shown at begining of log entries
DATA_FOUND=NO         # Indicates if any segment data was found

##############################################################################################################
remove_temp_files()
{
  ProcPid=$1
  for SEG in $DAYBREAK_SEGMENTS
  do
    rm -f $DAYBREAK_PROC_DIR/$SEG.$ProcPid.dat 2>/dev/null
  done
}
##############################################################################################################

##############################################################################################################
stop_process()
{
  ProcPid=$1
  remove_temp_files $ProcPid
  rm -f $DAYBREAK_PROC_DIR/daybreak_process.$ProcPid.pid 2>/dev/null  # the presence of this file allows script to continue
  rm -f $DAYBREAK_PROC_DIR/daybreak_process.$ProcPid.pid.stop 2>/dev/null
  rm -f $DAYBREAK_PROC_DIR/daybreak.sed.$ProcPid 2>/dev/null
}
##############################################################################################################

##############################################################################################################
test_process()
{
  if [ -f $PROCESS_FILE ]; then
    if [ ! -f ${PROCESS_FILE}.stop ]; then
      return 0    ## Stop file will cause this process to stop
    fi
    if [ ! -r $PROCESS_FILE ]; then
      echo "Can not read process file: $PROCESS_FILE"
      return 1
    fi
    exec < $PROCESS_FILE
    read PROCESS_PID
    read PROCESS_USER
    read PROCESS_CMD
    if [ x"${PROCESS_USER}" = x -o x"${PROCESS_CMD}" = x ]; then
      rm -f $PROCESS_FILE 2>/dev/null
      rm -f ${PROCESS_FILE}.stop 2>/dev/null
      if [ x"${PROCESS_PID}" != x ]; then
	remove_temp_files $PROCESS_PID
      fi
      return 0   ## Can not validate running processes, presume okay to start
    fi
    ps -fp$PROCESS_PID 2>/dev/null|grep "${PROCESS_USER} .*${PROCESS_CMD}">/dev/null
    RESULT=$?
    if [ $RESULT = 0 ]; then
      return 1   ## Process is running, NOT okay to start
    fi
    stop_process $PROCESS_PID
    return 0   ## Process is not running
  fi
  return 0   ## Can not validate running processes, presume okay to start
}
##############################################################################################################

##############################################################################################################
create_proc_file()
{

MYPROCFILE=$DAYBREAK_PROC_DIR/daybreak_process.$MY_PID.pid # the presence of this file allows script to continue
touch $MYPROCFILE                                 # the presence of this file allows script to continue

if [ ! -r $MYPROCFILE ]; then
    echo "`date +'%m/%d/%Y %X'` $TASK ERROR!  Process file is not readable: ${MYPROCFILE}.\n"|tee -a $LOGFILE
  return 1
fi

## Get the Command line as shown by ps -f  This way ps COMMAND truncation will not affect testing for process
POSN=`ps -fp$MY_PID|head -1 $INFO_FILE|sed s/COMMAND.*//|sed s/CMD.*//|wc -c`
POSN=`echo ${POSN}`   # This removes leading/trailing blanks
CMDLINE=`ps -fp$MY_PID|tail -1|sed s/".\{$POSN\}"//`

echo $MY_PID>$MYPROCFILE
case `uname` in
  AIX|HP-UX)
    IAM=`id -un`
    ;;
  SunOS)
    IAM=`/usr/xpg4/bin/id -un`
    ;;
esac
echo $IAM>>$MYPROCFILE
echo "$CMDLINE">>$MYPROCFILE

}
##############################################################################################################

##############################################################################################################
checklogfile()         ###  Validate Log file
{
  export LOGFILE=$1
  touch $LOGFILE 
  if [ ! -f $LOGFILE ]; then
    echo "`date +'%m/%d/%Y %X'` $TASK Startup ERROR! Can not access log file: $LOGFILE."
    return 1
  elif [ ! -w $LOGFILE ]; then
    echo "`date +'%m/%d/%Y %X'` $TASK Startup ERROR! Can not write to log file: $LOGFILE."
    return 1
  fi
  return 0
}
##############################################################################################################

##############################################################################################################
create_sed_file()
{
  SEGCNT=0
  for SEG in $DAYBREAK_SEGMENTS
  do
    touch $DAYBREAK_PROC_DIR/$SEG.$MY_PID.dat
    if [ ! -f $DAYBREAK_PROC_DIR/$SEG.$MY_PID.dat ]; then
      echo "`date +'%m/%d/%Y %X'` ERROR! $TASK Can not create temp file ($DAYBREAK_PROC_DIR/$SEG.$MY_PID.dat)"
      ERROR_FLAG=ERROR
      return 1
    fi
    rm -f $DAYBREAK_PROC_DIR/$SEG.$MY_PID.dat 2>/dev/null
    ### linetot and chartot show total number of lines and characters for each segment
    linetot[SEGCNT]=0
    chartot[SEGCNT]=0
    let "SEGCNT = SEGCNT + 1" 
  done

  > $DAYBREAK_PROC_DIR/daybreak.sed.$MY_PID 2>/dev/null
  if [ ! -f $DAYBREAK_PROC_DIR/daybreak.sed.$MY_PID ]; then
    echo "`date +'%m/%d/%Y %X'` ERROR! $TASK Can not create temp sed file ($DAYBREAK_PROC_DIR/daybreak.sed.$MY_PID)"
    ERROR_FLAG=ERROR
    return 1
  fi

  #echo "## Search for segments on a single line" > $DAYBREAK_PROC_DIR/daybreak.sed.$MY_PID 2>/dev/null
  for SEG in $DAYBREAK_SEGMENTS
  do
    echo "/^<$SEG>.*<\\/$SEG>\\015$/{"
    echo "s/^<$SEG>\\(.*\\)<\\/$SEG>\\015$/\\1/"
    echo "w $DAYBREAK_PROC_DIR/$SEG.$MY_PID.dat"
    echo "b"
    echo "}"
    echo
  done >> $DAYBREAK_PROC_DIR/daybreak.sed.$MY_PID 2>/dev/null

  #echo "## Search for segments spanning multiple lines" >> $DAYBREAK_PROC_DIR/daybreak.sed.$MY_PID 2>/dev/null
  for SEG in $DAYBREAK_SEGMENTS
  do
    echo "/^<$SEG>/,/<\/$SEG>$/{"
    echo "s/^<$SEG>//"
    echo "s/<\/$SEG>\\015$//"
    echo "w $DAYBREAK_PROC_DIR/$SEG.$MY_PID.dat"
    echo "b"
    echo "}"
    echo
  done >> $DAYBREAK_PROC_DIR/daybreak.sed.$MY_PID 2>/dev/null

}
##############################################################################################################

##############################################################################################################
parse_command()
{
  ## Take contents of application file and move segments to relevent flat file
  PARSE_FILE=$1
  SEG_DATA_STATUS="No Data Found"

  for SEG in $DAYBREAK_SEGMENTS   ## Create temporary segment files
  do
    > $DAYBREAK_PROC_DIR/$SEG.$MY_PID.dat
  done
  
  cat $PARSE_FILE|sed -n -f $DAYBREAK_PROC_DIR/daybreak.sed.$MY_PID

  SEGCNT=0
  filelinetot=0
  filechartot=0
  for SEG in $DAYBREAK_SEGMENTS     ## Append temporary segment files onto main segment files
  do
    if [ -s $DAYBREAK_PROC_DIR/$SEG.$MY_PID.dat ]; then
      seglinetot[SEGCNT]=0
      segchartot[SEGCNT]=0
      cat $DAYBREAK_PROC_DIR/$SEG.$MY_PID.dat >> $DAYBREAK_DEST_DIR/$SEG.$TimeStamp.dat
      DATA_FOUND=yes
      SEG_DATA_STATUS="Data Parsed"
      ## Count number of lines and characters per segment
      if [ "$DAYBREAK_SHOW_TOTALS" = YES ]; then
	lcnt=0 ccnt=0
	wc -lc $DAYBREAK_PROC_DIR/$SEG.$MY_PID.dat| read lcnt ccnt fname
	let "linetot[SEGCNT] = linetot[SEGCNT] + lcnt"
	let "chartot[SEGCNT] = chartot[SEGCNT] + ccnt"
	let "filelinetot = filelinetot + lcnt"
	let "filechartot = filechartot + ccnt"
      fi
    fi
    let "SEGCNT = SEGCNT + 1" 
  done   # for SEG in $DAYBREAK_SEGMENTS     ## Append temporary segment files onto main segment files

}
##############################################################################################################

##############################################################################################################

#######################################################################################################################
# $0 shows -ksh if dot scriptname is used in starting script (i.e. ". scriptname.sh a b c")
# Script can not be run in current shell, i.e. do not run using "dot name" 
SCRIPTNAME=${0##*/} # Show what is to the right of last slash, shows everything if no slash found
SCRIPTPATH=${0%/*}  # Full or relative path of script, OR just the script name was used (script is in $PATH)

if [ $SCRIPTNAME = $SCRIPTPATH ]; then
  SCRIPTPATH=""
  SCRIPTPATH=`which $SCRIPTNAME`    # gives full path and script name
  if [ $? != 0 ]; then  ## which command is not in PATH
    echo "`date +'%m/%d/%Y %X'` Startup ERROR! $TASK Can not use \"which\" command in script ($0)"
    return 1
  fi
  SCRIPTPATH=${SCRIPTPATH%/*}   # remove last slash and script name
fi
#######################################################################################################################

########################################################################################################################
#####  Figure out where startup script is, supporting files and directories should be in the same location
#####  If pathname used in start up then that gives us our directory. If not, use which to figure which script is being run.

STARTING_DIR=`pwd`
cd ${SCRIPTPATH}  # Change to MYDIR so that any relative file names are found, as in *.par file
if [ $? != 0 ]; then 
  echo "`date +'%m/%d/%Y %X'` ERROR! $TASK Can not access directory holding script ($SCRIPTNAME)"
  echo "`date +'%m/%d/%Y %X'` ERROR! $TASK Dirname=$SCRIPTPATH"
  echo "`date +'%m/%d/%Y %X'` ERROR! $TASK Do not preceed command with a dot space."  #4/16/2008
  return 1
fi
MYDIR=`pwd`  # This ensures full path is used in MYDIR var
if [ ! -d $MYDIR ]; then   ## Should never happen
  echo "`date +'%m/%d/%Y %X'` $TASK ERROR! Problem accessing Import Directory ($MYDIR)."
  echo "`date +'%m/%d/%Y %X'` $TASK ERROR! Problem accessing Import Directory in this script ($SCRIPTNAME)."
  cd $STARTING_DIR >/dev/null
  return 1
fi
#######################################################################################################################

#######################################################################################################################
# Get env vars.  Keep this setting below MYDIR logic, in case PATH changes where it no longer includes this script
if [ x$DAYBREAK_ENV_VARS != x ]; then
  ENV_VARS=$DAYBREAK_ENV_VARS
else 
  ENV_VARS=$MYDIR/setenv_daybreak.sh
fi
if [ -r $ENV_VARS ]; then
  . $ENV_VARS
fi
########################################################################################################################


##############################################################################################################
#### Env Vars could be set prior to this script
if [ x$TERM = x ]; then
  export TERM=vt100
fi
ERROR_FLAG="All Okay"
############################################################################################################################

##############################################################################################################
###  Validate LOG file
if [ x$DAYBREAK_LOG = x ]; then
  checklogfile $MYDIR/daybreak.log
  RESULT=$?
  if [ $RESULT != 0 ]; then
    return $RESULT
  fi
else 
  checklogfile $DAYBREAK_LOG
  RESULT=$?
  if [ $RESULT != 0 ]; then
    return $RESULT
  fi
fi

############################################################################################################################
# Get the data directory that holds the data files needing to be sent

if [ x$DAYBREAK_SRC_DIR = x ]; then   ### Default the Data Directory
  DAYBREAK_SRC_DIR=$MYDIR
fi

### Validate Data Directory is given 
if [ ! -d $DAYBREAK_SRC_DIR -o ! -r $DAYBREAK_SRC_DIR -o ! -w $DAYBREAK_SRC_DIR ]; then
  echo "`date +'%m/%d/%Y %X'` $TASK Startup ERROR! Invalid source directory."|tee -a $LOGFILE
  echo "`date +'%m/%d/%Y %X'` $TASK Startup ERROR! \$DAYBREAK_SRC_DIR=$DAYBREAK_SRC_DIR."|tee -a $LOGFILE
  ERROR_FLAG=ERROR
fi
############################################################################################################################

############################################################################################################################
# Get the data directory that holds the Process files

if [ x$DAYBREAK_PROC_DIR = x ]; then   ### Default the Data Directory
  DAYBREAK_PROC_DIR=$MYDIR/PROCESS
fi
if [ ! -d $DAYBREAK_PROC_DIR ]; then
  echo "`date +'%m/%d/%Y %X'` $TASK Create Process directory: $DAYBREAK_PROC_DIR."|tee -a $LOGFILE
  mkdir -p $DAYBREAK_PROC_DIR 2>/dev/null
fi
### Validate Data Directory is given 
if [ ! -d $DAYBREAK_PROC_DIR -o ! -r $DAYBREAK_PROC_DIR -o ! -w $DAYBREAK_PROC_DIR ]; then
  echo "`date +'%m/%d/%Y %X'` $TASK Startup ERROR! Invalid process directory."|tee -a $LOGFILE
  echo "`date +'%m/%d/%Y %X'` $TASK Startup ERROR! \$DAYBREAK_PROC_DIR=$DAYBREAK_PROC_DIR."|tee -a $LOGFILE
  ERROR_FLAG=ERROR
fi
############################################################################################################################

############################################################################################################################
## Make sure the Old data directory exists.  Directory holds data files that have been processed
if [ x"${ERROR_FLAG}" != xERROR ]; then
  if [ x$DAYBREAK_SAVE = x ]; then
    DAYBREAK_SAVE=$DAYBREAK_SRC_DIR/SAVE
  else   # Old Data Directory already set
    if [ $DAYBREAK_SAVE = $MYDIR ]; then
      echo "`date +'%m/%d/%Y %X'` $TASK Startup ERROR! \$DAYBREAK_SAVE can not be the script's directory"|tee -a $LOGFILE
      ERROR_FLAG=ERROR
      return 1
    elif [ $DAYBREAK_SAVE = $DAYBREAK_SRC_DIR ]; then
      echo "`date +'%m/%d/%Y %X'` $TASK Startup ERROR! \$DAYBREAK_SAVE can not be same as \$DAYBREAK_SRC_DIR"|tee -a $LOGFILE
      ERROR_FLAG=ERROR
      return 1
    fi
  fi

  if [ ! -d $DAYBREAK_SAVE ]; then
    mkdir $DAYBREAK_SAVE 
    if [ ! -d $DAYBREAK_SAVE ]; then
      echo "`date +'%m/%d/%Y %X'` $TASK Startup ERROR! Could not create Save Data Directory"|tee -a $LOGFILE
      echo "`date +'%m/%d/%Y %X'` $TASK Startup ERROR! $DAYBREAK_SAVE"|tee -a $LOGFILE
      ERROR_FLAG=ERROR
    else
      echo "`date +'%m/%d/%Y %X'` $TASK Created Directory to hold Save Data."|tee -a $LOGFILE
      echo "`date +'%m/%d/%Y %X'` $TASK Created $DAYBREAK_SAVE"|tee -a $LOGFILE
      chmod 777 $DAYBREAK_SAVE 
    fi
  elif [ ! -w $DAYBREAK_SAVE ]; then
      echo "`date +'%m/%d/%Y %X'` $TASK Startup ERROR! Can not write to Save Data Directory"|tee -a $LOGFILE
      echo "`date +'%m/%d/%Y %X'` $TASK Startup ERROR! $DAYBREAK_SAVE"|tee -a $LOGFILE
      ERROR_FLAG=ERROR
  fi
fi
############################################################################################################################

############################################################################################################################
# Number of seconds between searching for files to process
if [ x$DAYBREAK_SLEEP_SECS = x ]; then
  DAYBREAK_SLEEP_SECS=0    # Default number of seconds between searching for files to process
elif [ x$DAYBREAK_SLEEP_SECS = xNone -o x$DAYBREAK_SLEEP_SECS = xNONE -o x$DAYBREAK_SLEEP_SECS = xnone ]; then
  DAYBREAK_SLEEP_SECS=0    # Default number of seconds between searching for files to process
else  # Validate number of sleep seconds
  test $DAYBREAK_SLEEP_SECS -ge 0 2>/dev/null
  if [ $? != 0 ]; then
    echo "`date +'%m/%d/%Y %X'` $TASK Startup ERROR! DAYBREAK_SLEEP_SECS = $DAYBREAK_SLEEP_SECS."|tee -a $LOGFILE
    ERROR_FLAG=ERROR
  fi
fi
############################################################################################################################

############################################################################################################################
if [ x$DAYBREAK_DEST_DIR = x ]; then
  DAYBREAK_DEST_DIR=$DAYBREAK_SRC_DIR
fi
### Validate Destination Directory
if [ ! -d $DAYBREAK_DEST_DIR -o ! -r $DAYBREAK_DEST_DIR -o ! -w $DAYBREAK_DEST_DIR ]; then
  echo "`date +'%m/%d/%Y %X'` $TASK Startup ERROR! Invalid destination directory."|tee -a $LOGFILE
  echo "`date +'%m/%d/%Y %X'` $TASK Startup ERROR! \$DAYBREAK_DEST_DIR=$DAYBREAK_DEST_DIR."|tee -a $LOGFILE
  ERROR_FLAG=ERROR
fi
############################################################################################################################

############################################################################################################################
# Default pattern for filename
if [ x$DAYBREAK_PATTERN = x ]; then
  DAYBREAK_PATTERN="^X[0-9]*.dat$"
fi
############################################################################################################################

############################################################################################################################
## Segment names should match flat file names
if [ "x$DAYBREAK_SEGMENTS" = x ]; then
  DAYBREAK_SEGMENTS="api_cusprim api_cusoth api_acd api_ase api_con"
fi
############################################################################################################################

############################################################################################################################
if [ "x$DAYBREAK_SHOW_TOTALS" = x ]; then
  DAYBREAK_SHOW_TOTALS=YES      # Total the number of lines and characters found for each segement
elif [ "x$DAYBREAK_SHOW_TOTALS" = xYES -o "x$DAYBREAK_SHOW_TOTALS" = xyes -o "x$DAYBREAK_SHOW_TOTALS" = xYes ]; then
  DAYBREAK_SHOW_TOTALS=YES      # Total the number of lines and characters found for each segement
else
  DAYBREAK_SHOW_TOTALS=NO       # Do NOT total the number of lines and characters found for each segement
fi
############################################################################################################################

############################################################################################################################
create_sed_file
############################################################################################################################

############################################################################################################################
if [ "${ERROR_FLAG}" = "ERROR" ]; then
  echo "`date +'%m/%d/%Y %X'` $TASK Process Stopped.\n"|tee -a $LOGFILE
  cd $STARTING_DIR >/dev/null
  return 1
fi

############################################################################################################################
for PROCESS_FILE in `ls $DAYBREAK_PROC_DIR/daybreak_process.*.pid 2>/dev/null`   # Presence of file shows script is running
do
  test_process
  RESULT=$?
  if [ $RESULT != 0 ]; then
    echo "`date +'%m/%d/%Y %X'` $TASK Process running. Will only start one process.  Use stop script before running start script.\n"|tee -a $LOGFILE
    return 0
  fi
done

create_proc_file

############################################################################################################################

############################################################################################################################
############################################################################################################################
###  Mainline

echo "`date +'%m/%d/%Y %X'` $TASK START.  Process ID $MY_PID. Command: $0 $*"|tee $LOGFILE
echo "`date +'%m/%d/%Y %X'` $TASK Start Dir: $STARTING_DIR" >> $LOGFILE
if [ "${MYDIR}" != "${STARTING_DIR}" ]; then
echo "`date +'%m/%d/%Y %X'` $TASK Script Dir: ${MYDIR}" >> $LOGFILE
fi
echo "`date +'%m/%d/%Y %X'` $TASK Selecting files named \"${DAYBREAK_PATTERN}\"" |tee -a $LOGFILE
echo "`date +'%m/%d/%Y %X'` $TASK Checking directory ${DAYBREAK_SRC_DIR}" |tee -a $LOGFILE
test $DAYBREAK_SLEEP_SECS -ge 0 2>/dev/null
if [ $? != 0 ]; then
echo "`date +'%m/%d/%Y %X'` $TASK Checking every ${DAYBREAK_SLEEP_SECS} seconds" |tee -a $LOGFILE
fi
echo "`date +'%m/%d/%Y %X'` $TASK Save input files to $DAYBREAK_SAVE" |tee -a $LOGFILE
echo "`date +'%m/%d/%Y %X'` $TASK Consolidate data into $DAYBREAK_DEST_DIR" |tee -a $LOGFILE
echo "`date +'%m/%d/%Y %X'` $TASK Processing segments: $DAYBREAK_SEGMENTS" |tee -a $LOGFILE
echo "`date +'%m/%d/%Y %X'` $TASK Logfile=$LOGFILE." |tee -a $LOGFILE

TimeStamp=`date +%Y%m%d.%H%M%S`  # Used in naming of Segment .dat files e.g. api_cusprim.20050902.141224.dat

cd ${DAYBREAK_SRC_DIR} >/dev/null

# LOOP for files needing to be consolidated  -Fitz
while [ -f $MYPROCFILE -a ! -f ${MYPROCFILE}.stop ]
do
  for SOURCE_FILE in `ls |grep "${DAYBREAK_PATTERN}" 2> /dev/null`
  do
    if [ ! -f $SOURCE_FILE ]; then
      continue  ## Another process grabbed it before we got to it
    elif [ ! -s $SOURCE_FILE ]; then
      continue  ## File is empty
    fi

    if [ ! -r $SOURCE_FILE ]; then
      echo "`date +'%m/%d/%Y %X'` $TASK Read access required for $SOURCE_FILE" |tee -a $LOGFILE
      continue
    fi

    ## Change extension if necessary
    if [ x$DAYBREAK_EXT != x ]; then
      DAYBREAK_FILE=${SOURCE_FILE%.*}.$DAYBREAK_EXT   ## Replace (or add) extension 
      mv -f $SOURCE_FILE $DAYBREAK_FILE   ## Change extension 
      if [ $? != 0 ]; then
	if [ -f $DAYBREAK_FILE ]; then
	  continue   # Another process got to this file first
	else
	  echo "`date +'%m/%d/%Y %X'` $TASK ERROR! mv -f $SOURCE_FILE $DAYBREAK_FILE" |tee -a $LOGFILE
	  echo "`date +'%m/%d/%Y %X'` $TASK ERROR! Can not rename file." |tee -a $LOGFILE
	  echo "`date +'%m/%d/%Y %X'` $TASK Process Stopped.\n"|tee -a $LOGFILE
	  stop_process $MY_PID
	  return 1
	fi
      fi
    else
      DAYBREAK_FILE=${SOURCE_FILE}
    fi

    ## Move Datafile so another process does not pick it up
    mv -f $DAYBREAK_FILE $DAYBREAK_SAVE/$DAYBREAK_FILE >> $LOGFILE 2>&1  ## Move it so another process does not pick it up
    if [ $? != 0 ]; then
      if [ -f $DAYBREAK_SAVE/$DAYBREAK_FILE ]; then
	continue   # Another process got to this file first
      else
	echo "`date +'%m/%d/%Y %X'` $TASK ERROR! mv -f $DAYBREAK_FILE $DAYBREAK_SAVE/$DAYBREAK_FILE" |tee -a $LOGFILE
	echo "`date +'%m/%d/%Y %X'` $TASK ERROR! Can not save file." |tee -a $LOGFILE
	echo "`date +'%m/%d/%Y %X'` $TASK Process Stopped.\n"|tee -a $LOGFILE
	stop_process $MY_PID
	return 1
      fi
    fi

    echo "`date +'%m/%d/%Y %X'` $TASK Processing $SOURCE_FILE.\c" >> $LOGFILE
    parse_command $DAYBREAK_SAVE/$DAYBREAK_FILE     ## move each data segment into it's own file
    if [ "$DAYBREAK_SHOW_TOTALS" = YES -a "$SEG_DATA_STATUS" = "Data Parsed" ]; then
      echo "  $SEG_DATA_STATUS: ${filelinetot} Lines, ${filechartot} Characters".  >> $LOGFILE
    else
      echo "  $SEG_DATA_STATUS" >> $LOGFILE
    fi

    if [ ! -f $MYPROCFILE -o -f ${MYPROCFILE}.stop ]; then
      stop_process $MY_PID
      break 2
    fi
    touch $MYPROCFILE

  done   # for SOURCE_FILE in `ls |grep "${DAYBREAK_PATTERN}" 2> /dev/null`

  remove_temp_files $MY_PID
  if [ ! -f $MYPROCFILE -o -f ${MYPROCFILE}.stop ]; then
    break 
  fi

  touch $MYPROCFILE

  if [ ${DAYBREAK_SLEEP_SECS} = 0 ]; then 
    break
  fi
  sleep ${DAYBREAK_SLEEP_SECS}
done # while [ -f $MYPROCFILE -a ! -f ${MYPROCFILE}.stop ]

if [ $DATA_FOUND = yes ]; then
  if [ "$DAYBREAK_SHOW_TOTALS" = YES ]; then
    echo "`date +'%m/%d/%Y %X'` $TASK Summarizing Process."|tee -a $LOGFILE
    SEGCNT=0
    for SEG in $DAYBREAK_SEGMENTS     ## Append temporary segment files onto main segment files
    do
      echo "`date +'%m/%d/%Y %X'` $TASK Built ${linetot[SEGCNT]} Lines, ${chartot[SEGCNT]} characters for $SEG." >> $LOGFILE
      let "SEGCNT = SEGCNT + 1" 
    done   # for SEG in $DAYBREAK_SEGMENTS     ## Append temporary segment files onto main segment files
  else
    echo "`date +'%m/%d/%Y %X'` $TASK Ending Process: Data was parsed."|tee -a $LOGFILE
  fi
else
  echo "`date +'%m/%d/%Y %X'` $TASK Ending Process: No data processed." >> $LOGFILE
fi

if [ ! -f $MYPROCFILE -o -f ${MYPROCFILE}.stop ]; then
  echo "`date +'%m/%d/%Y %X'` $TASK Process stopped normally." >> $LOGFILE
fi
stop_process $MY_PID

echo "`date +'%m/%d/%Y %X'` $TASK Process Complete (pid $MY_PID).\n"|tee -a $LOGFILE

cd $STARTING_DIR >/dev/null       # Return to original directory

# mailx -s "$TASK log" -r origenate@company.com sysamdin@company.com < $LOGFILE

return 0

