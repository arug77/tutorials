/*
 * withdrawApp.java
 *
 * Created on June 09, 2006
 *
 * @author Brad Snyder
 *
 * @version
 *
 * Searches for apps to withdraw according to configured criteria
 *
 * HISTORY 
 *
 * Chapel Dcunha	11/29/2011
 * Tkt 156616 - RBC CCIA: Added new source 'OLB'
 */

package com.cmsinc.origenate.tool;

import java.sql.*;

import com.cmsinc.origenate.util.DBConnection;
import com.cmsinc.origenate.util.LogMsg;
//import com.cmsinc.origenate.util.COLEncrypt;
import com.cmsinc.origenate.util.IniFile;
//import com.cmsinc.origenate.workflow.ApplicationStatusManager;
import com.cmsinc.origenate.workflow.WorkFlowManager;
import com.cmsinc.origenate.event.CommentEvents;
import com.cmsinc.origenate.event.JournalEvents;

public class withdrawApp {

	private java.sql.Connection con;
	private String sHost = "";
	private String sSIDname = "";
	private String sUser = "";
	private String sPass = "";
	private String sPort = "";
	private String sTNSEntry = "";
	private String sIniFile = "";
	private String evaluator = "";
	private IniFile ini = new IniFile();
	private LogMsg log = new LogMsg();
	private String log_file = "";
	private LogMsg log_obj = new LogMsg();

	// default constructor
	public withdrawApp() {
	}

	/** ************************************************************ */
	/* Main method to call withdraw app process */
	/** ************************************************************ */
	public static void main(String args[]) throws Exception {
		withdrawApp wa = new withdrawApp();

		wa.getArgs(args);

		wa.withdrawApplications();

		wa.closeConnection();
	}

	private void getArgs(String args[]) {
		if (args.length > 0) {
			for (int ix = 0; ix < args.length; ix++) {
				if ((args[ix].charAt(0) != '-') && (args[ix].length() > 1))
					showUsage();
				switch (args[ix].charAt(1)) {
				case 'i': // ini file
					sIniFile = args[ix].substring(2);
					try {
						//
						// Read host, user, sid and password from ini file
						//
						ini.readINIFile(sIniFile);

						sHost = ini.getINIVar("database.host", "");
						sPort = ini.getINIVar("database.port", "");
						sUser = ini.getINIVar("database.user", "");
						sPass = ini.getINIVar("database.password", "");
						sSIDname = ini.getINIVar("database.sid", "");
						sTNSEntry = ini.getINIVar("database.TNSEntry", "");

					} catch (Exception e) {
						log_obj.FmtAndLogMsg("Caught exception reading ini file '"+ sIniFile + "':" + e.toString());
					}
					break;
				case 'e': // evaluator
					evaluator = args[ix].substring(2);
					break;
				default:
					log_obj.FmtAndLogMsg("Unknown parameter: " + args[ix]);
					showUsage();
					break;
				}
			}

			// check for evaluator
			if (evaluator.length() == 0) {
				log_obj.FmtAndLogMsg("Evaluator not supplied");
				showUsage();
			}

			try {
			// open worflow log file
			log_file = ini.getINIVar("logs.workflow_log_file", "");
			log.openLogFile(log_file);
			}
			catch (Exception e) {
				log_obj.FmtAndLogMsg("Error creating logfile: "+log_file+".  "+ e.toString());
			}

			try {
				// open withdrawApp log file
				log_file = ini.getINIVar("logs.withdrawapp_log_file", "");
				log_obj.openLogFile(log_file);
			}
			catch (Exception e) {
				log_obj.FmtAndLogMsg("Error creating logfile: "+log_file+".  "+ e.toString());
			}

			if (((sHost.length() == 0) || (sUser.length() == 0) || (sSIDname.length() == 0) || (sPort.length() == 0)) && sTNSEntry.length() == 0) {
				log_obj.FmtAndLogMsg("Host,User,Pwd,SID or Port not specified in INI file");
				showUsage();
			}

			try {
				DBConnection DBConnect = new DBConnection();

				if (sTNSEntry.length() == 0) {
					con = DBConnect.getConnection(sHost, sSIDname, sUser, sPass, log_file, sPort,"");
				} else {
					// use tns entry if available
					con = DBConnect.getConnectionTNS(sTNSEntry, sUser,  sPass, log_file);
				}
			}
			catch (Exception e) {
				log_obj.FmtAndLogMsg("Error connecting to database: "+ e.toString());
			}
		} else
			showUsage();
	}

	private void showUsage() {
		System.out.println("");
		System.out.println("Usage: java withdrawApp -i<inifile> -e<evalID>");
		System.out.println("---------------------");
		System.out.println("-i - required: INI file to use for configuration");
		System.out.println("-e - required: evaluator ID");
		System.out.println("example: java withdrawApp -ic:/development/origenatebin/origenate.ini -e37");
		System.exit(1);
	}

	private void closeConnection() {
		try {
			if (con != null)
				con.close();
		}
		catch (SQLException e) {
		}
		con = null;
	}

	private void withdrawApplications() {
		PreparedStatement stmt = null;
		ResultSet rs = null;
		String sql;
		// get apps qualified for automatic withdrawal...assumes hrs and days will be integer values (not null)
		try {
		sql = "SELECT cr.request_id, cr.booking_status_id, cr.evaluator_id, decode(upper(cr.network_txt),'DEALERTRACK',1,'CUROMAX',1,'ROUTEONE',1,'DEALERACCESS',1,'CAPONE',1,'DTCANADA',1,'DTNCANADA',1,'CYENCE',1,'AP1',1,'ODE',1,'POWERBAND',1,'OLB',1,'TARGET',1,'CARMAX',1,'RASOR',1,'SANTANDER',1,'SNAP',1,'GGR',1,'PUBLIC',1,'AUTOCAPITAL',1,'FOURSQUARE',1,'DTNCANADA',1,0) as notify_flg, cr.client_app_id " +
				  "FROM config_withdrawal_application cwa, credit_request cr " +
                  "WHERE cwa.evaluator_id = ? " +
				  "AND cwa.evaluator_id = cr.evaluator_id " +
				  "AND cwa.status_id = cr.app_status_id " +
				  "AND cr.task_group_id in ('UNDERWRITING','CONTRACTADMIN','APPENTRY') " +
				  "AND cr.initiation_dt + cwa.withdrawal_eligible_days_num + (cwa.withdrawal_eligible_hours_num/24) < sysdate";
			stmt  = con.prepareStatement(sql);
			stmt.setInt(1, Integer.valueOf(evaluator));
			rs = stmt.executeQuery();

			log_obj.FmtAndLogMsg("Used selection query:  "+sql);

			WorkFlowManager wfm = new WorkFlowManager(con, log);
			JournalEvents je = new JournalEvents(con,log_file);
			CommentEvents ce = new CommentEvents(con,log);

			while (rs.next()) {
				log_obj.FmtAndLogMsg("withdrawing app: rid = "+rs.getString("request_id")+"; app number = "+rs.getString("client_app_id"));
				try {
	            	je.addJournal(rs.getInt("request_id"),22,"Application Withdrawn","SYSTEM");
	            }
	           	catch (Exception e) {
	           		log_obj.FmtAndLogMsg("Error:  exception creating journal event. "+e);
	            }

	            try {
	            	ce.addComment(rs.getInt("request_id"),41,"Application withdrawn","Missing Required Information","SYSTEM","",null);
	            }
	            catch (Exception e) {
	            	log_obj.FmtAndLogMsg("Error:  exception creating the comment. "+e);
	            }
				try {
					wfm.withdrawnApp(rs.getInt("request_id"),rs.getInt("evaluator_id"),"SYSTEM",rs.getInt("notify_flg"), "");
					wfm.cancelOutstandingTAFs(rs.getLong("request_id"), "SYSTEM");
				}
				catch (Exception e) {
					log_obj.FmtAndLogMsg("Error:  exception withdrawing app using workflowmanager. "+e);
	            }
			}

		}
		catch (Exception e) {
			log_obj.FmtAndLogMsg("Error: exception withdrawing apps.  "+e);
			try{if(rs !=null) rs.close();} catch(Exception ex) {ex.printStackTrace();}
		    try{if(stmt !=null) stmt.close();} catch(Exception ex) {ex.printStackTrace();} 
			System.exit(0);

	    }
		finally {
			try{if(rs !=null) rs.close();} catch(Exception ex) {ex.printStackTrace();}
		    try{if(stmt !=null) stmt.close();} catch(Exception ex) {ex.printStackTrace();} 
		}
	}
}