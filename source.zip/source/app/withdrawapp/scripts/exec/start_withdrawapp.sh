#!/bin/ksh

. ../../config/usrconfig.sh

java -classpath .:../lib/evidl.jar::../lib/common.jar:../lib/ojdbc6.jar com.cmsinc.origenate.tool.withdrawApp -i/opt

/jrun4/servers/$ENV/cfusion-ear/cfusion-war/config/origenate.ini -e$EVALUATOR
