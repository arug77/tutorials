/* Filename: ODEDealerExtract.java
 * Version: 
 * Creation Date: June 23, 2010
 * Author: Stevet
 * Copyright (c) 2002. All rights reserved
 * Description: Refer Clientele #152347
 * This program would generate a dealer data extract for AppOne
 * and save the data in a CSV format and ftp the file every night.
 */

package com.cmsinc.origenate.apponedealerextract;

import com.cmsinc.origenate.util.*;
import java.io.*;
import java.net.*;
import java.security.SecureRandom;
import java.security.cert.X509Certificate;
import java.sql.Date;
import java.sql.*;
import java.util.*;
import java.text.DecimalFormat;
import javax.net.ssl.*;
import com.cmsinc.origenate.util.OWASPSecurity;
import org.apache.commons.net.ftp.*;
import org.apache.commons.net.io.*;
import org.apache.commons.io.*;


public class AppOneDealerExtract {	
	private static LogMsg log = new LogMsg(); // log
	private static AppOneDealerExtract apo = new AppOneDealerExtract();
	private static String evaluator_id; // evaluator_id from commandline
	private static String destinationURL;
	private static String cleanupDays;	
	private static Connection con; // db settings
	private static String ftpServer; // ftp settings
	private static String ftpUser; // ftp settings
	private static String ftpPass; // ftp settings
	private static String ftpDecPass; // ftp Decrypted Password
	private static String ftpDir; // ftp settings
	private static String fileTransmission = "FTP"; //Preferred File Transmission Mech. FTP/HTTP
	private static boolean performFileDelete =false;	
	private static String input_filename; // input filename.
	private static String header_filename; // header filename
	private static String finance_src_name; // Finance Source Name
	private static String header_file_data; // header file content
	private static String localfile_path;
	private static String s_iniFile;
	//private static String header_filelocation;
	private static String input_filelocation;
	private static Vector v = new Vector(300,100); //Vector to hold dealer data extract fields 
	private static Vector cmdargs = new Vector(10,10);	//Vector to hold the command line args
	private static String transmissionOptional;
	private static boolean performFTP = true;  //whether FTP should be performed
	private static int recordCount; //number of records in CSV input file
	private PrintWriter dataFile = null;
	private static Character ch;
	private boolean append = true;
	private static String FTPorHTTP; //whether FTP or HTTP file 
	private static final int MAX_BUFFER_SIZE = 1 * 1024 * 1024;
	private static final String NEWLINE = "\r\n";
	private static final String TABSTOP = "\t";	
	private static final String FORM_BOUNDARY = "---------------------------7d2e2c76e104be";
	private static IniFile ini = new IniFile();

	/*
	 * Main method to call the getDBConnection method, getDataExtract method and
	 * retreive the command line parameters like evaluator id,
	 * ini file locn, file transmission mech.
	 */
	public static void main(String[] args) {

		String s_log_file = "";
		if (args.length > 0) {
			for (int i = 0; i < args.length; ++i) {	
				if ((args[i].charAt(0) != '-') && (args[i].length() > 1)) {				
					showUsageAndExit();
				}
				ch = Character.valueOf(args[i].charAt(1));
				cmdargs.add(ch);
				switch (args[i].charAt(1)) {
				case 'i':
					s_iniFile = args[i].substring(2); // ini file						
					try {							
						ini.readINIFile(s_iniFile);
						s_log_file = ini.getINIVar("logs.apponedealer_extract_log_file", "");
						if (s_log_file.length() > 0) {				
							log.openLogFile(s_log_file);						
						}
					} catch (Exception e) {
						log.FmtAndLogMsg("Caught exception reading ini file '" + s_iniFile + "':" + e.toString(), e);
					}
					log.FmtAndLogMsg("\r");
					log.FmtAndLogMsg("******* Starting AppOne Exchange Extract Tool ********");
					log.FmtAndLogMsg("\r");
					log.FmtAndLogMsg("iniFile name: " + s_iniFile);
					break;
				case 'e':
					evaluator_id = args[i].substring(2); // evaluator id
					log.FmtAndLogMsg("evaluator id : " + evaluator_id);
					break;
				case 'l':
					localfile_path = args[i].substring(2); // location of input
															// and header files
															// on local machine
					log.FmtAndLogMsg("local location of the input & header files: " + localfile_path);
					break;
				case 'd':
					ftpDir = args[i].substring(2); // directory location on ftp
													// server where file needs
													// to be sent
					log.FmtAndLogMsg("ftp server directory: " + ftpDir);
					break;
				case 'f':
					fileTransmission = args[i].substring(2); // file
																// transmission
																// method
					log.FmtAndLogMsg("file transmission method: " + fileTransmission);
					break;
				case 'u':
					destinationURL = args[i].substring(2); // web server URL
					log.FmtAndLogMsg("web server URL: " + destinationURL);
					break;
				case 'n':
					cleanupDays = args[i].substring(2);
					log.FmtAndLogMsg("Number of days to keep the files: " + cleanupDays);
					break;					
				case 't':
					transmissionOptional = args[i].substring(2);
					log.FmtAndLogMsg("Do you want to transmit the file electronically: " + transmissionOptional);
					break;
				default:
					log.FmtAndLogMsg("Unknown parameter: " + args[i]);
					showUsageAndExit();
					break;
				}
			}
		}
		
		 /* Check if the required command line args are present*/
		try {
			log.FmtAndLogMsg("Calling checkCmdLineArgs Method");
			checkCmdLineArgs();
		} catch (Exception e) {
			log.FmtAndLogMsg("Error in checkCmdLineArgs method of : " + e.toString(), e);
		}
		log.FmtAndLogMsg("checkCmdLineArgs Method Completed");

		if(transmissionOptional.equalsIgnoreCase("no")) {
			performFTP = false;
			performFileDelete = true;
		}
			
		if (fileTransmission.equalsIgnoreCase("FTP"))
			FTPorHTTP = "FTP";
		else if (fileTransmission.equalsIgnoreCase("HTTP"))
			FTPorHTTP = "HTTP";
		else if (fileTransmission.equals("HTTPS"))
			FTPorHTTP = "HTTPS";
		
		log.FmtAndLogMsg("File Transmission : " + FTPorHTTP);

		try {
			log.FmtAndLogMsg("Calling getDBConnection Method");
			getDBConnection(s_log_file);
		} catch (Exception e) {
			log.FmtAndLogMsg("Error in getDBConnection method of : " + e.toString(), e);
		}
		log.FmtAndLogMsg("getDBConnection Method Completed");
		try {
			if(fileTransmission.equals("FTP") && performFTP) {
				log.FmtAndLogMsg("Calling getFTPSettings Method");
				getFTPSettings(evaluator_id);
			}
		} catch (Exception e) {
			log.FmtAndLogMsg("Error in getFTPSettings method of : " + e.toString(), e);
		}
		if(fileTransmission.equals("FTP") && performFTP)
			log.FmtAndLogMsg("getFTPSettings Method Completed");

		log.FmtAndLogMsg("Calling getFileName Method");
		input_filename = getFileName("Input");
		header_filename = getFileName("Header");
		log.FmtAndLogMsg("getFileName Method Completed");		
		
		
		try {
			log.FmtAndLogMsg("Calling getDataExtract Method");
			getDataExtract(evaluator_id);
		} catch (Exception e) {
			log.FmtAndLogMsg("Error in getDataExtract method of : " + e.toString(), e);
		}
		log.FmtAndLogMsg("getDataExtract Method Completed");
		log.FmtAndLogMsg("********AppOne Exchange Tool Completed********");
	}

	/*
	 * Method to inform that expected values are missing on the command line.
	 */

	public static void showUsageAndExit() {
		System.out
		.println("Usage: java com.cmsinc.origenate.apponedealerextract.AppOneDealerExtract");
		System.out
		.println("-e<evaluator id> -i<ini file> -f<file transmission> -u<web server url> -l<localfile location> -d<ftp directory> -n<Cleanup Days> -t<Transmission Optional>");
		System.out
				.println("------------------------------------------------------------------------------");
		System.out.println("Parameter	Data Type	Required/Optional			Description");
		System.out.println("  -e 		 Integer		Required		Evaluator ID");
		System.out.println("  -i 		 String			Required		ini file name including the location");
		System.out.println("  -f 		 String			Optional		File Transmission Mechanism FTP/HTTP(S) FTP-Default");		
		System.out.println("  -u		 String 		Optional		Web Server URL if HTTP(S) method used");
		System.out.println("  -l		 String 		Required		location of input and header file on local machine");
		System.out.println("  -d		 String			Optional		FTP Directory to which the file needs to be FTP'ed");
		System.out.println("  -n 		 Integer		Required		Number of days to keep the files in local directory");		
		System.out.println("  -t 		 String			Required		Do you want to electronically transmit the file or not; Yes/No");
		System.exit(0);
	}

	
	/*
	 * Method to report an error in a method. Mainly used in the getDataExtract
	 * method to report missing field values in the extract for required fields.
	 */

	public static void recordError(String methodName, Exception err)
			throws Exception {
		try {
			log.FmtAndLogMsg("Error occured in " + methodName + " method of : "	+ err.toString(), err);
			throw new Exception("    Error occured in " + methodName + " method of : " + err.toString(), err);
		} catch (Exception e) {
			log.FmtAndLogMsg("Error in reportError method of : " + e.toString(), e);
		}

	}

	/*checks if the command line args are present*/
	
	public static void checkCmdLineArgs() {
		if(cmdargs.contains(Character.valueOf('i')) && cmdargs.contains(Character.valueOf('l')) && 
		   cmdargs.contains(Character.valueOf('e')) && cmdargs.contains(Character.valueOf('t'))) {
			log.FmtAndLogMsg("Required Command Line Parameters Present");
		}
		else {
			log.FmtAndLogMsg("Required Command Line Parameters Missing");
			log.FmtAndLogMsg("Calling showUsageAndExit() method to exit");
			showUsageAndExit();
		}
	}

	
	
	/*get DB connection*/

	public static void getDBConnection(String s_log_file) throws Exception {

		try {
			// Get ini file values for DB connection

			String s_dbhost = ini.getINIVar("database.host").trim();
			log.FmtAndLogMsg("dbHost : " + s_dbhost);

			String s_dbport = ini.getINIVar("database.port").trim();
			log.FmtAndLogMsg("dbPort : " + s_dbport);

			String s_dbsid = ini.getINIVar("database.sid").trim();
			log.FmtAndLogMsg("dbSID : " + s_dbsid);

			String s_dbuser = ini.getINIVar("database.user").trim();
			log.FmtAndLogMsg("dbUser : " + s_dbuser);

			String s_dbpassword = ini.getINIVar("database.password").trim();
			
			String sTNSEntry = ini.getINIVar("database.TNSEntry");
			log.FmtAndLogMsg("TNSEntry : " + sTNSEntry);
			
			
			DBConnection DBConnect = new DBConnection();
			
			if (sTNSEntry == null) {
				con = DBConnect.getConnection(s_dbhost, s_dbsid, s_dbuser, s_dbpassword, s_log_file, s_dbport,"");
			} else {
				// use tns entry if available
				con = DBConnect.getConnectionTNS(sTNSEntry, s_dbuser,  s_dbpassword, s_log_file);
			}
		} catch (Exception e) {
			recordError("    getDBConnection", e);
		}
	} // end getDBConnection method

	/*
	 * Method to obtain the ftp settings for FTP file transmission
	 */

	public static void getFTPSettings(String evaluator_id) throws Exception {
		PreparedStatement ps = null;
		ResultSet rs = null;
		String sql = "";

		try {

			/* Select ftp settings from the evaluator table */
			if (!evaluator_id.isEmpty()) {

				sql = " SELECT APPONE_SERVERNAME_TXT,APPONE_USERID_TXT,APPONE_PSSWD_TXT"
						+ " FROM EVALUATOR" + " WHERE EVALUATOR_ID = ? "; // Preparing
																			// sql
																			// statement

				ps = con.prepareStatement(sql); // Prepare statement to execute

				ps.setInt(1, Integer.parseInt(evaluator_id)); // Set param
																// values
				rs = ps.executeQuery(); // Execute statement

				// Get value of ftp server,ftp userid and password.
				while (rs.next()) {
					ftpServer = rs.getString("APPONE_SERVERNAME_TXT"); // FTP
																			// server
																			// name
					log.FmtAndLogMsg("ftpServer : " + ftpServer);
					ftpUser = rs.getString("APPONE_USERID_TXT"); // FTP
																	// userid
					log.FmtAndLogMsg("ftpUser : " + ftpUser);
					ftpPass = rs.getString("APPONE_PSSWD_TXT"); // FTP
					log.FmtAndLogMsg("Calling getDecryptedPassword Method********");// password
					ftpPass = getDecryptedPassword(ftpPass);
					log.FmtAndLogMsg("getDecryptedPassword Method Completed********");
				}
			}
			if (ftpServer == null || ftpUser == null || ftpPass == null) {
				log.FmtAndLogMsg("FTP Information Missing; The file would not be FTPed");
			}
		} catch (Exception e) {
			recordError("getFTPSettings", e);
		} finally {
			try {
				if (ps != null)
					ps.close();
				if (rs != null)
					rs.close();
			} catch (Exception e) {
				recordError("getFTPSettings", e);
			}
		} // end finally

	} // end getFTPSettings method.

	/*
	 * Method to decrypt the ftp password for FTP file transmission
	 */
	
	public static String getDecryptedPassword(String password) throws Exception {
		PreparedStatement ps = null;
		ResultSet rs = null;
		String sql = "";
		COLEncrypt col = new COLEncrypt();

		try {

			/* Select ftp settings from the evaluator table */
			if (!password.isEmpty()) {
			  if(col.getEncryption_Flg().equals("1"))  { 
				// Pwd Encryption -  
					ftpDecPass = COLEncrypt.sCfgPwdDecrypt(password);
				
				System.out.println("password :  "+ password);
				} else { 
				sql = " SELECT encrypt(?,'D') as e_psswd FROM dual "; // Preparing sql statement

				ps = con.prepareStatement(sql); // Prepare statement to execute
				ps.setString(1, password);

				rs = ps.executeQuery(); // Execute statement
				while (rs.next()) {
					ftpDecPass = rs.getString("e_psswd").trim(); // FTP
					log.FmtAndLogMsg("FTP Password Decrypted Successfully");
				}
			  }				
			}
			else {
				log.FmtAndLogMsg("FTP Server Password not present in database");
			}
		}	
		catch (Exception e) {
					recordError("getDecryptedPassword", e);
				} finally {
					try {
						if (ps != null)
							ps.close();
						if (rs != null)
							rs.close();
					} catch (Exception e) {
						recordError("getDecryptedPassword", e);
					}
				} // end finally
				return ftpDecPass;
	}

	/*
	 * Method to create the dealer data extract and calling 
	 * getHeaderFileData and ftpfile methods and creating a
	 * CSV file of the data extract.
	 */

	public static void getDataExtract(String evaluator_id) throws Exception {

		PreparedStatement ps = null;
		ResultSet rs = null;
		String sql = "";
		// declaring variables to hold the values of the data extract fields.
		String s_dealer_ac_no = "";
		String s_dealer2_ac_no = "";
		String s_dealer_legal_name = "";
		String s_dba_name = "";
		String s_physical_addr_line1 = "";
		String s_physical_addr_line2 = "";
		String s_city = "";
		String s_state = "";
		String s_status = "";
		String s_contact_name = "";
		String s_brand_name = "";
		String s_fax_num = "";
		String s_dealer_tax_id = "";
		String s_contact_phone_num = "";
		String s_phone_num = "";
		String s_zipcode = "";
		String s_tax_id = "";
		String s_location = "";
		String s_program = "";
		String s_cosindicator = "";
		String s_mktgroupid = "";
		String s_servorigcode = "";
		
		String newline = System.getProperty("line.separator");
		
		int i_status_flg;
		recordCount = 0;

		apo.openCSVFile(input_filename);
		try {

			/*
			 * Select dealer extract from evaluator_originator and
			 * originator_address db tables.
			 */
			
			sql = " SELECT DISTINCT eo.originator_code_txt, "
			+ "                     eo.originator_name_txt, "
			+ "                     nvl(eo.dba_name_txt, eo.originator_name_txt) dba_name_txt,"
			+ "                     oa.address1_txt, "
			+ "                     oa.address2_txt, "
			+ "                     oa.city_txt, "
			+ "                     oa.state_id, "
			+ "                     oa.zipcode_txt,"
			+ "                     oa.phone_number_txt, "
			+ "                     eo.active_flg, "
			+ "                     eo.contact_txt, "
			+ "                     xeoc.comm_type_number_txt as fax_number_txt, "
			+ "                     eo.tax_id,"
			+ "                     eo.evaluator_id, "
			+ "                     e.evaluator_name_txt,"
			+ "                     cxos.source_id"
			+ " FROM    EVALUATOR_ORIGINATOR eo, ORIGINATOR_ADDRESS oa,XREF_EVAL_ORIG_PRODUCT xeop, config_xref_originator_source  cxos, evaluator e, config_sources cs, xref_eval_orig_comm_type xeoc"
			+ " WHERE   eo.evaluator_id  =  ?"
			+ " AND     eo.evaluator_id  =  oa.EVALUATOR_ID(+) "
			+ " AND     eo.ORIGINATOR_ID =  oa.ORIGINATOR_ID(+) "
			+ " AND 	 eo.evaluator_id  =  xeop.evaluator_id "
			+ " AND	 eo.ORIGINATOR_ID =	 xeop.ORIGINATOR_ID "
			+ " AND	 eo.evaluator_id = e.evaluator_id "
			+ " AND     oa.ADDRESS_TYPE_ID = 0 "
			+ " AND 	 eo.ORIGINATOR_TYPE_ID=1 " 
			+ " AND 	 xeop.product_id IN (1,3) "
			+ " AND     cs.source_id = cxos.source_id "			
			+ " AND     eo.active_flg = 1 "
			+ " AND     eo.evaluator_id = cxos.evaluator_id "
			+ " AND     eo.originator_id = cxos.originator_id " 
			+ " AND     cxos.active_flg = 1 "
			+ " AND     cs.evaluator_id = eo.evaluator_id "
			+ " AND     cs.active_flg = 1 "
			+ " AND    UPPER(cs.source_desc_txt) = 'AP1' "
			+ "	AND xeoc.evaluator_id (+) = oa.evaluator_id "
			+ "	AND xeoc.originator_id (+) = oa.originator_id "
			+ "	AND xeoc.address_type_id (+) = oa.address_type_id "
			+ "	AND xeoc.comm_type_id (+) = 1 "
			+ "	AND xeoc.comm_id (+) = 1 "
			+ " ORDER BY eo.evaluator_id, originator_code_txt";
			
			ps = con.prepareStatement(sql); // Prepare statement to execute

			ps.setString(1, evaluator_id); // Set param values
		
			rs = ps.executeQuery(); // Execute statement

			log.FmtAndLogMsg("Processing ... ");
			
			while (rs.next()) {
				
				recordCount++;
				//Source Name
				finance_src_name = rs.getString("evaluator_name_txt");
				
				// Lender Dealer Number
				s_dealer_ac_no = rs.getString("originator_code_txt");
				log.FmtAndLogMsg(" Dealer " + s_dealer_ac_no);
				if (s_dealer_ac_no == null) {
					log.FmtAndLogMsg(" Required: Originator code value not present in the database");
					s_dealer_ac_no = surroundWithQuotes("");					
					performFTP = false;
				} else {
					s_dealer2_ac_no = s_dealer_ac_no;			
					s_dealer_ac_no = surroundWithQuotes(s_dealer_ac_no.trim());
				}
				v.add(s_dealer_ac_no);
				
				// Dealer Name
				s_dealer_legal_name = rs.getString("originator_name_txt");
				if (s_dealer_legal_name == null) {
					log.FmtAndLogMsg(" Required: Dealer Legal Name value not present in the database");
					s_dealer_legal_name = surroundWithQuotes("");
					performFTP = false;
				} else {
					s_dealer_legal_name = surroundWithQuotes(s_dealer_legal_name.trim());
				}
				v.add(s_dealer_legal_name);
				
				// Dealer DBA Name
				s_dba_name = rs.getString("dba_name_txt");
				if (s_dba_name == null) {
					s_dba_name = surroundWithQuotes("");
				} else {
					s_dba_name = surroundWithQuotes(s_dba_name.trim());
				}
				v.add(s_dba_name);
				
				// Dealer Street Address Line1
				s_physical_addr_line1 = rs.getString("address1_txt");
				if (s_physical_addr_line1 == null) {
					log.FmtAndLogMsg(" Required: Physical Address Line1 value not present in the database");
					s_physical_addr_line1 = surroundWithQuotes("");
					performFTP = false;
				} else {
					s_physical_addr_line1 = surroundWithQuotes(s_physical_addr_line1.trim());
				}
				v.add(s_physical_addr_line1);
				
				// Dealer Street Address Line2
				s_physical_addr_line2 = rs.getString("address2_txt");
				if (s_physical_addr_line2 == null) {
					s_physical_addr_line2 = surroundWithQuotes("");
				} else {
					s_physical_addr_line2 = surroundWithQuotes(s_physical_addr_line2);
				}
				v.add(s_physical_addr_line2);
				
				// Dealer City
				s_city = rs.getString("city_txt");
				if (s_city == null) {
					log.FmtAndLogMsg(" Required: City value not present in the database");
					s_city = surroundWithQuotes("");
					performFTP = false;
				} else {
					s_city = surroundWithQuotes(s_city.trim());
				}
				v.add(s_city);
				
				// Dealer State
				s_state = rs.getString("state_id");
				if (s_state == null) {
					log.FmtAndLogMsg(" Required: State value not present in the database");
					s_state = surroundWithQuotes("");
					performFTP = false;
				} else {
					s_state = surroundWithQuotes(s_state.trim());
				}
				v.add(s_state);
				
				// Dealer ZipCode
				s_zipcode = rs.getString("zipcode_txt");
				if (s_zipcode == null) {
					log.FmtAndLogMsg(" Required: Zipcode value not present in the database");
					s_zipcode = surroundWithQuotes("");
					performFTP = false;
				} else {
					s_zipcode = surroundWithQuotes(s_zipcode.trim());
				}
				v.add(s_zipcode);
				
				// Dealer Phone Number
				s_phone_num = rs.getString("phone_number_txt");
				if (s_phone_num == null) {
					log.FmtAndLogMsg(" Required: Phone Number value not present in the database");
					s_phone_num = surroundWithQuotes("");
					performFTP = false;
				} else {
					s_phone_num = surroundWithQuotes(s_phone_num.trim());
				}
				v.add(s_phone_num);

				// Dealer Contact Name
				s_contact_name = rs.getString("contact_txt");
				if (s_contact_name == null) {
					log.FmtAndLogMsg(" Required: Contact value not present in the database");					
					s_contact_name = surroundWithQuotes("");
					performFTP = false;
				} else {
					s_contact_name = surroundWithQuotes(s_contact_name);
				}
				v.add(s_contact_name);
				
				// Dealer Contact Phone Number (this is originator number since we dont store a contact phone)
				s_contact_phone_num = rs.getString("phone_number_txt");
				if (s_contact_phone_num == null) {
					s_contact_phone_num = surroundWithQuotes("");
				} else {
					s_contact_phone_num = surroundWithQuotes(s_contact_phone_num);
				}
				v.add(s_contact_phone_num);

				// Dealer Fax Number
				s_fax_num = rs.getString("fax_number_txt");
				if (s_fax_num == null) {
					log.FmtAndLogMsg(" Required: Fax Number value not present in the database");
					s_fax_num = surroundWithQuotes("");
					performFTP = false;
				} else {
					s_fax_num = surroundWithQuotes(s_fax_num.trim());
				}
				v.add(s_fax_num);
				
				// Dealer Tax ID
				s_fax_num = rs.getString("tax_id");
				if (s_fax_num == null) {
					s_tax_id = surroundWithQuotes("");
				} else {
					s_fax_num = surroundWithQuotes(s_tax_id.trim());
				}
				v.add(s_tax_id);
				
				// Unknown field mappings.  Send null for now giving they are not required.
				s_program = surroundWithQuotes("");
				v.add(s_program);
				s_cosindicator = surroundWithQuotes("");
				v.add(s_cosindicator);				
				s_mktgroupid = surroundWithQuotes("");
				v.add(s_mktgroupid);				
				s_servorigcode = surroundWithQuotes("");
				v.add(s_servorigcode);				

				v.add(newline);
				
			} // end loop database records.
			
				
			ListIterator iter = v.listIterator();
			while (iter.hasNext()) {					
				apo.writeDataExtract((String)iter.next());
			}
			
			apo.closeCSVFile();
						
		
			log.FmtAndLogMsg("Input File Creation Completed Successfully");
			log.FmtAndLogMsg("Calling getHeaderFileData Method");
			header_file_data = getHeaderFileData(recordCount, finance_src_name);
			log.FmtAndLogMsg("getHeaderFileData Method Completed");
			log.FmtAndLogMsg("Calling openCSVFile Method for Header File");
			apo.openCSVFile(header_filename);
			log.FmtAndLogMsg("Calling writeDataExtract Method for Header File");
			apo.writeDataExtract(header_file_data);
			apo.writeDataExtract(newline);
			log.FmtAndLogMsg("Calling closeCSVFile Method for Header File");
			apo.closeCSVFile();
			log.FmtAndLogMsg("Header File Creation Completed Successfully");			
			
			//log.FmtAndLogMsg(" Calling getFileName Method");
			//input_filename = getFileName("Input", recordCount);
			//header_filename = getFileName("Header", recordCount);
			//log.FmtAndLogMsg(" getFileName Method Completed");

			apo.openCSVFile(input_filename);
				

			input_filelocation = localfile_path.concat(input_filename);
			log.FmtAndLogMsg(" input_filelocation : " + input_filelocation);
				
			if (FTPorHTTP.equals("FTP") && performFTP) {
				log.FmtAndLogMsg(" Calling FTPFile Method");
				apo.ftpFile(input_filelocation, "Input");
			} else if (FTPorHTTP.equals("HTTP")) {
				apo.httpFile(input_filelocation);
			} else if (FTPorHTTP.equals("HTTPS")) {
				apo.httpsFile(input_filelocation);	
			}				
				

			if (performFileDelete == true) {
				log.FmtAndLogMsg("Calling Cleanup Files Method");
				cleanupFiles();
				log.FmtAndLogMsg("Cleanup Files Method Completed");
			}			
				
		} catch (Exception e) {
			recordError("getDataExtract", e);
		} finally {
			try {
				if (ps != null)
					ps.close();
				if (rs != null)
					rs.close();
			} catch (Exception e) {
				recordError("getDataExtract", e);
			} // end catch
		} // end finally
				
	} // end getDataExtract method


	/*
	 * method to ftp the file. Method taken from ConcatLetters Program author:
	 * Chuck Caplan
	 */

	public void ftpFile(String fileName, String fileType) throws IOException {
		if (performFTP == true && ftpPass != null
				&& ftpServer != null && ftpUser != null
				&& !ftpUser.trim().equals("")
				&& !ftpPass.trim().equals("") && !ftpServer.trim().equals("")) {
			File F = new File(fileName);
			FTPClient ftp = new FTPClient();
			ftp.connect(ftpServer, 21);
			//FTPClient ftp = FTPClient.create(ftpServer);
			ftp.login(ftpUser, ftpPass);
			log.FmtAndLogMsg("Logged into FTP server " + ftpServer);
			log.FmtAndLogMsg("Welcome Msg - " + ftp.getReplyString());
			if(ftpDir != null && !ftpDir.trim().equals("")) {
				ftp.changeWorkingDirectory(ftpDir);
			}
			log.FmtAndLogMsg("Setting Binary Mode");
			// ftp.ascii();
			ftp.setFileType(FTP.BINARY_FILE_TYPE);
			ftp.setFileTransferMode(FTP.BINARY_FILE_TYPE);
			log.FmtAndLogMsg("Uploading " + fileType + " File");
		//	OutputStream os = ftp.putFileStream(getFileNameFromPath(fileName));
		//	BufferedOutputStream bos = new BufferedOutputStream(os);
			ByteArrayInputStream bais; 
			
			
			/**		
	         * OWASP TOP 10 2010 - A4 Path Manipulation
		     * Changes to the below code to fix vulnerabilities
		     * TTP 324955
		     **/
	        //FileInputStream is = new FileInputStream(fileName);
	        FileInputStream is = null;
	        try{
	        	OWASPSecurity.validationCheck(fileName, OWASPSecurity.DIRANDFILE);
	       // 	is = new FileInputStream(OWASPSecurity.validationCheck(fileName, OWASPSecurity.DIRANDFILE));
	        }
	        catch (Exception e) {
				System.out.println("Exception: " + e);
			}
	        bais = new ByteArrayInputStream(FileUtils.readFileToByteArray(F));
	        ftp.storeFile(fileName, bais); 
	//		BufferedInputStream bis = new BufferedInputStream(is);
	//		byte[] buffer = new byte[1024];
	///		int readCount;
	//		while ((readCount = bis.read(buffer)) > 0) {
	//			bos.write(buffer, 0, readCount);
	//		}

	//		bos.close();
	//		bis.close();
	//		os.close();
	//		is.close();
	        bais.close();
	       
			log.FmtAndLogMsg("Finished Uploading " + fileType + " File");
			ftp.logout();
		    ftp.disconnect();
			ftp = null;
			log.FmtAndLogMsg("Finished FTPing " + fileType + " file");
			performFileDelete = true;
		} // end if
		else {
			performFileDelete = false;
			log.FmtAndLogMsg("Error FTPing " + fileType + " File");
			log.FmtAndLogMsg("One of the required FTP Parameters were missing");
		}
	} // end ftpFile method

	/** *************************************** */
	public void httpFile(String fileName) throws IOException {
		// Read dealer extract file
		String extractFileStr = "";
		String response = "";
		BufferedInputStream fis = null;
		try {

			/**		
	         * OWASP TOP 10 2010 - A4 Path Manipulation
		     * Changes to the below code to fix vulnerabilities
		     * TTP 324955
		     **/         
	        //File f = new File(fileName);
			File f = new File(OWASPSecurity.validationCheck(fileName, OWASPSecurity.DIRANDFILE));
			
			byte[] buffer = new byte[(int) f.length()];
			fis = new BufferedInputStream(new FileInputStream(f));
			int i = 0;
			int b = fis.read();

			while (b != -1) {
				buffer[i++] = (byte) b;
				b = fis.read();
			}

			extractFileStr = new String(buffer);

		} catch (Exception e) {
			System.out.println("Exception: " + e);
			System.exit(0);
		} finally {

			if (fis != null) {
				try {
					fis.close();
				} catch (IOException ioe) {
					// do nothing
				}
			}

		}

		// Post dealer extract file
		try {
			PostRequest postRequest = new PostRequest();
			postRequest.setHeaderProperty("Content-Type",
					"multipart/form-data; boundary=" + FORM_BOUNDARY);
			postRequest.setHeaderProperty("Cookie", "SMCHALLENGE=YES");
			response = postRequest.post(destinationURL, extractFileStr, 0);
		} catch (Exception e) {
			System.out.println("Exception: " + e);
			e.printStackTrace(System.out);
			System.exit(0);
		}

		System.out.println("Response: " + response);

	}

	/** **************************************** */
	/*
	 * Method to get the filenames for the header and input data extract file
	 */

	public static String getFileName(String filetype) {

		Calendar cal = new GregorianCalendar(); // create a Calendar object
		String year = ""; // year
		String month = ""; // month
		String day = ""; // day
		String date = "";
		String s_filetype = filetype; // file type : input or header file
		String filename = "";
		String transFormat = new DecimalFormat("000000").format(recordCount);
		String fname="dealerfile";

		try {

			// get date to append to the filename.
			year = (Integer.toString(cal.get(Calendar.YEAR))).trim(); // 2002
			month = (Integer.toString((cal.get(Calendar.MONTH)) + 1))
					.trim(); // 0=Jan, 1=Feb, ...
			if (month.length() < 2) {
				month = "0".concat(month);
			}
			day = (Integer.toString(cal.get(Calendar.DAY_OF_MONTH))).trim(); // 1...
			if (day.length() < 2) {
				day = "0".concat(day);
			}
			date = year + day + month;


			/*
			 * CSV Input file Format: dealerfile_Date_input.tab
			 * Header file Format: dealerfile_Date_header.tab
			 */

			if (s_filetype.equalsIgnoreCase("Input"))
				filename = (fname.concat(date)).concat("_input.tab");
			else if (s_filetype.equals("Header"))
				filename = (fname.concat(date)).concat("_header.tab");

		} catch (Exception e) {
			try {
				recordError("setFileName", e);
			} catch (Exception ex) {
				log.FmtAndLogMsg("Error in getFileName method of : " + ex.toString(), ex);
			}
		} // end catch
		return filename;
	} // end getFileName method

	/*
	 * Method to create the header file data.
	 */

	public static String getHeaderFileData(int recordCount, String financeSource) throws Exception {
		String FinanceSourceName = "\"" + financeSource + "\"" + ",";
		String number_of_records = Integer.toString(recordCount) + ",";
		String headerFileData = "";
		String input_file = "\"" + input_filename + "\"" + ",";
		headerFileData = ((input_file.concat(number_of_records))
				.concat(FinanceSourceName));
		return headerFileData;
	}

	// try it and check if it works...

	public String getFileNameFromPath(String file) {
		return file.substring(file.lastIndexOf("\\") + 1, file.length());
	}

	/*
	 * Method to create the CVS fields. surround the fields with double qoutes.
	 */

	public static String surroundWithQuotes(String fieldName) {
		String s_field = fieldName;
		//s_field = (("\"".concat(s_field)).concat("\"")).concat(",");
		s_field = (s_field.concat(TABSTOP));
		return s_field;
	}
	
	//public static String surroundWithQuotesNoComma(String fieldName) {
	//	String s_field = fieldName;
	//	s_field = (("\"".concat(s_field)).concat("\""));
	//	return s_field;
	//}
	
	
	/* 
	 * method to cleanup files older than n days(from Chuck Caplan) 
	*/	
	public static void cleanupFiles() {
		int numOfDays = Integer.parseInt(cleanupDays);	
		if (numOfDays >= 0) {
			// get list of all files in local dir
			
			/**		
	         * OWASP TOP 10 2010 - A4 Path Manipulation
		     * Changes to the below code to fix vulnerabilities
		     * TTP 324955
		     **/
	        //File localDirFiles = new File(localfile_path);
	        File localDirFiles = null;
			try{
				localDirFiles = new File(OWASPSecurity.validationCheck(localfile_path, OWASPSecurity.DIRANDFILE));
			}
			catch (Exception e) {
				System.out.println("Exception: " + e);
			}

			String[] localFiles = localDirFiles.list();			
			FilenameFilter filter = new FilenameFilter() {
		        public boolean accept(File localDirFiles, String name) {
		            return name.endsWith(".tab");
		        }
		    };
		    localFiles = localDirFiles.list(filter);
				
			for (int i = 0; i < localFiles.length; i++) {
				File backupFile = new File(localDirFiles.getAbsolutePath() + "//"
						+ localFiles[i]);
				Date lastModified = new Date(backupFile.lastModified());
				GregorianCalendar gc = new GregorianCalendar();
				gc.add(Calendar.DATE, 0 - numOfDays);
				java.util.Date cleanupDate = gc.getTime();
				if (cleanupDate.after(lastModified)) {
					log.FmtAndLogMsg("Deleted file " + localFiles[i] + ": "
							+ backupFile.delete());
				}
				backupFile = null;
			}
			localDirFiles = null;
		} else {
			log.FmtAndLogMsg(" Not deleting any files since cleanupDays = "	+ cleanupDays);
		}
		log.FmtAndLogMsg(" Ended cleanup of files");
	}
	
	/*
	 * Opens a file for writing. If file exists the data would be appended by
	 * default.
	 */
	public void openCSVFile(String fileName) throws Exception {
		try {
			fileName = localfile_path.concat(fileName);
			
			/**		
	         * OWASP TOP 10 2010 - A4 Path Manipulation
		     * Changes to the below code to fix vulnerabilities
		     * TTP 324955
		     **/		          
			//dataFile = new PrintWriter(new BufferedWriter(new FileWriter(fileName, append)));
			dataFile = new PrintWriter(new BufferedWriter(new FileWriter(OWASPSecurity.validationCheck(fileName, OWASPSecurity.DIRANDFILE), append)));
			
		} catch (Exception e) {
			recordError("openCSVFile", e);
		}
	}

	public void writeDataExtract(String str) {
		if (dataFile != null) {
			dataFile.print(str);
			dataFile.flush();
		}
	}

	public void closeCSVFile() {
		if (dataFile != null) {
			dataFile.flush();
			dataFile.close();
			dataFile = null;
		}
	}

	
	
	/*
	 * Method to post a file via https
	 */
	public void httpsFile(String filename) {
    	byte[] buffer;
    	int bytesRead, bytesAvail, bufferSize;
    	HttpURLConnection conn = null;
    	DataOutputStream ostream = null;
		FileInputStream istream = null;
		BufferedReader breader = null;
    	
    	//Authenticator.setDefault(new R1Authenticator());

		// create a trust manager that does not validate certificate chains
		TrustManager[] trustAllCerts = new TrustManager[] {
			new X509TrustManager() {
				public X509Certificate[] getAcceptedIssuers() {
					return null;
				}
				public void checkClientTrusted(X509Certificate[] certs, String authType) {}
				public void checkServerTrusted(X509Certificate[] certs, String authType) {}
			}
		};

		// hostname verifier to ignore bad urls from https
		HostnameVerifier hv = new HostnameVerifier() {
			public boolean verify(String hostname, SSLSession session) {
				System.out.println("URL Host: " + hostname + ", " + session.getPeerHost());
				return true;
			}
		};
		
		try {
			
			/**		
	         * OWASP TOP 10 2010 - A4 Path Manipulation
		     * Changes to the below code to fix vulnerabilities
		     * TTP 324955
		     **/	          
	         //istream = new FileInputStream(new File(filename));
			istream = new FileInputStream(new File(OWASPSecurity.validationCheck(filename, OWASPSecurity.DIRANDFILE)));
			
			SSLContext sc = SSLContext.getInstance("SSL");
			URL url = new URL(destinationURL);
			
			sc.init(null, trustAllCerts, new SecureRandom());
			HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());
			HttpsURLConnection.setDefaultHostnameVerifier(hv);

			conn = (HttpURLConnection)url.openConnection();
			conn.setRequestMethod("POST");
			conn.setRequestProperty("Content-type", "multipart/form-data; boundary=" + FORM_BOUNDARY);
			conn.setDoOutput(true);
			
			ostream = new DataOutputStream (conn.getOutputStream ());
			ostream.writeBytes("--" + FORM_BOUNDARY + NEWLINE);
			ostream.writeBytes("content-disposition: form-data; name=\"File\";  filename=" + filename + NEWLINE);
			ostream.writeBytes(NEWLINE);
		
			bytesAvail = istream.available();
			bufferSize = Math.min(bytesAvail, MAX_BUFFER_SIZE);
			buffer = new byte[bufferSize];
			bytesRead = istream.read(buffer, 0, bufferSize);

			while (bytesRead > 0) {
				ostream.write(buffer, 0, bufferSize);
				bytesAvail = istream.available();
                bufferSize = Math.min(bytesAvail, MAX_BUFFER_SIZE);
                bytesRead = istream.read(buffer, 0, bufferSize);
            }

			// send multipart form data necessary after file data
			ostream.writeBytes(NEWLINE);
			ostream.writeBytes("--" + FORM_BOUNDARY + "--" + NEWLINE);

	        // get the response
	        breader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
	        String line;
        
	        while ((line = breader.readLine()) != null) {
	        	System.out.println(line);
        	}
	        
	        // close streams
	        istream.close();
	        ostream.flush();
	        ostream.close();
		}
		catch (Exception e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		} finally {
			try{ if(istream != null) istream.close(); }catch(Exception ex){ex.printStackTrace();}
			try{ if(ostream != null) ostream.flush();} catch (Exception ex)  {ex.printStackTrace();}
		    try{ if(ostream != null) ostream.close(); }catch(Exception ex){ex.printStackTrace();}
			try{ if(breader != null) breader.close(); }catch(Exception ex){ex.printStackTrace();}
		}
    } // end httpsFile method
} // main class

/*
class R1Authenticator extends Authenticator {
	protected PasswordAuthentication getPasswordAuthentication() {
	    String password = "r1dealerextract";
	    return new PasswordAuthentication("r1dealer", password.toCharArray());
	}
}
*/



