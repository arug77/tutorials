echo $APPONEPARAM
nohup java -classpath .:../lib/common.jar:../lib/ojdbc6.jar:../lib/commons-io-1.3.1.jar:../lib/commons-net-3.3.jar \
 com.cmsinc.origenate.apponedealerextract.AppOneDealerExtract $APPONEPARAM &