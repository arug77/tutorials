package com.cmsinc.origenate.tool;

import org.apache.commons.lang3.StringUtils;

import com.opencsv.bean.CsvBindByName;
import com.sf.bank.lue.util.DateValidator;

public class SolicitationBean {
	@CsvBindByName
	private String campaign;
	@CsvBindByName
	private String effectiveDate;
	@CsvBindByName
	private String expirationDate;
	@CsvBindByName
	private String solicitationID;
	@CsvBindByName
	private String firstName;
	@CsvBindByName
	private String middleInitial;
	@CsvBindByName
	private String lastName;
	@CsvBindByName
	private String suffix;
	@CsvBindByName
	private String streetNumber;
	@CsvBindByName
	private String streetName;
	@CsvBindByName
	private String streetType;
	@CsvBindByName
	private String address2;
	@CsvBindByName
	private String city1;
	@CsvBindByName
	private String state1;
	@CsvBindByName
	private String zip1;
	@CsvBindByName
	private String countryID;
	@CsvBindByName
	private String partialSSN;

	private boolean isValidSolicitation = true;
	private String logMessages;
	
	/**
	 * Empty constructor for CSVReader
	 */
	public SolicitationBean() { }
	
	/**
	 * Full constructor for testing
	 * @param campaign
	 * @param effectiveDate
	 * @param expirationDate
	 * @param solicitationID
	 * @param firstName
	 * @param middleInitial
	 * @param lastName
	 * @param suffix
	 * @param streetNumber
	 * @param streetName
	 * @param streetType
	 * @param address2
	 * @param city1
	 * @param state1
	 * @param zip1
	 * @param countryID
	 * @param partialSSN
	 */
	public SolicitationBean(String campaign, String effectiveDate,
			String expirationDate, String solicitationID, String firstName,
			String middleInitial, String lastName, String suffix,
			String streetNumber, String streetName, String streetType,
			String address2, String city1, String state1, String zip1,
			String countryID, String partialSSN) {
		this.campaign = campaign;
		this.effectiveDate = effectiveDate;
		this.expirationDate = expirationDate;
		this.solicitationID = solicitationID;
		this.firstName = firstName;
		this.middleInitial = middleInitial;
		this.lastName = lastName;
		this.suffix = suffix;
		this.streetNumber = streetNumber;
		this.streetName = streetName;
		this.streetType = streetType;
		this.address2 = address2;
		this.city1 = city1;
		this.state1 = state1;
		this.zip1 = zip1;
		this.countryID = countryID;
		this.partialSSN = partialSSN;
	}
	
	/**
	 * @return campaign
	 */
	public String getCampaign() {
		return campaign;
	}

	/**
	 * Accepts a campaign string and trims it to 25 characters
	 * @param campaign
	 */
	public void setCampaign(String campaign) {
		this.campaign = StringUtils.trim(campaign);
		if(StringUtils.length(this.campaign) > 50) {
			this.campaign = this.campaign.substring(0, 50);
			logMessages = logMessages + "Solicitation campaign truncated to 50 characters\n ";
		}

	}

	/**
	 * @return effectiveDate
	 */
	public String getEffectiveDate() {
		return effectiveDate;
	}

	/**	 
	 * Accepts a string, validates that is in the correct format
	 * and sets the effective date. Invalid dates will cause 
	 * isValidSolicitation to be set to false and the date to be
	 * set to null
	 * @param effectiveDate
	 */
	public void setEffectiveDate(String effectiveDate) {
		if(DateValidator.isValidDate(effectiveDate)) {
			this.effectiveDate = effectiveDate;
		} else {
			this.effectiveDate = null;
			isValidSolicitation = false;
		}
	}

	/**
	 * @return expirationDate
	 */
	public String getExpirationDate() {
		return expirationDate;
	}

	/**
	 * Accepts a string, validates that is in the correct format
	 * and sets the expiration date. Invalid dates will cause 
	 * isValidSolicitation to be set to false and the date to be
	 * set to null 
	 * @param expirationDate
	 */
	public void setExpirationDate(String expirationDate) {
		if(DateValidator.isValidDate(expirationDate)) {
			this.expirationDate = expirationDate;
		} else {
			this.expirationDate = null;
			isValidSolicitation = false;
		}
	}

	/**
	 * @return solicitationID
	 */
	public String getSolicitationID() {
		return solicitationID;
	}

	/**
	 * Accepts a solicitation id and trims it to 25 characters
	 * @param solicitationID
	 */
	public void setSolicitationID(String solicitationID) {
		this.solicitationID = StringUtils.trim(solicitationID);
		if(StringUtils.length(this.solicitationID)>25) {
			this.solicitationID = this.solicitationID.substring(0, 25);
			logMessages = logMessages + "Solicitation ID truncated to 25 characters\n ";
		}
	}

	/**
	 * @return firstName
	 */
	public String getFirstName() {
		return firstName;
	}

	/**
	 * Accepts a first name and trims it to 64 characters
	 * @param firstName
	 */
	public void setFirstName(String firstName) {
		this.firstName = StringUtils.trim(firstName);
		if(StringUtils.length(this.firstName)>64) {
			this.firstName = this.firstName.substring(0, 64);
			logMessages = logMessages + "First name truncated to 64 characters\n ";
		}
	}

	/**
	 * @return middleInitial
	 */
	public String getMiddleInitial() {
		return middleInitial;
	}

	/**
	 * Accepts a middle initial string and trims it to a single character
	 * @param middleInitial
	 */
	public void setMiddleInitial(String middleInitial) {
		this.middleInitial = StringUtils.trim(middleInitial);
		if(StringUtils.length(this.middleInitial)>1) {
			this.middleInitial = middleInitial.substring(0,1);
		}
	}

	/**
	 * @return lastName
	 */
	public String getLastName() {
		return lastName;
	}

	/**
	 * Accepts a last name and trims it to 25 characters
	 * @param lastName
	 */
	public void setLastName(String lastName) {
		this.lastName = StringUtils.trim(lastName);
		if(this.lastName.length()>25) {
			this.lastName = this.lastName.substring(0, 25);
			logMessages = logMessages + "Last name truncated to 25 characters\n ";
		}
	}

	/**
	 * @return suffix
	 */
	public String getSuffix() {
		return suffix;
	}

	/**
	 * Accepts a suffix and trims off a period if present
	 * @param suffix
	 */
	public void setSuffix(String suffix) {
		if(!StringUtils.isBlank(suffix)) {
			this.suffix = StringUtils.trim(suffix);
			if(suffix.indexOf(".")>0) {
				this.suffix = suffix.substring(0, suffix.indexOf("."));
				logMessages = logMessages + "Removed '.' from suffix\n ";
			}
		}
	}

	/**
	 * @return streetNumber
	 */
	public String getStreetNumber() {
		return streetNumber;
	}

	/**
	 * Accepts a street number and trims whitespace
	 * @param streetNumber
	 */
	public void setStreetNumber(String streetNumber) {
		this.streetNumber = StringUtils.trim(streetNumber);
	}

	/**
	 * @return streetName
	 */
	public String getStreetName() {
		return streetName;
	}

	/**
	 * Accepts a street name and trims it to 50 characters
	 * @param streetName
	 */
	public void setStreetName(String streetName) {
		this.streetName = StringUtils.trim(streetName);
		if(streetName.length()>50) {
			this.streetName = streetName.substring(0, 50);
			logMessages = logMessages + "Street name truncated to 50 characters\n ";
		}
	}

	/**
	 * @return streetType
	 */
	public String getStreetType() {
		return streetType;
	}

	/**
	 * Accepts a street type and trims it to 50 characters
	 * @param streetType
	 */
	public void setStreetType(String streetType) {
		this.streetType = StringUtils.trim(streetType);
	}

	/**
	 * @return address2
	 */
	public String getAddress2() {
		return address2;
	}

	/**
	 * Accepts the second line of an address
	 * and trims it to 25 characters
	 * @param address2
	 */
	public void setAddress2(String address2) {
		this.address2 = StringUtils.trim(address2);
		if(address2.length()>25) {
			this.address2 = address2.substring(0, 25);
			logMessages = logMessages + "Second line of address truncated to 25 characters\n ";
		}
	}

	/**
	 * @return city1
	 */
	public String getCity1() {
		return city1;
	}

	/**
	 * Accepts a city name and trims it to 25 characters
	 * @param city1
	 */
	public void setCity1(String city1) {
		this.city1 = StringUtils.trim(city1);
		if(city1.length()>25) {
			this.city1 = city1.substring(0, 25);
		}
	}

	/**
	 * @return state1
	 */
	public String getState1() {
		return state1;
	}

	/**
	 * Accepts a state name and trims it of white space
	 * @param state1
	 */
	public void setState1(String state1) {
		this.state1 = StringUtils.trim(state1);
	}

	/**
	 * @return zip1
	 */
	public String getZip1() {
		return zip1;
	}

	/**
	 * Accepts a zip code and validates that is either 5 or 9 digits
	 * @param zip1
	 */
	public void setZip1(String zip1) {
		if(!(StringUtils.isBlank(zip1))) {
			this.zip1 = StringUtils.trim(zip1);
			if(!((zip1.matches("\\d{5}")) || zip1.matches("\\d{5}-\\d{4}"))) {
				this.zip1= "";
				logMessages = logMessages + "Invalid zipcode, value set to empty\n ";
			}
		}
	}

	/**
	 * @return countryID
	 */
	public String getCountryID() {
		return countryID;
	}

	/**
	 * Accepts a country ID and trims it to 5 characters
	 * @param countryID
	 */
	public void setCountryID(String countryID) {
		this.countryID = StringUtils.trim(countryID);
		if(countryID.length()>5) {
			this.countryID = countryID.substring(0, 5);
			logMessages = logMessages + "Country truncated to 5 characters\n ";
		}
	}

	/**
	 * @return partialSSN
	 */
	public String getPartialSSN() {
		return partialSSN;
	}

	/**
	 * Accepts a partial number and trims it to 8 characters
	 * If the string is to short, validSolicitation is set to false
	 * @param partialSSN
	 */
	public void setPartialSSN(String partialSSN) {
		this.partialSSN = StringUtils.trim(partialSSN);
		if(partialSSN.length()!=8) {
			if(partialSSN.length()>8) {
				this.partialSSN = partialSSN.substring(partialSSN.length()-8);
				logMessages = logMessages + "SSN truncated to last 8 characters\n ";
			} else {
				logMessages = logMessages + "Partial SSN is empty or not long enough.\n ";
				this.partialSSN = null;
				isValidSolicitation = false;
			}
		}
	}

	/**
	 * @return true if date formats and SSN were correct
	 * @return false if either the ssn or date values did not match standards
	 */
	public boolean getIsValidSolicitation() {
		return isValidSolicitation; 
	}

	public String getLogMessages() {
		return logMessages;
	}

	/**
	 * @return a comma separated string for this solicitation's information. 
	 */
	public String toCSVString() {
		return campaign + "," + effectiveDate + "," + expirationDate + "," + solicitationID + "," + firstName
				+ "," + middleInitial + "," + lastName+ "," + suffix+ "," + streetNumber + "," + streetName
				+ "," + streetType+ "," + address2+ "," + city1+ "," + state1+ "," + zip1+ "," + countryID
				+ "," + partialSSN;
	}
}
