package com.cmsinc.origenate.tool;

import com.cmsinc.origenate.crypto.Crypto;
import com.cmsinc.origenate.crypto.CryptoFactory;
import com.cmsinc.origenate.util.DBConnection;
import com.cmsinc.origenate.util.IniFile;
import com.cmsinc.origenate.util.LogMsg;
import com.cmsinc.origenate.util.OWASPSecurity;
import com.opencsv.CSVReader;
import com.opencsv.bean.CsvToBean;
import com.opencsv.bean.HeaderColumnNameMappingStrategy;

import java.io.FileReader;
import java.sql.BatchUpdateException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;

public class SolicitationListDataLoad {

	private static final int BATCH_SIZE = 200;
	private static final String CRYPTO_FIELD_NAME = "id";
	private static final int STATE_FARM_ID = 148;
	
	private Connection connection;
	private Crypto crypto;
	private String csvLocation = "";
	private DBConnection dbConnect;
	private IniFile ini = new IniFile();
	private LogMsg log_obj = new LogMsg();
	private List<String> mstrStates = new ArrayList<String>();
	private List<String> mstrStreet = new ArrayList<String>();
	private Map<String, String> mstrSuffix = new HashMap<String, String>();
	private boolean purgeOldRecords;
	private List<SolicitationBean> solicitationBeanList;

	public SolicitationListDataLoad() { }
	
	public static void main(String[] args) {
		SolicitationListDataLoad solicitationListDataLoad = new SolicitationListDataLoad();
		if (solicitationListDataLoad.run(args)){
			System.exit(0);
		} else {
			System.exit(1);
		}
	}

	/**
	 * Runs the Solicitation List Data Load
	 * @param args Input Arguments
	 * @return true if no errors were encountered; otherwise false
	 */
	public boolean run(String[] args) {
		long startTime = System.currentTimeMillis();
		boolean successfulExecution = true;
		
		try{
			log_obj.FmtAndLogMsg("Solicitation List Data Load initializing");
			setPropertiesFromArgs(args);
			if(StringUtils.isBlank(csvLocation) && !purgeOldRecords ) {
				log_obj.FmtAndLogMsg("Import file name not provided and purge not selected.");
				showOptions();
				return false;
			}
			if(purgeOldRecords) {
				removeExpiredSolicitations();
			} 
			if(!StringUtils.isBlank(csvLocation)) {
				getDatabaseConnection();
				String client = ini.getINIVar("database.user", "").toLowerCase();
				if(isIdentifierEncrypted() && !(StringUtils.isBlank(client))) {
					crypto = CryptoFactory.getCrypto();
				}
				readCSVToBeans();
				insertIntoSoliciation(solicitationBeanList, client);
				crypto.closeSession();
			}
			log_obj.FmtAndLogMsg("Solicitation List Data Load from " + csvLocation + " complete");
			long duration = System.currentTimeMillis() - startTime;
			log_obj.FmtAndLogMsg("Run time was " + duration + " milliseconds, or about " + duration/1000 + " seconds.");
		} catch (Exception e) {
			log_obj.FmtAndLogMsg("Job Failure. ", e);
			successfulExecution = false;
		} finally {
            // If we have an open database connection close it before we exit.
            try {
                if (connection != null) {
                    connection.close();
                }
            } catch (Exception e) {
                log_obj.FmtAndLogMsg("Failure closing database connection: " + e.toString());
            }
        }
		
		return successfulExecution;
	}

	private List<SolicitationBean> readCSVToBeans() {
		String fileName;
		try {
			fileName = OWASPSecurity.validationCheck(csvLocation, OWASPSecurity.DIRANDFILE);
			try (CSVReader reader = new CSVReader(new FileReader(fileName))) {
				HeaderColumnNameMappingStrategy<SolicitationBean> strategy = new HeaderColumnNameMappingStrategy<>();
				strategy.setType(SolicitationBean.class);
				CsvToBean<SolicitationBean> csvToSolicitation = new CsvToBean<>();
				solicitationBeanList = csvToSolicitation.parse(strategy, reader);
			} catch (Exception e1) {
				log_obj.FmtAndLogMsg("Error with import file name");
				log_obj.FmtAndLogMsg(e1.toString());
				throw new RuntimeException("Error with import", e1);
			}
		} catch (Exception ex) {
			log_obj.FmtAndLogMsg(ex.toString());
			throw new RuntimeException("Error reading solicitations.", ex);
		}
		return solicitationBeanList;
	}

	/**
	 * Set the parameters for data load from incoming arguments
	 * @param args
	 */
	private void setPropertiesFromArgs(String[] args) {
		checkArgsLength(args);
		for(String argument : args) {
			if(argument.charAt(0)!='-') {
				showOptions();
			}
			switch(argument.charAt(1)) {
			case 'i':
				String iniFileData = argument.substring(2);
				try {
					ini.readINIFile(iniFileData);
					log_obj.FmtAndLogMsg("Solicitation List Data Load reading ini file...");
					String logFile = ini.getINIVar("logs.solicitation_data_load_log_file", "");
					if (logFile.length() > 0) {
						log_obj.openLogFile(logFile);
					}
				} catch (Exception e) {
					log_obj.FmtAndLogMsg("Caught exception reading ini: " + e.getMessage());
				}
				log_obj.FmtAndLogMsg("IniFile is " + iniFileData);
				break;
			case 'e':
				log_obj.FmtAndLogMsg("e is not required as an arguement, Statefarm is always evaluator 148");
				break;
			case 'f':
				csvLocation = argument.substring(2);
				log_obj.FmtAndLogMsg("File Name: " + csvLocation);
				break;
			case 'p':
				if("-purge".equals(argument)) {
					purgeOldRecords = true;
					log_obj.FmtAndLogMsg("Purge old records added to queue.");
					break;
				}
			default: 
				log_obj.FmtAndLogMsg("Unrecognized command: " + argument);
				showOptions();
				throw new RuntimeException("Command provided not recognized");
			}
		}
	}

	private void checkArgsLength(String[] args) {
		if(args.length<2) {
			log_obj.FmtAndLogMsg("Inadequate number of arguments provided.");
			showOptions();
			throw new RuntimeException("Less than two arguments provided");
		}
	}

	/**
	 * CMSI code to inform people of their options.
	 * Called after an error is thrown during argument load.
	 */
	private void showOptions() {
		log_obj.FmtAndLogMsg("Printing options information. ");
		log_obj.FmtAndLogMsg("Usage: java SolicitationListDataLoad -i<inifile> -f<file> [-purge]");
		log_obj.FmtAndLogMsg("----------------------------------------------------");
		log_obj.FmtAndLogMsg("-i     - required: INI file to use for configuration");
		log_obj.FmtAndLogMsg("-f     - required: .csv file (optional if -purge)");
		log_obj.FmtAndLogMsg("-purge - optional: Remove expired solicitations");
		log_obj.FmtAndLogMsg("----------------------------------------------------\n");
	}

	/**
	 * Checks the database that it is connected to to determine if the
	 * identifier for the client is encrypted.
	 * @param con
	 * @param evalIDint
	 * @return true if the flag for encryption is set to 1 (encrypted)
	 */
	private boolean isIdentifierEncrypted() {
		String sqlCommand = "SELECT nvl(id_flg,0) id_flg FROM config_encryption WHERE evaluator_id = " + STATE_FARM_ID;
		PreparedStatement prepared = null;
		ResultSet results = null;
		String result = "";
		try{
			prepared = connection.prepareStatement(sqlCommand);
			results = prepared.executeQuery();
			if(results.next()) {
				result = results.getString("id_flg");
			}
			prepared.close();
			results.close();
		} catch (Exception e) {
			log_obj.FmtAndLogMsg("Error getting id flag for encryption status.");
			throw new RuntimeException("Error getting id flag for encryption status.", e);
		}
		return "1".equals(result);
	}

	/**
	 * Inserts rows into Solicitation List Values in batches of 200.
	 * checks for non-valid beans and does not enter them.
	 * @param solicitationBeans
	 * @param crypto
	 * @param client
	 */
	private void insertIntoSoliciation(List<SolicitationBean> solicitationBeans, String client) {
		String sqlCommand = "INSERT INTO CONFIG_SOLICITATION_LIST VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,to_date(?,'mm/dd/yyyy'),to_date(?,'mm/dd/yyyy'),sysdate,'SYSTEM',?,?,?,?)";
		PreparedStatement prepared = null;
		int count = 0;
		try{
			prepared = connection.prepareStatement(sqlCommand);
			int solicitationID = getMaxSolicitationID();
			log_obj.FmtAndLogMsg("Previous final solicitation ID: " +solicitationID);
			for(SolicitationBean solicitation : solicitationBeans) {
				if(!solicitation.getIsValidSolicitation()) {
					log_obj.FmtAndLogMsg("Invalid data for solicitation #" + count);
				} else {
					if(!StringUtils.isBlank(solicitation.getLogMessages())) {
						log_obj.FmtAndLogMsg("Import messages for " + count + "\n " + solicitation.getLogMessages());
					}
					prepared.setInt(1, ++solicitationID);
					prepared.setInt(2, STATE_FARM_ID);
					prepared.setString(3, solicitation.getFirstName());
					prepared.setString(4, solicitation.getMiddleInitial());
					prepared.setString(5, solicitation.getLastName());
					prepared.setString(6, validateSuffix(solicitation.getSuffix()));
					prepared.setString(7, solicitation.getStreetNumber());
					prepared.setString(8, solicitation.getStreetName());
					prepared.setString(9, validateStreet(solicitation.getStreetType()));
					prepared.setString(10, solicitation.getAddress2());
					prepared.setString(11, solicitation.getCity1());
					prepared.setString(12, validateState(solicitation.getState1()));
					prepared.setString(13, solicitation.getZip1());
					prepared.setString(14, solicitation.getSolicitationID());
					prepared.setString(15, solicitation.getCampaign());
					prepared.setString(16, solicitation.getEffectiveDate());
					prepared.setString(17, solicitation.getExpirationDate());
					prepared.setString(18, solicitation.getCountryID());
					if(crypto != null) {
						prepared.setString(19, formatMask(solicitation.getPartialSSN()));
						prepared.setString(20, crypto.batchEncryptString("origenate_" + client, CRYPTO_FIELD_NAME, solicitation.getPartialSSN()));
						prepared.setString(21, crypto.batchGenerateMAC("origenate_" + client, solicitation.getPartialSSN()));
					} else {
						prepared.setString(19, solicitation.getPartialSSN());
						prepared.setString(20, null);
						prepared.setString(21, null);
					}
					count++;
					prepared.addBatch();
				}
				if(count != 0 && count % BATCH_SIZE == 0) {
					try { 
						prepared.executeBatch();
						log_obj.FmtAndLogMsg("Batch processing for " + (count-BATCH_SIZE) + " through " + count + " executed.");
					} catch (BatchUpdateException ex) {
						log_obj.FmtAndLogMsg("Data load failed between " + (count-BATCH_SIZE) + " and " + count);
						throw new RuntimeException("Data load failed.", ex);
					}
				}
			}
			int numberOfBatches = count/BATCH_SIZE; 
			try { 
				prepared.executeBatch();
				log_obj.FmtAndLogMsg("Batch processing final records: " + BATCH_SIZE*numberOfBatches + " through " + count);
			} catch (BatchUpdateException ex) {
				log_obj.FmtAndLogMsg("Data load failed between " + BATCH_SIZE*numberOfBatches + " and " + count);
				throw new RuntimeException("Data load failed.", ex);
			}
		} catch (Exception e) {
			log_obj.FmtAndLogMsg(e.toString()+ " " + e.getCause().toString());
			throw new RuntimeException("Error with solicitation import. Please check logs");
		}
	}

	/**
	 * Returns the current maximum solicitation id (key value)
	 * @return maxID
	 */
	private int getMaxSolicitationID() {
		int maxId = 0;
		PreparedStatement statement = null;
		ResultSet result = null;
		try {
			statement = connection.prepareStatement("SELECT NVL(MAX(solicitation_id),0) FROM CONFIG_SOLICITATION_LIST where evaluator_id = ?");
			statement.setInt(1, STATE_FARM_ID);
			result = statement.executeQuery();
			if(result.next()) {
				maxId = result.getInt(1);
			}
			statement.close();
			result.close();
		} catch (Exception e) {
			log_obj.FmtAndLogMsg("Error getting max Soliciation ID :" + e.toString());
			throw new RuntimeException("Error getting max Soliciation ID" , e);
		} finally {
			if (statement != null)
				try {
					statement.close();
				} catch (Exception e) {
					throw new RuntimeException(e);
				}
			if (result != null)
				try {
					result.close();
				} catch (Exception e) {
					throw new RuntimeException(e);
				}
		}
		return maxId;
	}

	/**
	 * @param value
	 * @return value with the first four characters masked
	 */
	private String formatMask(String value) {
		return "****" + value.substring(4);
	}

	/**
	 * CMSI code to remove expired solicitations.
	 * Left intact but commented out against future need.
	 */
	private void removeExpiredSolicitations() {
		log_obj.FmtAndLogMsg("Removing expired solicitations for evaluator " + STATE_FARM_ID);
		int startingSolicitations = evaluatorSolicitationCount();
		PreparedStatement getSolicitationCount = null;
		try {
			getSolicitationCount = connection.prepareStatement("delete from config_solicitation_list where evaluator_id = "
						+ STATE_FARM_ID + " and sysdate > expiration_dt");
			getSolicitationCount.executeUpdate();
		} catch (Exception e) {
			log_obj.FmtAndLogMsg("Error purging expiried solicitations");
		}
		int endingSolicitations = evaluatorSolicitationCount();
		log_obj.FmtAndLogMsg("Removed " + (startingSolicitations - endingSolicitations) + " expired solicitations for evaluator " + STATE_FARM_ID);
	}

	/**
	 *  CMSI code to determine the number of solicitations
	 *  present for a given evaluator.
	 *  Left intact but commented out against future need.
	 * @return the count of solicitations
	 */
	private int evaluatorSolicitationCount() {
		PreparedStatement getSolicitationCount = null;
		int val = 0;
		try {
			getSolicitationCount = connection.prepareStatement("SELECT COUNT(1) FROM config_solicitation_list where evaluator_id = " + STATE_FARM_ID);
			ResultSet result = getSolicitationCount.executeQuery();
			if(result.next()) {
				val = result.getInt(1);
			}
		} catch (Exception e) {
			log_obj.FmtAndLogMsg("Error evaluating solicitation count.");
		}
		return val;
	}

	/**
	 * Checks the street type value.
	 * If it is not null, compare it to database values.
	 * If the database comparison fails, the database value will be empty ("")
	 * @param streetName
	 */
	private String validateStreet(String streetName) {
		if(!StringUtils.isBlank(streetName)) {
			if(mstrStreet.isEmpty()) {
				mstrStreet = populateList("SELECT street_type_id FROM MSTR_STREET_TYPE");
			}

			for(String street : mstrStreet) {
				if(streetName.equalsIgnoreCase(street)) {
					return streetName;
				}
			}
			log_obj.FmtAndLogMsg("Street type not found, database entry will be empty");}
		return "";
	}

	/**
	 * Checks the suffix value.
	 * If it is not null, compare it to database values.
	 * If the database comparison fails, the database value will be empty ("")
	 * @param streetName
	 */
	private String validateSuffix(String suffix) {
		if(mstrSuffix.isEmpty()) {
			mstrSuffix = populateMap("SELECT suffix_id, suffix_roman_txt FROM MSTR_REQUESTOR_SUFFIX");
		}
		if(!StringUtils.isBlank(suffix)) {
			return StringUtils.defaultIfBlank(mstrSuffix.get(suffix.toLowerCase()), "");
		}
		return "";
	}

	/**
	 * Checks the state value.
	 * If it is not null, compare it to database values.
	 * If the database comparison fails, the database value will be empty ("")
	 * @param streetName
	 */
	private String validateState(String state1) {
		if(!StringUtils.isBlank(state1)) {
			if(mstrStates.isEmpty()) {
				mstrStates = populateList("SELECT state_id FROM MSTR_STATE");
			}

			for(String state : mstrStates) {
				if(state1.equalsIgnoreCase(state)) {
					return state1;
				}
			}
			log_obj.FmtAndLogMsg("State not found, database entry will be empty");
		}
		return "";
	}

	/**
	 * checks to see if the database connection has been initialized
	 */
	private void getDatabaseConnection() {
		if(connection==null) {
			dbConnect = new DBConnection();
			try {
				connection = dbConnect.getConnection(ini.getINIVar("database.host", ""), ini.getINIVar("database.sid", ""), ini.getINIVar("database.user", ""),
						ini.getINIVar("database.password", ""), ini.getINIVar("logs.solicitation_data_load_log_file", ""), ini.getINIVar("database.port", ""), ini.getINIVar("database.TNSEntry", ""));
			} catch (Exception e) {
				throw new RuntimeException("Error getting database connection",  e);
			}
		}
	}

	/**
	 * Uses the provided query string to populate an array list.
	 * @param query
	 * @return
	 */
	private List<String> populateList(String query) {
		List<String> mstrList = new ArrayList<String>();
		getDatabaseConnection();
		try {
			PreparedStatement prepared = connection.prepareStatement(query);
			ResultSet results = prepared.executeQuery();
			while(results.next()) {
				mstrList.add(results.getString(1));
			}
			prepared.close();
			results.close();
		} catch (SQLException e) {
			log_obj.FmtAndLogMsg("SQL Exception " + e.toString());
			throw new RuntimeException("SQL Exception", e);
		}
		return mstrList;
	}

	/**
	 * Uses the provided query string to populate a map.
	 * @param query
	 * @return
	 */
	private Map<String, String> populateMap(String query) {
		Map<String, String> mstrMap = new HashMap<String, String>();
		getDatabaseConnection();
		try {
			PreparedStatement prepared = connection.prepareStatement(query);
			ResultSet results = prepared.executeQuery();
			while(results.next()) {
				mstrMap.put(results.getString(1).toLowerCase(), results.getString(2));
			}
			prepared.close();
			results.close();
		} catch (SQLException e) {
			log_obj.FmtAndLogMsg("SQL Exception " + e.toString());
			throw new RuntimeException("SQL Exception", e);
		}
		return mstrMap;
	}
}
