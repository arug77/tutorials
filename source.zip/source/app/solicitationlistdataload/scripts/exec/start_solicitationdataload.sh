#!/bin/sh
#
# Process Soliciattion List Data Load
#

##########################################################################################################

# Set environment variables and classpath's
set_env(){
	ENV_PATH=/opt/origenate/or_statefarm
	echo ". $ENV_PATH/config/usrconfig.sh"
	. $ENV_PATH/config/usrconfig.sh
	. $ENV_PATH/config/$EDWCONFIG
	echo "done setting variables"
}

###########################################################################################################


##########################################################################################################################
# Main Logic #

set_env

INIFILE=$ORCONFIG/origenate.ini
LOGFILE=$ORLOGS/solicitationdataload.log
EVALID=148
FILETYPE=_BVLVAR_SOLICIT_NAS_/solicitationdataload.csv

cd /origenate/or_statefarm/apps/solicitationlistdataload

nohup java -classpath .:../lib/*:$ENV_PATH/config/origenate.ini com.cmsinc.origenate.tool.SolicitationListDataLoad -i$INIFILE -f$FILETYPE 
exit 0
