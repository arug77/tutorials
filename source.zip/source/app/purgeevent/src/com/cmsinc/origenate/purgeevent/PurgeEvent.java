/* Filename: PurgeEvent.java
 * Version: 
 * Creation Date: September 11, 2005
 * Author: Gautam Anand
 * Copyright (c) 2002. All rights reserved
 * Description: Refer Clientele #134975
 * This program would archive the Event table records older than n days 
 * in a CSV file and then delete them from the events table.
 */

package com.cmsinc.origenate.purgeevent;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.ListIterator;
import java.util.Vector;
import java.lang.Character;


import com.cmsinc.origenate.util.OWASPSecurity;
import com.cmsinc.origenate.util.DBConnection;
import com.cmsinc.origenate.util.IniFile;
import com.cmsinc.origenate.util.LogMsg;
import com.cmsinc.origenate.util.SQLUpdate;

public class PurgeEvent {

	private static LogMsg log = new LogMsg(); // log

	/*PurgeEvent Object Instantiation*/
	private static PurgeEvent pe1 = new PurgeEvent(); 

	/*Days to Keep the Event Table Records File*/
	private static String cleanupDays; 

	private static Connection con; // db settings

	private static String input_filename; // input filename.

	private static String header_filename; // header filename

	private static String localfile_path; // input and header file localpath

	private static String input_filelocation; // input file location

	private static String header_file_data; // header file content

	/*whether to delete input & header files*/
	private static boolean performFileDelete = false;
	
	private static Vector v = new Vector(300,100); 
	
	private static Vector cmdargs = new Vector(10,10);	
	
	/*determines days to keep records in event table*/
	private static String cleanupRecordsDate;

    /*determines date before which records should be deleted from event*/
	private static String deleteRecordsDays;

	/*whether the event table records should be deleted*/
	private static boolean performDBRecordDelete = false;

	private static String performArchive ="yes";
	
	private static String s_iniFile; // ini filename

	/*number of records in CSV input file*/
	private static int recordCount;

	private PrintWriter dataFile = null;

	private static Character ch;
	
	private boolean append = true;

	private static IniFile ini = new IniFile();

	/*
	 * Main method to call the getDBConnection method, 
	 * getEventDataExtract method and retreive the command 
	 * line parameters like ini file location, header and 
	 * input file location, days to clean input/header
	 * files etc. 
	 */

	public static void main(String[] args) {

		String s_log_file = "";
		if (args.length > 0) {
			for (int i = 0; i < args.length; ++i) {
				if ((args[i].charAt(0) != '-') && (args[i].length() > 1)) {
					showUsageAndExit();
				}
				ch = Character.valueOf(args[i].charAt(1));
				cmdargs.add(ch);				
				switch (args[i].charAt(1)) {
				case 'i':
					s_iniFile = args[i].substring(2);
					try {
						ini.readINIFile(s_iniFile);
						s_log_file = ini.getINIVar("logs.PurgeEvent_log_file",
								"");
						if (s_log_file.length() > 0) {
							log.openLogFile(s_log_file);
						}
					} catch (Exception e) {
						log.FmtAndLogMsg("Caught exception reading ini file '"
								+ s_iniFile + "':" + e.toString());
					}
					log.FmtAndLogMsg("\r");
					log.FmtAndLogMsg("Starting Purge Event Tool");
					log.FmtAndLogMsg("\r");
					log.FmtAndLogMsg("iniFile name: " + s_iniFile);
					break;
				case 'l':
					localfile_path = args[i].substring(2); 
					log
							.FmtAndLogMsg("local location of the input & header files: "
									+ localfile_path);
					break;
				case 'd':
					deleteRecordsDays = args[i].substring(2);
					log.FmtAndLogMsg("The records older than "
							+ deleteRecordsDays + " days should be deleted");
					break;
				case 'n':
					cleanupDays = args[i].substring(2);
					log.FmtAndLogMsg("Number of days to keep the files "
							+ cleanupDays);
					break;
				case 'a':
					performArchive = args[i].substring(2);
					log.FmtAndLogMsg("Should the Event Table data be archived "
							+ performArchive);
					break;
				default:
					log.FmtAndLogMsg("Unknown parameter: " + args[i]);
					showUsageAndExit();
					break;
				}
			}
		}
		
		
	 /* Check if the required command line args are present*/
		try {
			log.FmtAndLogMsg("********Calling checkCmdLineArgs Method********");
			checkCmdLineArgs();
		} catch (Exception e) {
			log.FmtAndLogMsg("Error in checkCmdLineArgs method of : "
					+ e.toString());
		}
		log.FmtAndLogMsg("********checkCmdLineArgs Method Completed********");

		/* Creating a DB Connection */

		try {
			log.FmtAndLogMsg("********Calling getDBConnection Method********");
			getDBConnection(s_log_file);
		} catch (Exception e) {
			log.FmtAndLogMsg("Error in getDBConnection method of : "
					+ e.toString());
		}
		log.FmtAndLogMsg("********getDBConnection Method Completed********");

		/*Determining date before which the event table records be deleted*/

		try {
			log.FmtAndLogMsg("********Calling getCleanupDate Method********");
			getRecordDeletionDate(deleteRecordsDays);
		} catch (Exception e) {
			log.FmtAndLogMsg("Error in getCleanupDate method of : "
					+ e.toString());
		}
		log.FmtAndLogMsg("********getCleanupDate Method Completed********");

		/*Checking if Audit table be archived;calling methods needed for archiving*/
		if(performArchive.equalsIgnoreCase("YES")){

			/* Calling method to retreive the input and header filenames */
			log.FmtAndLogMsg("********Calling getFileName Method********");
			input_filename = getFileName("Input");
			System.out.println("input_filename" + input_filename);
			
			header_filename = getFileName("Header");
			System.out.println("header_filename" + header_filename);
			log.FmtAndLogMsg("********getFileName Method Completed********");

			/* Calling method to extract Event Table Records */
			try {
				log
						.FmtAndLogMsg("********Calling getEventDataExtract Method********");
				getEventDataExtract();
			} catch (Exception e) {
				log.FmtAndLogMsg("Error in getEventDataExtract method of : "
						+ e.toString());
			}
			log
					.FmtAndLogMsg("********getEventDataExtract Method Completed********");

		}
		else {
			delete_from_event_table();
		}
		log.FmtAndLogMsg("********Purge Event Tool Completed********");

	}

	/*
	 * Method to inform that expected values are missing on the command line.
	 */

	public static void showUsageAndExit() {
		System.out
				.println("Usage: java com.cmsinc.origenate.purgeevent.PurgeEvent");
		System.out
				.println("-i<ini file> -l<localfile location> -d<deleteRecordsDays> -n<Cleanup Days> -a<Perform Archive>");
		System.out
				.println("------------------------------------------------------------------------------");
		System.out.println("Parameter	Data Type	Required/Optional			Description");
		System.out.println("  -i 		 String			Required		ini file name including the location");
		System.out.println("  -l		 String 		Required		location of input and header file on local machine");
		System.out.println("  -d		 Integer		Required		Number of days before which all records in Event table should be deleted");
		System.out.println("  -n 		 Integer		Required		Number of days to keep the files in local directory");
		System.out.println("  -a 		 String			Optional		Should the Event Table data be archived YES/NO; YES-Default");
		System.exit(0);
	}

	/*
	 * Method to report an error in a method. Mainly used in the
	 * getEventDataExtract method to report missing field values in the extract
	 * for required fields.
	 */

	public static void recordError(String methodName, Exception err)
			throws Exception {
		try {
			log.FmtAndLogMsg("Error occured in " + methodName + " method of : "
					+ err.toString());
			throw new Exception("Error occured in " + methodName
					+ " method of : " + err.toString());
		} catch (Exception e) {
			log
					.FmtAndLogMsg("Error in reportError method of : "
							+ e.toString());
		}

	}

	/*checks if the command line args are present*/
	
	public static void checkCmdLineArgs() {
		if(cmdargs.contains(Character.valueOf('i')) && cmdargs.contains(Character.valueOf('l')) && 
		   cmdargs.contains(Character.valueOf('d')) && cmdargs.contains(Character.valueOf('n'))) {
			log.FmtAndLogMsg("Required Command Line Parameters Present");
		}
		else {
			log.FmtAndLogMsg("Required Command Line Parameters Missing");
			log.FmtAndLogMsg("Calling showUsageAndExit() method to exit");
			showUsageAndExit();
		}
	}
	
	
	/*Create PurgeEvent object and get DB connection*/

	public static void getDBConnection(String s_log_file) throws Exception {

		try {
			// Get ini file values for DB connection

			String s_dbhost = ini.getINIVar("database.host").trim();
			log.FmtAndLogMsg("dbHost : " + s_dbhost);

			String s_dbport = ini.getINIVar("database.port").trim();
			log.FmtAndLogMsg("dbPort : " + s_dbport);

			String s_dbsid = ini.getINIVar("database.sid").trim();
			log.FmtAndLogMsg("dbSID : " + s_dbsid);

			String s_dbuser = ini.getINIVar("database.user").trim();
			log.FmtAndLogMsg("dbUser : " + s_dbuser);

			String s_dbpassword = ini.getINIVar("database.password").trim();

			String sTNSEntry = ini.getINIVar("database.TNSEntry", "");
			log.FmtAndLogMsg("TNS Entry : " + sTNSEntry);
			
			DBConnection DBConnect = new DBConnection();

			
			if (sTNSEntry.length() == 0) {
				// Get DB connection
				con = DBConnect.getConnection(s_dbhost, s_dbsid, s_dbuser,
						s_dbpassword, s_log_file, s_dbport,"");
			} else {
				// use tns entry if available
				con = DBConnect.getConnectionTNS(sTNSEntry, s_dbuser,  s_dbpassword, s_log_file);
			}
		} catch (Exception e) {
			recordError("getDBConnection", e);
		}
	} // end getDBConnection method

	/*
	 * Method to archive the Event table records and 
	 * create a CSV file.
	 */

	public static void getEventDataExtract() throws Exception {

		PreparedStatement ps = null;
		ResultSet rs = null;
		String sql = "";

	/*variables to hold the values of the event table columns*/

		String s_event_id = "";
		String s_event_type_id = "";
		String s_event_dt = "";
		String s_evaluator_id = "";
		String s_user_id = "";
		String s_additional_desc_txt = "";
		recordCount = 0;

		try {

			/* Select records from EVENT db table */

                      // GL 2/22/08 144384 - need to format event_dt explicitly
			sql = "SELECT  event_id,event_type_id,to_char(event_dt,'yyyy-mm-dd hh24:mi:ss') as event_dt,"
					+ "evaluator_id, user_id,additional_desc_txt "
					+ "FROM EVENT "
					+ "WHERE event_dt < to_date( ? ,'MM/DD/YYYY') "
					+ "ORDER BY event_id";

			ps = con.prepareStatement(sql); // Prepare statement to execute

			ps.setString(1, cleanupRecordsDate); // Set param values

			rs = ps.executeQuery(); // Execute statement

			while (rs.next()) {

				recordCount++;
				// Event ID
				s_event_id = rs.getString("event_id");
				if (s_event_id == null) {
					s_event_id = surroundWithQuotes("");
					log
							.FmtAndLogMsg("Event ID value not present in the database");
					v.add(s_event_id); 

				} else {
					s_event_id = surroundWithQuotes(s_event_id);
					System.out.println("s_event_id: " + s_event_id);
					v.add(s_event_id);
				}

				// Event Type ID
				s_event_type_id = rs.getString("event_type_id");
				if (s_event_type_id == null) {
					s_event_type_id = surroundWithQuotes("");
					log
							.FmtAndLogMsg("Event Type ID value not present in the database");
					v.add(s_event_type_id);

				} else {
					s_event_type_id = surroundWithQuotes(s_event_type_id);
					System.out.println("s_event_type_id: " + s_event_type_id);
					v.add(s_event_type_id);
				}

				// Event Date
				s_event_dt = rs.getString("event_dt");
				if (s_event_dt == null) {
					s_event_dt = surroundWithQuotes("");
					log
							.FmtAndLogMsg("Event Date value not present in the database");
					v.add(s_event_dt);

				} else {
					s_event_dt = surroundWithQuotes(s_event_dt);
					System.out.println("s_event_dt: " + s_event_dt);
					v.add(s_event_dt);
				}

				// Evaluator ID
				s_evaluator_id = rs.getString("evaluator_id");
				if (s_evaluator_id == null) {
					s_evaluator_id = surroundWithQuotes("");
					log
							.FmtAndLogMsg("Evaluator ID value not present in the database");
					v.add(s_evaluator_id);

				} else {
					s_evaluator_id = surroundWithQuotes(s_evaluator_id);
					System.out.println("s_evaluator_id: " + s_evaluator_id);
					v.add(s_evaluator_id);
				}

				// User ID
				s_user_id = rs.getString("user_id");
				if (s_user_id == null) {
					s_user_id = surroundWithQuotes("");
					System.out.println("s_user_id: " + s_user_id);
					log
							.FmtAndLogMsg("User ID value not present in the database");
					v.add(s_user_id);
				} else {
					s_user_id = surroundWithQuotes(s_user_id);
					System.out.println("s_user_id: " + s_user_id);
					v.add(s_user_id);
				}

				// Additional Description
				s_additional_desc_txt = rs.getString("additional_desc_txt");
				if (s_additional_desc_txt == null) {
					s_additional_desc_txt = surroundWithQuotesWithoutComma("");
					log.FmtAndLogMsg("Additional Description value for "
							+ s_event_id + " not present in the database");
					v.add(s_additional_desc_txt);

				} else {
					s_additional_desc_txt = surroundWithQuotesWithoutComma(s_additional_desc_txt);
					System.out.println("s_additional_desc_txt: "
							+ s_additional_desc_txt);
					v.add(s_additional_desc_txt);
				}
				v.add("\r");
			} // end loop database records.

			log.FmtAndLogMsg("Total Record Count : " + recordCount);

			/* Checking if archiving the data is required */
			if(performArchive.equalsIgnoreCase("YES")){
				log
				.FmtAndLogMsg("********Calling eventDataArchive Method********");
				eventDataArchive();
				log
				.FmtAndLogMsg("********eventDataArchive Method Completed********");
				
				log
				.FmtAndLogMsg("********Calling fileExistsCheck Method********");
				fileExistsCheck();
				log
				.FmtAndLogMsg("********fileExistsCheck Method Completed********");

				/* Calling method to generated header file data */

				log
						.FmtAndLogMsg("********Calling getHeaderFileData Method********");
				header_file_data = getHeaderFileData();
				log
						.FmtAndLogMsg("********getHeaderFileData Method Completed********");
				log
						.FmtAndLogMsg("********Calling openCSVFile Method for Header File********");

				/* Opening a new file for writing header data */

				pe1.openCSVFile(header_filename);
				log
						.FmtAndLogMsg("********Calling writeDataExtract Method for Header File********");

				/* Writing headerfile data */
				pe1.writeDataExtract(header_file_data);
				pe1.writeDataExtract("\r");
				log
						.FmtAndLogMsg("********Calling closeCSVFile Method for Header File********");

				/* Closing Header File */
				pe1.closeCSVFile();
				log
						.FmtAndLogMsg("********Header File Creation Completed Successfully********");
			}
			else{
				log
				.FmtAndLogMsg("********Archiving Not Required********");
			}	
			


			/* Calling method to Delete Event Table Records */

			if (performDBRecordDelete == true) {
				log
						.FmtAndLogMsg("********Calling Delete From Event Table Method********");
				delete_from_event_table();
				log
						.FmtAndLogMsg("********Delete From Event Table Method Completed********");
			} else {
				log.FmtAndLogMsg("Event Table data cannot be deleted");
			}

			/* Calling method to cleanup the input and header files */

			if (performFileDelete == true) {
				log
						.FmtAndLogMsg("********Calling Cleanup Files Method********");
				cleanupFiles();
				log
						.FmtAndLogMsg("********Cleanup Files Method Completed********");
			}

		} catch (Exception e) {
			recordError("getEventDataExtract", e);
		} finally {
			try {
				if (ps != null)
					ps.close();
				if (rs != null)
					rs.close();
			} catch (Exception e) {
				recordError("getEventDataExtract", e);
			} // end catch
		} // end finally
	} // end getEventDataExtract method

	/*
	 * Performing check on the Input File Created before 
	 * deleting db event table records
	 */

	public static void fileExistsCheck(){

		input_filelocation = localfile_path.concat(input_filename);
		System.out.println("input filelocation" + input_filelocation);
		log.FmtAndLogMsg("input_filelocation : " + input_filelocation);
		File file = null;
		/**		
         * OWASP TOP 10 2010 - A4 Path Manipulation
	     * Changes to the below code to fix vulnerabilities
	     **/
		//File file = new File(input_filelocation);
		try{
			file = new File(OWASPSecurity.validationCheck(input_filelocation,OWASPSecurity.DIRANDFILE));
		}catch(Exception e){
					log
					.FmtAndLogMsg("Error Creating input file; Invalid File or Dir");
		}
		long length = file.length();
		System.out.println("inputfile length: " + length);
		log.FmtAndLogMsg("inputfile length : " + length);
		boolean fileExists = file.exists();
		System.out.println("fileExists" + fileExists);
		if (fileExists && length > recordCount) {
			performDBRecordDelete = true;
			log
					.FmtAndLogMsg("Input File Created Successfully; Database Event Table Records can be deleted");
		} else {
			performDBRecordDelete = false;
			log
					.FmtAndLogMsg("Error Creating input file; Database Event Table records would not be deleted");
		}
	}
	
	/* Method to generate header file data */
	public static String getHeaderFileData() throws Exception {
		String headerFileData = "";
		String number_of_records ="";
		if(performDBRecordDelete)
			number_of_records = surroundWithQuotes(Integer
				.toString(recordCount));
		else
			number_of_records =surroundWithQuotes("");
		String input_file = surroundWithQuotes(input_filename);
		String recordDeletionDate = cleanupRecordsDate;
		if(performDBRecordDelete)
			headerFileData = (((input_file.concat(number_of_records))
				.concat("\"Event Table Records Before "))
				.concat(recordDeletionDate)).concat(" would be deleted\"");
		else
			headerFileData = (input_file.concat(number_of_records))
					.concat("\"No Event Table Records would be deleted\"");
		return headerFileData;
	}

	/*
	 * Method to determine the date before which the event 
	 * table records should be deleted
	 */
	public static void getRecordDeletionDate(String deleteRecordsDays) {
		int numOfDays = Integer.parseInt(deleteRecordsDays);
		String year = ""; // year
		String month = ""; // month
		String day = ""; // day

		if (numOfDays >= 0) {
			GregorianCalendar gc = new GregorianCalendar();
			gc.add(Calendar.DATE, 0 - numOfDays);

			day = (Integer.toString(gc.get(Calendar.DATE))).trim();
			if (day.length() < 2) {
				day = "0".concat(day);
			}
			month = (Integer.toString((gc.get(Calendar.MONTH)) + 1)).trim();
			if (month.length() < 2) {
				month = "0".concat(month);
			}
			year = (Integer.toString(gc.get(Calendar.YEAR))).trim();
			cleanupRecordsDate = month + "/" + day + "/" + year;
			System.out.println(cleanupRecordsDate);
			log.FmtAndLogMsg("Cleanup date : " + cleanupRecordsDate);
		}
	}

	public static void eventDataArchive() throws Exception{
		log.FmtAndLogMsg("********Input File Creation Method Called********");
		
		/* opening a file for writing the field values */
		pe1.openCSVFile(input_filename);
		
		ListIterator iter = v.listIterator();
		while (iter.hasNext()) {
			pe1.writeDataExtract((String)iter.next());
		}
		pe1.closeCSVFile();
		log.FmtAndLogMsg("********Input File Creation Completed Successfully********");

	}
	
	/* Method to Delete Event Table Records */

	public static void delete_from_event_table() {
		try {
			String sql = "DELETE FROM EVENT WHERE EVENT_DT < TO_DATE('"
					+ cleanupRecordsDate + "','MM/DD,YYYY')";
			SQLUpdate.RunUpdateStatement(con, sql);
			log.FmtAndLogMsg("Deleted rows in EVENT with event_dt before "
					+ cleanupRecordsDate);
		} catch (Exception e) {
			log
					.FmtAndLogMsg("Error deleting rows in EVENT with event_dt before "
							+ cleanupRecordsDate + e);
		}
	}

	/*Method to get filenames for header/input data files*/

	public static String getFileName(String filetype) {

		Calendar cal = new GregorianCalendar(); // create a Calendar object
		String year = ""; // year
		String month = ""; // month
		String day = ""; // day
		String date = "";
		String s_filetype = filetype; // file type : input or header file
		String filename = "";
		try {

			// get date to append to the filename.
			year = (Integer.toString(cal.get(Calendar.YEAR))).trim(); // 2002
			month = (Integer.toString((cal.get(Calendar.MONTH)) + 1)).trim(); // 0=Jan,
			// 1=Feb,
			// ...
			if (month.length() < 2) {
				month = "0".concat(month);
			}
			day = (Integer.toString(cal.get(Calendar.DAY_OF_MONTH))).trim(); // 1...
			if (day.length() < 2) {
				day = "0".concat(day);
			}
			System.out.println("Current Month: " + month);
			System.out.println("Current Year: " + year);
			System.out.println("Current Day: " + day);
			date = month + day + year;

			/*
			 * CSV Input file Format: PurgeEventInputFile_Date_input.csv CSV
			 * Header file Format: PurgeEventHeader_Date_header.csv
			 */

			if (s_filetype.equalsIgnoreCase("Input"))
				filename = (("PurgeEvent".concat("_")).concat(date))
						.concat("_input.csv");
			else if (s_filetype.equals("Header"))
				filename = (("PurgeEvent".concat("_")).concat(date))
						.concat("_header.csv");

		} catch (Exception e) {
			try {
				recordError("setFileName", e);
			} catch (Exception ex) {
				log.FmtAndLogMsg("Error in getFileName method of : "
						+ ex.toString());
			}
		} // end catch
		return filename;
	} // end getFileName method

	/*
	 * Method to retreive the filename from path.
	 */

	public static String getFileNameFromPath(String file) {
		return file.substring(file.lastIndexOf("\\") + 1, file.length());
	}

	/*
	 * Method to create the CVS fields. surround the fields 
	 * with double qoutes.
	 */

	public static String surroundWithQuotes(String fieldName) {
		String s_field = fieldName;
		s_field = (("\"".concat(s_field)).concat("\"")).concat(",");
		return s_field;
	}

	/* Surround the fields with double qoutes but without an 
	 * ending comma 
	 */
	public static String surroundWithQuotesWithoutComma(String fieldName) {
		String s_field = fieldName;
		s_field = (("\"".concat(s_field)).concat("\""));
		return s_field;
	}

	/*
	 * method to cleanup files older than n days(from Chuck Caplan)
	 */

	public static void cleanupFiles() {

		int numOfDays = Integer.parseInt(cleanupDays);
		File localDirFiles = null;
		if (numOfDays >= 0) {
			// get list of all files in local dir
			
			/**		
	         * OWASP TOP 10 2010 - A4 Path Manipulation
		     * Changes to the below code to fix vulnerabilities
		     **/
			//File localDirFiles = new File(localfile_path);

			try{
				localDirFiles = new File(OWASPSecurity.validationCheck(localfile_path,OWASPSecurity.DIRANDFILE));
			}catch(Exception e){
				log.FmtAndLogMsg("Invalid Directory or File Name");
			}
			String[] localFiles = localDirFiles.list();
			for (int i = 0; i < localFiles.length; i++) {
				File backupFile = new File(localDirFiles.getAbsolutePath()
						+ "\\" + localFiles[i]);
				Date lastModified = new Date(backupFile.lastModified());
				GregorianCalendar gc = new GregorianCalendar();
				gc.add(Calendar.DATE, 0 - numOfDays);
				java.util.Date cleanupDate = gc.getTime();
				if (cleanupDate.after(lastModified)) {
					log.FmtAndLogMsg("Deleted file " + localFiles[i] + ": "
							+ backupFile.delete());
				}
				backupFile = null;
			}
			localDirFiles = null;
		} else {
			log.FmtAndLogMsg("Not deleting any files since cleanupDays = "
					+ cleanupDays);
		}
		log.FmtAndLogMsg("Ended cleanup of files");

	}

	/*
	 * Opens a file for writing. If file exists the data would be appended by
	 * default.
	 */
	public void openCSVFile(String fileName) throws Exception {
		try {
			fileName = localfile_path.concat(fileName);
			
			/**		
	         * OWASP TOP 10 2010 - A4 Path Manipulation
		     * Changes to the below code to fix vulnerabilities
		     **/
			//dataFile = new PrintWriter(new BufferedWriter(new FileWriter(fileName, append)));
			dataFile = new PrintWriter(new BufferedWriter(new FileWriter(OWASPSecurity.validationCheck(fileName,OWASPSecurity.DIRANDFILE), append)));
			
		} catch (Exception e) {
			recordError("openCSVFile", e);
		}
	}

	public void writeDataExtract(String str) {
		if (dataFile != null) {
			dataFile.print(str);
			dataFile.flush();
		}
	}

	public void closeCSVFile() {
		if (dataFile != null) {
			dataFile.flush();
			dataFile.close();
			dataFile = null;
		}
	}
} // main class
