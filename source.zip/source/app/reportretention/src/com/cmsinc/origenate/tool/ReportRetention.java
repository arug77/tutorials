/****************************************************************************************************************
   Company: First American CMSI
    Product: Origenate
    Version: Beta
    Author: Akash Pandya
    Copyright (c) 2002. All rights reserved

    Description: Manages Retention Reports
                 Check start.bat file to start this process.
*******************************************************************************************************************/
package com.cmsinc.origenate.tool;

import java.io.File;
import java.util.*;
import java.sql.ResultSet;
import java.sql.PreparedStatement;

import com.cmsinc.origenate.util.IniFile;
import com.cmsinc.origenate.util.LogMsg;
import com.cmsinc.origenate.util.DBConnection;
import com.cmsinc.origenate.util.OWASPSecurity;

public class ReportRetention {
	  //Set debugger
  private static boolean b_debugger = true;
  private static java.sql.Connection con;
  private static LogMsg log = new LogMsg();
  private static  String s_log_file = "";
  private static String iniFileNm = "c:\\development\\origenate\\origenate.ini";
  private static int evaluatorId = 0;
  private static String localfile_path="";
  private static Character ch;
  private static Vector cmdargs = new Vector(10,10);
  
  /***************************************************************/
   /*              Main method to call Report Retention process      */
   /***************************************************************/
  public static void main(String args[]) throws Exception {

    if (args.length > 0) {
		for (int i = 0; i < args.length; ++i) {
			if ((args[i].charAt(0) != '-') && (args[i].length() > 1)) {
				showUsageAndExit();
			}
			ch = Character.valueOf(args[i].charAt(1));
			cmdargs.add(ch);
			switch (args[i].charAt(1)) {
			case 'i':
				iniFileNm = args[i].substring(2);
				log.FmtAndLogMsg("iniFile name: " + iniFileNm);
				break;
			case 'l':
				localfile_path = args[i].substring(2);
				log.FmtAndLogMsg("Location of generated reports: " 	+ localfile_path);
				break;
			case 'e':
				evaluatorId = Integer.parseInt(args[i].substring(2));
				log.FmtAndLogMsg("For Evaluator: " 	+ evaluatorId);
				break;
			default:
				log.FmtAndLogMsg("Unknown parameter: " + args[i]);
				showUsageAndExit();
				break;
			}
		}

		 /* Check if the required command line args are present*/
		try {
			log.FmtAndLogMsg("********Calling checkCmdLineArgs Method********");
			checkCmdLineArgs();
		} catch (Exception e) {
			log.FmtAndLogMsg("Error in checkCmdLineArgs method of : "+ e.toString());
		}
		log.FmtAndLogMsg("********checkCmdLineArgs Method Completed********");
    //Create object of Report Retention process
    new ReportRetention();
  }

  }
  /***************************************************************/
  /* Create Report Retention obejct and get DB connection         */
  /***************************************************************/
  private static void getDBConnection(String s_iniFile) throws Exception {

    try {
      //Get ini file values for DB connection
      IniFile ini = new IniFile();
      ini.readINIFile(s_iniFile);
      String s_host = ini.getINIVar("database.host");
      String s_port = ini.getINIVar("database.port");
      String s_sid = ini.getINIVar("database.sid");
      String s_user = ini.getINIVar("database.user");
      String s_password = ini.getINIVar("database.password");
      String sTNSEntry = ini.getINIVar("database.TNSEntry", "");
      s_log_file = ini.getINIVar("logs.reportretention_log_file");
      
      DBConnection DBConnect = new DBConnection();
      
	  log.FmtAndLogMsg("********log file: " + s_log_file +" ********");
	  log.openLogFile(s_log_file);
      if (sTNSEntry.length() == 0) {
    	  con = DBConnect.getConnection( s_host,  s_sid, s_user,  s_password, s_log_file, s_port,"");
      } else {
    	  // use tns entry if available
    	  con = DBConnect.getConnectionTNS(sTNSEntry, s_user,  s_password, s_log_file);
      }
    } catch (Exception e) {
      recordError(e, "getDBConnection");
    }
  }

  /***************************************************************/
  /*                    Reocord error                            */
  /***************************************************************/
  private static void recordError(Exception err, String classStr) throws Exception  {
    try {
      if (b_debugger)
        err.printStackTrace();
      log.FmtAndLogMsg("Error in " + classStr + " method of : " + err.toString());
      throw new Exception("Error in " + classStr + " method of : " + err.toString());
    } catch (Exception e) {
      log.FmtAndLogMsg("Error in recordError method of : " + e.toString());
    }
  }

  public ReportRetention() throws Exception  {
    try {
      //Get db connection
      getDBConnection(iniFileNm);
   	  deleteReports();
    } catch (Exception ex) {
      recordError(ex, "ReportRetention");
      System.exit(0);
    }
  }


    /***************************************************************/
    /*    Check  Rention days and delete old record and files      */
    /*    at present evaluator id is not used in this method       */
    /***************************************************************/
    private static void deleteReports() throws Exception {
    	PreparedStatement ps = null, ps1 = null,ps2=null;
    	ResultSet rs = null;
    	String sql = "";

    	try {
    		// get db connection; if it is closed
    		getDBConnection(iniFileNm);

    		log.FmtAndLogMsg("*** Report Retention process started successfully. ****");
    		
    		//delete files first
    		sql = "select FILE_PATH_TXT from SAVED_REPORT " +
					"where REPORT_GENERATION_LOG_ID in " +
					"(select rgl.REPORT_GENERATION_LOG_ID " +
					"from report_generation_log rgl, users u, config_reports cr " +
					"where u.USER_ID = rgl.USER_ID ";
    			sql = sql + (evaluatorId!=0? 
    				"and	  cr.EVALUATOR_ID=? ":"");
    			sql = sql + 
    				"and	  u.EVALUATOR_ID=cr.EVALUATOR_ID " +
    				"and	  cr.REPORT_ID = rgl.REPORT_ID " +
    				"and	  (trunc(sysdate,'dd')-trunc(GENERATION_DT,'dd'))>nvl(cr.RETENTION_DAYS_NUM,365))";
    		// prepare statement to execute
    		ps = con.prepareStatement(sql);
    		if(evaluatorId!=0){
    			ps.setInt(1, evaluatorId);
    		}
    		// execute statement
    		rs = ps.executeQuery();

    		log.FmtAndLogMsg("Fetching records...");
    		// get file names to delete
    		while (rs.next()) {
    			String fileName = rs.getString("FILE_PATH_TXT");
    			if(fileName!=null && !fileName.equalsIgnoreCase(""))
    				deleteFile(fileName);
    		}
    		
    		//delete rows from table SAVED_REPORT
    		sql = "delete from SAVED_REPORT " +
    				"where REPORT_GENERATION_LOG_ID in " + 
					"(select rgl.REPORT_GENERATION_LOG_ID " +
					"from report_generation_log rgl, users u, config_reports cr " +
					"where u.USER_ID = rgl.USER_ID ";
    			sql = sql + (evaluatorId!=0? 
    				"and  cr.EVALUATOR_ID=? ":"");
    			sql = sql + 
    				"and  u.EVALUATOR_ID=cr.EVALUATOR_ID " +
    				"and  cr.REPORT_ID = rgl.REPORT_ID " +
    				"and  (trunc(sysdate,'dd')-trunc(GENERATION_DT,'dd'))> nvl(cr.RETENTION_DAYS_NUM,365))";
    	    // prepare statement to execute
    	    ps1 = con.prepareStatement(sql);
    		if(evaluatorId!=0){
    			ps1.setInt(1, evaluatorId);
    		}
    	    // execute statement and log result
    	    log.FmtAndLogMsg(ps1.executeUpdate() + " records deleted from SAVED_REPORT ...");
    	    
			try{ if(rs != null) rs.close(); }catch(Exception e1){e1.printStackTrace();}
		    try{ if(ps != null) ps.close(); }catch(Exception e1){e1.printStackTrace();}
            try{ if(ps1 != null) ps1.close(); }catch(Exception e1){e1.printStackTrace();} 
            

    		log.FmtAndLogMsg("*** Report Retention process completed successfully. ****");
    	}
    	
    	catch (Exception ex) {
    		// roll back changes
    		con.rollback();
    		con.close();
    		// record error
    		recordError(ex, "deleteReports");
    		System.out.println(ex.getMessage());
    		ex.printStackTrace();
			try{ if(rs != null) rs.close(); }catch(Exception e1){e1.printStackTrace();}
		    try{ if(ps != null) ps.close(); }catch(Exception e1){e1.printStackTrace();}
            try{ if(ps1 != null) ps1.close(); }catch(Exception e1){e1.printStackTrace();}
            try{ if(con != null) con.close(); }catch(Exception e1){e1.printStackTrace();} 	
    		System.exit(0);
    	}
    	
    	finally {
		    try{ if(rs != null) rs.close(); }catch(Exception e1){e1.printStackTrace();}
		    try{ if(ps != null) ps.close(); }catch(Exception e1){e1.printStackTrace();}
            try{ if(ps1 != null) ps1.close(); }catch(Exception e1){e1.printStackTrace();}
            try{ if(con != null) con.close(); }catch(Exception e1){e1.printStackTrace();} 			
    	}
    }
	/*
	 * method to cleanup files
	 */

	private static void deleteFile(String fileName) {
				/**		
				 * OWASP TOP 10 2010 - A4 Path Manipulation
				 * Changes to the below code to fix vulnerabilities
				 **/
				//File fileToDel = new File(localfile_path+ "\\" +fileName );
				try{
					File fileToDel = new File(OWASPSecurity.validationCheck(localfile_path + "\\" + fileName,OWASPSecurity.DIRANDFILE));
				
					 if (!fileToDel.exists())
						log.FmtAndLogMsg("File not exist " + fileName);
					 else
						log.FmtAndLogMsg("Deleted file " + fileName + ": "
								+ fileToDel.delete());
					fileToDel = null;				
				
				} catch (Exception e) {
					log.FmtAndLogMsg("ReportRetention deleteFile err ",e);
				}

	}
	/*
	 * Method to inform that expected values are missing on the command line.
	 */

	public static void showUsageAndExit() {
		System.out
				.println("Usage: java com.cmsinc.origenate.tool.ReportRetention");
		System.out
				.println("-i<ini file> -e<evaluatorId>  -l<localfile location>");
		System.out
				.println("------------------------------------------------------------------------------");
		System.out.println("Parameter	Data Type	Required/Optional			Description");
		System.out.println("  -i 		 String			Required		ini file name including the location");
		System.out.println("  -e		 Integer		Optional		Evaluator Id, if not provided process will be done for all evaluators");
		System.out.println("  -l		 String 		Required		Location of generated reports");
		
		System.exit(0);
	}
	/*checks if the command line args are present*/
	
	public static void checkCmdLineArgs() {
		if(cmdargs.contains(Character.valueOf('i')) 
			//&& cmdargs.contains(Character.valueOf('e'))
			&& cmdargs.contains(Character.valueOf('l'))
			) {
			log.FmtAndLogMsg("Required Command Line Parameters Present");
		}
		else {
			log.FmtAndLogMsg("Required Command Line Parameters Missing");
			log.FmtAndLogMsg("Calling showUsageAndExit() method to exit");
			showUsageAndExit();
		}
	}
}