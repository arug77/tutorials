#!/bin/sh
#
# Process Report Retention
#


INIFILE=/opt/jrun4/servers/qs84/cfusion-ear/cfusion-war/config/origenate.ini
LOGFILE=/opt/origenate/qs84/log/reportretention.log
 

nohup java -classpath .:../lib/evidl.jar:../lib/common.jar:../lib/ojdbc6.jar com.cmsinc.origenate.tool.ReportRetention -i$INIFILE -e<evaluator_id> -l$LOGFILE  
exit 0
