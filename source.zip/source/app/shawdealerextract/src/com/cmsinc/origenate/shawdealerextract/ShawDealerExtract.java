/*
 * Shaw Dealer Extract
 * Created: July 05 2011
 * Author: Brandon Perkins
 * Description: This program generates a 
 * SHAW dealer data extract and saves the data
 * in xml format
 */

package com.cmsinc.origenate.shawdealerextract;

import com.cmsinc.origenate.util.*;
import java.io.*;
import java.net.*;
import java.sql.Date;
import java.sql.*;
import java.util.*;
import javax.net.ssl.*;
import javax.xml.transform.*;
import javax.xml.transform.stream.*;
import sun.net.TelnetOutputStream;
import sun.net.ftp.FtpClient;
import java.text.SimpleDateFormat;
import com.cmsinc.origenate.originator.extract.OriginatorDataExtract;
import com.cmsinc.origenate.util.ConnectionUtils;


public class ShawDealerExtract 
{
    private static char ch; //cmd line character
	private static LogMsg log = new LogMsg(); //log
	private static ShawDealerExtract s1 = new ShawDealerExtract(); //class instance
	private static String evaluator_id; //evaluator_id
	private static Connection con; // db connection
	//private static String input_filename; // input filename
	private static String s_iniFile; //ini file location
	private static String dir; //output directory
	private static String queryDays = "1"; //days to pull dealers
	private static String stylesheet="";//stylsheet 
	private static String sequenceOwner ="";//ini.getINIVar("database.user").trim();
	private static String xmlout="";//xml for each dealer;
	private static String nameoffile="";
	private static IniFile ini = new IniFile();
	private static Vector cmdargs = new Vector(10,10);	//Vector to hold the command line args
	private static boolean seperateFilePerOriginator = false;//if set to 1 create a seperate file for each origenator

	public static void main(String[] args)
	{
	/***************************GATHER COMMAND LINE PARAMETERS*************************/
		String s_log_file = "";
		if(args.length>0)
		{
			for (int i=0; i < args.length; ++i) 
			{
				if((args[i].charAt(0) !='-') && (args[i].length() > 1)) 
				{
					showUsageAndExit();
				}
				ch = Character.valueOf(args[i].charAt(1));
				cmdargs.add(ch);
				switch (args[i].charAt(1))
				{
					case 'i':
						s_iniFile = args[i].substring(2); // ini file
						try
						{
							ini.readINIFile(s_iniFile);
							s_log_file = ini.getINIVar("logs.Sdealer_extract_log_file", "");
							if(s_log_file.length() > 0)
							{
								log.openLogFile(s_log_file);
							}
						}
						catch (Exception e)
						{
							log.FmtAndLogMsg("Caught exception reading ini file '"+s_iniFile+"' :"+e.toString());
						}
						log.FmtAndLogMsg("\r");
						log.FmtAndLogMsg("Starting Shaw Extract Tool");
						log.FmtAndLogMsg("\r");
						log.FmtAndLogMsg("iniFile name: " + s_iniFile);
						break;
					case 'e':
						evaluator_id = args[i].substring(2); // evaluator id
						log.FmtAndLogMsg("evaluator id : " + evaluator_id);
						break;
					case 'd':
						dir = args[i].substring(2); // directory location
						log.FmtAndLogMsg("Output directory: " + dir);
						break;
					case 's':
						stylesheet = args[i].substring(2); // stylesheet
						log.FmtAndLogMsg("file stylesheet: "
							+ stylesheet);
						break;
					case 'q':
						queryDays = args[i].substring(2); // days to pull
						//new dealers from current day
						log.FmtAndLogMsg("Number of days to pull (from today):"+queryDays);
						break;
					case 'n':
						nameoffile = args[i].substring(2); // days to pull
						//new dealers from current day
						log.FmtAndLogMsg("File Name is:"+nameoffile);
						break;
					case 'f':
						try{
							seperateFilePerOriginator = args[i].substring(2).equals("1"); // whether or not to create a seperate file per originator. default to false
						//new dealers from current day
							log.FmtAndLogMsg("Create a seperate file for each origenator:"+seperateFilePerOriginator);
							System.out.println("seperateFilePerOriginator " +seperateFilePerOriginator);
						}
						catch (Exception e) {
						   log.FmtAndLogMsg("Seperate file per origenator (f) option must be 0 or 1: "+e.toString());
						   showUsageAndExit();
						}
						
						break;
					default:
						log.FmtAndLogMsg("Unknown parameter: " + args[i]);
						showUsageAndExit();
						break;
				}
			}
		}
		/*************************GATHERING COMMAND LINE PARAMETERS COMPLETE ******************/

		/* Check if the required command line args are present*/
		try 
		{
			log.FmtAndLogMsg("********Calling checkCmdLineArgs Method********");
			checkCmdLineArgs();
		} 
		catch (Exception e) 
		{
			log.FmtAndLogMsg("Error in checkCmdLineArgs method of : "
				+ e.toString());
		}
		log.FmtAndLogMsg("********checkCmdLineArgs Method Completed********");

		/*GET DB CONNECTION */
		try 
		{
			log.FmtAndLogMsg("********Calling getDBConnection Method********");
			getDBConnection(s_log_file);
		} 
		catch (Exception e) 
		{
			log.FmtAndLogMsg("Error in getDBConnection method of : "
				+ e.toString());
		}
		log.FmtAndLogMsg("********getDBConnection Method Completed********");

		/*Run getDataExtract Method */

		try 
		{
			//get sequence owner first.
			sequenceOwner = ini.getINIVar("database.user").trim();
			OriginatorDataExtract.OriginatorContainer odeVars = new OriginatorDataExtract.OriginatorContainer();
			odeVars.setSeperateFilePerOriginator(seperateFilePerOriginator);
			odeVars.setEvaluatorId(evaluator_id);
			odeVars.setExtractFileName(nameoffile);
			odeVars.setQueryDays(queryDays);
			odeVars.setStylesheet(stylesheet);
			odeVars.setDir(dir);
			odeVars.setSequenceOwner(sequenceOwner);
			odeVars.setQueryDaysFlg(true);
			odeVars.setQueryOriginatorIdFlg(false); //hard code to false, used in OriginatorExtract standalone app only
			odeVars.setDebugLvl(Integer.parseInt(ini.getINIVar("debug.genx_debug_lvl","0")));
			
			OriginatorDataExtract ode = new OriginatorDataExtract();
			log.FmtAndLogMsg("Begin shaw dealer extract");
			ode.runExtract(con,log,odeVars);
			//ode.runExtract(con, log, seperateFilePerOriginator, evaluator_id, nameoffile, queryDays, stylesheet, dir, sequenceOwner);
			log.FmtAndLogMsg("End shaw dealer extract");

		} 
		catch (Exception e) 
		{
			log.FmtAndLogMsg("Error in getDataExtract method of : " + e.toString());
		} finally {
			ConnectionUtils.closeConnection(con);
		}
		log.FmtAndLogMsg("getDataExtract Method Completed");
		log.FmtAndLogMsg("********SHAW Dealer Extract Tool Completed********");
		System.exit(0);
	}
	/*Method checks if the command line args are present*/
	
	public static void checkCmdLineArgs() 
	{
		if(cmdargs.contains(Character.valueOf('i')) && cmdargs.contains(Character.valueOf('d')) && 
			cmdargs.contains(Character.valueOf('e')) && cmdargs.contains(Character.valueOf('n')))
		{
			log.FmtAndLogMsg("Required Command Line Parameters Present");
		}
		else 
		{
			log.FmtAndLogMsg("Required Command Line Parameters Missing");
			log.FmtAndLogMsg("Calling showUsageAndExit() method to exit");
			showUsageAndExit();
		}
	}

	/*
	 * Method to inform that expected values are missing on the command line.
	 */

	public static void showUsageAndExit() 
	{
		System.out
			.println("Usage: java com.cmsinc.origenate.shawdealerextract.ShawDealerExtract");
		System.out
			.println("-e<evaluator id> -i<ini file> -d<directory> -q<Days to include> -s<Stylesheet> -f<Create Seperate Files Per Dealer>");
		System.out
			.println("------------------------------------------------------------------------------");
		System.out.println("Parameter	Data Type	Required/Optional				Description");
		System.out.println("  -e 		 Integer	Required						Evaluator ID");
		System.out.println("  -i 		 String		Required						ini file name including the location");		
		System.out.println("  -d		 String		Required						Output Directory ");
		System.out.println("  -q		 Integer	Optional						Number of days from current date to include dealer");
		System.out.println("  -s		 String		Optional						Stylesheet to pass in");
		System.out.println("  -n		 String		Required						Name of output file");
		System.out.println("  -f		 Integer	Optional						Set to 1 to generate a seperate file for each Dealer");
		System.exit(0);
	}

	/*get DB connection Method*/

	public static void getDBConnection(String s_log_file) throws Exception 
	{

		try 
		{
			// Get ini file values for DB connection

			String s_dbhost = ini.getINIVar("database.host").trim();
			log.FmtAndLogMsg("dbHost : " + s_dbhost);

			String s_dbport = ini.getINIVar("database.port").trim();
			log.FmtAndLogMsg("dbPort : " + s_dbport);

			String s_dbsid = ini.getINIVar("database.sid").trim();
			log.FmtAndLogMsg("dbSID : " + s_dbsid);

			String s_dbuser = ini.getINIVar("database.user").trim();
			log.FmtAndLogMsg("dbUser : " + s_dbuser);

			String s_dbpassword = ini.getINIVar("database.password").trim();
			
			String sTNSEntry = ini.getINIVar("database.TNSEntry");
			log.FmtAndLogMsg("TNSEntry : " + sTNSEntry);
			
			
			DBConnection DBConnect = new DBConnection();
			
			if (sTNSEntry == null) 
			{
				con = DBConnect.getConnection(s_dbhost, s_dbsid, s_dbuser, s_dbpassword, s_log_file, s_dbport,"");
			} 
			else 
			{
				// use tns entry if available
				con = DBConnect.getConnectionTNS(sTNSEntry, s_dbuser,  s_dbpassword, s_log_file);
			}
		} 
		catch (Exception e) 
		{
			log.FmtAndLogMsg("Failed to Connect to DB:"+e);
			recordError("getDBConnection", e);
		}
	} // end getDBConnection method

	
	//Borrowed from ODE Extract
	public static void recordError(String methodName, Exception err)
		throws Exception 
	{
		try 
		{
			log.FmtAndLogMsg("Error occured in " + methodName + " method of : "	+ err.toString());
			throw new Exception("    Error occured in " + methodName + " method of : " + err.toString());
		} 
		catch (Exception e) 
		{
			log.FmtAndLogMsg("Error in reportError method of : " + e.toString());
		}

	}
}