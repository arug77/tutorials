echo $SHAWPARAM
nohup java -classpath .:../lib/common.jar:../lib/ojdbc6.jar \
 com.cmsinc.origenate.shawdealerextract.ShawDealerExtract $SHAWPARAM &
