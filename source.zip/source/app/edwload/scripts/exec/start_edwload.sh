# Start EDW Load Process
# Starts the EDW Load program with the
# provided EDW file. The startup script
# accepts 4 params, which are the environment
# name, the name of the EDW config file, the DB to
# run against and the name of the
# EDW file. The EDW config file is expected
# to be located in the ORCONFIG directory. The EDW
# zip file is expected to be located in the
# EDWLOADDIR directory, specified in the EDW
# config file.
# Examples:
#
# start_edwload.sh or_dev88 dev_edwloadconfig.sh ORIG FULLORIG20131014.zip
# start_edwload.sh or_dev88 dev_edwloadconfig.sh EVAL INCREVAL20131014.zip


if [ $# -eq 4 ] 
then
. /opt/origenate/$1/config/usrconfig.sh
. /opt/origenate/$1/config/$2
export EDWCLASSPATH=".:$ORAPPS/lib/common.jar:$ORAPPS/lib/crypto.jar:$ORAPPS/lib/ojdbc6.jar:$ORAPPS/lib/commons-compress-1.4.1.jar:$ORAPPS/lib/commons-io-1.3.1.jar:$ORAPPS/lib/commons-codec-1.6.jar:$ORAPPS/lib/IngrianNAE-8.3.1.000.jar:$ORAPPS/lib/Ingrianlog4j-api-2.1.jar:$ORAPPS/lib/Ingrianlog4j-core-2.1.jar"
export EDWPARAMS="-n${EDWLOADNUMTHREADS:-1} -T$EDWLOADTNSENTRY -z$EDWLOADDIR/$4 -l$EDWLOADLOG -d${EDWLOADDELETE:-none} -b${EDWLOADBATCHSIZE:-200}"
if [ ${EDWLOADDECRYPTFLG:-false} = true ]
then
export EDWPARAMS="$EDWPARAMS -F$EDWLOADDECRYPTFLG"
fi
if [ $3 = EVAL ]
then
echo `date` "Running EVAL EDW Load with file: $4"
java -cp $EDWCLASSPATH com.cmsinc.origenate.tool.EDWLoad $EDWPARAMS -u$EDWLOADEVALUSER -p$EDWLOADEVALPASS
else
echo `date` "Running ORIG EDW Load with file: $4"
java -cp $EDWCLASSPATH com.cmsinc.origenate.tool.EDWLoad $EDWPARAMS -u$EDWLOADUSER -p$EDWLOADPASS
fi
else
echo `date` "Invalid number of parameters. Must provide Environment Name, EDW Config file name, DB type (ORIG or EVAL), and name of EDW file."
echo `date` "Example: start_edwload.sh or_dev88 dev_edwloadconfig.sh ORIG FULLORIG20131014.zip"
fi
