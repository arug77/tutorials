#EDW Load Configuration file. This file must be modified
#for each lender using the EDW Load Process. The modified
#configuration file should be put into the lender's
#ORCONFIG directory.

#Set this Entry to true, if we need decrypted data
#Used in Origenate 8.6 and up only. Remove or leave
#as "false" in lower versions of Origenate.
#Valid values "true" and "false"
export EDWLOADDECRYPTFLG="false"

#Determines what data to delete
#Valid values "none", "ziponly", "all"
export EDWLOADDELETE="none"

#Origenate Database Information
export EDWLOADUSER="ORIGDV87"
export EDWLOADPASS="ORIGDV87"

#Evaluate Database Information
export EDWLOADEVALUSER="EVAL_ORIGDV87"
export EDWLOADEVALPASS="EVAL_ORIGDV87"

#Database TNS Entry
export EDWLOADTNSENTRY="(DESCRIPTION=(ADDRESS_LIST=(ADDRESS=(PROTOCOL=tcp)(HOST=cmdb01)(PORT=1521))(ADDRESS=(PROTOCOL=tcp)(HOST=cmdb01)(PORT=1521))(LOAD_BALANCE=ON)(FAILOVER=ON))(CONNECT_DATA=(SERVICE_NAME=CMSIDB2)))"

#Location of EDW zip files
export EDWLOADDIR=/opt/origenate/$ENV/data/edw/prodtest/edwload

#Log file for EDW Load process
export EDWLOADLOG=/opt/origenate/$ENV/log/edwload.log

#Performance fields. Changing the number of threads
#or the batch size can affect performance.
#Using too many threads or too large of a batch size
#may negatively affect performance. In practice, no
#more than 10 threads and a batch size of 400 is
#recommended.

#Number of threads to use
export EDWLOADNUMTHREADS=5

#Number of SQL statements to execute
#in each batch
export EDWLOADBATCHSIZE=200
