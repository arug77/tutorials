package com.cmsinc.origenate.tool;

/**
 * Class to hold a key/value pair.
 * 
 * @author michaelsw
 * 
 */
public class KeyValueContainer {
	private String key;
	private String value;
	
	/**
	 * Instantiates a KeyValue Container object.
	 * 
	 * @param key
	 *            Key field. If null, it will be set to empty string.
	 * @param value
	 *            Value field. If null, it will be set to empty string.
	 */
	public KeyValueContainer(String key, String value) {
		if (key == null) {
			key = "";
		}
		if (value == null) {
			value = "";
		}
		this.key = key;
		this.value = value;
	}
	
	/**
	 * @return the key
	 */
	public String getKey() {
		return key;
	}
	
	/**
	 * @param key
	 *            the key to set
	 */
	public void setKey(String key) {
		this.key = key;
	}
	
	/**
	 * @return the value
	 */
	public String getValue() {
		return value;
	}
	
	/**
	 * @param value
	 *            the value to set
	 */
	public void setValue(String value) {
		this.value = value;
	}
	
	/**
	 * Two KeyValueContainers are equal if and only if
	 * they are the same object or their key and value
	 * have the same string value.
	 */
	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		
		if (other instanceof KeyValueContainer) {
			KeyValueContainer otherAssertion = (KeyValueContainer) other;
			if (this.key.equals(otherAssertion.key) && this.value.equals(otherAssertion.value)) {
				return true;
			}
		}
		
		return false;
	}
	
	public int hashCode() {
		int hash = 5;
		hash = 11 * hash + key.hashCode();
		hash = 17 * hash + value.hashCode();
		return hash;
	}
	
	/**
	 * Compares one KeyValueContainer to another Object.
	 * If the other object is not a KeyValueContainer, returns
	 * value greater than 0. Otherwise, returns the comparison
	 * of the key fields. If the keys are the same, the comparison
	 * of the value fields is used.
	 * 
	 * @param other
	 *            Object with which to compare
	 * @return Integer greater than 0 if this object is greater than
	 *         the other, less than 0 if the other object is greater, or 0
	 *         if they are equal.
	 */
	public int compareTo(Object other) {
		if (!(other instanceof KeyValueContainer)) {
			return 1;
		}
		
		KeyValueContainer otherAssertion = (KeyValueContainer) other;
		if (this.key.equals(otherAssertion.key)) {
			return this.value.compareTo(otherAssertion.value);
		} else {
			return this.key.compareTo(otherAssertion.key);
		}
	}
}
