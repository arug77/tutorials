package com.cmsinc.origenate.tool;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.sql.BatchUpdateException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.zip.ZipEntry;

import com.cmsinc.origenate.util.LogMsg;
import com.cmsinc.origenate.util.Query;
import com.cmsinc.origenate.util.SQLSecurity;
import com.cmsinc.origenate.util.TarFileReader;

/**
 * Thread class for the EDW Load process. This thread will process
 * either a ZIP or a TAR file for the EDW Load process.<br />
 * For an EDW ZIP file, multiple threads can instantiate and run this
 * class. For an EDW TAR file, only a single instance of this class
 * can be instantiated and run.
 * 
 * @author michaelsw
 * 
 */
@SuppressWarnings("unused")
public class EDWLoadThread implements Runnable {
	private EDWLoad main;
	private String threadName;
	private Connection con;
	private LogMsg log_obj;
	private boolean closeConnection = true;
	private int batchSize = EDWLoad.BATCH_SIZE;
	
	/**
	 * Instantiates a new EDWLoadThread object. This constructor
	 * accepts database connection information and instantiates
	 * a new database connection. This will force the thread to
	 * close its DB connection upon completion.
	 * 
	 * @param main
	 *            The EDWLoadObject that instantiated this thread
	 * @param threadName
	 *            The name of the thread, like "THREAD1 "
	 * @param sConStr
	 *            DB Connection string
	 * @param sUser
	 *            DB User
	 * @param sPass
	 *            DB Password; must be plaintext
	 * @param log_obj
	 *            LogMsg object for logging
	 * @throws Exception
	 *             If there was an exception initializing
	 *             the database connection
	 */
	public EDWLoadThread(EDWLoad main, String threadName,
			String sConStr, String sUser, String sPass, LogMsg log_obj)
			throws Exception {
		this.main = main;
		this.threadName = threadName;
		this.con = DriverManager.getConnection(sConStr, sUser, sPass);
		this.log_obj = log_obj;
		this.closeConnection = true;
		this.batchSize = this.main.getBatchSize();
	}
	
	/**
	 * Instantiates a new EDWLoadThread object. This constructor
	 * accepts an already open database connection. Since the
	 * connection does not belong to this object, it will not be
	 * closed upon completion.
	 * 
	 * @param main
	 *            The EDWLoadObject that instantiated this thread
	 * @param threadName
	 *            The name of the thread, like "THREAD1 "
	 * @param con
	 *            An open Connection object
	 * @param log_obj
	 *            LogMsg object for logging
	 */
	public EDWLoadThread(EDWLoad main, String threadName,
			Connection con, LogMsg log_obj)
			throws Exception {
		this.main = main;
		this.threadName = threadName;
		this.con = con;
		this.log_obj = log_obj;
		this.closeConnection = false;
		this.batchSize = this.main.getBatchSize();
	}
	
	/**
	 * Kicks off the EDW Load Thread. Depending on whether
	 * the file is a ZIP or TAR file, this method will call
	 * the appropriate logic to process the EDW file.
	 */
	public void run() {
		try {
			if (main.isTar()) {
				updateDbWithTar();
			} else {
				updateDbWithZip();
			}
		} catch (Exception e) {
			main.threadFailed();
			e.printStackTrace();
		} finally {
			try {
				if (closeConnection && con != null) {
					con.close();
				}
			} catch (Exception e) {
			}
			main.decrementThreadCount();
		}
	}
	
	/**
	 * Processes an EDW tar file. The method
	 * will continue until there are no more tables in the tar file.<br />
	 * If the parent class has the delete zipped flag set, then each table will
	 * first have its data deleted before the process adds the new data.<br />
	 * This process uses the batch size from the parent class in order to determine
	 * what size batches to use when running the SQL statements.
	 * 
	 * @throws Exception
	 *             If there is any issue in the process. This may happen
	 *             when deleting data, when reading from the tar, when parsing the information
	 *             in the tar, or when running the SQL statements to put the data into the DB.
	 */
	private void updateDbWithTar() throws Exception {
		int numProcessed = 0;
		TarFileReader reader = null;
		try {
			// Get the TAR reader from the main class.
			reader = main.getTarArchive();
			
			// The main class will return null if another thread
			// has already retrieved the TAR reader.
			if (reader == null) {
				log_obj.FmtAndLogMsg(threadName + "The EDW TAR file has already been retrieved. " +
						"Exiting thread.");
				return;
			}
			
			// Loop through each entry in the TAR file.
			while (!main.hasThreadFailed() && reader.moveToNextEntry()) {
				String tableName = reader.getFileName().
						substring(0, reader.getFileName().lastIndexOf("."));
				
				PreparedStatement ps = null;
				String tableQuery = "";
				ArrayList<String> varsInLine = new ArrayList<String>();
				try {
					log_obj.FmtAndLogMsg(threadName + "BEGIN Processing Table: " + tableName);
					
					// If the delete flag is set, delete from this table
					if (main.getDeleteFlag().equalsIgnoreCase(EDWLoad.DELETE_ZIPPED)) {
						log_obj.FmtAndLogMsg(threadName + "BEGIN Delete From Table: " + tableName);
						deleteFromTable(tableName);
						log_obj.FmtAndLogMsg(threadName + "END Delete From Table: " + tableName);
					}
					
					String line = "";
					ArrayList<KeyValueContainer> cols = getColsInTable(tableName);
					tableQuery = buildQueryForTable(tableName, cols);
					
					// Create a PreparedStatement that will be reused
					// for each statement run for this table.
					
					/**
					 * OWASP TOP 10 2010 - A1 High SQL Injection
					 * TTP 324955 Security Remediation Fortify Scan false positive
					 **/					
					ps = con.prepareStatement(SQLSecurity.basicSanitize(tableQuery));
					//ps = con.prepareStatement(ESAPI.encoder().encodeForSQL( new OracleCodec(), tableQuery.toString()));
					
					int i = 1;
					while ((line = reader.readLine()) != null) {
						// If the reader gave us a blank line for
						// some reason, just move onto the next
						// record (if there is one).
						if (line.equals("")) {
							continue;
						}
						
						varsInLine = getVarsInLine(line);
						
						// Check that the number of columns in the table
						// is the same as the number in the EDW file. If
						// not, then it's possible that the DB is not in
						// sync with the DB that the EDW used.
						if (cols.size() != varsInLine.size()) {
							throw new Exception("Number of columns in table (" +
									cols.size() + ") is not equal to the number " +
										"of columns in the EDW (" +
										varsInLine.size() + ").");
						}
						
						// Set the vars in the PreparedStatement and
						// add it to the batch to execute later.
						processLine(varsInLine, ps, cols);
						ps.addBatch();
						
						// If the batch is full, execute it
						if (i % batchSize == 0) {
							try {
								ps.executeBatch();
							} catch (BatchUpdateException ex) {
								// Log the query and give a range where it failed
								int batchStart = 1 + (int) Math.ceil(
										i / (double) batchSize - 1.0)
										* batchSize;
								log_obj.FmtAndLogMsg(threadName + "Table Query: " + tableQuery);
								log_obj.FmtAndLogMsg(threadName + "Failed between Rows: "
										+ batchStart
										+ " and " + i);
								throw ex;
							}
						}
						i++;
					}
					
					// Unless the batch was executed already after
					// the last row, then execute the batch now.
					if (i > 1 && i % batchSize != 1) {
						try {
							ps.executeBatch();
						} catch (BatchUpdateException ex) {
							// Log the query and give a range where it failed
							int batchStart = 1 + (int) Math.ceil(
									i / (double) batchSize - 1.0) * batchSize;
							log_obj.FmtAndLogMsg(threadName + "Table Query: " + tableQuery);
							log_obj.FmtAndLogMsg(threadName + "Failed between Rows: " + batchStart
									+ " and " + i);
							throw ex;
						}
					}
					ps.close();
					log_obj.FmtAndLogMsg(threadName + "END Processing Table: " + tableName
							+ "; Rows Processed: " + (i - 1));
					numProcessed++;
				} catch (Exception e) {
					log_obj.FmtAndLogMsg(threadName + "ERROR Processing Table: " + tableName + "; "
							+ e.toString(), e);
					throw e;
				} finally {
					try {
						if (ps != null) {
							ps.close();
						}
					} catch (Exception e) {
					}
				}
			}
		} catch (Exception e) {
			throw e;
		} finally {
			try {
				if (reader != null) {
					reader.close();
				}
			} catch (Exception e) {
			}
		}
		
		// Tell the main thread how many tables were processed by this thread
		main.addTablesExported(numProcessed);
		
		log_obj.FmtAndLogMsg(threadName + "COMPLETE. Num tables processed: " + numProcessed);
	}
	
	/**
	 * Processes an EDW zip file. This process supports multithreading with the
	 * parent class distributing the tables among any running threads. The method
	 * will continue until there are either no more tables or another of its
	 * sibling threads has failed.<br />
	 * If the parent class has the delete zipped flag set, then each table will
	 * first have its data deleted before the process adds the new data.<br />
	 * If this thread fails for any reason, a flag is set in the parent telling
	 * any other threads to exit gracefully.<br />
	 * This process uses the batch size from the parent class in order to determine
	 * what size batches to use when running the SQL statements.
	 * 
	 * @throws Exception
	 *             If there is any issue in the process. This may happen
	 *             when deleting data, when reading from the zip, when parsing the information
	 *             in the zip, or when running the SQL statements to put the data into the DB.
	 */
	private void updateDbWithZip() throws Exception {
		int numProcessed = 0;
		ZipEntry entry = null;
		
		// Get the next table file from the zip.
		// If another thread has failed, don't get another table.
		while (!main.hasThreadFailed() && (entry = main.getNextZipEntry()) != null) {
			String tableName = entry.getName().
					substring(0, entry.getName().lastIndexOf("."));
			InputStream is = null;
			PreparedStatement ps = null;
			BufferedReader in = null;
			String tableQuery = "";
			ArrayList<String> varsInLine = new ArrayList<String>();
			try {
				log_obj.FmtAndLogMsg(threadName + "BEGIN Processing Table: " + tableName);
				
				// If the delete flag is set, delete from this table
				if (main.getDeleteFlag().equalsIgnoreCase(EDWLoad.DELETE_ZIPPED)) {
					log_obj.FmtAndLogMsg(threadName + "BEGIN Delete From Table: " + tableName);
					deleteFromTable(tableName);
					log_obj.FmtAndLogMsg(threadName + "END Delete From Table: " + tableName);
				}
				
				is = main.getZipEntryInputStream(entry);
				in =
						new BufferedReader(
								new InputStreamReader(
										is));
				String line = "";
				ArrayList<KeyValueContainer> cols = getColsInTable(tableName);
				tableQuery = buildQueryForTable(tableName, cols);
				
				// Create a PreparedStatement that will be reused
				// for each statement run for this table.
				
				/**
				 * OWASP TOP 10 2010 - A1 High SQL Injection
				 * TTP 324955 Security Remediation Fortify Scan false positive
				 **/				
				ps = con.prepareStatement(SQLSecurity.basicSanitize(tableQuery));
				//ps = con.prepareStatement(ESAPI.encoder().encodeForSQL( new OracleCodec(), tableQuery.toString()));
				
				int i = 1;
				while (!main.hasThreadFailed() && (line = in.readLine()) != null) {
					// If the reader gave us a blank line for
					// some reason, just move onto the next
					// record (if there is one).
					if (line.equals("")) {
						continue;
					}
					varsInLine = getVarsInLine(line);
					
					// Check that the number of columns in the table
					// is the same as the number in the EDW file. If
					// not, then it's possible that the DB is not in
					// sync with the DB that the EDW used.
					if (cols.size() != varsInLine.size()) {
						throw new Exception("Number of columns in table (" +
								cols.size() + ") is not equal to the number " +
										"of columns in the EDW (" +
										varsInLine.size() + ").");
					}
					
					// Set the vars in the PreparedStatement and
					// add it to the batch to execute later.
					processLine(varsInLine, ps, cols);
					ps.addBatch();
					
					// If the batch is full, execute it
					if (i % batchSize == 0) {
						try {
							ps.executeBatch();
						} catch (BatchUpdateException ex) {
							// Log the query and give a range where it failed
							int batchStart = 1 + (int) Math.ceil(
									i / (double) batchSize - 1.0) * batchSize;
							log_obj.FmtAndLogMsg(threadName + "Table Query: " + tableQuery);
							log_obj.FmtAndLogMsg(threadName + "Failed between Rows: " + batchStart
									+ " and " + i, ex);
							throw ex;
						}
					}
					i++;
				}
				
				// Unless the batch was executed already after
				// the last row, then execute the batch now.
				if (!main.hasThreadFailed() && i > 1 && i % batchSize != 1) {
					try {
						ps.executeBatch();
					} catch (BatchUpdateException ex) {
						// Log the query and give a range where it failed
						int batchStart = 1 + (int) Math.ceil(
								i / (double) batchSize - 1.0) * batchSize;
						log_obj.FmtAndLogMsg(threadName + "Table Query: " + tableQuery);
						log_obj.FmtAndLogMsg(threadName + "Failed between Rows: " + batchStart
								+ " and " + i, ex);
						throw ex;
					}
				}
				ps.close();
				in.close();
				is.close();
				
				log_obj.FmtAndLogMsg(threadName + "END Processing Table: " + tableName
						+ "; Rows Processed: " + (i - 1));
				numProcessed++;
			} catch (Exception e) {
				log_obj.FmtAndLogMsg(threadName + "ERROR Processing Table: " + tableName + "; "
						+ e.toString(), e);
				throw e;
			} finally {
			    try {
					if (in != null) {
						in.close();
					}
				} catch (Exception e) {
				}
				try {
					if (is != null) {
						is.close();
					}
				} catch (Exception e) {
				}
				try {
					if (ps != null) {
						ps.close();
					}
				} catch (Exception e) {
				}
			}
		}
		// Tell the main thread how many tables were processed by this thread
		main.addTablesExported(numProcessed);
		
		log_obj.FmtAndLogMsg(threadName + "COMPLETE. Num tables processed: " + numProcessed);
	}
	
	/**
	 * Runs a delete statement on the table.
	 * 
	 * @param tableName
	 *            The table to delete all data from.
	 * @throws Exception
	 *             If there is an exception deleting.
	 */
	private void deleteFromTable(String tableName) throws Exception {
		PreparedStatement ps = null;
		try {
			
			/**
			 * OWASP TOP 10 2010 - A1 High SQL Injection
			 * TTP 324955 Security Remediation Fortify Scan
			 **/
			//ps = con.prepareStatement("delete from " + tableName);
			String strDelete = "";
			try{
				strDelete = "delete from " + SQLSecurity.sanitize(tableName);
			}catch (SQLException se){
				log_obj.FmtAndLogMsg("Class " + this.getClass() + "; " + se.toString());
			}
			//ps = con.prepareStatement(ESAPI.encoder().encodeForSQL( new OracleCodec(),strDelete.toString()));
			ps = con.prepareStatement(strDelete);
			ps.execute();
			ps.close();
		} catch (Exception e) {
			throw e;
		} finally {
			try {
				if (ps != null) {
					ps.close();
				}
			} catch (Exception e) {
			}
		}
	}
	
	/**
	 * Parses a pipe delimited line to get all entries in the line.
	 * The logic expects that the last entry in the line comes after
	 * the final pipe (i.e. the last entry doesn't have a pipe after it).
	 * 
	 * @param line
	 *            The pipe delimited line to parse.
	 * @return List of entries in the line.
	 */
	private ArrayList<String> getVarsInLine(String line) {
		ArrayList<String> varsInLine = new ArrayList<String>();
		String var = "";
		char delimiter = '|';
		for (int i = 0; i < line.length(); i++) {
			if (line.charAt(i) == delimiter) {
				varsInLine.add(var);
				var = "";
			} else {
				var += line.charAt(i);
			}
			
			if (i == line.length() - 1) {
				varsInLine.add(var);
			}
		}
		
		return varsInLine;
	}
	
	/**
	 * Sets the variables in the line as bind variables in the
	 * PreparedStatement. The <i>cols</i> object is used to
	 * determine the each column's datatype. If the columns is
	 * a CLOB, BFILE, BLOB, LONG, or LONG RAW, it is not put
	 * into the query as a bind variable.
	 * 
	 * @param vars
	 *            List of entries to set as bind vars.
	 * @param ps
	 *            PreparedStatement to use.
	 * @param cols
	 *            Columns names and datatypes. This is expected
	 *            to be in the same order as the vars.
	 * @throws Exception
	 *             If there was any issue setting the bind vars.
	 */
	private void processLine(ArrayList<String> vars, PreparedStatement ps,
			ArrayList<KeyValueContainer> cols)
			throws Exception {
		int updateIdx = 1;
		for (int i = 0; i < vars.size(); i++) {
			String dataType = cols.get(i).getValue();
			if (dataType.equals("CLOB") || dataType.equals("BFILE") || dataType.equals("BLOB") ||
					dataType.equals("LONG") || dataType.equals("LONG RAW")) {
				// Do nothing
			} else {
				ps.setString(updateIdx++, vars.get(i));
			}
		}
	}
	
	/**
	 * Gets the list of columns in the table. The list is stored as
	 * key/value pairs containing the column name and datatype.
	 * 
	 * @param tableName
	 *            The name of the database table.
	 * @return List of columns in the table and their datatypes.
	 * @throws Exception
	 *             If there was an issue executing the query
	 *             to get the column information.
	 */
	private ArrayList<KeyValueContainer> getColsInTable(String tableName)
			throws Exception {
		Query query = new Query(con);
		ArrayList<KeyValueContainer> cols = new ArrayList<KeyValueContainer>();
		query.prepareStatement("select atc.column_name, atc.data_type " +
				"from user_tab_columns atc " +
				"WHERE atc.table_name = ? " +
				"ORDER BY atc.column_id ASC");
		query.setString(1, tableName, false);
		query.executePreparedQuery();
		while (query.next()) {
			cols.add(new KeyValueContainer(query.getColValue("column_name"), query
					.getColValue("data_type")));
		}
		return cols;
	}
	
	/**
	 * Builds a select from dual statement for the table that selects
	 * each column in the table. Each column will have a bind variable
	 * that can be used later. Any CLOB, BFILE, BLOB, LONG, and LONG RAW
	 * columns are left out of the statement. Any DATE or DATETIME columns
	 * are expected to be in "MM/DD/YYYY  HH:MI:SS AM" format when putting
	 * them into the bind variable, since this built statement will convert
	 * them to an Oracle date using that format.
	 * 
	 * @param cols
	 *            The list of columns in the table.
	 * @return Statement string selecting each column in the table from dual.
	 */
	private String buildSelectPartOfQueryForTable(ArrayList<KeyValueContainer> cols) {
		String sql = "select ";
        StringBuilder temp_builder = new StringBuilder(sql);

		for (KeyValueContainer col : cols) {
			String colString = "?";
			if (col.getValue().equals("DATE") || col.getValue().equals("DATETIME")) {
				colString = "to_date(?,'MM/DD/YYYY  HH:MI:SS AM')";
			}
			
			if (col.getValue().equals("CLOB") || col.getValue().equals("BFILE") ||
						col.getValue().equals("BLOB") || col.getValue().equals("LONG") ||
						col.getValue().equals("LONG RAW")) {
				// Do nothing
			} else {
                temp_builder.append(colString);
                temp_builder.append(" as \"");
                try{
                	temp_builder.append(SQLSecurity.sanitize(col.getKey().toUpperCase()));
                }catch (SQLException se){
					log_obj.FmtAndLogMsg("Class " + this.getClass() + "; " + se.toString());
				}
                temp_builder.append("\", ");
			}
		}

        sql = temp_builder.toString();
		sql = sql.substring(0, sql.lastIndexOf(","));
		sql += " from dual";
		return sql;
	}
	
	/**
	 * Builds a Merge statement to insert/update a database
	 * table.<br />
	 * Any CLOB, BFILE, BLOB, LONG, or LONG RAW columns are left
	 * out of the merge statement.
	 * 
	 * @param tableName
	 *            The table name for which to build the merge.
	 * @return Merge statement string for the table.
	 * @throws Exception
	 *             If there is any issue building the merge.
	 */
	private String buildQueryForTable(String tableName)
			throws Exception {
		ArrayList<KeyValueContainer> cols = getColsInTable(tableName);
		return buildQueryForTable(tableName, cols, buildSelectPartOfQueryForTable(cols));
	}
	
	/**
	 * Builds a Merge statement to insert/update a database
	 * table. <br />
	 * The <i>cols</i> parameter can be retrieved using
	 * the {@link #getColsInTable(String) getColsInTable} method.<br />
	 * Any CLOB, BFILE, BLOB, LONG, or LONG RAW columns are left
	 * out of the merge statement.
	 * 
	 * @param tableName
	 *            The table name for which to build the merge.
	 * @param cols
	 *            The list of columns in the table.
	 * @return Merge statement string for the table.
	 * @throws Exception
	 *             If there is any issue building the merge.
	 */
	private String buildQueryForTable(String tableName, ArrayList<KeyValueContainer> cols)
			throws Exception {
		return buildQueryForTable(tableName, cols, buildSelectPartOfQueryForTable(cols));
	}
	
	/**
	 * Builds a Merge statement to insert/update a database
	 * table. <br />
	 * The <i>cols</i> parameter can be retrieved using
	 * the {@link #getColsInTable(String) getColsInTable} method.<br />
	 * The <i>select</i> parameter can be retrieved by using the
	 * {@link #buildSelectPartOfQueryForTable(ArrayList) buildSelectPartOfQueryForTable} method.
	 * <br />Any CLOB, BFILE, BLOB, LONG, or LONG RAW columns are left
	 * out of the merge statement.
	 * 
	 * @param tableName
	 *            The table name for which to build the merge.
	 * @param cols
	 *            The list of columns in the table.
	 * @param select
	 *            The select from dual statement to put into the merge.
	 * @return Merge statement string for the table.
	 * @throws Exception
	 *             If there is any issue building the merge.
	 */
	private String buildQueryForTable(String tableName, ArrayList<KeyValueContainer> cols,
			String select)
			throws Exception {
		
		// Get the primary key constraints. These will be used to
		// build the ON clause of the merge statement.
		ArrayList<String> consCols = new ArrayList<String>();
		Query query = new Query(con);
		query.prepareStatement("select ucc.column_name " +
				"from user_constraints  uc, " +
				"user_cons_columns ucc, " +
				"user_tab_columns utc " +
				"where uc.table_name = ? " +
				"and uc.constraint_type = 'P' " +
				"and uc.table_name = ucc.table_name " +
				"and uc.constraint_name = ucc.constraint_name " +
				"and ucc.table_name = utc.table_name " +
				"and ucc.column_name = utc.column_name " +
				"and utc.data_type not in ('CLOB','BFILE','BLOB','LONG','LONG RAW') " +
				"order by position nulls first");
		query.setString(1, tableName, false);
		query.executePreparedQuery();
		while (query.next()) {
			consCols.add(SQLSecurity.sanitize(query.getColValue("column_name")));
		}
		
		// If there is no PK, look for unique indexes
		if (consCols.size() == 0) {
			query.prepareStatement("select distinct uic.column_name " +
					"from user_indexes ui, user_ind_columns uic, user_tab_columns utc " +
					"where ui.table_name = ? " +
					"and ui.uniqueness = 'UNIQUE' " +
					"and ui.table_name = uic.table_name " +
					"and ui.index_name = uic.index_name " +
					"and ui.table_name = utc.table_name " +
					"and uic.column_name = utc.column_name " +
					"and utc.data_type not in ('CLOB','BFILE','BLOB','LONG','LONG RAW')");
			query.setString(1, tableName, false);
			query.executePreparedQuery();
			while (query.next()) {
				consCols.add(SQLSecurity.sanitize(query.getColValue("column_name")));
			}
		}
		
		// Put the select from dual statement into the USING clause
		String sql = "merge into " + SQLSecurity.sanitize(tableName) + " A using (";
		sql += select;
		sql += ") B";
        
        StringBuilder temp_builder1 = new StringBuilder(sql);
		
		// If the table has a PK, then put those columns into
		// the ON clause.
		// Otherwise, all columns will go into the ON clause,
		// which means that we will only need to handle the 
		// insert part, not the update part of the merge later.
		if (consCols.size() > 0) {
            temp_builder1.append(" ON (");

			for (String col : consCols) {
                temp_builder1.append("A.");
                temp_builder1.append(SQLSecurity.sanitize(col));
                temp_builder1.append(" = B.");
                temp_builder1.append(SQLSecurity.sanitize(col));
                temp_builder1.append(" AND ");
			}
            
            sql = temp_builder1.toString();
			sql = sql.substring(0, sql.lastIndexOf(" AND"));
			sql += ") ";
		} else {
            temp_builder1.append(" ON (");

			for (KeyValueContainer col : cols) {
				if (!col.getValue().equals("CLOB") && !col.getValue().equals("BFILE") &&
						!col.getValue().equals("BLOB") && !col.getValue().equals("LONG") &&
						!col.getValue().equals("LONG RAW")) {

                    temp_builder1.append("A.");
                    temp_builder1.append(SQLSecurity.sanitize(col.getKey()));
                    temp_builder1.append(" = B.");
                    temp_builder1.append(SQLSecurity.sanitize(col.getKey()));
                    temp_builder1.append(" AND ");
				}
			}
            
            sql = temp_builder1.toString();
			sql = sql.substring(0, sql.lastIndexOf(" AND"));
			sql += ") ";
		}
		
		// Build the insert clause. All columns, except for the normal excluded
		// datatypes, will go into the insert.
		sql += " when not matched then insert (";
        
        StringBuilder temp_builder2 = new StringBuilder(sql);
		for (KeyValueContainer col : cols) {
			if (col.getValue().equals("CLOB") || col.getValue().equals("BFILE") ||
					col.getValue().equals("BLOB") || col.getValue().equals("LONG") ||
					col.getValue().equals("LONG RAW")) {
				// Do nothing
			} else {
                temp_builder2.append(SQLSecurity.sanitize(col.getKey()));
                temp_builder2.append(", ");
			}
		}
        
        sql = temp_builder2.toString();
		sql = sql.substring(0, sql.lastIndexOf(","));
		sql += ") VALUES (";
        
        StringBuilder temp_builder3 = new StringBuilder(sql);
		for (KeyValueContainer col : cols) {
			if (col.getValue().equals("CLOB") || col.getValue().equals("BFILE") ||
						col.getValue().equals("BLOB") || col.getValue().equals("LONG") ||
						col.getValue().equals("LONG RAW")) {
				// Do nothing
			} else {
                temp_builder3.append("B.");
                temp_builder3.append(SQLSecurity.sanitize(col.getKey()));
                temp_builder3.append(", ");
			}
		}
        
        sql = temp_builder3.toString();
		sql = sql.substring(0, sql.lastIndexOf(","));
		sql += ") ";
		
		// Build the update clause. There are two conditions that
		// will prevent us from needing an update clause:
		// 1. Each column in the table is part of the PK
		// 2. There is no PK and therefore each column is in the ON clause
		if (cols.size() != consCols.size() && consCols.size() > 0) {
			sql += " when matched then update set ";
			boolean updatedCols = false;
            StringBuilder temp_builder4 = new StringBuilder(sql);
			for (KeyValueContainer col : cols) {
				// Only add columns that are not in the ON clause
				if (!consCols.contains(col.getKey())) {
					if (col.getValue().equals("CLOB") || col.getValue().equals("BFILE") ||
							col.getValue().equals("BLOB") || col.getValue().equals("LONG") ||
							col.getValue().equals("LONG RAW")) {
						// Do nothing
					} else {
                        temp_builder4.append("A.");
                        temp_builder4.append(SQLSecurity.sanitize(col.getKey()));
                        temp_builder4.append(" = B.");
                        temp_builder4.append(SQLSecurity.sanitize(col.getKey()));
                        temp_builder4.append(", ");
						updatedCols = true;
					}
				}
			}
            
            sql = temp_builder4.toString();
			
			if(updatedCols) {
				sql = sql.substring(0, sql.lastIndexOf(","));
			} else {
				sql = sql.substring(0, sql.lastIndexOf("when"));
			}
		}
		return sql;
	}
}
