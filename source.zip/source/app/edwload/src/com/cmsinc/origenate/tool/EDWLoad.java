package com.cmsinc.origenate.tool;

import java.io.File;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Enumeration;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import com.cmsinc.origenate.crypto.Crypto;
import com.cmsinc.origenate.crypto.CryptoFactory;
import com.cmsinc.origenate.util.LogMsg;
import com.cmsinc.origenate.util.OWASPSecurity;
import com.cmsinc.origenate.util.SQLSecurity;
import com.cmsinc.origenate.util.TarFileReader;



/**
 * EDW Load process. This process takes the EDW file (zip or tar.gz) that
 * was generated with CMSI's EDW Extract process and loads it into a
 * database. It is expected that the database from which the data was
 * extracted and the database to which the data is being loaded have exactly
 * the same schema. Otherwise, the EDW Load process may run into issues.
 * <br /><br />
 * The EDW Load supports loading into Origenate and Evaluate. When loading
 * the data, the process also supports several different options for deleting
 * existing data. The design and usage document for the EDW Load specifies
 * the details for the process.
 * 
 * @author michaelsw
 * 
 */
public class EDWLoad {
	public static final String DELETE_NONE = "none";
	public static final String DELETE_ZIPPED = "ziponly";
	public static final String DELETE_ALL = "all";
	public static final String ZIP = ".zip";
	public static final String TAR = ".tar.gz";
	public static final int BATCH_SIZE = 200;
	
	private int iNumThreads = 0;
	private Connection conn = null;
	private LogMsg log_obj = null;
	
	private String sConStr = "jdbc:oracle:thin:@";
	
	private ArrayList<KeyValueContainer> constraintsList = new ArrayList<KeyValueContainer>();
	private ArrayList<KeyValueContainer> triggersList = new ArrayList<KeyValueContainer>();
	
	private String sContr = "", sTNSEntry = "", sUser = "",
			sPass = "", numThreads = "", logFile = "", zipFileName = "",
			deleteFlag = "";
	private boolean decryptFlg = false;
	private String encryptionUser = "";
	private boolean isTar = false;
	private boolean threadFailed = false;
	private ZipFile zipFile = null;
	private Enumeration<? extends ZipEntry> zipEntries = null;
	private TarFileReader tarReader = null;
	private long start = 0, end = 0, elapsed = 0;
	private int numTablesImported = 0;
	private int batchSize = BATCH_SIZE;
	
	public static void main(String[] args) {
		try {
			EDWLoad edwLoad = new EDWLoad();
			edwLoad.run(args);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * Instantiates a new EDWLoad object.
	 */
	public EDWLoad() {
		
	}
	
	/**
	 * Runs the EDW Load process.
	 * 
	 * @param args
	 *            Startup parameters.
	 * @throws Exception
	 *             If there is any exception running
	 *             the EDW Load process.
	 */
	private void run(String[] args) throws Exception {
		start = new java.util.Date().getTime();
		
		try {
			GetArgs(args);
		} catch (Exception e) {
			throw new Exception("Unable to initialize EDW Extract: " + e.toString(), e);
		}
		
		// Verify that the EDW file is a valid file type
		if (zipFileName.endsWith(ZIP)) {
			log_obj.FmtAndLogMsg("Extracting zip: " + zipFileName);
			isTar = false;
		} else if (zipFileName.endsWith(TAR)) {
			log_obj.FmtAndLogMsg("Extracting tar: " + zipFileName);
			numThreads = "1"; // Only 1 thread allowed for tar file
			isTar = true;
		} else {
			throw new Exception("Invalid EDW file. Must be zip or tar.gz file. File Name: "
					+ zipFileName);
		}
		
		// Verify that the EDW file exists
		/**  
		  * OWASP TOP 10 2010 - A4 Path Manipulation
		  * Changes to the below code to fix vulnerabilities
		  * TTP 324955
		  */
		//if (!(new File(zipFileName).exists())
		//if (!(new File(Encode.forJava(zipFileName))).exists())
		if (!(new File(OWASPSecurity.validationCheck(zipFileName, OWASPSecurity.DIRANDFILE))).exists())
		{
			throw new Exception("Could not find EDW file. File Name: " + zipFileName);
		}
		
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			conn.setAutoCommit(false);
			
			// Just need to make sure we disable Unique and Primary Key constraints
			// after Foreign Keys, and enable Unique and Primary Keys before
			// Foreign Keys. The other constraint types aren't as important.
			ps = conn.prepareStatement("select c.table_name, c.constraint_name " +
					"from user_constraints c, user_tables t " +
					"where c.table_name = t.table_name " +
					"and c.status = 'ENABLED' " +
					"order by " +
					"decode(c.constraint_type,'C',2,'O',4,'P',7,'R',1,'U',6,'V',3,5), " +
					"c.constraint_type desc");
			rs = ps.executeQuery();
			while (rs.next()) {
				constraintsList.add(new KeyValueContainer(rs.getString(1), rs.getString(2)));
			}
			rs.close();
			ps.close();
			
			ps = conn.prepareStatement("select table_owner, trigger_name " +
					"from user_triggers " +
					"where status = 'ENABLED'");
			rs = ps.executeQuery();
			while (rs.next()) {
				triggersList.add(new KeyValueContainer(rs.getString(1), rs.getString(2)));
			}
			rs.close();
			ps.close();
			

			// Disable all constraints and triggers. We're using the
			// constraintsList and triggersList lists so that we can
			// re-enable the same set of constraints and triggers,
			// in reverse order, at the end.
			log_obj.FmtAndLogMsg("BEGIN Disable Constraints");
			handleConstraints(constraintsList, true);
			log_obj.FmtAndLogMsg("END Disable Constraints");
			log_obj.FmtAndLogMsg("BEGIN Disable Triggers");
			handleTriggers(triggersList, true);
			log_obj.FmtAndLogMsg("END Disable Triggers");
			

			// If the flag is set to delete all data, then call
			// the method to clear the data from all tables.
			if (deleteFlag.equalsIgnoreCase(DELETE_ALL)) {
				log_obj.FmtAndLogMsg("BEGIN Delete All Data");
				clearAllTables();
				log_obj.FmtAndLogMsg("END Delete All Data");
			}
			
			// Instantiate the proper object based on file type
			if (isTar) {
				tarReader = new TarFileReader(zipFileName, true);
			} else {
				
				/**  
				  * OWASP TOP 10 2010 - A4 Path Manipulation
				    * Changes to the below code to fix vulnerabilities
				    * TTP 324955
				    */
				   
				//zipFile = new ZipFile(zipFileName);
				//zipFile = new ZipFile(Encode.forJava(zipFileName));
				zipFile = new ZipFile(OWASPSecurity.validationCheck(zipFileName, OWASPSecurity.DIRANDFILE));

			}
			
			List<EDWLoadThread> processThreads = new ArrayList<EDWLoadThread>();
			iNumThreads = Integer.parseInt(numThreads);
			
			// Add all threads
			for (int currThread = 1; currThread <= iNumThreads; currThread++) {
				processThreads.add(
						new EDWLoadThread(this, "THREAD" + currThread + "  ",
								conn, log_obj));
			}
			
			ExecutorService threadExecutor = Executors.newCachedThreadPool();
			
			// Start threads and place in runnable state
			log_obj.FmtAndLogMsg("Starting " + iNumThreads + " threads...");
			for (EDWLoadThread t : processThreads) {
				threadExecutor.execute(t);
				try {
					Thread.sleep(2000);
				} catch (Exception e) {
				} // sleep 2 seconds
			}
			
			threadExecutor.shutdown(); // shutdown worker threads and exit
			
			while (true) {
				try {
					Thread.sleep(2000);
				} catch (Exception e) {
				} // sleep 2 seconds
				if (iNumThreads == 0) {
					break; // waiting for all threads to finish
				}
			}
			
			// Put the constraints and triggers in reverse order,
			// then re-enable them.
			Collections.reverse(constraintsList);
			Collections.reverse(triggersList);
			log_obj.FmtAndLogMsg("BEGIN Enable Constraints");
			handleConstraints(constraintsList, false);
			log_obj.FmtAndLogMsg("END Enable Constraints");
			log_obj.FmtAndLogMsg("BEGIN Enable Triggers");
			handleTriggers(triggersList, false);
			log_obj.FmtAndLogMsg("END Enable Triggers");
			
			// If one or more threads failed, then roll back changes.
			// Otherwise, commit the changes that were made.
			if (threadFailed) {
				conn.rollback();
				log_obj.FmtAndLogMsg("Import Failed. Rolled back changes.");
			} else {
				conn.commit();
				log_obj.FmtAndLogMsg("Import Successful. Committed changes. " +
						"Number of tables processed: " + numTablesImported);
			}
			
			// Print statistics
			end = new java.util.Date().getTime();
			elapsed = end - start;
			log_obj.FmtAndLogMsg("\n\nImport Finished");
			log_obj.FmtAndLogMsg("Total Elapsed Time: "
					+ ((int) (elapsed / (60 * 60 * 1000F)) % 24) + " Hr. "
					+ ((int) (elapsed / (60 * 1000F)) % 60) + " min. "
					+ ((int) (elapsed / 1000F) % 60) + " sec.");
		} catch (Exception e) {
			conn.rollback();
			log_obj.FmtAndLogMsg("Exception running EDWImport: " + e.toString(), e);
			throw e;
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}
			} catch (Exception e) {
			}
			try {
				if (ps != null) {
					ps.close();
				}
			} catch (Exception e) {
			}
			try {
				if (conn != null) {
					conn.close();
				}
			} catch (Exception e) {
			}
			try {
				if (zipFile != null) {
					zipFile.close();
				}
			} catch (Exception e) {
			}
			try {
				if (tarReader != null) {
					tarReader.close();
				}
			} catch (Exception e) {
			}
		}
	}
	
	/**
	 * Runs a delete statement for each table in the database.
	 * 
	 * @throws Exception
	 *             If there is an issue with any of the deletes.
	 */
	private void clearAllTables() throws Exception {
		String deleteSql = "delete from %s";
		PreparedStatement ps = null;
		ResultSet rs = null;
		Statement deleteStmt = null;
		try {
			deleteStmt = conn.createStatement();
			ps = conn.prepareStatement("select table_name from user_tables");
			rs = ps.executeQuery();
			int i = 1;
			while (rs.next()) {
				//TTP 324955 Security Remediation Fortify Scan
				deleteStmt.addBatch(String.format(SQLSecurity.sanitize(deleteSql), SQLSecurity.sanitize(rs.getString(1))));
				if (i % batchSize == 0) {
					deleteStmt.executeBatch();
				}
				i++;
			}
			if (i > 1 && i % batchSize != 1) {
				deleteStmt.executeBatch();
			}
			deleteStmt.close();
			rs.close();
			ps.close();
		} catch (Exception e) {
			throw e;
		} finally {
			try {
				if (deleteStmt != null) {
					deleteStmt.close();
				}
			} catch (Exception e) {
			}
			try {
				if (rs != null) {
					rs.close();
				}
			} catch (Exception e) {
			}
			try {
				if (ps != null) {
					ps.close();
				}
			} catch (Exception e) {
			}
		}
	}
	
	/**
	 * Handles enabling or disabling constraints. When the constraints
	 * are enabled, the novalidate keyword is used to prevent constraints
	 * from validating at this time. Any future changes to the DB will
	 * validate as normal. When disabling constraints, the cascade
	 * keyword is used to prevent any downstream constraints from failing.
	 * 
	 * @param constraints
	 *            List of constraint names to work with.
	 * @param disable
	 *            If true, constraints will be disabled. If false, they
	 *            will get enabled.
	 * @throws Exception
	 *             If there is an issue handling the constraints.
	 */
	private void handleConstraints(ArrayList<KeyValueContainer> constraints,
			boolean disable) throws Exception {
		String constraintSql = "alter table %s %s constraint %s";
		if (disable) {
			constraintSql += " cascade";
		}
		String disableStr = disable ? "disable" : "enable novalidate";
		Statement constraintStmt = null;
		try {
			constraintStmt = conn.createStatement();
			int i = 1;
			int constraintsSize = constraints.size();
			for (KeyValueContainer constraint : constraints) {
				constraintStmt.addBatch(
										//TTP 324955 Security Remediation Fortify Scan
										String.format(SQLSecurity.sanitize(constraintSql), SQLSecurity.basicSanitize(constraint.getKey()),
												SQLSecurity.sanitize(disableStr),
												SQLSecurity.basicSanitize(constraint.getValue())));
				if (i % batchSize == 0 || i >= constraintsSize) {
					constraintStmt.executeBatch();
				}
				i++;
			}
			constraintStmt.close();
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			try {
				if (constraintStmt != null) {
					constraintStmt.close();
				}
			} catch (Exception e) {
			}
		}
	}
	
	/**
	 * Handles enabling or disabling triggers.
	 * 
	 * @param triggers
	 *            List of trigger names to work with.
	 * @param disable
	 *            If true, triggers will be disabled. If false, they
	 *            will get enabled.
	 * @throws Exception
	 *             If there is an issue handling the triggers.
	 */
	private void handleTriggers(ArrayList<KeyValueContainer> triggers,
			boolean disable) throws Exception {
		String triggerSql = "alter trigger %s.%s %s";
		String disableStr = disable ? "disable" : "enable";
		Statement triggerStmt = null;
		try {
			triggerStmt = conn.createStatement();
			int i = 1;
			int constraintsSize = triggers.size();
			for (KeyValueContainer trigger : triggers) {
				triggerStmt.addBatch(
						//TTP 324955 Security Remediation Fortify Scan
						String.format(SQLSecurity.sanitize(triggerSql), SQLSecurity.basicSanitize(trigger.getKey()),
								SQLSecurity.basicSanitize(trigger.getValue()), SQLSecurity.sanitize(disableStr)));
				if (i % batchSize == 0 || i >= constraintsSize) {
					triggerStmt.executeBatch();
				}
				i++;
			}
			triggerStmt.close();
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			try {
				if (triggerStmt != null) {
					triggerStmt.close();
				}
			} catch (Exception e) {
			}
		}
	}
	
	/**
	 * Gets arguments required by EDWLoad process.
	 * 
	 * @param args
	 *            Array of arguments.
	 * @throws Exception
	 *             If there was an issue getting the
	 *             arguments or processing the arguments afterwards.
	 *             For example, if there was an issue instantiating the
	 *             DB connection, decrypting the password, or if
	 *             required parameters are missing.
	 */
	private void GetArgs(String args[]) throws Exception {
		encryptionUser = "origenate";
		try {
			if (args.length > 0) {
				for (int i = 0; i < args.length; i++) {
					if ((args[i].charAt(0) != '-') && (args[i].length() > 1)) {
						ShowUsage();
					}
					
					switch (args[i].charAt(1)) {
					
					case 'n': //numThreads
						numThreads = args[i].substring(2);
						break;
					
					case 'T': //sTNSEntry 
						sTNSEntry = args[i].substring(2);
						break;
					
					case 'c': //sContr 
						sContr = args[i].substring(2);
						break;
					
					case 'u': //sUser 
						sUser = args[i].substring(2);
						break;
					
					case 'p': //sPass 
						sPass = args[i].substring(2);
						break;
					
					case 'F': //decryptFlg
						if (args[i].substring(2).equalsIgnoreCase("true")) {
							decryptFlg = true;
						}
						break;
					
					case 'l': //logFile
						logFile = args[i].substring(2);
						break;
					
					case 'z': //zipFileName
						zipFileName = args[i].substring(2);
						break;
					
					case 'd': //deleteFlag
						deleteFlag = args[i].substring(2);
						break;
					
					case 'b': //batchSize
						batchSize = Integer.valueOf(args[i].substring(2));
						break;
					
					default:
						ShowUsage();
						break;
					} // end case
				} // end for loop
				
				log_obj = new LogMsg();
				if (logFile != null && !logFile.equals("")) {
					log_obj.openLogFile(logFile);
				}
				
				checkRequiredArgs();
				
				if (numThreads.equals("")) {
					numThreads = "1";
				}
				
				if (deleteFlag.equals("")) {
					deleteFlag = DELETE_NONE;
				}
				
				if (batchSize <= 0) {
					batchSize = BATCH_SIZE;
				}
				
				// Load Oracle driver
				DriverManager.registerDriver(new oracle.jdbc.OracleDriver());
				
				sConStr = "jdbc:oracle:thin:@";
				
				if (sTNSEntry.length() == 0) {
					sConStr = sConStr + sContr;
				} else {
					sConStr = sConStr + sTNSEntry;
					log_obj.FmtAndLogMsg("Using TNS Entry");
				}
				
				if (decryptFlg) {
					// PERFORMING DUMMY ENCRYPTION OPERATION, SO IN THREADS IT WON'T THROW ANY ERROR
					try {
						Crypto crypto = CryptoFactory.getCrypto();
						crypto.encryptString("origenate", "ssn", "212715432");
					} catch (Exception e) {
						e.printStackTrace();
					}
					
					// Decrypt password
					try {
						Crypto crypto = CryptoFactory.getCrypto();
						sPass = crypto.decryptString(encryptionUser, "password", sPass);
					} catch (Exception e) {
						log_obj.FmtAndLogMsg("Exception occurred decrypting password.", e);
						throw e;
					}
				}
				
				conn = DriverManager.getConnection(sConStr, sUser, sPass);
			} // end if
			else {
				ShowUsage();
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		
	} // getArgs
	
	/**
	 * Checks that all required arguments are available.
	 * If they aren't, the usage instructions will be displayed
	 * and the program will exit.
	 */
	private void checkRequiredArgs() {
		if (sUser == null || sUser.equals("")) {
			log_obj.FmtAndLogMsg("-u argument is required. Exiting EDW.");
			ShowUsage();
		} else if (sPass == null || sPass.equals("")) {
			log_obj.FmtAndLogMsg("-p argument is required. Exiting EDW.");
			ShowUsage();
		} else if ((sTNSEntry == null || sTNSEntry.equals("")) &&
				(sContr == null || sContr.equals(""))) {
			log_obj.FmtAndLogMsg("-T OR -c argument is required. Exiting EDW.");
			ShowUsage();
		} else if (zipFileName == null || zipFileName.equals("")) {
			log_obj.FmtAndLogMsg("-z argument is required. Exiting EDW.");
			ShowUsage();
		} else if (logFile == null || logFile.equals("")) {
			log_obj.FmtAndLogMsg("-l argument is recommended. All logging will be printed to SystemOut.");
		}
	}
	
	/**
	 * Prints usage instructions to SystemErr and exits.
	 */
	private void ShowUsage() {
		System.err
				.println("Usage: java EDWExtract -n<numThreads> "
						+
						"[-c<dbContr> or -T<sTNSEntry>] -u<dbUser> -p<dbPass> "
						+
						"-z<full path to EDW file> -F<decryptFlg(true/false)> "
						+
						"-l<logFile> -d<delete flag(none/ziponly/all)> "
						+
						"-b<batch size>");
		System.exit(-1);
	}
	
	/**
	 * Decrements the running thread count by 1.
	 */
	public synchronized void decrementThreadCount() {
		iNumThreads--;
	}
	
	/**
	 * If a thread would throw an exception, it will
	 * instead call this method, which will allow the
	 * other threads to exit gracefully and proceed
	 * to roll back any DB changes.
	 */
	public synchronized void threadFailed() {
		threadFailed = true;
	}
	
	/**
	 * @return the threadFailed
	 */
	public synchronized boolean hasThreadFailed() {
		return threadFailed;
	}
	
	/**
	 * Gets the TAR Reader and then sets this class'
	 * instance of the TAR Reader to null so that any
	 * future calls to this method will return null.
	 * 
	 * @return The TAR Reader object
	 */
	public synchronized TarFileReader getTarArchive() {
		TarFileReader temp = tarReader;
		tarReader = null;
		return temp;
	}
	
	/**
	 * Gets the next file from the ZIP file. <br />
	 * Returns null if the ZIP file has not been instantiated.
	 * 
	 * @return The next entry in the ZIP file, or null
	 *         if there are no more entries.
	 */
	public synchronized ZipEntry getNextZipEntry() {
		if (zipFile == null) {
			return null;
		}
		
		if (zipEntries == null) {
			zipEntries = zipFile.entries();
		}
		
		if (zipEntries.hasMoreElements()) {
			ZipEntry entry = zipEntries.nextElement();
			return entry;
		} else {
			return null;
		}
	}
	
	/**
	 * Gets an InputStream object for a particular entry
	 * in the ZIP file.
	 * 
	 * @param entry
	 *            The entry to retrieve.
	 * @return InputStream object for the entry.
	 * @throws Exception
	 *             If an exception is thrown getting the InputStream.
	 */
	public synchronized InputStream getZipEntryInputStream(ZipEntry entry)
			throws Exception {
		if (entry == null) {
			return null;
		}
		
		return zipFile.getInputStream(entry);
	}
	
	/**
	 * @return the isTar
	 */
	public synchronized boolean isTar() {
		return isTar;
	}
	
	/**
	 * @return the deleteFlag
	 */
	public synchronized String getDeleteFlag() {
		return deleteFlag;
	}
	
	/**
	 * @return the batchSize
	 */
	public synchronized int getBatchSize() {
		return batchSize;
	}
	
	/**
	 * Adds the specified number of tables to this
	 * class' count of tables processed.
	 * 
	 * @param numTables
	 *            Number of tables to add to count.
	 */
	public synchronized void addTablesExported(int numTables) {
		numTablesImported += numTables;
	}
}
