package com.cmsinc.origenate.doc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Hashtable;

import com.cmsinc.origenate.doc.DocGen;
import com.cmsinc.origenate.doc.GenJob;
import com.cmsinc.origenate.event.JournalEvents;
import com.cmsinc.origenate.util.LogMsg;
import com.cmsinc.origenate.util.Query;
import com.cmsinc.origenate.util.SQLSecurity;
import com.cmsinc.origenate.util.SQLUpdate;
import com.cmsinc.origenate.workflow.ApplicationIDs;

/**
 * @author miker
 *
 */
public class ProcessThread extends Thread {

	// INSTANCE VARIABLES

	Connection con = null;
	NightlyLetters main = null;
	//boolean busy = false;
	//boolean workToDo = false;
	//boolean errorOccurred = false;
	//boolean endThread = false;
	//String errorMessage = null;
	String letterID = "";
	int lock_app_param = 0;
	String logFile = "";
	String queryID = "";
	//String sConStr, sUser, sPass;
	//LogMsg log_obj = null;
	GenJob genJob = null;
	String batch_job_id = "";
	int printCount = 0;
	int appCount = 0;
	String submitDate = "";
	String sortByTxt = "";
	int manualWthdwlFlg = 0;

	// CONSTRUCTOR

	/**
	 * @param main
	 * @param sConStr
	 * @param sUser
	 * @param sPass
	 * @param ID
	 * @param log_obj
	 * @param submitDate
	 * @throws Exception
	 */
	public ProcessThread(NightlyLetters main, String sConStr, String sUser,
			String sPass, String ID, int lock, String log_file, String Query_ID, LogMsg log_obj, String submitDate, int inclManualWthdwl)
			throws Exception {

		letterID = ID;
		lock_app_param = lock;
		logFile = log_file;
		queryID = Query_ID;
		manualWthdwlFlg = inclManualWthdwl;
		this.main = main;
		//this.sConStr = sConStr;
		//this.sUser = sUser;
		//this.sPass = sPass;
		//this.log_obj = log_obj;
		this.submitDate = submitDate;

		// Connect to the Oracle database
		con = DriverManager.getConnection(sConStr, sUser, sPass);

		genJob = new GenJob(con, log_obj);

	} // end constructor

	// ///////////////////////////////////////////////////////////////////////////

	// RUN METHOD - execution continues in its own thread

	public void run() {

		printCount = 0;
		appCount = 0;

		do {

			try {

				// create a unique batch ID for this thread

				Query queryTmp = new Query(con);

				queryTmp
						.executeQuery("SELECT NEXT_JOB_ID.NEXTVAL AS next_job_id FROM DUAL");

				queryTmp.next();

				batch_job_id = queryTmp.getColValue("next_job_id", "0");

				main.log(0, letterID + " thread running... ASSIGNED BATCH ID: "
						+ batch_job_id);

				if (main.shuttingDown)
					break; // user forcing shutdown

				processLetterCategory(letterID);

			} catch (Exception e) {
				main.log(0, letterID + " error: " + e.toString());
			}

		} while (false); // loop done once so we can break out easily when
		// shuttingDown flag is detected early

		main.log(0, letterID + " " + appCount + " applications processed");
		main.log(0, letterID + " Submitted " + printCount + " print requests");

		// close down this thread

		try {
			con.close();
		} catch (Exception e1) {
		}

		main.log(0, letterID + " thread exited");

		main.threadCount(true); // decrease thread count

		// fall thru to end thread

	} // end run()

	// ///////////////////////////////////////////////////////////////////////

	/**
	 * @param letterID
	 * @throws Exception
	 */
	void processLetterCategory(String letterID) throws Exception {

		// letter categories: DECLINE_LETTER,COUNTER_OFFER_LETTER,
		// EXPIRED_OFFER_LETTER,WELCOME_LETTER,
		// FIRST_PAYMENT_LETTER,BATCH,CLOSING_DOCUMENT,EARLY_DISCLOSURE_DOCUMENT,RISK_BASED_PRICING_LETTER, GEN_NOTIFICATION_LETTER_1 - 10,
		// HOUSING_COUNSEL_LETTER

		String submit_reason_id = "0";
        String touchPoint="";

		if (letterID.equals("DECLINE_LETTER")) {
			submit_reason_id = "5";
			touchPoint="2";
		}
		if (letterID.equals("COUNTER_OFFER_LETTER")){
			touchPoint="4";
			submit_reason_id = "6";
		}
		if (letterID.equals("WELCOME_LETTER")) {
			touchPoint="1";
			submit_reason_id = "7";
		}
		if (letterID.equals("EXPIRED_OFFER_LETTER")) {
			touchPoint="6";
			submit_reason_id = "8";
		}
		if (letterID.equals("WITHDRAW_LETTER")) {
			touchPoint="5";
			submit_reason_id = "18";
		}
		if (letterID.equals("FIRST_PAYMENT_LETTER")) {
			touchPoint="3";
			submit_reason_id = "9";
		}
		if (letterID.equals("BATCH")) {
			touchPoint="8";
			submit_reason_id = "10";
		}
		if (letterID.equals("CLOSING_DOCUMENT")) {
			touchPoint="7";
			submit_reason_id = "12";
		}
		if (letterID.equals("EARLY_DISCLOSURE_DOCUMENT")) {
			touchPoint="9";
			submit_reason_id = "14";
		}

		if (letterID.equals("INITIAL")) {
			touchPoint="10";
			submit_reason_id = "19";
		}
		if (letterID.equals("FOLLOW_UP_1")) {
			touchPoint="12";
			submit_reason_id = "20";
		}
		if (letterID.equals("FOLLOW_UP_2")) {
			touchPoint="13";
			submit_reason_id = "21";
		}
		if (letterID.equals("MISSING_INFO")) {
			touchPoint="11";
			submit_reason_id = "22";
		}
		if (letterID.equals("RISK_BASED_PRICING_LETTER")) 
		{
			touchPoint="60";
			submit_reason_id = "26";
		}
		if (letterID.equals("HOUSING_COUNSEL_LETTER")) {
			touchPoint = "79";
			submit_reason_id = "31";
		}
		if (letterID.equals("GEN_NOTIFICATION_LETTER_1")) 
		{
			touchPoint="63";
			submit_reason_id = "29";
		}
		if (letterID.equals("GEN_NOTIFICATION_LETTER_2")) 
		{
			touchPoint="83";
			submit_reason_id = "29";
		}
		if (letterID.equals("GEN_NOTIFICATION_LETTER_3")) 
		{
			touchPoint="84";
			submit_reason_id = "29";
		}
		if (letterID.equals("GEN_NOTIFICATION_LETTER_4")) 
		{
			touchPoint="85";
			submit_reason_id = "29";
		}
		if (letterID.equals("GEN_NOTIFICATION_LETTER_5")) 
		{
			touchPoint="86";
			submit_reason_id = "29";
		}
		if (letterID.equals("GEN_NOTIFICATION_LETTER_6")) 
		{
			touchPoint="87";
			submit_reason_id = "29";
		}
		if (letterID.equals("GEN_NOTIFICATION_LETTER_7")) 
		{
			touchPoint="88";
			submit_reason_id = "29";
		}
		if (letterID.equals("GEN_NOTIFICATION_LETTER_8")) 
		{
			touchPoint="89";
			submit_reason_id = "29";
		}
		if (letterID.equals("GEN_NOTIFICATION_LETTER_9")) 
		{
			touchPoint="90";
			submit_reason_id = "29";
		}
		if (letterID.equals("GEN_NOTIFICATION_LETTER_10")) 
		{
			touchPoint="91";
			submit_reason_id = "29";
		}

		if (submit_reason_id.equals("0"))
			throw new Exception(
					"Letter Category must be one of BATCH, INITIAL, FOLLOW_UP_1, FOLLOW_UP_2, MISSING_INFO, DECLINE_LETTER, WITHDRAW_LETTER, COUNTER_OFFER_LETTER, WELCOME_LETTER, EXPIRED_OFFER_LETTER, CLOSING_DOCUMENT, EARLY_DISCLOSURE_DOCUMENT,RISK_BASED_PRICING_LETTER, GEN_NOTIFICATION_LETTER_1 - 10 or FIRST_PAYMENT_LETTER");

		// If we need to filter on evaluator then build a where clause for it

		// BATCH LETTER CATEGORY IS DOCUMENT CENTRIC WHEREAS ALL THE OTHER
		// CATEGORIES SELECT APPS FIRST AND THEN SEE WHICH DOCS CAN BE PRINTED
		// FOR EACH
		// APP. SO IF THE LETTER TYPE IS 'BATCH' CALL A DIFFERENT METHOD TO
		// PROCESS IT

		if (letterID.equals("BATCH")) {

                   throw new Exception(
                                   "Letter Category of BATCH is no longer supported as of release 8.4");
			//processBatchDocuments(letterID, submit_reason_id, evaluatorCheck);

			//return;
		}

		String select;
		ArrayList<String> evaluatorsInList = new ArrayList<String>();
		boolean needEvalList = true;
		/*
		 * ALSO GET THE LIST OF DOCUMENTS THAT CAN BE PRINTED IN THIS LETTER ID
		 * CATEGORY
		 */

		/*
		 * Glenn, DocGen - If config is defined for this touchpoint then we want to use it instead of
		 *                 checking the config_evaluator_documents table.
		 */

		DocGen docGen = new DocGen(main.sIniFile);

		String docGenList=docGen.getListOfTouchpointDocuments(con,touchPoint, main.evaluatorList);

		// IMPORTANT: FOR DOCGEN IF DOCGENLIST IS POPULATED THEN WE WILL USE THIS AS A FLAG TO INDICATE THAT WE HAVE DOCGEN
		//  CONFIG AND SHOULD USE IT RATHER THAN THE OLD WAY

		Query queryDocsInCategory = new Query(con);

		/*
		 * GL. start 10/19/04 Create an in list of doc ids so we can join to the
		 * credit_req_doc_history on the app select to reduce the population of
		 * selected apps to only those that have not printed a doc in the list
		 * yet. Otherwise the app result set can get quite large. Don't worry
		 * that doc ids belong to different evaluators because they should be
		 * mutually exclusive. ie. a doc for one evaluator will not show up in
		 * docs that are printed for an app belowing to another evaluator.
		 */
		String doc_id_list = "-100"; // -100 is a dummy to
													// prevent an empty list
		if (docGenList.length()>0) { // no docgen config so do it the old way for backwards compatibility
			doc_id_list = docGenList;
		}
		else { // no docgen config so do it the old way for backwards compatibility
				//TTP 324955 Security Remediation Fortify Scan
				if (main.evaluatorList.length() == 0){
					select = "select evaluator_id, document_id, batch_printer_txt, copies_to_print_num from config_evaluator_documents where category_id = ?"
							+ " order by evaluator_id";
					needEvalList = false;
				}
				else if (main.evaluatorList.indexOf(",") > 0)
					select = "select evaluator_id, document_id, batch_printer_txt, copies_to_print_num from config_evaluator_documents where category_id = ?"
							+ " and evaluator_id in ("
							+ SQLSecurity.listToPlaceholders(main.evaluatorList, evaluatorsInList)
							+ ") order by evaluator_id";
				else
					select = "select evaluator_id, document_id, batch_printer_txt, copies_to_print_num from config_evaluator_documents where category_id = "
							+ "? and evaluator_id = " + SQLSecurity.listToPlaceholders(main.evaluatorList, evaluatorsInList);
				
				queryDocsInCategory.prepareStatement(select);
				queryDocsInCategory.setString(1, letterID); //because previous code concatenated single quotations around the parameter letterID, it is a string
				if(needEvalList){
					int placeCt = 2;
					for(String param:evaluatorsInList){
						if(param.startsWith("'")){
						  queryDocsInCategory.setString(placeCt++, param.substring(1,param.length() - 1)); // no need for OWASP validation since Query does that by default
						}
						else{ //evaluator IDs won't be floating point numbers, so don't need to check for "."
						  queryDocsInCategory.setInt(placeCt++, Integer.valueOf(param));
						}
					}
				} 
				queryDocsInCategory.executePreparedQuery();


				// above query is used by getNextDocIDInCategory()

				/*
				 * GL. start 10/19/04 Create an in list of doc ids so we can join to the
				 * credit_req_doc_history on the app select to reduce the population of
				 * selected apps to only those that have not printed a doc in the list
				 * yet. Otherwise the app result set can get quite large. Don't worry
				 * that doc ids belong to different evaluators because they should be
				 * mutually exclusive. ie. a doc for one evaluator will not show up in
				 * docs that are printed for an app belonging to another evaluator.
				 */
				String docid = "";
				StringBuffer doc_id_listBuffer = new StringBuffer();
				while (queryDocsInCategory.next()) {
					docid = queryDocsInCategory.getColValue("document_id");
					if (docid != null)
						doc_id_listBuffer.append("," + docid); //doc_id_list += "," + docid;
				} // while finding by original eval ID
				doc_id_list = doc_id_listBuffer.toString();
				queryDocsInCategory.reset();

				/* GL. end 10/19/04 */
		}

		// Build a query to select the desired apps for this category
		Query query = new Query(con);

		// create the part that is common to all types of docs

		// DISTINCT - because when joining to xref_tasks_in_task_group we will
		// find more than
		// one row if an eval is overriding the -1 definition


		// F I N D A P P S
		boolean printOnceFlg = getPrintOnceFlg(con, touchPoint);
		ArrayList<String> params = new ArrayList<String>();

		//TTP 324955 Security Remediation Fortify Scan
		select = docGen.buildSelect(con, letterID, doc_id_list, main.evaluatorList, submit_reason_id, queryID, main.log_obj, main.i_dbg_level, printOnceFlg, params);
		
		if (letterID.equals("WITHDRAW_LETTER")) {
			if(manualWthdwlFlg == 1) { 
				select = select.replaceAll("and crj.created_user_id = 'SYSTEM' ", "");
			}
		}
		// TTP 324955 Security Remediation Fortify Scan
		query.prepareStatement(select);
		int placeCt = 1;
		for(int i = 0; i < params.size(); i++){
			String v = params.get(i);
			if(v.startsWith("'")){
			  query.setString(placeCt++, v.substring(1,v.length() - 1)); // no need for OWASP validation since Query does that by default
			}
			else if(v.contains(".")){
			   query.setFloat(placeCt++, Float.valueOf(v));
			}
			else{
			  query.setLong(placeCt++, Long.valueOf(v)); //in case the numeric is long, it is better not to lose precision
			}
		}
		query.executePreparedQuery();

		main.log(5, letterID + " <<QUERY>>: " + select + "\n");
			
		//query.executeQuery(select); 

		String request_id, document_id, evaluator_id, central_pro_server_id = "DEFAULT", job_name_txt = "DEFAULT";

		main.log(0, letterID + " Checking " + query.getRowCount()
				+ " apps for qualifying documents to print ");

		boolean newApp;

		while (query.next()) { // for each app found

			if (main.shuttingDown)
				break; // user forcing shutdown

			newApp = true;

			// main.log(5,letterID+" request_id:
			// "+query.getColValue("request_id"));

			request_id = query.getColValue("request_id");

			evaluator_id = query.getColValue("evaluator_id");

			// job_name_txt in printfax_queue table now holds the printer to
			// print to

			// DETERMINE WHICH CENTRAL PRO SERVER AND WHICH PRINTER TO USE
			// BASED ON LETTER TYPE AND EVALUATOR

			central_pro_server_id = query.getColValue("central_pro_server_id");

			if (letterID.equals("DECLINE_LETTER")) {
					job_name_txt = query.getColValue("turndown_printer_txt");
					if(lock_app_param == 1) { 
						PreparedStatement qryStatement = null;
						try {
						qryStatement = con.prepareStatement("update credit_request set app_lock_flg  = 1 where request_id = ?");
						qryStatement.setString(1,request_id);
						qryStatement.executeQuery();
						JournalEvents je = new JournalEvents(con,logFile);
						je.addJournal(new Long(request_id).intValue(),110,"App locked by Nightly Letters",ApplicationIDs.sysuser);
						} catch (Exception e) {
							e.printStackTrace();
						} finally {
							try{ if(qryStatement != null) qryStatement.close(); }catch(Exception e1){e1.printStackTrace();}
						}			
					}				
				}

			if (letterID.equals("WITHDRAW_LETTER"))
				job_name_txt = query.getColValue("turndown_printer_txt");

			if (letterID.equals("COUNTER_OFFER_LETTER"))
				job_name_txt = query.getColValue("counter_printer_txt");

			if (letterID.equals("WELCOME_LETTER"))
				job_name_txt = query.getColValue("welcome_printer_txt");

			if (letterID.equals("CLOSING_DOCUMENT"))
				job_name_txt = query.getColValue("welcome_printer_txt");

			if (letterID.equals("EARLY_DISCLOSURE_DOCUMENT"))
				job_name_txt = query.getColValue("welcome_printer_txt");

			if (letterID.equals("EXPIRED_OFFER_LETTER"))
				job_name_txt = query.getColValue("expired_offer_printer_txt");

			if (letterID.equals("FIRST_PAYMENT_LETTER"))
				job_name_txt = query.getColValue("first_payment_printer_txt");
				
			if (letterID.equals("HOUSING_COUNSEL_LETTER"))
				job_name_txt = query.getColValue("welcome_printer_txt");
				
			if (letterID.equals("GEN_NOTIFICATION_LETTER_1"))
				job_name_txt = query.getColValue("gen_notification_printer_txt");
				
			if (letterID.equals("GEN_NOTIFICATION_LETTER_2"))
				job_name_txt = query.getColValue("gen_notification_printer_txt");
			
			if (letterID.equals("GEN_NOTIFICATION_LETTER_3"))
				job_name_txt = query.getColValue("gen_notification_printer_txt");
			
			if (letterID.equals("GEN_NOTIFICATION_LETTER_4"))
				job_name_txt = query.getColValue("gen_notification_printer_txt");
				
			if (letterID.equals("GEN_NOTIFICATION_LETTER_5"))
				job_name_txt = query.getColValue("gen_notification_printer_txt");
			
			if (letterID.equals("GEN_NOTIFICATION_LETTER_6"))
				job_name_txt = query.getColValue("gen_notification_printer_txt");
			
			if (letterID.equals("GEN_NOTIFICATION_LETTER_7"))
				job_name_txt = query.getColValue("gen_notification_printer_txt");
				
			if (letterID.equals("GEN_NOTIFICATION_LETTER_8"))
				job_name_txt = query.getColValue("gen_notification_printer_txt");
			
			if (letterID.equals("GEN_NOTIFICATION_LETTER_9"))
				job_name_txt = query.getColValue("gen_notification_printer_txt");
			
			if (letterID.equals("GEN_NOTIFICATION_LETTER_10"))
				job_name_txt = query.getColValue("gen_notification_printer_txt");
			
			// Now find the document(s) in this category that we should print
			// for this
			// application. Currently, the only time we should find more than
			// one
			// is when we are printing a letter to be sent to the applicant and
			// co-applicant separately because they have different addresses

			/*
			 * For instance, in the counter_offer_letters category there is 4
			 * documents:
			 *
			 * counter-bureau used counter-bureau not used counter-bureau used
			 * (co-app different address) counter-bureau not used (co-app
			 * different address)
			 *
			 */


			/*
			 * Glenn 12/8/08, New enhancement for DocGen. If the DocGen config tables are populated then we want the docgen object to submit the print job based
			 * on the config tables.
			 */


			if (docGenList.length()>0) {

					sortByTxt = documentSortByText(main.sortQueryID, request_id, evaluator_id);
					// now that we have the app we want to print this letter for call docgen to submit the print request
					System.out.println("FOUND DOCGEN USING THIS FOR APS");
					main.log(0,"VALUES: ReasonID: "+submit_reason_id+" RunMODE: "+main.runMode+" Printer Name: "+job_name_txt+" batch_job_id: "+batch_job_id); 
				   docGen.generateTouchpointDocuments(con,evaluator_id,touchPoint,request_id,
						   central_pro_server_id, // central pro server ID
						   submit_reason_id, // submit reason
						   main.runMode, // runMode
						   job_name_txt, // printer name, if config_print_delivery.print_name_txt is specified then it will override this setting
						   batch_job_id, // batch job ID
						   main.concatBatchFiles, // concat batch file flag
						   "SYSTEM", // user ID
						   "0", // lock app by system flag
						   "0", // move to failed flag
						   "0" // doc hist seq ID (history docs)
                                                   ,main.suppressCheckForPrevPrintedDoc // boolean defaults to false
							,sortByTxt
						   );

			}
			else { // use the old config to define the documents to print (using the config_evaluator_documents table)

					document_id = getNextDocIDInCategory(queryDocsInCategory, true,
							evaluator_id);
					// TRUE - get first

					if (document_id == null) {
						main.log(0, letterID + " ERROR: Can't print app: " + request_id
								+ " because evaluator " + evaluator_id
								+ " has no documents assigned in this category");
						continue;
					}
                                        /* GL. 2/1/10 151041 - Make sure that this document has not been printed for any reason. Previous select
                                        allowed apps thru that did not have a doc printed for batch reasons, but now make sure this doc has not been printed.
                                        Ie. select an app if not docs were printed for a welcome letter, but here this doc may have already been printed for a co-app
                                        but we still want to print the doc for the applicant (two different doc ids)
                                        */
                                        /* GL. 9/5/12 CL160399 -o parm on startup will suppress this check
                                        */
                                        //TTP 324955 Security Remediation Fortify Scan
                                        String slct = " select request_id from credit_req_doc_history where request_id = ? and document_id = ? "
                                                         + " and (status_id = 'SUCCESS' or status_id = 'GENERATED')";
                                        Query queryDocHist = new Query(con);
                                        queryDocHist.prepareStatement(slct);
                                        queryDocHist.setInt(1, request_id); // don't need to parseInt because it's automatically done in Query class
                                        queryDocHist.setInt(2, document_id);
                                        queryDocHist.executePreparedQuery();

                                        if (!queryDocHist.next() || main.suppressCheckForPrevPrintedDoc)
					 if (genJob.doesDocumentPassWhenToUseCriteria(document_id,
							request_id)) {
                                              if (newApp) {
							appCount++;
							newApp = false;
						}

						String printer_txt = (getPrinter(queryDocsInCategory).equals("DEFAULT")) ? job_name_txt : getPrinter(queryDocsInCategory);
						Integer numCopies = getNumberOfCopies(queryDocsInCategory);
						for (int i = 0; i < numCopies; i++)
							submitPrintJob(request_id, document_id, evaluator_id,
									central_pro_server_id, printer_txt, submit_reason_id,
									letterID);

					} // found a document type to print

					// get any other docs to print for this app, like one to the co-app
					// address

					while ((document_id = getNextDocIDInCategory(queryDocsInCategory,
							false, evaluator_id)) != null) {
						// false - get next

                                           /* GL. 2/1/10 151041 - Make sure that this document has not been printed for any reason. Previous select
                                           allowed apps thru that did not have a doc printed for batch reasons, but now make sure this doc has not been printed.
                                           Ie. select an app if not docs were printed for a welcome letter, but here this doc may have already been printed for a co-app
                                           but we still want to print the doc for the applicant (two different doc ids)
                                           */
                                           //TTP 324955 Security Remediation Fortify Scan
                                           slct = " select request_id from credit_req_doc_history where request_id = ? and document_id = "
                                                            + " ? and (status_id = 'SUCCESS' or status_id = 'GENERATED')";
	                                        queryDocHist = new Query(con);
	                                        queryDocHist.prepareStatement(slct);
	                                        queryDocHist.setInt(1, request_id); // don't need to parseInt because it's automatically done in Query class
	                                        queryDocHist.setInt(2, document_id);
	                                        queryDocHist.executePreparedQuery();
                                           if (!queryDocHist.next())
						if (genJob.doesDocumentPassWhenToUseCriteria(document_id,
								request_id)) {
							if (newApp) {
								appCount++;
								newApp = false;
							}

							String printer_txt = (getPrinter(queryDocsInCategory).equals("DEFAULT")) ? job_name_txt : getPrinter(queryDocsInCategory);
							Integer numCopies = getNumberOfCopies(queryDocsInCategory);

							for (int i = 0; i < numCopies; i++)
								submitPrintJob(request_id, document_id, evaluator_id,
										central_pro_server_id, printer_txt,
										submit_reason_id, letterID);
						}

					} // while get other docs

			} // printing docs using the old method



		} // for each possible app found

	} // processLetterCatgeory

	// //////////////////////////////////////////////////////////////////////////////////

	/**
	 * @param letterID
	 * @param submit_reason_id
	 * @param evaluatorCheck
	 * @throws Exception
	 */
	public void processBatchDocuments(String letterID, String submit_reason_id,
			String evaluatorCheck) throws Exception {

		String document_id, delayDays, select, evaluator_name = "", last_evaluator_name = "xxx", docName = "";
		String evaluator_id, request_id;

		Query query = new Query(con);

		Query queryDocsInCategory = new Query(con);

		select = "select cr.evaluator_id, cr.document_id, cr.copies_to_print_num, cr.batch_printer_txt as alt_printer_txt, cd.batch_delay_days_num, cd.description_txt, e.evaluator_name_txt, "
				+ " e.central_pro_server_id, e.batch_printer_txt "
				+ " from config_evaluator_documents cr, config_documents cd, evaluator e where";
		try{ 
			select += SQLSecurity.basicSanitize(evaluatorCheck);
		}
		catch(SQLException se){
			main.log(0, "Class " + this.getClass() + "; Method processBatchDocuments; " + se.toString());
			throw se;
		}
		select += " cr.category_id = 'BATCH' and cr.document_id = cd.document_id and cr.evaluator_id = cd.evaluator_id and "
				+ " cd.batch_flg = 1 and (cd.closing_flg = 0 or cd.closing_flg is null) and cr.evaluator_id = e.evaluator_id "
				+ " order by cr.evaluator_id, cr.document_id";

		queryDocsInCategory.executeQuery(select);

		if (queryDocsInCategory.getRowCount() == 0) {
			main.log(	0,letterID	+ " No (non-closing) batch documents defined for evaluator list to print");
			return;
		}

		int numApps = 0, numCopies = 1;

		String central_pro_server_id, batch_printer_txt, alt_printer_txt;

		while (queryDocsInCategory.next()) {

			evaluator_name = queryDocsInCategory.getColValue(
					"evaluator_name_txt", "");

			if (!evaluator_name.equals(last_evaluator_name)) {
				main.log(0, letterID
						+ " Processing batch documents for evaluator: "
						+ evaluator_name);
				last_evaluator_name = evaluator_name;
			}

			document_id = queryDocsInCategory.getColValue("document_id");

			delayDays = queryDocsInCategory.getColValue("batch_delay_days_num",
					"0");

			evaluator_id = queryDocsInCategory.getColValue("evaluator_id", "0");

			docName = queryDocsInCategory
					.getColValue("description_txt", "none");

			central_pro_server_id = queryDocsInCategory.getColValue(
					"central_pro_server_id", "DEFAULT");

			alt_printer_txt = queryDocsInCategory.getColValue(
					"alt_printer_txt", "DEFAULT");

			batch_printer_txt = queryDocsInCategory.getColValue(
					"batch_printer_txt", alt_printer_txt);

			numCopies = Integer.parseInt(queryDocsInCategory.getColValue(
					"copies_to_print_num", "1"));

			/*
			 * lifted from requirements doc -
			 *
			 * Find apps that satisfy the following: 1) The InitDate is greater
			 * than or equal to the last run date minus the delay days for the
			 * document, and 2) The InitDate is less than or equal to today's
			 * date minus the delay days for the document
			 *
			 * 1 can not be satisfied because we are not keeping track of run
			 * dates for the NightlyLetterProcessor. It doesn't matter because
			 * the check is to limit the scope of selected apps. If an app all
			 * ready had this doc printed then it will be skipped by
			 * submitPrintJob. So the only side affect is that we may select
			 * apps that don't need to be processed (but the outcome is the
			 * same)
			 *
			 * So just implement 2.
			 *
			 */

			// Build a query to select the desired apps for this category
			//TTP 324955 Security Remediation Fortify Scan
			select = "select cr.request_id, cr.evaluator_id from credit_request cr where "
					+ "cr.evaluator_id = ? "
					+ " and trunc(initiation_dt) <= (trunc(sysdate) - ?)";

			main.log(0, letterID + "     Doc ID: " + document_id + " - "
					+ docName + ", delay days: " + delayDays);

			query.prepareStatement(select);
			query.setInt(1, evaluator_id);
			query.setInt(2, delayDays);
			query.executePreparedQuery();
			// main.log(0,letterID+" LETTERS:"+" found: "+query.getRowCount()+"
			// "+select);

			numApps = 0;

			// always send batch docs to the default server because not being
			// xref anywhere

			boolean updateCount;

			while (query.next()) {

				request_id = query.getColValue("request_id", "0");

				if (genJob.doesDocumentPassWhenToUseCriteria(document_id, request_id)) {
					updateCount = true;

					for (int i = 0; i < numCopies; i++){
						if (submitPrintJob(request_id, document_id, evaluator_id,
								central_pro_server_id, batch_printer_txt,
								submit_reason_id, letterID) && updateCount) {
							numApps++;
							appCount++; // grand total
							updateCount = false;
						}
					}
				}

			} // each app

			main.log(0, letterID + "     Processed " + numApps
					+ " applications");

		} // end while more batch docs to process

		return;

	} // end processBatchDocuments

	// ///////////////////////////////////////////////////////////////////

	boolean submitPrintJob(String request_id, String document_id,
			String evaluator_id, String central_pro_server_id,
			String job_name_txt, String submit_reason_id, String letterID)
			throws Exception {

		// first check to make sure this document has not already printed

		boolean printed = false;

		String next_job_id = "";

		Query queryTmp = new Query(con);

		/*
		 * a doc hist status will be GENERATED when the PrintFaxProcessor
		 * generates the output file. The Batch Lender Tool will set it to
		 * SUCCESS when it knows the lender has pulled the file to the browser
		 * for printing (at which point it also writes the system comment)
		 */

		queryTmp
				.prepareStatement("select request_id from credit_req_doc_history where "
						+ " request_id = ? "
						+ " and evaluator_id = ? "
						+ " and document_id = ? "
						+ " and (status_id = 'SUCCESS' or status_id = 'GENERATED')");
		queryTmp.setInt(1, request_id);
		queryTmp.setInt(2, evaluator_id);
		queryTmp.setInt(3, document_id);
		queryTmp.executePreparedQuery();
		sortByTxt = documentSortByText(main.sortQueryID, request_id, evaluator_id);
		
		if (!queryTmp.next() || letterID.equals("RISK_BASED_PRICING_LETTER")) { // not printed yet or letter is RBP then print

			// insert a job into the printfax_queue to print this document

			queryTmp.executeQuery("SELECT NEXT_JOB_ID.NEXTVAL AS next_job_id FROM DUAL");

			queryTmp.next();

			next_job_id = queryTmp.getColValue("next_job_id");

			// if we are running in ASP mode then docs are retrieved via a
			// browser
			// for printing, if we are running in LOCAL mode then we are
			// printing
			// docs via the RightFax Print server

			String job_type_txt = "ASP";
			if (main.runMode.equals("LOCAL"))
				job_type_txt = "Print";

			// if the command line parm -pPrinterName was supplied then store it
			// in job
			// name txt only if we are in LOCAL mode

			if (job_type_txt.equals("Print") && main.printerName.length() > 0)
				job_name_txt = main.printerName;
			// if a printer name is not supplied here then the default printer
			// for the
			// evaluator will be determined by the PrintFaxProcessor
			//TTP 324955 Security Remediation Fortify Scan
			SQLUpdate sqlup = new SQLUpdate();
			sqlup.SetPreparedUpdateStatement(con, "INSERT INTO printfax_queue ("
					+ "JOB_ID," + "PRIORITY_NUM," + "JOB_TYPE_TXT,"
					+ "EVALUATOR_ID," + "STATUS_ID," + "CREATE_DT,"
					+ "WHEN_TO_PROCESS_DT," + "REQUEST_ID," + "DOCUMENT_ID,"
					+ "USER_ID," + "COPIES_NUM," + "CENTRAL_PRO_SERVER_ID,"
					+ "JOB_NAME_TXT," + // this is really the printer name now
					"submit_reason_id,batch_job_id,batch_concat_flg,SORT_BY_TXT" +
					" ) values ("
					+ " ? "
					+ ",50,"
					+ " ? "
					+ ","
					+ " ? "
					+ ",'SUBMITTED',to_date('"
					+ " ? "
					+ "','"
					+ " ? "
					+ "'),"
					+ "to_date('"
					+ " ? "
					+ "','"
					+ " ? "
					+ "'),"
					+ " ? "
					+ ","
					+ " ? "
					+ ",'SYSTEM',1,'"
					+ " ? "
					+ "','"
					+ " ? "
					+ "',"
					+ " ? "
					+ ","
					+ " ? "
					+ ","
					+ " ? " 
					+ ", ? "
					+ ")");
			sqlup.setInt(1, next_job_id);
			sqlup.setString(2, job_type_txt);
			sqlup.setInt(3, evaluator_id);
			sqlup.setString(4, submitDate);
			sqlup.setString(5, NightlyLetters.DATEFORMAT);
			sqlup.setString(6, submitDate);
			sqlup.setString(7, NightlyLetters.DATEFORMAT);
			sqlup.setInt(8, request_id);
			sqlup.setInt(9, document_id);
			sqlup.setInt(10, central_pro_server_id);
			sqlup.setString(11, job_name_txt);
			sqlup.setString(12, submit_reason_id);
			sqlup.setInt(13, batch_job_id);
			sqlup.setInt(14, main.concatBatchFiles);
			sqlup.setString(15, sortByTxt);
			sqlup.RunPreparedUpdateStatement();
			main.log(5, letterID + " Submitted print request for App: "
					+ request_id + " document ID: " + document_id);

			// add a row to the credit_req_doc_history for this submission
			//TTP 324955 Security Remediation Fortify Scan
			SQLUpdate sqlup2 = new SQLUpdate();
			sqlup2.SetPreparedUpdateStatement(
							con,
							"insert into credit_req_doc_history (request_id,evaluator_id,create_dt,document_id,"
									+ "job_type_txt,status_id,user_id,copies_num,job_id,central_pro_server_id,"
									+ "job_name_txt,submit_reason_id,batch_job_id) values ("
									+ " ? "
									+ ","
									+ " ? "
									+ ","
									+ "to_date("
									+ " ? "
									+ ","
									+ " ? "
									+ "),"
									+ " ? "
									+ ",'Print','SUBMITTED','SYSTEM',1,"
									+ " ? "
									+ ","
									+ " ? "
									+ ","
									+ " ? "
									+ ","
									+ " ? "
									+ ", ? )");
			sqlup2.setInt(1, request_id);
			sqlup2.setInt(2, evaluator_id);
			sqlup2.setString(3, submitDate);
			sqlup2.setString(4, NightlyLetters.DATEFORMAT);
			sqlup2.setInt(5, document_id);
			sqlup2.setInt(6, next_job_id);
			sqlup2.setString(7, central_pro_server_id);
			sqlup2.setString(8, job_name_txt);
			sqlup2.setInt(9, submit_reason_id);
			sqlup2.setInt(10, batch_job_id);
			sqlup2.RunPreparedUpdateStatement();

			int reqID = Integer.parseInt(request_id);
			JournalEvents journal = new JournalEvents(con, null);
			journal.addJournal(reqID, 28, "Request to generate " + letterID
					+ " submitted", "SYSTEM"); // 28 - Letter

			printCount++;

			printed = true;

		} // not printed yet
		else
			main.log(5, letterID + " App: " + request_id
					+ " already printed document ID: " + document_id);

		return (printed);

	}

	// ///////////////////////////////////////////////////////////////////

	public String getNextDocIDInCategory(Query queryDocsInCategory,
			boolean getFirst, String evaluator_id) throws Exception {

		String catEvaluatorID;
		boolean foundOne = false;

		if (getFirst) {
			queryDocsInCategory.reset();
			while (queryDocsInCategory.next()) {
				catEvaluatorID = queryDocsInCategory.getColValue(
						"evaluator_id", "");
				if (catEvaluatorID.equals(evaluator_id)) {
					foundOne = true;
					break;
				}
			} // while finding by original eval ID

			// If didn't find one by the eval ID then look for a system
			// evaluator (-1)

			if (!foundOne) {
				queryDocsInCategory.reset();
				while (queryDocsInCategory.next()) {
					catEvaluatorID = queryDocsInCategory.getColValue(
							"evaluator_id", "");
					if (catEvaluatorID.equals("-1")) {
						foundOne = true;
						break;
					}
				}
			} // find system def

		} else {
			// compare against last one retrieved, if changed then no more
			catEvaluatorID = queryDocsInCategory
					.getColValue("evaluator_id", "");
			if (queryDocsInCategory.next())
				if (catEvaluatorID.equals(queryDocsInCategory.getColValue(
						"evaluator_id", ""))) {
					foundOne = true;
				}
		}

		if (!foundOne)
			return (null);

		return (queryDocsInCategory.getColValue("document_id"));

	} // end getNextDocIDInCategory()
    
	/**
	 * @param con, touchPointID
	 * @return boolean
	 */
	private boolean getPrintOnceFlg(Connection con,String touchpointID) {
		boolean printOnceFlg = true;
		try {
			Query queryTmp = new Query(con);
			 // Get the printOnce Flg for this touchpoint
			String sql="select print_once_flg from config_print_delivery where touchpoint_id = ? ";
			queryTmp.prepareStatement(sql);
			queryTmp.setString(1, touchpointID);
			queryTmp.executePreparedQuery();
			while (queryTmp.next()) {
			   printOnceFlg= queryTmp.getColValue("print_once_flg", "1").equals("1");
			}			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return printOnceFlg;
	}
	
	/**
	 * @param queryDocsInCategory
	 * @return
	 * @throws Exception
	 */
	private Integer getNumberOfCopies(Query queryDocsInCategory) throws Exception{
		return Integer.parseInt(queryDocsInCategory.getColValue("copies_to_print_num","1"));
	}

	/**
	 * @param queryDocsInCategory
	 * @return
	 * @throws Exception
	 */
	private String getPrinter(Query queryDocsInCategory) throws Exception{
		return queryDocsInCategory.getColValue("batch_printer_txt","DEFAULT");
	}

	//CL 157372 run a sort query id if passed in, retrieve the value and send it back to be saved on the printfax queue table
	public String documentSortByText(String qryID, String request_id, String evaluator_id)
	{
		String sortBy = "";
		Hashtable<String, String> runtimeValues = new Hashtable<String, String>();
		PreparedStatement ps = null;
		ResultSet rs = null;
		String sqlCheckIfQryExists;
		String sqlGetProdId;
		Query sortValQry;
		String product_id ="";
		
		runtimeValues.put("request_id", request_id);
		runtimeValues.put("evaluator_id", evaluator_id);
		//when to use flag = 10 is specific for the query type of "Nightly Letter Sort By"
		sqlCheckIfQryExists = "SELECT QUERY_ID FROM CONFIG_DOC_QUERIES WHERE evaluator_id =  ? AND QUERY_ID = ? AND WHEN_TO_USE_FLG = 10" ;
		sqlGetProdId = "select product_id from credit_request where request_id =?";
		try {
			
			 ps = con.prepareStatement(sqlGetProdId);
	         ps.setString(1, request_id);
	         rs = ps.executeQuery();

	         //if the query id passed in is a valid query id for this evaluator, we can attempt to run the query
	         if (rs.next()){
	        	 product_id = rs.getString("product_id");
	         }
	 			runtimeValues.put("product_id", product_id);
				
	         // close stmt
	         try { if (rs != null) rs.close();} catch (Exception e1) {e1.printStackTrace();}
			 try { if (ps != null) ps.close();} catch (Exception e1) {e1.printStackTrace();}
			 
			 ps = con.prepareStatement(sqlCheckIfQryExists);
	         ps.setString(1, evaluator_id);
	         ps.setString(2, qryID);
	         rs = ps.executeQuery();
	         //if the query id passed in is a valid query id for this evaluator and the "Nightly Letter Sort By" Query Type, we can attempt to run the query
	         if (rs.next()){
				sortValQry = genJob.buildAndExecuteQuery(con, qryID, request_id, runtimeValues);
				if(sortValQry.next()){
					sortBy = sortValQry.getColValue(1); //only retrieving the first value from the first result to append to file name
				}
	         }
	         
	         // close stmt
	         try { if (rs != null) rs.close();} catch (Exception e1) {e1.printStackTrace();}
			 try { if (ps != null) ps.close();} catch (Exception e1) {e1.printStackTrace();}

		} catch (Exception e) {
			main.log(0, "Error getting the sort by text for generated pdf: "+e);
		}
		finally {
	        // close stmt
	        try { if (rs != null) rs.close();} catch (Exception e1) {e1.printStackTrace();}
			try { if (ps != null) ps.close();} catch (Exception e1) {e1.printStackTrace();}
    	}
		return sortBy;
	}
} // ProcessThread

