package com.cmsinc.origenate.doc;

import java.io.*;
import java.util.*;
import java.sql.*;

import com.cmsinc.origenate.util.LogMsg;
import com.cmsinc.origenate.util.IniFile;
import com.cmsinc.origenate.util.COLEncrypt;
import com.cmsinc.origenate.util.Query;
import com.cmsinc.origenate.util.OWASPSecurity;

/*
 * NightlyLetters.java
 *
 * Created on July 18, 2002
 *
 * @author  Glenn Leyba
 * @version
 *
 * Searches for apps that need letters to be printed and for each app
 * submits a job to the printfax_queue
 *
 */
public class NightlyLetters extends Object {

	/*
	 * Version history
	 * 
	 * 1.0 - Initial release
	 */

	static String VERSION = "1.0";

	static String DATEFORMAT = "mm/dd/yy hh24:mi";

	String sHost = "";
	String sSIDname = "";
	String sUser = "";
	String sPass = "";
	String sPort = "";
	String sTNSEntry = "";
	String sIniFile = "";
	String eojFileName = "";
	String logFile = "";
	File eojFile = null; // file object used to find eoj file
	int runningThreads = 0;
	int i_dbg_level = 0;
	int lock_app = 0;
	IniFile ini = new IniFile();
	Vector<ProcessThread> processThreads = null;
	LogMsg log_obj = new LogMsg();
	String evaluatorList = "";
	String concatBatchFiles = "0";
	String letterIDList = "";
	public boolean shuttingDown = false;
	String submitDate = "";
	String runMode = "";
	String printerName = "";
	String queryID = "";
	String sortQueryID = "";
	int inclManualWthdwl = 0;
        boolean suppressCheckForPrevPrintedDoc=false;

	public NightlyLetters() {
	}

	// ///////////////////////////////////////////////////////////////////////////////

	static public void main(String args[]) {

		NightlyLetters nl = new NightlyLetters();
		try {
			nl.run(args);
		} catch (Exception e) {
		} // error already reported

		System.exit(0);
	}

	// /////////////////////////////////////////////////////////////////////////////////////

	private void GetArgs(String args[], LogMsg log_obj) {
		int ix;

		if (args.length > 0) {

			for (ix = 0; ix < args.length; ++ix) {

				if ((args[ix].charAt(0) != '-') && (args[ix].length() > 1)) {
					ShowUsage();
				}

				switch (args[ix].charAt(1)) {

				case 'i':
					sIniFile = args[ix].substring(2);
					log(0, "IniFile is '" + sIniFile + "'");
					try {
						//
						// Read host, user, sid and password from ini file
						//
						ini.readINIFile(sIniFile);

						logFile = ini.getINIVar(
								"logs.nightly_letters_log_file", "");
						if (logFile.length() > 0) {
							log_obj.openLogFile(logFile);
						}

						log(0, "NightlyLetters version " + VERSION
								+ " initializing...");

						sHost = ini.getINIVar("database.host", "");
						log(0, "Host is '" + sHost + "'");

						sPort = ini.getINIVar("database.port", "");
						log(0, "Port is '" + sPort + "'");

						sUser = ini.getINIVar("database.user", "");
						log(0, "User:" + sUser);

						sPass = ini.getINIVar("database.password", "");
						// log(0,"Password:"+sPass);

						sSIDname = ini.getINIVar("database.sid", "");
						log(0, "Database (SID name) is '" + sSIDname + "'");

						sTNSEntry = ini.getINIVar("database.TNSEntry", "");
						log(0, "TNS Entry is '" + sTNSEntry + "'");
					} catch (Exception e) {
						log(0, "Caught exception reading ini file '" + sIniFile
								+ "':" + e.toString());
					}
					break;

				case 'd': // turn debug on
					i_dbg_level = 5;
					log(0, "debugging turned on");
					break;
				
				case 'k': // locks the app in case of decline letter only
					lock_app = 1;
					log(0, "app will be locked when DECLINE_LETTER is generated");
					break;

					
				case 'j': // eoj file name
					eojFileName = args[ix].substring(2);
					log(0, "eoj file: " + eojFileName);
					break;

				case 'm': // run mode ASP or LOCAL
					runMode = args[ix].substring(2).toUpperCase();
					log(0, "Run mode: " + runMode);
					break;

				case 'p': // printer name
					printerName = args[ix].substring(2).toUpperCase();
					log(0, "Printer name: " + printerName);
					break;

				case 'c': // concat batch files
					concatBatchFiles = "1";
					log(0, "Concat Batch Files ON");
					break;

                                        //160399
				case 'o': // suppressing check if doc printed before
					suppressCheckForPrevPrintedDoc=true;
					log(0, "suppressing check if doc printed before");
					break;

				case 'e': // evaluator list
					evaluatorList = args[ix].substring(2);
					log(0, "Evaluator list: " + evaluatorList);
					break;

				case 'l': // letter ID list
					letterIDList = args[ix].substring(2);
					log(0, "Letter ID list: " + letterIDList);
					break;
					
				case 'q': //QueryID
					queryID = args[ix].substring(2);
					log(0, "Query ID: " + queryID);
					break;

				case 's': //Query ID used for sorting generated docs
					sortQueryID = args[ix].substring(2);
					log(0, "Sort Query ID: " + sortQueryID);
					break;
					
				case 'w': //used for including manual withdrawal letters
					inclManualWthdwl = 1;
					log(0, "Manual withdrawal letters will be included.");
					break;
					
				default:
					log(0, "Unknown parameter: " + args[ix]);
					ShowUsage();
					break;
				}
			} // for each parm

			// edits

			if ((sHost.length() == 0) || (sUser.length() == 0)
					|| (sSIDname.length() == 0) || (sPort.length() == 0)) {
				log(0, "Host,User,Pwd,SID or Port not specified in INI file");
				ShowUsage();
			}

			if (letterIDList.length() == 0) {
				log(0, "-l parm is required");
				ShowUsage();
			}
			if (runMode.length() == 0) {
				log(0, "-m parm is required, ie. -mASP or -mLOCAL");
				ShowUsage();
			}
			if (evaluatorList.length() == 0) {
				log(0, "-e parm is required");
				ShowUsage();
			}

			if (evaluatorList.toLowerCase().equals("all"))
				evaluatorList = "";

		} else {
			ShowUsage();
		}

	} // getArgs

	// //////////////////////////////////////////////////////////////////////////////////

	private void ShowUsage() {
		System.out.println("");
		System.out
				.println("Usage: java NightlyLetters -m<mode> -i<inifile> -e<evalID list> -l<letter list> -q<queryID> [-d] [-j<eoj file name>]");
		System.out.println("---------------------");
		System.out.println("-i - required: INI file to use for configuration");
		System.out
				.println("-e - required: evaluator ID list separated by commas (-e1279,1123,3312 or -eALL for all evaluators)");
		System.out
				.println("-l - required: letter ID list separated by commas (-lBATCH,DECLINE_LETTER,WITHDRAW_LETTER,COUNTER_OFFER_LETTER,EXPIRED_OFFER_LETTER,WELCOME_LETTER,FIRST_PAYMENT_LETTER,CLOSING_LETTER,EARLY_DISCLOSURE_DOCUMENT, RISK_BASED_PRICING_LETTER, HOUSING_COUNSEL_LETTER, GEN_NOTIFICATION_LETTER_1 - 10)");
		System.out.println("-q - used for GEN_NOTIFICATION_LETTER_1 - 10 (optional): QueryID");
		System.out
				.println("-s - optional: used for Document Name Sort Order (Sort Query ID)");
		System.out
				.println("-m - required: ASP or LOCAL, determines if batch documents will be printed locally or via a browser (ASP) ");
		System.out
				.println("-p - optional: RightFax printer name, applies only for mode = LOCAL");
		System.out.println("-j - optional: filename and path of eoj file");
		System.out
				.println("-d - optional: turns debug messages on.  (Default is off)");
		System.out
				.println("-o -  optional: turns off checking if a document has been printed before.  (Default is on)");
		System.out
				.println("-c - optional: concat batch files  (Default is off)");
		System.out
				.println("-k - optional: locks the application, applies only to letter ID = DECLINE_LETTER");
		System.out
				.println("-w - optional: includes manual withdraws, applies only to letter ID = WITHDRAW_LETTER");
		System.out
				.println("example: java NightlyLetters -ic:/development/origenatebin/origenate.ini -eALL -lDECLINE_LETTER,WELCOME_LETTER");
		System.exit(1);
	}

	// ///////////////////////////////////////////////////////////////////////////////

	void run(String args[]) throws Exception {
		Connection con = null;
		boolean shuttingDown = false;

		log(0, "NightlyLetters initializing..."); // to stderr

		GetArgs(args, log_obj);

		if (eojFileName.length() > 0) {
			
			/** OWASP Top 10 2010 - A4 path manipulation
			  * Change to the below code to fix vulnerabilities
			  * TTP 324955
			  */
			//eojFile = new File(eojFileName);
			//eojFile = new File(Encode.forJava(eojFileName));
			eojFile = new File(OWASPSecurity.validationCheck(eojFileName, OWASPSecurity.DIRANDFILE));
			if (eojFile.exists())
				eojFile.delete(); // make sure one doesn't already exist
		}

		String sConStr = "";

		// sConStr should be something like:

		// "jdbc:oracle:thin:@172.16.17.108:1521:cmsiprod"

		sConStr = "jdbc:oracle:thin:@";

		if (sTNSEntry.length() == 0) {
			sConStr = sConStr + sHost + ":" + sPort + ":" + sSIDname;
		} else {
			sConStr = sConStr + sTNSEntry;
			log(0, "Using TNS Entry");
		}

		try {

			// Load Oracle driver
			DriverManager.registerDriver(new oracle.jdbc.OracleDriver());

			log(0, "Connecting to database: " + sConStr);

			sPass = COLEncrypt.sDecrypt(sPass);

			// Connect to the Oracle database
			con = DriverManager.getConnection(sConStr, sUser, sPass);

		} catch (Exception e) {
			log(0, "Error connecting to database: " + e.toString());
			throw e;
		}

		Query queryTmp = new Query(con);

		String sql = "SELECT to_char(sysdate, ?) as curr_dt FROM DUAL";

		queryTmp.prepareStatement(sql);
		queryTmp.setString(1, DATEFORMAT);
		queryTmp.executePreparedQuery();
		queryTmp.next();

		submitDate = queryTmp.getColValue("curr_dt");

		// submitDate is used by all threads to indicate the date that all
		// related rows
		// in a batch were processed
		

		// create a thread for each type of letter to be processed

		log(0, "Starting letter threads...");

		processThreads = new Vector<ProcessThread>();

		StringTokenizer t = new StringTokenizer(letterIDList, ",");
		String letterID;
		Query query = new Query(con);
		runningThreads = 0;

		while (t.hasMoreTokens()) {
			letterID = t.nextToken().toUpperCase();
			sql = "select description_txt from mstr_doc_categories where category_id = ? ";
			queryTmp.prepareStatement(sql);
			queryTmp.setString(1, letterID);
			queryTmp.executePreparedQuery();
			if (!queryTmp.next()) {
				String msg = letterID + " not found in mstr_doc_categories";
				log(0, msg);
				throw new Exception(msg);
			} else {
				// create the thread but don't start it running yet
				ProcessThread pt = new ProcessThread(this, sConStr, sUser,
						sPass, letterID, lock_app, logFile, queryID, log_obj, submitDate, inclManualWthdwl);
				processThreads.addElement(pt);
				runningThreads++;
			}
		} // for each letter category

		// If we got this far then the letter ID list is valid so start
		// each thread to do the actual work

		ProcessThread pt;

		for (Enumeration<ProcessThread> e = processThreads.elements(); e.hasMoreElements();) {
			pt = e.nextElement();
			pt.start();
		}

		// Now wait for all threads to finish their work

		// wait for threads to end gracefully

		while (true) {

			if (threadCount(false) <= 0)
				break;

			// sleep 3 seconds
			try {
				Thread.sleep(3000);
			} catch (Exception e) {
			}

			if (!shuttingDown)
				if (eojFileExists())
					shuttingDown = true;

		}

		try {
			con.close();
		} catch (Exception e1) {
		}

		log(0, "NightlyLetters exiting.");

	} // run

	// /////////////////////////////////////////////////////////////////////////////////////

	public boolean eojFileExists() {

		if (eojFile != null && eojFile.exists()) {
			eojFile.delete();
			log(0, "EOJ file found, shutting down...");
			return (true);
		}
		return (false);
	}

	// //////////////////////////////////////////////////////////////////

	public synchronized void log(int level, String msg) {

		log_obj.FmtAndLogMsg(msg, i_dbg_level, level);

	}

	public synchronized int threadCount(boolean decreaseCount) {
		if (decreaseCount)
			runningThreads--;
		return (runningThreads);
	}
	


} // end class NightlyLetters
