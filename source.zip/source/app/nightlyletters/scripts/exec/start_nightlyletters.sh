
PATH=$PATH:$JAVA_HOME/bin;            export PATH

nohup java -classpath .:../lib/common.jar:../lib/classes111.jar com.cmsinc.origenate.doc.NightlyLetters  -i/opt/jrun4/servers/qs42/cfusion-ear/cfusion-war/config/origenate.ini -eALL -lDECLINE_LETTER,COUNTER_OFFER_LETTER,WELCOME_LETTER,EXPIRED_OFFER_LETTER,FIRST_PAYMENT_LETTER,INITIAL,FOLLOW_UP_1,FOLLOW_UP_2,MISSING_INFO -j/opt/origenate/qs42/nightlyletters/eoj >>err.out >>err.out & 
