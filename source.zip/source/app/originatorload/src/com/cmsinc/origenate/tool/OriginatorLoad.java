/**
 * OriginatorLoad
 * 
 * Author: michaelsw
 * Created: 01/29/2014
 * 
 * The Originator Load program takes an Originator Extract file
 * created by the OriginatorExtract standalone application
 * and posts the DealerLoadRq transactions contained in the file
 * to a DealerLoad web service. The purpose of this is to allow
 * one company to extract its dealers and then send its dealers
 * to another company's web service to load.
 * The Originator Extract file must be in a format provided by
 * default from the OriginatorExtract app. In particular, it must
 * not be styled to any other format.
 * This program accepts two required parameters and four optional
 * parameters:
 *  Required:
 *   File Name - the full path to the OriginatorExtract file
 *   Post URL - the endpoint URL of the web service to post to;
 *              for example: http://localhost:8300/orig-ws.war/services/DealerLoad
 *  Optional:
 *   User ID - the DealerLoad web service may be set to secure;
 *             if it is secure, it will need this parameter
 *   Password - if the DealerLoad is secure, it will need this parameter
 *   Log File - the full path to a log file; if this parameter is
 *              not provided, all logging will go to SystemOut
 *   Debug - a flag to determine the level of debugging; if not set, the logging
 *           will just contain high level information about the process and the
 *           status of each transaction; if set, each step of each transaction
 *           will be logged
 */

package com.cmsinc.origenate.tool;

import java.io.File;
import java.util.ArrayList;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang.StringEscapeUtils;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.cmsinc.origenate.util.LogMsg;
import com.cmsinc.origenate.util.PostRequest;
import com.cmsinc.origenate.util.XMLUtils;
import com.cmsinc.origenate.util.OWASPSecurity;

public class OriginatorLoad {
	
	public static void main(String[] args) {
		try {
			// Launch the application
			OriginatorLoad originatorLoad = new OriginatorLoad(args);
			originatorLoad.processFile();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	// Required fields
	private String fileName = "";
	private String postUrl = "";
	
	// Optional fields
	private String user = null;
	private String password = null;
	private LogMsg log = null;
	private boolean debug = false;
	
	public OriginatorLoad() {
		this("", "");
	}
	
	public OriginatorLoad(String[] args) {
		this("", "");
		getArgs(args);
	}
	
	public OriginatorLoad(String postUrl, String fileName) {
		this.postUrl = postUrl;
		this.fileName = fileName;
		this.log = new LogMsg();
		this.debug = false;
	}
	
	/**
	 * Sets the postUrl
	 * @param postUrl
	 */
	public void setPostUrl(String postUrl) {
		this.postUrl = postUrl;
	}
	
	/**
	 * Sets the fileName
	 * @param fileName
	 */
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	
	/**
	 * Sets the user
	 * @param user
	 */
	public void setUser(String user) {
		this.user = user;
	}
	
	/**
	 * Sets the password
	 * @param password
	 */
	public void setPassword(String password) {
		this.password = password;
	}
	
	/**
	 * Sets the debug
	 * @param debug
	 */
	public void setDebug(boolean debug) {
		this.debug = debug;
	}
	
	/**
	 * Points the log at a specific log file
	 * @param logFileName
	 */
	public void setLogFile(String logFileName) {
		try {
			if(log == null) {
				log = new LogMsg();
			}
			log.openLogFile(logFileName);
		} catch(Exception e) {
			log.FmtAndLogMsg("Log file " + logFileName + 
				" cannot be opened. Printing all logging to SystemOut");
			e.printStackTrace();
		}
	}
	
	/**
	 * Processes the {@link #fileName OriginatorExtract file} and posts the file
	 * to the specified {@link #postUrl DealerLoad Web Service URL}.
	 * @throws Exception If there was any issue converting the file to a 
	 * {@link Document} object or if the file contains invalid data.
	 */
	public void processFile() throws Exception {
		
		// Fields for tracking progress
		int numSuccess = 0;
		int numFailed = 0;
		long startTime = System.currentTimeMillis();
		
		log.FmtAndLogMsg("START OriginatorLoad.");
		
		// Turn the file into a Document object
		
		/**  
		* OWASP TOP 10 2010 - A4 Path Manipulation
		* TTP 324955
		* Changes to the below code to fix vulnerabilities
		*/
		/*String originatorXml = FileUtils.readFileToString(new File(fileName))
				.replace("\n", "") // replace newline and carriage return to
				.replace("\r", "") // allow it to parse correctly to document
				.replace("<Routing>", "<Routing Transaction=\"DealerLoadRq\">"); // required for web service	*/	
		//String originatorXml = FileUtils.readFileToString(new File(Encode.forJava(fileName)))
		String originatorXml = FileUtils.readFileToString(new File(OWASPSecurity.validationCheck(fileName, OWASPSecurity.DIRANDFILE)))		
								.replace("\n", "") // replace newline and carriage return to
								.replace("\r", "") // allow it to parse correctly to document
								.replace("<Routing>", "<Routing Transaction=\"DealerLoadRq\">"); // required for web service
		Document doc = XMLUtils.stringToXmlDocument(originatorXml);
		Node root = doc.getDocumentElement();
		
		// The file can be in one of two formats:
		// 1. ALL_ORIGINATORS tag with a series of ORIGINATOR tags as children
		// 2. A single ORIGINATOR tag containing DealerLoadRq XML
		//
		// Either format can also have a ShawBatchHeader tag, so check
		// the node name for each child to ensure it's the expected node.
		if(root.getNodeName().equals("ALL_ORIGINATORS")) { // Format 1
			NodeList childNodes = root.getChildNodes();
			for(int i = 0; i < childNodes.getLength(); i++) { // Loop over child nodes
				Node childNode = childNodes.item(i);
				if(childNode.getNodeName().equals("ORIGINATOR")) { // Check node name
					Node dealerLoadNode = childNode.getFirstChild(); // First child will be IFX tag beginning DealerLoadRq
					if(processDealerLoadNode(dealerLoadNode)) { // Process DealerLoadRq
						numSuccess++;
					} else {
						numFailed++;
					}
				}
			}
		} else if(root.getNodeName().equals("ORIGINATOR")) { // Format 2
			NodeList childNodes = root.getChildNodes();
			for(int i = 0; i < childNodes.getLength(); i++) { // Loop over child nodes
				Node childNode = childNodes.item(i);
				if(childNode.getNodeName().equals("IFX")) { // Check node name
					if(processDealerLoadNode(childNode)) { // Process DealerLoadRq
						numSuccess++;
					} else {
						numFailed++;
					}
				}
			}
		} else { // Invalid format
			throw new Exception("Invalid root node: " + root.getNodeName());
		}
		
		log.FmtAndLogMsg("END OriginatorLoad. Number of DealerLoadRq trans processed: " + 
				(numSuccess + numFailed) + ". Num successful = " + 
				numSuccess + ". Num failed = " + numFailed +
				". Total Time (in ms): " + 
				(System.currentTimeMillis() - startTime));
	}
	
	/**
	 * Processes an individual DealerLoadRq node. Takes the XML
	 * and posts it to the location specified by the 
	 * {@link #postUrl Post URL}. Will also record a log message
	 * indicating the success or failure of the post.
	 * @param dealerLoadNode Individual DealerLoadRq node to process
	 * @return <b>true</b> if node processed successfully, <b>false</b> otherwise
	 */
	private boolean processDealerLoadNode(Node dealerLoadNode) {
		String errorMessage = "";
		
		// Use the Dealer Code in the log messages to identify each record.
		String dealerCode = getTextContent(getFirstChildByTagName(dealerLoadNode, "DealerCode"));
		
		// Surround the entire processing logic inside try/catch block.
		// Any error conditions will throw an Exception, which will be
		// logged at the end.
		try {
			// Convert the node to an XML string
			String dealerLoadXml = "";
			try {
				dealerLoadXml = XMLUtils.nodeToXML(dealerLoadNode);
			} catch(Exception e) {
				e.printStackTrace();
				throw new Exception("Exception parsing DealerLoadRq node to XML: " + e.getMessage());
			}
			
			// Log the DealerLoadRq XML
			if(debug) {
				log.FmtAndLogMsg("Dealer Code = " + dealerCode + ". XML = " + dealerLoadXml);
			}
				
			// Add necessary args for WS post
			ArrayList<String> webServiceArgs = new ArrayList<String>();
			webServiceArgs.add(dealerLoadXml);	// in0
			if(user != null && password != null) {
				webServiceArgs.add(user); 		// in1
				webServiceArgs.add(password); 	// in2
			}
			
			// Build SOAP Envelope
			StringBuilder builder = new StringBuilder();
			builder.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
			builder.append("<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\">");
			builder.append("<soapenv:Body>");
			builder.append("<ns2:dealerUpdate xmlns:ns2=\"http://webservices.origenate.cmsinc.com\">");
			builder.append(transformArgsToXml(webServiceArgs));
			builder.append("</ns2:dealerUpdate>");
			builder.append("</soapenv:Body>");
			builder.append("</soapenv:Envelope>");
			
			// Log the Web Service URL and SOAP Request XML
			if(debug) {
				log.FmtAndLogMsg("Dealer Code = " + dealerCode + ". Post to URL: " + postUrl);
				log.FmtAndLogMsg("Dealer Code = " + dealerCode + ". SOAP Request: " + builder.toString());
			}
		
			// Post SOAP Envelope to Web Service
			String response = "";
			try {
				PostRequest postRequest = new PostRequest();
				postRequest.setHeaderProperty("SOAPAction", "");
				response = postRequest.post(postUrl,	// URL
					builder.toString(), 				// SOAP XML
					0);									// No Timeout
			} catch(Exception e) {
				e.printStackTrace();
				throw new Exception("Exception posting XML to Web Service: " + e.getMessage());
			}
			
			// Log the SOAP Response from the Web Service
			if(debug) {
				log.FmtAndLogMsg("Dealer Code = " + dealerCode + ". SOAP Response: " + response);
			}
			
			// Look for the DealerUpdate tag in the response XML
			String dlrUpdtResponse = getXmlTag(StringEscapeUtils.unescapeXml(response), "DealerUpdate");
			if(dlrUpdtResponse == null) {
				throw new Exception("DealerUpdate tag not found in response: " + dlrUpdtResponse);
			}
			
			// Get the Return Code and return Message tags
			String returnCode = getXmlTagValue(dlrUpdtResponse, "ReturnCode");
			String message = getXmlTagValue(dlrUpdtResponse, "Msg");
			if(returnCode == null) {
				throw new Exception("ReturnCode tag not found in DealerUpdate response: " + dlrUpdtResponse);
			}
			
			// Log the DealerUpdate section from the SOAP Response
			// as well as the Return Code and Message
			if(debug) {
				log.FmtAndLogMsg("Dealer Code = " + dealerCode + ". DealerUpdate XML from response: " + 
						dlrUpdtResponse);
				log.FmtAndLogMsg("Dealer Code = " + dealerCode + ". Return Code from response: " + 
						returnCode);
				log.FmtAndLogMsg("Dealer Code = " + dealerCode + ". Message from response: " + 
						message);
			}
			
			// Return code of 0 indicates success, 1 indicates failure
			if(!returnCode.equals("0")) { // failure
				throw new Exception("DealerLoad returned error: " + message);
			}
		} catch(Exception e) {
			errorMessage = e.getMessage();
		}
		
		// Log the status of this DealerLoadRq node
		if(!errorMessage.equals("")) {
			log.FmtAndLogMsg("Error adding Dealer Code = " + dealerCode + "; Error = " + errorMessage);
			return false;
		} else {
			log.FmtAndLogMsg("Successfully imported Dealer Code = " + dealerCode);
			return true;
		}
	}
	
	/**
	 * Gets the required and optional parameters from the args
	 * @param args List of command line arguments
	 */
	private void getArgs(String[] args) {
		if(args.length > 0) {
			for(int i = 0; i < args.length; i++) {
				if(args[i].charAt(0) != '-' && args[i].length() > 1) {
					ShowUsage();
				}
				
				String arg = args[i].substring(2);
				
				switch(args[i].charAt(1)) {
				
				case 'i': // File Name
					setFileName(arg);
					break;
				case 'u': // Post URL
					setPostUrl(arg);
					break;
				case 's': // User ID
					setUser(arg);
					break;
				case 'p': // Password
					setPassword(arg);
					break;
				case 'l': // Log File
					setLogFile(arg);
					break;
				case 'd': // Debug
					setDebug(true);
					break;
				default: // Invalid Arg
					ShowUsage();
					break;
					
				}
			}
		}
		
		// Check required fields
		if(fileName == null || fileName.equals("")) {
			log.FmtAndLogMsg("File Name is required. Exiting.");
			ShowUsage();
		} else if(postUrl == null || postUrl.equals("")) {
			log.FmtAndLogMsg("Post URL is required. Exiting.");
			ShowUsage();
		} else if(!checkFile(fileName)) {
			log.FmtAndLogMsg("File " + fileName + " does not exist. Exiting.");
			ShowUsage();
		}
	}
	
	/**
	 * Prints the usage instructions to SystemOut and exits the application.
	 */
	private static void ShowUsage() {
		System.out.println();
		System.out.print("Usage: java OriginatorLoad -i<input file> -u<post url> ");
		System.out.println("-s<user id> -p<password> -l<log file> -d");
		System.out.println("----------------------------------------------");
		System.out.println("-i - required: Full path to Originator Extract file");
		System.out.println("-u - required: URL of DealerLoad web service; ex: http://localhost:8300/orig-ws.war/services/DealerLoad");
		System.out.println("-s - optional: User ID if DealerLoad web service is set to Secure");
		System.out.println("-p - optional: Password if DealerLoad web service is set to Secure");
		System.out.println("-l - optional: Full path to OriginatorLoad log file");
		System.out.println("-d - optional: If this flag is set, additional debugging will be logged");
		
		System.exit(1);
	}
	
	/**
	 * Checks if file exists.
	 * @param fileName Name of the file to check for
	 * @return <b>true</b> if file exists, <b>false</b> otherwise
	 */
	
	private static boolean checkFile(String fileName) {
		
		/**  
		* OWASP TOP 10 2010 - A4 Path Manipulation
		* Changes to the below code to fix vulnerabilities
		* TTP 324955
		*/
		//return new File(fileName).exists();
		//return new File(Encode.forJava(fileName)).exists();
		boolean checkIfFileExists=false;
		try
		{
		checkIfFileExists=new File(OWASPSecurity.validationCheck(fileName, OWASPSecurity.DIRANDFILE)).exists();
		}
		catch(Exception e)
		{
		e.printStackTrace();
		}
		return checkIfFileExists;
	}
	/**
	 * Find the first instance of a tag in the XML string and returns
	 * the tag as well as its contents. Returns null if the tag
	 * does not exist.
	 * @param xml XML string to search
	 * @param tagName Tag name to search for
	 * @return The specified tag and its contents
	 */
	private static String getXmlTag(String xml, String tagName) {
		String startTag = buildTag(tagName);
		String endTag = buildTag(tagName, true);
		
		if(xml.indexOf(startTag) > 0 && xml.indexOf(endTag) > 0) {
			return xml.substring(xml.indexOf(startTag), xml.indexOf(endTag) + endTag.length());
		}
		
		return null;
	}
	
	/**
	 * Finds the first instance of a tag in the XML string and returns
	 * the text inside of the tag. Returns null if the tag does not exist.
	 * @param xml XML string to search
	 * @param tagName Tag name to search for
	 * @return The text inside of the specified tag
	 */
	private static String getXmlTagValue(String xml, String tagName) {
		String startTag = buildTag(tagName);
		String endTag = buildTag(tagName, true);
		
		if(xml.indexOf(startTag) > 0 && xml.indexOf(endTag) > 0) {
			return xml.substring(xml.indexOf(startTag) + startTag.length(), xml.indexOf(endTag));
		}
		
		return null;
	}
	
	/**
	 * Build an XML start tag as a string.<br />
	 * For example, if the <i>tagName</i> is <b>Dealer</b>,
	 * the output would look like the following:<br>
	 * <b>&lt;Dealer&gt;</b><br />
	 * @param tagName The name of the tag
	 * @see #buildTag(String, boolean)
	 */
	private static String buildTag(String tagName) {
		return buildTag(tagName, false);
	}
	
	/**
	 * Builds an XML tag string based on the tag name. If the
	 * tag is an end tag, it will be built as an XML end tag.<br />
	 * For example, if the <i>tagName</i> is <b>Dealer</b>,
	 * the output would look like the following:<br>
	 * 1. If <i>isEndTag</i> is <b>false</b>: <b>&lt;Dealer&gt;</b><br />
	 * 2. If <i>isEndTag</i> is <b>true</b>:  <b>&lt;/Dealer&gt;</b>
	 * @param tagName The name of the tag
	 * @param isEndTag If the tag to be built is an end tag
	 * @return The XML tag as a String
	 */
	private static String buildTag(String tagName, boolean isEndTag) {
		StringBuilder tag = new StringBuilder();
		
		tag.append("<");
		if(isEndTag) {
			tag.append("/");
		}
		tag.append(tagName);
		tag.append(">");
		
		return tag.toString();
	}
	
	/**
	 * Gets the first child of the provided {@link Node} that matches
	 * the specified tag name. If none is found, returns null.
	 * @param node
	 * @param tagName The tag name to search for
	 * @return The first Node object that matches the tag name
	 */
	private static Node getFirstChildByTagName(Node node, String tagName) {
		try {
			NodeList nodeList = ((Element)node).getElementsByTagName(tagName);
			if(nodeList.getLength() > 0) {
				return nodeList.item(0);
			}
		} catch(Exception e) {
			e.printStackTrace();
		}
		
		return null;
	}
	
	/**
	 * Gets the text content of a {@link Node}. If the node is null,
	 * returns null.
	 * @param node
	 * @return The text content of the node
	 */
	private static String getTextContent(Node node) {
		if(node == null) {
			return null;
		}
		
		return node.getTextContent();
	}
	
	/**
	 * Loops through a list of args and builds them into a string of
	 * args to pass to the web service. Each arg will be surrounded
	 * by an <i>&lt;in&gt;</i> tag, with the tag being incremented.<br />
	 * Ex: If the args contains the values <b>Hello</b> and <b>World</b>,
	 * the resulting string would be:
	 * <b>&lt;in0&gt;Hello&lt;/in0&gt;&lt;in1&gt;World&lt;in1&gt;</b>
	 * @param args List of args to build
	 * @return String containing args as XML parameters
	 */
	private static String transformArgsToXml(ArrayList<String> args) {
		StringBuilder builder = new StringBuilder();
		int i = 0;
		for(String arg : args) {
			builder.append("<in");
			builder.append(i);
			builder.append(">");
			builder.append(StringEscapeUtils.escapeXml(arg));
			builder.append("</in");
			builder.append(i);
			builder.append(">");
			i++;
		}
		return builder.toString();
	}
}
