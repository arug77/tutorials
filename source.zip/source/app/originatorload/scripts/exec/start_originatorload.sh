#!/bin/sh
#
# sample call to originator load
# the args will need to be changed
#

ORIGINATORLOAD_ARGS="-iC:\opt\origenate\or_dev88\data\originatorextract\OriginatorTest.txt -uhttp://cmap05:9082/orig-ws.war/services/DealerLoad -lc:/development/dealerload.log -d"
echo "java -classpath .:../lib/common.jar:../lib/commons-io-1.3.1.jar:../lib/commons-lang-2.1.jar:../lib/commons-logging.jar com.cmsinc.origenate.tool.OriginatorLoad $ORIGINATORLOAD_ARGS"
java -classpath .:../lib/common.jar:../lib/commons-io-1.3.1.jar:../lib/commons-lang-2.1.jar:../lib/commons-logging.jar com.cmsinc.origenate.tool.OriginatorLoad $ORIGINATORLOAD_ARGS

