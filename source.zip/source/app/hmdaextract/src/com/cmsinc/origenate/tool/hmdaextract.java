package com.cmsinc.origenate.tool;

/*
 * hmdaextract.java
 *
 * Created 10/04/07 by B. Snyder
 *
 * Used to extract HMDA data from the Origenate db and write a file to disk
 * the format of the file is configurable.  Currently we support the government file format
 * and CRA Wiz
 *
 */

import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Vector;
import java.lang.Math;
import java.sql.*;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.cmsinc.origenate.xmldbt.TransformerUtils;
import com.cmsinc.origenate.util.DBConnection;
import com.cmsinc.origenate.util.IniFile;
import com.cmsinc.origenate.util.Query;
import java.sql.PreparedStatement;


public class hmdaextract {
	private Connection conn = null;
	private String export_id = "";
	// get details about the configuration - evaluator, selection criteria, etc
	private int evaluator_id = 0, total_apps = 0, numRecord = 0;
	private int action = 0, debug_flg = 0;
	private StringBuffer xmlbuffer = null;
	private String s_xslt = null;
	private String s_xslt_inifile = null;
	private int hmda_data_id = 0;
	private List<Argument> argumentList = null;

	public static void main(String args[]) {
		// create hmda object
		hmdaextract he = new hmdaextract();

		// get program parameters
		// he.getArgs(args);
		// he.getArgsCLI(args);
		if (!he.getArgsNative(args))
			return;

		// create file to write output to
		File hmda_xml_file = null;
		BufferedWriter hmda_xml_stream = null;
		try {
			hmda_xml_file = new File("hmda.dat");
			hmda_xml_file.createNewFile();
			hmda_xml_stream = new BufferedWriter(new FileWriter(hmda_xml_file));
		} catch (Exception e) {
			System.out.println("Exception: error creating file hmda.dat; " + e);
			e.printStackTrace();
			hmda_xml_file.deleteOnExit();
			try {
				he.conn.close();
			} catch (Exception e1) {
			}
			System.exit(0);
		}

		// generate selection query
		//String sql = he.createSelectionQuery();
		// determine apps to select
		// since oracle won't allow outer joins to subqueries, i had to nest
		// case statements to allow null programs to be hmda eligible for non
		// home equity products
		String[] query_tokens = null;
		String sql1;
		String sql_date = "";
		String selection_sql_where = "where cr.evaluator_id = ? "
				+ " and ", selection_sql_from = "select cr.request_id, to_char(sysdate,'YYYYMMDDHH24MI') as timestamp, cr.product_id, "
				+ "CASE WHEN (cr.product_id != 16 AND cr.product_id != 17 AND cr.product_id != 22 )"
				+ " 	  THEN (CASE (SELECT nvl(hmda_eligible_flg,1)"
				+ "	              FROM config_product_program cpp, credit_request_loan crl "
				+ "				  WHERE cr.request_id = crl.request_id"
				+ "				  AND cpp.evaluator_id = cr.evaluator_id"
				+ "				  AND cpp.product_id = cr.product_id"
				+ "				  AND crl.program_id = cpp.program_id)"
				+ "	  		WHEN 0 THEN 0"
				+ "   		WHEN 1 THEN 1"
				+ "   		ELSE 1 END) "
				+ "      WHEN (cr.product_id = 16 OR cr.product_id = 17)"
				+ "	   THEN (CASE (SELECT nvl(hmda_eligible_flg,1)"
				+ "				   FROM config_product_program cpp, credit_request_home_loan crhl"
				+ "                  WHERE cr.request_id = crhl.request_id"
				+ " 				   AND cpp.evaluator_id = cr.evaluator_id"
				+ "				   AND cpp.product_id = cr.product_id"
				+ "				   AND crhl.program_id = cpp.program_id)"
				+ "			 WHEN 0 THEN 0"
				+ "			 WHEN 1 THEN 1"
				+ "            ELSE 0 END)"
				+ "	  WHEN (cr.product_id = 22)"
				+ "	  THEN (CASE (SELECT nvl(hmda_eligible_flg,1)"
				+ "				  FROM config_product_program cpp, credit_request_credit_card crcc"
				+ "				  WHERE cr.request_id = crcc.request_id"
				+ "				  AND cpp.evaluator_id = cr.evaluator_id"
				+ "				  AND cpp.product_id = cr.product_id"
				+ "				  AND crcc.program_id = cpp.program_id)"
				+ " 			WHEN 0 THEN 0"
				+ "           WHEN 1 THEN 1"
				+ "			ELSE 1 END) "
				+ "END as program_eligible_flg from credit_request cr";
		PreparedStatement ps1 = null;
		ResultSet rs1 = null;
		boolean[] placeholders = new boolean[3];
		try {
			sql1 = "SELECT timeframe_id, days_to_extract_num, to_char(range_from_dt,'MM/DD/YY HH24:MI:SS') as range_from_dt, to_char(range_to_dt,'MM/DD/YY HH24:MI:SS') as range_to_dt, "
					+ "date_type_id, selection_criteria_id, nvl(incl_incomplete_apps_flg,1) as incl_incomplete_apps_flg, stylesheet_txt, hmda_extract_query_id "
					+ "FROM config_hmda_extract_profile "
					+ "WHERE evaluator_id = ? AND extract_profile_id = ?";

			ps1 = he.conn.prepareStatement(sql1);

			ps1.setInt(1, he.evaluator_id);
			ps1.setString(2, he.export_id);

			rs1 = ps1.executeQuery();

			if (rs1.next()) {
				int sql_date_id = rs1.getInt("date_type_id");
				if(sql_date_id == 0){
					sql_date = "initiation_dt";
				}
				else if(sql_date_id == 1){
					sql_date = "action_dt";
				}
				// create xslt
				he.s_xslt = rs1.getString("stylesheet_txt");

				if (!he.s_xslt.toLowerCase().startsWith("http")
						&& !he.s_xslt.startsWith("/")
						&& !he.s_xslt.startsWith(File.separator)) {
					/*
					 * The value is neither a http address nor an absolute path,
					 * so we read the mpe.xslt_dir value from origenate.ini and
					 * treat that as the working directory and just grab the
					 * name of the ini file from the databse
					 *
					 * TransformerUtils.toString(String, String) already has the
					 * ability to read a http link as well as an absolute path
					 * (#167322) - chrisk
					 */
					if (he.s_xslt_inifile.endsWith(File.separator)
							|| he.s_xslt_inifile.endsWith("/"))
						he.s_xslt = he.s_xslt_inifile + he.s_xslt;
					else
						he.s_xslt = he.s_xslt_inifile + "/" + he.s_xslt;
				}
				
				if (rs1.getString("timeframe_id") != null) {
					// use timeframe
					switch (rs1.getInt("timeframe_id")) {
						case 0 :
							// current month
							selection_sql_where += sql_date
							+ " >= last_day(add_months((trunc(sysdate)+0/86400),-1))+1";
							break;
						case 1 :
							// previous month
							selection_sql_where += sql_date 
									+ " >= last_day(add_months((trunc(sysdate)+0/86400),-2))+1 and "
									+ sql_date
									+ " <= last_day(add_months((trunc(sysdate)-1/86400),-1))";
							break;
						case 2 :
							// current quarter
							selection_sql_where += sql_date
							+ " >= to_date(decode(to_char((trunc(sysdate)+1/86400),'Q'),1,'01/01/',2,'04/01/',3,'07/01/',4,'10/01/')||to_char((trunc(sysdate)+1/86400),'YYYY'),'MM/DD/YYYY')";
							break;
						case 3 :
							// previous quarter
							selection_sql_where += sql_date
									+ " >= to_date(decode(to_char((trunc(sysdate)+1/86400),'Q'),1,'10/01/'||to_char((trunc(sysdate)+1/86400)-100,'YYYY'),2,'01/01/'||to_char((trunc(sysdate)+1/86400),'YYYY'),3,'04/01/'||to_char((trunc(sysdate)+1/86400),'YYYY'),4,'07/01/'||to_char((trunc(sysdate)+1/86400),'YYYY')),'MM/DD/YYYY') and "
									+ sql_date 
									+ " < to_date(decode(to_char((trunc(sysdate)-1/86400),'Q'),1,'01/01/'||to_char((trunc(sysdate)-1/86400)-100,'YYYY'),2,'04/01/'||to_char((trunc(sysdate)-1/86400),'YYYY'),3,'07/01/'||to_char((trunc(sysdate)-1/86400),'YYYY'),4,'10/01/'||to_char((trunc(sysdate)-1/86400),'YYYY')),'MM/DD/YYYY')";
							break;
						case 4 :
							// ytd
							selection_sql_where += sql_date 
									+ " >= to_date('01/01/'||to_char((trunc(sysdate)+1/86400),'YYYY'), 'MM/DD/YYYY')";
							break;
						default :
							System.out.println("Unknown timeframe_id...will use current month");
							selection_sql_where += sql_date
									+ " >= last_day(add_months((trunc(sysdate)+1/86400),-1))+1";
							break;
					}
				} else if (rs1.getString("days_to_extract_num") != null) {
					// use days prior to extract date
					selection_sql_where += sql_date 
							+ " >= (trunc(sysdate)+1/86400) - "
							+ rs1.getInt("days_to_extract_num");
				} else if (rs1.getString("range_from_dt") != null
						&& rs1.getString("range_to_dt") != null) {
					// use daterange
					selection_sql_where += sql_date
							+ " >= ? and " + sql_date
							+ " <= ? ";
					placeholders[0] = true;
				} else {
					System.out.println("Exception:  there is no valid time frame to use.");
					try{
			        if(rs1 != null) rs1.close();
					}
					catch(Exception e){
						e.printStackTrace();
					}
					finally{
						try {if(ps1 != null) ps1.close();} catch (Exception e) {e.printStackTrace();}
					}
					System.exit(0);
				}

				// if using action date, we need to include hmda table it comes
				// from and join to credit_request
				if (sql_date.equals("action_dt")) {
					selection_sql_from += ", credit_request_hmda hmda";
					selection_sql_where += " and cr.request_id = hmda.request_id";
				}

				// whether to include incomplete apps or not
				if (rs1.getInt("incl_incomplete_apps_flg") == 0) {
					// activity_id = 26 is hmda activity
					selection_sql_from += ", credit_request_activity cra";
					selection_sql_where += " and cra.request_id = cr.request_id and cra.activity_id = 26 and activity_status_id = 3";
				}

				if (rs1.getString("hmda_extract_query_id") != null) {
					selection_sql_where += " and cr.request_id in (";
					selection_sql_where += he.buildQuery(he.conn, rs1.getString("hmda_extract_query_id"), Integer.valueOf(he.evaluator_id).toString());
					selection_sql_where += ") ";
				}

				switch (rs1.getInt("selection_criteria_id")) {
					case 0 :
						// all eligible hmda apps...changed to include
						// respective
						// programs for any product (except lease)...this was
						// done
						// above in select statement because null won't work
						// here
						selection_sql_from += ", config_loan_purpose clp";
						selection_sql_where += " and nvl(clp.hmda_eligible_flg,0) = 1 and clp.evaluator_id = cr.evaluator_id AND clp.product_id = cr.product_id AND clp.loan_purpose_id = cr.loan_purpose_id ";
						break;
					case 1 :
						// all eligible hmda apps not in a previous extract
						selection_sql_from += ", config_loan_purpose clp";
						selection_sql_where += " and nvl(clp.hmda_eligible_flg,0) = 1 and clp.evaluator_id = cr.evaluator_id AND clp.product_id = cr.product_id AND clp.loan_purpose_id = cr.loan_purpose_id ";
						selection_sql_where += "AND NOT EXISTS (select 1 from credit_request_hmda_extract crhe where crhe.evaluator_id = ? "
								+ " and crhe.hmda_extract_id = ? "
								+ " and cr.request_id = crhe.request_id) ";
						placeholders[1] = true;
						break;
					case 2 :
						// all eligible hmda apps not in a previous extract OR
						// action date is newer than extract date
						selection_sql_from += ", config_loan_purpose clp";
						selection_sql_where += " and nvl(clp.hmda_eligible_flg,0) = 1 and clp.evaluator_id = cr.evaluator_id AND clp.product_id = cr.product_id AND clp.loan_purpose_id = cr.loan_purpose_id ";
						selection_sql_where += "AND NOT EXISTS (select 1 from credit_request_hmda_extract crhe, credit_request_hmda crh where crh.request_id = crhe.request_id AND crh.action_dt < crhe.generated_dt AND crhe.evaluator_id = ? "
								+ " and crhe.hmda_extract_id = ? and cr.request_id = crhe.request_id) ";
						placeholders[2] = true;
						break;
					default :
						System.out.println("Unknown selection_criteria_id...will use all eligible hmda apps");
						selection_sql_from += ", config_loan_purpose clp";
						selection_sql_where += " and nvl(clp.hmda_eligible_flg,0) = 1 and clp.evaluator_id = cr.evaluator_id AND clp.product_id = cr.product_id AND clp.loan_purpose_id = cr.loan_purpose_id ";
						break;
				}
			} else {
				System.out.println("Exception:  could not find an extract configured for evaluator_id = "
						+ he.evaluator_id + ", and extract_id = " + he.export_id);
				try{
			        if(rs1 != null) rs1.close();
			    }
				catch(Exception e){
					e.printStackTrace();
				}
				finally{
					try {if(ps1 != null) ps1.close();} catch (Exception e) {e.printStackTrace();}
				}
				System.exit(0);
			}

		} catch (Exception e) {
			System.out.println("Exception: error looking up extract. " + e);
			e.printStackTrace();
			try{
			    if(rs1 != null) rs1.close();
			}
			catch(Exception e1){
				e1.printStackTrace();
			}
			finally{
				try {if(ps1 != null) ps1.close();} catch (Exception e2) {e2.printStackTrace();}
			}
			System.exit(0);
		} finally {
		    try{ if(rs1 != null) rs1.close(); }catch(Exception e1){e1.printStackTrace();}
			try{ if(ps1 != null) ps1.close(); }catch(Exception e1){e1.printStackTrace();}
		}
		String sql = selection_sql_from + " " + selection_sql_where;
		// end generation of SQL
		PreparedStatement stmt = null;
		ResultSet rs = null;
		Statement update_stmt = null;
        PreparedStatement ps = null;

		if (he.debug_flg != 0)
			System.out.println("selection query: " + sql);

		try {
			// identify apps to export
			stmt = he.conn.prepareStatement(sql, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
			stmt.setInt(1, he.evaluator_id);
			int placeCt = 2;
			if(placeholders[0]){
				DateFormat df = new SimpleDateFormat("MM/dd/yy HH:mm:ss");
				Date rangeFrom = df.parse(rs1.getString("range_from_dt"));
				Date rangeTo = df.parse(rs1.getString("range_to_dt"));
				stmt.setDate(placeCt++, new java.sql.Date(rangeFrom.getTime()));
				stmt.setDate(placeCt++, new java.sql.Date(rangeTo.getTime()));
			}
			if(placeholders[1]){
				stmt.setInt(placeCt++, he.evaluator_id);
				stmt.setString(placeCt++, he.export_id);
			}
			if(placeholders[2]){
				stmt.setInt(placeCt++, he.evaluator_id);
				stmt.setString(placeCt++, he.export_id);
			}
			/**
			 * OWASP TOP 10 2010 - A1 High SQL Injection
			 *  TTP 324955 Security Remediation Fortify Scan
			 */
			rs = stmt.executeQuery();
			//rs = stmt.executeQuery(ESAPI.encoder().encodeForSQL( new OracleCodec(),sql.toString()));

			update_stmt = he.conn.createStatement();

			// setup transformer for applying xsl stylesheet
			// StreamSource in = null;

			// need to count total number of apps identified because there is no
			// rowcount available and we don't want to rerun the select with
			// count(*)
			while (rs.next()) {
				// only count this if program was hmda eligible
				if (rs.getInt(4) == 1) {
					he.total_apps++;
				}
			}
			// reset recordset
			rs.beforeFirst();

			// we may be exporting other products now that hmda isn't just home
			// equity apps
			int productId = 0;

			// for each identified app, export it
			while (rs.next()) {
				if (rs.getInt(4) == 1) {
					try {
						he.numRecord++;

						// reinitialize for each app
						he.xmlbuffer = new StringBuffer(4096);

						// create xml to be styled for this app
						he.xmlbuffer.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?><HMDA><LenderHeader>");

						he.writeHeader();

						he.xmlbuffer.append("<TotalApps>" + he.total_apps
								+ "</TotalApps></LenderHeader>");

						he.xmlbuffer.append("<Record>" + he.numRecord
								+ "</Record><TimeStamp>" + rs.getString(2)
								+ "</TimeStamp>");

						he.writeHMDA(rs.getLong(1), rs.getInt(3));

						he.writeHMDARequestor(rs.getLong(1));

						he.writeLoanAmount(rs.getLong(1), rs.getInt(3));

						// only include denial codes if action is a denial
						if (he.action == 3 || he.action == 7) {
							he.writeDenial(rs.getLong(1));
						}

						he.writeHomeEquity(rs.getLong(1));

						he.xmlbuffer.append("</HMDA>");

						if (he.debug_flg != 0)
							System.out.println("xml: "
									+ he.xmlbuffer.toString());

						// style xml
						try {
							// xslt retrieved from selection query
							String styledData = TransformerUtils.toString(he.xmlbuffer.toString(), he.s_xslt);

							// we must check for double encoded characters
							styledData = styledData.replaceAll("&amp;amp;", "&amp;");
							styledData = styledData.replaceAll("&amp;gt;", "&gt;");
							styledData = styledData.replaceAll("&amp;lt;", "&lt;");
							styledData = styledData.replaceAll("&amp;quot;", "&quot;");
							styledData = styledData.replaceAll("&amp;#39;", "&#39;");

							// flush xml buffer to file
							try {
								hmda_xml_stream.write(styledData);

								String s_sql1 = "MERGE INTO credit_request_hmda_extract crhe "
										+ "USING (select ?"
										+ " request_id, "
										+ " ? evaluator_id, "
										+ " ? hmda_extract_id from dual) d "
										+ "ON (crhe.request_id = d.request_id AND crhe.evaluator_id = d.evaluator_id AND crhe.hmda_extract_id = d.hmda_extract_id) "
										+ "WHEN MATCHED THEN UPDATE SET generated_dt = sysdate, error_flg = 0 "
										+ "WHEN NOT MATCHED THEN INSERT "
										+ "(request_id, evaluator_id, hmda_extract_id, generated_dt, error_flg) "
										+ "VALUES "
										+ "(?,?,?,sysdate,0)";
								 ps = he.conn.prepareStatement(s_sql1);
								 ps.setLong(1, rs.getLong(1));
								 ps.setInt(2, he.evaluator_id);
								 ps.setString(3, he.export_id);
								 ps.setLong(4, rs.getLong(1));
								 ps.setInt(5, he.evaluator_id);
								 ps.setString(6, he.export_id);
								 ps.executeQuery();
								 ps.close();
								/*
								update_stmt.executeUpdate("MERGE INTO credit_request_hmda_extract crhe "
										+ "USING (select "
										+ rs.getLong(1)
										+ " request_id, "
										+ he.evaluator_id
										+ " evaluator_id, '"
										+ he.export_id
										+ "' hmda_extract_id from dual) d "
										+ "ON (crhe.request_id = d.request_id AND crhe.evaluator_id = d.evaluator_id AND crhe.hmda_extract_id = d.hmda_extract_id) "
										+ "WHEN MATCHED THEN UPDATE SET generated_dt = sysdate, error_flg = 0 "
										+ "WHEN NOT MATCHED THEN INSERT "
										+ "(request_id, evaluator_id, hmda_extract_id, generated_dt, error_flg) "
										+ "VALUES "
										+ "("
										+ rs.getLong(1)
										+ ","
										+ he.evaluator_id
										+ ",'"
										+ he.export_id
										+ "',sysdate,0)");
								*/

							} catch (Exception e) {
								System.out.println("Exception: error writing to file hmda.dat; "
										+ e);
								e.printStackTrace();
								hmda_xml_stream.close();
								hmda_xml_file.deleteOnExit();
								System.exit(0);
							}
							finally {
							   try{ if(ps != null) ps.close(); }catch(Exception e1){e1.printStackTrace();}
							}
						} catch (Exception e) {
							System.out.println("Exception:  error applying stylesheet; "
									+ e);
							e.printStackTrace();
							System.exit(0);
						}
					} catch (Exception e) {
						System.out.println("Exception: error creating xml buffer; "
								+ e);
						e.printStackTrace();
						System.exit(0);
					}
				}
			}
		} catch (Exception e) {
			System.out.println("Exception: error running selection query:  "
					+ sql + "; " + e);
			e.printStackTrace();
			try { if (rs != null) rs.close();} catch (Exception e1) {e1.printStackTrace();}
			try { if (stmt != null) stmt.close();} catch (Exception e1) {e1.printStackTrace();}
			try { if (update_stmt != null) update_stmt.close();} catch (Exception e1) {e1.printStackTrace();}
			try { if (hmda_xml_stream != null) hmda_xml_stream.close();} catch (Exception e1) {e1.printStackTrace();}
            try{ if(ps != null) ps.close(); }catch(Exception e1){e1.printStackTrace();}
			System.exit(0);
		} finally {
			try { if (rs != null) rs.close();} catch (Exception e) {e.printStackTrace();}
			try { if (stmt != null) stmt.close();} catch (Exception e) {e.printStackTrace();}
			try { if (update_stmt != null) update_stmt.close();} catch (Exception e) {e.printStackTrace();}
			try { if (hmda_xml_stream != null) hmda_xml_stream.close();} catch (Exception e) {e.printStackTrace();}
			try{ if(ps != null) ps.close(); }catch(Exception e){e.printStackTrace();}
		}

		// close stream after writing output
		/*try {
			hmda_xml_stream.close();
		} catch (Exception e) {
			System.out.println("Exception: problem closing stream; " + e);
		}*/

		//update_stmt = null;
		try {
			String s_sql = "insert into event "
					+ "(event_id, event_type_id, event_dt, evaluator_id, user_id, additional_desc_txt) "
					+ "values " + "(event_id_seq.nextval,15,sysdate,?,'SYSTEM',?)";

    		// prepare statement to execute
    		ps = he.conn.prepareStatement(s_sql);
    		ps.setInt(1, he.evaluator_id);
    		ps.setString(2,he.export_id);

    		// execute statement
    		rs = ps.executeQuery();

			/*
			update_stmt = he.conn.createStatement();
			update_stmt.executeUpdate("insert into event "
					+ "(event_id, event_type_id, event_dt, evaluator_id, user_id, additional_desc_txt) "
					+ "values " + "(event_id_seq.nextval,15,sysdate,"
					+ he.evaluator_id + ",'SYSTEM','" + he.export_id + "')");
			*/
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			//try { if (update_stmt != null) update_stmt.close();} catch (Exception e) {e.printStackTrace();}
			try { if (rs != null) rs.close();} catch (Exception e1) {e1.printStackTrace();}
		    try { if (ps != null) ps.close();} catch (Exception e1) {e1.printStackTrace();}
			try { if (he.conn != null) he.conn.close();} catch (Exception e) {e.printStackTrace();}
		}

		// close connection
		/*try {
			he.conn.close();
		} catch (Exception e1) {
		}*/

	}

	// //////////////////////////////// writeHeader
	// ////////////////////////////////////
	private void writeHeader() {
		String sql, sql1 = null;
		PreparedStatement ps = null, ps1 = null;
		ResultSet rs = null, rs1 = null;

		try {
			sql1 = "SELECT hmda_data_id " + "FROM config_hmda_extract_profile "
					+ "WHERE evaluator_id = ? AND extract_profile_id = ?";

			ps1 = conn.prepareStatement(sql1);

			ps1.setInt(1, evaluator_id);
			ps1.setString(2, export_id);

			rs1 = ps1.executeQuery();

			if (rs1.next()) {

				if (rs1.getString("hmda_data_id") != null) {
					hmda_data_id = Integer.parseInt(rs1.getString("hmda_data_id"));
				} else {
					PreparedStatement psData = null;
					ResultSet rsData = null;
                    try {
						String sqlData = "SELECT min(hmda_data_id) as hmda_data_id "
								+ "FROM config_hmda_data "
								+ "WHERE evaluator_id = ? ";

						psData = conn.prepareStatement(sqlData);

						psData.setInt(1, evaluator_id);

						rsData = psData.executeQuery();

						if (rsData.next()) {
							hmda_data_id = rsData.getInt("hmda_data_id");
						} else {
							System.out.println("No hmda data configured for the evaluator.");
						}
                    }
					catch (Exception e) {
					   e.printStackTrace();
					}
					finally {
					  try { if (rsData != null) rsData.close();} catch (Exception e) {e.printStackTrace();}
			          try { if (psData != null) psData.close();} catch (Exception e) {e.printStackTrace();}
					}
				}
			}
		} catch (Exception e) {
			System.out.println("Exception: error getting HMDA data id information. "
					+ e);
			e.printStackTrace();
			try { if (rs1 != null) rs1.close();} catch (Exception e1) {e1.printStackTrace();}
			try { if (ps1 != null) ps1.close();} catch (Exception e1) {e1.printStackTrace();}
			System.exit(0);
		} finally {
			try { if (rs1 != null) rs1.close();} catch (Exception e1) {e1.printStackTrace();}
			try { if (ps1 != null) ps1.close();} catch (Exception e1) {e1.printStackTrace();}
		}
		// retrieve hmda header info by evaluator_id
		try {
			sql = "SELECT respondent_id, agency_code_id, tax_id, upper(respondent_name_txt) as respondent_name_txt, respondent_address_txt, "
					+ "respondent_city_txt, respondent_state_id, respondent_zipcode_txt, upper(parent_name_txt) as parent_name_txt, parent_address_txt, "
					+ "parent_city_txt, parent_state_id, parent_zipcode_txt, upper(contact_name_txt) as contact_name_txt, contact_phone_number_txt, "
					+ "contact_fax_number_txt, contact_email_address_txt "
					+ "FROM config_hmda_data "
					+ "WHERE evaluator_id = ? "
					+ "AND hmda_data_id = ?";

			ps = conn.prepareStatement(sql);

			ps.setInt(1, evaluator_id);
			ps.setInt(2, hmda_data_id);

			rs = ps.executeQuery();

			if (rs.next()) {
				// create header items

				// write non null fields first: respondent_id, agency_code_id,
				// tax_id, respondent_name_txt, respondent_address_txt
				// respondent_city_txt, respondent_state_id,
				// respondent_zipcode_txt, contact_name_txt,
				// contact_phone_number_txt
				xmlbuffer.append("<RespondentID>"
						+ encodeValue(rs.getString("respondent_id"))
						+ "</RespondentID><AgencyCode>"
						+ rs.getInt("agency_code_id") + "</AgencyCode><TaxID>"
						+ encodeValue(rs.getString("tax_id"))
						+ "</TaxID><RespondentName>"
						+ encodeValue(rs.getString("respondent_name_txt"))
						+ "</RespondentName><RespondentAddress>"
						+ encodeValue(rs.getString("respondent_address_txt"))
						+ "</RespondentAddress>" + "<RespondentCity>"
						+ encodeValue(rs.getString("respondent_city_txt"))
						+ "</RespondentCity><RespondentState>"
						+ encodeValue(rs.getString("respondent_state_id"))
						+ "</RespondentState><RespondentZip>"
						+ encodeValue(rs.getString("respondent_zipcode_txt"))
						+ "</RespondentZip><ContactName>"
						+ encodeValue(rs.getString("contact_name_txt"))
						+ "</ContactName><ContactPhone>"
						+ encodeValue(rs.getString("contact_phone_number_txt"))
						+ "</ContactPhone>");
				// for nullable fields, make sure it's not null before building
				// tag
				// parent_name_txt
				if (rs.getString("parent_name_txt") != null)
					xmlbuffer.append("<ParentName>"
							+ encodeValue(rs.getString("parent_name_txt"))
							+ "</ParentName>");
				// parent_address_txt
				if (rs.getString("parent_address_txt") != null)
					xmlbuffer.append("<ParentAddress>"
							+ encodeValue(rs.getString("parent_address_txt"))
							+ "</ParentAddress>");
				// parent_city_txt
				if (rs.getString("parent_city_txt") != null)
					xmlbuffer.append("<ParentCity>"
							+ encodeValue(rs.getString("parent_city_txt"))
							+ "</ParentCity>");
				// parent_state_id
				if (rs.getString("parent_state_id") != null)
					xmlbuffer.append("<ParentState>"
							+ encodeValue(rs.getString("parent_state_id"))
							+ "</ParentState>");
				// parent_zipcode_txt
				if (rs.getString("parent_zipcode_txt") != null)
					xmlbuffer.append("<ParentZip>"
							+ encodeValue(rs.getString("parent_zipcode_txt"))
							+ "</ParentZip>");
				// contact_fax_number_txt
				if (rs.getString("contact_fax_number_txt") != null)
					xmlbuffer.append("<ContactFax>"
							+ encodeValue(rs.getString("contact_fax_number_txt"))
							+ "</ContactFax>");
				// contact_email_address_txt
				if (rs.getString("contact_email_address_txt") != null)
					xmlbuffer.append("<ContactEmail>"
							+ encodeValue(rs.getString("contact_email_address_txt"))
							+ "</ContactEmail>");
			} else
				throw new Exception("Evaluator does not have HMDA data configured in config_hmda_data.");
		} catch (Exception e) {
			System.out.println("Exception: error getting HMDA header information. "
					+ e);
			e.printStackTrace();
			try { if (rs != null) rs.close();} catch (Exception e1) {e1.printStackTrace();}
			try { if (ps != null) ps.close();} catch (Exception e1) {e1.printStackTrace();}
			System.exit(0);
		} finally {
			try { if (rs != null) rs.close();} catch (Exception e1) {e1.printStackTrace();}
			try { if (ps != null) ps.close();} catch (Exception e1) {e1.printStackTrace();}
		}
	}

	// /////////////////////////// end writeHeader
	// //////////////////////////////////////

	// //////////////////////////// write hmda data
	// /////////////////////////////////////
	private void writeHMDA(long request_id, int product_id) {
		String sql2;
		PreparedStatement ps2 = null;
		ResultSet rs2 = null;
		// retrieve hmda app data
		try {
			sql2 = "SELECT crh.preapproval_id, crh.purpose_id, crh.lien_status_id, crh.property_type_id, trim(to_char(crh.census_tract_num, '0009D00')) as census_tract_num, "
					+ "crh.msa_txt, nvl(crh.hoepa_flg,2) as hoepa_flg, crh.state_code_txt, crh.county_code_txt, crh.loan_type_id, crh.purchaser_id, "
					+ "crh.occupancy_id, crh.rate_spread_num, crh.gross_income_num, crh.purchaser_dt, mhit.description_txt,  "
					+ "crh.interviewer_txt, crh.phone_number_txt, crh.phone_extension_txt,"
					+ "to_char(crh.action_dt,'MM/DD/YYYY') as action_dt, crh.action_id, to_char(cr.receipt_dt,'MM/DD/YYYY') as receipt_dt, cr.client_app_id, "
					+ "(select to_char(send_dt,'MM/DD/YYYY') from credit_req_decisions_evaluator where decision_ref_id = cr.latest_final_dec_ref_id and decision_id in (1,3,102)) as decision_dt "
					+ "FROM credit_request_hmda crh, credit_request cr, mstr_hmda_interview_type mhit "
					+ "WHERE cr.request_id = ? AND cr.request_id = crh.request_id (+)"
					+ "AND mhit.interview_type_id (+) = crh.interview_type_id";

			ps2 = conn.prepareStatement(sql2);

			ps2.setLong(1, request_id);

			rs2 = ps2.executeQuery();

			if (rs2.next()) {
				// create hmda items
				// write not null fields first: client_app_id, receipt_dt
				xmlbuffer.append("<LoanNumber>"
						+ rs2.getString("client_app_id")
						+ "</LoanNumber><ReceivedDate>"
						+ rs2.getString("receipt_dt") + "</ReceivedDate>");
				// for nullable fields, make sure it's not null before building
				// tag
				// loan type
				if (rs2.getString("loan_type_id") != null)
					xmlbuffer.append("<LoanType>"
							+ rs2.getString("loan_type_id") + "</LoanType>");
				// property_type_id
				if (rs2.getString("property_type_id") != null)
					xmlbuffer.append("<PropertyType>"
							+ rs2.getString("property_type_id")
							+ "</PropertyType>");
				// purpose_id
				if (rs2.getString("purpose_id") != null)
					xmlbuffer.append("<LoanPurpose>"
							+ rs2.getString("purpose_id") + "</LoanPurpose>");
				// occupancy_id
				if (rs2.getString("occupancy_id") != null)
					xmlbuffer.append("<OwnerOccupancy>"
							+ rs2.getString("occupancy_id")
							+ "</OwnerOccupancy>");
				// preapproval_id
				if (rs2.getString("preapproval_id") != null)
					xmlbuffer.append("<Preapproval>"
							+ rs2.getString("preapproval_id")
							+ "</Preapproval>");
				// action_id
				if (rs2.getString("action_id") != null) {
					// use action to determine later if we need denial codes
					action = rs2.getInt("action_id");
					xmlbuffer.append("<ActionType>" + action + "</ActionType>");
				}
				// action_dt
				if (rs2.getString("action_dt") != null)
					xmlbuffer.append("<ActionDate>"
							+ rs2.getString("action_dt") + "</ActionDate>");
				// census_tract_num
				if (rs2.getString("census_tract_num") != null)
					xmlbuffer.append("<CensusTract>"
							+ rs2.getString("census_tract_num")
							+ "</CensusTract>");
				// state_code_txt
				if (rs2.getString("state_code_txt") != null)
					xmlbuffer.append("<State>"
							+ rs2.getString("state_code_txt") + "</State>");
				// county_code_txt
				if (rs2.getString("county_code_txt") != null)
					xmlbuffer.append("<County>"
							+ encodeValue(rs2.getString("county_code_txt"))
							+ "</County>");
				// msa_txt
				if (rs2.getString("msa_txt") != null)
					xmlbuffer.append("<MSA>"
							+ encodeValue(rs2.getString("msa_txt")) + "</MSA>");
				// gross_income_num
				if (rs2.getString("gross_income_num") != null)
					xmlbuffer.append("<Income>"
							+ rs2.getString("gross_income_num") + "</Income>");
				// purchaser_id
				if (rs2.getString("purchaser_id") != null)
					xmlbuffer.append("<PurchaserType>"
							+ rs2.getString("purchaser_id")
							+ "</PurchaserType>");
				// rate_spread_num
				if (rs2.getString("rate_spread_num") != null)
					xmlbuffer.append("<RateSpread>"
							+ rs2.getString("rate_spread_num")
							+ "</RateSpread>");
				// decision_dt
				if (rs2.getString("decision_dt") != null)
					xmlbuffer.append("<DateInterestSet>"
							+ rs2.getString("decision_dt")
							+ "</DateInterestSet>");
				// hoepa_flg
				if (rs2.getString("hoepa_flg") != null)
					xmlbuffer.append("<HOEPA>" + rs2.getString("hoepa_flg")
							+ "</HOEPA>");
				// lien_status_id
				if (rs2.getString("lien_status_id") != null)
					xmlbuffer.append("<LienStatus>"
							+ rs2.getString("lien_status_id") + "</LienStatus>");
				// interview type text
				if (rs2.getString("description_txt") != null)
					xmlbuffer.append("<InterviewType>"
							+ encodeValue(rs2.getString("description_txt"))
							+ "</InterviewType>");
				// interviewer
				if (rs2.getString("interviewer_txt") != null)
					xmlbuffer.append("<Interviewer>"
							+ encodeValue(rs2.getString("interviewer_txt"))
							+ "</Interviewer>");
				// phone_number_txt
				if (rs2.getString("phone_number_txt") != null)
					xmlbuffer.append("<Phone>"
							+ rs2.getString("phone_number_txt") + "</Phone>");
				// phone_extension_txt
				if (rs2.getString("phone_extension_txt") != null)
					xmlbuffer.append("<PhoneExt>"
							+ rs2.getString("phone_extension_txt")
							+ "</PhoneExt>");
				// phone_extension_txt
				String programTxt = getProgram(conn, evaluator_id, request_id, product_id);
				if (programTxt != null)
					xmlbuffer.append("<Program>" + programTxt + "</Program>");

			}
		} catch (Exception e) {
			System.out.println("Exception: error getting HMDA information. "
					+ e);
			e.printStackTrace();
			try { if (rs2 != null) rs2.close();} catch (Exception e1) {e1.printStackTrace();}
			try { if (ps2 != null) ps2.close();} catch (Exception e1) {e1.printStackTrace();}
			System.exit(0);
		} finally {
			try { if (rs2 != null) rs2.close();} catch (Exception e1) {e1.printStackTrace();}
			try { if (ps2 != null) ps2.close();} catch (Exception e1) {e1.printStackTrace();}
		}

		// Run two queries to get collateral use (Primary, Secondary, Vacation,
		// etc)
		// and collateral type description (Ex: Home Equity Lines and Loans).
		// Added for CL152969
		try {
			sql2 = "select mct.collateral_type_descr_txt "
					+ "from mstr_collateral_type mct, mstr_product mp, credit_request cr "
					+ "where cr.product_id = mp.product_id "
					+ "and mp.collateral_type_id = mct.collateral_type_id "
					+ "and cr.request_id = ? ";

			ps2 = conn.prepareStatement(sql2);

			ps2.setLong(1, request_id);

			rs2 = ps2.executeQuery();

			if (rs2.next()) {
				// collateral_type_descr_txt
				if (rs2.getString("collateral_type_descr_txt") != null)
					xmlbuffer.append("<CollateralType>"
							+ rs2.getString("collateral_type_descr_txt")
							+ "</CollateralType>");
			}
		} catch (Exception e) {
			System.out.println("Exception: error getting HMDA information. "
					+ e);
			e.printStackTrace();
			try { if (rs2 != null) rs2.close();} catch (Exception e1) {e1.printStackTrace();}
			try { if (ps2 != null) ps2.close();} catch (Exception e1) {e1.printStackTrace();}
			System.exit(0);
		} finally {
			try { if (rs2 != null) rs2.close();} catch (Exception e1) {e1.printStackTrace();}
			try { if (ps2 != null) ps2.close();} catch (Exception e1) {e1.printStackTrace();}
		}
		try {
			sql2 = "select crhe.colla_use_id "
					+ "from credit_request cr, credit_request_home_equity crhe "
					+ "where cr.request_id = crhe.request_id "
					+ "and crhe.include_in_ltv_flg = 1 "
					+ "and cr.request_id = ? "
					+ "order by home_equity_id asc, collateral_request_id asc";

			ps2 = conn.prepareStatement(sql2);

			ps2.setLong(1, request_id);

			rs2 = ps2.executeQuery();

			if (rs2.next()) {
				// colla_use_id
				if (rs2.getString("colla_use_id") != null)
					xmlbuffer.append("<CollateralUse>"
							+ rs2.getString("colla_use_id")
							+ "</CollateralUse>");
			}
		} catch (Exception e) {
			System.out.println("Exception: error getting HMDA information. "
					+ e);
			e.printStackTrace();
			try { if (rs2 != null) rs2.close();} catch (Exception e1) {e1.printStackTrace();}
			try { if (ps2 != null) ps2.close();} catch (Exception e1) {e1.printStackTrace();}
			System.exit(0);
		} finally {
			try { if (rs2 != null) rs2.close();} catch (Exception e1) {e1.printStackTrace();}
			try { if (ps2 != null) ps2.close();} catch (Exception e1) {e1.printStackTrace();}
		}

	}

	// //////////////////////////// end writeHMDA()
	// /////////////////////////////////////

	// ///////////////////////////// write hmda requestor data
	// //////////////////////////
	private void writeHMDARequestor(long request_id) {
		String sql3;
		PreparedStatement ps3 = null;
		ResultSet rs3 = null;
		// retrieve hmda requestor data
		try {
			sql3 = "select rh.requestor_type_id, rhmda.gender_id, rhmda.ethnicity_id, nvl(rhmda.race_bmsk,0) as race_bmsk "
					+ "from requestor_header rh, requestor_hmda rhmda "
					+ "where rh.request_id = ? and rh.requestor_type_id in (0,1,3) and rh.request_id = rhmda.request_id and rh.requestor_id = rhmda.requestor_id";

			ps3 = conn.prepareStatement(sql3);

			ps3.setLong(1, request_id);

			rs3 = ps3.executeQuery();

			while (rs3.next()) {
				// create requestor hmda items
				// wrap data in requestor specific tags
				if (rs3.getInt("requestor_type_id") == 0
						|| rs3.getInt("requestor_type_id") == 3)
					xmlbuffer.append("<Applicant>");
				else
					xmlbuffer.append("<CoApplicant>");
				// ethnicity_id
				if (rs3.getString("ethnicity_id") != null)
					xmlbuffer.append("<Ethnicity>"
							+ rs3.getString("ethnicity_id") + "</Ethnicity>");
				// race_bmsk
				if ((rs3.getInt("race_bmsk") & 1) == 1)
					xmlbuffer.append("<Race>1</Race>");
				if ((rs3.getInt("race_bmsk") & 2) == 2)
					xmlbuffer.append("<Race>2</Race>");
				if ((rs3.getInt("race_bmsk") & 4) == 4)
					xmlbuffer.append("<Race>3</Race>");
				if ((rs3.getInt("race_bmsk") & 8) == 8)
					xmlbuffer.append("<Race>4</Race>");
				if ((rs3.getInt("race_bmsk") & 16) == 16)
					xmlbuffer.append("<Race>5</Race>");
				if ((rs3.getInt("race_bmsk") & 32) == 32)
					xmlbuffer.append("<Race>6</Race>");
				if ((rs3.getInt("race_bmsk") & 64) == 64)
					xmlbuffer.append("<Race>7</Race>");

				// gender_id
				if (rs3.getString("gender_id") != null)
					xmlbuffer.append("<Sex>" + rs3.getString("gender_id")
							+ "</Sex>");
				// wrap data in requestor specific tags
				if (rs3.getInt("requestor_type_id") == 0
						|| rs3.getInt("requestor_type_id") == 3)
					xmlbuffer.append("</Applicant>");
				else
					xmlbuffer.append("</CoApplicant>");
			}
		} catch (Exception e) {
			System.out.println("Exception: error getting requestor HMDA information. "
					+ e);
			e.printStackTrace();
			try { if (rs3 != null) rs3.close();} catch (Exception e1) {e1.printStackTrace();}
			try { if (ps3 != null) ps3.close();} catch (Exception e1) {e1.printStackTrace();}
			System.exit(0);
		} finally {
			try { if (rs3 != null) rs3.close();} catch (Exception e1) {e1.printStackTrace();}
			try { if (ps3 != null) ps3.close();} catch (Exception e1) {e1.printStackTrace();}
		}
	}

	// ////////////////////////////// end writeHMDARequestor()
	// //////////////////////////

	private void writeDenial(long request_id) {
		String sql5, sql7;
		PreparedStatement ps5 = null;
		PreparedStatement ps7 = null;
		ResultSet rs5 = null;
		ResultSet rs7 = null;
		// retrieve denial reasons for turndown reason types only (not the other
		// decision reason types)
		try {
			sql5 = "SELECT cdr.hmda_reason_id, crdr.order_precedence_num "
					+ "FROM config_decision_reasons cdr, credit_req_decision_reasons crdr "
					+ "WHERE cdr.evaluator_id = ? AND cdr.evaluator_id = crdr.evaluator_id "
					+ "AND crdr.reason_type_id = 1 "
					+ "AND cdr.reason_id = crdr.reason_id AND cdr.reason_type_id = crdr.reason_type_id "
					+ "AND crdr.decision_ref_id = (SELECT max(decision_ref_id) FROM credit_req_decisions_evaluator where request_id = ?) "
					+ "ORDER BY crdr.order_precedence_num";

			ps5 = conn.prepareStatement(sql5);

			ps5.setInt(1, evaluator_id);
			ps5.setLong(2, request_id);

			rs5 = ps5.executeQuery();

			sql7 = "SELECT distinct cdr.hmda_reason_id "
					+ "FROM config_decision_reasons cdr, credit_req_decision_reasons crdr "
					+ "WHERE cdr.evaluator_id = ? AND cdr.evaluator_id = crdr.evaluator_id "
					+ "AND crdr.reason_type_id = 1 "
					+ "AND cdr.reason_id = crdr.reason_id AND cdr.reason_type_id = crdr.reason_type_id "
					+ "AND crdr.decision_ref_id = (SELECT max(decision_ref_id) FROM credit_req_decisions_evaluator where request_id = ?) ";

			ps7 = conn.prepareStatement(sql7);

			ps7.setInt(1, evaluator_id);
			ps7.setLong(2, request_id);

			rs7 = ps7.executeQuery();
			int i = 0;
			Vector<String> denial_vec = new Vector<String>();
			while (rs7.next()) {
				// do not assume that a hmda reason will be configured for each
				// decision reason
				if (rs7.getString("hmda_reason_id") != null)
					denial_vec.addElement(rs7.getString("hmda_reason_id"));
			}
			while (rs5.next()) {
				// create denial reasons
				// hmda_reason_id
				if (rs5.getString("hmda_reason_id") != null) {
					for (i = 0; i < denial_vec.size(); i++) {
						if (rs5.getString("hmda_reason_id").equals(denial_vec.get(i).toString())) {
							xmlbuffer.append("<DenialReason>"
									+ encodeValue(denial_vec.get(i).toString())
									+ "</DenialReason>");
							denial_vec.setElementAt("-1", i);
						}
					}
				}
			}
		} catch (Exception e) {
			System.out.println("Exception: error getting denial reasons. " + e);
			e.printStackTrace();
			try { if (rs5 != null) rs5.close();} catch (Exception e1) {e1.printStackTrace();}
			try { if (rs7 != null) rs7.close();} catch (Exception e1) {e1.printStackTrace();}
			try { if (ps5 != null) ps5.close();} catch (Exception e1) {e1.printStackTrace();}
			try { if (ps7 != null) ps7.close();} catch (Exception e1) {e1.printStackTrace();}
			System.exit(0);
		} finally {
		    try { if (rs5 != null) rs5.close();} catch (Exception e) {e.printStackTrace();}
			try { if (rs7 != null) rs7.close();} catch (Exception e) {e.printStackTrace();}
			try { if (ps5 != null) ps5.close();} catch (Exception e) {e.printStackTrace();}
			try { if (ps7 != null) ps7.close();} catch (Exception e) {e.printStackTrace();}
		}
	}

	// //////////////////////////////// write loan amount
	// ///////////////////////////////
	private void writeLoanAmount(long request_id, int product_id) {

		String sql1;
		int purposeID = 0;
		int actionID = 0;
		int repayType = 0;
		float requestedAmt = 0;
		float approvedAmt = 0;
		float contractAmt = 0;
		float loanAmount = 0;
		PreparedStatement ps1 = null;
		ResultSet rs1 = null;

		// retrieve financed amount
		try {
			// Get decision type, debt payment and approved amt for approved
			// decision
			sql1 = "SELECT nvl(cd.repayment_type_num,0) as repayment_type_num, nvl(cd.approved_amount_num,0) as approved_amount_num FROM CREDIT_REQ_DECISIONS_EVALUATOR cd "
					+ " WHERE cd.decision_ref_id = (select latest_final_dec_ref_id from credit_request where request_id = ?)";

			ps1 = conn.prepareStatement(sql1);

			ps1.setLong(1, request_id);

			rs1 = ps1.executeQuery();

			if (rs1.next()) {
				repayType = rs1.getInt("repayment_type_num");
				approvedAmt = rs1.getFloat("approved_amount_num");
			}
            try { if (rs1 != null) rs1.close();} catch (Exception e) {e.printStackTrace();}
			try { if (ps1 != null) ps1.close();} catch (Exception e) {e.printStackTrace();}

            // Get requested amount
			if (product_id == 16 || product_id == 17) {
				sql1 = "select nvl(total_financed_num,0) "
						+ "from credit_request_home_loan "
						+ "where request_id = ?";
			} else if (product_id == 22) {
				sql1 = "select nvl(credit_limit_num,0) "
						+ "from credit_request_credit_card "
						+ "where request_id = ?";
			} else {
				sql1 = "select Calc_Requested_Amount_Num(request_id, evaluator_id) "
						+ "from credit_request " + "where request_id = ?";
			}

			ps1 = conn.prepareStatement(sql1);

			ps1.setLong(1, request_id);

			rs1 = ps1.executeQuery();

			if (rs1.next()) {
				requestedAmt = rs1.getFloat(1);
			}

			try { if (rs1 != null) rs1.close();} catch (Exception e) {e.printStackTrace();}
			try { if (ps1 != null) ps1.close();} catch (Exception e) {e.printStackTrace();}

			// Get contact amount - contract_amount_num for home equity...amount
			// financed amount otherwise
			if (product_id == 16 || product_id == 17) {
				sql1 = "select NVL(contract_amount_num,0) as contract_amount_num "
						+ "from credit_req_contr_fin " + "where request_id = ?";
			} else {
				sql1 = "select NVL(amount_financed_num,0) as contract_amount_num "
						+ "from credit_req_contr_fin " + "where request_id = ?";
			}

			ps1 = conn.prepareStatement(sql1);

			ps1.setLong(1, request_id);

			rs1 = ps1.executeQuery();

			if (rs1.next()) {
				contractAmt = rs1.getFloat("CONTRACT_AMOUNT_NUM");
			}

			try { if (rs1 != null) rs1.close();} catch (Exception e) {e.printStackTrace();}
			try { if (ps1 != null) ps1.close();} catch (Exception e) {e.printStackTrace();}

			// catch all - if contract amount was not retrieved, use approved
			// amount from decision
			if (contractAmt == 0) {
				contractAmt = approvedAmt;
			}

			// Get purpose and action
			sql1 = "select PURPOSE_ID, ACTION_ID "
					+ "from credit_request_hmda " + "where request_id = ?";

			ps1 = conn.prepareStatement(sql1);

			ps1.setLong(1, request_id);

			rs1 = ps1.executeQuery();

			if (rs1.next()) {
				purposeID = rs1.getInt("PURPOSE_ID");
				actionID = rs1.getInt("ACTION_ID");
			}

			try { if (rs1 != null) rs1.close();} catch (Exception e) {e.printStackTrace();}
			try { if (ps1 != null) ps1.close();} catch (Exception e) {e.printStackTrace();}

			// Set loan amount based on values
			if (repayType == 1 && actionID == 1 && purposeID == 1) { // A. Use
																		// Note
																		// Amount
				loanAmount = contractAmt;
			} else if (repayType == 1 && actionID == 6 && purposeID == 1) { // B.
																			// Use
																			// Note
																			// Amount
				loanAmount = contractAmt;
			} else if (repayType == 1 && (actionID == 1 || actionID == 6)
					&& purposeID == 2) { // C. Use Note Amount
				loanAmount = contractAmt;
			} else if (repayType == 2 && (actionID == 1 || actionID == 6)
					&& (purposeID == 1 || purposeID == 2)) { // D. Use Approved
																// Amount
				loanAmount = approvedAmt;
			} else if (repayType == 1 && (actionID == 1 || actionID == 6)
					&& purposeID == 3) { // E1. Use Note Amount for installment
				loanAmount = contractAmt;
			} else if (repayType == 2 && (actionID == 1 || actionID == 6)
					&& purposeID == 3) { // E2. Use Approved Amount for
											// revolving
				loanAmount = approvedAmt;
			} else if (actionID != 1 && actionID != 6) { // F. Use Requested
															// Amount
				loanAmount = requestedAmt;
			}

			// Create tag for loan amount
			if (loanAmount != 0)
				xmlbuffer.append("<LoanAmount>" + Math.round(loanAmount / 1000)
						+ "</LoanAmount>");

		} catch (Exception e) {
			System.out.println("Exception: error getting loan amount. " + e);
			e.printStackTrace();
			try { if (rs1 != null) rs1.close();} catch (Exception e1) {e1.printStackTrace();}
			try { if (ps1 != null) ps1.close();} catch (Exception e1) {e1.printStackTrace();}
			System.exit(0);
		} finally {
			try { if (rs1 != null) rs1.close();} catch (Exception e) {e.printStackTrace();}
			try { if (ps1 != null) ps1.close();} catch (Exception e) {e.printStackTrace();}
		}
	}

	// ////////////////////// end writeLoanAmount()
	// /////////////////////////////////////

	// ////////////////////// writeHomeEquity()
	// /////////////////////////////////////
	private void writeHomeEquity(long request_id) {
		String sql6;
		PreparedStatement ps6 = null;
		ResultSet rs6 = null;
		// pull from hmda record now since this information is no longer product
		// specific
		try {
			sql6 = "select street_number_txt||' '||street_name_txt||' '||street_type_id||' '||apt_suite_box_txt as address_txt, "
					+ "city_txt, state_id, zipcode_txt "
					+ "from credit_request_hmda " + "where request_id = ?";

			ps6 = conn.prepareStatement(sql6);

			ps6.setLong(1, request_id);

			rs6 = ps6.executeQuery();

			if (rs6.next()) {
				// create crawiz specific data - property address info
				xmlbuffer.append("<Property>");
				// address_txt
				if (rs6.getString("address_txt") != null)
					xmlbuffer.append("<Address>"
							+ encodeValue(rs6.getString("address_txt"))
							+ "</Address>");
				// city_txt
				if (rs6.getString("city_txt") != null)
					xmlbuffer.append("<City>"
							+ encodeValue(rs6.getString("city_txt"))
							+ "</City>");
				// state_id
				if (rs6.getString("state_id") != null)
					xmlbuffer.append("<State>"
							+ encodeValue(rs6.getString("state_id"))
							+ "</State>");
				// zipcode_txt
				if (rs6.getString("zipcode_txt") != null)
					xmlbuffer.append("<Zip>"
							+ encodeValue(rs6.getString("zipcode_txt"))
							+ "</Zip>");

				xmlbuffer.append("</Property>");
			}
		} catch (Exception e) {
			System.out.println("Exception: error getting address info. " + e);
			e.printStackTrace();
			try { if (rs6 != null) rs6.close();} catch (Exception e1) {e1.printStackTrace();}
			try { if (ps6 != null) ps6.close();} catch (Exception e1) {e1.printStackTrace();}
			System.exit(0);
		} finally {
			try { if (rs6 != null) rs6.close();} catch (Exception e) {e.printStackTrace();}
			try { if (ps6 != null) ps6.close();} catch (Exception e) {e.printStackTrace();}
		}

	}

	// ////////////////////// end writeHomeEquity()
	// /////////////////////////////////////

	// ///////////////////////// createSelectionQuery()
	// //////////////////////////////////
	/*private String createSelectionQuery() {
		// determine apps to select
		// since oracle won't allow outer joins to subqueries, i had to nest
		// case statements to allow null programs to be hmda eligible for non
		// home equity products
		String sql1, sql_date, selection_sql_where = "where cr.evaluator_id = "
				+ evaluator_id + " and ", selection_sql_from = "select cr.request_id, to_char(sysdate,'YYYYMMDDHH24MI') as timestamp, cr.product_id, "
				+ "CASE WHEN (cr.product_id != 16 AND cr.product_id != 17 AND cr.product_id != 22 )"
				+ " 	  THEN (CASE (SELECT nvl(hmda_eligible_flg,1)"
				+ "	              FROM config_product_program cpp, credit_request_loan crl "
				+ "				  WHERE cr.request_id = crl.request_id"
				+ "				  AND cpp.evaluator_id = cr.evaluator_id"
				+ "				  AND cpp.product_id = cr.product_id"
				+ "				  AND crl.program_id = cpp.program_id)"
				+ "	  		WHEN 0 THEN 0"
				+ "   		WHEN 1 THEN 1"
				+ "   		ELSE 1 END) "
				+ "      WHEN (cr.product_id = 16 OR cr.product_id = 17)"
				+ "	   THEN (CASE (SELECT nvl(hmda_eligible_flg,1)"
				+ "				   FROM config_product_program cpp, credit_request_home_loan crhl"
				+ "                  WHERE cr.request_id = crhl.request_id"
				+ " 				   AND cpp.evaluator_id = cr.evaluator_id"
				+ "				   AND cpp.product_id = cr.product_id"
				+ "				   AND crhl.program_id = cpp.program_id)"
				+ "			 WHEN 0 THEN 0"
				+ "			 WHEN 1 THEN 1"
				+ "            ELSE 0 END)"
				+ "	  WHEN (cr.product_id = 22)"
				+ "	  THEN (CASE (SELECT nvl(hmda_eligible_flg,1)"
				+ "				  FROM config_product_program cpp, credit_request_credit_card crcc"
				+ "				  WHERE cr.request_id = crcc.request_id"
				+ "				  AND cpp.evaluator_id = cr.evaluator_id"
				+ "				  AND cpp.product_id = cr.product_id"
				+ "				  AND crcc.program_id = cpp.program_id)"
				+ " 			WHEN 0 THEN 0"
				+ "           WHEN 1 THEN 1"
				+ "			ELSE 1 END) "
				+ "END as program_eligible_flg from credit_request cr";
		PreparedStatement ps1 = null;
		ResultSet rs1 = null;

		try {
			sql1 = "SELECT timeframe_id, days_to_extract_num, to_char(range_from_dt,'MM/DD/YY HH24:MI:SS') as range_from_dt, to_char(range_to_dt,'MM/DD/YY HH24:MI:SS') as range_to_dt, "
					+ "decode(date_type_id,0,'initiation_dt',1,'action_dt') as date_type_id, selection_criteria_id, nvl(incl_incomplete_apps_flg,1) as incl_incomplete_apps_flg, stylesheet_txt, hmda_extract_query_id "
					+ "FROM config_hmda_extract_profile "
					+ "WHERE evaluator_id = ? AND extract_profile_id = ?";

			ps1 = conn.prepareStatement(sql1);

			ps1.setInt(1, evaluator_id);
			ps1.setString(2, export_id);

			rs1 = ps1.executeQuery();

			if (rs1.next()) {
				sql_date = rs1.getString("date_type_id");
				// create xslt
				s_xslt = rs1.getString("stylesheet_txt");

				if (!s_xslt.toLowerCase().startsWith("http")
						&& !s_xslt.startsWith("/")
						&& !s_xslt.startsWith(File.separator)) {*/
					/*
					 * The value is neither a http address nor an absolute path,
					 * so we read the mpe.xslt_dir value from origenate.ini and
					 * treat that as the working directory and just grab the
					 * name of the ini file from the databse
					 *
					 * TransformerUtils.toString(String, String) already has the
					 * ability to read a http link as well as an absolute path
					 * (#167322) - chrisk
					 */
	/*				if (s_xslt_inifile.endsWith(File.separator)
							|| s_xslt_inifile.endsWith("/"))
						s_xslt = s_xslt_inifile + s_xslt;
					else
						s_xslt = s_xslt_inifile + "/" + s_xslt;
				}

				if (rs1.getString("timeframe_id") != null) {
					// use timeframe
					switch (rs1.getInt("timeframe_id")) {
						case 0 :
							// current month
							selection_sql_where += sql_date
									+ " >= last_day(add_months((trunc(sysdate)+0/86400),-1))+1";
							break;
						case 1 :
							// previous month
							selection_sql_where += sql_date
									+ " >= last_day(add_months((trunc(sysdate)+0/86400),-2))+1 and "
									+ sql_date
									+ " <= last_day(add_months((trunc(sysdate)-1/86400),-1))";
							break;
						case 2 :
							// current quarter
							selection_sql_where += sql_date
									+ " >= to_date(decode(to_char((trunc(sysdate)+1/86400),'Q'),1,'01/01/',2,'04/01/',3,'07/01/',4,'10/01/')||to_char((trunc(sysdate)+1/86400),'YYYY'),'MM/DD/YYYY')";
							break;
						case 3 :
							// previous quarter
							selection_sql_where += sql_date
									+ " >= to_date(decode(to_char((trunc(sysdate)+1/86400),'Q'),1,'10/01/'||to_char((trunc(sysdate)+1/86400)-100,'YYYY'),2,'01/01/'||to_char((trunc(sysdate)+1/86400),'YYYY'),3,'04/01/'||to_char((trunc(sysdate)+1/86400),'YYYY'),4,'07/01/'||to_char((trunc(sysdate)+1/86400),'YYYY')),'MM/DD/YYYY') and "
									+ sql_date
									+ " < to_date(decode(to_char((trunc(sysdate)-1/86400),'Q'),1,'01/01/'||to_char((trunc(sysdate)-1/86400)-100,'YYYY'),2,'04/01/'||to_char((trunc(sysdate)-1/86400),'YYYY'),3,'07/01/'||to_char((trunc(sysdate)-1/86400),'YYYY'),4,'10/01/'||to_char((trunc(sysdate)-1/86400),'YYYY')),'MM/DD/YYYY')";
							break;
						case 4 :
							// ytd
							selection_sql_where += sql_date
									+ " >= to_date('01/01/'||to_char((trunc(sysdate)+1/86400),'YYYY'), 'MM/DD/YYYY')";
							break;
						default :
							System.out.println("Unknown timeframe_id...will use current month");
							selection_sql_where += sql_date
									+ " >= last_day(add_months((trunc(sysdate)+1/86400),-1))+1";
							break;
					}
				} else if (rs1.getString("days_to_extract_num") != null) {
					// use days prior to extract date
					selection_sql_where += sql_date
							+ " >= (trunc(sysdate)+1/86400) - "
							+ rs1.getInt("days_to_extract_num");
				} else if (rs1.getString("range_from_dt") != null
						&& rs1.getString("range_to_dt") != null) {
					// use daterange
					selection_sql_where += sql_date + " >= to_date('"
							+ rs1.getString("range_from_dt")
							+ "','MM/DD/YY HH24:MI:SS') and " + sql_date
							+ " <= to_date('" + rs1.getString("range_to_dt")
							+ "','MM/DD/YY HH24:MI:SS')";
				} else {
					System.out.println("Exception:  there is no valid time frame to use.");
					try{
			        if(rs1 != null) rs1.close();
					}
					catch(Exception e){
						e.printStackTrace();
					}
					finally{
						try {if(ps1 != null) ps1.close();} catch (Exception e) {e.printStackTrace();}
					}
					System.exit(0);
				}

				// if using action date, we need to include hmda table it comes
				// from and join to credit_request
				if (sql_date.equals("action_dt")) {
					selection_sql_from += ", credit_request_hmda hmda";
					selection_sql_where += " and cr.request_id = hmda.request_id";
				}

				// whether to include incomplete apps or not
				if (rs1.getInt("incl_incomplete_apps_flg") == 0) {
					// activity_id = 26 is hmda activity
					selection_sql_from += ", credit_request_activity cra";
					selection_sql_where += " and cra.request_id = cr.request_id and cra.activity_id = 26 and activity_status_id = 3";
				}

				if (rs1.getString("hmda_extract_query_id") != null) {
					selection_sql_where += " and cr.request_id in (";
					selection_sql_where += buildQuery(conn, rs1.getString("hmda_extract_query_id"), Integer.valueOf(evaluator_id).toString());
					selection_sql_where += ") ";
				}

				switch (rs1.getInt("selection_criteria_id")) {
					case 0 :
						// all eligible hmda apps...changed to include
						// respective
						// programs for any product (except lease)...this was
						// done
						// above in select statement because null won't work
						// here
						selection_sql_from += ", config_loan_purpose clp";
						selection_sql_where += " and nvl(clp.hmda_eligible_flg,0) = 1 and clp.evaluator_id = cr.evaluator_id AND clp.product_id = cr.product_id AND clp.loan_purpose_id = cr.loan_purpose_id ";
						break;
					case 1 :
						// all eligible hmda apps not in a previous extract
						selection_sql_from += ", config_loan_purpose clp";
						selection_sql_where += " and nvl(clp.hmda_eligible_flg,0) = 1 and clp.evaluator_id = cr.evaluator_id AND clp.product_id = cr.product_id AND clp.loan_purpose_id = cr.loan_purpose_id ";
						selection_sql_where += "AND NOT EXISTS (select 1 from credit_request_hmda_extract crhe where crhe.evaluator_id = "
								+ evaluator_id
								+ " and crhe.hmda_extract_id = '"
								+ export_id
								+ "' and cr.request_id = crhe.request_id) ";
						break;
					case 2 :
						// all eligible hmda apps not in a previous extract OR
						// action date is newer than extract date
						selection_sql_from += ", config_loan_purpose clp";
						selection_sql_where += " and nvl(clp.hmda_eligible_flg,0) = 1 and clp.evaluator_id = cr.evaluator_id AND clp.product_id = cr.product_id AND clp.loan_purpose_id = cr.loan_purpose_id ";
						selection_sql_where += "AND NOT EXISTS (select 1 from credit_request_hmda_extract crhe, credit_request_hmda crh where crh.request_id = crhe.request_id AND crh.action_dt < crhe.generated_dt AND crhe.evaluator_id = "
								+ evaluator_id
								+ " and crhe.hmda_extract_id = '"
								+ export_id
								+ "' and cr.request_id = crhe.request_id) ";
						break;
					default :
						System.out.println("Unknown selection_criteria_id...will use all eligible hmda apps");
						selection_sql_from += ", config_loan_purpose clp";
						selection_sql_where += " and nvl(clp.hmda_eligible_flg,0) = 1 and clp.evaluator_id = cr.evaluator_id AND clp.product_id = cr.product_id AND clp.loan_purpose_id = cr.loan_purpose_id ";
						break;
				}
			} else {
				System.out.println("Exception:  could not find an extract configured for evaluator_id = "
						+ evaluator_id + ", and extract_id = " + export_id);
				try{
			        if(rs1 != null) rs1.close();
			    }
				catch(Exception e){
					e.printStackTrace();
				}
				finally{
					try {if(ps1 != null) ps1.close();} catch (Exception e) {e.printStackTrace();}
				}
				System.exit(0);
			}

		} catch (Exception e) {
			System.out.println("Exception: error looking up extract. " + e);
			e.printStackTrace();
			try{
			    if(rs1 != null) rs1.close();
			}
			catch(Exception e1){
				e1.printStackTrace();
			}
			finally{
				try {if(ps1 != null) ps1.close();} catch (Exception e2) {e2.printStackTrace();}
			}
			System.exit(0);
		} finally {
		    try{ if(rs1 != null) rs1.close(); }catch(Exception e1){e1.printStackTrace();}
			try{ if(ps1 != null) ps1.close(); }catch(Exception e1){e1.printStackTrace();}
		}
		return (selection_sql_from + " " + selection_sql_where);
	}*/

	// /////////////////////////end
	// createSelectionQuery()//////////////////////////////////

	private String getProgram(Connection con, Integer evaluatorId,
			Long requestId, int productId) {
		String retVal = "";
		String tablename = null;

		// now that other products are hmda eligible, we need to pull program
		// from respective loan table
		if (productId == 16 || productId == 17)
			tablename = "credit_request_home_loan";
		else if (productId == 22)
			tablename = "credit_request_credit_card";
		else
			tablename = "credit_request_loan";
        PreparedStatement ps = null;
		ResultSet rs  = null;
		try {
			String sql = "select description_txt "
				+ "from ?"
				+ " crhl, config_product_program cpp "
				+ "where cpp.evaluator_id = ? and crhl.request_id = ? and crhl.program_id = cpp.program_id";


			ps = con.prepareStatement(sql);

			ps.setString(1, tablename);
			ps.setInt(2, evaluatorId);
			ps.setLong(3, requestId);

			rs = ps.executeQuery();

			if (rs.next()) {
				retVal = rs.getString("description_txt");
			}
		} catch (Exception e) {
           e.printStackTrace();
		}
        finally {
			try{ if(rs != null) rs.close(); }catch(Exception e1){e1.printStackTrace();}
			try{ if(ps != null) ps.close(); }catch(Exception e1){e1.printStackTrace();}
		}
		return encodeValue(retVal);
	}

	// this method xml encodes characters that could make the xml malformed
	private String encodeValue(String s_val) {
		try {
			s_val = s_val.replaceAll("&", "&amp;");
			s_val = s_val.replaceAll(">", "&gt;");
			s_val = s_val.replaceAll("<", "&lt;");
			s_val = s_val.replaceAll("\"", "&quot;");
			s_val = s_val.replaceAll("'", "&#39;");
		} catch (Exception e) {
			System.out.println("Error xml encoding string: " + e.toString());
			e.printStackTrace();
		}
		return s_val;
	}

	// Based off of code from GenJob. It doesn't seem like this method would be
	// used much in there in the future,
	// so I'm just putting it by itself here to be used by this program only.
	// Takes evaluator_id rather than request_id.
	private String buildQuery(Connection con, String query_id,
			String evaluator_id) throws Exception {
		Query querySQLParms = new Query(con);
		Query querySQL = new Query(con);
		String sql = "";

		if (evaluator_id == null || evaluator_id.trim().equals("")) {
			return null;
		}

		querySQL.prepareStatement("select query_txt from config_doc_queries where query_id = ? and evaluator_id = ?");
		querySQL.setInt(1, query_id);
		querySQL.setInt(2, evaluator_id);
		querySQL.executePreparedQuery();

		if (!querySQL.next())
			throw new Exception("Query not found: " + query_id);

		sql = querySQL.getColValue("query_txt");

		querySQLParms.prepareStatement("select parm_name_txt,source_id,source_txt from config_doc_query_parms where query_id = ? and evaluator_id = ? ");
		querySQLParms.setInt(1, Integer.parseInt(query_id));
		querySQLParms.setInt(2, Integer.parseInt(evaluator_id));
		querySQLParms.executePreparedQuery();

		int source_id;
		String parm, sourceValue;

		while (querySQLParms.next()) {
			source_id = Integer.parseInt(querySQLParms.getColValue("source_id"));

			switch (source_id) {
			// Only want to support evaluator_id
				case 4 : {
					sourceValue = querySQLParms.getColValue("source_txt", "notavail");
					if (!sourceValue.equalsIgnoreCase("evaluator_id")) {
						System.out.println("hmdaextract: Source "
								+ sourceValue
								+ " not supported in Application Selection Query");
						throw new Exception("hmdaextract: Source "
								+ sourceValue
								+ " not supported in Application Selection Query");
					}
					parm = querySQLParms.getColValue("parm_name_txt");
					if (sql.indexOf(parm) < 0) {
						System.out.println("hmdaextract: Parameter " + parm
								+ " not found in Application Selection Query");
						throw new Exception("hmdaextract: Parameter " + parm
								+ " not found in Application Selection Query");
					}
					sql = replace(sql, parm, evaluator_id);
				}
					break;
				default :
					System.out.println("hmdaextract: Source ID " + source_id
							+ " not supported in Application Selection Query");
					throw new Exception("hmdaextract: Source ID " + source_id
							+ " not supported in Application Selection Query");
			} // end switch
		}

		return sql;
	}

	private String replace(String target, String removeStr, String replaceWith) {
		if (target.indexOf(removeStr) < 0)
			return (target);
		int idx = 0, removeLength = removeStr.length(), offset = 0;
		while ((idx = target.indexOf(removeStr, offset)) >= 0) {
			String prefix = "", suffix = "";
			if (idx > 0)
				prefix = target.substring(0, idx);
			if (idx + removeLength + 1 <= target.length())
				suffix = target.substring(idx + removeLength);
			offset = prefix.length() + replaceWith.length();
			target = prefix + replaceWith + suffix;
			// System.out.println(target);
			if (offset >= target.length())
				break;
		} // while
		return (target);

	} // replace

	/**
	 * Requires at least 3, maximum 5, arguments for hmdaextract ini file - path
	 * to origenate.ini file to use for configuration evaluator id - Origenate's
	 * numeric identifier of lender extract id - Identifier of the hmda extract
	 * to determine query for selection criteria and transaction type
	 * debug(optional) - 1=on/0=off; default is off; denotes whether to write
	 * intermediate results to log help - print usage info
	 *
	 * @param args
	 *            - The arguments to hmdaextract
	 */
	public boolean getArgsNative(String[] args) {
		IniFile ini = new IniFile();
		String inifile = "", dbhost = "", dbport = "", dbsid = "", dbuser = "", dbpwd = "", sTNSEntry = "";

		argumentList = new ArrayList<Argument>();
		argumentList.add(new Argument(false, 'h', "", "Print usage information"));
		argumentList.add(new Argument(true, 'i', "file", "Path to origenate.ini file to use for configuration"));
		argumentList.add(new Argument(true, 'e', "evaluator id", "Origenate's numeric identifier of lender"));
		argumentList.add(new Argument(true, 'x', "extract id", "Identifier of the hmda extract to determine query for selection criteria and transaction type"));
		argumentList.add(new Argument(false, 'd', "debug", "1=on/0=off; default is off; denotes whether to show selection criteria and xml before styling and unencoding"));
		CommandLine cmdLine = null;

		try {
			cmdLine = this.parse(args);
		} catch (ParseException e) {
			System.err.println("Error parsing arguments. " + e);
			e.printStackTrace();
			showUsage();
			return false;
		}

		if (!cmdLine.getOptionValue('h').equals("")) {
			showUsage();
			return false;
		}

		if (!cmdLine.getOptionValue('d').equals("")) {
			String debugFlag = cmdLine.getOptionValue('d');
			if (debugFlag.length() != 1)
			{
				showUsage();
				return false;
			}
			// debugflag = 1 sets this to true.
			if (debugFlag.charAt(0) == '1')
				debug_flg = 1;
			else
				debug_flg = 0;
		} else {
			debug_flg = 0; // default value for debug flg
		}

		if (!cmdLine.getOptionValue('i').equals("")) // option i
		{
			inifile = cmdLine.getOptionValue('i');

			try {
				//
				// Read host, user, sid and password from ini file
				//
				ini.readINIFile(inifile);

				dbhost = ini.getINIVar("database.host", "");
				dbport = ini.getINIVar("database.port", "");
				dbuser = ini.getINIVar("database.user", "");
				dbpwd = ini.getINIVar("database.password", "");
				dbsid = ini.getINIVar("database.sid", "");
				sTNSEntry = ini.getINIVar("database.TNSEntry", "");
				s_xslt_inifile = ini.getINIVar("mpe.xslt_dir", "");

			} catch (Exception e) {
				System.out.println("Caught exception reading ini file '"
						+ inifile + "':" + e.toString());
				e.printStackTrace();
			}
		} else {
			showUsage();
			return false;
		}

		if (!cmdLine.getOptionValue('x').equals("")) // option x
		{
			export_id = cmdLine.getOptionValue('x');
		} else {
			System.out.println("Export ID not supplied.  see usage");
			showUsage();
			return false;
		}

		if (!cmdLine.getOptionValue('e').equals("")) // option e
		{
			try {
				evaluator_id = Integer.parseInt(cmdLine.getOptionValue('e'));
			} catch (Exception e) {
				System.out.println("Exception: Could not determine integer value of evaluator.  see usage");
				e.printStackTrace();
				showUsage();
				return false;
			}
		} else {
			System.out.println("Evaluator ID not supplied.  see usage");
			showUsage();
			return false;
		}

		try {
			DBConnection DBConnect = new DBConnection();

			if (sTNSEntry.length() == 0) {
				conn = DBConnect.getConnection(dbhost, dbsid, dbuser, dbpwd, null, dbport, "");
			} else {
				// use tns entry if available
				conn = DBConnect.getConnectionTNS(sTNSEntry, dbuser, dbpwd, null);
			}
		} catch (Exception e) {
			System.out.println("Exception: supplied db information could not create a connection.  see usage");
			e.printStackTrace();
			showUsage();
			return false;
		}
		return true;
	}

	/**
	 *
	 * Axioms: Arguments containing multiple spaces e.g. "this is a   test" will
	 * be interpreted as if there were only one space there, and that's because
	 * of the JVM. All arguments must start with a dash. Otherwise they are
	 * concatenated to the last argument.
	 *
	 * @param programName
	 *            the name of the program, used when printing the usage
	 *            information
	 * @param args
	 *            arguments passed in to the running java program
	 * @return
	 * @throws Exception
	 *             Exception to be thrown when the parsing fails.
	 */
	public CommandLine parse(String[] args) throws ParseException {
		CommandLine cmd = new CommandLine();

		// insert all values into the cmd structure
		for (Argument a : argumentList) {
			// clear argument value in case user is reusing this.
			a.setArgumentValue("");
			cmd.putValue(a.getcCharacter(), a);
		}
		Argument lastArgument = null;
		for (String currentArg : args) {
			// all args must start with a '-'
			if (currentArg.startsWith("-")) {
				// skip all arguments which are shorter than "-a"
				if (currentArg.length() < 2)
					continue;

				// Hashmap lookup avoids nested FOR loop when comparing the IDs.
				Argument currentArgument = cmd.getValue(currentArg.charAt(1));
				if (currentArgument == null)
					throw new ParseException("Unrecognized argument -"
							+ currentArg.charAt(1));

				// if this is a FLAG (e.g. -h), we note its presence and move on
				if (currentArgument.getStrLongName().length() == 0)
					currentArgument.setArgumentValue("true");
				else
					// regular argument. We grab the value and place it in its
					// designated argument container.
					currentArgument.setArgumentValue(currentArg.substring(2));

				lastArgument = currentArgument;

			} else {
				if (lastArgument != null)
					lastArgument.setArgumentValue(lastArgument.getArgumentValue()
							+ " " + currentArg); // concatenate what was just
													// read to the previous
													// value.
				else
					throw new ParseException("Argument " + currentArg
							+ " could not be interpreted");
			}
		}

		return cmd;
	}

	/**
	 * Requires at least 3, maximum 5, arguments for hmdaextract ini file - path
	 * to origenate.ini file to use for configuration evaluator id - Origenate's
	 * numeric identifier of lender extract id - Identifier of the hmda extract
	 * to determine query for selection criteria and transaction type
	 * debug(optional) - 1=on/0=off; default is off; denotes whether to write
	 * intermediate results to log help - print usage info
	 *
	 * @param args
	 *            - The arguments to hmdaextract
	 */
	// @SuppressWarnings("static-access")
	// public void getArgsCLI(String[] args)
	// {
	// IniFile ini = new IniFile();
	// String inifile = "", dbhost = "", dbport = "", dbsid = "", dbuser = "",
	// dbpwd = "", sTNSEntry = "";
	//
	// argumentList = new
	// options.addOption("h", "help", false, "Print usage information");
	// Option iniFile =
	// OptionBuilder.withArgName("file").hasArg().withDescription("Path to origenate.ini file to use for configuration (required)").create("i");
	// Option sqlFile =
	// OptionBuilder.withArgName("evaluator id").hasArg().withDescription("Origenate's numeric identifier of lender (required)").create("e");
	// Option outFile =
	// OptionBuilder.withArgName("extract id").hasArg().withDescription("Identifier of the hmda extract to determine query for selection criteria and transaction type (required)").create("x");
	// options.addOption(iniFile);
	// options.addOption(sqlFile);
	// options.addOption(outFile);
	// options.addOption(OptionBuilder.withArgName("debug").isRequired(false).withDescription("1=on/0=off; default is off; denotes whether to show selection criteria and xml before styling and unencoding (optional)").create('d'));
	// // options.addOption("d","debug",
	// //
	// false,"1=on/0=off; default is off; denotes whether to show selection criteria and xml before styling and unencoding (optional)");
	//
	// CommandLine cmdLine = null;
	// try
	// {
	// cmdLine = parser.parse(options, args);
	// } catch (ParseException e)
	// {
	// System.err.println("Error parsing arguments.");
	// showUsage();
	// }
	//
	// if (cmdLine.hasOption('h'))
	// {
	// showUsage(); // and quit
	// }
	//
	// if (cmdLine.hasOption('d'))
	// {
	// String debugFlag = cmdLine.getOptionValue('d', "0");
	// if (debugFlag.length() != 1)
	// showUsage();
	// // debugflag = 1 sets this to true.
	// if (debugFlag.charAt(0) == '1')
	// debug_flg = 1;
	// else
	// debug_flg = 0;
	// } else
	// {
	// debug_flg = 0; // default value for debug flg
	// }
	//
	// if (cmdLine.hasOption('i')) // option i
	// {
	// inifile = cmdLine.getOptionValue('i');
	//
	// try
	// {
	// //
	// // Read host, user, sid and password from ini file
	// //
	// ini.readINIFile(inifile);
	//
	// dbhost = ini.getINIVar("database.host", "");
	// dbport = ini.getINIVar("database.port", "");
	// dbuser = ini.getINIVar("database.user", "");
	// dbpwd = ini.getINIVar("database.password", "");
	// dbsid = ini.getINIVar("database.sid", "");
	// sTNSEntry = ini.getINIVar("database.TNSEntry", "");
	// s_xslt_inifile = ini.getINIVar("mpe.xslt_dir", "");
	//
	// } catch (Exception e)
	// {
	// System.out.println("Caught exception reading ini file '"
	// + inifile + "':" + e.toString());
	// }
	// } else
	// {
	// showUsage(); // and quit
	// }
	//
	// if (cmdLine.hasOption('x')) // option x
	// {
	// export_id = cmdLine.getOptionValue('x');
	// } else
	// {
	// showUsage(); // and quit
	// }
	//
	// if (cmdLine.hasOption('e')) // option e
	// {
	// try
	// {
	// evaluator_id = Integer.parseInt(cmdLine.getOptionValue('e'));
	// } catch (Exception e)
	// {
	// System.out.println("Exception: Could not determine integer value of evaluator.  see usage");
	// showUsage();
	// }
	// } else
	// {
	// System.out.println("Evaluator ID not supplied.  see usage");
	// showUsage();
	// }
	//
	// try
	// {
	// DBConnection DBConnect = new DBConnection();
	//
	// if (sTNSEntry.length() == 0)
	// {
	// conn = DBConnect.getConnection(dbhost, dbsid, dbuser, dbpwd, null,
	// dbport, "");
	// } else
	// {
	// // use tns entry if available
	// conn = DBConnect.getConnectionTNS(sTNSEntry, dbuser, dbpwd, null);
	// }
	// } catch (Exception e)
	// {
	// System.out.println("Exception: supplied db information could not create a connection.  see usage");
	// showUsage();
	// }
	// /*
	// *
	// * if(cmdLine.hasOption('s')) { sqlFileName =
	// * cmdLine.getOptionValue('s');
	// *
	// * log.FmtAndLogMsg("SQL File name: " + sqlFileName);
	// *
	// * if(sqlFileName.length() <= 0) {
	// * log.FmtAndLogMsg("Need to specify SQL file"); showUsage(); } } else {
	// * showUsage(); }
	// *
	// * if(cmdLine.hasOption('o')) { outFileName =
	// * cmdLine.getOptionValue('o');
	// *
	// * log.FmtAndLogMsg("Output File name: " + outFileName);
	// *
	// * if(outFileName.length() <= 0) {
	// * log.FmtAndLogMsg("Need to specify output file"); showUsage(); } }
	// * else { showUsage(); }
	// *
	// * // If no errors in args, try to connect to DB connectToDB(ini);
	// */
	// }

	// ////////////////////////////////// get args
	// //////////////////////////////////////
	// private void getArgs(String args[]) {
	// IniFile ini = new IniFile();
	// String inifile = "", dbhost = "", dbport = "", dbsid = "", dbuser = "",
	// dbpwd = "", sTNSEntry = "";
	// int i;
	//
	// if (args.length >= 3) {
	// for (i = 0; i < args.length; ++i) {
	// if ((args[i].charAt(0) != '-') && (args[i].length() > 1)) {
	// showUsage();
	// }
	// switch (args[i].charAt(1)) {
	// case 'i' :
	// inifile = args[i].substring(2);
	//
	// try {
	// //
	// // Read host, user, sid and password from ini file
	// //
	// ini.readINIFile(inifile);
	//
	// dbhost = ini.getINIVar("database.host", "");
	// dbport = ini.getINIVar("database.port", "");
	// dbuser = ini.getINIVar("database.user", "");
	// dbpwd = ini.getINIVar("database.password", "");
	// dbsid = ini.getINIVar("database.sid", "");
	// sTNSEntry = ini.getINIVar("database.TNSEntry", "");
	//
	// } catch (Exception e) {
	// System.out.println("Caught exception reading ini file '"
	// + inifile + "':" + e.toString());
	// }
	//
	// break;
	// case 'x' :
	// export_id = args[i].substring(2);
	// break;
	// case 'e' :
	// try {
	// // get evaluator
	// evaluator_id = Integer.parseInt(args[i].substring(2));
	// } catch (Exception e) {
	// System.out.println("Exception: Could not determine integer value of evaluator.  see usage");
	// }
	// break;
	// case 'd' :
	// try {
	// debug_flg = Integer.parseInt(args[i].substring(2));
	// } catch (Exception e) {
	// System.out.println("Exception: Could not determine integer value of debug flag.  see usage");
	// }
	// break;
	// default :
	// System.out.println("Unknown argument.  see usage");
	// showUsage();
	// break;
	// }
	// }
	//
	// try {
	// DBConnection DBConnect = new DBConnection();
	//
	// if (sTNSEntry.length() == 0) {
	// conn = DBConnect.getConnection(dbhost, dbsid, dbuser, dbpwd, null,
	// dbport, "");
	// } else {
	// // use tns entry if available
	// conn = DBConnect.getConnectionTNS(sTNSEntry, dbuser, dbpwd, null);
	// }
	// } catch (Exception e) {
	// System.out.println("Exception: supplied db information could not create a connection.  see usage");
	// showUsage();
	// }
	// if (evaluator_id == 0) {
	// System.out.println("Evaluator ID not supplied.  see usage");
	// showUsage();
	// }
	// } else {
	// showUsage();
	// }
	// }

	// //////////////////////////// end get args
	// /////////////////////////////////////

	// /////////////////////////////// USAGE
	// /////////////////////////////////////////
	public void showUsage() {
		/*
		 * System.out.println("Usage:"); System.out .println(
		 * "hmdaextract -i<ini file> -e<evaluator id> -x<extract id> -d<debug>"
		 * ); System.out .println(
		 * "------------------------------------------------------------------------------"
		 * ); System.out
		 * .println("ini file - path to origenate.ini file to use for configuration"
		 * ); System.out
		 * .println("evaluator id - Origenate's numeric identifier of lender");
		 * System.out .println(
		 * "extract id - identifier of the hmda extract to determine query for selection criteria and transaction type"
		 * ); System.out .println(
		 * "debug - 1=on/0=off; default is off; denotes whether to show selection criteria and xml before styling and unencoding"
		 * ); System.exit(1);
		 */
		System.out.println("Usage:");
		StringBuffer strBuffer = new StringBuffer();
		for (Argument a : argumentList)
			strBuffer.append((a.getStrLongName().equals("")
					? String.format(" -%c", a.getcCharacter())
					: String.format(" -%c<%s>", a.getcCharacter(), a.getStrLongName())));
		System.out.println("hmdaextract" + strBuffer.toString());

		System.out.println("------------------------------------------------------------------------------");

		for (Argument a : argumentList)
			System.out.println(String.format("-%c\t\t%s %s", a.getcCharacter(), a.getStrDescription(), (a.isbRequired() ? "(Required)" : "(Optional)")));
	}
	// ////////////////////////////// END USAGE
	// //////////////////////////////////////////
}
