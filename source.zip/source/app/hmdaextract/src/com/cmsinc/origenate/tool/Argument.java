package com.cmsinc.origenate.tool;

/**
 * Command line argument class with five fields that match with typical command
 * line arguments.
 * 
 * @author chrisk
 * 
 */

public class Argument {
	private final boolean bRequired;
	private final char cCharacter;
	private final String strLongName;
	private final String strDescription;
	private String argumentValue;

	/**
	 * Constructor
	 * 
	 * @param bRequired
	 *            if the argument is required or not (e.g. -h<help> is not
	 *            required)
	 * @param cCharacter
	 *            single character representation of the argument
	 * @param strLongName
	 *            long name (-d = debug) when printing usage information
	 * @param strDescription
	 *            description of what the argument does
	 */
	public Argument(boolean bRequired, char cCharacter, String strLongName,
			String strDescription) {
		super();
		this.bRequired = bRequired;
		this.cCharacter = cCharacter;
		this.strDescription = strDescription;
		this.strLongName = strLongName;
		this.argumentValue = "";
	}

	public String getArgumentValue() {
		return argumentValue;
	}

	public void setArgumentValue(String argumentValue) {
		this.argumentValue = argumentValue;
	}

	public boolean isbRequired() {
		return bRequired;
	}

	public char getcCharacter() {
		return cCharacter;
	}

	public String getStrDescription() {
		return strDescription;
	}

	public String getStrLongName() {
		return strLongName;
	}
}
