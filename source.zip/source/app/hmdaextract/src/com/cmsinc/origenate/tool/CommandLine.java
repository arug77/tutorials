package com.cmsinc.origenate.tool;

/**
 * CommandLine class
 * 
 * Contains the final output after parsing of the command line is complete.
 * 
 *  @author chrisk
 */

import java.util.HashMap;
import java.util.Map;

public class CommandLine {
	private Map<Character, Argument> values;

	public CommandLine() {
		// initialize hashmap
		values = new HashMap<Character, Argument>();
	}

	/**
	 * Puts the Argument in the location of cValue, overwriting what's already
	 * there.
	 * 
	 * @param cValue
	 *            the argument you want (e.g. -i<inifile>; cValue = 'i')
	 * @param strArgument
	 *            Argument class of what gets stored there.
	 */
	public void putValue(char cValue, Argument strArgument) {
		values.put(Character.valueOf(cValue), strArgument);
	}

	/**
	 * Gets the Argument class for the indicated character
	 * 
	 * @param cValue
	 *            the argument you want (e.g. -i<inifile>; cValue = 'i')
	 * @return
	 */
	public Argument getValue(char cValue) {
		return values.get(Character.valueOf(cValue)); // Map class returns null
														// if the mapping
														// doesn't exist
	}

	/**
	 * Gets the actual value of the argument at the indicated character (saves
	 * the caller a step)
	 * 
	 * @param cValue
	 *            the argument you want (e.g. -i<inifile>; cValue = 'i')
	 * @return
	 */
	public String getOptionValue(char cValue) {
		return this.getValue(cValue).getArgumentValue();
	}
}
