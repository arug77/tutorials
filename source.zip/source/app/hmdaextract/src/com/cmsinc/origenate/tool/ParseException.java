package com.cmsinc.origenate.tool;

/**
 * ParseException.java
 * Exception that gets thrown when we have a 
 * problem parsing the command line
 * @author chrisk
 *
 */

public class ParseException extends Exception
{
	private static final long serialVersionUID = 1L;

	/**
	 * Default Constructor
	 * @param strError Error string describing what went wrong.
	 */
	public ParseException(String strError)
	{
		super(strError);
	}
}
