import java.io.BufferedReader; // GL. for ini file reading
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

import com.allaire.cfx.CustomTag;
import com.allaire.cfx.Query;
import com.allaire.cfx.Response;

import eValuate.DMAppDetail;
import eValuate.DMAppDetailHolder;
import eValuate.DMDataElement;
import eValuate.EVAppContext;
import eValuate.EVAppInfo;
import eValuate.EVAppKeySet;
import eValuate.EVAppKeys;
import eValuate.EVConfigKeys;
import eValuate.EVEntityInfo;
import eValuate.ModuleException;
import eValuate.OrbTSColumn2;
import eValuate.OrbTSTable2;
import eValuate.SPParamElement;
import eValuate.evCORBAException;

public class EvaluateCF implements CustomTag
{
	static boolean initialized = false;
	static Object critsec = new Object();

	static int counter=0;


	static EvaluateInstance eiPri=null;  // primary eValuate instance
	static EvaluateInstance eiAlt=null;  // alternate instance in case primary goes down
	static EvaluateInstance ei=null; // instance we are currently talking to, either pri or alt
	static Hashtable appseqnoTable=new Hashtable();

	private static final int MAX_SYNC_CACHE = 10000;
	private static Map<String, Object> syncObjects = new HashMap<String, Object>(MAX_SYNC_CACHE);
	private static Object sync = new Object();
	private static Set<String> activeObjects = new HashSet<String>();


	/*  These are now maintained in the EvaluateInstance class.
ei points to the current evaluate instance that is up.

static org.omg.CORBA.ORB orb=null;
static eValuate.DM.DataManager dm=null;
static Evaluator ev=null;
static ScriptProcessorFacade sp=null;
static ScoreModuleFacade sc=null;
static HashMap table_id;
static HashMap id_table;
static HashMap field_id;
static HashMap id_field;
static HashMap id_shortfield;
	 */

	static int conncurrentRequests = 0; // set but not used

	// GL. ini file reading
	static String ini_file_name="";
	static Properties INIProperties=null;

	static boolean debugon=false;

	static int GET = 0;
	static int PUT = 1;
	static int REMOVE = 2;

	public synchronized EvaluateInstance  getSetAppseqnoInstance(int action,String appseqno,EvaluateInstance evi) {
		if (action==PUT) {
			if (debugon) System.out.println(getDateTime()+"EvaluateCF: appseqno table PUT: "+appseqno);
			return((EvaluateInstance)appseqnoTable.put(appseqno,evi));
		}
		if (action==GET) {
			if (debugon) System.out.println(getDateTime()+"EvaluateCF: appseqno table GET: "+appseqno);
			return((EvaluateInstance)appseqnoTable.get(appseqno));
		}
		if (action==REMOVE) {
			if (debugon) System.out.println(getDateTime()+"EvaluateCF: appseqno table REMOVE: "+appseqno);
			return((EvaluateInstance)appseqnoTable.remove(appseqno));
		}
		return null;
	}

	/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	public String getCFAttribute(com.allaire.cfx.Request request, String name)
	{
		String value = request.getAttribute(name);
		if(value == null) value="";
		return value;
	}

	/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	public void processRequest( com.allaire.cfx.Request request, Response response )
			throws Exception
	{

		/*
   Multiple requests can be coming thru this rtn at the same time. If one of the requests has an error
   in evaluate and we switch over to the alternate instance we don't want the other threads to fail and
   cause the alternate to switch back to the primary. To prevent this we are setting eiCur to the current
   EvaluateInstance (ei) and then passing it to all subsequent methods to use.
		 */
		EvaluateInstance eiCur=ei;
		boolean errorOccurred=false;
		String exceptionMsg="";
		String appseqno = getCFAttribute(request,"EVAPPSEQNO");


		try
		{
			++conncurrentRequests;
			String module = getCFAttribute(request,"MODULE");

			if (module.equals("SetIniFile")) {
				// This will only be called once when the application variables are set in confglobalconstants.cfm
				// load the inifile so we can access the variables to initialize evaluate
				ini_file_name=getCFAttribute(request,"INI_FILE_NAME");
				// will set INIProperties
				readINIFile(ini_file_name);
				// create initial instances of EvaluateInstances, one for pri and alternate
				synchronized (critsec) {
					eiPri = new EvaluateInstance(INIProperties);
					eiAlt = new EvaluateInstance(INIProperties);
					// try to initialize each instance, ei will be set to either the Pri or Alt instance. If both are availabe the the  Pri will be selected
					initializeInstances(null,null);
				} // sync
			}
			else
				if (module.equals("SetEnvVariables"))
				{
					synchronized (critsec) {
						if(!initialized)
						{
							// try again
							eiPri = new EvaluateInstance(INIProperties);
							eiAlt = new EvaluateInstance(INIProperties);
							// try to initialize each instance, ei will be set to either the Pri or Alt instance. If both are availabe the the  Pri will be selected
							// this will also set the initialized variable if successful
							initializeInstances(null,null);
							if (!initialized)
								throw new Exception("No evaluate instances available");
						}
					} // sync
				}
				else if (module.equals("ResetEnvVariables"))
				{
					System.out.println(getDateTime()+"EvaluateCF: ResetEnvVariables called");
					synchronized (critsec) {
						eiPri = new EvaluateInstance(INIProperties);
						eiAlt = new EvaluateInstance(INIProperties);
						// try to initialize each instance, ei will be set to either the Pri or Alt instance. If both are availabe then the  Pri will be selected
						// this will also set the initialized variable if successful
						initializeInstances(null,null);
					} // sync
				}
				else if(module.equals("Notifier"))
				{
					// this should not be called anymore from CF. It does not pass an app seq no.
					synchronized (critsec) {
						if(!initialized) {
							// try again
							eiPri = new EvaluateInstance(INIProperties);
							eiAlt = new EvaluateInstance(INIProperties);
							// try to initialize each instance, ei will be set to either the Pri or Alt instance. If both are availabe the the  Pri will be selected
							// this will also set the initialized variable if successful
							initializeInstances(null,null);
							if (!initialized)
								throw new Exception("No evaluate instances available");
						}
					} // sync

					eiCur=ei;

					cfxNotify(request,response,eiCur);
				}
				else if(module.equals("ResetApp")) 
				{
					synchronized(sync) { // synchronize on object that locks generation of new sync objects
						String EVAppSeqNo = getCFAttribute(request,"EVAPPSEQNO");
						if(EVAppSeqNo != null && !EVAppSeqNo.equals("")) {
							activeObjects.remove(EVAppSeqNo);
							syncObjects.remove(EVAppSeqNo);
						}
					}
				}
				else // application processing
				{
					synchronized (critsec) {
						if(!initialized) {
							// try again
							eiPri = new EvaluateInstance(INIProperties);
							eiAlt = new EvaluateInstance(INIProperties);
							// try to initialize each instance, ei will be set to either the Pri or Alt instance. If both are availabe the the  Pri will be selected
							// this will also set the initialized variable if successful
							initializeInstances(null,null);
							if (!initialized)
								throw new Exception("No evaluate instances available, module called: "+module);
						}
					} // sync


					// set eiCur to the instance we want to talk to

					// If this appseqno is in a transaction (init,send,run script, flush) then it will be in the hash table
					// util it is flushed. If it is and it points to a previously failed instance of eval we need to still point to
					// it instead of pointing to the new instance. If we pointed it to the new instance then it would get an error
					// and we don't want to fail back to the original (this would cause a constant flip/flop between the two. Instead
					// let it fail on the old instance so the transaction can be backed out by the CF calling code.


					if (appseqno.length()>0 && !appseqno.equals("0")) {
						EvaluateInstance eiTmp=getSetAppseqnoInstance(GET,appseqno,null);
						if (eiTmp==null) {
							eiCur=ei; // use what ever is the currently active instance
							getSetAppseqnoInstance(PUT,appseqno,eiCur);
						}
						else {
							// use whatever instance it was pointing to
							eiCur=eiTmp;
						}

					}  // app seqno is present, may not be present for newly created apps, they will be added to the table after the app is initialized and an appseqno is retruned
					else
						eiCur=ei;

					counter++;

					String client = getCFAttribute(request,"CLIENT");
					String effDate = getCFAttribute(request,"EFFDATE");
					String EVAppSeqNo = getCFAttribute(request,"EVAPPSEQNO");
					String EVAppEntity = getCFAttribute(request,"EVAPPENTITY");
					String EVReqID = getCFAttribute(request,"REQUESTORID");
					String EVReqTypeID = getCFAttribute(request,"REQUESTORTYPEID");
					String traceLevel = getCFAttribute(request,"TRACELEVEL");
					if(request.debug())
					{
						response.writeDebug("Tag Count = " + counter + "<br>");
						response.writeDebug("CLIENT = " + client + "<br>");
						response.writeDebug("EFFDATE = " + effDate + "<br>");
						response.writeDebug("EVAPPSEQNO = " + EVAppSeqNo + "<br>");
						response.writeDebug("EVAPPENTITY = " + EVAppEntity + "<br>");
						response.writeDebug("EVReqID = " + EVReqID + "<br>");
						response.writeDebug("EVReqTypeID = " + EVReqTypeID + "<br>");
						response.writeDebug("TRACELEVEL = " + traceLevel + "<br>");
					}

					// Synchronization logic to protect against Evaluate being called at the same
					// time for the same application. We maintain a Map keyed by the requestId, and the
					// value is a plain Object used for synchronization.
					// For memory conservation, the cache is capped at 1000. Once the cache reaches 1000,
					// the logic will clear out any stale appseqnos that are not currently processing an
					// Evaluate call.
					Object syncObject = null;
					if(!syncObjects.containsKey(EVAppSeqNo)) {
						synchronized(sync) {
							if(!syncObjects.containsKey(EVAppSeqNo)) { // double locking check

								// If there are too many stale synchronization objects
								if(syncObjects.size() >= MAX_SYNC_CACHE) {

									// Get any appseqnos that are processing an Evaluate call
									Map<String, Object> tmpActiveObjects = new HashMap<String, Object>();
									for(String activeAppseqno : activeObjects) {
										Object activeObject = syncObjects.get(activeAppseqno);
										if(activeObject != null) {
											tmpActiveObjects.put(activeAppseqno, activeObject);
										}
									}

									// Clear out all synchronization objects
									syncObjects.clear();

									// Put any appseqnos and their synchronization objects back
									// that are currently processing an Evaluate call
									syncObjects.putAll(tmpActiveObjects);
								}

								syncObject = new Object();
								syncObjects.put(EVAppSeqNo, syncObject);
							} else {
								syncObject = syncObjects.get(EVAppSeqNo);
							}
						}
					} else {
						syncObject = syncObjects.get(EVAppSeqNo);
					}
					
					if(activeObjects.contains(EVAppSeqNo)) {
						System.out.println(getDateTime()+"EvaluateCF: Application already in process. Waiting for completion. Appseqno: " + EVAppSeqNo);
					}

					synchronized(syncObject) { // synchronizing on requestId
						try {
							activeObjects.add(EVAppSeqNo);

							EVAppContext appContext = new EVAppContext();
							appContext.ai = new EVAppInfo();
							appContext.ai.appKeys = new EVAppKeys();
							appContext.ai.appKeys.EVAppSeqNo = Integer.parseInt(EVAppSeqNo);
							appContext.entityInfo = new EVEntityInfo();
							appContext.entityInfo.appEntity ="";
							appContext.entityInfo.reqID = Integer.parseInt(EVReqID);
							appContext.entityInfo.reqtypeID = Integer.parseInt(EVReqTypeID);
							appContext.bureauID="";
							appContext.ai.appLvl = eValuate.TraceDepth.Level.NONE;

							// set the trace level
							appContext.ai.traceLevel = eValuate.Trace.TraceLevel.NO_TRACING;
							if(traceLevel.equals("ENTRY_EXIT_POINT"))
							{
								appContext.ai.traceLevel = eValuate.Trace.TraceLevel.ENTRY_EXIT_POINT;
							}
							else if(traceLevel.equals("HIGH"))
							{
								appContext.ai.traceLevel = eValuate.Trace.TraceLevel.HIGH;
							}
							else if(traceLevel.equals("DETAIL"))
							{
								appContext.ai.traceLevel = eValuate.Trace.TraceLevel.DETAIL;
							}
							else if(traceLevel.equals("DEVELOPER"))
							{
								appContext.ai.traceLevel = eValuate.Trace.TraceLevel.DEVELOPER_DEBUG;
							}

							EVConfigKeys configKeys = new EVConfigKeys();
							configKeys.clientID = client;
							configKeys.effectiveDate = effDate;
							configKeys.companyID = "";
							configKeys.challengeName = "";

							if(module.equals("RunScript"))
							{
								cfxScriptProcessor(request,response,appContext,configKeys,eiCur);
							}
							else if(module.equals("CheckScript"))
							{
								cfxScriptProcessorCheckScript(request,response,appContext,configKeys,eiCur);
							}
							else if(module.equals("Evaluator"))
							{
								cfxEvaluator(request,response,appContext,configKeys,eiCur);
							}
							else if(module.equals("DataManager"))
							{
								cfxDataManager(request,response,appContext,configKeys,eiCur);
							}
							else if(module.equals("Initiator"))
							{
								cfxInitiator(request,response,appContext,configKeys,eiCur);
							}
							else
							{
								throw new Exception("EvaluateCF: Module call not supported: "+module);
							}
						} catch(Exception e) {
							throw e;
						} finally {
							activeObjects.remove(EVAppSeqNo);
						}
					}
				} // application processing
		}
		catch(org.omg.CORBA.TRANSIENT e)
		{
			errorOccurred=true;
			exceptionMsg=e.toString();
			response.setVariable("ErrorText",exceptionMsg);
			response.setVariable("ErrorType","100");

			if(exceptionMsg.indexOf("Application already active") >= 0 ||
					exceptionMsg.indexOf("Appplication already active") >= 0  ||
					exceptionMsg.indexOf("Application is in transaction") >= 0  ||
					exceptionMsg.indexOf("Application is not active") >= 0  ||
					exceptionMsg.indexOf("Appplication is not active") >= 0 )
				errorOccurred=false; // do not want to flip over to alternate instance, these are informational msgs

			throw e;
		}
		catch(org.omg.CORBA.OBJECT_NOT_EXIST e)
		{
			errorOccurred=true;
			exceptionMsg=e.toString();
			response.setVariable("ErrorText",exceptionMsg);
			response.setVariable("ErrorType","101");

			if(exceptionMsg.indexOf("Application already active") >= 0  ||
					exceptionMsg.indexOf("Appplication already active") >= 0  ||
					exceptionMsg.indexOf("Application is in transaction") >= 0  ||
					exceptionMsg.indexOf("Application is not active")  >= 0 ||
					exceptionMsg.indexOf("Appplication is not active") >= 0 )
				errorOccurred=false; // do not want to flip over to alternate instance, these are informational msgs

			throw e;
		}
		catch(evCORBAException e)
		{
			String errText = e.Exceptions[0].text;
			response.setVariable("ErrorText",errText);
			if(errText.indexOf("Application already active") >= 0 || errText.indexOf("Appplication already active") >= 0 || errText.indexOf("Application is in transaction") >= 0  )
				response.setVariable("ErrorType","2");
			else   {
				response.setVariable("ErrorType","1");
				errorOccurred=true;
				exceptionMsg=e.toString();
			}

			if(errText.indexOf("Application already active") >= 0  ||
					errText.indexOf("Appplication already active") >= 0  ||
					errText.indexOf("Application is in transaction") >= 0  ||
					errText.indexOf("Application is not active") >= 0  ||
					errText.indexOf("Appplication is not active") >= 0 ||
					exceptionMsg.indexOf("IDL:eValuate/evCORBAException:") >= 0 // evaluate IDL errors should not failover, just report them
					)
				errorOccurred=false; // do not want to flip over to alternate instance, these are informational msgs

			throw new Exception(printEvaluateException(e));
		}
		catch(ModuleException e)
		{
			errorOccurred=true;
			exceptionMsg=e.toString();
			String err = "";
			err = "eValuate error: " + e.businessMessage + ":" + e.reason + ":" + e.sourceFile + ":" + e.method + ":" + e.lineNumber;
			response.setVariable("ErrorText",err);
			response.setVariable("ErrorType","3");

			if(exceptionMsg.indexOf("Application already active") >= 0  ||
					exceptionMsg.indexOf("Appplication already active") >= 0  ||
					exceptionMsg.indexOf("Application is in transaction") >= 0  ||
					exceptionMsg.indexOf("Application is not active") >= 0  ||
					exceptionMsg.indexOf("Appplication is not active") >= 0 )
				errorOccurred=false; // do not want to flip over to alternate instance, these are informational msgs

			throw new Exception(err);
		}
		catch(Exception e)
		{
			errorOccurred=true;
			exceptionMsg=e.toString();
			response.setVariable("ErrorText",exceptionMsg);
			response.setVariable("ErrorType","-1");

			if(exceptionMsg.indexOf("Application already active") >= 0  ||
					exceptionMsg.indexOf("Appplication already active") >= 0  ||
					exceptionMsg.indexOf("Application is in transaction") >= 0  ||
					exceptionMsg.indexOf("Application is not active") >= 0  ||
					exceptionMsg.indexOf("Appplication is not active") >= 0 )
				errorOccurred=false; // do not want to flip over to alternate instance, these are informational msgs

			throw e;
		}
		finally {
			--conncurrentRequests;
			// Switch over to the other evaluate instance if we had an error on the current instance
			// if eiCur is not equal to ei then it means that two threads were in this code at the same time and
			// we have already switched over to the alternate or other instance. Or, that a previous call was in a trans
			// and it was pointing to a prev bad instance
			// and we don't want to switch back and forth

			/*For this appseqno we don't want to remove it from the appseqno table because it will be called one
         more time by act_callerror.cfm to call flush app. When flush app is called it will find it in the table and use
         the bad instance, get a second error, and then we can remove it. For trans that work correctly (no errors)
         the flush or end trans will remove the entry. If we did not do this then when the flush was called it would
         fail against the second instance and we would try to flip back to the pri incorrectly.
			 */

			String calledMethod = getCFAttribute(request,"METHOD");
			if (errorOccurred && (calledMethod.equals("FlushApp") || calledMethod.equals("EndTransaction")))
				getSetAppseqnoInstance(REMOVE,appseqno,null); // appseqno was set before the try block
			// if it was "" or "0" (new app) then it will not remove anything



			if (errorOccurred && ei!=null && eiCur!=null && eiCur==ei) {
				// evaluate is down so switch to alternate if we can
				if (ei==eiPri) {
					System.out.println(getDateTime()+"EvaluateCF: ERROR on current connection to evaluate (primary),  error: "+exceptionMsg);
					System.out.println(getDateTime()+"EvaluateCF: Outstanding transaction count: "+appseqnoTable.size()) ;
					eiPri.isAvailable=false;
					if (!eiAlt.isAvailable) {
						if (eiAlt.alternateDefined) {
							System.out.println(getDateTime()+"EvaluateCF: Switching to alternate but alternate is not currently available, trying to reinitialize alternate to see if it is now up");
							// try one more time to see if it has since come up
							eiAlt = new EvaluateInstance(INIProperties);
							eiAlt.initializeVariables(request,response,false); // false means initialize alt
						}
					}

					if (!eiAlt.isAvailable) {
						initialized=false; // next time thru it will try to reestablish connections to either evaluate
						System.out.println(getDateTime()+"EvaluateCF: Tried to switch from primary to alternate, but alternate instance is not availiable. Reset to retry primary on next call");
					}
					else {
						System.out.println(getDateTime()+"EvaluateCF: Successfully switched to alternate evaluate instance, subsequent calls will be redirected to alternate");
						ei=eiAlt;
					}
				}
				else    // error occurred on alternate so see if we can switch back to primary
					if (ei==eiAlt) {
						System.out.println(getDateTime()+"EvaluateCF: ERROR on current connection to evaluate (alternate),  error: "+exceptionMsg);
						System.out.println(getDateTime()+"EvaluateCF: Outstanding transaction count: "+appseqnoTable.size()) ;
						eiAlt.isAvailable=false;
						if (!eiPri.isAvailable) {
							System.out.println(getDateTime()+"EvaluateCF: Switching to primary but primary is not currently available, trying to reinitialize primary to see if it is now up");
							// try one more time to see if it has since come up
							eiPri = new EvaluateInstance(INIProperties);
							eiPri.initializeVariables(request,response,true); // true means initialize primary
						}
						if (!eiPri.isAvailable) {
							initialized=false; // next time thru it will try to reestablish connections to either evaluate
							System.out.println(getDateTime()+"EvaluateCF: tried to switch from alternate to primary, but primary instance is not availiable. Reset to retry primary on next call");
						}
						else {
							System.out.println(getDateTime()+"EvaluateCF: Successfully switched to primary evaluate instance, subsequent calls will be redirected to primary");
							ei=eiPri;
						}
					}

			} // errorOccurred
			else
				if (exceptionMsg.length() > 0)
					System.out.println(getDateTime()+"EvaluateCF: returning err to caller,  error: "+exceptionMsg);
			// otherwise don't switch to another evaluate because this was an inflight transaction that failed
			// because we switched over in mid-stream

		}  // finally
	}



	public boolean cfxInitiator(com.allaire.cfx.Request request, Response response, EVAppContext appContext, EVConfigKeys configKeys,EvaluateInstance eiCur)
			throws evCORBAException,ModuleException,Exception
	{
		String method = getCFAttribute(request,"METHOD");

		if(method.equals("InitializeApp"))
		{
			cfxInitiatorInitializeApp(request,response,appContext,configKeys,eiCur);
		}
		else
			if(method.equals("InitializeOrigenateApp"))
			{
				cfxInitiatorInitializeOrigenateApp(request,response,appContext,configKeys,eiCur);
			}
			else if(method.equals("FlushApp"))
			{
				if (debugon) System.out.println(getDateTime()+"EvaluateCF: flushapp");
				cfxInitiatorFlushApp(request,response,appContext,configKeys,eiCur);
			}
			else if(method.equals("EndTransaction"))
			{
				if (debugon) System.out.println(getDateTime()+"EvaluateCF: endtrans");
				cfxInitiatorEndTrans(request,response,appContext,configKeys,eiCur);
			}
			else if(method.equals("StartTransaction"))
			{
				cfxInitiatorStartTrans(request,response,appContext,configKeys,eiCur);
			}
			else if(method.equals("IsAppOpen"))
			{
				cfxInitiatorIsAppOpen(request,response,appContext,configKeys,eiCur);
			}
			else
			{
				throw new Exception("EvaluateCF: Method call not supported: "+method);
			}
		return true;
	}
	public boolean cfxInitiatorInitializeApp(com.allaire.cfx.Request request, Response  response,EVAppContext appContext, EVConfigKeys configKeys,EvaluateInstance eiCur)
			throws evCORBAException,ModuleException,Exception
	{
		if(request.debug())
			response.writeDebug("-->cfxInitiatorInitializeApp<br>");
		String tableset = "";
		String[] changedTables = new String[0];

		String effDate = getCFAttribute(request,"EFFDATE");
		String [] effDateStr = effDate.split(" ");;
		int numRetry = 0;
		DMAppDetail app = new DMAppDetail();
		app.EVAppSeqNo = 0;
		app.EVAppNo = 0;
		app.clientID = configKeys.clientID;
		app.iterationNo = 1;
		app.resultID = 0;
		app.fesAppID = "0";
		app.fesID="hi there";
		app.scriptID="MainEval";
		app.responseID = "Not Null";
		app.batchName = "Not Null";
		app.effDate = effDateStr[0];
		app.effTime = effDateStr[1];
		app.iterationCopy = " ";
		app.costCenter = "Not Null";
		app.subCostCenter = "Not Null";
		app.userID = "Not Null";
		app.companyID = "Not Null";
		app.challengeName=" ";
		if (request.attributeExists("FESAPPID"))
			app.fesAppID = request.getAttribute("FESAPPID");

		String iteration = "1";
		if (request.attributeExists("ITERATION"))
		{
			iteration = request.getAttribute("ITERATION");
			Integer iIteration = Integer.valueOf(iteration);
			app.iterationNo = (short) iIteration.intValue();
		}

		String Evappno="0";
		if(request.attributeExists("EVAPPNO"))
		{
			Evappno = request.getAttribute("EVAPPNO");
		}
		Integer iEvAppNo = Integer.valueOf(Evappno);
		app.EVAppNo = iEvAppNo.intValue();

		// go find the appseqno for the this evappno
		//

		if (app.EVAppNo != 0)
		{
			tableset = getCFAttribute(request,"TABLESET");
			if (request.attributeExists("QUERY"))
			{
				Query data = request.getQuery();
				int nNumRows = data.getRowCount();
				response.writeDebug("Number of Rows"+nNumRows);
				changedTables = new String[nNumRows];
				for(int row=0;row < nNumRows;row++)
				{
					String tablex = data.getData((row+1),1);
					response.writeDebug("Row: " + tablex);
					changedTables[row] = tablex;
				}

			}
			EVAppKeySet appKeySet = new EVAppKeySet();
			EVAppKeys appKeys = new EVAppKeys();
			appKeySet.appNo       = app.EVAppNo;
			appKeySet.iterationNo = app.iterationNo;
			appKeySet.resultID    = app.resultID = 0;
			appKeySet.clientID = configKeys.clientID;

			if(request.debug())
			{
				response.writeDebug("Looking for old app<br>");
				response.writeDebug("EVAPPNO= " + Evappno + "<br>");
				response.writeDebug("ITERATION = " + iteration + "<br>");
			}

			try{
				while(numRetry < 3)
				{
					try
					{
						appKeys = eiCur.dm.getEvaluateAppSeqNo(appKeySet);
						break;
					}
					catch(org.omg.CORBA.COMM_FAILURE e)
					{
						if(request.debug())
							response.writeDebug("COMM Failure With minor code: "+e.minor);
						System.out.println(getDateTime()+"InitiatorInitializeApp getEvaluateAppSeqNo COMM Failure With minor code: "+e.minor + " retrying times: " +numRetry);
						try {Thread.sleep(1000);} catch (Exception ex) {} 			//Pausing for a second before retrying again
						if(numRetry == 2)
							throw e;
						else
							numRetry++;
					}
				}
			}
			catch(evCORBAException e)
			{
			}
			catch(Exception e)
			{
				throw e;
			}
			app.EVAppSeqNo = appKeys.EVAppSeqNo;
		}
		DMAppDetailHolder a = new DMAppDetailHolder(app);
		response.setVariable("EVAPPSEQNO",String.valueOf(a.value.EVAppSeqNo));
		response.setVariable("EVAPPNO",String.valueOf(a.value.EVAppNo));

		boolean newapp=String.valueOf(a.value.EVAppSeqNo).equals("0");
		numRetry = 0;

		while(numRetry < 3)
		{
			try
			{
				eiCur.dm.initEvaluateApp(a,changedTables,tableset);
				break;		//breaking out since there was a successful call
			}
			catch(org.omg.CORBA.COMM_FAILURE e)
			{
				if(request.debug())
					response.writeDebug("COMM Failure With minor code: "+e.minor);
				System.out.println(getDateTime()+"InitiatorInitializeApp COMM Failure With minor code: "+e.minor + " retrying times: " +numRetry);
				try {Thread.sleep(1000);} catch (Exception ex) {} 			//Pausing for a second before retrying again
				if(numRetry == 2)
					throw e;
				else
					numRetry++;
			}

		}

		if (newapp) {  // need to indicate that this newly created app is associated with this instance
			if (debugon) System.out.println(getDateTime()+"EvaluateCF: new app created, adding to table");
			getSetAppseqnoInstance(PUT,String.valueOf(a.value.EVAppSeqNo),eiCur);
		}

		response.setVariable("EVAPPSEQNO",String.valueOf(a.value.EVAppSeqNo));
		response.setVariable("EVAPPNO",String.valueOf(a.value.EVAppNo));

		if(request.debug())
			response.writeDebug("<--cfxInitiatorInitializeApp<br>");

		return true;
	}



	public boolean cfxInitiatorInitializeOrigenateApp(com.allaire.cfx.Request request, Response  response,EVAppContext appContext, EVConfigKeys configKeys,EvaluateInstance eiCur)
			throws evCORBAException,ModuleException,Exception
	{
		if(request.debug())
			response.writeDebug("-->cfxInitiatorInitializeOrigenateApp<br>");
		String tableset = "";

		String effDate = getCFAttribute(request,"EFFDATE");
		String [] effDateStr = effDate.split(" ");;
		int numRetry = 0;
		String[] changedTables = new String[0];
		DMAppDetail app = new DMAppDetail();
		app.EVAppSeqNo = 0;
		app.EVAppNo = 0;
		app.clientID = configKeys.clientID;
		app.iterationNo = 1;
		app.resultID = 0;
		app.fesAppID = "0";
		app.fesID="hi there";
		app.scriptID="MainEval";
		app.responseID = "Not Null";
		app.batchName = "Not Null";
		app.effDate = effDateStr[0];
		app.effTime = effDateStr[1];
		app.iterationCopy = " ";
		app.costCenter = "Not Null";
		app.subCostCenter = "Not Null";
		app.userID = "Not Null";
		app.companyID = "Not Null";
		app.challengeName=" ";
		if (request.attributeExists("FESAPPID"))
			app.fesAppID = request.getAttribute("FESAPPID");

		String iteration = "1";
		if (request.attributeExists("ITERATION"))
		{
			iteration = request.getAttribute("ITERATION");
			Integer iIteration = Integer.valueOf(iteration);
			app.iterationNo = (short) iIteration.intValue();
		}

		String Evappno="0";
		if(request.attributeExists("EVAPPNO"))
		{
			Evappno = request.getAttribute("EVAPPNO");
		}
		Integer iEvAppNo = Integer.valueOf(Evappno);
		app.EVAppNo = iEvAppNo.intValue();

		// go find the appseqno for the this evappno
		//
		if (app.EVAppNo != 0)
		{
			tableset = getCFAttribute(request,"TABLESET");
			if (request.attributeExists("QUERY"))
			{
				Query data = request.getQuery();
				int nNumRows = data.getRowCount();
				response.writeDebug("Number of Rows"+nNumRows);
				changedTables = new String[nNumRows];
				for(int row=0;row < nNumRows;row++)
				{
					String tablex = data.getData((row+1),1);
					response.writeDebug("Row: " + tablex);
					changedTables[row] = tablex;
				}

			}
			EVAppKeySet appKeySet = new EVAppKeySet();
			EVAppKeys appKeys = new EVAppKeys();
			appKeySet.appNo       = app.EVAppNo;
			appKeySet.iterationNo = app.iterationNo;
			appKeySet.resultID    = app.resultID = 0;
			appKeySet.clientID = configKeys.clientID;

			if(request.debug())
			{
				response.writeDebug("Looking for old app<br>");
				response.writeDebug("EVAPPNO= " + Evappno + "<br>");
				response.writeDebug("ITERATION = " + iteration + "<br>");
			}

			try
			{
				while(numRetry < 3)
				{
					try{
						appKeys = eiCur.dm.getEvaluateAppSeqNo(appKeySet);
						break;
					}
					catch(org.omg.CORBA.COMM_FAILURE e)
					{
						if(request.debug())
							response.writeDebug("COMM Failure With minor code: "+e.minor);
						System.out.println(getDateTime()+"InitiatorInitializeOrigenateApp getEvaluateAppSeqNo COMM Failure With minor code: "+e.minor + " retrying times: " +numRetry);
						try {Thread.sleep(1000);} catch (Exception ex) {} 			//Pausing for a second before retrying again
						if(numRetry == 2)
							throw e;
						else
							numRetry++;
					}
				}
			}
			catch(evCORBAException e)
			{
			}
			catch(Exception e)
			{
				throw e;
			}
			app.EVAppSeqNo = appKeys.EVAppSeqNo;
		}
		DMAppDetailHolder a = new DMAppDetailHolder(app);
		response.setVariable("EVAPPSEQNO",String.valueOf(a.value.EVAppSeqNo));
		response.setVariable("EVAPPNO",String.valueOf(a.value.EVAppNo));

		boolean newapp=String.valueOf(a.value.EVAppSeqNo).equals("0");
		numRetry = 0;

		while(numRetry < 3)
		{
			try
			{
				eiCur.dm.initEvaluateAppForOrigenate(a,changedTables,tableset);
				break;		//breaking out since there was a successful call
			}
			catch(org.omg.CORBA.COMM_FAILURE e)
			{
				if(request.debug())
					response.writeDebug("COMM Failure With minor code: "+e.minor);
				System.out.println(getDateTime()+"InitiatorInitializeOrigenateApp COMM Failure With minor code: "+e.minor + " retrying times: " +numRetry);
				try {Thread.sleep(1000);} catch (Exception ex) {} 			//Pausing for a second before retrying again
				if(numRetry == 2)
					throw e;
				else
					numRetry++;
			}

		}


		if (newapp) {  // need to indicate that this newly created app is associated with this instance
			if (debugon) System.out.println(getDateTime()+"EvaluateCF: new app created, adding to table");
			getSetAppseqnoInstance(PUT,String.valueOf(a.value.EVAppSeqNo),eiCur);
		}

		response.setVariable("EVAPPSEQNO",String.valueOf(a.value.EVAppSeqNo));
		response.setVariable("EVAPPNO",String.valueOf(a.value.EVAppNo));

		if(request.debug())
			response.writeDebug("<--cfxInitiatorInitializeOrigenateApp<br>");

		return true;
	}


	public boolean cfxInitiatorFlushApp(com.allaire.cfx.Request request, Response response,EVAppContext appContext, EVConfigKeys configKeys,EvaluateInstance eiCur)
			throws evCORBAException,ModuleException
	{
		if(request.debug())
			response.writeDebug("-->cfxInitiatorFlushApp <br>");

		// for build 135 onward
		int numRetry = 0;

		while(numRetry < 3)
		{
			try
			{
				eiCur.dm.completeEvaluateApp(appContext.ai.appKeys.EVAppSeqNo);

				getSetAppseqnoInstance(REMOVE,String.valueOf(appContext.ai.appKeys.EVAppSeqNo),null); // disassociate this appseqno from this instance
				break;		//breaking out since there was a successful call
			}
			catch(org.omg.CORBA.COMM_FAILURE e)
			{
				if(request.debug())
					response.writeDebug("COMM Failure With minor code: "+e.minor);
				System.out.println(getDateTime()+"Initiator Flush application COMM Failure With minor code: "+e.minor + " retrying times: " +numRetry);
				try {Thread.sleep(1000);} catch (Exception ex) {} 		//Pausing for a second before retrying again
				if(numRetry == 2)
					throw e;
				else
					numRetry++;
			}

		}

		// for pre 135
		//dm.flushCacheForApplication(appContext.ai.appKeys.EVAppSeqNo);
		if(request.debug())
			response.writeDebug("<--cfxInitiatorFlushApp <br>");
		return true;
	}

	public boolean cfxInitiatorEndTrans(com.allaire.cfx.Request request, Response response,EVAppContext appContext, EVConfigKeys configKeys,EvaluateInstance eiCur)
			throws evCORBAException,ModuleException
	{
		if(request.debug())
			response.writeDebug("-->cfxEndTransaction <br>");

		int numRetry = 0;

		while(numRetry < 3)
		{
			try
			{
				eiCur.dm.endTransaction(appContext.ai.appKeys.EVAppSeqNo);

				getSetAppseqnoInstance(REMOVE,String.valueOf(appContext.ai.appKeys.EVAppSeqNo),null); // disassociate this appseqno from this instance
				break;		//breaking out since there was a successful call
			}
			catch(org.omg.CORBA.COMM_FAILURE e)
			{
				if(request.debug())
					response.writeDebug("COMM Failure With minor code: "+e.minor);
				System.out.println(getDateTime()+"End Transaction COMM Failure With minor code: "+e.minor + " retrying times: " +numRetry);
				try {Thread.sleep(1000);} catch (Exception ex) {} 		//Pausing for a second before retrying again
				if(numRetry == 2)
					throw e;
				else
					numRetry++;
			}

		}

		if(request.debug())
			response.writeDebug("<--cfxEndTransaction <br>");
		return true;
	}

	public boolean cfxInitiatorStartTrans(com.allaire.cfx.Request request, Response response,EVAppContext appContext, EVConfigKeys configKeys,EvaluateInstance eiCur)
			throws evCORBAException,ModuleException
	{
		if(request.debug())
			response.writeDebug("-->cfxStartTransaction <br>");

		int numRetry = 0;

		while(numRetry < 3)
		{
			try
			{
				eiCur.dm.startTransaction(appContext.ai.appKeys.EVAppSeqNo);
				break;		//breaking out since there was a successful call
			}
			catch(org.omg.CORBA.COMM_FAILURE e)
			{
				if(request.debug())
					response.writeDebug("COMM Failure With minor code: "+e.minor);
				System.out.println(getDateTime()+"Start Transaction COMM Failure With minor code: "+e.minor + " retrying times: " +numRetry);
				try {Thread.sleep(1000);} catch (Exception ex) {} 		//Pausing for a second before retrying again
				if(numRetry == 2)
					throw e;
				else
					numRetry++;
			}

		}

		if(request.debug())
			response.writeDebug("<--cfxStartTransaction <br>");
		return true;
	}

	public boolean cfxInitiatorIsAppOpen(com.allaire.cfx.Request request, Response response,EVAppContext appContext, EVConfigKeys configKeys,EvaluateInstance eiCur)
			throws evCORBAException,ModuleException
	{
		if(request.debug())
			response.writeDebug("-->cfxInitiatorIsAppOpen <br>");

		boolean appOpen = false;
		int numRetry = 0;

		while(numRetry < 3)
		{
			try
			{
				appOpen = eiCur.dm.isEvaluateAppOpen(appContext.ai.appKeys.EVAppSeqNo);
				break;		//breaking out since there was a successful call
			}
			catch(org.omg.CORBA.COMM_FAILURE e)
			{
				if(request.debug())
					response.writeDebug("COMM Failure With minor code: "+e.minor);
				System.out.println(getDateTime()+"InitiatorIsAppOpen COMM Failure With minor code: "+e.minor + " retrying times: " +numRetry);
				try {Thread.sleep(1000);} catch (Exception ex) {} 		//Pausing for a second before retrying again
				if(numRetry == 2)
					throw e;
				else
					numRetry++;
			}

		}

		if(appOpen)
		{
			response.setVariable("OPEN","TRUE");
		}
		else
		{
			response.setVariable("OPEN","FALSE");
		}

		if(request.debug())
			response.writeDebug("<--cfxInitiatorIsAppOpen <br>");
		return true;
	}


	public boolean cfxDataManager(com.allaire.cfx.Request request, Response response,EVAppContext appContext, EVConfigKeys configKeys,EvaluateInstance eiCur)
			throws evCORBAException,Exception,ModuleException
	{
		String method = getCFAttribute(request,"METHOD");

		if(method.equals("SetTableSet"))
		{
			cfxDataManagerSetTableSet(request,response,appContext,configKeys,eiCur);
		}
		else if(method.equals("GetTableSet"))
		{
			cfxDataManagerGetTableSet(request,response,appContext,configKeys,eiCur);
		}
		else if(method.equals("DeleteTableSet"))
		{
			cfxDataManagerDeleteTableSet(request,response,appContext,configKeys,eiCur);
		}
		else
		{
			if(request.debug())
				response.writeDebug("cfxDataManager -- no method #"+method+"#<br>");
		}

		return true;
	}


	public boolean loadField(Response response,HashMap tables,Query data,String table,String column,String occur,String value,EvaluateInstance eiCur)
	{
		boolean newTable = false;
		//
		// get the table
		//
		HashMap rows;
		Integer tID =  (java.lang.Integer)eiCur.table_id.get(table);
		if(tID == null)
		{
			response.writeDebug("Error Table " + table + " not found <br>");
		}
		else
		{
			if(tables.containsKey(tID))
			{
				rows= (java.util.HashMap) tables.get(tID);
			}
			else
			{
				newTable = true;
				rows = new HashMap();
				tables.put(tID,rows);
			}
			//
			// get the row
			//
			HashMap row = new HashMap();
			if(rows.containsKey(occur))
			{
				row= (java.util.HashMap) rows.get(occur);
			}
			else
			{
				row = new HashMap();
				rows.put(occur,row);
			}
			//
			// get the field
			//
			OrbTSColumn2 field;
			Integer fID = (java.lang.Integer)eiCur.field_id.get(table + "_" + column);
			if(fID == null)
			{
				response.writeDebug("Error Field " + table + "_" + column + " not found <br>");
			}
			else
			{
				if(row.containsKey(fID))
				{
					field = (OrbTSColumn2) row.get(fID);
				}
				else
				{
					field = new OrbTSColumn2();
					field.fieldID =  fID.intValue();
					field.stringValue = value;
					field.dataType = eValuate.EVTypes.EVDataType.EV_STRING;
					field.empty = false;
					row.put(fID,field);
				}
			}
		}
		//response.writeDebug("<--loadField<br>");

		return newTable;
	}


	public boolean cfxDataManagerSetTableSet(com.allaire.cfx.Request request, Response response, EVAppContext appContext, EVConfigKeys configKeys,EvaluateInstance eiCur)
			throws evCORBAException,ModuleException
	{
		if(request.debug())
			response.writeDebug("-->cfxDataManagerSetTableSet<br>");

		String tableSet = getCFAttribute(request,"TABLESET");
		String evappseqno = String.valueOf(appContext.ai.appKeys.EVAppSeqNo);

		String table,column,value,occur;
		int occurance;

		Query data = request.getQuery();

		int nNumCols = (data.getColumns()).length ;
		int nNumRows = data.getRowCount() ;

		int numRetry = 0;

		HashMap tables = new HashMap();
		int rows = data.getRowCount();
		int iTblCount = 0;
		boolean newTable;
		ArrayList oTbls = new ArrayList();
		for(int row=1;row<=rows;row++)
		{
			String tablex = data.getData(row,1);
			String columnx = data.getData(row,2);
			value = data.getData(row,3);
			occur = data.getData(row,4);
			table = tablex.toUpperCase();
			column = columnx.toUpperCase();
			if(request.debug())
				response.writeDebug("Row: " + table + column + occur + value + "<br>");
			newTable = loadField(response,tables,data,table,column,occur,value,eiCur);
			if(newTable)
			{
				if(request.debug())
					response.writeDebug("-->Table : " + iTblCount + " : " );
				Integer val = (java.lang.Integer)eiCur.table_id.get(table);
				if(request.debug())
					response.writeDebug(" --Table : " + iTblCount + " : " + val);
				OrbTSTable2 oTbl = new OrbTSTable2();
				oTbl.tableID = val.intValue();
				oTbls.add(oTbl);
				if(request.debug())
					response.writeDebug("<--Table : " + iTblCount + " : " + val +"<br>");
				iTblCount++;
			}
		}
		OrbTSTable2 oTS[] = new OrbTSTable2[oTbls.size()];
		for(int j=0;j<iTblCount;j++)
		{
			oTS[j] = (OrbTSTable2) oTbls.get(j);
			Integer tblID = Integer.valueOf(oTS[j].tableID);
			String tablename = (String) eiCur.id_table.get(tblID);
			HashMap tbl = (HashMap) tables.get(tblID);
			Collection rws = tbl.values();
			Iterator iRows = rws.iterator();
			oTS[j].rows = new OrbTSColumn2[rws.size()][];

			int iRowCount = 0;
			while(iRows.hasNext())
			{
				// add each field
				int iColCount = 0;
				HashMap row = (HashMap) iRows.next();
				Collection flds = row.values();
				Iterator iFlds = flds.iterator();
				oTS[j].rows[iRowCount] = new OrbTSColumn2[row.size()+1];
				while(iFlds.hasNext())
				{
					oTS[j].rows[iRowCount][iColCount] = new OrbTSColumn2();
					oTS[j].rows[iRowCount][iColCount] = (OrbTSColumn2) iFlds.next();
					iColCount++;
				}
				//insert the evapseqno on each record
				oTS[j].rows[iRowCount][iColCount] = new OrbTSColumn2();
				Integer fID = (java.lang.Integer)eiCur.field_id.get(tablename + "_APPSEQNO");
				oTS[j].rows[iRowCount][iColCount].fieldID = fID.intValue();
				oTS[j].rows[iRowCount][iColCount].stringValue = evappseqno;
				oTS[j].rows[iRowCount][iColCount].dataType = eValuate.EVTypes.EVDataType.EV_STRING;
				oTS[j].rows[iRowCount][iColCount].empty = false;

				iRowCount++;
			}
		}


		while(numRetry < 3)
		{
			try
			{
				if(request.debug())
					response.writeDebug("<--Insert Into OrbTableSet : " + iTblCount + "<br>");
				eiCur.dm.setTableSet2(oTS,appContext);
				if(request.debug())
					response.writeDebug("<--cfxDataManagerSetTableSet<br>");
				break;		//breaking out since there was a successful call
			}
			catch(org.omg.CORBA.COMM_FAILURE e)
			{
				if(request.debug())
					response.writeDebug("COMM Failure With minor code: "+e.minor);
				System.out.println(getDateTime()+"Set Tableset COMM Failure With minor code: "+e.minor + " retrying times: " +numRetry);
				try {Thread.sleep(1000);} catch (Exception ex) {} 		//Pausing for a second before retrying again
				if(numRetry == 2)
					throw e;
				else
					numRetry++;
			}

		}
		return true;
	}

	public boolean cfxDataManagerGetTableSet(com.allaire.cfx.Request request, Response response,EVAppContext appContext, EVConfigKeys configKeys,EvaluateInstance eiCur)
			throws evCORBAException, Exception,ModuleException
	{
		boolean retn = true;
		String tblSet = getCFAttribute(request,"TABLESET");
		String fieldId;

		if(request.debug())
			response.writeDebug("-->cfxDataManagerGetTableSet - tableset:"+tblSet+":<br>");
		String[] columns = {"name"};
		Query tableList = response.addQuery("TableList",columns);


		Query pTable;
		String[] pColumnNames;
		int k;
		int numRetry = 0;


		String tableName;
		OrbTSTable2[] orbData = new OrbTSTable2[0];
		try{
			while(numRetry < 3)
			{
				try
				{
					appContext.bureauID = "";
					orbData  = eiCur.dm.getTableSet2(tblSet,appContext);
					break;		//breaking out since there was a successful call	
				}
				catch(org.omg.CORBA.COMM_FAILURE e)
				{
					if(request.debug())
						response.writeDebug("COMM Failure With minor code: "+e.minor);
					System.out.println(getDateTime()+"Get Tableset COMM Failure With minor code: "+e.minor + " retrying times: " +numRetry);
					try {Thread.sleep(1000);} catch (Exception ex) {} 			//Pausing for a second before retrying again
					if(numRetry == 2)
						throw e;
					else
						numRetry++;
				}

			}
		}
		catch(Exception e){
			System.out.println(getDateTime()+e);
			e.printStackTrace();
			throw new Exception("Failed to get TableSet "+ tblSet);
		}
		OrbTSTable2[] tableSet = orbData;
		int numTables = tableSet.length;
		for( int tableCounter = 0; tableCounter < numTables; tableCounter++ )
		{
			int orbTableID = tableSet[ tableCounter ].tableID ;
			int numRows = tableSet[ tableCounter ].rows.length;
			if(numRows > 0)
			{
				Integer id = Integer.valueOf(orbTableID);
				tableName = (String) eiCur.id_table.get(id);
				k = tableList.addRow();
				tableList.setData(k,1,tableName);
				int numFields = tableSet[ tableCounter ].rows[0].length;
				String[] columnNames = new String[numFields];
				for( int fieldCounter = 0; fieldCounter < numFields; fieldCounter++ )
				{
					Integer _fid = Integer.valueOf(tableSet[ tableCounter ].rows[ 0 ][ fieldCounter ].fieldID);
					columnNames[fieldCounter] = (String) eiCur.id_shortfield.get(_fid);
				}
				Query Table = response.addQuery(tableName,columnNames);
				for( int rowCounter = 0; rowCounter < numRows; rowCounter++ )
				{
					numFields = tableSet[ tableCounter ].rows[ rowCounter ].length;
					k = Table.addRow();
					for( int fieldCounter = 0; fieldCounter < numFields; fieldCounter++ )
					{
						Table.setData(k,fieldCounter+1,tableSet[ tableCounter ].rows[ rowCounter ][ fieldCounter ].stringValue);
					}
				}
			}
		}
		if(request.debug())
			response.writeDebug("<--cfxDataManagerGetTableSet - tableset:"+tblSet+":<br>");

		return retn;
	}

	public boolean cfxDataManagerDeleteTableSet(com.allaire.cfx.Request request, Response response, EVAppContext appContext, EVConfigKeys configKeys,EvaluateInstance eiCur)
			throws evCORBAException,ModuleException
	{
		if(request.debug())
			response.writeDebug("-->cfxDataManagerDeleteTableSet<br>");

		String tableSet = getCFAttribute(request,"TABLESET");
		String evappseqno = String.valueOf(appContext.ai.appKeys.EVAppSeqNo);

		String table,column,value,occur;
		int occurance;

		Query data = request.getQuery();

		int nNumCols = (data.getColumns()).length ;
		int nNumRows = data.getRowCount() ;

		HashMap tables = new HashMap();
		int rows = data.getRowCount();
		int iTblCount = 0;
		int numRetry = 0;
		boolean newTable;
		ArrayList oTbls = new ArrayList();
		for(int row=1;row<=rows;row++)
		{
			String tablex = data.getData(row,1);
			String columnx = data.getData(row,2);
			value = data.getData(row,3);
			occur = data.getData(row,4);
			table = tablex.toUpperCase();
			column = columnx.toUpperCase();
			if(request.debug())
				response.writeDebug("Row: " + table + column + occur + value + "<br>");
			newTable = loadField(response,tables,data,table,column,occur,value,eiCur);
			if(newTable)
			{
				if(request.debug())
					response.writeDebug("-->Table : " + iTblCount + " : " );
				Integer val = (java.lang.Integer)eiCur.table_id.get(table);
				if(request.debug())
					response.writeDebug(" --Table : " + iTblCount + " : " + val);
				OrbTSTable2 oTbl = new OrbTSTable2();
				oTbl.tableID = val.intValue();
				oTbls.add(oTbl);
				if(request.debug())
					response.writeDebug("<--Table : " + iTblCount + " : " + val +"<br>");
				iTblCount++;
			}
		}
		OrbTSTable2 oTS[] = new OrbTSTable2[oTbls.size()];
		for(int j=0;j<iTblCount;j++)
		{
			oTS[j] = (OrbTSTable2) oTbls.get(j);
			Integer tblID = Integer.valueOf(oTS[j].tableID);
			String tablename = (String) eiCur.id_table.get(tblID);
			HashMap tbl = (HashMap) tables.get(tblID);
			Collection rws = tbl.values();
			Iterator iRows = rws.iterator();
			oTS[j].rows = new OrbTSColumn2[rws.size()][];

			int iRowCount = 0;
			while(iRows.hasNext())
			{
				// add each field
				int iColCount = 0;
				HashMap row = (HashMap) iRows.next();
				Collection flds = row.values();
				Iterator iFlds = flds.iterator();
				oTS[j].rows[iRowCount] = new OrbTSColumn2[row.size()+1];
				while(iFlds.hasNext())
				{
					oTS[j].rows[iRowCount][iColCount] = new OrbTSColumn2();
					oTS[j].rows[iRowCount][iColCount] = (OrbTSColumn2) iFlds.next();
					iColCount++;
				}
				//insert the evapseqno on each record
				oTS[j].rows[iRowCount][iColCount] = new OrbTSColumn2();
				Integer fID = (java.lang.Integer)eiCur.field_id.get(tablename + "_APPSEQNO");
				oTS[j].rows[iRowCount][iColCount].fieldID = fID.intValue();
				oTS[j].rows[iRowCount][iColCount].stringValue = evappseqno;
				oTS[j].rows[iRowCount][iColCount].dataType = eValuate.EVTypes.EVDataType.EV_STRING;
				oTS[j].rows[iRowCount][iColCount].empty = false;

				iRowCount++;
			}
		}

		while(numRetry < 3)
		{
			try
			{
				if(request.debug())
					response.writeDebug("<--Delete from OrbTableSet : " + iTblCount + "<br>");
				eiCur.dm.deleteTableSet(oTS,appContext);
				if(request.debug())
					response.writeDebug("<--cfxDataManagerDeleteTableSet<br>");
				break;      //breaking out because there was a successfull call
			}
			catch(org.omg.CORBA.COMM_FAILURE e)
			{
				if(request.debug())
					response.writeDebug("COMM Failure With minor code: "+e.minor);
				System.out.println(getDateTime()+"Delete Tableset COMM Failure With minor code: "+e.minor + " retrying times: " +numRetry);
				try {Thread.sleep(1000);} catch (Exception ex) {} 			//Pausing for a second before retrying again
				if(numRetry == 2)
					throw e;
				else
					numRetry++;
			}

		}

		return true;
	}

	public boolean cfxEvaluator(com.allaire.cfx.Request request, Response response, EVAppContext appContext, EVConfigKeys configKeys,EvaluateInstance eiCur)
			throws evCORBAException,ModuleException
	{
		String method = getCFAttribute(request,"METHOD");

		if(method.equals("Eval"))
		{
			cfxEvaluatorEval(request,response,appContext,configKeys,eiCur);
		}
		else if(method.equals("InitializeApplication"))
		{
			cfxEvaluatorInitApp(request,response,appContext,configKeys,eiCur);
		}
		else if(method.equals("Initialize"))
		{
			cfxEvaluatorInitEntity(request,response,appContext,configKeys,eiCur);
		}
		else
		{
			if(request.debug())
				response.writeDebug("cfxEvaluator -- no method #"+method+"#<br>");
		}
		return true;
	}
	public boolean cfxEvaluatorEval(com.allaire.cfx.Request request, Response response,EVAppContext appContext, EVConfigKeys configKeys,EvaluateInstance eiCur)
			throws evCORBAException,ModuleException
	{
		String expression = getCFAttribute(request,"EXPRESSION");
		String saveIntermediates = getCFAttribute(request,"SAVEINTERMEDIATES");
		int numRetry = 0;
		while(numRetry < 3)
		{
			try
			{
				boolean bSave = (0 == saveIntermediates.compareToIgnoreCase("true"));
				DMDataElement val = eiCur.ev.evalRecursive(appContext,configKeys,expression,bSave,null);
				response.setVariable("RESULT",val.value);
				break;      //breaking out because there was a successfull call
			}
			catch(org.omg.CORBA.COMM_FAILURE e)
			{
				if(request.debug())
					response.writeDebug("COMM Failure With minor code: "+e.minor);
				System.out.println(getDateTime()+"Eval COMM Failure With minor code: "+e.minor + " retrying times: " +numRetry);
				try {Thread.sleep(1000);} catch (Exception ex) {} 			//Pausing for a second before retrying again
				if(numRetry == 2)
					throw e;
				else
					numRetry++;
			}

		}
		return true;
	}
	public boolean cfxEvaluatorInitApp(com.allaire.cfx.Request request,  Response response,EVAppContext appContext, EVConfigKeys configKeys,EvaluateInstance eiCur)
			throws evCORBAException,ModuleException
	{
		String expression = getCFAttribute(request,"EXPRESSION");
		int numRetry = 0;
		while(numRetry < 3)
		{
			try
			{
				eiCur.sc.Initialize(expression,configKeys,appContext);

				break;      //breaking out because there was a successfull call
			}
			catch(org.omg.CORBA.COMM_FAILURE e)
			{
				if(request.debug())
					response.writeDebug("COMM Failure With minor code: "+e.minor);
				System.out.println(getDateTime()+"Initialize Appllication COMM Failure With minor code: "+e.minor + " retrying times: " +numRetry);
				try {Thread.sleep(1000);} catch (Exception ex) {} 			//Pausing for a second before retrying again
				if(numRetry == 2)
					throw e;
				else
					numRetry++;
			}

		}
		return true;
	}
	public boolean cfxEvaluatorInitEntity(com.allaire.cfx.Request request,  Response response,EVAppContext appContext, EVConfigKeys configKeys,EvaluateInstance eiCur)
			throws evCORBAException,ModuleException
	{
		String expression = getCFAttribute(request,"EXPRESSION");
		String entityExpression = "";
		int numRetry = 0;
		while(numRetry < 3)
		{
			try
			{
				eiCur.sc.InitializeByAppentity(expression,entityExpression,configKeys,appContext);

				break;      //breaking out because there was a successfull call
			}
			catch(org.omg.CORBA.COMM_FAILURE e)
			{
				if(request.debug())
					response.writeDebug("COMM Failure With minor code: "+e.minor);
				System.out.println(getDateTime()+"Initialize AppEntity COMM Failure With minor code: "+e.minor + " retrying times: " +numRetry);
				try {Thread.sleep(1000);} catch (Exception ex) {} 			//Pausing for a second before retrying again
				if(numRetry == 2)
					throw e;
				else
					numRetry++;
			}

		}


		return true;
	}
	public boolean cfxScriptProcessor(com.allaire.cfx.Request request,  Response response,EVAppContext appContext, EVConfigKeys configKeys,EvaluateInstance eiCur)
			throws evCORBAException,ModuleException,Exception
	{

		cfxScriptProcessorRunScript(request,response,appContext,configKeys,eiCur);

		return true;
	}

	public boolean cfxScriptProcessorRunScript(com.allaire.cfx.Request request,  Response response,EVAppContext appContext, EVConfigKeys configKeys,EvaluateInstance eiCur)
			throws evCORBAException,ModuleException,Exception
	{
		boolean retryCall = false;
		int numRetry = 0;
		if(request.debug())
			response.writeDebug("-->cfxScriptProcessorRunScript<br>");
		String scriptname = getCFAttribute(request,"scriptname");
		SPParamElement[] params = new SPParamElement[0];
		if(request.debug())
			response.writeDebug("Trying to call Script Processor");

		while(numRetry < 3)
		{
			try
			{

				//if (debugon) System.out.println(getDateTime()+"Trying to call Script Processor");

				eiCur.sp.processApplication(scriptname,configKeys,appContext,params);


				//if (debugon) System.out.println(getDateTime()+"Call Script Processor successful");
				break;      //breaking out because there was a successfull call
			}
			catch(org.omg.CORBA.COMM_FAILURE e)
			{
				if(request.debug())
					response.writeDebug("COMM Failure With minor code: "+e.minor);
				System.out.println(getDateTime()+"ScriptProcessor COMM Failure With minor code: "+e.minor + " retrying times: " +numRetry);
				try {Thread.sleep(1000);} catch (Exception ex) {} 		//Pausing for a second before retrying again
				if(numRetry == 2)
					throw e;
				else
					numRetry++;
			}

		}
		if(request.debug())
			response.writeDebug("Call Script Processor successful");

		/*if(retryCall)
        {
            if(request.debug())
                response.writeDebug("Retrying to call Script Processor");
            //System.out.println(getDateTime()+"Retrying call to Script Processor");

            eiCur.sp.processApplication(scriptname,configKeys,appContext,params);

            if(request.debug())
                response.writeDebug("Call Script Processor successful");
            //System.out.println(getDateTime()+"Call Script Processor successful");
        }*/
		if(request.debug())
			response.writeDebug("<--cfxScriptProcessorRunScript<br>");
		return true;
	}

	public boolean cfxScriptProcessorCheckScript(com.allaire.cfx.Request request,  Response response,EVAppContext appContext, EVConfigKeys configKeys,EvaluateInstance eiCur)
			throws evCORBAException,ModuleException,Exception
	{
		boolean bExists = false;
		if(request.debug())
			response.writeDebug("-->cfxScriptProcessorCheckScript <br>");

		String scriptname = getCFAttribute(request,"scriptname");
		int numRetry = 0;
		while(numRetry < 3)
		{
			try
			{
				bExists = eiCur.sp.scriptExists(scriptname,configKeys,appContext);

				break;      //breaking out because there was a successfull call
			}
			catch(org.omg.CORBA.COMM_FAILURE e)
			{
				if(request.debug())
					response.writeDebug("COMM Failure With minor code: "+e.minor);
				System.out.println(getDateTime()+"ScriptProcessor Check script COMM Failure With minor code: "+e.minor + " retrying times: " +numRetry);
				try {Thread.sleep(1000);} catch (Exception ex) {} 			//Pausing for a second before retrying again
				if(numRetry == 2)
					throw e;
				else
					numRetry++;
			}

		}

		if(bExists)
		{
			response.setVariable("EXISTS","TRUE");
		}
		else
		{
			response.setVariable("EXISTS","FALSE");
		}

		if(request.debug())
			response.writeDebug("<--cfxScriptProcessorCheckScript <br>");

		return bExists;
	}

	public void cfxNotify( com.allaire.cfx.Request request, Response response,EvaluateInstance eiCur )
			throws evCORBAException,ModuleException
	{
		eValuate.EvaluateObjectID.ItemType evalType;
		String type = getCFAttribute(request, "TYPE" );

		if(type.equals("CHART"))
			evalType = eValuate.EvaluateObjectID.ItemType.Chart;
		else if(type.equals("BUREAUCALLINGSTRATEGY"))
			evalType = eValuate.EvaluateObjectID.ItemType.BureauCallingStrategy;
		else if(type.equals("BUREAUPROFILE"))
			evalType = eValuate.EvaluateObjectID.ItemType.BureauProfile;
		else if(type.equals("BUREAUZIPCODEGROUP"))
			evalType = eValuate.EvaluateObjectID.ItemType.BureauZipCodeGroup;
		else if(type.equals("BUREAUSTATUS"))
			evalType = eValuate.EvaluateObjectID.ItemType.BureauStatus;
		else if(type.equals("BUREAUCOMPANYCONSTANT"))
			evalType = eValuate.EvaluateObjectID.ItemType.BureauCompanyConstant;
		else if(type.equals("BUREAUMEMBERNUMBER"))
			evalType = eValuate.EvaluateObjectID.ItemType.BureauClientMemberNumber;
		else if(type.equals("SCORECARD"))
			evalType = eValuate.EvaluateObjectID.ItemType.ScoreCard;
		else if(type.equals("DECISIONRULE"))
			evalType = eValuate.EvaluateObjectID.ItemType.DecisionRule;
		else if(type.equals("DECISIONRULELIST"))
			evalType = eValuate.EvaluateObjectID.ItemType.DecisionRuleList;
		else
			evalType = eValuate.EvaluateObjectID.ItemType.Undefined;

		eValuate.EVCache.CacheAction evalAction;
		String action = getCFAttribute(request, "ACTION" );
		if(action.equals("ADD"))
			evalAction = eValuate.EVCache.CacheAction.Add;
		else if(action.equals("DELETE"))
			evalAction = eValuate.EVCache.CacheAction.Delete;
		else
			evalAction = eValuate.EVCache.CacheAction.Modify;

		String ID = getCFAttribute(request,"ID");
		String clientID = getCFAttribute(request,"CLIENT");
		String effDate = getCFAttribute(request,"EFFDATE");

		if(request.debug())
		{
			response.writeDebug("TYPE = " + type + "<br>");
			response.writeDebug("ID = " + ID + "<br>");
			response.writeDebug("CLIENT = " + clientID + "<br>");
			response.writeDebug("EFFDATE = " + effDate + "<br>");
		}
		System.out.println(getDateTime()+"EvaluateCF cfxNotify() called BUT IGNORED, type = "+type+", action = "+action);
		// eiCur.dm.sendNotification(evalType,evalAction,ID,effDate,clientID);

	} // cfxNotify



	public String printEvaluateException(evCORBAException e)
	{
		String err = "";
		err = e.toString();
		int noOfDataElements = e.Exceptions.length;
		err += "\n*************************************************************************\n";
		err += "* evException information                                               *\n";
		err += "*************************************************************************\n";
		err += "No. of ERROR Elements = " + noOfDataElements + "\n";
		for (int i = 0; i < noOfDataElements; i++)
		{
			err += "Printing Contents of ERROR Element: " + (i+1) + "\n";
			err += "eventId = " + e.Exceptions[i].eventId + "\n";
			err += "processId = " + e.Exceptions[i].processId + "\n";
			err += "severity = " + e.Exceptions[i].severity + "\n";
			err += "text = " + e.Exceptions[i].text + "\n";
			err += "textId = " + e.Exceptions[i].textId + "\n";
			err += "moduleName = " + e.Exceptions[i].moduleName + "\n";
			err += "file = " + e.Exceptions[i].file + "\n";
			err += "method = " + e.Exceptions[i].method + "\n";
			err += "line = " + e.Exceptions[i].line + "\n";
			err += "time = " + e.Exceptions[i].time + "\n";
			err += "text1 = " + e.Exceptions[i].text1 + "\n";
			err += "text2 = " + e.Exceptions[i].text2 + "\n";
			err += "clientId = " + e.Exceptions[i].clientId + "\n";
			err += "appId = " + e.Exceptions[i].appId + "\n";
			err += "appEffDate = " + e.Exceptions[i].appEffDate + "\n";
			err += "appEntity = " + e.Exceptions[i].appEntity + "\n";
			err += "reqID = " + e.Exceptions[i].reqID + "\n";
			err += "reqTypeID = " + e.Exceptions[i].reqTypeID + "\n";
			err += "script = " + e.Exceptions[i].script + "\n";
			err += "entryPoint = " + e.Exceptions[i].entryPoint + "\n";
			if( i < noOfDataElements + 1 )
			{
				err += "--------------------------------------------------------------------------\n";
			}
		}
		err += "*************************************************************************\n";
		err += "* end of evException information                                        *\n";
		err += "*************************************************************************\n";
		return err;
	}

	// GL. INI FILE METHODS
	// GL. INI FILE METHODS
	// GL. INI FILE METHODS

	// retrieve property value - if not found, return default
	public String getINIVar(String key, String defaultValue) {
		return INIProperties.getProperty(key, defaultValue);
	}

	// retrieve property value - if not found, return null
	public String getINIVar(String key) {
		return INIProperties.getProperty(key);
	}

	public void readINIFile(String fileName) throws Exception {


		System.out.println(getDateTime() + "EvaluateCF reading ini file: " + fileName);
		BufferedReader iniFile = null; 	// inifile input stream

		String iniRecord = null, 	// inifile record
				section = null; 	// current inifile section name
		boolean done = false;

		// open file for input
		try {
			iniFile = new BufferedReader(new InputStreamReader(new
					FileInputStream(fileName)));
		}
		catch(FileNotFoundException e) { throw e; }


		INIProperties = new Properties();

		// initial read
		try {
			iniRecord = iniFile.readLine();
		}
		catch(IOException e) {
			done = true;
		}


		while (!done && iniRecord != null) {
			// if section header, capture section name
			if (iniRecord.startsWith("[")) {
				section = iniRecord.substring(1,
						iniRecord.lastIndexOf("]"));
			}
			// if not comment record AND record contains name=value parse it
			else if (!iniRecord.startsWith("#")) {
				int equalIndex = 0; 	// position of '=' within iniRecord
				equalIndex = iniRecord.indexOf("=");
				if (equalIndex > 0) {
					String keyname=iniRecord.substring(0, equalIndex).trim();
					String value=iniRecord.substring(equalIndex + 1);
					if (value.length()>0) {
						int commentIndex=value.indexOf("#");
						if (commentIndex>0) {
							value=value.substring(0,commentIndex);
						}
						value=value.trim();
						if (value.length()>0) {
							// add property to Properties object
							INIProperties.put(section+"."+keyname, value);
						}
					}
				}
			}

			try {
				iniRecord = iniFile.readLine();
			}
			catch(IOException e) {
				done = true;
			}
		} // while

		iniFile.close();

	} // readINIFile()


	// GL. END INI FILE METHODS


	// GL. INITIALIZE VARIABLES

	public synchronized void initializeInstances(com.allaire.cfx.Request request, Response response) throws Exception {

		initialized=false;
		ei=null;
		// initialize both the primary and alternate (backup) evaluate instances
		System.out.println(getDateTime()+"EvaluateCF: Connecting to primary instance of evaluate...");
		boolean primary=true;
		eiPri.initializeVariables(request,response,primary);
		System.out.println(getDateTime()+"EvaluateCF: Connecting to alternate instance of evaluate...");
		primary=false;
		eiAlt.initializeVariables(request,response,primary);
		// determine which instance should be the current one we should be talking to
		if (eiPri.isAvailable) {
			ei=eiPri;
			System.out.println(getDateTime()+"EvaluateCF: Current instance set to Primary");
		}

		if (ei==null && eiAlt.isAvailable) {
			ei=eiAlt;
			System.out.println(getDateTime()+"EvaluateCF: Current instance set to Alternate");
		}
		if (ei==null)
			System.out.println(getDateTime()+"EvaluateCF: Current instance set to NONE, No evaluate instances available");
		else
			initialized = true;
	}



	public String getDateTime(){
		Date curDate = new Date(System.currentTimeMillis());
		SimpleDateFormat timeFormatter= new SimpleDateFormat ("HH:mm:ss.SSS");
		SimpleDateFormat dateFormatter= new SimpleDateFormat ("yyyy/MM/dd");

		return(dateFormatter.format(curDate)+" "+timeFormatter.format(curDate)+"   ");
	}




} // end EvaluateCF class

