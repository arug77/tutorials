import java.util.*;
import java.io.*; 
import com.allaire.cfx.* ;

import java.text.SimpleDateFormat;

import org.omg.CORBA.*;
import org.omg.CosNaming.*;

import eValuate.*;
import eValuate.DM.*;


public class EvaluateInstance
{

public  org.omg.CORBA.ORB orb=null;
public  eValuate.DM.DataManager dm=null;
public  Evaluator ev=null;
public  ScriptProcessorFacade sp=null;
public  ScoreModuleFacade sc=null;
public  HashMap table_id;
public  HashMap id_table;
public  HashMap field_id;
public  HashMap id_field;
public  HashMap id_shortfield;
public Properties INIProperties=null;
public boolean isAvailable=false;
public boolean alternateDefined=true;

public EvaluateInstance(Properties INIProperties) {
   this.INIProperties = INIProperties;
}




public String getCFAttribute(com.allaire.cfx.Request request, String name)
{
    String value = request.getAttribute(name);
    if(value == null) value="";
    return value;
}

////////////////////////////////////////////////////////////////////////////////


    boolean InitializeModules(com.allaire.cfx.Request request, Response response,boolean primary)
        throws Exception
    {
       
       String prefix = "";
       if (!primary) prefix="alt_";

        if(request!=null && request.debug() && response!=null)
            response.writeDebug( "-->InitializeModules<BR>") ;

        boolean retn = true;

        String enviornment = new String();
        String version= new String();
        String concurrentapps= new String();

        if (request!=null && request.attributeExists("ENVIRONMENT"))
            enviornment = request.getAttribute("ENVIRONMENT");
        else
           if (INIProperties!=null) {
              enviornment = getINIVar("evaluate."+prefix+"environment","NA");
           }
           else
            enviornment = "NA";


           if (!primary) {
               if (enviornment.equals("NA")) {
                alternateDefined=false;
                throw new Exception("Alternate not defined");
               }
               else
                  alternateDefined=true; // continue on and try to connect to the alt instance
           }

        if (request!=null && request.attributeExists("VERSION"))
            version         = request.getAttribute("VERSION");
        else
           if (INIProperties!=null) {
              version =  getINIVar("evaluate."+prefix+"version","NA");
           }
           else
            version = "NA";

        if (request!=null && request.attributeExists("CONCURRENTAPPS"))
        {
            concurrentapps  = request.getAttribute("CONCURRENTAPPS");
            // maxConncurrentApps = Integer.parseInt(concurrentapps); not used
        }
        else
           if (INIProperties!=null) {
              concurrentapps =  getINIVar("evaluate."+prefix+"concurrentapps","0");
              // maxConncurrentApps = Integer.parseInt(concurrentapps); not used
           }

        try
        {
            String args[] = new String[0];

            //
            // settings for the NameService
            //
            String initialPort="900";
            String initialHost="localhost";
            if (request!=null && request.attributeExists("INITIALPORT")) {
            initialPort = request.getAttribute("INITIALPORT");
            }
            else
               if (INIProperties!=null) {
                  initialPort = getINIVar("evaluate."+prefix+"ini_port","900");
               }
            if (request!=null && request.attributeExists("INITIALHOST")) {
            initialHost = request.getAttribute("INITIALHOST");
            }
            else
               if (INIProperties!=null) {
                  initialHost = getINIVar("evaluate."+prefix+"ini_host","localhost");
               }

            System.out.println(getDateTime()+"EvaluateInstance: Connecting to: "+initialHost+"  "+initialPort+"  "+enviornment+"  "+version);

            java.util.Properties props = new java.util.Properties();
            props.put("org.omg.CORBA.ORBInitialPort", initialPort);
            props.put("org.omg.CORBA.ORBInitialHost", initialHost);

            // The Java ORB was having problems communicating large amounts of data to eValuate.
            // It had no problem recieving large chunks of data.  Turns out large transfers are chunked
            // in GIOP v1.2 (and v1.1).  GIOP v1.0 doesn't chunk.  Either of the following options address
            // the problem
            props.put("com.sun.CORBA.giop.ORBGIOPVersion", "1.0");
            //
            // this second one doesn't appear to work on my machine, have opted for the first
            //props.put("com.sun.CORBA.giop.ORBFragmentSize", "4096");

            orb=org.omg.CORBA.ORB.init(args,props);

        }catch(Exception e){
            System.out.println(getDateTime()+e);
            e.printStackTrace();
            throw e;
        }

        try
        {
            org.omg.CORBA.Object objRef = orb.resolve_initial_references("NameService");
            NamingContext ncRef = NamingContextHelper.narrow(objRef);

            String envString = "-"+enviornment+"-"+version;
            String module = "datamanager" + envString;
            NameComponent nc = new NameComponent(module, "");
            NameComponent path[] = {nc};
            try {
                dm = eValuate.DM.DataManagerHelper.narrow(ncRef.resolve(path));
            } catch( org.omg.CosNaming.NamingContextPackage.NotFound ex ) {
                if(request!=null && request.debug() && response!=null)
                    response.writeDebug( "Cannot find DM: "+module );
                System.out.println(getDateTime()+ "Cannot find DM: "+module );
                throw ex;
            } catch( org.omg.CosNaming.NamingContextPackage.CannotProceed ex ) {
                if(request!=null && request.debug() && response!=null)
                    response.writeDebug( "Cannot proceed with resolving DM: "+module );
                System.out.println(getDateTime()+ "Cannot proceed with resolving DM: "+module );
                throw ex;
            } catch( org.omg.CosNaming.NamingContextPackage.InvalidName ex ) {
                if(request!=null && request.debug() && response!=null)
                    response.writeDebug( "Invalid name for DM: "+module );
                System.out.println(getDateTime()+ "Invalid name for DM: "+module );
                throw ex;
            }

            module="eval" + envString;
            nc.id = module;
            path[0] = nc;
            try {
                ev = EvaluatorHelper.narrow(ncRef.resolve(path));
            } catch( org.omg.CosNaming.NamingContextPackage.NotFound ex ) {
                if(request!=null && request.debug() && response!=null)
                    response.writeDebug( "Cannot find Evaluator: "+module );
                System.out.println(getDateTime()+ "Cannot find Evaluator: "+module );
                throw ex;
            } catch( org.omg.CosNaming.NamingContextPackage.CannotProceed ex ) {
                if(request!=null && request.debug() && response!=null)
                    response.writeDebug( "Cannot proceed with Evaluator: "+module );
                System.out.println(getDateTime()+ "Cannot proceed with resolving Evaluator: "+module );
                throw ex;
            } catch( org.omg.CosNaming.NamingContextPackage.InvalidName ex ) {
                if(request!=null && request.debug() && response!=null)
                    response.writeDebug( "Invalid name for Evaluator: "+module );
                System.out.println(getDateTime()+ "Invalid name for Evaluator: "+module );
                throw ex;
            }

            module="ScriptProcessor" + envString;
            nc.id = module;
            path[0] = nc;
            try {
                sp = ScriptProcessorFacadeHelper.narrow(ncRef.resolve(path));
            } catch( org.omg.CosNaming.NamingContextPackage.NotFound ex ) {
                if(request!=null && request.debug() && response!=null)
                    response.writeDebug( "Cannot find Script Processor: "+module );
                System.out.println(getDateTime()+ "Cannot find Script Processor: "+module );
                throw ex;
            } catch( org.omg.CosNaming.NamingContextPackage.CannotProceed ex ) {
                if(request!=null && request.debug() && response!=null)
                    response.writeDebug( "Cannot proceed with resolving Script Processor: "+module );
                System.out.println(getDateTime()+ "Cannot proceed with resolving Script Processor: "+module );
                throw ex;
            } catch( org.omg.CosNaming.NamingContextPackage.InvalidName ex ) {
                if(request!=null && request.debug() && response!=null)
                    response.writeDebug( "Invalid name for Script Processor: "+module );
                System.out.println(getDateTime()+ "Invalid name for Script Processor: "+module );
                throw ex;
            }

            module="ScoreFacade" + envString;
            nc.id = module;
            path[0] = nc;
            try {
                sc = ScoreModuleFacadeHelper.narrow(ncRef.resolve(path));
            } catch( org.omg.CosNaming.NamingContextPackage.NotFound ex ) {
                if(request!=null && request.debug() && response!=null)
                    response.writeDebug( "Cannot find Score: "+module );
                System.out.println(getDateTime()+ "Cannot find Score: "+module );
                throw ex;
            } catch( org.omg.CosNaming.NamingContextPackage.CannotProceed ex ) {
                if(request!=null && request.debug() && response!=null)
                    response.writeDebug( "Cannot proceed with resolving Score: "+module );
                System.out.println(getDateTime()+ "Cannot proceed with resolving Score: "+module );
                throw ex;
            } catch( org.omg.CosNaming.NamingContextPackage.InvalidName ex ) {
                if(request!=null && request.debug() && response!=null)
                    response.writeDebug( "Invalid name for Score: "+module );
                System.out.println(getDateTime()+ "Invalid name for Score: "+module );
                throw ex;
            }
        }catch(Exception e)
        {
            System.out.println(getDateTime()+e);
            e.printStackTrace();
            if (response!=null) response.write(e.toString());
            //return retn;
            throw e;
        }

        if(request!=null && request.debug() && response!=null)
            response.writeDebug( "<--InitializeModules<BR>") ;
        return retn;
    } // end initializeModules

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


    public boolean InitializeMaps(com.allaire.cfx.Request request,Response response,boolean primary)
    {
        if(request!=null && request.debug() && response!=null)
            response.writeDebug("--> InitializeMaps<br>");
        table_id = new HashMap();
        id_table = new HashMap();
        //create table maps
        OrbTableNameIDAssoc[] tables = new OrbTableNameIDAssoc[0];
        tables = dm.getTableNameIDAssociations ();
        if(request!=null && request.debug() && response!=null)
            response.writeDebug( tables.length + " tables <br>");
        for(int i=0; i< tables.length; i++)
        {
            Integer tblId = new Integer(tables[i].tableID);
            if(request!=null && request.debug() && response!=null)
                response.writeDebug(" Table : "+tables[i].tableName+":" + tblId + "<br>");
            id_table.put(tblId,tables[i].tableName);
            table_id.put(tables[i].tableName,tblId);
        }

        //create field maps
        field_id = new HashMap();
        id_field = new HashMap();
        id_shortfield = new HashMap();
        OrbColumnNameIDAssoc[] columns = new OrbColumnNameIDAssoc[0];
        columns = dm.getColumnNameIDAssociations();
        //if (response != null) response.writeDebug(columns.length + " columns <br>");
        for(int i=0; i< columns.length; i++)
        {
            Integer colId = new Integer(columns[i].ColumnID);
            String colString = columns[i].TableName+"_"+columns[i].ColumnName;
            if(request!=null && request.debug() && response!=null)
                response.writeDebug(" Column : "+colString+":" + colId + "<br>");
            id_field.put(colId,colString);
            field_id.put(colString,colId);
            id_shortfield.put(colId,columns[i].ColumnName);
        }
        if(request!=null && request.debug() && response!=null)
            response.writeDebug("<-- InitializeMaps<br>");
        return true;
    } // end initializeMaps






    // GL. INI FILE METHODS

    // retrieve property value - if not found, return default
    public String getINIVar(String key, String defaultValue) {
      return INIProperties.getProperty(key, defaultValue);
    }

    // retrieve property value - if not found, return null
    public String getINIVar(String key) {
      return INIProperties.getProperty(key);
    }


  // GL. INITIALIZE VARIABLES

public void initializeVariables(com.allaire.cfx.Request request, Response response,boolean primary) throws Exception {


           try {
              InitializeModules(request,response,primary);
              InitializeMaps(request,response,primary);
           }
           catch (Exception e) {
              if (primary)
                 System.out.println(getDateTime()+"EvaluateInstance: Failed to initialize primary evaluate instance, err="+e.toString());
              else {
                 if (alternateDefined)
                    System.out.println(getDateTime()+"EvaluateInstance: Failed to initialize alternate evaluate instance, err="+e.toString());
                 else
                    System.out.println(getDateTime()+"EvaluateInstance: Alternate instance not defined in INI file, ignored");
              }
               isAvailable=false;
              return;
           }
           isAvailable=true;
           if (primary)
              System.out.println(getDateTime()+"EvaluateInstance: Primary evaluate instance initialized");
           else
              System.out.println(getDateTime()+"EvaluateInstance: Alternate evaluate instance initialized");
           return;
  }



    public String getDateTime(){
        Date curDate = new Date(System.currentTimeMillis());
        SimpleDateFormat timeFormatter= new SimpleDateFormat ("HH:mm:ss.SSS");
        SimpleDateFormat dateFormatter= new SimpleDateFormat ("yyyy/MM/dd");
        
        return(dateFormatter.format(curDate)+" "+timeFormatter.format(curDate)+"   ");
    }


} // end EvaluateInstance

