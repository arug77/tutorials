

import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;
import java.io.*; // GL. for ini file reading
//import com.allaire.cfx.* ;
import java.text.SimpleDateFormat;

//import org.omg.CORBA.*;
//import org.omg.CosNaming.*;

import eValuate.*;

//import com.cmsinc.origenate.util.EvaluateInstance;
import com.cmsinc.origenate.util.IniFile;
public class EvaluateCalc
{
boolean initialized = false;
boolean appinitialized = false;
int counter=0;
private static final String DELIMITER = "|";
boolean debugon=false;

EvaluateInstance eiPri=null;  // primary eValuate instance
EvaluateInstance eiAlt=null;  // alternate instance in case primary goes down
EvaluateInstance ei=null; // instance we are currently talking to, either pri or alt
EvaluateInstance eiCur=null;

public IniFile ini = null;

/*  These are now maintained in the EvaluateInstance class ei.
ei points to the current evaluate instance that is up.
static org.omg.CORBA.ORB orb=null;
static eValuate.DM.DataManager dm=null;
static Evaluator ev=null;
static HashMap table_id;
static HashMap id_table;
static HashMap field_id;
static HashMap id_field;
static HashMap id_shortfield;
*/

EVAppContext appContext = null;
EVConfigKeys configKeys = null;
String initialClient="anylender";
OrbTSTable2 oTS[] = null;
OrbTSTable2 oTSDelete[] = null;

String environment = "";
String version = "";
int initialPort = 0;
String initialHost = "";
String effDate = "";
String traceLevel = "ENTRY_EXIT_POINT";
String client = "";

String fesAppId = "";
short iteration = 0;
String evAppSeqNo = "";

int conRequests = 0; // set but not used
AtomicInteger concurrentRequests = new AtomicInteger(0);
boolean errorOccurred=false;
String exceptionMsg="";

// GL. ini file reading
String ini_file_name="";
Properties INIProperties=null;

/******************************
*******************************/
public EvaluateCalc() {}

/*********************************
This method must be called from every call made from Oringenate
to set the environment for the next single thread call
**********************************/
private void initRequest(){
	eiCur=ei;
	conRequests = concurrentRequests.incrementAndGet();
	errorOccurred=false;
	exceptionMsg="";
}

/*********************************
**********************************/
public void SetIniFile(String iniFileName) throws Exception{
   try{
	  // at the beginning of every request that could be made from Origenate
	  initRequest();
	  //
	  readINIFile(iniFileName);
	  // create initial instances of EvaluateInstances, one for pri and alternate
	  initializeInstances();
	  appinitialized=false;
	}
	catch(Exception e){
		handleException(e);
	}
	finally{
		completeRequest();
	}
}

/*********************************
**********************************/
public synchronized void Initialize(
			String environment,
			String version,
			int initialPort,
			String initialHost,
			String effDate)
	throws Exception
	{
	try{
	  // at the beginning of every request that could be made from Origenate
	  initRequest();
	  //
	  initializeInstances();
	  if (!initialized)
		 throw new Exception("No evaluate instances available");

	  if (!appinitialized) {
		 // set the class properties with what was passed in
		this.environment = environment;
		this.version = version;
		this.initialPort = initialPort;
		this.initialHost = initialHost;
		this.effDate = effDate;
		// end setting

		eiCur=ei;
		short iteration = new Short("1").shortValue();
		InitializeApplication(client, effDate, traceLevel, "0", iteration, "0");
		appinitialized=true;
	  }

	}
	catch(Exception e){
		handleException(e);
	}
	finally{
		completeRequest();
	}
}

/*********************************
**********************************/
public void reset() throws Exception{
	try{
	  // at the beginning of every request that could be made from Origenate
	  initRequest();
	  //
		System.out.println(getDateTime()+"EvaluateCalc: Reset called");
		// try to initialize each instance, ei will be set to either the Pri or Alt instance. If both are availabe the the  Pri will be selected
		// this will also set the initialized variable if successful
		initializeInstances();
		appinitialized=false;
		this.evAppSeqNo = null;
	}
	catch(Exception e){
		handleException(e);
	}
	finally{
		completeRequest();
	}
}

/*********************************
**********************************/
public synchronized void close(String client, String effDate, String tracelevel, String fesAppId, short iteration, String _evAppSeqNo) throws Exception{
	try{
	  // at the beginning of every request that could be made from Origenate
	  initRequest();
	  //
	   System.out.println(getDateTime()+"EvaluateCalc: Close called");
		if(!initialized)
		{
		   // try to initialize each instance, ei will be set to either the Pri or Alt instance. If both are availabe the the  Pri will be selected
		   // this will also set the initialized variable if successful
		   initializeInstances();
		   if (!initialized)
			  throw new Exception("No evaluate instances available");

		}

		eiCur=ei;

		if (!appinitialized || (this.evAppSeqNo == null) || (!this.evAppSeqNo.equals(_evAppSeqNo))) {
			InitializeApplication(client, effDate, tracelevel, fesAppId, iteration, this.evAppSeqNo);
			appinitialized=true;
		}

		FlushApp(appContext,configKeys);
		appinitialized=false;
	}
	catch(Exception e){
		handleException(e);
	}
	finally{
		completeRequest();
	}
}

/*********************************
**********************************/
public synchronized String evaluateExpression(
			String expression,
			String client,
			boolean bSave,
			String tableList,
			String columnList,
			String valueList,
			String occList,
			String _evAppSeqNo
			)
	throws Exception{

	this.client = client;

	String tableSet = "";

	System.out.println(getDateTime()+"EvaluateCalc: evAppSeqNo=" + this.evAppSeqNo + "  _evppSeqNo=" + _evAppSeqNo);

	String retVal = "";
	try{
	    initRequest();
		if(!initialized) {
			// try to initialize each instance, ei will be set to either the Pri or Alt instance. If both are availabe the the  Pri will be selected
			// this will also set the initialized variable if successful
			initializeInstances();
			if (!initialized)
			   throw new Exception("No evaluate instances available");
			appinitialized=false;
		}

		eiCur=ei;

		System.out.println(getDateTime()+"EvaluateCalc: evAppSeqNo=" + this.evAppSeqNo + "  _evppSeqNo=" + _evAppSeqNo);
		if (!appinitialized || (this.evAppSeqNo == null) || (!this.evAppSeqNo.equals(_evAppSeqNo))) {
			InitializeApplication(client, effDate, traceLevel, fesAppId, iteration, _evAppSeqNo);
			appinitialized=true;
		}

		System.out.println(getDateTime()+"EvaluateCalc: Evaluating...  _evAppSeqNo=" + _evAppSeqNo);
		System.out.println(getDateTime()+"tableList: " + tableList);
		System.out.println(getDateTime()+"columnList: " + columnList);
		System.out.println(getDateTime()+"valueList: " + valueList);
		System.out.println(getDateTime()+"occList: " + occList);
		SetTableSet(tableSet, tableList, columnList, valueList, occList);
		retVal = Evaluate(expression,client,bSave);
		//DeleteTableSet();
		System.out.println(getDateTime()+"EvaluateCalc: Evaluating...done.  Value=" + retVal);

	}catch(Exception e){
		handleException(e);
	}
	finally{
		completeRequest();
	}
	return retVal;
}



/*********************************
**********************************/
	private DMAppDetail InitializeApplication(String client, String effDate, String tracelevel, String fesAppId, short iteration, String evAppSeqNo)
		throws evCORBAException,ModuleException,Exception
	{
		System.out.println("InitializeApplication with evAppSeqNo=" + evAppSeqNo);
		this.client = client;
		this.effDate = effDate;
		this.traceLevel = tracelevel;
		this.fesAppId = fesAppId;
		this.iteration = iteration;
		this.evAppSeqNo = evAppSeqNo;

//		if(request.debug())
//			response.writeDebug("-->cfxInitiatorInitializeApp<br>");
                System.out.println(getDateTime()+"EvaluateCalc: Initializing new app");
                counter++;
//		String client = getCFAttribute(request,"CLIENT");
//		String effDate = getCFAttribute(request,"EFFDATE");
		String EVAppSeqNo = "0";
		String EVAppEntity = "A1";
		String EVReqID = "0";
  		String EVReqTypeID = "1";
//		String traceLevel = getCFAttribute(request,"TRACELEVEL");
//		if(request.debug())
//		{
//                    response.writeDebug("Tag Count = " + counter + "<br>");
//		    response.writeDebug("CLIENT = " + client + "<br>");
//		    response.writeDebug("EFFDATE = " + effDate + "<br>");
//		    response.writeDebug("EVAPPSEQNO = " + EVAppSeqNo + "<br>");
//		    response.writeDebug("EVAPPENTITY = " + EVAppEntity + "<br>");
//		    response.writeDebug("EVReqID = " + EVReqID + "<br>");
//			response.writeDebug("EVReqTypeID = " + EVReqTypeID + "<br>");
//		    response.writeDebug("TRACELEVEL = " + traceLevel + "<br>");
//		}

		appContext = new EVAppContext();
		appContext.ai = new EVAppInfo();
		appContext.ai.appKeys = new EVAppKeys();
		appContext.ai.appKeys.EVAppSeqNo = Integer.parseInt(EVAppSeqNo);
		appContext.entityInfo = new EVEntityInfo();
		appContext.entityInfo.appEntity = EVAppEntity;
		appContext.entityInfo.reqID = Integer.parseInt(EVReqID);
		appContext.entityInfo.reqtypeID = Integer.parseInt(EVReqTypeID);
		appContext.bureauID="";
		appContext.ai.appLvl = eValuate.TraceDepth.Level.NONE;

		// set the trace level
		appContext.ai.traceLevel = eValuate.Trace.TraceLevel.NO_TRACING;
		if(traceLevel.equals("ENTRY_EXIT_POINT"))
		{
			appContext.ai.traceLevel = eValuate.Trace.TraceLevel.ENTRY_EXIT_POINT;
		}
		else if(traceLevel.equals("HIGH"))
		{
			appContext.ai.traceLevel = eValuate.Trace.TraceLevel.HIGH;
		}
		else if(traceLevel.equals("DETAIL"))
		{
			appContext.ai.traceLevel = eValuate.Trace.TraceLevel.DETAIL;
		}
		else if(traceLevel.equals("DEVELOPER"))
		{
			appContext.ai.traceLevel = eValuate.Trace.TraceLevel.DEVELOPER_DEBUG;
		}

		configKeys = new EVConfigKeys();
		configKeys.clientID = client;
		initialClient=client;
		configKeys.effectiveDate = effDate;
		configKeys.companyID = "";
		configKeys.challengeName = "";


		DMAppDetail app = new DMAppDetail();
		app.EVAppSeqNo = 0;
		app.EVAppNo = 0;
		app.clientID = client;
		app.iterationNo = 1;
		app.resultID = 0;
		app.fesID= "hi there";
		app.scriptID= "MainEval";
		app.responseID = "Not Null";
		app.batchName = "Not Null";
		app.effDate = "09/12/2025";
		app.effTime = "00:00";
		app.iterationCopy = " ";
		app.costCenter = "Not Null";
		app.subCostCenter = "Not Null";
		app.userID = "Not Null";
		app.companyID = "Not Null";
		app.challengeName=" ";
//		if (request.attributeExists("FESAPPID"))
//			app.fesAppID = request.getAttribute("FESAPPID");
		if (null != fesAppId){
			app.fesAppID = "0";
		}else{
			app.fesAppID = fesAppId;
		}


//		String iteration = "1";
//		if (request.attributeExists("ITERATION"))
		if (!(iteration > 0))
		{
			iteration = 1;
//			iteration = request.getAttribute("ITERATION");
//			Integer iIteration = new Integer(iteration);
		}
		app.iterationNo = iteration;

//		String Evappno="0";
//		if(request.attributeExists("EVAPPNO"))
//		{
//			Evappno = request.getAttribute("EVAPPNO");
//		}
//		Integer iEvAppNo = new Integer(Evappno);
		app.EVAppNo = Integer.parseInt(evAppSeqNo);
		app.EVAppSeqNo = Integer.parseInt(evAppSeqNo);

		// go find the appseqno for the this evappno
		//
//		if (app.EVAppSeqNo != 0)
//		{
//			EVAppKeySet appKeySet = new EVAppKeySet();
//			EVAppKeys appKeys = new EVAppKeys();
//			appKeySet.appNo       = app.EVAppSeqNo;
//			appKeySet.iterationNo = app.iterationNo;
//			appKeySet.resultID    = app.resultID = 0;
//			appKeySet.clientID = configKeys.clientID;
//
////  			if(request.debug())
////			{
////			    response.writeDebug("Looking for old app<br>");
////			    response.writeDebug("EVAPPNO= " + Evappno + "<br>");
////			    response.writeDebug("ITERATION = " + iteration + "<br>");
////			}
//			try
//			{
//				appKeys = eiCur.dm.getEvaluateAppSeqNo(appKeySet);
//				app.EVAppSeqNo = appKeys.EVAppSeqNo;
//			}
//			catch(evCORBAException e)
//			{
//			}
//			catch(Exception e)
//			{
//				throw e;
//			}
//		}
		DMAppDetailHolder a = new DMAppDetailHolder(app);
//
		String[] changedTables = new String[0];
		//eiCur.dm.initEvaluateApp(a, changedTables, "");
		eiCur.dm.initEvaluateAppForOrigenate(a, changedTables, "");

//		response.setVariable("EVAPPSEQNO",String.valueOf(a.value.EVAppSeqNo));
//		response.setVariable("EVAPPNO",String.valueOf(a.value.EVAppNo));

//		appContext.ai.appKeys.EVAppSeqNo = a.value.EVAppSeqNo;
		app.EVAppSeqNo = Integer.parseInt(evAppSeqNo);
		app.EVAppNo = app.EVAppSeqNo;
		appContext.ai.appKeys.EVAppSeqNo = app.EVAppSeqNo;

//		if(request.debug())
//			response.writeDebug("<--cfxInitiatorInitializeApp<br>");

		return app;
	}

/*********************************
**********************************/
	private boolean FlushApp(EVAppContext appContext, EVConfigKeys configKeys)
		throws evCORBAException,ModuleException
	{
//		if(request.debug())
//			response.writeDebug("-->cfxInitiatorFlushApp <br>");

		eiCur.dm.completeEvaluateApp(appContext.ai.appKeys.EVAppSeqNo);

//		if(request.debug())
//			response.writeDebug("<--cfxInitiatorFlushApp <br>");
		return true;
	}

/*********************************
**********************************/
	private boolean SetTableSet(String tableSet, String tableList, String columnList, String valueList, String occList)
		throws evCORBAException,ModuleException
	{
//		if(request.debug())
//			response.writeDebug("-->cfxDataManagerSetTableSet<br>");

//		String tableSet = getCFAttribute(request,"TABLESET");
		String evappseqno = String.valueOf(appContext.ai.appKeys.EVAppSeqNo);

		String table,column,value,occur;
//		int occurance;

//		Query data = request.getQuery();

//		int nNumCols = (data.getColumns()).length ;
//		int nNumRows = data.getRowCount() ;

		StringTokenizer stTables = new StringTokenizer(tableList,DELIMITER);
		StringTokenizer stColumn = new StringTokenizer(columnList,DELIMITER);
		StringTokenizer stValues = new StringTokenizer(valueList,DELIMITER);
		StringTokenizer stOccur = new StringTokenizer(occList,DELIMITER);

		HashMap tables = new HashMap();
		int rows = stTables.countTokens(); //data.getRowCount();
		int iTblCount = 0;
		boolean newTable;
		ArrayList oTbls = new ArrayList();
		ArrayList oTblsDelete = new ArrayList();
		for(int row=1;row<=rows;row++)
		{
			String tablex = stTables.nextToken(DELIMITER); //data.getData(row,1);
			String columnx = stColumn.nextToken(DELIMITER); //data.getData(row,2);
			value = stValues.nextToken(DELIMITER);  //data.getData(row,3);
			occur = stOccur.nextToken(DELIMITER);  //data.getData(row,4);
			table = tablex.toUpperCase();
			column = columnx.toUpperCase();
//			if(request.debug())
//				response.writeDebug("Row: " + table + column + occur + value + "<br>");
			newTable = loadField(tables,table,column,occur,value,eiCur);
			if(newTable)
			{
//				if(request.debug())
//					response.writeDebug("-->Table : " + iTblCount + " : " );
				Integer val = (java.lang.Integer) eiCur.table_id.get(table);
//				if(request.debug())
//					response.writeDebug(" --Table : " + iTblCount + " : " + val);
				OrbTSTable2 oTbl = new OrbTSTable2();
				OrbTSTable2 oTblDelete = new OrbTSTable2();
				oTbl.tableID = val.intValue();
				oTbls.add(oTbl);
				oTblDelete.tableID = val.intValue();
				oTblsDelete.add(oTblDelete);
//				if(request.debug())
//					response.writeDebug("<--Table : " + iTblCount + " : " + val +"<br>");
				iTblCount++;
			}
		}
		oTS= new OrbTSTable2[oTbls.size()];
		oTSDelete= new OrbTSTable2[oTbls.size()];
		for(int j=0;j<iTblCount;j++)
		{
			oTS[j] = (OrbTSTable2) oTbls.get(j);
			Integer tblID = new Integer(oTS[j].tableID);
			String tablename = (String) eiCur.id_table.get(tblID);
			HashMap tbl = (HashMap) tables.get(tblID);
			Collection rws = tbl.values();
			Iterator iRows = rws.iterator();
			oTS[j].rows = new OrbTSColumn2[rws.size()][];

			int iRowCount = 0;
			while(iRows.hasNext())
			{
	// add each field
				int iColCount = 0;
				HashMap row = (HashMap) iRows.next();
				Collection flds = row.values();
				Iterator iFlds = flds.iterator();
				oTS[j].rows[iRowCount] = new OrbTSColumn2[row.size()+1];
				while(iFlds.hasNext())
				{
					oTS[j].rows[iRowCount][iColCount] = new OrbTSColumn2();
					oTS[j].rows[iRowCount][iColCount] = (OrbTSColumn2) iFlds.next();
					iColCount++;
				}
	//insert the evapseqno on each record
				oTS[j].rows[iRowCount][iColCount] = new OrbTSColumn2();
				Integer fID = (java.lang.Integer) eiCur.field_id.get(tablename + "_APPSEQNO");
				oTS[j].rows[iRowCount][iColCount].fieldID = fID.intValue();
				oTS[j].rows[iRowCount][iColCount].stringValue = evappseqno;
				oTS[j].rows[iRowCount][iColCount].dataType = eValuate.EVTypes.EVDataType.EV_STRING;
				oTS[j].rows[iRowCount][iColCount].empty = false;

				iRowCount++;
			}

			// populate the delete template
//                      response.writeDebug("-->Add to Delete Template : " + iTblCount + "<br>");
			oTSDelete[j] = (OrbTSTable2) oTblsDelete.get(j);
//                      response.writeDebug("--Add to Delete Template : " + iTblCount + "<br>");
			oTSDelete[j].rows = new OrbTSColumn2[1][];
//                      response.writeDebug("--Add to Delete Template : " + iTblCount + "<br>");
			oTSDelete[j].rows[0] = new OrbTSColumn2[1];
//                      response.writeDebug("--Add to Delete Template : " + iTblCount + "<br>");
			oTSDelete[j].rows[0][0] = new OrbTSColumn2();
//                      response.writeDebug("--Add to Delete Template : " + iTblCount + "<br>");
			Integer fID = (java.lang.Integer) eiCur.field_id.get(tablename + "_APPSEQNO");
			oTSDelete[j].rows[0][0].fieldID = fID.intValue();
			oTSDelete[j].rows[0][0].stringValue = evappseqno;
			oTSDelete[j].rows[0][0].dataType = eValuate.EVTypes.EVDataType.EV_STRING;
			oTSDelete[j].rows[0][0].empty = false;
//                      response.writeDebug("<--Add to Delete Template : " + iTblCount + "<br>");

		}
//                if(request.debug())
//                        response.writeDebug("<--Insert Into OrbTableSet : " + iTblCount + "<br>");
		eiCur.dm.setTableSet2(oTS,appContext);
//		if(request.debug())
//			response.writeDebug("<--cfxDataManagerSetTableSet<br>");
		return true;
	}


/*********************************
**********************************/
	private boolean DeleteTableSet()
		throws evCORBAException,ModuleException
	{
//		if(request.debug())
//			response.writeDebug("-->cfxDataManagerDeleteTableSet<br>");

		eiCur.dm.deleteTableSet(oTSDelete,appContext);
//		if(request.debug())
//			response.writeDebug("<--cfxDataManagerDeleteTableSet<br>");
		return true;
	}

/*********************************
**********************************/
	public String Evaluate(String expression, String client, boolean bSave)
		throws evCORBAException,ModuleException
	{
		if (client.equals(""))
		{
			configKeys.clientID = initialClient;
		}
		else
		{
			configKeys.clientID = client;
		}
		DMDataElement val = eiCur.ev.evalRecursive(appContext,configKeys,expression,bSave,null);
		return val.value;
	}

/*********************************
**********************************/
	private boolean loadField(HashMap tables,String table,String column,String occur,String value,EvaluateInstance eiCur)
	{
		boolean newTable = false;
	//
	// get the table
	//
		HashMap rows;
		Integer tID =  (java.lang.Integer) eiCur.table_id.get(table);
		if(tID == null)
		{
//			response.writeDebug("Error Table " + table + " not found <br>");
		}
		else
		{
			if(tables.containsKey(tID))
			{
				rows= (java.util.HashMap) tables.get(tID);
			}
			else
			{
				newTable = true;
				rows = new HashMap();
				tables.put(tID,rows);
			}
		//
		// get the row
		//
			HashMap row = new HashMap();
			if(rows.containsKey(occur))
			{
				row= (java.util.HashMap) rows.get(occur);
			}
			else
			{
				row = new HashMap();
				rows.put(occur,row);
			}
		//
		// get the field
		//
			OrbTSColumn2 field;
			Integer fID = (java.lang.Integer) eiCur.field_id.get(table + "_" + column);
			if(fID == null)
			{
//				response.writeDebug("Error Field " + table + "_" + column + " not found <br>");
			}
			else
			{
				if(row.containsKey(fID))
				{
					field = (OrbTSColumn2) row.get(fID);
				}
				else
				{
					field = new OrbTSColumn2();
					field.fieldID =  fID.intValue();
					field.stringValue = value;
					field.dataType = eValuate.EVTypes.EVDataType.EV_STRING;
					field.empty = false;
					row.put(fID,field);
				}
			}
		}
		//response.writeDebug("<--loadField<br>");

		return newTable;
	}


/*********************************
**********************************/
	private String printEvaluateException(evCORBAException e)
	{
		String err = e.toString();
	    int noOfDataElements = e.Exceptions.length;
	    err += "\n*************************************************************************\n";
	    err += "* evException information                                               *\n";
	    err += "*************************************************************************\n";
	    err += "No. of ERROR Elements = " + noOfDataElements + "\n";
	    for (int i = 0; i < noOfDataElements; i++)
	    {
	      err += "Printing Contents of ERROR Element: " + (i+1) + "\n";
	      err += "eventId = " + e.Exceptions[i].eventId + "\n";
	      err += "processId = " + e.Exceptions[i].processId + "\n";
	      err += "severity = " + e.Exceptions[i].severity + "\n";
	      err += "text = " + e.Exceptions[i].text + "\n";
	      err += "textId = " + e.Exceptions[i].textId + "\n";
	      err += "moduleName = " + e.Exceptions[i].moduleName + "\n";
	      err += "file = " + e.Exceptions[i].file + "\n";
	      err += "method = " + e.Exceptions[i].method + "\n";
	      err += "line = " + e.Exceptions[i].line + "\n";
	      err += "time = " + e.Exceptions[i].time + "\n";
	      err += "text1 = " + e.Exceptions[i].text1 + "\n";
	      err += "text2 = " + e.Exceptions[i].text2 + "\n";
	      err += "clientId = " + e.Exceptions[i].clientId + "\n";
	      err += "appId = " + e.Exceptions[i].appId + "\n";
	      err += "eVAppNo = " + e.Exceptions[i].eVAppNo + "\n";
	      err += "appEffDate = " + e.Exceptions[i].appEffDate + "\n";
	      err += "appEntity = " + e.Exceptions[i].appEntity + "\n";
	      err += "reqID = " + e.Exceptions[i].reqID + "\n";
	      err += "reqTypeID = " + e.Exceptions[i].reqTypeID + "\n";
	      err += "script = " + e.Exceptions[i].script + "\n";
	      err += "entryPoint = " + e.Exceptions[i].entryPoint + "\n";
	      if( i < noOfDataElements + 1 )
	      {
	        err += "--------------------------------------------------------------------------\n";
	      }
	    }
	    err += "*************************************************************************\n";
	    err += "* end of evException information                                        *\n";
	    err += "*************************************************************************\n";
		return err;
	}


        // GL. INI FILE METHODS
        // GL. INI FILE METHODS
        // GL. INI FILE METHODS

/*********************************
        // retrieve property value - if not found, return default
**********************************/
//        private String getINIVar(String key, String defaultValue) {
//          return INIProperties.getProperty(key, defaultValue);
//        }

/*********************************
        // retrieve property value - if not found, return null
        private String getINIVar(String key) {
          return INIProperties.getProperty(key);
        }

/*********************************
**********************************/
	  private void readINIFile(String fileName) throws Exception {

	        System.out.println(getDateTime()+"EvaluateCalc reading ini file: "+fileName);

            BufferedReader iniFile = null; 	// inifile input stream

            String iniRecord = null, 	// inifile record
                 section = null; 	// current inifile section name
            boolean done = false;

            // open file for input
            try {
              FileInputStream fis = new FileInputStream(fileName);
              InputStreamReader isr = new InputStreamReader(fis);
              iniFile = new BufferedReader(isr);
            }
            catch(FileNotFoundException e) { throw e; }


            INIProperties = new Properties();

            // initial read
            try {
              iniRecord = iniFile.readLine();
            }
            catch(IOException e) {
              done = true;
            }


            while (!done && iniRecord != null) {
            // if section header, capture section name
              if (iniRecord.startsWith("[")) {
                section = iniRecord.substring(1,
                    iniRecord.lastIndexOf("]"));
              }
              // if not comment record AND record contains name=value parse it
              else if (!iniRecord.startsWith("#")) {
                int equalIndex = 0; 	// position of '=' within iniRecord
              equalIndex = iniRecord.indexOf("=");
              if (equalIndex > 0) {
                  String keyname=iniRecord.substring(0, equalIndex).trim();
                  String value=iniRecord.substring(equalIndex + 1);
                  if (value.length()>0) {
                      int commentIndex=value.indexOf("#");
                      if (commentIndex>0) {
                          value=value.substring(0,commentIndex);
                      }
                      value=value.trim();
                      if (value.length()>0) {
                          // add property to Properties object
                          INIProperties.put(section+"."+keyname, value);
                      }
                  }
              }
              }

              try {
              iniRecord = iniFile.readLine();
              }
              catch(IOException e) {
                done = true;
              }
            } // while

            iniFile.close();

          } // readINIFile()


      // GL. END INI FILE METHODS


      // GL. INITIALIZE VARIABLES


/*********************************
**********************************/
	private void initializeInstances() throws Exception {


		eiPri = new EvaluateInstance(INIProperties);
		eiAlt = new EvaluateInstance(INIProperties);

          initialized=false;
          ei=null;
           // initialize both the primary and alternate (backup) evaluate instances
          System.out.println(getDateTime()+"EvaluateCalc: Connecting to primary instance of evaluate...");
          boolean primary=true;
          eiPri.initializeVariables(null,null,primary);
          System.out.println(getDateTime()+"EvaluateCalc: Connecting to alternate instance of evaluate...");
          primary=false;
          eiAlt.initializeVariables(null,null,primary);
          // determine which instance should be the current one we should be talking to
          if (eiPri.isAvailable) {
              ei=eiPri;
              System.out.println(getDateTime()+"EvaluateCalc: Current instance set to Primary");
          }

          if (ei==null && eiAlt.isAvailable) {
            ei=eiAlt;
            System.out.println(getDateTime()+"EvaluateCalc: Current instance set to Alternate");
          }
          if (ei==null)
             System.out.println(getDateTime()+"EvaluateCalc: Current instance set to NONE, no evaluate instances available");
          else
            initialized = true;
  }



/*********************************
**********************************/
    private String getDateTime(){
        Date curDate = new Date(System.currentTimeMillis());
        SimpleDateFormat timeFormatter= new SimpleDateFormat ("HH:mm:ss.SSS");
        SimpleDateFormat dateFormatter= new SimpleDateFormat ("yyyy/MM/dd");

        return(dateFormatter.format(curDate)+" "+timeFormatter.format(curDate)+"   ");
    }


/*********************************
**********************************/
	private void handleException(Exception e) throws Exception{

		if (e instanceof org.omg.CORBA.TRANSIENT)
		{
				   errorOccurred=true;
				   exceptionMsg=e.toString();
//				   response.setVariable("ErrorText",exceptionMsg);
//				   response.setVariable("ErrorType","100");

				   if(exceptionMsg.indexOf("Application already active") >= 0  ||
					 exceptionMsg.indexOf("Appplication already active") >= 0  ||
					  exceptionMsg.indexOf("Application is in transaction") >= 0  ||
					  exceptionMsg.indexOf("Application is not active") >= 0  ||
					  exceptionMsg.indexOf("Appplication is not active") >= 0 )
					  errorOccurred=false; // do not want to flip over to alternate instance, these are informational msgs

				   throw (org.omg.CORBA.TRANSIENT) e;
		}
		else if (e instanceof org.omg.CORBA.OBJECT_NOT_EXIST)
		{
					errorOccurred=true;
					exceptionMsg=e.toString();
//					response.setVariable("ErrorText",exceptionMsg);
//					response.setVariable("ErrorType","101");

					if(exceptionMsg.indexOf("Application already active") >= 0  ||
					  exceptionMsg.indexOf("Appplication already active") >= 0  ||
					   exceptionMsg.indexOf("Application is in transaction") >= 0  ||
					   exceptionMsg.indexOf("Application is not active") >= 0  ||
					   exceptionMsg.indexOf("Appplication is not active") >= 0 )
					   errorOccurred=false; // do not want to flip over to alternate instance, these are informational msgs

					throw (org.omg.CORBA.OBJECT_NOT_EXIST) e;
		}
		else if (e instanceof evCORBAException)
		{
			   errorOccurred=true;
			   exceptionMsg=e.toString();
			String errText = ((evCORBAException)e).Exceptions[0].text;
//			response.setVariable("ErrorText",errText);
			if(errText.indexOf("Application already active") >= 0 || errText.indexOf("Appplication already active") >= 0){
//				response.setVariable("ErrorType","2");
			}else{
//				response.setVariable("ErrorType","1");
			}

					if(errText.indexOf("Application already active") >= 0  ||
					  errText.indexOf("Appplication already active") >= 0  ||
					   errText.indexOf("Application is in transaction") >= 0  ||
					   errText.indexOf("Application is not active") >= 0  ||
					   errText.indexOf("Appplication is not active") >= 0 ||
					   exceptionMsg.indexOf("IDL:eValuate/evCORBAException:") >= 0 // evaluate IDL errors should not failover, just report them
					   )
					   errorOccurred=false; // do not want to flip over to alternate instance, these are informational msgs

					throw new Exception(printEvaluateException((evCORBAException)e));
		}
		else if (e instanceof ModuleException)
		{
			   errorOccurred=true;
			   exceptionMsg=e.toString();

			String err = "eValuate error: " + ((ModuleException)e).businessMessage + ":" + ((ModuleException)e).reason + ":" + ((ModuleException)e).sourceFile + ":" + ((ModuleException)e).method + ":" + ((ModuleException)e).lineNumber;
//			response.setVariable("ErrorText",err);
//			response.setVariable("ErrorType","3");

					if(exceptionMsg.indexOf("Application already active") >= 0  ||
					  exceptionMsg.indexOf("Appplication already active") >= 0  ||
					   exceptionMsg.indexOf("Application is in transaction") >= 0  ||
					   exceptionMsg.indexOf("Application is not active") >= 0  ||
					   exceptionMsg.indexOf("Appplication is not active") >= 0 )
					   errorOccurred=false; // do not want to flip over to alternate instance, these are informational msgs

					throw new Exception(err);
		}
		else
		{
			errorOccurred=true;
			exceptionMsg=e.toString();
//			response.setVariable("ErrorText",exceptionMsg);
//			response.setVariable("ErrorType","-1");

					if(exceptionMsg.indexOf("Application already active") >= 0  ||
					  exceptionMsg.indexOf("Appplication already active") >= 0  ||
					   exceptionMsg.indexOf("Application is in transaction") >= 0  ||
					   exceptionMsg.indexOf("Application is not active") >= 0  ||
					   exceptionMsg.indexOf("Appplication is not active") >= 0 )
					   errorOccurred=false; // do not want to flip over to alternate instance, these are informational msgs

					throw e;
		}

	}

/*********************************
	Run at the completion of any request made to this instantiated class
	This must be run in the FINALLY block of the request made to properly handle Evaluate Instances
	for failover purposes.
**********************************/
	private void completeRequest() throws Exception{

           conRequests = concurrentRequests.decrementAndGet();
           // Switch over to the other evaluate instance if we had an error on the current instance
           // if eiCur is not equal to ei then it means that two threads were in this code at the same time and
           // we have already switched over the the alternate or other instance
           // and we don't want to switch back and forth
           if (errorOccurred && ei!=null && eiCur!=null && eiCur==ei) {
              // evaluate is down so switch to alternate if we can
              if (ei==eiPri) {
                 System.out.println(getDateTime()+"EvaluateCalc: ERROR on current connection to evaluate (primary),  error: "+exceptionMsg);
                 eiPri.isAvailable=false;
                 if (!eiAlt.isAvailable) {
                    if (eiAlt.alternateDefined) {
                       System.out.println(getDateTime()+"EvaluateCalc: Switching to alternate but alternate is not currently available, trying to reinitialize alternate to see if it is now up");
                       // try one more time to see if it has since come up
                       eiAlt = new EvaluateInstance(INIProperties);
                       eiAlt.initializeVariables(null,null,false); // false means initialize alt
                    }
                 }
                 if (!eiAlt.isAvailable) {
                    initialized=false; // next time thru it will try to reestablish connections to either evaluate
                    appinitialized=false;
                    System.out.println(getDateTime()+"EvaluateCalc: tried to switch from primary to alternate, but alternate instance is not availiable. Reset to retry primary on next call");
                 }
                 else {
                    System.out.println(getDateTime()+"EvaluateCalc: Successfully switched to alternate evaluate instance, subsequent calls will be redirected to alternate");
                    appinitialized=false;
                    ei=eiAlt;
                 }
              }
              else    // see if we can switch back to primary
                 if (ei==eiAlt) {
                    System.out.println(getDateTime()+"EvaluateCalc: ERROR on current connection to evaluate (alternate),  error: "+exceptionMsg);
                    eiAlt.isAvailable=false;
                    if (!eiPri.isAvailable) {
                       System.out.println(getDateTime()+"EvaluateCalc: Switching to primary but primary is not currently available, trying to reinitialize primary to see if it is now up");
                       // try one more time to see if it has since come up
                       eiPri = new EvaluateInstance(INIProperties);
                       eiPri.initializeVariables(null,null,true); // true means initialize primary
                    }
                    if (!eiPri.isAvailable) {
                       initialized=false; // next time thru it will try to reestablish connections to either evaluate
                       appinitialized=false;
                       System.out.println(getDateTime()+"EvaluateCalc: tried to switch from alternate to primary, but primary instance is not availiable. Reset to retry primary on next call");
                    }
                    else {
                       System.out.println(getDateTime()+"EvaluateCalc: Successfully switched to primary evaluate instance, subsequent calls will be redirected to primary");
                       ei=eiPri;
                       appinitialized=false;
                    }
                 }

           } // errorOccurred
           else
              if (exceptionMsg.length() > 0)
                 System.out.println(getDateTime()+"EvaluateCalc: returning err to caller,  error: "+exceptionMsg);
           // otherwise don't switch to another evaluate because this was an inflight transaction that failed
           // because we switched over in mid-stream
	}

} // end EvaluateCalc class

