package com.cmsinc.origenate.cfx;

import com.allaire.cfx.*;
import com.cmsinc.origenate.event.JournalEvents;
import com.cmsinc.origenate.util.IniFile;

/**
 * CallJournalEvents CustomTag calls JournalEvents to insert a journal event.
 *
 * Required parameters
 *
 *   REQUEST_ID:  Request ID of app
 *   JOURNAL_EVENT_ID: journal_event_id
 *	 JOURNAL_EVENT_TXT: journal_event_txt
 *	 CREATED_USER_ID: created_user_id
 *   INI_FILE: path and filename of origentate.ini file.
 *
 *       Note: origenate.ini
 *             [logs]
 *             journalevents_log_file  =  filename
 *
 *       If not present then will log to System.out (under CF goes to application.log)!
 *
 * Returns:
 *  error_msg
 *
 **/

public class CallJournalEvents implements CustomTag {

    static JournalEvents  journalEvents;

    public void processRequest(Request request,Response response) throws Exception {

       boolean errorOccurred, brokenPipe=false;

        do {

        try {
	    errorOccurred=false;
	    boolean error=false;
	    String errorMsg="";

            //
            // Get passed in parameters
            //
            String s_request_id = request.getAttribute("REQUEST_ID");
            String s_journal_event_id = request.getAttribute("JOURNAL_EVENT_ID");
	    String s_journal_event_txt = request.getAttribute("JOURNAL_EVENT_TXT");
	    String s_created_user_id = request.getAttribute("CREATED_USER_ID");
            String s_ini_file = request.getAttribute("INI_FILE");

            //
            // create journalEvents object if it has not been created yet
            //
            if (journalEvents!=null)  
			  journalEvents=null;
			
                try {
                    IniFile ini = new IniFile();
                    ini.readINIFile(s_ini_file);
                    String s_host = ini.getINIVar("database.host");
                    String s_port = ini.getINIVar("database.port");
                    String s_sid = ini.getINIVar("database.sid");
                    String s_user = ini.getINIVar("database.user");
                    String s_password = ini.getINIVar("database.password");
                    String s_log_file = ini.getINIVar("logs.journalevents_log_file");
                    String sTNSEntry = ini.getINIVar("database.TNSEntry", "");

                    journalEvents = new JournalEvents(s_host,s_sid,s_user,s_password,s_log_file,s_port,sTNSEntry);

                }
                catch (Exception e) {
                    journalEvents=null;
                    error=true;
                    errorMsg="Caught exception getting ini and/or JournalEvents object in "+this.getClass()+":"+e.toString();
                }
            

            if (!error) {
		try {
			int request_id = Integer.parseInt(s_request_id);
			int journal_event_id = Integer.parseInt(s_journal_event_id);
			journalEvents.addJournal(request_id,journal_event_id,s_journal_event_txt,s_created_user_id);
                }
                catch (NumberFormatException ne) {
			journalEvents = null;
                	error=true;
                    	errorMsg=ne.toString();
                }
		catch (Exception e) {
			journalEvents = null;
			error=true;
                        errorMsg=e.toString();
		}
	    }

            response.setVariable("journal_error_msg",errorMsg);
        }
        catch (Exception e) {
            	journalEvents = null;
        	String sErr=e.toString();

            	//  If a broken pipe occurs then try just one more time to see if we can re-establish the connection
            	if (!brokenPipe && sErr.indexOf("Broken pipe") > 0) {
                	brokenPipe=true;
                	errorOccurred=true;
            	}
            	else throw new Exception("Caught exception in "+this.getClass()+":"+e.toString());
        }
	}//end do
	while(errorOccurred);

    } // processRequest()

} // CallJournalEvents
