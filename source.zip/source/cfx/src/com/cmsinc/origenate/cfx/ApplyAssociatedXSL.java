/*
 * CallApplyXSL.java
 *
 * ApplyAssociatedXSL an associated stylesheet to an xml document
 * Created on November 21, 2002, 11:58 AM
 */

package com.cmsinc.origenate.cfx;
 
import com.allaire.cfx.*;
import com.cmsinc.origenate.xmldbt.*;

/**
 *
 **/

public class ApplyAssociatedXSL implements CustomTag {

    public void processRequest(Request request, Response response) throws Exception {
      ApplyXSL app_xsl = new ApplyXSL();
      //
      // Get passed in parameters
      //
      String s_xml = request.getAttribute("s_xml");
      s_xml = app_xsl.sApplyAssociatedXSL(s_xml);
      response.setVariable("s_xml",s_xml);
    }
}
