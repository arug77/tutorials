/****************************************************************************************************************
   Company: First American CMSI
    Product: Origenate
    Version: Beta
    Author: Akash Pandya
    Copyright (c) 2002. All rights reserved

    Description: Implementation of call to ApplicationStatusManager. This class is registered in ColdFusion Admin.
*******************************************************************************************************************/
package com.cmsinc.origenate.cfx;

import java.io.*;
import com.allaire.cfx.*;
import com.cmsinc.origenate.workflow.ApplicationStatusManager;
import com.cmsinc.origenate.util.IniFile;
import com.cmsinc.origenate.util.LogMsg;


public class CallApplicationStatusManager implements CustomTag {

  //Declare static variable to handle one reqeust at a time
   static ApplicationStatusManager  appStatusManager;
   private LogMsg log = new LogMsg();

  /************************************************************************/
  /*            Implement method of CustomTag interface                   */
  /************************************************************************/
  public void processRequest(Request request,Response response) throws Exception {

    boolean errorOccurred, brokenPipe=false;

    do {
     try {
            errorOccurred=false;
            boolean error=false;
            String errorMsg = "", errAppManager = "";

            // Create appStatusManager object if it has not been created yet
           if (appStatusManager != null)
              appStatusManager = null;



           //Get Ini File name
           String s_iniFile = request.getAttribute("INI_FILE");

            //Get ini file values for DB connection
            IniFile ini = new IniFile();
            ini.readINIFile(s_iniFile);
            String s_host = ini.getINIVar("database.host");
            String s_port = ini.getINIVar("database.port");
            String s_sid = ini.getINIVar("database.sid");
            String s_user = ini.getINIVar("database.user");
            String s_password = ini.getINIVar("database.password");
            String s_log_file = ini.getINIVar("logs.appstatus_log_file");


           // log.openLogFile(s_log_file);
          //  log.FmtAndLogMsg(" START Method Call : " + request.getAttribute("METHOD_CALL").trim().toUpperCase() + " Request Id  : " + request.getAttribute("REQUEST_ID") );

            //Create appStatusManager object
          //   appStatusManager = new ApplicationStatusManager(s_host,  s_sid,  s_user,  s_password, s_log_file, s_port);
            // 150165 - calling different constructor to use connection pool instead
             appStatusManager = new ApplicationStatusManager(s_log_file, s_iniFile);


           // Get name of method to be called
           String s_methodCall = request.getAttribute("METHOD_CALL").trim().toUpperCase();

           try {


             if (s_methodCall.equals("GETAPPSTATUS"))  { // Get Application Status

               //Get requested values
               String s_requestId = request.getAttribute("REQUEST_ID");
               String s_evaluatorId = request.getAttribute("EVALUATOR_ID");
               //Convert values to appropriate format
               long l_requestId = Long.parseLong(s_requestId);
               int  i_evaluatorId = Integer.parseInt(s_evaluatorId);
               //Get app Status ID
                int  ret_statusID = appStatusManager.getApplicationStatus(l_requestId, i_evaluatorId);
               //Set return value
               response.setVariable("ret_appStatusID", (Integer.valueOf(ret_statusID)).toString());

             } else  if (s_methodCall.equals("GETAPPSTATUS_STR"))  { // Get Application Status String

               //Get requested values
               String s_requestId = request.getAttribute("REQUEST_ID");
               String s_evaluatorId = request.getAttribute("EVALUATOR_ID");
               //Convert values to appropriate format
               long l_requestId = Long.parseLong(s_requestId);
               int  i_evaluatorId = Integer.parseInt(s_evaluatorId);
               //Get app Status ID
               String  ret_statusID  = appStatusManager.getApplicationStatusStr(l_requestId, i_evaluatorId);
               //Set return value
               response.setVariable("ret_appStatusStr", ret_statusID);

             } else if (s_methodCall.equals("GETACTIVITYSTATUS"))  { // Get Activity Status

               //Get requested values
               String s_requestId = request.getAttribute("REQUEST_ID");
               String s_taskGroupId = request.getAttribute("TASK_GROUP_ID");
               String s_activityId = request.getAttribute("ACTIVITY_ID");
               //Convert values to appropriate format
               long l_requestId = Long.parseLong(s_requestId);
               int  i_activityId = Integer.parseInt(s_activityId);
               //Get activity Status ID
                int  ret_statusID = appStatusManager.getActivityStatus(l_requestId, s_taskGroupId, i_activityId);
               //Set return value
               response.setVariable("ret_activityStatusID", (Integer.valueOf(ret_statusID)).toString());

             } else if (s_methodCall.equals("GETACTIVITYSTATUS_STR"))  { // Get Activity Status String

               //Get requested values
               String s_requestId = request.getAttribute("REQUEST_ID");
               String s_taskGroupId = request.getAttribute("TASK_GROUP_ID");
               String s_activityId = request.getAttribute("ACTIVITY_ID");
               //Convert values to appropriate format
               long l_requestId = Long.parseLong(s_requestId);
               int  i_activityId = Integer.parseInt(s_activityId);
               //Get activity Status String
                String  ret_statusID = appStatusManager.getActivityStatusStr(l_requestId, s_taskGroupId, i_activityId);
               //Set return value
               response.setVariable("ret_activityStatusStr", ret_statusID);


             } else if (s_methodCall.equals("GETDECSTATUS"))  { // Get Decision Status

              //Get requested values
              String s_requestId = request.getAttribute("REQUEST_ID");
              String s_evaluatorId = request.getAttribute("EVALUATOR_ID");
              //Convert values to appropriate format
              long l_requestId = Long.parseLong(s_requestId);
              int  i_evaluatorId = Integer.parseInt(s_evaluatorId);
              //Get decision Status ID
               int  ret_statusID = appStatusManager.getDecisionStatus(l_requestId, i_evaluatorId);
              //Set return value
              response.setVariable("ret_decStatusID", (Integer.valueOf(ret_statusID)).toString());


             } else if (s_methodCall.equals("GETDECSTATUS_STR"))  { // Get Decision Status String

            //Get requested values
            String s_requestId = request.getAttribute("REQUEST_ID");
            String s_evaluatorId = request.getAttribute("EVALUATOR_ID");
            //Convert values to appropriate format
            long l_requestId = Long.parseLong(s_requestId);
            int  i_evaluatorId = Integer.parseInt(s_evaluatorId);
            //Get decision Status String
             String  ret_statusID = appStatusManager.getDecisionStatusStr(l_requestId, i_evaluatorId);
            //Set return value
            response.setVariable("ret_decStatusStr", ret_statusID);


             } else  if (s_methodCall.equals("SETAPPSTATUS_FORCE"))  { // Set Application Status Forcefully

               //Get requested values
               String s_requestId = request.getAttribute("REQUEST_ID");
               String s_evaluatorId = request.getAttribute("EVALUATOR_ID");
               String s_appStatusId = request.getAttribute("APP_STATUS_ID");
               //Convert values to appropriate format
               long l_requestId = Long.parseLong(s_requestId);
               int  i_evaluatorId = Integer.parseInt(s_evaluatorId);
               int  i_appStatusId = Integer.parseInt(s_appStatusId);
               //Set app Status ID
               appStatusManager.setApplicationStatus(l_requestId, i_evaluatorId, i_appStatusId);


             } else if (s_methodCall.equals("SETACTIVITYSTATUS"))  { // Set Activity Status

              //Get requested values
              String s_requestId = request.getAttribute("REQUEST_ID");
              String s_taskGroupId = request.getAttribute("TASK_GROUP_ID");
              String s_activityId = request.getAttribute("ACTIVITY_ID");
              String s_activityStatusId = request.getAttribute("ACTIVITY_STATUS_ID");
              String s_userId = request.getAttribute("USER_ID");
              String s_reqestrequireId = request.getAttribute("REQUEST_REQUIRE_ID");
              //Convert values to appropriate format
              long l_requestId = Long.parseLong(s_requestId);
              int  i_activityId = Integer.parseInt(s_activityId);
              int  i_activityStatusId = Integer.parseInt(s_activityStatusId);
              int  i_reqestrequireId  = Integer.parseInt(s_reqestrequireId);
              //Set activity Status ID
              appStatusManager.setActivityStatus(l_requestId, s_taskGroupId, i_activityId, i_activityStatusId, s_userId, i_reqestrequireId);

             } else if (s_methodCall.equals("SETDECSTATUS"))  { // Set Decision Status

              //Get requested values
              String s_requestId = request.getAttribute("REQUEST_ID");
              String s_evaluatorId = request.getAttribute("EVALUATOR_ID");
              String s_decStatusId = request.getAttribute("DEC_STATUS_ID");
              //Convert values to appropriate format
              long l_requestId = Long.parseLong(s_requestId);
              int  i_evaluatorId = Integer.parseInt(s_evaluatorId);
              int  i_decStatusId = Integer.parseInt(s_decStatusId);
              //Set decision Status ID
              appStatusManager.setDecisionStatus(l_requestId, i_evaluatorId, i_decStatusId);

             } else if(s_methodCall.equals("SETACTCALCAPPSTATUS")) { //Calc, Set and Get activity and new App Status

              //Get requested values
              String s_requestId = request.getAttribute("REQUEST_ID");
              String s_taskGroupId = request.getAttribute("TASK_GROUP_ID");
              String s_activityId = request.getAttribute("ACTIVITY_ID");
              String s_activityStatusId = request.getAttribute("ACTIVITY_STATUS_ID");
              String s_userId = request.getAttribute("USER_ID");
              String s_reqestrequireId = request.getAttribute("REQUEST_REQUIRE_ID");
              //Convert values to appropriate format
              long l_requestId = Long.parseLong(s_requestId);
              int  i_activityId = Integer.parseInt(s_activityId);
              int  i_activityStatusId = Integer.parseInt(s_activityStatusId);
              int  i_reqestrequireId  = Integer.parseInt(s_reqestrequireId);
              //Set activity Status and calc, get new app status
              int  ret_statusID = appStatusManager.setActandCalcAppStatus(l_requestId, s_taskGroupId, i_activityId, i_activityStatusId, s_userId, i_reqestrequireId);
              //Set return value
              response.setVariable("ret_appStatusID", (Integer.valueOf(ret_statusID)).toString());

             } else if(s_methodCall.equals("CALCNEWAPPSTATUS")) { //Set and Get new App Status

               //Get requested values
               String s_requestId = request.getAttribute("REQUEST_ID");
               String s_evaluatorId = request.getAttribute("EVALUATOR_ID");
               //Convert values to appropriate format
               long l_requestId = Long.parseLong(s_requestId);
               int  i_evaluatorId = Integer.parseInt(s_evaluatorId);
               //Get new APP status ID
               int  ret_statusID = appStatusManager.calcNewApplicationStatus(l_requestId, i_evaluatorId);
               //Set return value
               response.setVariable("ret_appStatusID", (Integer.valueOf(ret_statusID)).toString());


             }  else if(s_methodCall.equals("CALCNEWAPPSTATUS_STR")) { //Set and Get new App Status String Code

               //Get requested values
               String s_requestId = request.getAttribute("REQUEST_ID");
               String s_evaluatorId = request.getAttribute("EVALUATOR_ID");
               //Convert values to appropriate format
               long l_requestId = Long.parseLong(s_requestId);
               int  i_evaluatorId = Integer.parseInt(s_evaluatorId);
               //Get new APP status ID
               String ret_statusID = appStatusManager.calcNewApplicationStatusStr(l_requestId, i_evaluatorId);
               //Set return value
               response.setVariable("ret_appStatusStr", ret_statusID);

             }  else if(s_methodCall.equals("GETSPECACTIVITY")) { // Get list of specific activities

               //Get requested values
               String s_requestId = request.getAttribute("REQUEST_ID");
               String s_actStatusId = request.getAttribute("ACTIVITY_STATUS_ID");
               String s_taskGroupId = request.getAttribute("TASK_GROUP_ID");
               //Convert values to appropriate format
               long l_requestId = Long.parseLong(s_requestId);
               int  i_actStatusId = Integer.parseInt(s_actStatusId);
               //Get new APP status ID
               int[]  i_ret_statusID = appStatusManager.getSpecificActivities(l_requestId, i_actStatusId, s_taskGroupId);
              //Convert to string array
               int i_idLen = i_ret_statusID.length;

               response.setVariable("ret_specActivityIDLength", (Integer.valueOf(i_idLen)).toString());
               String[] s_ret_statusID = new String[i_idLen];

               //Store into string array
               for (int i=0; i < i_idLen; i++) {
                 String ret_specActivityID = "";
                 s_ret_statusID[i] =  (Integer.valueOf(i_ret_statusID[i])).toString();
                 ret_specActivityID = "ret_specActivityID" + i;
                 //Set return value
                 response.setVariable(ret_specActivityID, (Integer.valueOf(s_ret_statusID[i])).toString());
               }

            }  else if(s_methodCall.equals("SETBOOKINGSTATUS")) { //Set booking status.

             //Get requested values
             String s_requestId = request.getAttribute("REQUEST_ID");
             String s_bookstatId = request.getAttribute("BOOKING_STATUS_ID");
             //Convert values to appropriate format
             long l_requestId = Long.parseLong(s_requestId);
             int i_book_status = Integer.parseInt(s_bookstatId);
             //Set booking status
             appStatusManager.setBookingStatus(l_requestId,i_book_status);

            }  else if(s_methodCall.equals("GETBOOKINGSTATUS")) { //Get booking status.

            //Get requested values
            String s_requestId = request.getAttribute("REQUEST_ID");
            //Convert values to appropriate format
            long l_requestId = Long.parseLong(s_requestId);
            //Set booking status
            int  ret_bookingstatusID = appStatusManager.getBookingStatus(l_requestId);
            //Set return value
            response.setVariable("ret_bookingStatusID", (Integer.valueOf(ret_bookingstatusID)).toString());

            }  else if(s_methodCall.equals("GETBOOKINGSTATUSSTR")) { //Get booking status.

            //Get requested values
            String s_requestId = request.getAttribute("REQUEST_ID");
            //Convert values to appropriate format
            long l_requestId = Long.parseLong(s_requestId);
            //Set booking status
            String  ret_bookingstatusStr =  appStatusManager.getBookingStatusStr(l_requestId);
            //Set return value
            response.setVariable("ret_bookingStatusStr", ret_bookingstatusStr);

            }
           }  catch (NumberFormatException ne) {
             errAppManager = appStatusManager.errMsg;
             appStatusManager = null;
             error=true;
             errorMsg= "NumberFormatException Error occured in creating ApplicationStatusManager object in " + getClass()+ " in case-" + s_methodCall  + " : "+ ne.toString();
           }  catch (Exception e) { // Catch any exception occured in creating AppstatusManager object or calling its methods
             errAppManager = appStatusManager.errMsg;
             appStatusManager = null;
             error = true;
             errorMsg="Error occured while accessing ApplicationStatusManager method in " + getClass() + " in case-" + s_methodCall  + " : "+e.toString();
            } finally {
             // Set error message response variable
             response.setVariable("callAppStatusManager_error",errorMsg);
             response.setVariable("appStatusManager_error", errAppManager);
            // log.FmtAndLogMsg(" FINISH Method Call : " + request.getAttribute("METHOD_CALL").trim().toUpperCase() + " Request Id  : " + request.getAttribute("REQUEST_ID") );
           }
      } catch (Exception e) {
            appStatusManager = null;
            String sErr=e.getMessage();

            //  If a broken pipe occurs then try just one more time to see if we can re-establish the connection
            if (!brokenPipe && sErr.indexOf("Broken pipe") > 0) {
                brokenPipe=true;
                errorOccurred=true;
            }  else throw new Exception(" Error occured in establish connection "+ getClass()+" : "+ e.toString());
        }

     } while(errorOccurred);
   }
}
