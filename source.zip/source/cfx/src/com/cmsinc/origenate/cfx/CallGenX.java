package com.cmsinc.origenate.cfx;

import com.allaire.cfx.*;
import com.cmsinc.origenate.xmldbt.GenX;
import com.cmsinc.origenate.util.IniFile;
import java.util.StringTokenizer;

/**
 * GenX CustomTag calls genx to build XML.
 * Required parameters
 *   PARAM_NAMES: chr(1) delimited list of parameter names
 *   PARAM_VALUES: chr(1) delimited list of values of each parameter
 *   ADDITIONAL_XML_XPATHS: chr(1) delimited list of xpaths that will be added after document creation
 *   ADDITIONAL_XML_VALUES: chr(1) delimited list of xml values for each of the above xpaths.
 *   TRANSACTION_TYPE_ID: Transaaction_type_id of the xml being requested to build.
 *   S_APPLY_XML: If passed in the xml will then be applied to the style sheet url supplied here.
 *   INI_FILE: path and filename of system ini file.
 *	 S_DOCUMENT = valid values (Incoming, Outgoing), if supplied instead of building a normal xml document, the
 *                xml will be documented - 9/25/07 - DCG: Added IncomingCustomerFormat and OutgoingCustomerFormat
 *                as valid values to produce new documentation format.
 *
 **/

public class CallGenX implements CustomTag {
    static GenX genx=null;
    static String s_prev_ini_file = null;
    //
    // values read from ini file:
    //
    static String s_cur_host = "";
    static String s_cur_port = "";
    static String s_cur_sid = "";
    static String s_cur_user = "";
    static String s_cur_tns = "";
    static String s_cur_password = "";
    static String s_cur_log_file = "";
    static String s_cur_default_network = "";
    static int i_cur_dbg_lvl = 0;

    public void processRequest(Request request, Response response) throws Exception {


        boolean errorOccurred,brokenPipe=false;

        do {

          errorOccurred=false;

        try {
            //
            // Get passed in parameters
            //
            StringTokenizer st_fields = new StringTokenizer(request.getAttribute("PARAM_NAMES" ),"\001");
            StringTokenizer st_values =  new StringTokenizer(request.getAttribute("PARAM_VALUES"),"\001");
            String s_transaction = request.getAttribute("TRANSACTION_TYPE_ID");
            String s_ini_file = request.getAttribute("INI_FILE");
            String s_apply_xsl = request.getAttribute("APPLY_XSL");
            String s_document = request.getAttribute("DOCUMENT_XML");
            String s_field;
            String s_value;
            String s_xml="";
            boolean b_good_xml = true;

            //
            // if the ini file is different than the previous one, reread the
            // ini info, if its different too, then set object to null
            // so that we reopen the new database, and reinitailize
            //
            if ((s_prev_ini_file == null) || (s_prev_ini_file.compareToIgnoreCase(s_ini_file)!=0)) {
                String s_host;
                String s_port;
                String s_sid;
                String s_user;
                String s_tns;
                String s_password;
                String s_log_file;
                String s_default_network;
                int i_dbg_lvl;

                s_prev_ini_file = s_ini_file;
                IniFile ini = new IniFile();
                ini.readINIFile(s_ini_file);
                s_host = ini.getINIVar("database.host");
                s_port = ini.getINIVar("database.port");
                s_sid = ini.getINIVar("database.sid");
                s_user = ini.getINIVar("database.user");
                s_tns = ini.getINIVar("database.TNSEntry","");
                s_password = ini.getINIVar("database.password");
                s_log_file = ini.getINIVar("logs.cfx_genx_log_file");
                s_default_network = ini.getINIVar("general.default_network");
                try { i_dbg_lvl = Integer.parseInt(ini.getINIVar("debug.cfx_genx_dbg_lvl")); }
                catch (Exception e){ i_dbg_lvl = 0; }

                if ((s_cur_host.compareTo(s_host)!=0) ||
                    (s_cur_port.compareTo(s_port)!=0) ||
                    (s_cur_sid.compareTo(s_sid)!=0) ||
                    (s_cur_user.compareTo(s_user)!=0) ||
                    (s_cur_tns.compareTo(s_tns)!=0) ||
                    (s_cur_password.compareTo(s_password)!=0) ||
                    (s_cur_log_file.compareTo(s_log_file)!=0) ||
                    (s_cur_default_network.compareTo(s_default_network)!=0) ||
                    (i_cur_dbg_lvl != i_dbg_lvl)) {
                    s_cur_host = s_host;
                    s_cur_port = s_port;
                    s_cur_sid = s_sid;
                    s_cur_user = s_user;
                    s_cur_tns = s_tns;
                    s_cur_password = s_password;
                    s_cur_log_file = s_log_file;
                    s_cur_default_network = s_default_network;
                    i_cur_dbg_lvl = i_dbg_lvl;
                    //
                    // set object to null so we reinatialize
                    //
                    genx = null;
                }
            }
            //
            // create genx object if it has not been created yet
            //
            if (genx==null) {
                try {
                    genx = new GenX(s_cur_host,s_cur_sid,s_cur_user,s_cur_password ,s_cur_log_file,i_cur_dbg_lvl,s_cur_port,s_cur_tns);
                }
                catch (Exception e) {
                    throw new Exception("Caught exception getting ini and/or genx object in "+this.getClass()+":"+e.toString());
                }
            }
            //
            // pass in params to genx
            //
            genx.ResetParams();
            b_good_xml = genx.bSetParam("DEFAULT_NETWORK",s_cur_default_network);
            while ((st_fields.hasMoreTokens()) && (b_good_xml)) {
                s_field = st_fields.nextToken();
                s_value = st_values.nextToken();
                b_good_xml = genx.bSetParam(s_field,s_value);
            }
            //
            // if there are additional xml items to build pass them in as parameters also
            //
            if (b_good_xml) {
                b_good_xml = genx.bSetParam("ADDITIONAL_XML_XPATHS",request.getAttribute("ADDITIONAL_XML_XPATHS"));
                if (b_good_xml) {
                    b_good_xml = genx.bSetParam("ADDITIONAL_XML_VALUES",request.getAttribute("ADDITIONAL_XML_VALUES"));
                }
            }

			// Setting Decryption parameters, so XML will be decrypted.
			if (b_good_xml) {
				genx.setEncryptionParms(request.getAttribute("SCHEMAUSER"),request.getAttribute("DECRYPTION_FIELDS"));
			}
			
            if (b_good_xml) {
				// 
                if (s_document != null && s_document.length() > 0) {
					// 9/25/07 - DCG: Added IncomingCustomerFormat and OutgoingCustomerFormat
					//                as valid values to produce new documentation format.
					if (s_document.compareToIgnoreCase("Incoming")==0) {
						s_xml = genx.sGetXMLorThrow(s_transaction,genx.build_type_document_incoming);
					}
					else if (s_document.compareToIgnoreCase("Outgoing")==0) {
						s_xml = genx.sGetXMLorThrow(s_transaction,genx.build_type_document_outgoing);
					}
					else if (s_document.compareToIgnoreCase("IncomingCustomerFormat")==0) {
						s_xml = genx.sGetXMLorThrow(s_transaction,genx.build_type_document_incoming_customer_format);
					}
					else if (s_document.compareToIgnoreCase("OutgoingCustomerFormat")==0) {
						s_xml = genx.sGetXMLorThrow(s_transaction,genx.build_type_document_outgoing_customer_format);
					}
                }
                else {
                    s_xml = genx.sGetXMLorThrow(s_transaction,s_apply_xsl);
                }
            }
            else {
                s_xml = "";
                //
                // a problem occured, so null out genx, so that it re-establishes
                // a db connection on next call.
                //
                genx.cleanup();
                genx = null;
            }
            response.setVariable("s_xml",s_xml);
        }
        catch (Exception e) {
            //
            // blow away the genx object so it gets created again on the next call
            //
            genx.cleanup();
            genx = null;

            String sErr=e.toString();

            // GL. 06/05/02  If a broken pipe occurs then try just one more time to
            //               see if we can re-establish the connection

            if (!brokenPipe && sErr.indexOf("Broken pipe") > 0) {
                brokenPipe=true;
                errorOccurred=true;
            }
            else
               throw new Exception("ERROR Caught exception in "+this.getClass()+":"+sErr);
        }

        } // end do
        while (errorOccurred);

    }
}
