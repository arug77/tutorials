/****************************************************************************************************************
   Company: First American CMSI
    Product: Origenate
    Version: Beta
    Author: Akash Pandya
    Copyright (c) 2002. All rights reserved

    Description: Implementation of call to AppLockingManager. This class is registered in ColdFusion Admin.
 *******************************************************************************************************************/
package com.cmsinc.origenate.cfx;

import java.io.*;
import com.allaire.cfx.*;
import com.cmsinc.origenate.workflow.AppLockingManager;
import com.cmsinc.origenate.workflow.AppLockingInfo;
import com.cmsinc.origenate.util.IniFile;


public class CallAppLockingManager implements CustomTag {

  //Declare static variable to handle one reqeust at a time
  static AppLockingManager appLocking;

  /************************************************************************/
  /*            Implement method of CustomTag interface                   */
  /************************************************************************/
  public void processRequest(Request request,Response response) throws Exception {

    boolean errorOccurred, brokenPipe=false;

    do {
      try {

        errorOccurred=false;
        boolean error=false;
        String errorMsg="";


        // Create appLocking object if it has not been created yet
        if (appLocking != null)
          appLocking = null;

        //Get Ini File name
        String s_iniFile =  request.getAttribute("INI_FILE");

        //Get ini file values for DB connection
        IniFile ini = new IniFile();
        ini.readINIFile(s_iniFile);
        String s_host = ini.getINIVar("database.host");
        String s_port = ini.getINIVar("database.port");
        String s_sid = ini.getINIVar("database.sid");
        String s_user = ini.getINIVar("database.user");
        String s_password = ini.getINIVar("database.password");
        String s_log_file = ini.getINIVar("logs.applocking_log_file");
        String sTNSEntry = ini.getINIVar("database.TNSEntry", "");

        //Create workflowManager object
        appLocking = new AppLockingManager(s_host,  s_sid,  s_user,  s_password, s_log_file, s_port,sTNSEntry);


        // Get name of method to be called
        String s_methodCall = request.getAttribute("METHOD_CALL").trim().toUpperCase();

        try {

          if(s_methodCall.equals("SETLOCKONAPP")) { //set lock on app

            //Get requested values
            String s_requestId = request.getAttribute("REQUEST_ID");
            String s_userId = request.getAttribute("USER_ID");
            String s_locktypeId = request.getAttribute("LOCK_TYPE_ID");
            String s_lockdescTxt = request.getAttribute("LOCK_DESC_TXT");

            //Convert values to appropriate format
            long l_requestId = Integer.parseInt(s_requestId);
            int  i_locktypeId = Integer.parseInt(s_locktypeId);

            boolean b_is_lockset = appLocking.setLockOnApp(l_requestId,  s_userId, i_locktypeId, s_lockdescTxt);

            String s_lock_set;
            if (b_is_lockset)
              s_lock_set = "TRUE";
            else
              s_lock_set = "FALSE";

            //Set return value
            response.setVariable("ret_isLocked", s_lock_set);

          }   else if(s_methodCall.equals("RELEASELOCKONAPP")) { //Release lock on app

            //Get requested values
            String s_requestId = request.getAttribute("REQUEST_ID");
            String s_userId = request.getAttribute("USER_ID");

            //Convert values to appropriate format
            long l_requestId = Integer.parseInt(s_requestId);

            boolean b_is_unlock = appLocking.releaseLockOnApp(l_requestId,s_userId);

            String s_unlock;
            if (b_is_unlock)
              s_unlock = "TRUE";
            else
              s_unlock = "FALSE";

            //Set return value
            response.setVariable("ret_isUnLocked", s_unlock);

          }   else if(s_methodCall.equals("GETLOCKINFO")) { //Get lock info

            //Get requested values
            String s_requestId = request.getAttribute("REQUEST_ID");

            //Convert values to appropriate format
            long l_requestId = Integer.parseInt(s_requestId);

            //Get application lock information
            AppLockingInfo appInfoBean = appLocking.getLockInfo(l_requestId);

            //Set application lock information
            if (appInfoBean != null) {
              response.setVariable("ret_userID", appInfoBean.getUserID());
              response.setVariable("ret_lockDt", appInfoBean.getLockDt().toString());
              response.setVariable("ret_locktype", (Integer.valueOf(appInfoBean.getlockType())).toString());
              response.setVariable("ret_lockdesc",  appInfoBean.getLockDescTxt());
            } else {
              response.setVariable("ret_userID", "");
              response.setVariable("ret_lockDt", "");
              response.setVariable("ret_locktype", "");
              response.setVariable("ret_lockdesc",  "");
            }

          }  else {
            System.out.println("WRONG CASE");
          }
        }  catch (NumberFormatException ne) {
          ne.printStackTrace();
          appLocking = null;
          error=true;
          errorMsg= "NumberFormatException Error occured in creating appLocking object in " + " in case-" + s_methodCall  + " : "+ ne.toString();
        }  catch (Exception e) { // Catch any exception occured in creating AppstatusManager object or calling its methods
          e.printStackTrace();
          appLocking = null;
          error = true;
          errorMsg="Error occured while accessing appLocking method in "  + " in case-" + s_methodCall  + " : "+e.toString();
        }

        // Set error message response variable
        response.setVariable("callAppLockingManager_error",errorMsg);


      } catch (Exception e) {
        appLocking = null;
        String sErr=e.toString();

        //  If a broken pipe occurs then try just one more time to see if we can re-establish the connection
        if (!brokenPipe && sErr.indexOf("Broken pipe") > 0) {
          brokenPipe=true;
          errorOccurred=true;
          }  else throw new Exception(" Error occured in establish connection : " + e.toString());
      }

    } while(errorOccurred);
  }
}