package com.cmsinc.origenate.cfx;

import com.allaire.cfx.*;
import com.cmsinc.origenate.util.LogViewer;

/**
* CallLogViewer uses LogViewer to tail logs, format and sort, then return the log
* Required parameters 
*	logfiles - a list of log names (fully pathed)
*       lines - number of lines to tail
**/

public class CallLogViewer implements CustomTag {
  public void processRequest(Request request, Response response) throws Exception {
    try {
      // get params (can only get string input) 
      String s_logfiles = request.getAttribute("LOGFILES");      
      // convert input to correct datatype
      int i_lines = Integer.parseInt(request.getAttribute("LINES"));
      int i_numlogs = Integer.parseInt(request.getAttribute("NUMLOGS"));
      int ix = 0, i;
      String[] logname_arr = new String[i_numlogs];
      
      // move string (comma delimited list) value to string array value
      if(i_numlogs > 1) { 
        for(i=0;i<i_numlogs-1;i++) {
          logname_arr[i] = s_logfiles.substring(ix, s_logfiles.indexOf(",", ix));
          ix = s_logfiles.indexOf(",", ix)+1;
        }
      } 
      logname_arr[i_numlogs-1] = s_logfiles.substring(ix, s_logfiles.length());
      
      // set lv to store the logview
      LogViewer lv = new LogViewer();
      String[] ret_log = new String[i_lines];
      ret_log = lv.logView(i_lines, logname_arr);
      
      // convert output to string for cf, stripping out null elements
      i=0;
      while(i < ret_log.length && ret_log[i] != null) {
        response.write(ret_log[i]+"<BR>");
        ++i;
      }  
      
      // reinitialize for next call
      ret_log = null;
      lv = null;
    }
    catch (Exception e) {
      throw new Exception("Caught exception in "+this.getClass()+":"+e.toString());
    }   
  }
} 
