package com.cmsinc.origenate.cfx;

import com.allaire.cfx.*;
import com.cmsinc.origenate.util.IniFile;
import java.sql.*;
import com.cmsinc.origenate.util.EvaluateTransaction;
import com.cmsinc.origenate.util.LogMsg;
import com.cmsinc.origenate.util.COLEncrypt;

/**
 * CallEvaluateTransaction Calls the EvaluateTransaction class
 * Required parameters
            INI_FILE: path and filename of system ini file.
            STATUS - evaluate_transaction status id (1,2,3)
            MESSAGE - message (general description of error)
            DETAILED_MESSAGE - detailed message (precise description of error)
            RECEIVED - TRUE/FALSE indicating if the received date should be set
            ERQ_ID - Eval Request Queue id
            REQUEST_ID - application #
 *
 **/

public class CallEvaluateTransaction implements CustomTag {
    static Connection con= null;
    static String s_prev_ini_file = null;
    static LogMsg log_obj=null;
    //
    // values read from ini file:
    //
    static String s_cur_host = "";
    static String s_cur_port = "";
    static String s_cur_sid = "";
    static String s_cur_user = "";
    static String s_cur_password = "";
    static String s_cur_log_file = "";
    static int i_cur_dbg_lvl = 0;

    public void processRequest(Request request, Response response) throws Exception {


        boolean errorOccurred,brokenPipe=false;

        do {

          errorOccurred=false;

            try {
                //
                // Get passed in parameters
                //
                String s_ini_file = request.getAttribute("INI_FILE");
                String s_status = request.getAttribute("STATUS");
                String s_message = request.getAttribute("MESSAGE");
                String s_detail_message = request.getAttribute("DETAILED_MESSAGE");
                String s_received = request.getAttribute("RECEIVED");
                boolean b_received=true;
                if ((s_received.compareToIgnoreCase("FALSE")==0) || (s_received.compareTo("0")==0)) {
                    b_received = false;
                }
                String s_erq_id = request.getAttribute("ERQ_ID");
                String s_request_id= request.getAttribute("REQUEST_ID");

                //
                // if the ini file is different than the previous one, reread the
                // ini info, if its different too, then set object to null
                // so that we reopen the new database, and reinitailize
                //
                if ((s_prev_ini_file == null) || (s_prev_ini_file.compareToIgnoreCase(s_ini_file)!=0)) {
                    String s_host;
                    String s_port;
                    String s_sid;
                    String s_user;
                    String s_password;
                    String s_log_file;
                    String s_default_network;
                    int i_dbg_lvl;

                    s_prev_ini_file = s_ini_file;
                    IniFile ini = new IniFile();
                    ini.readINIFile(s_ini_file);
                    s_host = ini.getINIVar("database.host");
                    s_port = "1592";
                    s_sid = ini.getINIVar("database.sid");
                    s_user = ini.getINIVar("database.user");
                    s_password = ini.getINIVar("database.password");
                    s_log_file = ini.getINIVar("logs.cfx_evaltran_log_file");
                    try { i_dbg_lvl = Integer.parseInt(ini.getINIVar("debug.cfx_evaltran_dbg_lvl")); }
                    catch (Exception e){ i_dbg_lvl = 0; }

                    if ((s_cur_host.compareTo(s_host)!=0) ||
                        (s_cur_port.compareTo(s_port)!=0) ||
                        (s_cur_sid.compareTo(s_sid)!=0) ||
                        (s_cur_user.compareTo(s_user)!=0) ||
                        (s_cur_password.compareTo(s_password)!=0) ||
                        (s_cur_log_file.compareTo(s_log_file)!=0) ||
                        (i_cur_dbg_lvl != i_dbg_lvl)) {
                        s_cur_host = s_host;
                        s_cur_port = s_port;
                        s_cur_sid = s_sid;
                        s_cur_user = s_user;
                        s_cur_password = s_password;
                        s_cur_log_file = s_log_file;
                        i_cur_dbg_lvl = i_dbg_lvl;
                        //
                        // set object to null so we reinatialize
                        //
                        if (con!=null) {
                            con.close();
                            con = null;
                        }
                    }
                }
                //
                // create connection object if it has not been created yet
                //
                if (con==null) {
                    try {
                        String sConStr = "jdbc:oracle:thin:@" + s_cur_host + ":" + s_cur_port + ":" + s_cur_sid;
                        // Load Oracle driver
                        DriverManager.registerDriver (new oracle.jdbc.OracleDriver());

                        // Connect to the Oracle database
                        con = DriverManager.getConnection (sConStr,s_cur_user,COLEncrypt.sDecrypt(s_cur_password));
                    }
                    catch (Exception e) {
                        throw new Exception("Caught exception opening db in "+this.getClass()+":"+e.toString());
                    }
                }
                //
                // create log object if it has not been created yet
                //
                if (log_obj==null) {
                    log_obj = new LogMsg();
                    log_obj.openLogFile(s_cur_log_file);
                }
                //
                // Now Call EvaluateTransaction object
                //
                EvaluateTransaction.UpdateEvaluateTransactionStatus(con, log_obj, i_cur_dbg_lvl, s_status, s_message, s_detail_message, b_received, s_erq_id, true, s_request_id);
            }
            catch (Exception e) {
                //
                // blow away the static objects so they get created again on the next call
                //
                if (con!=null) {
                    con.close();
                    con = null;
                }
                log_obj = null;
                String sErr=e.toString();


                // If a broken pipe occurs then try just one more time to
                // see if we can re-establish the connection

                if (!brokenPipe && sErr.indexOf("Broken pipe") > 0) {
                    brokenPipe=true;
                    errorOccurred=true;
                }
                else
                   throw new Exception("ERROR Caught exception in "+this.getClass()+":"+sErr);
            }

        } // end do
        while (errorOccurred);

    }
}
