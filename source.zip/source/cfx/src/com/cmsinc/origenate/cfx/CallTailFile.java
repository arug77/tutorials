package com.cmsinc.origenate.cfx;

import com.allaire.cfx.*;
import com.cmsinc.origenate.util.TailFile;

/**
* CallLogViewer uses LogViewer to tail logs, format and sort, then return the log
* Required parameters 
*	logfiles - a list of log names (fully pathed)
*       lines - number of lines to tail
**/

public class CallTailFile implements CustomTag {
  public void processRequest(Request request, Response response) throws Exception {
    try {
      // get params (can only get string input)      
      // convert input to correct datatype
      int i_lines = Integer.parseInt(request.getAttribute("LINES"));
      
      // set tf to store the logview
      TailFile tf = new TailFile();
      String[] ret_log = new String[i_lines];
      ret_log = tf.tailFile(i_lines, request.getAttribute("LOGFILE"), "file", false);
      
      int i = 0;
      while(i < ret_log.length && ret_log[i] != null) {
        response.write(ret_log[i]+"\n");
        ++i;
      }  
      
      // reinitialize for next call
      ret_log = null;
      tf = null;
    }
    catch (Exception e) {
      throw new Exception("Caught exception in "+this.getClass()+":"+e.toString());
    }   
  }
} 

