package com.cmsinc.origenate.cfx;

import com.allaire.cfx.*;
import com.cmsinc.origenate.cp.mpe.Mpe;
import com.cmsinc.origenate.util.IniFile;
import com.cmsinc.origenate.util.SQLUpdate;
import com.cmsinc.origenate.util.LogMsg;
import com.cmsinc.origenate.util.COLEncrypt;
import java.sql.*;
import java.util.*;
import java.io.*;

/**
 * CallMPE
 *
 * Calls the MPE exporter to create a export file that will be sent to the
 * lender's servicing system
 *
 * Returns:
 *
 *  error_msg
 *
 **/

public class CallMPE implements CustomTag {

    static Mpe mpe=null;
    static String s_prev_ini_file = null;
    //
    // values read from ini file:
    //
    static String s_cur_host = "";
    static String s_cur_port = "";
    static String s_cur_sid = "";
    static String s_cur_user = "";
    static String s_cur_password = "";
    static String s_cur_tns = "";
    static String s_cur_log_file = "";
    static String s_cur_temp_dir = "";
    static String s_cur_output_dir = "";
    static String s_cur_xslt_dir = "";
    static String s_cur_dbg_lvl = "";
    static int i_dbg_lvl=0;
    static LogMsg log= new LogMsg();
    static Connection con=null;
	static boolean encryption_flg = false;


    public void processRequest(Request request,Response response) throws Exception {

        boolean error;
        String errorMsg="";


        // SINCE THIS IS CALLED INFREQUENTLY WE ARE GOING TO OPEN AND CLOSE
        // OUR DATABASE CONNECTION ON EACH CALL TO AVOID RETRY LOGIC

        mpe=null;
        con=null;

        boolean applyStyleSheet=true; // always apply style sheet for now


        error=false;
        errorMsg="";


        try {
            //
            // Get passed in parameters
            //


            String evaluator_id  = request.getAttribute("EVALUATOR_ID");
            String rerun  = request.getAttribute("RERUN");
            String user_id  = request.getAttribute("USER_ID");
            String background  = request.getAttribute("BACKGROUND");
            String startDate  = request.getAttribute("START_DATE");
            String endDate  = request.getAttribute("END_DATE");
            String s_ini_file = request.getAttribute("INI_FILE");
            String mpe_type = request.getAttribute("MPE_TYPE");
			String mpe_id = request.getAttribute("MPE_ID");
            String mpe_subtype = request.getAttribute("MPE_SUBTYPE");
			String file_name_txt = request.getAttribute("MPE_FILENAME");
			String ach_interface_id = request.getAttribute("ACH_INTERFACE_ID");
			IniFile ini = new IniFile();

            //
            // if the ini file is different than the previous one, reread the
            // ini info, if its different too, then set object to null
            // so that we reopen the new database, and reinitailize
            //
            if ((s_prev_ini_file == null) || (s_prev_ini_file.compareToIgnoreCase(s_ini_file)!=0)) {
                String s_host;
                String s_port;
                String s_sid;
                String s_user;
                String s_password;
                String s_tns;
                String s_log_file;
                String s_temp_dir = "";
                String s_output_dir = "";
                String s_xslt_dir = "";
                String s_dbg_lvl = "";
				
				
                s_prev_ini_file = s_ini_file;
                ini.readINIFile(s_ini_file);
                s_host = ini.getINIVar("database.host");
                s_port = ini.getINIVar("database.port");
                s_sid = ini.getINIVar("database.sid");
                s_user = ini.getINIVar("database.user");
                s_password = ini.getINIVar("database.password");
                s_tns = ini.getINIVar("database.TNSEntry","");
                s_log_file = ini.getINIVar("mpe.log_file");
                s_temp_dir = ini.getINIVar("mpe.temp_dir");
                s_output_dir = ini.getINIVar("mpe.output_dir");
                s_xslt_dir = ini.getINIVar("mpe.xslt_dir");
                s_dbg_lvl = ini.getINIVar("mpe.debug_level");

				if(Integer.parseInt(ini.getINIVar("encryption.encryption_flg","0")) == 1) {
					encryption_flg = true;
				}
						
                if ((s_cur_host.compareTo(s_host)!=0) ||
                    (s_cur_port.compareTo(s_port)!=0) ||
                    (s_cur_sid.compareTo(s_sid)!=0) ||
                    (s_cur_user.compareTo(s_user)!=0) ||
                    (s_cur_password.compareTo(s_password)!=0) ||
                    (s_cur_temp_dir.compareTo(s_temp_dir)!=0) ||
                    (s_cur_output_dir.compareTo(s_output_dir)!=0) ||
                    (s_cur_xslt_dir.compareTo(s_xslt_dir)!=0) ||
                    (s_cur_tns.compareTo(s_tns)!=0) ||
                    (s_cur_dbg_lvl.compareTo(s_dbg_lvl)!=0) ||
                    (s_cur_log_file.compareTo(s_log_file)!=0)) {
                    // reset class vars
                    s_cur_host = s_host;
                    s_cur_port = s_port;
                    s_cur_sid = s_sid;
                    s_cur_user = s_user;
                    s_cur_tns = s_tns;
                    s_cur_password = s_password;
                    s_cur_log_file = s_log_file;
                    s_cur_temp_dir =   s_temp_dir+File.separator;
                    s_cur_output_dir = s_output_dir+File.separator;
                    s_cur_xslt_dir =   s_xslt_dir+File.separator;
                    s_cur_dbg_lvl =   s_dbg_lvl;
                    try {i_dbg_lvl=Integer.parseInt(s_dbg_lvl);} catch (Exception e1) {i_dbg_lvl=0;}

                    if (s_cur_log_file!=null && s_cur_log_file.length()>0) log.openLogFile(s_cur_log_file);
                }


            } // ini file settings have changed
            else {
            	ini.readINIFile(s_prev_ini_file);
            }


            //
            // create mpe object
            //

            try {

                // now establish a database connection

                // sConStr should be something like:

                // "jdbc:oracle:thin:@172.16.17.108:1521:cmsiprod"


                //String sConStr = "jdbc:oracle:thin:@" + s_cur_host + ":" + s_cur_port + ":" + s_cur_sid;

                String sConStr = "jdbc:oracle:thin:@";
                               if (s_cur_tns.equals("")) {
                                       sConStr = sConStr  + s_cur_host + ":" + s_cur_port + ":" + s_cur_sid; 
                               } else {
                                       sConStr = sConStr + s_cur_tns;
                               }

                // Load Oracle driver
                DriverManager.registerDriver (new oracle.jdbc.OracleDriver());

                // Connect to the Oracle database
                con = DriverManager.getConnection (sConStr,s_cur_user,COLEncrypt.sDecrypt(s_cur_password));

                // now create the mpe object


                // In background mode we will submit a job to the Routing Queue Processor
                // so no need to new up MPE here
				String schemaUser = s_cur_user;
				log.FmtAndLogMsg("In callMPE- encryption (True/False) : " +encryption_flg+"  UserName: "+ schemaUser);
				
                if (background.equals("no")) {
                  mpe = new Mpe(con,log,
                           s_cur_temp_dir,s_cur_output_dir,
                           i_dbg_lvl,applyStyleSheet,
                           s_cur_xslt_dir,false,user_id, encryption_flg, schemaUser);// not batchMode
				  if(mpe_type.equals("SST") && mpe_subtype.equals("PSH")) {
					mpe.setini(ini);
				  }
				}

            }
            catch (Exception e) {
                mpe=null;
                error=true;
                errorMsg="Caught exception initializing MPE in "+this.getClass()+":"+e.toString();
                log.FmtAndLogMsg(errorMsg,e,i_dbg_lvl,0);
            }


            // call mpe to gen the export file


            if (!error)
               try {


                // In background mode we will submit a job to the Routing Queue Processor

                  if (background.equals("yes"))

                     errorMsg=submitBackgroundJob(evaluator_id,rerun,startDate,
                                                  endDate,s_cur_temp_dir,s_cur_output_dir,i_dbg_lvl,applyStyleSheet,
                                                  s_cur_xslt_dir,user_id,mpe_type,mpe_id,mpe_subtype,file_name_txt,ach_interface_id);
                  else // do it online
                     errorMsg=mpe.generateMpeFile(evaluator_id,(rerun.equals("yes")),startDate,endDate,mpe_type,mpe_id,mpe_subtype,file_name_txt,ach_interface_id);
                 }
               catch (Exception e) {
                   error=true;
                   // set mpe to null so it reinits on next call
                   mpe = null;
                   errorMsg=e.toString();
                   log.FmtAndLogMsg(errorMsg,e,i_dbg_lvl,0);
               }

            response.setVariable("error_msg",errorMsg);

        }
        catch (Exception e) {

            errorMsg="Unexpected error caught in "+this.getClass()+":"+e.toString();
            response.setVariable("error_msg",errorMsg);
            log.FmtAndLogMsg(errorMsg,e,i_dbg_lvl,0);

        }
        finally {
            if (con!=null)
               try {con.close();} catch (Exception ce) {}
        }


    } // processRequest()


    /////////////////////////////////////////////////////////////

    private String submitBackgroundJob(String evaluator_id,String rerun,String startDate,
                                     String endDate,String s_cur_temp_dir,String s_cur_output_dir,int i_dbg_lvl,boolean applyStyleSheet,
                                     String s_cur_xslt_dir,String user_id,String mpe_type,String mpe_id,String mpe_subtype,String file_name_txt,String ach_interface_id) throws Exception {


        Statement stmt=null;
        ResultSet rs=null;
        String response="Incomplete";

        try {
           stmt = con.createStatement();


           /* GET THE NEXT SEQUENCE FOR THE ROUTING QUEUE */

           rs = stmt.executeQuery("SELECT ROUTING_QUEUE_SEQ.NEXTVAL AS ROUTING_QUEUE_ID FROM DUAL");

           rs.next();

           String routingQueueID = rs.getString(1);

           if (startDate.length()==0) startDate="NONE";
           if (endDate.length()==0) endDate="NONE";

           String additionalData="EVALUATOR_ID,"+evaluator_id+
           ",RERUN,"+rerun+",STARTDATE,"+startDate+",ENDDATE,"+endDate+
           ",TEMPDIR,"+s_cur_temp_dir+",OUTPUTDIR,"+s_cur_output_dir+
           ",DEBUGLEVEL,"+i_dbg_lvl+",APPLYSTYLESHEET,"+applyStyleSheet+
           ",XSLTDIR,"+s_cur_xslt_dir+",USER_ID,"+user_id+",MPE_TYPE,"+mpe_type+
		   ",MPE_ID,"+mpe_id+",MPE_SUBTYPE_ID,"+mpe_subtype+",ACH_INTERFACE_ID,"+ach_interface_id+",FILE_NAME_TXT,"+file_name_txt;

           String  stmtText="insert into routing_queue "+
           " (request_id, queue_priority_num,"+
           " routing_state_id, run_dt,tries_num,additional_data_txt,routing_queue_id) "+
           " values (0,0,15,"+ // 15 - RUN_MPE action
           "sysdate,0,?,?)";
          //TTP 324955 Security Remediation Fortify Scan
           SQLUpdate sqlup = new SQLUpdate();
           sqlup.SetPreparedUpdateStatement(con,stmtText);
           sqlup.setString(1, additionalData);
           sqlup.setInt(2, routingQueueID);
           sqlup.RunPreparedUpdateStatement();
           response="MPE job: "+routingQueueID+" running in background, you can submit another job or return to main menu";
           rs.close();
		   stmt.close();
        }
        catch (Exception e) {
		    try{ if(rs != null) rs.close(); }catch(Exception e1){e1.printStackTrace();}
			try{ if(stmt != null) stmt.close(); }catch(Exception e1){e1.printStackTrace();}
            throw (e);
        }
        finally {
			try{ if(rs != null) rs.close(); }catch(Exception e1){e1.printStackTrace();}
			try{ if(stmt != null) stmt.close(); }catch(Exception e1){e1.printStackTrace();}
        }

        return  response;

    } // submitBackgroundJob()


} // CallMPE
