package com.cmsinc.origenate.cfx;

import com.allaire.cfx.*;
import com.cmsinc.origenate.ae.copyapp.*;
import com.cmsinc.origenate.util.IniFile;
import java.util.StringTokenizer;

/**
 * CopyApp CustomTag calls CopyApp to copy a credit request.
 *
 * Required parameters
 *
 *
 *   ACTION:  COPY  or  DELETE
 *
 *   TRANSACTION_TYPE_ID: Transaction_type_id in copyapp_tables to use.
 *
 *   REQUEST_ID:  Request ID of app to copy
 *
 *   TABLE_NAME:  Table name to start copy at. Normally, 'CREDIT_REQUEST'
 *
 *   ADDITIONAL_PARMS:  name value pairs formatted as:
 *     (PARMNAME)=VALUE|(PARMNAME2)=VALUE2|...
 *     EX. (REQUEST_ID)=123|(REQUESTOR_ID)=1|    (MUST INCLUDE TRAILING PIPE)
 *
 *   INI_FILE: path and filename of ccweb.ini file.
 *
 *       Note: ccweb.ini
 *             [logs]
 *             copyapp_log_file  =  filename
 *
 *       If not present then will log to System.out (under CF goes to application.log)!
 *
 * Returns:
 *
 *  new_request_id
 *  error_msg
 *
 **/

public class CallCopyApp implements CustomTag {

    static CopyApp copyApp=null;
    static String s_prev_ini_file = null;
    //
    // values read from ini file:
    //
    static String s_cur_host = "";
    static String s_cur_port = "";
    static String s_cur_sid = "";
    static String s_cur_user = "";
    static String s_cur_tns = "";
    static String s_cur_password = "";
    static String s_cur_log_file = "";

    public void processRequest(Request request,Response response) throws Exception {

        boolean error;
        String errorMsg="";



        boolean errorOccurred,brokenPipe=false;

        do {

          errorOccurred=false;
          error=false;
          errorMsg="";


        try {
            //
            // Get passed in parameters
            //

            String s_action = request.getAttribute("ACTION");
            if (s_action==null) s_action="COPY";
            String s_transaction = request.getAttribute("TRANSACTION_TYPE_ID");
            String s_request_id = request.getAttribute("REQUEST_ID");
            String s_table_name = request.getAttribute("TABLE_NAME");
            String s_parms = request.getAttribute("ADDITIONAL_PARMS");
            String s_ini_file = request.getAttribute("INI_FILE");

            //
            // if the ini file is different than the previous one, reread the
            // ini info, if its different too, then set object to null
            // so that we reopen the new database, and reinitailize
            //
            if ((s_prev_ini_file == null) || (s_prev_ini_file.compareToIgnoreCase(s_ini_file)!=0)) {
                String s_host;
                String s_port;
                String s_sid;
                String s_user;
                String s_tns;
                String s_password;
                String s_log_file;
                int i_dbg_lvl;

                s_prev_ini_file = s_ini_file;
                IniFile ini = new IniFile();
                ini.readINIFile(s_ini_file);
                s_host = ini.getINIVar("database.host");
                s_port = ini.getINIVar("database.port");
                s_sid = ini.getINIVar("database.sid");
                s_user = ini.getINIVar("database.user");
                s_tns = ini.getINIVar("database.TNSEntry","");
                s_password = ini.getINIVar("database.password");
                s_log_file = ini.getINIVar("logs.copyapp_log_file");

                if ((s_cur_host.compareTo(s_host)!=0) ||
                    (s_cur_port.compareTo(s_port)!=0) ||
                    (s_cur_sid.compareTo(s_sid)!=0) ||
                    (s_cur_user.compareTo(s_user)!=0) ||
                    (s_cur_tns.compareTo(s_tns)!=0) ||
                    (s_cur_password.compareTo(s_password)!=0) ||
                    (s_cur_log_file.compareTo(s_log_file)!=0)) {
                    s_cur_host = s_host;
                    s_cur_port = s_port;
                    s_cur_sid = s_sid;
                    s_cur_user = s_user;
                    s_cur_tns = s_tns;
                    s_cur_password = s_password;
                    s_cur_log_file = s_log_file;
                    //
                    // set object to null so we reinatialize
                    //
                    copyApp = null;
                }
            }

            //
            // create copyApp object if it has not been created yet
            //
            if (copyApp==null) {
                try {
                    // copyApp = new CopyApp(s_cur_host,s_cur_sid,s_cur_user,s_cur_password,s_cur_log_file,s_cur_port);
                    // call new constructor that passes an optional tns entry, 150165
                    copyApp = new CopyApp(s_cur_host,s_cur_sid,s_cur_user,s_cur_password,s_cur_log_file,s_cur_port,s_cur_tns);
                }
                catch (Exception e) {
                    if (copyApp != null) {
                        copyApp.closeDatabaseConnection();
                        copyApp = null;
                    }
                    error=true;
                    errorMsg="Caught exception getting ini and/or CopyApp object in "+this.getClass()+":"+e.toString();
                }
            } // created CopyApp object


            CopyAppResponse resp=null;

            if (!error)
               try {
                 if (s_action.equals("DELETE"))
                    resp=copyApp.delete(s_request_id,s_transaction,s_table_name,s_parms);
                 else
                    resp=copyApp.copy(s_request_id,s_transaction,s_table_name,s_parms);
                 }
               catch (Exception e) {
                   error=true;
                   // set copyApp to null so it reinits on next call
                    if (copyApp != null) {
                        copyApp.closeDatabaseConnection();
                        copyApp = null;
                    }
                   errorMsg=e.toString();
               }

            response.setVariable("new_request_id",((error) ? "0" : resp.assignedRequestID));
            response.setVariable("error_msg",errorMsg);

        }
        catch (Exception e) {
            if (copyApp != null) {
                copyApp.closeDatabaseConnection();
                copyApp = null;
            }
            
            String sErr=e.toString();

            // GL. 06/05/02  If a broken pipe occurs then try just one more time to
            //               see if we can re-establish the connection

            if (!brokenPipe && sErr.indexOf("Broken pipe") > 0) {
                brokenPipe=true;
                errorOccurred=true;
            }
            else
               throw new Exception("ERROR Caught exception in "+this.getClass()+":"+sErr);
        }

        } // end do
        while (errorOccurred);

    } // processRequest()

} // CallCopyApp
