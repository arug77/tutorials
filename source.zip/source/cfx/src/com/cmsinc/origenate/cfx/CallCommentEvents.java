package com.cmsinc.origenate.cfx;

import com.allaire.cfx.*;
import com.cmsinc.origenate.event.CommentEvents;
import com.cmsinc.origenate.util.IniFile;
import com.cmsinc.origenate.util.LogMsg;

/**
 * CallCommentEvents CustomTag calls CommentEvents to insert a Comment event.
 *
 * Required parameters
 *
 *   REQUEST_ID:  Request ID of app
 *   Comment_EVENT_ID: Comment_event_id
 *	 Comment_EVENT_TXT: Comment_event_txt
 *	 CREATED_USER_ID: created_user_id
 *   INI_FILE: path and filename of origentate.ini file.
 *
 *       Note: origenate.ini
 *             [logs]
 *             Commentevents_log_file  =  filename
 *
 *       If not present then will log to System.out (under CF goes to application.log)!
 *
 * Returns:
 *  comment_error_msg
 *
 **/

public class CallCommentEvents implements CustomTag {

    static CommentEvents  commentEvents;
    private LogMsg log = new LogMsg();

    public void processRequest(Request request,Response response) throws Exception {

	boolean errorOccurred, brokenPipe=false;

        do {

        try {
	    errorOccurred=false;
	    boolean error=false;
	    String errorMsg="";
	    long new_comment_id = -1;
            IniFile ini = null;
            String s_log_file =  "";

        //
        // Get passed in parameters
        //
        String s_request_id = request.getAttribute("REQUEST_ID");
        String s_comment_event_id = request.getAttribute("COMMENT_EVENT_ID");
	    String s_comment_subject_txt = request.getAttribute("COMMENT_SUBJECT_TXT");
	    String s_comment_txt = request.getAttribute("COMMENT_TXT");
	    String s_created_user_id = request.getAttribute("CREATED_USER_ID");
		String s_assigned_user_id = request.getAttribute("ASSIGNED_USER_ID");
		String s_due_dt = request.getAttribute("DUE_DT");
        String s_ini_file = request.getAttribute("INI_FILE");


        ini = new IniFile();
        ini.readINIFile(s_ini_file);
        s_log_file = ini.getINIVar("logs.commentevents_log_file");
        ini = null;

        log.openLogFile(s_log_file);
        log.FmtAndLogMsg(" START  Request Id  : " + s_request_id + " s_comment_event_id : " + s_comment_event_id  +  " s_comment_subject_txt : " + s_comment_subject_txt  + " s_comment_txt : " + s_comment_txt + " s_created_user_id : " + s_created_user_id);


        //
        // create CommentEvents object if it has not been created yet
        //
        if (commentEvents!=null)  
		   commentEvents=null;
		 
		
            try {
                ini = new IniFile();
                ini.readINIFile(s_ini_file);
                String s_host = ini.getINIVar("database.host");
                String s_port = ini.getINIVar("database.port");
                String s_sid = ini.getINIVar("database.sid");
                String s_user = ini.getINIVar("database.user");
                String s_password = ini.getINIVar("database.password");
                s_log_file = ini.getINIVar("logs.commentevents_log_file");
                String sTNSEntry = ini.getINIVar("database.TNSEntry", "");

                commentEvents = new CommentEvents(s_host,s_sid,s_user,s_password,s_log_file,s_port,sTNSEntry);

            }  catch (Exception e) {
                commentEvents=null;
                error=true;
                errorMsg="Caught exception getting ini and/or CommentEvents object in "+this.getClass()+":"+e.toString();
            }

        

        if (!error) {
			try {
				int request_id = Integer.parseInt(s_request_id);
				int comment_event_id = Integer.parseInt(s_comment_event_id);
				new_comment_id = commentEvents.addComment(request_id,comment_event_id,s_comment_subject_txt, s_comment_txt, s_created_user_id, s_assigned_user_id, s_due_dt);
	        }
	        catch (NumberFormatException ne) {
				commentEvents=null;
	        	error=true;
	            errorMsg= ne.toString();
	        }
			catch (Exception e) {
				commentEvents=null;
				error=true;
	            errorMsg= e.toString();
                        } finally {

               log.FmtAndLogMsg(" FINISH  Request Id  : " + s_request_id + " s_comment_event_id : " + s_comment_event_id  +  " s_comment_subject_txt : " + s_comment_subject_txt  + " s_comment_txt : " + s_comment_txt + " s_created_user_id : " + s_created_user_id);

            }
	    }

        response.setVariable("comment_error_msg",errorMsg);
	    response.setVariable("comment_id",""+new_comment_id);

        }
        catch (Exception e) {
            commentEvents = null;
	    	String sErr=e.toString();

            //  If a broken pipe occurs then try just one more time to see if we can re-establish the connection
            if (!brokenPipe && sErr.indexOf("Broken pipe") > 0) {
                brokenPipe=true;
                errorOccurred=true;
            }
            else throw new Exception("Caught exception in "+this.getClass()+":"+e.toString());
        }
	}//end do
	while(errorOccurred);

    } // processRequest()

} // CallCommentEvents
