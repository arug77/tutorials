package com.cmsinc.origenate.cfx;

import com.allaire.cfx.*;
import com.cmsinc.origenate.ae.Ofac;
import com.cmsinc.origenate.util.IniFile;

/**
* CallOfac is how CF interfaces with the Ofac java object
* Required parameters
*	request_id - the application to check for fraud
*       ini_file - ini file with db connection info
*
* Created 6/20/2003 by b. snyder
**/

public class CallOfac implements CustomTag {
    static Ofac o;

    public void processRequest(Request request, Response response) throws Exception {

        try {
            // get params
            int request_id = Integer.parseInt(request.getAttribute("REQUEST_ID"));
            String s_ini_file = request.getAttribute("INI_FILE");

            // get db connection info
            IniFile ini = new IniFile();
            ini.readINIFile(s_ini_file);
            String s_host = ini.getINIVar("database.host");
            String s_port = ini.getINIVar("database.port");
            String s_sid = ini.getINIVar("database.sid");
            String s_user = ini.getINIVar("database.user");
            String s_password = ini.getINIVar("database.password");
            String s_log_file = ini.getINIVar("logs.ofac_log_file");

            String sTNSEntry = ini.getINIVar("database.TNSEntry", "");


            // create object and then check for ofac violations
            if (o == null)
                o = new Ofac(s_host,s_sid,s_user,s_password,s_log_file,s_port,sTNSEntry);

            o.ofac(request_id);
            o.cleanup();
        }
        catch (Exception e) {
            if (o != null)
                o.cleanup();
            o = null;
            throw new Exception("Caught exception in "+this.getClass()+":"+e.toString());
        }
  }
}



