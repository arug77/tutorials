package com.cmsinc.origenate.cfx;

import com.allaire.cfx.*;
import com.cmsinc.origenate.xmldbt.conversion.Converter;
import com.cmsinc.origenate.util.IniFile;

/**
 * CallConverter CustomTag calls converter to convert data.
 * Required parameters
 *	value_txt - value to be converted to/from COL
 *	default_db_field_name-name of the db field to pull value from
 *	default_value- value to return if not found.
 *	action - which conversion to run.
 *	to_from_COL - convert to or from COL.  Defaulted to TO_COL.
 *   INI_FILE: path and filename of system ini file.
 *
 **/

public class CallConverter implements CustomTag {
    static Converter cnv = null;
    static String s_prev_ini_file = null;
    //
    // values read from ini file:
    //
    static String s_cur_host = "";
    static String s_cur_port = "";
    static String s_cur_sid = "";
    static String s_cur_user = "";
    static String s_cur_password = "";
    static String s_cur_log_file = "";
    static int i_cur_dbg_lvl = 0;

    public void processRequest(Request request,  Response response) throws Exception {


        boolean errorOccurred,brokenPipe=false;

        do {

          errorOccurred=false;

        try {
            //
            // Get passed in parameters
            //
            String s_action = request.getAttribute("ACTION");
            String s_value = request.getAttribute("VALUE");
            String s_default_db_field_name = request.getAttribute("DEFAULT_DB_FIELD_NAME");
            String s_default_value = request.getAttribute("DEFAULT_VALUE");
            String s_to_from_COL = request.getAttribute("TO_FROM_COL");
            String s_transaction = request.getAttribute("TRANSACTION_TYPE_ID");
            String s_ini_file = request.getAttribute("INI_FILE");
            String s_fields="";
            String s_values="";
            boolean b_ret = false;

            //
            // if the ini file is different than the previous one, reread the
            // ini info, if its different too, then set object to null
            // so that we reopen the new database, and reinitailize
            //
            if ((s_prev_ini_file == null) || (s_prev_ini_file.compareToIgnoreCase(s_ini_file)!=0)) {
                String s_host;
                String s_port;
                String s_sid;
                String s_user;
                String s_password;
                String s_log_file;
                int i_dbg_lvl;

                s_prev_ini_file = s_ini_file;
                IniFile ini = new IniFile();
                ini.readINIFile(s_ini_file);
                s_host = ini.getINIVar("database.host");
                s_port = ini.getINIVar("database.port");
                s_sid = ini.getINIVar("database.sid");
                s_user = ini.getINIVar("database.user");
                s_password = ini.getINIVar("database.password");
                s_log_file = ini.getINIVar("logs.converter_log_file");
                try { i_dbg_lvl = Integer.parseInt(ini.getINIVar("debug.debug_level")); }
                catch (Exception e){ i_dbg_lvl = 0; }

                if ((s_cur_host.compareTo(s_host)!=0) ||
                    (s_cur_port.compareTo(s_port)!=0) ||
                    (s_cur_sid.compareTo(s_sid)!=0) ||
                    (s_cur_user.compareTo(s_user)!=0) ||
                    (s_cur_password.compareTo(s_password)!=0) ||
                    (s_cur_log_file.compareTo(s_log_file)!=0) ||
                    (i_cur_dbg_lvl != i_dbg_lvl)) {
                    s_cur_host = s_host;
                    s_cur_port = s_port;
                    s_cur_sid = s_sid;
                    s_cur_user = s_user;
                    s_cur_password = s_password;
                    s_cur_log_file = s_log_file;
                    i_cur_dbg_lvl = i_dbg_lvl;
                    //
                    // set object to null so we reinatialize
                    //
                    cnv = null;
                }
            }

            //
            // create cnv object if it has not been created yet
            //
            if (cnv==null) {
                try {
                    String s_con = "jdbc:oracle:thin:@" + s_cur_host + ":" + s_cur_port + ":" + s_cur_sid;
                    cnv = new Converter(s_con,s_cur_user,s_cur_password,s_cur_log_file, i_cur_dbg_lvl);
                }
                catch (Exception e) {
                    throw new Exception("Caught exception getting ini and/or cnv object in "+this.getClass()+":"+e.toString());
                }
            }
            //
            // pass in params to cnv
            //
            b_ret = cnv.bRunConvert(s_action,s_value,s_default_db_field_name,s_default_value,s_to_from_COL);
            if (b_ret) {
                s_fields = cnv.sGetFields();
                s_values = cnv.sGetValues();
            }
            else {
                //
                // blow away converter object so it reinitializes on next call
                //
                if (cnv != null) {
                    cnv.closeConnection();
                    cnv = null;
                }
            }
            response.setVariable("s_fields",s_fields);
            response.setVariable("s_values",s_values);
        }
        catch (Exception e) {
            //
            // blow away the cnv object so it gets created again on the next call
            //
            if (cnv != null) {
                cnv.closeConnection();
                cnv = null;
            }

            String sErr=e.toString();

            // GL. 06/05/02  If a broken pipe occurs then try just one more time to
            //               see if we can re-establish the connection

            if (!brokenPipe && sErr.indexOf("Broken pipe") > 0) {
                brokenPipe=true;
                errorOccurred=true;
            }
            else
               throw new Exception("ERROR Caught exception in "+this.getClass()+":"+sErr);
        }

        } // end do
        while (errorOccurred);

    }
}
