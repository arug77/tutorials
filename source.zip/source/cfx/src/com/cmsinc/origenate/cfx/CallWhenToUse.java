package com.cmsinc.origenate.cfx;

import com.allaire.cfx.*;
import com.cmsinc.origenate.doc.GenJob;
import com.cmsinc.origenate.util.IniFile;
import com.cmsinc.origenate.util.LogMsg;
import java.util.StringTokenizer;

/**
 * CallWhenToUse CustomTag calls GenJob.doesDocumentPassWhenToUseCriteria to see if
 * the passed in document passes the when-to-use criteria for the given request_id
 *
 * Required parameters
 *
 *
 *   REQUEST_ID:  Request ID of app to copy
 *
 *   DOCUMENT_ID:  Document to check
 *
 *   INI_FILE: path and filename of ccweb.ini file.
 *
 *
 * Returns: sets variable 'return_code' in caller to 0-did not pass, 1-passed
 *          error_msg if error occurred
 *
 **/

public class CallWhenToUse implements CustomTag {

    static GenJob genJob=null;
    static String s_prev_ini_file = null;
    //
    // values read from ini file:
    //
    static String s_cur_host = "";
    static String s_cur_port = "";
    static String s_cur_sid = "";
    static String s_cur_user = "";
    static String s_cur_password = "";
    static String s_cur_tns = "";
    static String s_cur_log_file = "";
    static LogMsg log=null;



    public void processRequest(Request request,Response response) throws Exception {

        boolean error=false;
        String errorMsg="";


        /************  DEBUG

        if (log==null) {
           log=new LogMsg();
           log.openLogFile("c:\\development\\ccweblog\\glenn.log");
        }
        log.FmtAndLogMsg("Enter CallWhenToUse");
        ***************/


        boolean errorOccurred,brokenPipe=false,passed=false;

        do {

          errorOccurred=false;
          error=false;
          passed=false;
          errorMsg="";

         // log.FmtAndLogMsg("Do CallWhenToUse");

        try {
            //
            // Get passed in parameters
            //

            String request_id = request.getAttribute("REQUEST_ID");
            String document_id = request.getAttribute("DOCUMENT_ID");
            if (document_id==null) document_id = "";
            String package_id = request.getAttribute("PACKAGE_ID");
            if (package_id==null) package_id = "";
            String s_ini_file = request.getAttribute("INI_FILE");

            // logged in Origenate user
            String user = null;
            if (request.attributeExists("USER_ID")) {
				user = request.getAttribute("USER_ID");
			}

            //
            // if the ini file is different than the previous one, reread the
            // ini info, if its different too, then set object to null
            // so that we reopen the new database, and reinitailize
            //
            if ((s_prev_ini_file == null) || (s_prev_ini_file.compareToIgnoreCase(s_ini_file)!=0)) {
                String s_host;
                String s_port;
                String s_sid;
                String s_user;
                String s_password;
                String s_tns;
                String s_log_file;
                int i_dbg_lvl;

                s_prev_ini_file = s_ini_file;
                IniFile ini = new IniFile();
                ini.readINIFile(s_ini_file);
                s_host = ini.getINIVar("database.host");
                s_port = ini.getINIVar("database.port");
                s_sid = ini.getINIVar("database.sid");
                s_user = ini.getINIVar("database.user");
                s_password = ini.getINIVar("database.password");
                s_tns = ini.getINIVar("database.TNSEntry","");
                s_log_file = ini.getINIVar("logs.cfx_when_to_use_log_file");

                if ((s_cur_host.compareTo(s_host)!=0) ||
                    (s_cur_port.compareTo(s_port)!=0) ||
                    (s_cur_sid.compareTo(s_sid)!=0) ||
                    (s_cur_user.compareTo(s_user)!=0) ||
                    (s_cur_password.compareTo(s_password)!=0) ||
                    (s_cur_tns.compareTo(s_tns)!=0) ||
                    (s_cur_log_file.compareTo(s_log_file)!=0)) {
                    s_cur_host = s_host;
                    s_cur_port = s_port;
                    s_cur_sid = s_sid;
                    s_cur_user = s_user;
                    s_cur_tns = s_tns;
                    s_cur_password = s_password;
                    s_cur_log_file = s_log_file;
                    //
                    // set object to null so we reinatialize
                    //
                    genJob = null;
                }
            }

            //
            // create genJob object if it has not been created yet
            //

            if (genJob==null) {
                 genJob = new GenJob(s_cur_host,s_cur_sid,s_cur_user,s_cur_password,s_cur_log_file,s_cur_port,s_cur_tns);
            }


            if (package_id.length()>0 && !package_id.equals("0"))
               passed=genJob.doesPackagePassWhenToUseCriteria(package_id,request_id, user);
            else
               passed=genJob.doesDocumentPassWhenToUseCriteria(document_id,request_id, null, user);


            response.setVariable("error_msg","");

            if (passed)
                response.setVariable("return_code","1");
            else
                response.setVariable("return_code","0");

        }
        catch (Exception e9) {

            // set genJob to null so it reinits on next try
            genJob = null;

            String sErr=e9.toString();
            sErr=sErr.replace('\n',' ');
            sErr=sErr.replace('\'',' ');

            // GL. 06/05/02  If a broken pipe occurs then try just one more time to
            //               see if we can re-establish the connection

            // for any kind of error try at least one more time
            if (!brokenPipe /* && sErr.indexOf("Broken pipe") > 0 */ ) {
                brokenPipe=true;
                errorOccurred=true;
            }
            else {
               response.setVariable("error_msg",sErr);
               response.setVariable("return_code","0"); // 0 - means did not pass
            }
        }

        } // end do
        while (errorOccurred);


    } // processRequest()

} // CallWhenToUse
