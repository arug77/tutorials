/****************************************************************************************************************
   Company: First American CMSI
    Product: Origenate
    Version: Beta
    Author: Akash Pandya
    Copyright (c) 2002. All rights reserved

    Description: Implementation of call to WorkFlowManager. This class is registered in ColdFusion Admin.
*******************************************************************************************************************/
package com.cmsinc.origenate.cfx;

import java.io.*;
import com.allaire.cfx.*;
import com.cmsinc.origenate.workflow.ApplicationStatusManager;
import com.cmsinc.origenate.workflow.WorkFlowManager;
import com.cmsinc.origenate.util.IniFile;


public class CallWorkFlowManager implements CustomTag {

  //Declare static variable to handle one reqeust at a time
   static WorkFlowManager  workflowManager;


  /************************************************************************/
  /*            Implement method of CustomTag interface                   */
  /************************************************************************/
  public void processRequest(Request request,Response response) throws Exception {

    boolean errorOccurred, brokenPipe=false;

    do {
     try {
            errorOccurred=false;
            boolean error=false;
            String errorMsg = "", errAppManager = "";
            String s_methodCall = "";

         try {

            // Create workflowManager object if it has not been created yet
           if (workflowManager != null)
              workflowManager = null;


           //Get Ini File name
           String s_iniFile = request.getAttribute("INI_FILE");

            //Get ini file values for DB connection
            IniFile ini = new IniFile();
            ini.readINIFile(s_iniFile);
            String s_host = ini.getINIVar("database.host");
            String s_port = ini.getINIVar("database.port");
            String s_sid = ini.getINIVar("database.sid");
            String s_user = ini.getINIVar("database.user");
            String s_password = ini.getINIVar("database.password");
            String s_log_file = ini.getINIVar("logs.workflow_log_file");
            String s_client_name = ini.getINIVar("general.client_name");

            //Create workflowManager object
            //workflowManager = new WorkFlowManager(s_host,  s_sid,  s_user,  s_password, s_log_file, s_port);
            // GL. 150165 - call with client name to use connection pool 
            workflowManager = new WorkFlowManager(s_log_file,s_iniFile,s_client_name);


           // Get name of method to be called
           s_methodCall = request.getAttribute("METHOD_CALL").trim().toUpperCase();



              if(s_methodCall.equals("WITHDRAWNAPP")) { //Set withdraw app statuses

               //Get requested values
               String s_requestId = request.getAttribute("REQUEST_ID");
               String s_evaluatorId = request.getAttribute("EVALUATOR_ID");
               String s_uerId = request.getAttribute("USER_ID");
			   String s_notify = request.getAttribute("NOTIFY_FLG");

               //Convert values to appropriate format
              long l_requestId = Long.parseLong(s_requestId);
              int  i_evaluatorId = Integer.parseInt(s_evaluatorId);
			  int  i_sendNotify = Integer.parseInt(s_notify);

              //Get activity Status ID
              workflowManager.withdrawnApp(l_requestId, i_evaluatorId,  s_uerId, i_sendNotify, "");


             }   else if (s_methodCall.equals("EVALDECISION")) { //Evaluation Decision

                    //Get requested values
                   String s_requestId = request.getAttribute("REQUEST_ID");
                   String s_decisionStatus = request.getAttribute("DECISION_STATUS");
                   String s_userId = request.getAttribute("USER_ID");
		   		   String s_evalreturn = request.getAttribute("EVALRETURN_TEAMUSER");
				   String s_newProg = request.getAttribute("S_NEWPROGTXT");

                   //Convert values to appropriate format
                   long l_requestId = Long.parseLong(s_requestId);
                   int  i_decStatus = Integer.parseInt(s_decisionStatus);
                   boolean b_evaluserteam;
                   if (s_evalreturn.equalsIgnoreCase("true"))
                      b_evaluserteam = true;
                   else
                      b_evaluserteam = false;

                   workflowManager.evaluationDecision(l_requestId, i_decStatus, s_userId, b_evaluserteam,s_newProg);


             }   else if(s_methodCall.equals("GETDEFAULTTASK")) { //Get default next task by task group

               //Get requested values
               String s_taskgrpId = request.getAttribute("TASK_GROUP_ID");
               String s_taskId = request.getAttribute("TASK_ID");
               String s_evaluatorId = request.getAttribute("EVALUATOR_ID");
               String s_productId = request.getAttribute("PRODUCT_ID");

               //Convert values to appropriate format
               int  i_evaluatorId = Integer.parseInt(s_evaluatorId);
               int  i_productId = Integer.parseInt(s_productId);

               String default_task_id =  workflowManager.getDefaultTask(s_taskgrpId, s_taskId, i_evaluatorId, i_productId);

               //Set return value
               response.setVariable("ret_defaultTaskID", default_task_id);


             }  else if(s_methodCall.equals("CALCNEXTTASK")) { //Calc, Set & Get next task by task group

               //Get requested values
               String s_requestId = request.getAttribute("REQUEST_ID");
               String s_evaluatorId = request.getAttribute("EVALUATOR_ID");
               String s_productId = request.getAttribute("PRODUCT_ID");
               String s_taskgrpId = request.getAttribute("TASK_GROUP_ID");
               String s_taskId = request.getAttribute("TASK_ID");
               String s_userId = request.getAttribute("USER_ID");

               //Convert values to appropriate format
               long l_requestId = Integer.parseInt(s_requestId);
               int  i_evaluatorId = Integer.parseInt(s_evaluatorId);
               int  i_productId = Integer.parseInt(s_productId);

               String next_task_id = workflowManager.calcNextTask(l_requestId, i_evaluatorId,  i_productId,   s_taskgrpId,  s_taskId,  s_userId);

               //Set return value
               response.setVariable("ret_nextTaskID", next_task_id);

             }  else if(s_methodCall.equals("GETCURRENTTASK")) { // Get current task by task group

               //Get requested values
               String s_requestId = request.getAttribute("REQUEST_ID");
               String s_evaluatorId = request.getAttribute("EVALUATOR_ID");

               //Convert values to appropriate format
               long l_requestId = Integer.parseInt(s_requestId);
               int  i_evaluatorId = Integer.parseInt(s_evaluatorId);

               String current_task_id = workflowManager.getCurrentTask(l_requestId, i_evaluatorId);

               //Set return value
               response.setVariable("ret_currentTaskID", current_task_id);


             }  else if(s_methodCall.equals("SETNEWTASKANDTG")) { // Get current task by task group

               //Get requested values
               String s_requestId = request.getAttribute("REQUEST_ID");
               String s_taskId = request.getAttribute("TASK_ID");
               String s_taskgroupId = request.getAttribute("TASK_GROUP_ID");
               String s_userId = request.getAttribute("USER_ID");

               //Convert values to appropriate format
               long l_requestId = Long.parseLong(s_requestId);

               boolean b_ret_valid_status = workflowManager.setNewTaskandTaskGroup(l_requestId,s_taskId,s_taskgroupId,s_userId);

               String s_ret_valid_status;
               if (b_ret_valid_status)
                  s_ret_valid_status = "TRUE";
               else
                  s_ret_valid_status = "FALSE";

               //Set return value
               response.setVariable("ret_valid_status", s_ret_valid_status);

             } else if(s_methodCall.equals("SETNEWTASKANDTG_REDIRECT")) { // Get current task by task group

               //Get requested values
               String s_requestId = request.getAttribute("REQUEST_ID");
               String s_taskId = request.getAttribute("TASK_ID");
               String s_taskgroupId = request.getAttribute("TASK_GROUP_ID");
               String s_userId = request.getAttribute("USER_ID");
               String s_assignUserId = request.getAttribute("ASSIGN_USER_ID");
               String s_assignTeamId = request.getAttribute("ASSIGN_TEAM_ID");
               String s_taskTOFlag = request.getAttribute("TASK_TIMEOUT_FLAG");

               //Convert values to appropriate format
               long l_requestId = Long.parseLong(s_requestId);
               int  i_task_timeout_flg =   Integer.parseInt(s_taskTOFlag);
               int  i_assign_team_id =   Integer.parseInt(s_assignTeamId);

               boolean b_ret_valid_status = workflowManager.setNewTaskandTaskGroup(l_requestId,s_taskId,s_taskgroupId,s_userId,s_assignUserId,i_assign_team_id,i_task_timeout_flg);

               String s_ret_valid_status;
               if (b_ret_valid_status)
                  s_ret_valid_status = "TRUE";
               else
                  s_ret_valid_status = "FALSE";

               //Set return value
               response.setVariable("ret_valid_status", s_ret_valid_status);

             }  else if(s_methodCall.equals("ISALLACTRESOLVED")) { //Check all activities resolved in task group or application

               //Get requested values
               String s_requestId = request.getAttribute("REQUEST_ID");
               String s_taskgrpId = request.getAttribute("TASK_GROUP_ID");

               //Convert values to appropriate format
               long l_requestId = Integer.parseInt(s_requestId);

               boolean b_is_resolved = workflowManager.isAllActivitiesResolved(l_requestId, s_taskgrpId);

               String s_act_resolved;
               if (b_is_resolved)
                  s_act_resolved = "TRUE";
               else
                  s_act_resolved = "FALSE";

               //Set return value
               response.setVariable("ret_allActResolved", s_act_resolved);

             }  else if(s_methodCall.equals("ISVALIDTASK")) { //check is this valid task

               //Get requested values
               String s_requestId = request.getAttribute("REQUEST_ID");
               String s_evaluatorId = request.getAttribute("EVALUATOR_ID");

               //Convert values to appropriate format
               long l_requestId = Integer.parseInt(s_requestId);
               int  i_evaluatorId = Integer.parseInt(s_evaluatorId);

               boolean b_is_validTask = workflowManager.isValidTask(l_requestId, i_evaluatorId);

               String s_valid_task;
               if (b_is_validTask)
                  s_valid_task = "TRUE";
               else
                  s_valid_task = "FALSE";

               //Set return value
               response.setVariable("ret_isValidTask", s_valid_task);

         }   else if(s_methodCall.equals("CANCELECONTRACT")) { // Update cancel econtract statuses

           //Get requested values
           String s_requestId = request.getAttribute("REQUEST_ID");
           String s_userId = request.getAttribute("USER_ID");
           String s_lendDealId = request.getAttribute("LEND_DEAL_ID");


           //Convert values to appropriate format
           long l_requestId = Integer.parseInt(s_requestId);


           boolean b_success_flg = workflowManager.canceleContractStatus(l_requestId,s_userId,s_lendDealId);

           String s_success_flg;
           if (b_success_flg)
                s_success_flg = "TRUE";
           else
                s_success_flg = "FALSE";

           //Set return value
           response.setVariable("ret_successflg", s_success_flg);

             }
           }  catch (NumberFormatException ne) {
             workflowManager = null;
             error=true;
             errorMsg= "NumberFormatException Error occured in creating workflowManager object in " + getClass()+ " in case-" + s_methodCall  + " : "+ ne.toString();
           }  catch (Exception e) { // Catch any exception occured in creating AppstatusManager object or calling its methods
             workflowManager = null;
             error = true;
             errorMsg="Error occured while accessing workflowManager method in " + getClass() + " in case-" + s_methodCall  + " : "+e.toString();
            } finally {
             // Set error message response variable
             response.setVariable("callWorkFlowManager_error",errorMsg);
           }
      } catch (Exception e) {
            workflowManager = null;
            String sErr=e.getMessage();

            //  If a broken pipe occurs then try just one more time to see if we can re-establish the connection
            if (!brokenPipe && sErr.indexOf("Broken pipe") > 0) {
                brokenPipe=true;
                errorOccurred=true;
            }  else throw new Exception(" Error occured in establish connection "+ getClass()+" : "+ e.toString());
        }

     } while(errorOccurred);
   }
}
