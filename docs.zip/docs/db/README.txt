FILES IN THE VSS DIRECTORY $\origenate\docs\db\upgrade HAVE MOVED:

Developer Checklist - Making Origenate DB Changes.doc
now in $\origenate\docs\how to\

Origenate DB Upgrade.doc
now in $\origenate\docs\design\Origenate DB Upgrade - Design Doc.doc