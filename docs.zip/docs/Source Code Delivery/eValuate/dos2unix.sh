# Script to run dos2unix command

UNZIP_DIR=$1
BUILD_DIR=$2

cd $UNZIP_DIR
chmod -R 777 *
find . -name \*.sh -exec dos2unix {} \;
cd $BUILD_DIR

