# Script to run Linkbin.sh

UNZIP_DIR=$1
BUILD_DIR=$2

cd $UNZIP_DIR
./Linkbin.sh
cd $BUILD_DIR
