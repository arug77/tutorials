# Script to run setpath.sh

UNZIP_DIR=$1
BUILD_DIR=$2

cd $UNZIP_DIR
. ./setpath.sh -release -1
gmake
cd $BUILD_DIR