# Script to run makejar.sh

JAVA_SRC_DIR=$1
BUILD_DIR=$2

cd $JAVA_SRC_DIR/../..
. ./setpath.sh -release -1
cd $JAVA_SRC_DIR
. ./makejar.sh
cd $BUILD_DIR