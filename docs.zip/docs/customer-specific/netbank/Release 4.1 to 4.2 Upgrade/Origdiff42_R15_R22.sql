/* Origdiff42_R15_R22.sql */

/* From origenate4.01.sql - No changes - v133 only removed a line that was executed in another script */

/* From origenate4.1.sql from v120 R42.15 thru v126 R42.22 */

/* BEGIN: 07/20/2004 Wei Ma */

/* Itemized Total Down is equal to Reg Z Total Down, compl rule 1043 */

INSERT INTO MSTR_RULE (RULE_ID ,RULE_CATEGORY_ID ,RULE_NAME_TXT ,ACTION_MODULE_TXT ,PRESENTATION_NUM ,RULE_DESCRIPTION_TXT ,RULE_CONSEQUENCE_ID ,DB_DATA_TYPE_TXT ,DB_FIELD_NAME_TXT ,COUNTRY_TXT ) VALUES 
(1049 ,-1 ,'Itemized Total Down <> Reg Z Total Down' ,'act_rule_compl_contracttotaldown.cfm' ,null ,'Itemized Total Down <> Reg Z Total Down' ,1 ,'number' ,'total_down_num' ,'USA'  );

INSERT INTO XREF_PRODUCT_RULES (RULE_ID ,PRODUCT_ID ) VALUES (1049 ,1  );
INSERT INTO XREF_PRODUCT_RULES (RULE_ID ,PRODUCT_ID ) VALUES (1049 ,2  );
INSERT INTO XREF_PRODUCT_RULES (RULE_ID ,PRODUCT_ID ) VALUES (1049 ,3  );
INSERT INTO XREF_PRODUCT_RULES (RULE_ID ,PRODUCT_ID ) VALUES (1049 ,4  );

/* END: 07/20/2004 Wei Ma */

/* BEGIN Dave Kelly 07/21/2004 */
/* Added view for Allison for ACC */

Create or Replace view max_decision_ref_id_acc_view as
SELECT
CR.REQUEST_ID,
CR.STATUS_ID,
CR.SOURCE_ID,
CR.PRODUCT_ID,
CR.INITIATION_DT-0.125 INIT_DATE,
CR.CLIENT_APP_ID,
CRDE.EVALUATOR_ID,
CRDE.DECISIONED_BY_USER_ID,	
' ' APPROVED_SCORE_TXT,
CRDE.SEND_DT,
CRDE.DECISION_ID,
CRDE.CREATE_DT,
CRDE.DECISION_REF_ID,
CRDE.DECISION_CATEGORY_ID,
CRDE.LENDERLINK_EVALUATOR_ID,
calc_total_financed_num( CRDE.request_id, CRDE.evaluator_id) total_financed_num
FROM  CREDIT_REQ_DECISIONS_EVALUATOR CRDE, CREDIT_REQUEST CR
WHERE 
  CR.REQUEST_ID = CRDE.REQUEST_ID AND
  crde.decision_ref_id = (select max(decision_ref_id) from credit_req_decisions_evaluator
where  request_id = crde.request_id and DECISION_CATEGORY_ID in (1,2,3) );
/

/* END: Dave Kelly 07/21/2004 */


/* BEGIN: Dave Kelly 07/21/04 */

CREATE OR REPLACE PROCEDURE Contract_Verif_Auto_Collateral
(IN_evaluator_id IN NUMBER,IN_request_id IN NUMBER) AS

  x NUMBER(1);
  y NUMBER(1);
  z NUMBER(1);
  t NUMBER(1);
  u NUMBER(1);
  w NUMBER(1);
  v_crcc_cnt number(1);


  v_count NUMBER(1);
  NextCatID NUMBER(2);
  v_cat_id  NUMBER(1);
  v_verif_cat NUMBER(1);
  nextverifnum NUMBER(2);

  CURSOR c_getcollateral IS
  SELECT collateral_request_id, collateral_type_id
  FROM CREDIT_REQUEST_COLLATERAL
  WHERE  request_id  =   IN_request_id;

  CURSOR c_getprimaryauto IS
  SELECT credit_request_auto_id,collateral_request_id,new_used_flg,vin_txt,primary_flg,year_num,auto_make_id,model_txt,model_detail_txt,mileage_num,invoice_cost_num,msrp_num
  FROM CREDIT_REQUEST_AUTO
  WHERE request_id   = IN_request_id
  AND   primary_flg  = 1;

  CURSOR c_getauto IS
  SELECT credit_request_auto_id,collateral_request_id,new_used_flg,vin_txt,primary_flg,year_num,auto_make_id,model_txt,model_detail_txt,mileage_num,invoice_cost_num,msrp_num
  FROM CREDIT_REQUEST_AUTO
  WHERE request_id     = IN_request_id
  AND   (primary_flg    IS NULL OR primary_flg = 0)
  AND  include_in_ltv_flg = 1;

  BEGIN

  u := 0;
  nextcatid := 25;

  FOR rec IN c_getcollateral LOOP

	 SELECT COUNT(*) INTO u
	 FROM CREDIT_REQ_CONTR_VERIF_CAT
	 WHERE evaluator_id = IN_evaluator_id
	 AND   request_id   = IN_request_id
	 AND   collateral_request_id = rec.collateral_request_id;

	 IF u = 0 THEN

	 	SELECT COUNT(*) INTO v_crcc_cnt
	 	FROM CREDIT_REQ_CONTR_COLLATERAL
	 	WHERE request_id   = IN_request_id
	 	AND   collateral_request_id = rec.collateral_request_id;

		IF v_crcc_cnt = 0 THEN

		BEGIN
          		INSERT INTO CREDIT_REQ_CONTR_COLLATERAL (request_id,collateral_request_id,collateral_type_id,evaluator_id)
                        				 VALUES (IN_request_id,rec.collateral_request_id,rec.collateral_type_id,IN_evaluator_id);
		END;
	 END IF;
     END IF;

  END LOOP;

  u := 0;
  FOR rec IN c_getprimaryauto LOOP

     SELECT COUNT(*) INTO u
	 FROM CREDIT_REQ_CONTR_VERIF_CAT
	 WHERE evaluator_id           = IN_evaluator_id
	 AND   request_id             = IN_request_id
	 AND   collateral_request_id  = rec.collateral_request_id
	 AND   credit_request_auto_id = rec.credit_request_auto_id;

     IF u = 0 THEN

	    SELECT NVL(MAX(contr_verif_num),0)+1 INTO nextverifnum
		FROM  CREDIT_REQ_CONTR_VERIF_CAT
		WHERE evaluator_id          = IN_evaluator_id
		AND   request_id 			= IN_request_id;

	    BEGIN

          INSERT INTO CREDIT_REQ_CONTR_AUTO (request_id,collateral_request_id,credit_request_auto_id,year_num,new_used_flg,auto_make_id,model_txt,vin_txt,mileage_num,model_detail_txt,invoice_cost_num,msrp_num)
                                     VALUES (IN_request_id,rec.collateral_request_id,rec.credit_request_auto_id,rec.year_num,rec.new_used_flg,rec.auto_make_id,rec.model_txt,rec.vin_txt,rec.mileage_num,rec.model_detail_txt,rec.invoice_cost_num,rec.msrp_num);

          INSERT INTO CREDIT_REQ_CONTR_VERIF_CAT (evaluator_id,request_id,collateral_request_id,credit_request_auto_id,verif_category_id,contr_verif_num)
			                          VALUES (IN_evaluator_id,IN_request_id,rec.collateral_request_id,rec.credit_request_auto_id,nextcatid,nextverifnum);

	    END;

	 END IF;
     nextcatid :=  nextcatid + 1;
  END LOOP;

  u := 0;
  FOR rec IN c_getauto LOOP

	 SELECT COUNT(*) INTO u
	 FROM CREDIT_REQ_CONTR_VERIF_CAT
	 WHERE evaluator_id           = IN_evaluator_id
	 AND   request_id             = IN_request_id
	 AND   collateral_request_id  = rec.collateral_request_id
	 AND   credit_request_auto_id = rec.credit_request_auto_id;

	 IF u = 1 THEN
	    BEGIN

		   SELECT NVL(MAX(verif_category_id + 1), 5) INTO NextcatId
	       FROM CREDIT_REQ_CONTR_VERIF_CAT
	       WHERE evaluator_id           = IN_evaluator_id
	       AND   request_id             = IN_request_id
	       AND   collateral_request_id  = rec.collateral_request_id
	       AND   credit_request_auto_id = rec.credit_request_auto_id;

		END;

     END IF;

	 IF u = 0 THEN

	    SELECT NVL(MAX(contr_verif_num),0)+1 INTO nextverifnum
		FROM  CREDIT_REQ_CONTR_VERIF_CAT
		WHERE evaluator_id          = IN_evaluator_id
		AND   request_id 			= IN_request_id;

	    BEGIN

          INSERT INTO CREDIT_REQ_CONTR_AUTO (request_id,collateral_request_id,credit_request_auto_id,year_num,new_used_flg,auto_make_id,model_txt,vin_txt,mileage_num,model_detail_txt,invoice_cost_num,msrp_num)
                                     VALUES (IN_request_id,rec.collateral_request_id,rec.credit_request_auto_id,rec.year_num,rec.new_used_flg,rec.auto_make_id,rec.model_txt,rec.vin_txt,rec.mileage_num,rec.model_detail_txt,rec.invoice_cost_num,rec.msrp_num);

          INSERT INTO CREDIT_REQ_CONTR_VERIF_CAT (evaluator_id,request_id,collateral_request_id,credit_request_auto_id,verif_category_id,contr_verif_num)
			                            VALUES (IN_evaluator_id,IN_request_id,rec.collateral_request_id,rec.credit_request_auto_id,nextcatid,nextverifnum);

	      nextcatid :=  nextcatid + 1;
	    END;

     END IF;
  END LOOP;

END;
/


/* END: Dave Kelly 07/21/04 */

/* BEGIN: Jon Miller 07/23/04 */
ALTER TABLE REQUESTOR_BUREAU_SUMMARY ADD(TRADE_DEBT_NUM NUMBER(14,2));
COMMENT ON COLUMN REQUESTOR_BUREAU_SUMMARY.TRADE_DEBT_NUM IS 'Trade debt from eValuate.';
/* END: Jon Miller 07/23/04 */



/* From origenate4.2.sql from v109 R42.15 thru v127 R42.22 */

/* BEGIN: Dave Geelhaar 7/14/04 CT 128231 - Laser Pro DB Changes */

-- Add column for output directory to CONFIG_MPE

alter table CONFIG_MPE add (OUTPUT_DIR_TXT VARCHAR2(120));
comment on column CONFIG_MPE.OUTPUT_DIR_TXT IS 'Output directory for MPE files - Replaces setting in origenate.ini.';

-- Add LASERPRO to MSTR_MPE_TYPE & MSTR_ROUTING_STATE

INSERT INTO MSTR_MPE_TYPES ( MPE_TYPE_ID, MPE_DESC_TXT ) VALUES ( 
'LASERPRO', 'Laser Pro Export'); 

INSERT INTO MSTR_ROUTING_STATE ( ROUTING_STATE_ID, ROUTING_STATE_TXT, ROUTING_STATE_DESCRIPTION_TXT ) VALUES ( 
20, 'LASERPRO', 'Generate Laser Pro Export File'); 

-- Add Export Closing Documents activity

INSERT INTO MSTR_ACTIVITY ( ACTIVITY_ID, ACTIVITY_DESC_TXT, ACTIVITY_SHORT_NAME_TXT, VALID_TASK_GROUP ) VALUES ( 
33, 'Export Closing Documents', 'ExpClosingDocs', 4); 

-- Add Function to secure Export Closing Documents menu option

INSERT INTO FUNCTION_ANCESTOR ( FUNCTION_ID, FUNCTION_DESCRIPTION_TXT, PARENT_FUNCTION_ID, ACTIVE_FLG ) VALUES ( 
247, 'Export Closing Documents', 85, 1); 

/* END: Dave Geelhaar 7/14/04 CT 128231 - Laser Pro DB Changes */

/* BEGIN: StevenT 7/16/2004 - 128910 */
INSERT INTO MSTR_AUTO_MAKE(auto_make_id,auto_make_description_txt)
VALUES(78,'CHEVROLET COMMERCIAL');
INSERT INTO MSTR_AUTO_MAKE(auto_make_id,auto_make_description_txt)
VALUES(79,'DODGE COMMERCIAL');
INSERT INTO MSTR_AUTO_MAKE(auto_make_id,auto_make_description_txt)
VALUES(80,'FORD COMMERCIAL');
INSERT INTO MSTR_AUTO_MAKE(auto_make_id,auto_make_description_txt)
VALUES(81,'GMC LIGHT DUTY');
INSERT INTO MSTR_AUTO_MAKE(auto_make_id,auto_make_description_txt)
VALUES(82,'GMC MEDIUM DUTY');
INSERT INTO MSTR_AUTO_MAKE(auto_make_id,auto_make_description_txt)
VALUES(83,'ISUZU MEDIUM DUTY');
INSERT INTO MSTR_AUTO_MAKE(auto_make_id,auto_make_description_txt)
VALUES(84,'MITSUBISHI FUSO');
INSERT INTO MSTR_AUTO_MAKE(auto_make_id,auto_make_description_txt)
VALUES(85,'STERLING TRUCK');
INSERT INTO MSTR_AUTO_MAKE(auto_make_id,auto_make_description_txt)
VALUES(86,'VOLVO/WHITE');

UPDATE XREF_VEHICLE_MAKE SET auto_make_id = 78 WHERE vg_make_id = 37;
UPDATE XREF_VEHICLE_MAKE SET auto_make_id = 79 WHERE vg_make_id = 48;
UPDATE XREF_VEHICLE_MAKE SET auto_make_id = 79 WHERE vg_make_id = 51;
UPDATE XREF_VEHICLE_MAKE SET auto_make_id = 80 WHERE vg_make_id = 47;
UPDATE XREF_VEHICLE_MAKE SET auto_make_id = 80 WHERE vg_make_id = 50;
UPDATE XREF_VEHICLE_MAKE SET auto_make_id = 81 WHERE vg_make_id = 46;
UPDATE XREF_VEHICLE_MAKE SET auto_make_id = 82 WHERE vg_make_id = 45;
UPDATE XREF_VEHICLE_MAKE SET auto_make_id = 83 WHERE vg_make_id = 44;
UPDATE XREF_VEHICLE_MAKE SET auto_make_id = 84 WHERE vg_make_id = 43;
UPDATE XREF_VEHICLE_MAKE SET auto_make_id = 85 WHERE vg_make_id = 56;
UPDATE XREF_VEHICLE_MAKE SET auto_make_id = 86 WHERE vg_make_id = 40;
/* END: StevenT 7/16/2004 - 128910 */

/* BEGIN: Dave Geelhaar 7/19/04 CT 128231 - Add Closing Docs Exported to MSTR_JOURNAL_EVENTS */

INSERT INTO MSTR_JOURNAL_EVENTS ( JOURNAL_EVENT_ID, JOURNAL_EVENT_DESC_TXT, NOTE_DESC_TXT ) VALUES ( 
70, 'C Docs Exported', 'C Docs Exported'); 

/* END: Dave Geelhaar 7/19/04 CT 128231 - Add Closing Docs Exported to MSTR_JOURNAL_EVENTS */

/* BEGIN StevenT 07/19/2004 128720 */

/* Create temp funding table */
CREATE TABLE TMP_FUNDING_METHOD (
  EVALUATOR_ID		NUMBER,
  FUND_METH_ID		VARCHAR2(1),
  PRODUCT_ID            NUMBER,
  ACTIVE_FLG		NUMBER(1),
  AUDIT_LAST_UPDATED_DT DATE,
  AUDIT_UPDATED_USER_ID VARCHAR2(16)
);


/* Copy current funding records to temp file */
CREATE OR REPLACE PROCEDURE copyFunding IS

  CURSOR c_funding IS
   SELECT *
   FROM CONFIG_FUNDING_METHOD;

  BEGIN

    FOR rec IN c_funding LOOP

      INSERT INTO TMP_FUNDING_METHOD(evaluator_id,fund_meth_id,product_id,active_flg,audit_last_updated_dt,audit_updated_user_id)
      VALUES(rec.evaluator_id,rec.fund_meth_id,rec.product_id,rec.active_flg,rec.audit_last_updated_dt,rec.audit_updated_user_id);

    END LOOP; 

  END;
/
execute copyFunding;


/* Disable related constraints */
ALTER TABLE CREDIT_REQUEST_FUNDING DISABLE CONSTRAINT CREDIT_REQ_FUNDING_FK2;
ALTER TABLE CREDIT_REQUEST_PAYOFF DISABLE CONSTRAINT CREDIT_REQUEST_PAYOFF_FK1;
ALTER TABLE EVALUATOR_ORIGINATOR DISABLE CONSTRAINT EO_FUND_METH_FK;

/* Drop and recreate existing table */
DROP TABLE CONFIG_FUNDING_METHOD CASCADE CONSTRAINTS;
CREATE TABLE CONFIG_FUNDING_METHOD(
  EVALUATOR_ID		NUMBER		NOT NULL,
  FUND_METH_ID		VARCHAR2(1)	NOT NULL,
  PRODUCT_ID		NUMBER		NOT NULL,
  ACTIVE_FLG		NUMBER		NOT NULL,
  AUDIT_LAST_UPDATED_DT DATE		NOT NULL,
  AUDIT_UPDATED_USER_ID VARCHAR2(16)    NOT NULL,
  CONSTRAINT CONF_FUND_METHOD_PK PRIMARY KEY(EVALUATOR_ID,FUND_METH_ID,PRODUCT_ID),
  CONSTRAINT CONF_FUND_METHOD_FK1 FOREIGN KEY(EVALUATOR_ID,PRODUCT_ID) REFERENCES XREF_EVALUATOR_PRODUCT(EVALUATOR_ID,PRODUCT_ID),
  CONSTRAINT CONF_FUND_METHOD_FK2 FOREIGN KEY(FUND_METH_ID) REFERENCES MSTR_FUNDING_METHOD(FUND_METH_ID)
);
COMMENT ON TABLE CONFIG_FUNDING_METHOD IS 'Contains valid funding methods per evaluator and product';
COMMENT ON COLUMN CONFIG_FUNDING_METHOD.EVALUATOR_ID IS 'Unique internal identifier for a lending institution';
COMMENT ON COLUMN CONFIG_FUNDING_METHOD.PRODUCT_ID IS 'Unique internal identifier for a product';
COMMENT ON COLUMN CONFIG_FUNDING_METHOD.ACTIVE_FLG IS 'Flag indicating if this funding method is active';
COMMENT ON COLUMN CONFIG_FUNDING_METHOD.AUDIT_LAST_UPDATED_DT IS 'Date this record was last updated';
COMMENT ON COLUMN CONFIG_FUNDING_METHOD.AUDIT_UPDATED_USER_ID IS 'User who last updated this record';



/* Populate funding records from temp file */
CREATE OR REPLACE PROCEDURE addFunding IS

  CURSOR c_funding IS
   SELECT *
   FROM TMP_FUNDING_METHOD;

  BEGIN

    FOR rec IN c_funding LOOP

      INSERT INTO CONFIG_FUNDING_METHOD(evaluator_id,fund_meth_id,product_id,active_flg,audit_last_updated_dt,audit_updated_user_id)
      VALUES(rec.evaluator_id,rec.fund_meth_id,rec.product_id,rec.active_flg,rec.audit_last_updated_dt,rec.audit_updated_user_id);

    END LOOP; 

  END;
/

execute addFunding;


/* Add product_id */
ALTER TABLE CREDIT_REQUEST_PAYOFF ADD product_id NUMBER;
ALTER TABLE CREDIT_REQUEST_FUNDING ADD product_id NUMBER;
COMMENT ON COLUMN CREDIT_REQUEST_PAYOFF.PRODUCT_ID IS 'Unique internal indentifier for a product';
COMMENT ON COLUMN CREDIT_REQUEST_FUNDING.PRODUCT_ID IS 'Unique internal indentifier for a product';

/* Create procedure to populate product_id */
CREATE OR REPLACE PROCEDURE addProduct IS

  CURSOR c_product IS
   SELECT request_id, product_id
   FROM CREDIT_REQUEST;

  BEGIN

    FOR rec IN c_product LOOP

      UPDATE CREDIT_REQUEST_FUNDING SET product_id = rec.product_id WHERE request_id = rec.request_id;
      UPDATE CREDIT_REQUEST_PAYOFF SET product_id = rec.product_id WHERE request_id = rec.request_id;

    END LOOP; 

  END;
/
execute addProduct;

/* Make product_id required */
ALTER TABLE CREDIT_REQUEST_FUNDING MODIFY (product_id NOT NULL);
ALTER TABLE CREDIT_REQUEST_PAYOFF MODIFY (product_id NOT NULL);

/* Add back constraints */
ALTER TABLE CREDIT_REQUEST_FUNDING ADD CONSTRAINT CREDIT_REQ_FUNDING_FK2 FOREIGN KEY(EVALUATOR_ID,STANDARD_FUND_METH_ID,PRODUCT_ID) REFERENCES CONFIG_FUNDING_METHOD(EVALUATOR_ID,FUND_METH_ID,PRODUCT_ID) NOVALIDATE;
ALTER TABLE CREDIT_REQUEST_FUNDING ENABLE CONSTRAINT CREDIT_REQ_FUNDING_FK2;
ALTER TABLE CREDIT_REQUEST_PAYOFF ADD CONSTRAINT CREDIT_REQUEST_PAYOFF_FK1 FOREIGN KEY(EVALUATOR_ID,DETAIL_FUND_METH_ID,PRODUCT_ID) REFERENCES CONFIG_FUNDING_METHOD(EVALUATOR_ID,FUND_METH_ID,PRODUCT_ID) NOVALIDATE;
ALTER TABLE CREDIT_REQUEST_PAYOFF ENABLE NOVALIDATE CONSTRAINT CREDIT_REQUEST_PAYOFF_FK1;


/* Constraint related changes for origenator */
ALTER TABLE XREF_EVAL_ORIG_PRODUCT ADD fund_meth_id VARCHAR2(1);
COMMENT ON COLUMN XREF_EVAL_ORIG_PRODUCT.FUND_METH_ID IS 'Unique internal identifier for a funding method';

/* Pop defaults from eo */
CREATE OR REPLACE PROCEDURE addOrigMeth IS

  CURSOR c_meth IS
   SELECT eo.evaluator_id,xeop.product_id,eo.fund_meth_id,eo.originator_id
   FROM EVALUATOR_ORIGINATOR eo, XREF_EVAL_ORIG_PRODUCT xeop
   WHERE eo.evaluator_id = xeop.evaluator_id
   AND eo.originator_id = xeop.originator_id;
  BEGIN

    FOR rec IN c_meth LOOP

      UPDATE XREF_EVAL_ORIG_PRODUCT 
      SET fund_meth_id = rec.fund_meth_id
      WHERE evaluator_id = rec.evaluator_id
      AND product_id = rec.product_id
      AND originator_id = rec.originator_id;

    END LOOP; 

  END;
/
execute addOrigMeth;

CREATE INDEX xref_eval_orig_prod_ndx1 ON XREF_EVAL_ORIG_PRODUCT(evaluator_id,product_id,fund_meth_id);

ALTER TABLE XREF_EVAL_ORIG_PRODUCT ADD CONSTRAINT xref_orig_prod_fk2 FOREIGN KEY(evaluator_id,fund_meth_id,product_id) REFERENCES CONFIG_FUNDING_METHOD(evaluator_id,fund_meth_id,product_id) novalidate;
ALTER TABLE EVALUATOR_ORIGINATOR DROP COLUMN fund_meth_id;


/* CREATE TRIGGER */
CREATE OR REPLACE TRIGGER AUD_CONFIG_FUNDING_METHOD_TRG                                                                             
AFTER INSERT OR UPDATE OR DELETE ON CONFIG_FUNDING_METHOD                                                                           
FOR EACH ROW                                                                                                                        
DECLARE                                                                                                                             
-- Static insert_credit_request_audit parameters                                                                                    
v_audit_updated_user_id    VARCHAR2(20);                                                                                            
v_table_name_txt           VARCHAR2(30);                                                                                            
-- Dynamic insert_credit_request_audit parameters                                                                                   
v_column_name_txt          VARCHAR2(30);                                                                                            
v_old_value_txt            VARCHAR2(4000);                                                                                          
v_new_value_txt            VARCHAR2(4000);                                                                                          
v_user_value_txt           VARCHAR2(4000);                                                                                          
-- Error handling                                                                                                                   
v_error_num                NUMBER;                                                                                                  
v_error_message_txt        VARCHAR2(235);                                                                                           
BEGIN                                                                                                                               
-- Initialize common variables                                                                                                      
v_table_name_txt := 'CONFIG_FUNDING_METHOD';                                                                                        
v_user_value_txt := 'UNKNOWN';                                                                                                      
IF INSERTING OR DELETING THEN                                                                                                       
v_column_name_txt := 'ACTIVE_FLG';                                                                                                  
v_old_value_txt   := :OLD.ACTIVE_FLG;                                                                                               
v_new_value_txt   := :NEW.ACTIVE_FLG;                                                                                               
IF INSERTING THEN                                                                                                                   
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
ELSIF DELETING THEN                                                                                                                 
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
'UNKNOWN',                                                                                                                          
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
v_column_name_txt := 'EVALUATOR_ID';                                                                                                
v_old_value_txt   := :OLD.EVALUATOR_ID;                                                                                             
v_new_value_txt   := :NEW.EVALUATOR_ID;                                                                                             
IF INSERTING THEN                                                                                                                   
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
ELSIF DELETING THEN                                                                                                                 
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
'UNKNOWN',                                                                                                                          
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
v_column_name_txt := 'FUND_METH_ID';                                                                                                
v_old_value_txt   := :OLD.FUND_METH_ID;                                                                                             
v_new_value_txt   := :NEW.FUND_METH_ID;                                                                                             
IF INSERTING THEN                                                                                                                   
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
ELSIF DELETING THEN                                                                                                                 
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
'UNKNOWN',                                                                                                                          
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
v_column_name_txt := 'PRODUCT_ID';                                                                                                  
v_old_value_txt   := :OLD.PRODUCT_ID;                                                                                               
v_new_value_txt   := :NEW.PRODUCT_ID;                                                                                               
IF INSERTING THEN                                                                                                                   
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
ELSIF DELETING THEN                                                                                                                 
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
'UNKNOWN',                                                                                                                          
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
ELSIF UPDATING THEN                                                                                                                 
IF (:NEW.ACTIVE_FLG IS NOT NULL AND :OLD.ACTIVE_FLG IS NULL)                                                                        
OR (:OLD.ACTIVE_FLG IS NOT NULL AND :NEW.ACTIVE_FLG IS NULL)                                                                        
OR (:NEW.ACTIVE_FLG <> :OLD.ACTIVE_FLG) THEN                                                                                        
v_column_name_txt := 'ACTIVE_FLG';                                                                                                  
v_old_value_txt   := :OLD.ACTIVE_FLG;                                                                                               
v_new_value_txt   := :NEW.ACTIVE_FLG;                                                                                               
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
IF (:NEW.EVALUATOR_ID IS NOT NULL AND :OLD.EVALUATOR_ID IS NULL)                                                                    
OR (:OLD.EVALUATOR_ID IS NOT NULL AND :NEW.EVALUATOR_ID IS NULL)                                                                    
OR (:NEW.EVALUATOR_ID <> :OLD.EVALUATOR_ID) THEN                                                                                    
v_column_name_txt := 'EVALUATOR_ID';                                                                                                
v_old_value_txt   := :OLD.EVALUATOR_ID;                                                                                             
v_new_value_txt   := :NEW.EVALUATOR_ID;                                                                                             
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
IF (:NEW.FUND_METH_ID IS NOT NULL AND :OLD.FUND_METH_ID IS NULL)                                                                    
OR (:OLD.FUND_METH_ID IS NOT NULL AND :NEW.FUND_METH_ID IS NULL)                                                                    
OR (:NEW.FUND_METH_ID <> :OLD.FUND_METH_ID) THEN                                                                                    
v_column_name_txt := 'FUND_METH_ID';                                                                                                
v_old_value_txt   := :OLD.FUND_METH_ID;                                                                                             
v_new_value_txt   := :NEW.FUND_METH_ID;                                                                                             
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
IF (:NEW.PRODUCT_ID IS NOT NULL AND :OLD.PRODUCT_ID IS NULL)                                                                        
OR (:OLD.PRODUCT_ID IS NOT NULL AND :NEW.PRODUCT_ID IS NULL)                                                                        
OR (:NEW.PRODUCT_ID <> :OLD.PRODUCT_ID) THEN                                                                                        
v_column_name_txt := 'PRODUCT_ID';                                                                                                  
v_old_value_txt   := :OLD.PRODUCT_ID;                                                                                               
v_new_value_txt   := :NEW.PRODUCT_ID;                                                                                               
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
END IF; -- Inserting, Updating or Deleting?                                                                                         
EXCEPTION                                                                                                                           
WHEN OTHERS THEN                                                                                                                    
v_error_num         := SQLCODE;                                                                                                     
v_error_message_txt := SUBSTR(SQLERRM, 1, 235);                                                                                     
RAISE_APPLICATION_ERROR(-20001, ' ERROR ' || v_error_num ||  ' : ' || v_error_message_txt || 'AUD_CONFIG_FUNDING_METHOD_TRG         
aborted.');                                                                                                                         
END;                                                                                                                                
/



CREATE OR REPLACE TRIGGER AUD_XREF_EVAL_ORIG_PRODUCT_TRG                                                                            
AFTER INSERT OR UPDATE OR DELETE ON XREF_EVAL_ORIG_PRODUCT                                                                          
FOR EACH ROW                                                                                                                        
DECLARE                                                                                                                             
-- Static insert_credit_request_audit parameters                                                                                    
v_audit_updated_user_id    VARCHAR2(20);                                                                                            
v_table_name_txt           VARCHAR2(30);                                                                                            
-- Dynamic insert_credit_request_audit parameters                                                                                   
v_column_name_txt          VARCHAR2(30);                                                                                            
v_old_value_txt            VARCHAR2(4000);                                                                                          
v_new_value_txt            VARCHAR2(4000);                                                                                          
v_user_value_txt           VARCHAR2(4000);                                                                                          
-- Error handling                                                                                                                   
v_error_num                NUMBER;                                                                                                  
v_error_message_txt        VARCHAR2(235);                                                                                           
BEGIN                                                                                                                               
-- Initialize common variables                                                                                                      
v_table_name_txt := 'XREF_EVAL_ORIG_PRODUCT';                                                                                       
v_user_value_txt := 'UNKNOWN';                                                                                                      
v_user_value_txt := :NEW.AUDIT_UPDATED_USER_ID;                                                                                     
IF INSERTING OR DELETING THEN                                                                                                       
v_column_name_txt := 'EVALUATOR_ID';                                                                                                
v_old_value_txt   := :OLD.EVALUATOR_ID;                                                                                             
v_new_value_txt   := :NEW.EVALUATOR_ID;                                                                                             
IF INSERTING THEN                                                                                                                   
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
ELSIF DELETING THEN                                                                                                                 
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
'UNKNOWN',                                                                                                                          
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
v_column_name_txt := 'FUND_METH_ID';                                                                                                
v_old_value_txt   := :OLD.FUND_METH_ID;                                                                                             
v_new_value_txt   := :NEW.FUND_METH_ID;                                                                                             
IF INSERTING THEN                                                                                                                   
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
ELSIF DELETING THEN                                                                                                                 
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
'UNKNOWN',                                                                                                                          
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
v_column_name_txt := 'ORIGINATOR_ID';                                                                                               
v_old_value_txt   := :OLD.ORIGINATOR_ID;                                                                                            
v_new_value_txt   := :NEW.ORIGINATOR_ID;                                                                                            
IF INSERTING THEN                                                                                                                   
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
ELSIF DELETING THEN                                                                                                                 
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
'UNKNOWN',                                                                                                                          
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
v_column_name_txt := 'PRODUCT_ID';                                                                                                  
v_old_value_txt   := :OLD.PRODUCT_ID;                                                                                               
v_new_value_txt   := :NEW.PRODUCT_ID;                                                                                               
IF INSERTING THEN                                                                                                                   
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
ELSIF DELETING THEN                                                                                                                 
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
'UNKNOWN',                                                                                                                          
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
ELSIF UPDATING THEN                                                                                                                 
IF (:NEW.EVALUATOR_ID IS NOT NULL AND :OLD.EVALUATOR_ID IS NULL)                                                                    
OR (:OLD.EVALUATOR_ID IS NOT NULL AND :NEW.EVALUATOR_ID IS NULL)                                                                    
OR (:NEW.EVALUATOR_ID <> :OLD.EVALUATOR_ID) THEN                                                                                    
v_column_name_txt := 'EVALUATOR_ID';                                                                                                
v_old_value_txt   := :OLD.EVALUATOR_ID;                                                                                             
v_new_value_txt   := :NEW.EVALUATOR_ID;                                                                                             
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
IF (:NEW.FUND_METH_ID IS NOT NULL AND :OLD.FUND_METH_ID IS NULL)                                                                    
OR (:OLD.FUND_METH_ID IS NOT NULL AND :NEW.FUND_METH_ID IS NULL)                                                                    
OR (:NEW.FUND_METH_ID <> :OLD.FUND_METH_ID) THEN                                                                                    
v_column_name_txt := 'FUND_METH_ID';                                                                                                
v_old_value_txt   := :OLD.FUND_METH_ID;                                                                                             
v_new_value_txt   := :NEW.FUND_METH_ID;                                                                                             
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
IF (:NEW.ORIGINATOR_ID IS NOT NULL AND :OLD.ORIGINATOR_ID IS NULL)                                                                  
OR (:OLD.ORIGINATOR_ID IS NOT NULL AND :NEW.ORIGINATOR_ID IS NULL)                                                                  
OR (:NEW.ORIGINATOR_ID <> :OLD.ORIGINATOR_ID) THEN                                                                                  
v_column_name_txt := 'ORIGINATOR_ID';                                                                                               
v_old_value_txt   := :OLD.ORIGINATOR_ID;                                                                                            
v_new_value_txt   := :NEW.ORIGINATOR_ID;                                                                                            
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
IF (:NEW.PRODUCT_ID IS NOT NULL AND :OLD.PRODUCT_ID IS NULL)                                                                        
OR (:OLD.PRODUCT_ID IS NOT NULL AND :NEW.PRODUCT_ID IS NULL)                                                                        
OR (:NEW.PRODUCT_ID <> :OLD.PRODUCT_ID) THEN                                                                                        
v_column_name_txt := 'PRODUCT_ID';                                                                                                  
v_old_value_txt   := :OLD.PRODUCT_ID;                                                                                               
v_new_value_txt   := :NEW.PRODUCT_ID;                                                                                               
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
END IF; -- Inserting, Updating or Deleting?                                                                                         
EXCEPTION                                                                                                                           
WHEN OTHERS THEN                                                                                                                    
v_error_num         := SQLCODE;                                                                                                     
v_error_message_txt := SUBSTR(SQLERRM, 1, 235);                                                                                     
RAISE_APPLICATION_ERROR(-20001, ' ERROR ' || v_error_num ||  ' : ' || v_error_message_txt || 'AUD_XREF_EVAL_ORIG_PRODUCT_TRG        
aborted.');                                                                                                                         
END;                                                                                                                                
/                                                                                                                                   


CREATE OR REPLACE TRIGGER AUD_EVALUATOR_ORIGINATOR_TRG                                                                              
AFTER INSERT OR UPDATE OR DELETE ON EVALUATOR_ORIGINATOR                                                                            
FOR EACH ROW                                                                                                                        
DECLARE                                                                                                                             
-- Static insert_credit_request_audit parameters                                                                                    
v_audit_last_updated_dt    DATE;                                                                                                    
v_audit_updated_user_id    VARCHAR2(20);                                                                                            
v_table_name_txt           VARCHAR2(30);                                                                                            
-- Dynamic insert_credit_request_audit parameters                                                                                   
v_column_name_txt          VARCHAR2(30);                                                                                            
v_old_value_txt            VARCHAR2(4000);                                                                                          
v_new_value_txt            VARCHAR2(4000);                                                                                          
v_user_value_txt           VARCHAR2(4000);                                                                                          
-- Error handling                                                                                                                   
v_error_num                NUMBER;                                                                                                  
v_error_message_txt        VARCHAR2(235);                                                                                           
BEGIN                                                                                                                               
-- Initialize common variables                                                                                                      
v_table_name_txt := 'EVALUATOR_ORIGINATOR';                                                                                         
v_user_value_txt := 'UNKNOWN';                                                                                                      
v_user_value_txt := :NEW.AUDIT_UPDATED_USER_ID;                                                                                     
IF INSERTING OR DELETING THEN                                                                                                       
v_column_name_txt := 'ABANUMBER_TXT';                                                                                               
v_old_value_txt   := :OLD.ABANUMBER_TXT;                                                                                            
v_new_value_txt   := :NEW.ABANUMBER_TXT;                                                                                            
IF INSERTING THEN                                                                                                                   
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
ELSIF DELETING THEN                                                                                                                 
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
'UNKNOWN',                                                                                                                          
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
v_column_name_txt := 'ABA_ID';                                                                                                      
v_old_value_txt   := :OLD.ABA_ID;                                                                                                   
v_new_value_txt   := :NEW.ABA_ID;                                                                                                   
IF INSERTING THEN                                                                                                                   
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
ELSIF DELETING THEN                                                                                                                 
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
'UNKNOWN',                                                                                                                          
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
v_column_name_txt := 'ACH_FAX_NO_TXT';                                                                                              
v_old_value_txt   := :OLD.ACH_FAX_NO_TXT;                                                                                           
v_new_value_txt   := :NEW.ACH_FAX_NO_TXT;                                                                                           
IF INSERTING THEN                                                                                                                   
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
ELSIF DELETING THEN                                                                                                                 
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
'UNKNOWN',                                                                                                                          
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
v_column_name_txt := 'ACH_NO_TXT';                                                                                                  
v_old_value_txt   := :OLD.ACH_NO_TXT;                                                                                               
v_new_value_txt   := :NEW.ACH_NO_TXT;                                                                                               
IF INSERTING THEN                                                                                                                   
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
ELSIF DELETING THEN                                                                                                                 
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
'UNKNOWN',                                                                                                                          
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
v_column_name_txt := 'ACH_TRANS_NO_TXT';                                                                                            
v_old_value_txt   := :OLD.ACH_TRANS_NO_TXT;                                                                                         
v_new_value_txt   := :NEW.ACH_TRANS_NO_TXT;                                                                                         
IF INSERTING THEN                                                                                                                   
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
ELSIF DELETING THEN                                                                                                                 
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
'UNKNOWN',                                                                                                                          
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
v_column_name_txt := 'ACTIVE_FLG';                                                                                                  
v_old_value_txt   := :OLD.ACTIVE_FLG;                                                                                               
v_new_value_txt   := :NEW.ACTIVE_FLG;                                                                                               
IF INSERTING THEN                                                                                                                   
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
ELSIF DELETING THEN                                                                                                                 
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
'UNKNOWN',                                                                                                                          
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
v_column_name_txt := 'ASSIGNED_TEAM_ID';                                                                                            
v_old_value_txt   := :OLD.ASSIGNED_TEAM_ID;                                                                                         
v_new_value_txt   := :NEW.ASSIGNED_TEAM_ID;                                                                                         
IF INSERTING THEN                                                                                                                   
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
ELSIF DELETING THEN                                                                                                                 
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
'UNKNOWN',                                                                                                                          
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
v_column_name_txt := 'ASSIGNED_USER_ID';                                                                                            
v_old_value_txt   := :OLD.ASSIGNED_USER_ID;                                                                                         
v_new_value_txt   := :NEW.ASSIGNED_USER_ID;                                                                                         
IF INSERTING THEN                                                                                                                   
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
ELSIF DELETING THEN                                                                                                                 
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
'UNKNOWN',                                                                                                                          
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
v_column_name_txt := 'BRANCH_ASSIGNMENT_TXT';                                                                                       
v_old_value_txt   := :OLD.BRANCH_ASSIGNMENT_TXT;                                                                                    
v_new_value_txt   := :NEW.BRANCH_ASSIGNMENT_TXT;                                                                                    
IF INSERTING THEN                                                                                                                   
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
ELSIF DELETING THEN                                                                                                                 
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
'UNKNOWN',                                                                                                                          
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
v_column_name_txt := 'CONTACT_TXT';                                                                                                 
v_old_value_txt   := :OLD.CONTACT_TXT;                                                                                              
v_new_value_txt   := :NEW.CONTACT_TXT;                                                                                              
IF INSERTING THEN                                                                                                                   
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
ELSIF DELETING THEN                                                                                                                 
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
'UNKNOWN',                                                                                                                          
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
v_column_name_txt := 'CONTRACT_TYPE_TXT';                                                                                           
v_old_value_txt   := :OLD.CONTRACT_TYPE_TXT;                                                                                        
v_new_value_txt   := :NEW.CONTRACT_TYPE_TXT;                                                                                        
IF INSERTING THEN                                                                                                                   
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
ELSIF DELETING THEN                                                                                                                 
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
'UNKNOWN',                                                                                                                          
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
v_column_name_txt := 'COST_CENTER_TXT';                                                                                             
v_old_value_txt   := :OLD.COST_CENTER_TXT;                                                                                          
v_new_value_txt   := :NEW.COST_CENTER_TXT;                                                                                          
IF INSERTING THEN                                                                                                                   
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
ELSIF DELETING THEN                                                                                                                 
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
'UNKNOWN',                                                                                                                          
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
v_column_name_txt := 'CURRYEAR_NUM';                                                                                                
v_old_value_txt   := :OLD.CURRYEAR_NUM;                                                                                             
v_new_value_txt   := :NEW.CURRYEAR_NUM;                                                                                             
IF INSERTING THEN                                                                                                                   
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
ELSIF DELETING THEN                                                                                                                 
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
'UNKNOWN',                                                                                                                          
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
v_column_name_txt := 'DBA_NAME_TXT';                                                                                                
v_old_value_txt   := :OLD.DBA_NAME_TXT;                                                                                             
v_new_value_txt   := :NEW.DBA_NAME_TXT;                                                                                             
IF INSERTING THEN                                                                                                                   
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
ELSIF DELETING THEN                                                                                                                 
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
'UNKNOWN',                                                                                                                          
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
v_column_name_txt := 'DDA_NUM';                                                                                                     
v_old_value_txt   := :OLD.DDA_NUM;                                                                                                  
v_new_value_txt   := :NEW.DDA_NUM;                                                                                                  
IF INSERTING THEN                                                                                                                   
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
ELSIF DELETING THEN                                                                                                                 
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
'UNKNOWN',                                                                                                                          
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
v_column_name_txt := 'DEALER_RESERVE_ACCOUNT_TXT';                                                                                  
v_old_value_txt   := :OLD.DEALER_RESERVE_ACCOUNT_TXT;                                                                               
v_new_value_txt   := :NEW.DEALER_RESERVE_ACCOUNT_TXT;                                                                               
IF INSERTING THEN                                                                                                                   
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
ELSIF DELETING THEN                                                                                                                 
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
'UNKNOWN',                                                                                                                          
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
v_column_name_txt := 'DEALER_RESERVE_BONUS_PLAN_TXT';                                                                               
v_old_value_txt   := :OLD.DEALER_RESERVE_BONUS_PLAN_TXT;                                                                            
v_new_value_txt   := :NEW.DEALER_RESERVE_BONUS_PLAN_TXT;                                                                            
IF INSERTING THEN                                                                                                                   
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
ELSIF DELETING THEN                                                                                                                 
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
'UNKNOWN',                                                                                                                          
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
v_column_name_txt := 'DEALER_RESERVE_METHOD_TXT';                                                                                   
v_old_value_txt   := :OLD.DEALER_RESERVE_METHOD_TXT;                                                                                
v_new_value_txt   := :NEW.DEALER_RESERVE_METHOD_TXT;                                                                                
IF INSERTING THEN                                                                                                                   
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
ELSIF DELETING THEN                                                                                                                 
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
'UNKNOWN',                                                                                                                          
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
v_column_name_txt := 'DEALER_RESERVE_PLAN_TXT';                                                                                     
v_old_value_txt   := :OLD.DEALER_RESERVE_PLAN_TXT;                                                                                  
v_new_value_txt   := :NEW.DEALER_RESERVE_PLAN_TXT;                                                                                  
IF INSERTING THEN                                                                                                                   
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
ELSIF DELETING THEN                                                                                                                 
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
'UNKNOWN',                                                                                                                          
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
v_column_name_txt := 'DEALER_RESERVE_PROMO_TXT';                                                                                    
v_old_value_txt   := :OLD.DEALER_RESERVE_PROMO_TXT;                                                                                 
v_new_value_txt   := :NEW.DEALER_RESERVE_PROMO_TXT;                                                                                 
IF INSERTING THEN                                                                                                                   
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
ELSIF DELETING THEN                                                                                                                 
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
'UNKNOWN',                                                                                                                          
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
v_column_name_txt := 'DLR_FUND_ID';                                                                                                 
v_old_value_txt   := :OLD.DLR_FUND_ID;                                                                                              
v_new_value_txt   := :NEW.DLR_FUND_ID;                                                                                              
IF INSERTING THEN                                                                                                                   
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
ELSIF DELETING THEN                                                                                                                 
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
'UNKNOWN',                                                                                                                          
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
v_column_name_txt := 'EFTACHNUMBER_TXT';                                                                                            
v_old_value_txt   := :OLD.EFTACHNUMBER_TXT;                                                                                         
v_new_value_txt   := :NEW.EFTACHNUMBER_TXT;                                                                                         
IF INSERTING THEN                                                                                                                   
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
ELSIF DELETING THEN                                                                                                                 
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
'UNKNOWN',                                                                                                                          
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
v_column_name_txt := 'EMAIL_ADDRESS_TXT';                                                                                           
v_old_value_txt   := :OLD.EMAIL_ADDRESS_TXT;                                                                                        
v_new_value_txt   := :NEW.EMAIL_ADDRESS_TXT;                                                                                        
IF INSERTING THEN                                                                                                                   
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
ELSIF DELETING THEN                                                                                                                 
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
'UNKNOWN',                                                                                                                          
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
v_column_name_txt := 'EVALUATOR_ID';                                                                                                
v_old_value_txt   := :OLD.EVALUATOR_ID;                                                                                             
v_new_value_txt   := :NEW.EVALUATOR_ID;                                                                                             
IF INSERTING THEN                                                                                                                   
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
ELSIF DELETING THEN                                                                                                                 
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
'UNKNOWN',                                                                                                                          
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
v_column_name_txt := 'GL_ACCT_TXT';                                                                                                 
v_old_value_txt   := :OLD.GL_ACCT_TXT;                                                                                              
v_new_value_txt   := :NEW.GL_ACCT_TXT;                                                                                              
IF INSERTING THEN                                                                                                                   
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
ELSIF DELETING THEN                                                                                                                 
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
'UNKNOWN',                                                                                                                          
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
v_column_name_txt := 'GL_CENTER_TXT';                                                                                               
v_old_value_txt   := :OLD.GL_CENTER_TXT;                                                                                            
v_new_value_txt   := :NEW.GL_CENTER_TXT;                                                                                            
IF INSERTING THEN                                                                                                                   
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
ELSIF DELETING THEN                                                                                                                 
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
'UNKNOWN',                                                                                                                          
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
v_column_name_txt := 'GL_CORP_TXT';                                                                                                 
v_old_value_txt   := :OLD.GL_CORP_TXT;                                                                                              
v_new_value_txt   := :NEW.GL_CORP_TXT;                                                                                              
IF INSERTING THEN                                                                                                                   
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
ELSIF DELETING THEN                                                                                                                 
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
'UNKNOWN',                                                                                                                          
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
v_column_name_txt := 'MARKET_TXT';                                                                                                  
v_old_value_txt   := :OLD.MARKET_TXT;                                                                                               
v_new_value_txt   := :NEW.MARKET_TXT;                                                                                               
IF INSERTING THEN                                                                                                                   
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
ELSIF DELETING THEN                                                                                                                 
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
'UNKNOWN',                                                                                                                          
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
v_column_name_txt := 'MEGA_ORIGINATOR_ID';                                                                                          
v_old_value_txt   := :OLD.MEGA_ORIGINATOR_ID;                                                                                       
v_new_value_txt   := :NEW.MEGA_ORIGINATOR_ID;                                                                                       
IF INSERTING THEN                                                                                                                   
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
ELSIF DELETING THEN                                                                                                                 
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
'UNKNOWN',                                                                                                                          
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
v_column_name_txt := 'ORIGINATOR_CODE_TXT';                                                                                         
v_old_value_txt   := :OLD.ORIGINATOR_CODE_TXT;                                                                                      
v_new_value_txt   := :NEW.ORIGINATOR_CODE_TXT;                                                                                      
IF INSERTING THEN                                                                                                                   
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
ELSIF DELETING THEN                                                                                                                 
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
'UNKNOWN',                                                                                                                          
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
v_column_name_txt := 'ORIGINATOR_ID';                                                                                               
v_old_value_txt   := :OLD.ORIGINATOR_ID;                                                                                            
v_new_value_txt   := :NEW.ORIGINATOR_ID;                                                                                            
IF INSERTING THEN                                                                                                                   
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
ELSIF DELETING THEN                                                                                                                 
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
'UNKNOWN',                                                                                                                          
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
v_column_name_txt := 'ORIGINATOR_NAME_TXT';                                                                                         
v_old_value_txt   := :OLD.ORIGINATOR_NAME_TXT;                                                                                      
v_new_value_txt   := :NEW.ORIGINATOR_NAME_TXT;                                                                                      
IF INSERTING THEN                                                                                                                   
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
ELSIF DELETING THEN                                                                                                                 
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
'UNKNOWN',                                                                                                                          
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
v_column_name_txt := 'ORIGINATOR_TYPE_ID';                                                                                          
v_old_value_txt   := :OLD.ORIGINATOR_TYPE_ID;                                                                                       
v_new_value_txt   := :NEW.ORIGINATOR_TYPE_ID;                                                                                       
IF INSERTING THEN                                                                                                                   
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
ELSIF DELETING THEN                                                                                                                 
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
'UNKNOWN',                                                                                                                          
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
v_column_name_txt := 'OWNER_TXT';                                                                                                   
v_old_value_txt   := :OLD.OWNER_TXT;                                                                                                
v_new_value_txt   := :NEW.OWNER_TXT;                                                                                                
IF INSERTING THEN                                                                                                                   
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
ELSIF DELETING THEN                                                                                                                 
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
'UNKNOWN',                                                                                                                          
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
v_column_name_txt := 'PRENOTIFICATION_FLG';                                                                                         
v_old_value_txt   := :OLD.PRENOTIFICATION_FLG;                                                                                      
v_new_value_txt   := :NEW.PRENOTIFICATION_FLG;                                                                                      
IF INSERTING THEN                                                                                                                   
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
ELSIF DELETING THEN                                                                                                                 
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
'UNKNOWN',                                                                                                                          
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
v_column_name_txt := 'PRIORITY_FLG';                                                                                                
v_old_value_txt   := :OLD.PRIORITY_FLG;                                                                                             
v_new_value_txt   := :NEW.PRIORITY_FLG;                                                                                             
IF INSERTING THEN                                                                                                                   
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
ELSIF DELETING THEN                                                                                                                 
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
'UNKNOWN',                                                                                                                          
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
v_column_name_txt := 'REGION_ID';                                                                                                   
v_old_value_txt   := :OLD.REGION_ID;                                                                                                
v_new_value_txt   := :NEW.REGION_ID;                                                                                                
IF INSERTING THEN                                                                                                                   
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
ELSIF DELETING THEN                                                                                                                 
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
'UNKNOWN',                                                                                                                          
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
v_column_name_txt := 'SALES_REP_TXT';                                                                                               
v_old_value_txt   := :OLD.SALES_REP_TXT;                                                                                            
v_new_value_txt   := :NEW.SALES_REP_TXT;                                                                                            
IF INSERTING THEN                                                                                                                   
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
ELSIF DELETING THEN                                                                                                                 
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
'UNKNOWN',                                                                                                                          
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
v_column_name_txt := 'SALES_SOURCE_TXT';                                                                                            
v_old_value_txt   := :OLD.SALES_SOURCE_TXT;                                                                                         
v_new_value_txt   := :NEW.SALES_SOURCE_TXT;                                                                                         
IF INSERTING THEN                                                                                                                   
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
ELSIF DELETING THEN                                                                                                                 
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
'UNKNOWN',                                                                                                                          
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
v_column_name_txt := 'SLA_AT_RISK_MINS_NUM';                                                                                        
v_old_value_txt   := :OLD.SLA_AT_RISK_MINS_NUM;                                                                                     
v_new_value_txt   := :NEW.SLA_AT_RISK_MINS_NUM;                                                                                     
IF INSERTING THEN                                                                                                                   
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
ELSIF DELETING THEN                                                                                                                 
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
'UNKNOWN',                                                                                                                          
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
v_column_name_txt := 'SLA_FAILED_MINS_NUM';                                                                                         
v_old_value_txt   := :OLD.SLA_FAILED_MINS_NUM;                                                                                      
v_new_value_txt   := :NEW.SLA_FAILED_MINS_NUM;                                                                                      
IF INSERTING THEN                                                                                                                   
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
ELSIF DELETING THEN                                                                                                                 
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
'UNKNOWN',                                                                                                                          
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
v_column_name_txt := 'SLA_FLG';                                                                                                     
v_old_value_txt   := :OLD.SLA_FLG;                                                                                                  
v_new_value_txt   := :NEW.SLA_FLG;                                                                                                  
IF INSERTING THEN                                                                                                                   
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
ELSIF DELETING THEN                                                                                                                 
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
'UNKNOWN',                                                                                                                          
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
ELSIF UPDATING THEN                                                                                                                 
IF (:NEW.ABANUMBER_TXT IS NOT NULL AND :OLD.ABANUMBER_TXT IS NULL)                                                                  
OR (:OLD.ABANUMBER_TXT IS NOT NULL AND :NEW.ABANUMBER_TXT IS NULL)                                                                  
OR (:NEW.ABANUMBER_TXT <> :OLD.ABANUMBER_TXT) THEN                                                                                  
v_column_name_txt := 'ABANUMBER_TXT';                                                                                               
v_old_value_txt   := :OLD.ABANUMBER_TXT;                                                                                            
v_new_value_txt   := :NEW.ABANUMBER_TXT;                                                                                            
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
IF (:NEW.ABA_ID IS NOT NULL AND :OLD.ABA_ID IS NULL)                                                                                
OR (:OLD.ABA_ID IS NOT NULL AND :NEW.ABA_ID IS NULL)                                                                                
OR (:NEW.ABA_ID <> :OLD.ABA_ID) THEN                                                                                                
v_column_name_txt := 'ABA_ID';                                                                                                      
v_old_value_txt   := :OLD.ABA_ID;                                                                                                   
v_new_value_txt   := :NEW.ABA_ID;                                                                                                   
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
IF (:NEW.ACH_FAX_NO_TXT IS NOT NULL AND :OLD.ACH_FAX_NO_TXT IS NULL)                                                                
OR (:OLD.ACH_FAX_NO_TXT IS NOT NULL AND :NEW.ACH_FAX_NO_TXT IS NULL)                                                                
OR (:NEW.ACH_FAX_NO_TXT <> :OLD.ACH_FAX_NO_TXT) THEN                                                                                
v_column_name_txt := 'ACH_FAX_NO_TXT';                                                                                              
v_old_value_txt   := :OLD.ACH_FAX_NO_TXT;                                                                                           
v_new_value_txt   := :NEW.ACH_FAX_NO_TXT;                                                                                           
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
IF (:NEW.ACH_NO_TXT IS NOT NULL AND :OLD.ACH_NO_TXT IS NULL)                                                                        
OR (:OLD.ACH_NO_TXT IS NOT NULL AND :NEW.ACH_NO_TXT IS NULL)                                                                        
OR (:NEW.ACH_NO_TXT <> :OLD.ACH_NO_TXT) THEN                                                                                        
v_column_name_txt := 'ACH_NO_TXT';                                                                                                  
v_old_value_txt   := :OLD.ACH_NO_TXT;                                                                                               
v_new_value_txt   := :NEW.ACH_NO_TXT;                                                                                               
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
IF (:NEW.ACH_TRANS_NO_TXT IS NOT NULL AND :OLD.ACH_TRANS_NO_TXT IS NULL)                                                            
OR (:OLD.ACH_TRANS_NO_TXT IS NOT NULL AND :NEW.ACH_TRANS_NO_TXT IS NULL)                                                            
OR (:NEW.ACH_TRANS_NO_TXT <> :OLD.ACH_TRANS_NO_TXT) THEN                                                                            
v_column_name_txt := 'ACH_TRANS_NO_TXT';                                                                                            
v_old_value_txt   := :OLD.ACH_TRANS_NO_TXT;                                                                                         
v_new_value_txt   := :NEW.ACH_TRANS_NO_TXT;                                                                                         
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
IF (:NEW.ACTIVE_FLG IS NOT NULL AND :OLD.ACTIVE_FLG IS NULL)                                                                        
OR (:OLD.ACTIVE_FLG IS NOT NULL AND :NEW.ACTIVE_FLG IS NULL)                                                                        
OR (:NEW.ACTIVE_FLG <> :OLD.ACTIVE_FLG) THEN                                                                                        
v_column_name_txt := 'ACTIVE_FLG';                                                                                                  
v_old_value_txt   := :OLD.ACTIVE_FLG;                                                                                               
v_new_value_txt   := :NEW.ACTIVE_FLG;                                                                                               
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
IF (:NEW.ASSIGNED_TEAM_ID IS NOT NULL AND :OLD.ASSIGNED_TEAM_ID IS NULL)                                                            
OR (:OLD.ASSIGNED_TEAM_ID IS NOT NULL AND :NEW.ASSIGNED_TEAM_ID IS NULL)                                                            
OR (:NEW.ASSIGNED_TEAM_ID <> :OLD.ASSIGNED_TEAM_ID) THEN                                                                            
v_column_name_txt := 'ASSIGNED_TEAM_ID';                                                                                            
v_old_value_txt   := :OLD.ASSIGNED_TEAM_ID;                                                                                         
v_new_value_txt   := :NEW.ASSIGNED_TEAM_ID;                                                                                         
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
IF (:NEW.ASSIGNED_USER_ID IS NOT NULL AND :OLD.ASSIGNED_USER_ID IS NULL)                                                            
OR (:OLD.ASSIGNED_USER_ID IS NOT NULL AND :NEW.ASSIGNED_USER_ID IS NULL)                                                            
OR (:NEW.ASSIGNED_USER_ID <> :OLD.ASSIGNED_USER_ID) THEN                                                                            
v_column_name_txt := 'ASSIGNED_USER_ID';                                                                                            
v_old_value_txt   := :OLD.ASSIGNED_USER_ID;                                                                                         
v_new_value_txt   := :NEW.ASSIGNED_USER_ID;                                                                                         
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
IF (:NEW.BRANCH_ASSIGNMENT_TXT IS NOT NULL AND :OLD.BRANCH_ASSIGNMENT_TXT IS NULL)                                                  
OR (:OLD.BRANCH_ASSIGNMENT_TXT IS NOT NULL AND :NEW.BRANCH_ASSIGNMENT_TXT IS NULL)                                                  
OR (:NEW.BRANCH_ASSIGNMENT_TXT <> :OLD.BRANCH_ASSIGNMENT_TXT) THEN                                                                  
v_column_name_txt := 'BRANCH_ASSIGNMENT_TXT';                                                                                       
v_old_value_txt   := :OLD.BRANCH_ASSIGNMENT_TXT;                                                                                    
v_new_value_txt   := :NEW.BRANCH_ASSIGNMENT_TXT;                                                                                    
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
IF (:NEW.CONTACT_TXT IS NOT NULL AND :OLD.CONTACT_TXT IS NULL)                                                                      
OR (:OLD.CONTACT_TXT IS NOT NULL AND :NEW.CONTACT_TXT IS NULL)                                                                      
OR (:NEW.CONTACT_TXT <> :OLD.CONTACT_TXT) THEN                                                                                      
v_column_name_txt := 'CONTACT_TXT';                                                                                                 
v_old_value_txt   := :OLD.CONTACT_TXT;                                                                                              
v_new_value_txt   := :NEW.CONTACT_TXT;                                                                                              
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
IF (:NEW.CONTRACT_TYPE_TXT IS NOT NULL AND :OLD.CONTRACT_TYPE_TXT IS NULL)                                                          
OR (:OLD.CONTRACT_TYPE_TXT IS NOT NULL AND :NEW.CONTRACT_TYPE_TXT IS NULL)                                                          
OR (:NEW.CONTRACT_TYPE_TXT <> :OLD.CONTRACT_TYPE_TXT) THEN                                                                          
v_column_name_txt := 'CONTRACT_TYPE_TXT';                                                                                           
v_old_value_txt   := :OLD.CONTRACT_TYPE_TXT;                                                                                        
v_new_value_txt   := :NEW.CONTRACT_TYPE_TXT;                                                                                        
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
IF (:NEW.COST_CENTER_TXT IS NOT NULL AND :OLD.COST_CENTER_TXT IS NULL)                                                              
OR (:OLD.COST_CENTER_TXT IS NOT NULL AND :NEW.COST_CENTER_TXT IS NULL)                                                              
OR (:NEW.COST_CENTER_TXT <> :OLD.COST_CENTER_TXT) THEN                                                                              
v_column_name_txt := 'COST_CENTER_TXT';                                                                                             
v_old_value_txt   := :OLD.COST_CENTER_TXT;                                                                                          
v_new_value_txt   := :NEW.COST_CENTER_TXT;                                                                                          
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
IF (:NEW.CURRYEAR_NUM IS NOT NULL AND :OLD.CURRYEAR_NUM IS NULL)                                                                    
OR (:OLD.CURRYEAR_NUM IS NOT NULL AND :NEW.CURRYEAR_NUM IS NULL)                                                                    
OR (:NEW.CURRYEAR_NUM <> :OLD.CURRYEAR_NUM) THEN                                                                                    
v_column_name_txt := 'CURRYEAR_NUM';                                                                                                
v_old_value_txt   := :OLD.CURRYEAR_NUM;                                                                                             
v_new_value_txt   := :NEW.CURRYEAR_NUM;                                                                                             
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
IF (:NEW.DBA_NAME_TXT IS NOT NULL AND :OLD.DBA_NAME_TXT IS NULL)                                                                    
OR (:OLD.DBA_NAME_TXT IS NOT NULL AND :NEW.DBA_NAME_TXT IS NULL)                                                                    
OR (:NEW.DBA_NAME_TXT <> :OLD.DBA_NAME_TXT) THEN                                                                                    
v_column_name_txt := 'DBA_NAME_TXT';                                                                                                
v_old_value_txt   := :OLD.DBA_NAME_TXT;                                                                                             
v_new_value_txt   := :NEW.DBA_NAME_TXT;                                                                                             
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
IF (:NEW.DDA_NUM IS NOT NULL AND :OLD.DDA_NUM IS NULL)                                                                              
OR (:OLD.DDA_NUM IS NOT NULL AND :NEW.DDA_NUM IS NULL)                                                                              
OR (:NEW.DDA_NUM <> :OLD.DDA_NUM) THEN                                                                                              
v_column_name_txt := 'DDA_NUM';                                                                                                     
v_old_value_txt   := :OLD.DDA_NUM;                                                                                                  
v_new_value_txt   := :NEW.DDA_NUM;                                                                                                  
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
IF (:NEW.DEALER_RESERVE_ACCOUNT_TXT IS NOT NULL AND :OLD.DEALER_RESERVE_ACCOUNT_TXT IS NULL)                                        
OR (:OLD.DEALER_RESERVE_ACCOUNT_TXT IS NOT NULL AND :NEW.DEALER_RESERVE_ACCOUNT_TXT IS NULL)                                        
OR (:NEW.DEALER_RESERVE_ACCOUNT_TXT <> :OLD.DEALER_RESERVE_ACCOUNT_TXT) THEN                                                        
v_column_name_txt := 'DEALER_RESERVE_ACCOUNT_TXT';                                                                                  
v_old_value_txt   := :OLD.DEALER_RESERVE_ACCOUNT_TXT;                                                                               
v_new_value_txt   := :NEW.DEALER_RESERVE_ACCOUNT_TXT;                                                                               
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
IF (:NEW.DEALER_RESERVE_BONUS_PLAN_TXT IS NOT NULL AND :OLD.DEALER_RESERVE_BONUS_PLAN_TXT IS NULL)                                  
OR (:OLD.DEALER_RESERVE_BONUS_PLAN_TXT IS NOT NULL AND :NEW.DEALER_RESERVE_BONUS_PLAN_TXT IS NULL)                                  
OR (:NEW.DEALER_RESERVE_BONUS_PLAN_TXT <> :OLD.DEALER_RESERVE_BONUS_PLAN_TXT) THEN                                                  
v_column_name_txt := 'DEALER_RESERVE_BONUS_PLAN_TXT';                                                                               
v_old_value_txt   := :OLD.DEALER_RESERVE_BONUS_PLAN_TXT;                                                                            
v_new_value_txt   := :NEW.DEALER_RESERVE_BONUS_PLAN_TXT;                                                                            
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
IF (:NEW.DEALER_RESERVE_METHOD_TXT IS NOT NULL AND :OLD.DEALER_RESERVE_METHOD_TXT IS NULL)                                          
OR (:OLD.DEALER_RESERVE_METHOD_TXT IS NOT NULL AND :NEW.DEALER_RESERVE_METHOD_TXT IS NULL)                                          
OR (:NEW.DEALER_RESERVE_METHOD_TXT <> :OLD.DEALER_RESERVE_METHOD_TXT) THEN                                                          
v_column_name_txt := 'DEALER_RESERVE_METHOD_TXT';                                                                                   
v_old_value_txt   := :OLD.DEALER_RESERVE_METHOD_TXT;                                                                                
v_new_value_txt   := :NEW.DEALER_RESERVE_METHOD_TXT;                                                                                
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
IF (:NEW.DEALER_RESERVE_PLAN_TXT IS NOT NULL AND :OLD.DEALER_RESERVE_PLAN_TXT IS NULL)                                              
OR (:OLD.DEALER_RESERVE_PLAN_TXT IS NOT NULL AND :NEW.DEALER_RESERVE_PLAN_TXT IS NULL)                                              
OR (:NEW.DEALER_RESERVE_PLAN_TXT <> :OLD.DEALER_RESERVE_PLAN_TXT) THEN                                                              
v_column_name_txt := 'DEALER_RESERVE_PLAN_TXT';                                                                                     
v_old_value_txt   := :OLD.DEALER_RESERVE_PLAN_TXT;                                                                                  
v_new_value_txt   := :NEW.DEALER_RESERVE_PLAN_TXT;                                                                                  
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
IF (:NEW.DEALER_RESERVE_PROMO_TXT IS NOT NULL AND :OLD.DEALER_RESERVE_PROMO_TXT IS NULL)                                            
OR (:OLD.DEALER_RESERVE_PROMO_TXT IS NOT NULL AND :NEW.DEALER_RESERVE_PROMO_TXT IS NULL)                                            
OR (:NEW.DEALER_RESERVE_PROMO_TXT <> :OLD.DEALER_RESERVE_PROMO_TXT) THEN                                                            
v_column_name_txt := 'DEALER_RESERVE_PROMO_TXT';                                                                                    
v_old_value_txt   := :OLD.DEALER_RESERVE_PROMO_TXT;                                                                                 
v_new_value_txt   := :NEW.DEALER_RESERVE_PROMO_TXT;                                                                                 
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
IF (:NEW.DLR_FUND_ID IS NOT NULL AND :OLD.DLR_FUND_ID IS NULL)                                                                      
OR (:OLD.DLR_FUND_ID IS NOT NULL AND :NEW.DLR_FUND_ID IS NULL)                                                                      
OR (:NEW.DLR_FUND_ID <> :OLD.DLR_FUND_ID) THEN                                                                                      
v_column_name_txt := 'DLR_FUND_ID';                                                                                                 
v_old_value_txt   := :OLD.DLR_FUND_ID;                                                                                              
v_new_value_txt   := :NEW.DLR_FUND_ID;                                                                                              
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
IF (:NEW.EFTACHNUMBER_TXT IS NOT NULL AND :OLD.EFTACHNUMBER_TXT IS NULL)                                                            
OR (:OLD.EFTACHNUMBER_TXT IS NOT NULL AND :NEW.EFTACHNUMBER_TXT IS NULL)                                                            
OR (:NEW.EFTACHNUMBER_TXT <> :OLD.EFTACHNUMBER_TXT) THEN                                                                            
v_column_name_txt := 'EFTACHNUMBER_TXT';                                                                                            
v_old_value_txt   := :OLD.EFTACHNUMBER_TXT;                                                                                         
v_new_value_txt   := :NEW.EFTACHNUMBER_TXT;                                                                                         
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
IF (:NEW.EMAIL_ADDRESS_TXT IS NOT NULL AND :OLD.EMAIL_ADDRESS_TXT IS NULL)                                                          
OR (:OLD.EMAIL_ADDRESS_TXT IS NOT NULL AND :NEW.EMAIL_ADDRESS_TXT IS NULL)                                                          
OR (:NEW.EMAIL_ADDRESS_TXT <> :OLD.EMAIL_ADDRESS_TXT) THEN                                                                          
v_column_name_txt := 'EMAIL_ADDRESS_TXT';                                                                                           
v_old_value_txt   := :OLD.EMAIL_ADDRESS_TXT;                                                                                        
v_new_value_txt   := :NEW.EMAIL_ADDRESS_TXT;                                                                                        
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
IF (:NEW.EVALUATOR_ID IS NOT NULL AND :OLD.EVALUATOR_ID IS NULL)                                                                    
OR (:OLD.EVALUATOR_ID IS NOT NULL AND :NEW.EVALUATOR_ID IS NULL)                                                                    
OR (:NEW.EVALUATOR_ID <> :OLD.EVALUATOR_ID) THEN                                                                                    
v_column_name_txt := 'EVALUATOR_ID';                                                                                                
v_old_value_txt   := :OLD.EVALUATOR_ID;                                                                                             
v_new_value_txt   := :NEW.EVALUATOR_ID;                                                                                             
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
IF (:NEW.GL_ACCT_TXT IS NOT NULL AND :OLD.GL_ACCT_TXT IS NULL)                                                                      
OR (:OLD.GL_ACCT_TXT IS NOT NULL AND :NEW.GL_ACCT_TXT IS NULL)                                                                      
OR (:NEW.GL_ACCT_TXT <> :OLD.GL_ACCT_TXT) THEN                                                                                      
v_column_name_txt := 'GL_ACCT_TXT';                                                                                                 
v_old_value_txt   := :OLD.GL_ACCT_TXT;                                                                                              
v_new_value_txt   := :NEW.GL_ACCT_TXT;                                                                                              
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
IF (:NEW.GL_CENTER_TXT IS NOT NULL AND :OLD.GL_CENTER_TXT IS NULL)                                                                  
OR (:OLD.GL_CENTER_TXT IS NOT NULL AND :NEW.GL_CENTER_TXT IS NULL)                                                                  
OR (:NEW.GL_CENTER_TXT <> :OLD.GL_CENTER_TXT) THEN                                                                                  
v_column_name_txt := 'GL_CENTER_TXT';                                                                                               
v_old_value_txt   := :OLD.GL_CENTER_TXT;                                                                                            
v_new_value_txt   := :NEW.GL_CENTER_TXT;                                                                                            
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
IF (:NEW.GL_CORP_TXT IS NOT NULL AND :OLD.GL_CORP_TXT IS NULL)                                                                      
OR (:OLD.GL_CORP_TXT IS NOT NULL AND :NEW.GL_CORP_TXT IS NULL)                                                                      
OR (:NEW.GL_CORP_TXT <> :OLD.GL_CORP_TXT) THEN                                                                                      
v_column_name_txt := 'GL_CORP_TXT';                                                                                                 
v_old_value_txt   := :OLD.GL_CORP_TXT;                                                                                              
v_new_value_txt   := :NEW.GL_CORP_TXT;                                                                                              
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
IF (:NEW.MARKET_TXT IS NOT NULL AND :OLD.MARKET_TXT IS NULL)                                                                        
OR (:OLD.MARKET_TXT IS NOT NULL AND :NEW.MARKET_TXT IS NULL)                                                                        
OR (:NEW.MARKET_TXT <> :OLD.MARKET_TXT) THEN                                                                                        
v_column_name_txt := 'MARKET_TXT';                                                                                                  
v_old_value_txt   := :OLD.MARKET_TXT;                                                                                               
v_new_value_txt   := :NEW.MARKET_TXT;                                                                                               
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
IF (:NEW.MEGA_ORIGINATOR_ID IS NOT NULL AND :OLD.MEGA_ORIGINATOR_ID IS NULL)                                                        
OR (:OLD.MEGA_ORIGINATOR_ID IS NOT NULL AND :NEW.MEGA_ORIGINATOR_ID IS NULL)                                                        
OR (:NEW.MEGA_ORIGINATOR_ID <> :OLD.MEGA_ORIGINATOR_ID) THEN                                                                        
v_column_name_txt := 'MEGA_ORIGINATOR_ID';                                                                                          
v_old_value_txt   := :OLD.MEGA_ORIGINATOR_ID;                                                                                       
v_new_value_txt   := :NEW.MEGA_ORIGINATOR_ID;                                                                                       
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
IF (:NEW.ORIGINATOR_CODE_TXT IS NOT NULL AND :OLD.ORIGINATOR_CODE_TXT IS NULL)                                                      
OR (:OLD.ORIGINATOR_CODE_TXT IS NOT NULL AND :NEW.ORIGINATOR_CODE_TXT IS NULL)                                                      
OR (:NEW.ORIGINATOR_CODE_TXT <> :OLD.ORIGINATOR_CODE_TXT) THEN                                                                      
v_column_name_txt := 'ORIGINATOR_CODE_TXT';                                                                                         
v_old_value_txt   := :OLD.ORIGINATOR_CODE_TXT;                                                                                      
v_new_value_txt   := :NEW.ORIGINATOR_CODE_TXT;                                                                                      
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
IF (:NEW.ORIGINATOR_ID IS NOT NULL AND :OLD.ORIGINATOR_ID IS NULL)                                                                  
OR (:OLD.ORIGINATOR_ID IS NOT NULL AND :NEW.ORIGINATOR_ID IS NULL)                                                                  
OR (:NEW.ORIGINATOR_ID <> :OLD.ORIGINATOR_ID) THEN                                                                                  
v_column_name_txt := 'ORIGINATOR_ID';                                                                                               
v_old_value_txt   := :OLD.ORIGINATOR_ID;                                                                                            
v_new_value_txt   := :NEW.ORIGINATOR_ID;                                                                                            
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
IF (:NEW.ORIGINATOR_NAME_TXT IS NOT NULL AND :OLD.ORIGINATOR_NAME_TXT IS NULL)                                                      
OR (:OLD.ORIGINATOR_NAME_TXT IS NOT NULL AND :NEW.ORIGINATOR_NAME_TXT IS NULL)                                                      
OR (:NEW.ORIGINATOR_NAME_TXT <> :OLD.ORIGINATOR_NAME_TXT) THEN                                                                      
v_column_name_txt := 'ORIGINATOR_NAME_TXT';                                                                                         
v_old_value_txt   := :OLD.ORIGINATOR_NAME_TXT;                                                                                      
v_new_value_txt   := :NEW.ORIGINATOR_NAME_TXT;                                                                                      
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
IF (:NEW.ORIGINATOR_TYPE_ID IS NOT NULL AND :OLD.ORIGINATOR_TYPE_ID IS NULL)                                                        
OR (:OLD.ORIGINATOR_TYPE_ID IS NOT NULL AND :NEW.ORIGINATOR_TYPE_ID IS NULL)                                                        
OR (:NEW.ORIGINATOR_TYPE_ID <> :OLD.ORIGINATOR_TYPE_ID) THEN                                                                        
v_column_name_txt := 'ORIGINATOR_TYPE_ID';                                                                                          
v_old_value_txt   := :OLD.ORIGINATOR_TYPE_ID;                                                                                       
v_new_value_txt   := :NEW.ORIGINATOR_TYPE_ID;                                                                                       
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
IF (:NEW.OWNER_TXT IS NOT NULL AND :OLD.OWNER_TXT IS NULL)                                                                          
OR (:OLD.OWNER_TXT IS NOT NULL AND :NEW.OWNER_TXT IS NULL)                                                                          
OR (:NEW.OWNER_TXT <> :OLD.OWNER_TXT) THEN                                                                                          
v_column_name_txt := 'OWNER_TXT';                                                                                                   
v_old_value_txt   := :OLD.OWNER_TXT;                                                                                                
v_new_value_txt   := :NEW.OWNER_TXT;                                                                                                
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
IF (:NEW.PRENOTIFICATION_FLG IS NOT NULL AND :OLD.PRENOTIFICATION_FLG IS NULL)                                                      
OR (:OLD.PRENOTIFICATION_FLG IS NOT NULL AND :NEW.PRENOTIFICATION_FLG IS NULL)                                                      
OR (:NEW.PRENOTIFICATION_FLG <> :OLD.PRENOTIFICATION_FLG) THEN                                                                      
v_column_name_txt := 'PRENOTIFICATION_FLG';                                                                                         
v_old_value_txt   := :OLD.PRENOTIFICATION_FLG;                                                                                      
v_new_value_txt   := :NEW.PRENOTIFICATION_FLG;                                                                                      
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
IF (:NEW.PRIORITY_FLG IS NOT NULL AND :OLD.PRIORITY_FLG IS NULL)                                                                    
OR (:OLD.PRIORITY_FLG IS NOT NULL AND :NEW.PRIORITY_FLG IS NULL)                                                                    
OR (:NEW.PRIORITY_FLG <> :OLD.PRIORITY_FLG) THEN                                                                                    
v_column_name_txt := 'PRIORITY_FLG';                                                                                                
v_old_value_txt   := :OLD.PRIORITY_FLG;                                                                                             
v_new_value_txt   := :NEW.PRIORITY_FLG;                                                                                             
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
IF (:NEW.REGION_ID IS NOT NULL AND :OLD.REGION_ID IS NULL)                                                                          
OR (:OLD.REGION_ID IS NOT NULL AND :NEW.REGION_ID IS NULL)                                                                          
OR (:NEW.REGION_ID <> :OLD.REGION_ID) THEN                                                                                          
v_column_name_txt := 'REGION_ID';                                                                                                   
v_old_value_txt   := :OLD.REGION_ID;                                                                                                
v_new_value_txt   := :NEW.REGION_ID;                                                                                                
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
IF (:NEW.SALES_REP_TXT IS NOT NULL AND :OLD.SALES_REP_TXT IS NULL)                                                                  
OR (:OLD.SALES_REP_TXT IS NOT NULL AND :NEW.SALES_REP_TXT IS NULL)                                                                  
OR (:NEW.SALES_REP_TXT <> :OLD.SALES_REP_TXT) THEN                                                                                  
v_column_name_txt := 'SALES_REP_TXT';                                                                                               
v_old_value_txt   := :OLD.SALES_REP_TXT;                                                                                            
v_new_value_txt   := :NEW.SALES_REP_TXT;                                                                                            
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
IF (:NEW.SALES_SOURCE_TXT IS NOT NULL AND :OLD.SALES_SOURCE_TXT IS NULL)                                                            
OR (:OLD.SALES_SOURCE_TXT IS NOT NULL AND :NEW.SALES_SOURCE_TXT IS NULL)                                                            
OR (:NEW.SALES_SOURCE_TXT <> :OLD.SALES_SOURCE_TXT) THEN                                                                            
v_column_name_txt := 'SALES_SOURCE_TXT';                                                                                            
v_old_value_txt   := :OLD.SALES_SOURCE_TXT;                                                                                         
v_new_value_txt   := :NEW.SALES_SOURCE_TXT;                                                                                         
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
IF (:NEW.SLA_AT_RISK_MINS_NUM IS NOT NULL AND :OLD.SLA_AT_RISK_MINS_NUM IS NULL)                                                    
OR (:OLD.SLA_AT_RISK_MINS_NUM IS NOT NULL AND :NEW.SLA_AT_RISK_MINS_NUM IS NULL)                                                    
OR (:NEW.SLA_AT_RISK_MINS_NUM <> :OLD.SLA_AT_RISK_MINS_NUM) THEN                                                                    
v_column_name_txt := 'SLA_AT_RISK_MINS_NUM';                                                                                        
v_old_value_txt   := :OLD.SLA_AT_RISK_MINS_NUM;                                                                                     
v_new_value_txt   := :NEW.SLA_AT_RISK_MINS_NUM;                                                                                     
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
IF (:NEW.SLA_FAILED_MINS_NUM IS NOT NULL AND :OLD.SLA_FAILED_MINS_NUM IS NULL)                                                      
OR (:OLD.SLA_FAILED_MINS_NUM IS NOT NULL AND :NEW.SLA_FAILED_MINS_NUM IS NULL)                                                      
OR (:NEW.SLA_FAILED_MINS_NUM <> :OLD.SLA_FAILED_MINS_NUM) THEN                                                                      
v_column_name_txt := 'SLA_FAILED_MINS_NUM';                                                                                         
v_old_value_txt   := :OLD.SLA_FAILED_MINS_NUM;                                                                                      
v_new_value_txt   := :NEW.SLA_FAILED_MINS_NUM;                                                                                      
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
IF (:NEW.SLA_FLG IS NOT NULL AND :OLD.SLA_FLG IS NULL)                                                                              
OR (:OLD.SLA_FLG IS NOT NULL AND :NEW.SLA_FLG IS NULL)                                                                              
OR (:NEW.SLA_FLG <> :OLD.SLA_FLG) THEN                                                                                              
v_column_name_txt := 'SLA_FLG';                                                                                                     
v_old_value_txt   := :OLD.SLA_FLG;                                                                                                  
v_new_value_txt   := :NEW.SLA_FLG;                                                                                                  
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
END IF; -- Inserting, Updating or Deleting?                                                                                         
EXCEPTION                                                                                                                           
WHEN OTHERS THEN                                                                                                                    
v_error_num         := SQLCODE;                                                                                                     
v_error_message_txt := SUBSTR(SQLERRM, 1, 235);                                                                                     
RAISE_APPLICATION_ERROR(-20001, ' ERROR ' || v_error_num ||  ' : ' || v_error_message_txt || 'AUD_EVALUATOR_ORIGINATOR_TRG          
aborted.');                                                                                                                         
END;                                                                                                                                
/                                                                                                                                   



DROP TABLE TMP_FUNDING_METHOD;
DROP PROCEDURE addOrigMeth;
DROP PROCEDURE copyFunding;
DROP PROCEDURE addFunding;
DROP PROCEDURE addProduct;

/* END StevenT 07/19/2004 */

/* BEGIN StevenT 07/20/2004 */
UPDATE MSTR_AUTO_MAKE SET auto_make_description_txt = 'Peterbilt' WHERE auto_make_id = 71;
/* END StevenT 07/20/2004 */

/* BEGIN: 07/20/2004 Wei Ma */

INSERT INTO XREF_PRODUCT_RULES (RULE_ID ,PRODUCT_ID ) VALUES (1049 ,7  );
INSERT INTO XREF_PRODUCT_RULES (RULE_ID ,PRODUCT_ID ) VALUES (1049 ,8  );
INSERT INTO XREF_PRODUCT_RULES (RULE_ID ,PRODUCT_ID ) VALUES (1049 ,9  );
INSERT INTO XREF_PRODUCT_RULES (RULE_ID ,PRODUCT_ID ) VALUES (1049 ,10  );
INSERT INTO XREF_PRODUCT_RULES (RULE_ID ,PRODUCT_ID ) VALUES (1049 ,11  );
INSERT INTO XREF_PRODUCT_RULES (RULE_ID ,PRODUCT_ID ) VALUES (1049 ,12  );

/* END: 07/20/2004 Wei Ma */

/* BEGIN: 7/20/2004 Stevet */
ALTER TABLE CREDIT_REQUEST_PAYOFF MODIFY product_id null;
ALTER TABLE CREDIT_REQUEST_FUNDING MODIFY product_id null;
/* END: 7/20/2004 Stevet */

/* BEGIN 07/22/2004 129006 (Mods in client specific sql also)*/
ALTER TABLE EVALUATOR ADD newret_txt VARCHAR2(10);
COMMENT ON COLUMN EVALUATOR.NEWRET_TXT IS 'Return value to be used with new vehicles.';

/* Create temp funding table */
CREATE TABLE  TMP_VG_RETURN(
  EVALUATOR_ID		NUMBER,
  VALUE_GUIDE_ID	NUMBER,
  VG_RETURN_TXT		VARCHAR2(15)
);

/* Copy current funding records to temp file */
CREATE OR REPLACE PROCEDURE copyVG IS

  CURSOR c_vg IS
   SELECT *
   FROM VG_RETURN_VALUES;

  BEGIN

    FOR rec IN c_vg LOOP

      INSERT INTO TMP_VG_RETURN(evaluator_id,value_guide_id,vg_return_txt)
      VALUES(rec.evaluator_id,rec.value_guide_id,rec.vg_return_txt);

    END LOOP; 

  END;
/
execute copyVG;

DROP TABLE VG_RETURN_VALUES;

CREATE TABLE VG_RETURN_VALUES(
  evaluator_id		NUMBER,
  value_guide_id	NUMBER,
  new_used_id		NUMBER,
  vg_return_txt		VARCHAR2(15),
  CONSTRAINT vg_return_pk PRIMARY KEY(evaluator_id,value_guide_id,new_used_id,vg_return_txt),
  CONSTRAINT vg_return_fk1 FOREIGN KEY(evaluator_id,value_guide_id) REFERENCES XREF_EVALUATOR_VALUE_GUIDE(evaluator_id,value_guide_id),
  CONSTRAINT vg_return_fk2 FOREIGN KEY(new_used_id) REFERENCES MSTR_COLLATERAL_AGE_CATEGORY(collateral_age_category_id)
);
COMMENT ON TABLE VG_RETURN_VALUES IS 'Contains return values for each guide to be used in assigning wholesale values.';
COMMENT ON COLUMN VG_RETURN_VALUES.EVALUATOR_ID IS 'Unique internal identifier for a lending company.';
COMMENT ON COLUMN VG_RETURN_VALUES.VALUE_GUIDE_ID IS 'Unique internal identifier for a value guide.';
COMMENT ON COLUMN VG_RETURN_VALUES.VG_RETURN_TXT IS 'Value guide returned field to use for wholesale value assignment.';
COMMENT ON COLUMN VG_RETURN_VALUES.NEW_USED_ID IS 'Indicates the collateral age category.';

CREATE OR REPLACE PROCEDURE insVG IS

  CURSOR c_vg IS
   SELECT *
   FROM TMP_VG_RETURN;

  BEGIN

    FOR rec IN c_vg LOOP

      INSERT INTO VG_RETURN_VALUES(evaluator_id,value_guide_id,new_used_id,vg_return_txt)
      VALUES(rec.evaluator_id,rec.value_guide_id,2,rec.vg_return_txt);

    END LOOP; 

  END;
/
execute insVG;


CREATE OR REPLACE TRIGGER AUD_EVALUATOR_TRG                                                                                         
AFTER INSERT OR UPDATE OR DELETE ON EVALUATOR                                                                                       
FOR EACH ROW                                                                                                                        
DECLARE                                                                                                                             
-- Static insert_credit_request_audit parameters                                                                                    
v_audit_last_updated_dt    DATE;                                                                                                    
v_audit_updated_user_id    VARCHAR2(20);                                                                                            
v_table_name_txt           VARCHAR2(30);                                                                                            
-- Dynamic insert_credit_request_audit parameters                                                                                   
v_column_name_txt          VARCHAR2(30);                                                                                            
v_old_value_txt            VARCHAR2(4000);                                                                                          
v_new_value_txt            VARCHAR2(4000);                                                                                          
v_user_value_txt           VARCHAR2(4000);                                                                                          
-- Error handling                                                                                                                   
v_error_num                NUMBER;                                                                                                  
v_error_message_txt        VARCHAR2(235);                                                                                           
BEGIN                                                                                                                               
-- Initialize common variables                                                                                                      
v_table_name_txt := 'EVALUATOR';                                                                                                    
v_user_value_txt := 'UNKNOWN';                                                                                                      
v_user_value_txt := :NEW.AUDIT_UPDATED_USER_ID;                                                                                     
IF INSERTING OR DELETING THEN                                                                                                       
v_column_name_txt := 'ACH_DFI_ID_TXT';                                                                                              
v_old_value_txt   := :OLD.ACH_DFI_ID_TXT;                                                                                           
v_new_value_txt   := :NEW.ACH_DFI_ID_TXT;                                                                                           
IF INSERTING THEN                                                                                                                   
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
ELSIF DELETING THEN                                                                                                                 
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
'UNKNOWN',                                                                                                                          
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
v_column_name_txt := 'ACTIVE_FLG';                                                                                                  
v_old_value_txt   := :OLD.ACTIVE_FLG;                                                                                               
v_new_value_txt   := :NEW.ACTIVE_FLG;                                                                                               
IF INSERTING THEN                                                                                                                   
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
ELSIF DELETING THEN                                                                                                                 
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
'UNKNOWN',                                                                                                                          
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
v_column_name_txt := 'ALWAYS_CONCUR_FLG';                                                                                           
v_old_value_txt   := :OLD.ALWAYS_CONCUR_FLG;                                                                                        
v_new_value_txt   := :NEW.ALWAYS_CONCUR_FLG;                                                                                        
IF INSERTING THEN                                                                                                                   
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
ELSIF DELETING THEN                                                                                                                 
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
'UNKNOWN',                                                                                                                          
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
v_column_name_txt := 'AUTOMATED_BROKER_FLG';                                                                                        
v_old_value_txt   := :OLD.AUTOMATED_BROKER_FLG;                                                                                     
v_new_value_txt   := :NEW.AUTOMATED_BROKER_FLG;                                                                                     
IF INSERTING THEN                                                                                                                   
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
ELSIF DELETING THEN                                                                                                                 
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
'UNKNOWN',                                                                                                                          
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
v_column_name_txt := 'AUTO_DECISION_FAX_NOTIFY_FLG';                                                                                
v_old_value_txt   := :OLD.AUTO_DECISION_FAX_NOTIFY_FLG;                                                                             
v_new_value_txt   := :NEW.AUTO_DECISION_FAX_NOTIFY_FLG;                                                                             
IF INSERTING THEN                                                                                                                   
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
ELSIF DELETING THEN                                                                                                                 
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
'UNKNOWN',                                                                                                                          
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
v_column_name_txt := 'AUTO_FINANCE_LENDER_FLG';                                                                                     
v_old_value_txt   := :OLD.AUTO_FINANCE_LENDER_FLG;                                                                                  
v_new_value_txt   := :NEW.AUTO_FINANCE_LENDER_FLG;                                                                                  
IF INSERTING THEN                                                                                                                   
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
ELSIF DELETING THEN                                                                                                                 
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
'UNKNOWN',                                                                                                                          
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
v_column_name_txt := 'BACKEND_LENDER_FLG';                                                                                          
v_old_value_txt   := :OLD.BACKEND_LENDER_FLG;                                                                                       
v_new_value_txt   := :NEW.BACKEND_LENDER_FLG;                                                                                       
IF INSERTING THEN                                                                                                                   
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
ELSIF DELETING THEN                                                                                                                 
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
'UNKNOWN',                                                                                                                          
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
v_column_name_txt := 'BATCH_PRINTER_TXT';                                                                                           
v_old_value_txt   := :OLD.BATCH_PRINTER_TXT;                                                                                        
v_new_value_txt   := :NEW.BATCH_PRINTER_TXT;                                                                                        
IF INSERTING THEN                                                                                                                   
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
ELSIF DELETING THEN                                                                                                                 
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
'UNKNOWN',                                                                                                                          
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
v_column_name_txt := 'BBRET_TXT';                                                                                                   
v_old_value_txt   := :OLD.BBRET_TXT;                                                                                                
v_new_value_txt   := :NEW.BBRET_TXT;                                                                                                
IF INSERTING THEN                                                                                                                   
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
ELSIF DELETING THEN                                                                                                                 
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
'UNKNOWN',                                                                                                                          
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
v_column_name_txt := 'BE_USE_GATEWAY_FLG';                                                                                          
v_old_value_txt   := :OLD.BE_USE_GATEWAY_FLG;                                                                                       
v_new_value_txt   := :NEW.BE_USE_GATEWAY_FLG;                                                                                       
IF INSERTING THEN                                                                                                                   
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
ELSIF DELETING THEN                                                                                                                 
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
'UNKNOWN',                                                                                                                          
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
v_column_name_txt := 'BUREAU_COST_CENTER_TXT';                                                                                      
v_old_value_txt   := :OLD.BUREAU_COST_CENTER_TXT;                                                                                   
v_new_value_txt   := :NEW.BUREAU_COST_CENTER_TXT;                                                                                   
IF INSERTING THEN                                                                                                                   
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
ELSIF DELETING THEN                                                                                                                 
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
'UNKNOWN',                                                                                                                          
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
v_column_name_txt := 'BUSINESS_GUAR_REQ_FLG';                                                                                       
v_old_value_txt   := :OLD.BUSINESS_GUAR_REQ_FLG;                                                                                    
v_new_value_txt   := :NEW.BUSINESS_GUAR_REQ_FLG;                                                                                    
IF INSERTING THEN                                                                                                                   
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
ELSIF DELETING THEN                                                                                                                 
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
'UNKNOWN',                                                                                                                          
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
v_column_name_txt := 'CENTRAL_PRO_SERVER_ID';                                                                                       
v_old_value_txt   := :OLD.CENTRAL_PRO_SERVER_ID;                                                                                    
v_new_value_txt   := :NEW.CENTRAL_PRO_SERVER_ID;                                                                                    
IF INSERTING THEN                                                                                                                   
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
ELSIF DELETING THEN                                                                                                                 
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
'UNKNOWN',                                                                                                                          
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
v_column_name_txt := 'CHECK_CODE_TXT';                                                                                              
v_old_value_txt   := :OLD.CHECK_CODE_TXT;                                                                                           
v_new_value_txt   := :NEW.CHECK_CODE_TXT;                                                                                           
IF INSERTING THEN                                                                                                                   
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
ELSIF DELETING THEN                                                                                                                 
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
'UNKNOWN',                                                                                                                          
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
v_column_name_txt := 'CHECK_SITE_ID';                                                                                               
v_old_value_txt   := :OLD.CHECK_SITE_ID;                                                                                            
v_new_value_txt   := :NEW.CHECK_SITE_ID;                                                                                            
IF INSERTING THEN                                                                                                                   
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
ELSIF DELETING THEN                                                                                                                 
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
'UNKNOWN',                                                                                                                          
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
v_column_name_txt := 'CHKLST_ITEM_REQ_WAIVE_CMT_FLG';                                                                               
v_old_value_txt   := :OLD.CHKLST_ITEM_REQ_WAIVE_CMT_FLG;                                                                            
v_new_value_txt   := :NEW.CHKLST_ITEM_REQ_WAIVE_CMT_FLG;                                                                            
IF INSERTING THEN                                                                                                                   
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
ELSIF DELETING THEN                                                                                                                 
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
'UNKNOWN',                                                                                                                          
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
v_column_name_txt := 'COUNTER_DELAY_DAYS_NUM';                                                                                      
v_old_value_txt   := :OLD.COUNTER_DELAY_DAYS_NUM;                                                                                   
v_new_value_txt   := :NEW.COUNTER_DELAY_DAYS_NUM;                                                                                   
IF INSERTING THEN                                                                                                                   
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
ELSIF DELETING THEN                                                                                                                 
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
'UNKNOWN',                                                                                                                          
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
v_column_name_txt := 'COUNTER_PRINTER_TXT';                                                                                         
v_old_value_txt   := :OLD.COUNTER_PRINTER_TXT;                                                                                      
v_new_value_txt   := :NEW.COUNTER_PRINTER_TXT;                                                                                      
IF INSERTING THEN                                                                                                                   
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
ELSIF DELETING THEN                                                                                                                 
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
'UNKNOWN',                                                                                                                          
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
v_column_name_txt := 'CREATE_DATE_DT';                                                                                              
v_old_value_txt   := :OLD.CREATE_DATE_DT;                                                                                           
v_new_value_txt   := :NEW.CREATE_DATE_DT;                                                                                           
IF INSERTING THEN                                                                                                                   
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
ELSIF DELETING THEN                                                                                                                 
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
'UNKNOWN',                                                                                                                          
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
v_column_name_txt := 'DEALERTRACK_POSTURL_TXT';                                                                                     
v_old_value_txt   := :OLD.DEALERTRACK_POSTURL_TXT;                                                                                  
v_new_value_txt   := :NEW.DEALERTRACK_POSTURL_TXT;                                                                                  
IF INSERTING THEN                                                                                                                   
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
ELSIF DELETING THEN                                                                                                                 
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
'UNKNOWN',                                                                                                                          
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
v_column_name_txt := 'DEALERTRACK_PSSWD_TXT';                                                                                       
v_old_value_txt   := :OLD.DEALERTRACK_PSSWD_TXT;                                                                                    
v_new_value_txt   := :NEW.DEALERTRACK_PSSWD_TXT;                                                                                    
IF INSERTING THEN                                                                                                                   
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
ELSIF DELETING THEN                                                                                                                 
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
'UNKNOWN',                                                                                                                          
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
v_column_name_txt := 'DEALERTRACK_USERID_TXT';                                                                                      
v_old_value_txt   := :OLD.DEALERTRACK_USERID_TXT;                                                                                   
v_new_value_txt   := :NEW.DEALERTRACK_USERID_TXT;                                                                                   
IF INSERTING THEN                                                                                                                   
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
ELSIF DELETING THEN                                                                                                                 
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
'UNKNOWN',                                                                                                                          
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
v_column_name_txt := 'DEFVGNEW_ID';                                                                                                 
v_old_value_txt   := :OLD.DEFVGNEW_ID;                                                                                              
v_new_value_txt   := :NEW.DEFVGNEW_ID;                                                                                              
IF INSERTING THEN                                                                                                                   
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
ELSIF DELETING THEN                                                                                                                 
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
'UNKNOWN',                                                                                                                          
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
v_column_name_txt := 'DEFVGUSED_ID';                                                                                                
v_old_value_txt   := :OLD.DEFVGUSED_ID;                                                                                             
v_new_value_txt   := :NEW.DEFVGUSED_ID;                                                                                             
IF INSERTING THEN                                                                                                                   
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
ELSIF DELETING THEN                                                                                                                 
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
'UNKNOWN',                                                                                                                          
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
v_column_name_txt := 'DEL_CP_CONVERT_TO_PAPER_FLG';                                                                                 
v_old_value_txt   := :OLD.DEL_CP_CONVERT_TO_PAPER_FLG;                                                                              
v_new_value_txt   := :NEW.DEL_CP_CONVERT_TO_PAPER_FLG;                                                                              
IF INSERTING THEN                                                                                                                   
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
ELSIF DELETING THEN                                                                                                                 
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
'UNKNOWN',                                                                                                                          
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
v_column_name_txt := 'DOCGEN_REQ_WAIVE_CMT_FLG';                                                                                    
v_old_value_txt   := :OLD.DOCGEN_REQ_WAIVE_CMT_FLG;                                                                                 
v_new_value_txt   := :NEW.DOCGEN_REQ_WAIVE_CMT_FLG;                                                                                 
IF INSERTING THEN                                                                                                                   
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
ELSIF DELETING THEN                                                                                                                 
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
'UNKNOWN',                                                                                                                          
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
v_column_name_txt := 'DR_APP_BUYRATE_FLG';                                                                                          
v_old_value_txt   := :OLD.DR_APP_BUYRATE_FLG;                                                                                       
v_new_value_txt   := :NEW.DR_APP_BUYRATE_FLG;                                                                                       
IF INSERTING THEN                                                                                                                   
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
ELSIF DELETING THEN                                                                                                                 
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
'UNKNOWN',                                                                                                                          
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
v_column_name_txt := 'DR_FLAT_FEE_FLG';                                                                                             
v_old_value_txt   := :OLD.DR_FLAT_FEE_FLG;                                                                                          
v_new_value_txt   := :NEW.DR_FLAT_FEE_FLG;                                                                                          
IF INSERTING THEN                                                                                                                   
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
ELSIF DELETING THEN                                                                                                                 
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
'UNKNOWN',                                                                                                                          
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
v_column_name_txt := 'DUPLICATE_COPY_DAYS_NUM';                                                                                     
v_old_value_txt   := :OLD.DUPLICATE_COPY_DAYS_NUM;                                                                                  
v_new_value_txt   := :NEW.DUPLICATE_COPY_DAYS_NUM;                                                                                  
IF INSERTING THEN                                                                                                                   
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
ELSIF DELETING THEN                                                                                                                 
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
'UNKNOWN',                                                                                                                          
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
v_column_name_txt := 'EVALUATE_CLIENT_ID_TXT';                                                                                      
v_old_value_txt   := :OLD.EVALUATE_CLIENT_ID_TXT;                                                                                   
v_new_value_txt   := :NEW.EVALUATE_CLIENT_ID_TXT;                                                                                   
IF INSERTING THEN                                                                                                                   
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
ELSIF DELETING THEN                                                                                                                 
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
'UNKNOWN',                                                                                                                          
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
v_column_name_txt := 'EVALUATOR_DESCRIPTION_TXT';                                                                                   
v_old_value_txt   := :OLD.EVALUATOR_DESCRIPTION_TXT;                                                                                
v_new_value_txt   := :NEW.EVALUATOR_DESCRIPTION_TXT;                                                                                
IF INSERTING THEN                                                                                                                   
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
ELSIF DELETING THEN                                                                                                                 
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
'UNKNOWN',                                                                                                                          
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
v_column_name_txt := 'EVALUATOR_ID';                                                                                                
v_old_value_txt   := :OLD.EVALUATOR_ID;                                                                                             
v_new_value_txt   := :NEW.EVALUATOR_ID;                                                                                             
IF INSERTING THEN                                                                                                                   
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
ELSIF DELETING THEN                                                                                                                 
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
'UNKNOWN',                                                                                                                          
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
v_column_name_txt := 'EVALUATOR_NAME_TXT';                                                                                          
v_old_value_txt   := :OLD.EVALUATOR_NAME_TXT;                                                                                       
v_new_value_txt   := :NEW.EVALUATOR_NAME_TXT;                                                                                       
IF INSERTING THEN                                                                                                                   
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
ELSIF DELETING THEN                                                                                                                 
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
'UNKNOWN',                                                                                                                          
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
v_column_name_txt := 'EVALUATOR_SHORT_NAME_TXT';                                                                                    
v_old_value_txt   := :OLD.EVALUATOR_SHORT_NAME_TXT;                                                                                 
v_new_value_txt   := :NEW.EVALUATOR_SHORT_NAME_TXT;                                                                                 
IF INSERTING THEN                                                                                                                   
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
ELSIF DELETING THEN                                                                                                                 
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
'UNKNOWN',                                                                                                                          
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
v_column_name_txt := 'EXPIRED_OFFER_DELAY_DAYS_NUM';                                                                                
v_old_value_txt   := :OLD.EXPIRED_OFFER_DELAY_DAYS_NUM;                                                                             
v_new_value_txt   := :NEW.EXPIRED_OFFER_DELAY_DAYS_NUM;                                                                             
IF INSERTING THEN                                                                                                                   
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
ELSIF DELETING THEN                                                                                                                 
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
'UNKNOWN',                                                                                                                          
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
v_column_name_txt := 'EXPIRED_OFFER_PRINTER_TXT';                                                                                   
v_old_value_txt   := :OLD.EXPIRED_OFFER_PRINTER_TXT;                                                                                
v_new_value_txt   := :NEW.EXPIRED_OFFER_PRINTER_TXT;                                                                                
IF INSERTING THEN                                                                                                                   
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
ELSIF DELETING THEN                                                                                                                 
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
'UNKNOWN',                                                                                                                          
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
v_column_name_txt := 'FIRST_PAYMENT_PRINTER_TXT';                                                                                   
v_old_value_txt   := :OLD.FIRST_PAYMENT_PRINTER_TXT;                                                                                
v_new_value_txt   := :NEW.FIRST_PAYMENT_PRINTER_TXT;                                                                                
IF INSERTING THEN                                                                                                                   
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
ELSIF DELETING THEN                                                                                                                 
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
'UNKNOWN',                                                                                                                          
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
v_column_name_txt := 'IMAGE_TXT';                                                                                                   
v_old_value_txt   := :OLD.IMAGE_TXT;                                                                                                
v_new_value_txt   := :NEW.IMAGE_TXT;                                                                                                
IF INSERTING THEN                                                                                                                   
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
ELSIF DELETING THEN                                                                                                                 
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
'UNKNOWN',                                                                                                                          
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
v_column_name_txt := 'IMAGING_INPUT_DIR_TXT';                                                                                       
v_old_value_txt   := :OLD.IMAGING_INPUT_DIR_TXT;                                                                                    
v_new_value_txt   := :NEW.IMAGING_INPUT_DIR_TXT;                                                                                    
IF INSERTING THEN                                                                                                                   
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
ELSIF DELETING THEN                                                                                                                 
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
'UNKNOWN',                                                                                                                          
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
v_column_name_txt := 'IMAGING_OUTPUT_DIR_TXT';                                                                                      
v_old_value_txt   := :OLD.IMAGING_OUTPUT_DIR_TXT;                                                                                   
v_new_value_txt   := :NEW.IMAGING_OUTPUT_DIR_TXT;                                                                                   
IF INSERTING THEN                                                                                                                   
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
ELSIF DELETING THEN                                                                                                                 
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
'UNKNOWN',                                                                                                                          
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
v_column_name_txt := 'KELLEYRET_TXT';                                                                                               
v_old_value_txt   := :OLD.KELLEYRET_TXT;                                                                                            
v_new_value_txt   := :NEW.KELLEYRET_TXT;                                                                                            
IF INSERTING THEN                                                                                                                   
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
ELSIF DELETING THEN                                                                                                                 
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
'UNKNOWN',                                                                                                                          
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
v_column_name_txt := 'NADARET_TXT';                                                                                                 
v_old_value_txt   := :OLD.NADARET_TXT;                                                                                              
v_new_value_txt   := :NEW.NADARET_TXT;                                                                                              
IF INSERTING THEN                                                                                                                   
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
ELSIF DELETING THEN                                                                                                                 
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
'UNKNOWN',                                                                                                                          
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
v_column_name_txt := 'NETWORK_TXT';                                                                                                 
v_old_value_txt   := :OLD.NETWORK_TXT;                                                                                              
v_new_value_txt   := :NEW.NETWORK_TXT;                                                                                              
IF INSERTING THEN                                                                                                                   
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
ELSIF DELETING THEN                                                                                                                 
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
'UNKNOWN',                                                                                                                          
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
v_column_name_txt := 'NET_TO_GROSS_FACTOR_NUM';                                                                                     
v_old_value_txt   := :OLD.NET_TO_GROSS_FACTOR_NUM;                                                                                  
v_new_value_txt   := :NEW.NET_TO_GROSS_FACTOR_NUM;                                                                                  
IF INSERTING THEN                                                                                                                   
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
ELSIF DELETING THEN                                                                                                                 
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
'UNKNOWN',                                                                                                                          
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
v_column_name_txt := 'NEWRET_TXT';                                                                                                  
v_old_value_txt   := :OLD.NEWRET_TXT;                                                                                               
v_new_value_txt   := :NEW.NEWRET_TXT;                                                                                               
IF INSERTING THEN                                                                                                                   
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
ELSIF DELETING THEN                                                                                                                 
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
'UNKNOWN',                                                                                                                          
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
v_column_name_txt := 'NLSU_NAME';                                                                                                   
v_old_value_txt   := :OLD.NLSU_NAME;                                                                                                
v_new_value_txt   := :NEW.NLSU_NAME;                                                                                                
IF INSERTING THEN                                                                                                                   
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
ELSIF DELETING THEN                                                                                                                 
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
'UNKNOWN',                                                                                                                          
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
v_column_name_txt := 'PARENT_EVALUATOR_ID';                                                                                         
v_old_value_txt   := :OLD.PARENT_EVALUATOR_ID;                                                                                      
v_new_value_txt   := :NEW.PARENT_EVALUATOR_ID;                                                                                      
IF INSERTING THEN                                                                                                                   
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
ELSIF DELETING THEN                                                                                                                 
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
'UNKNOWN',                                                                                                                          
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
v_column_name_txt := 'SEND_CONCUR_DEC_FLG';                                                                                         
v_old_value_txt   := :OLD.SEND_CONCUR_DEC_FLG;                                                                                      
v_new_value_txt   := :NEW.SEND_CONCUR_DEC_FLG;                                                                                      
IF INSERTING THEN                                                                                                                   
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
ELSIF DELETING THEN                                                                                                                 
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
'UNKNOWN',                                                                                                                          
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
v_column_name_txt := 'SEND_TO_DEALERTRACK_FLG';                                                                                     
v_old_value_txt   := :OLD.SEND_TO_DEALERTRACK_FLG;                                                                                  
v_new_value_txt   := :NEW.SEND_TO_DEALERTRACK_FLG;                                                                                  
IF INSERTING THEN                                                                                                                   
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
ELSIF DELETING THEN                                                                                                                 
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
'UNKNOWN',                                                                                                                          
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
v_column_name_txt := 'TURNDOWN_DELAY_DAYS_NUM';                                                                                     
v_old_value_txt   := :OLD.TURNDOWN_DELAY_DAYS_NUM;                                                                                  
v_new_value_txt   := :NEW.TURNDOWN_DELAY_DAYS_NUM;                                                                                  
IF INSERTING THEN                                                                                                                   
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
ELSIF DELETING THEN                                                                                                                 
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
'UNKNOWN',                                                                                                                          
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
v_column_name_txt := 'TURNDOWN_PRINTER_TXT';                                                                                        
v_old_value_txt   := :OLD.TURNDOWN_PRINTER_TXT;                                                                                     
v_new_value_txt   := :NEW.TURNDOWN_PRINTER_TXT;                                                                                     
IF INSERTING THEN                                                                                                                   
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
ELSIF DELETING THEN                                                                                                                 
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
'UNKNOWN',                                                                                                                          
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
v_column_name_txt := 'VIN_DECODER_ID';                                                                                              
v_old_value_txt   := :OLD.VIN_DECODER_ID;                                                                                           
v_new_value_txt   := :NEW.VIN_DECODER_ID;                                                                                           
IF INSERTING THEN                                                                                                                   
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
ELSIF DELETING THEN                                                                                                                 
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
'UNKNOWN',                                                                                                                          
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
v_column_name_txt := 'WELCOME_PRINTER_TXT';                                                                                         
v_old_value_txt   := :OLD.WELCOME_PRINTER_TXT;                                                                                      
v_new_value_txt   := :NEW.WELCOME_PRINTER_TXT;                                                                                      
IF INSERTING THEN                                                                                                                   
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
ELSIF DELETING THEN                                                                                                                 
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
'UNKNOWN',                                                                                                                          
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
ELSIF UPDATING THEN                                                                                                                 
IF (:NEW.ACH_DFI_ID_TXT IS NOT NULL AND :OLD.ACH_DFI_ID_TXT IS NULL)                                                                
OR (:OLD.ACH_DFI_ID_TXT IS NOT NULL AND :NEW.ACH_DFI_ID_TXT IS NULL)                                                                
OR (:NEW.ACH_DFI_ID_TXT <> :OLD.ACH_DFI_ID_TXT) THEN                                                                                
v_column_name_txt := 'ACH_DFI_ID_TXT';                                                                                              
v_old_value_txt   := :OLD.ACH_DFI_ID_TXT;                                                                                           
v_new_value_txt   := :NEW.ACH_DFI_ID_TXT;                                                                                           
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
IF (:NEW.ACTIVE_FLG IS NOT NULL AND :OLD.ACTIVE_FLG IS NULL)                                                                        
OR (:OLD.ACTIVE_FLG IS NOT NULL AND :NEW.ACTIVE_FLG IS NULL)                                                                        
OR (:NEW.ACTIVE_FLG <> :OLD.ACTIVE_FLG) THEN                                                                                        
v_column_name_txt := 'ACTIVE_FLG';                                                                                                  
v_old_value_txt   := :OLD.ACTIVE_FLG;                                                                                               
v_new_value_txt   := :NEW.ACTIVE_FLG;                                                                                               
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
IF (:NEW.ALWAYS_CONCUR_FLG IS NOT NULL AND :OLD.ALWAYS_CONCUR_FLG IS NULL)                                                          
OR (:OLD.ALWAYS_CONCUR_FLG IS NOT NULL AND :NEW.ALWAYS_CONCUR_FLG IS NULL)                                                          
OR (:NEW.ALWAYS_CONCUR_FLG <> :OLD.ALWAYS_CONCUR_FLG) THEN                                                                          
v_column_name_txt := 'ALWAYS_CONCUR_FLG';                                                                                           
v_old_value_txt   := :OLD.ALWAYS_CONCUR_FLG;                                                                                        
v_new_value_txt   := :NEW.ALWAYS_CONCUR_FLG;                                                                                        
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
IF (:NEW.AUTOMATED_BROKER_FLG IS NOT NULL AND :OLD.AUTOMATED_BROKER_FLG IS NULL)                                                    
OR (:OLD.AUTOMATED_BROKER_FLG IS NOT NULL AND :NEW.AUTOMATED_BROKER_FLG IS NULL)                                                    
OR (:NEW.AUTOMATED_BROKER_FLG <> :OLD.AUTOMATED_BROKER_FLG) THEN                                                                    
v_column_name_txt := 'AUTOMATED_BROKER_FLG';                                                                                        
v_old_value_txt   := :OLD.AUTOMATED_BROKER_FLG;                                                                                     
v_new_value_txt   := :NEW.AUTOMATED_BROKER_FLG;                                                                                     
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
IF (:NEW.AUTO_DECISION_FAX_NOTIFY_FLG IS NOT NULL AND :OLD.AUTO_DECISION_FAX_NOTIFY_FLG IS NULL)                                    
OR (:OLD.AUTO_DECISION_FAX_NOTIFY_FLG IS NOT NULL AND :NEW.AUTO_DECISION_FAX_NOTIFY_FLG IS NULL)                                    
OR (:NEW.AUTO_DECISION_FAX_NOTIFY_FLG <> :OLD.AUTO_DECISION_FAX_NOTIFY_FLG) THEN                                                    
v_column_name_txt := 'AUTO_DECISION_FAX_NOTIFY_FLG';                                                                                
v_old_value_txt   := :OLD.AUTO_DECISION_FAX_NOTIFY_FLG;                                                                             
v_new_value_txt   := :NEW.AUTO_DECISION_FAX_NOTIFY_FLG;                                                                             
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
IF (:NEW.AUTO_FINANCE_LENDER_FLG IS NOT NULL AND :OLD.AUTO_FINANCE_LENDER_FLG IS NULL)                                              
OR (:OLD.AUTO_FINANCE_LENDER_FLG IS NOT NULL AND :NEW.AUTO_FINANCE_LENDER_FLG IS NULL)                                              
OR (:NEW.AUTO_FINANCE_LENDER_FLG <> :OLD.AUTO_FINANCE_LENDER_FLG) THEN                                                              
v_column_name_txt := 'AUTO_FINANCE_LENDER_FLG';                                                                                     
v_old_value_txt   := :OLD.AUTO_FINANCE_LENDER_FLG;                                                                                  
v_new_value_txt   := :NEW.AUTO_FINANCE_LENDER_FLG;                                                                                  
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
IF (:NEW.BACKEND_LENDER_FLG IS NOT NULL AND :OLD.BACKEND_LENDER_FLG IS NULL)                                                        
OR (:OLD.BACKEND_LENDER_FLG IS NOT NULL AND :NEW.BACKEND_LENDER_FLG IS NULL)                                                        
OR (:NEW.BACKEND_LENDER_FLG <> :OLD.BACKEND_LENDER_FLG) THEN                                                                        
v_column_name_txt := 'BACKEND_LENDER_FLG';                                                                                          
v_old_value_txt   := :OLD.BACKEND_LENDER_FLG;                                                                                       
v_new_value_txt   := :NEW.BACKEND_LENDER_FLG;                                                                                       
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
IF (:NEW.BATCH_PRINTER_TXT IS NOT NULL AND :OLD.BATCH_PRINTER_TXT IS NULL)                                                          
OR (:OLD.BATCH_PRINTER_TXT IS NOT NULL AND :NEW.BATCH_PRINTER_TXT IS NULL)                                                          
OR (:NEW.BATCH_PRINTER_TXT <> :OLD.BATCH_PRINTER_TXT) THEN                                                                          
v_column_name_txt := 'BATCH_PRINTER_TXT';                                                                                           
v_old_value_txt   := :OLD.BATCH_PRINTER_TXT;                                                                                        
v_new_value_txt   := :NEW.BATCH_PRINTER_TXT;                                                                                        
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
IF (:NEW.BBRET_TXT IS NOT NULL AND :OLD.BBRET_TXT IS NULL)                                                                          
OR (:OLD.BBRET_TXT IS NOT NULL AND :NEW.BBRET_TXT IS NULL)                                                                          
OR (:NEW.BBRET_TXT <> :OLD.BBRET_TXT) THEN                                                                                          
v_column_name_txt := 'BBRET_TXT';                                                                                                   
v_old_value_txt   := :OLD.BBRET_TXT;                                                                                                
v_new_value_txt   := :NEW.BBRET_TXT;                                                                                                
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
IF (:NEW.BE_USE_GATEWAY_FLG IS NOT NULL AND :OLD.BE_USE_GATEWAY_FLG IS NULL)                                                        
OR (:OLD.BE_USE_GATEWAY_FLG IS NOT NULL AND :NEW.BE_USE_GATEWAY_FLG IS NULL)                                                        
OR (:NEW.BE_USE_GATEWAY_FLG <> :OLD.BE_USE_GATEWAY_FLG) THEN                                                                        
v_column_name_txt := 'BE_USE_GATEWAY_FLG';                                                                                          
v_old_value_txt   := :OLD.BE_USE_GATEWAY_FLG;                                                                                       
v_new_value_txt   := :NEW.BE_USE_GATEWAY_FLG;                                                                                       
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
IF (:NEW.BUREAU_COST_CENTER_TXT IS NOT NULL AND :OLD.BUREAU_COST_CENTER_TXT IS NULL)                                                
OR (:OLD.BUREAU_COST_CENTER_TXT IS NOT NULL AND :NEW.BUREAU_COST_CENTER_TXT IS NULL)                                                
OR (:NEW.BUREAU_COST_CENTER_TXT <> :OLD.BUREAU_COST_CENTER_TXT) THEN                                                                
v_column_name_txt := 'BUREAU_COST_CENTER_TXT';                                                                                      
v_old_value_txt   := :OLD.BUREAU_COST_CENTER_TXT;                                                                                   
v_new_value_txt   := :NEW.BUREAU_COST_CENTER_TXT;                                                                                   
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
IF (:NEW.BUSINESS_GUAR_REQ_FLG IS NOT NULL AND :OLD.BUSINESS_GUAR_REQ_FLG IS NULL)                                                  
OR (:OLD.BUSINESS_GUAR_REQ_FLG IS NOT NULL AND :NEW.BUSINESS_GUAR_REQ_FLG IS NULL)                                                  
OR (:NEW.BUSINESS_GUAR_REQ_FLG <> :OLD.BUSINESS_GUAR_REQ_FLG) THEN                                                                  
v_column_name_txt := 'BUSINESS_GUAR_REQ_FLG';                                                                                       
v_old_value_txt   := :OLD.BUSINESS_GUAR_REQ_FLG;                                                                                    
v_new_value_txt   := :NEW.BUSINESS_GUAR_REQ_FLG;                                                                                    
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
IF (:NEW.CENTRAL_PRO_SERVER_ID IS NOT NULL AND :OLD.CENTRAL_PRO_SERVER_ID IS NULL)                                                  
OR (:OLD.CENTRAL_PRO_SERVER_ID IS NOT NULL AND :NEW.CENTRAL_PRO_SERVER_ID IS NULL)                                                  
OR (:NEW.CENTRAL_PRO_SERVER_ID <> :OLD.CENTRAL_PRO_SERVER_ID) THEN                                                                  
v_column_name_txt := 'CENTRAL_PRO_SERVER_ID';                                                                                       
v_old_value_txt   := :OLD.CENTRAL_PRO_SERVER_ID;                                                                                    
v_new_value_txt   := :NEW.CENTRAL_PRO_SERVER_ID;                                                                                    
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
IF (:NEW.CHECK_CODE_TXT IS NOT NULL AND :OLD.CHECK_CODE_TXT IS NULL)                                                                
OR (:OLD.CHECK_CODE_TXT IS NOT NULL AND :NEW.CHECK_CODE_TXT IS NULL)                                                                
OR (:NEW.CHECK_CODE_TXT <> :OLD.CHECK_CODE_TXT) THEN                                                                                
v_column_name_txt := 'CHECK_CODE_TXT';                                                                                              
v_old_value_txt   := :OLD.CHECK_CODE_TXT;                                                                                           
v_new_value_txt   := :NEW.CHECK_CODE_TXT;                                                                                           
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
IF (:NEW.CHECK_SITE_ID IS NOT NULL AND :OLD.CHECK_SITE_ID IS NULL)                                                                  
OR (:OLD.CHECK_SITE_ID IS NOT NULL AND :NEW.CHECK_SITE_ID IS NULL)                                                                  
OR (:NEW.CHECK_SITE_ID <> :OLD.CHECK_SITE_ID) THEN                                                                                  
v_column_name_txt := 'CHECK_SITE_ID';                                                                                               
v_old_value_txt   := :OLD.CHECK_SITE_ID;                                                                                            
v_new_value_txt   := :NEW.CHECK_SITE_ID;                                                                                            
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
IF (:NEW.CHKLST_ITEM_REQ_WAIVE_CMT_FLG IS NOT NULL AND :OLD.CHKLST_ITEM_REQ_WAIVE_CMT_FLG IS NULL)                                  
OR (:OLD.CHKLST_ITEM_REQ_WAIVE_CMT_FLG IS NOT NULL AND :NEW.CHKLST_ITEM_REQ_WAIVE_CMT_FLG IS NULL)                                  
OR (:NEW.CHKLST_ITEM_REQ_WAIVE_CMT_FLG <> :OLD.CHKLST_ITEM_REQ_WAIVE_CMT_FLG) THEN                                                  
v_column_name_txt := 'CHKLST_ITEM_REQ_WAIVE_CMT_FLG';                                                                               
v_old_value_txt   := :OLD.CHKLST_ITEM_REQ_WAIVE_CMT_FLG;                                                                            
v_new_value_txt   := :NEW.CHKLST_ITEM_REQ_WAIVE_CMT_FLG;                                                                            
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
IF (:NEW.COUNTER_DELAY_DAYS_NUM IS NOT NULL AND :OLD.COUNTER_DELAY_DAYS_NUM IS NULL)                                                
OR (:OLD.COUNTER_DELAY_DAYS_NUM IS NOT NULL AND :NEW.COUNTER_DELAY_DAYS_NUM IS NULL)                                                
OR (:NEW.COUNTER_DELAY_DAYS_NUM <> :OLD.COUNTER_DELAY_DAYS_NUM) THEN                                                                
v_column_name_txt := 'COUNTER_DELAY_DAYS_NUM';                                                                                      
v_old_value_txt   := :OLD.COUNTER_DELAY_DAYS_NUM;                                                                                   
v_new_value_txt   := :NEW.COUNTER_DELAY_DAYS_NUM;                                                                                   
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
IF (:NEW.COUNTER_PRINTER_TXT IS NOT NULL AND :OLD.COUNTER_PRINTER_TXT IS NULL)                                                      
OR (:OLD.COUNTER_PRINTER_TXT IS NOT NULL AND :NEW.COUNTER_PRINTER_TXT IS NULL)                                                      
OR (:NEW.COUNTER_PRINTER_TXT <> :OLD.COUNTER_PRINTER_TXT) THEN                                                                      
v_column_name_txt := 'COUNTER_PRINTER_TXT';                                                                                         
v_old_value_txt   := :OLD.COUNTER_PRINTER_TXT;                                                                                      
v_new_value_txt   := :NEW.COUNTER_PRINTER_TXT;                                                                                      
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
IF (:NEW.CREATE_DATE_DT IS NOT NULL AND :OLD.CREATE_DATE_DT IS NULL)                                                                
OR (:OLD.CREATE_DATE_DT IS NOT NULL AND :NEW.CREATE_DATE_DT IS NULL)                                                                
OR (:NEW.CREATE_DATE_DT <> :OLD.CREATE_DATE_DT) THEN                                                                                
v_column_name_txt := 'CREATE_DATE_DT';                                                                                              
v_old_value_txt   := :OLD.CREATE_DATE_DT;                                                                                           
v_new_value_txt   := :NEW.CREATE_DATE_DT;                                                                                           
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
IF (:NEW.DEALERTRACK_POSTURL_TXT IS NOT NULL AND :OLD.DEALERTRACK_POSTURL_TXT IS NULL)                                              
OR (:OLD.DEALERTRACK_POSTURL_TXT IS NOT NULL AND :NEW.DEALERTRACK_POSTURL_TXT IS NULL)                                              
OR (:NEW.DEALERTRACK_POSTURL_TXT <> :OLD.DEALERTRACK_POSTURL_TXT) THEN                                                              
v_column_name_txt := 'DEALERTRACK_POSTURL_TXT';                                                                                     
v_old_value_txt   := :OLD.DEALERTRACK_POSTURL_TXT;                                                                                  
v_new_value_txt   := :NEW.DEALERTRACK_POSTURL_TXT;                                                                                  
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
IF (:NEW.DEALERTRACK_PSSWD_TXT IS NOT NULL AND :OLD.DEALERTRACK_PSSWD_TXT IS NULL)                                                  
OR (:OLD.DEALERTRACK_PSSWD_TXT IS NOT NULL AND :NEW.DEALERTRACK_PSSWD_TXT IS NULL)                                                  
OR (:NEW.DEALERTRACK_PSSWD_TXT <> :OLD.DEALERTRACK_PSSWD_TXT) THEN                                                                  
v_column_name_txt := 'DEALERTRACK_PSSWD_TXT';                                                                                       
v_old_value_txt   := :OLD.DEALERTRACK_PSSWD_TXT;                                                                                    
v_new_value_txt   := :NEW.DEALERTRACK_PSSWD_TXT;                                                                                    
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
IF (:NEW.DEALERTRACK_USERID_TXT IS NOT NULL AND :OLD.DEALERTRACK_USERID_TXT IS NULL)                                                
OR (:OLD.DEALERTRACK_USERID_TXT IS NOT NULL AND :NEW.DEALERTRACK_USERID_TXT IS NULL)                                                
OR (:NEW.DEALERTRACK_USERID_TXT <> :OLD.DEALERTRACK_USERID_TXT) THEN                                                                
v_column_name_txt := 'DEALERTRACK_USERID_TXT';                                                                                      
v_old_value_txt   := :OLD.DEALERTRACK_USERID_TXT;                                                                                   
v_new_value_txt   := :NEW.DEALERTRACK_USERID_TXT;                                                                                   
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
IF (:NEW.DEFVGNEW_ID IS NOT NULL AND :OLD.DEFVGNEW_ID IS NULL)                                                                      
OR (:OLD.DEFVGNEW_ID IS NOT NULL AND :NEW.DEFVGNEW_ID IS NULL)                                                                      
OR (:NEW.DEFVGNEW_ID <> :OLD.DEFVGNEW_ID) THEN                                                                                      
v_column_name_txt := 'DEFVGNEW_ID';                                                                                                 
v_old_value_txt   := :OLD.DEFVGNEW_ID;                                                                                              
v_new_value_txt   := :NEW.DEFVGNEW_ID;                                                                                              
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
IF (:NEW.DEFVGUSED_ID IS NOT NULL AND :OLD.DEFVGUSED_ID IS NULL)                                                                    
OR (:OLD.DEFVGUSED_ID IS NOT NULL AND :NEW.DEFVGUSED_ID IS NULL)                                                                    
OR (:NEW.DEFVGUSED_ID <> :OLD.DEFVGUSED_ID) THEN                                                                                    
v_column_name_txt := 'DEFVGUSED_ID';                                                                                                
v_old_value_txt   := :OLD.DEFVGUSED_ID;                                                                                             
v_new_value_txt   := :NEW.DEFVGUSED_ID;                                                                                             
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
IF (:NEW.DEL_CP_CONVERT_TO_PAPER_FLG IS NOT NULL AND :OLD.DEL_CP_CONVERT_TO_PAPER_FLG IS NULL)                                      
OR (:OLD.DEL_CP_CONVERT_TO_PAPER_FLG IS NOT NULL AND :NEW.DEL_CP_CONVERT_TO_PAPER_FLG IS NULL)                                      
OR (:NEW.DEL_CP_CONVERT_TO_PAPER_FLG <> :OLD.DEL_CP_CONVERT_TO_PAPER_FLG) THEN                                                      
v_column_name_txt := 'DEL_CP_CONVERT_TO_PAPER_FLG';                                                                                 
v_old_value_txt   := :OLD.DEL_CP_CONVERT_TO_PAPER_FLG;                                                                              
v_new_value_txt   := :NEW.DEL_CP_CONVERT_TO_PAPER_FLG;                                                                              
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
IF (:NEW.DOCGEN_REQ_WAIVE_CMT_FLG IS NOT NULL AND :OLD.DOCGEN_REQ_WAIVE_CMT_FLG IS NULL)                                            
OR (:OLD.DOCGEN_REQ_WAIVE_CMT_FLG IS NOT NULL AND :NEW.DOCGEN_REQ_WAIVE_CMT_FLG IS NULL)                                            
OR (:NEW.DOCGEN_REQ_WAIVE_CMT_FLG <> :OLD.DOCGEN_REQ_WAIVE_CMT_FLG) THEN                                                            
v_column_name_txt := 'DOCGEN_REQ_WAIVE_CMT_FLG';                                                                                    
v_old_value_txt   := :OLD.DOCGEN_REQ_WAIVE_CMT_FLG;                                                                                 
v_new_value_txt   := :NEW.DOCGEN_REQ_WAIVE_CMT_FLG;                                                                                 
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
IF (:NEW.DR_APP_BUYRATE_FLG IS NOT NULL AND :OLD.DR_APP_BUYRATE_FLG IS NULL)                                                        
OR (:OLD.DR_APP_BUYRATE_FLG IS NOT NULL AND :NEW.DR_APP_BUYRATE_FLG IS NULL)                                                        
OR (:NEW.DR_APP_BUYRATE_FLG <> :OLD.DR_APP_BUYRATE_FLG) THEN                                                                        
v_column_name_txt := 'DR_APP_BUYRATE_FLG';                                                                                          
v_old_value_txt   := :OLD.DR_APP_BUYRATE_FLG;                                                                                       
v_new_value_txt   := :NEW.DR_APP_BUYRATE_FLG;                                                                                       
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
IF (:NEW.DR_FLAT_FEE_FLG IS NOT NULL AND :OLD.DR_FLAT_FEE_FLG IS NULL)                                                              
OR (:OLD.DR_FLAT_FEE_FLG IS NOT NULL AND :NEW.DR_FLAT_FEE_FLG IS NULL)                                                              
OR (:NEW.DR_FLAT_FEE_FLG <> :OLD.DR_FLAT_FEE_FLG) THEN                                                                              
v_column_name_txt := 'DR_FLAT_FEE_FLG';                                                                                             
v_old_value_txt   := :OLD.DR_FLAT_FEE_FLG;                                                                                          
v_new_value_txt   := :NEW.DR_FLAT_FEE_FLG;                                                                                          
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
IF (:NEW.DUPLICATE_COPY_DAYS_NUM IS NOT NULL AND :OLD.DUPLICATE_COPY_DAYS_NUM IS NULL)                                              
OR (:OLD.DUPLICATE_COPY_DAYS_NUM IS NOT NULL AND :NEW.DUPLICATE_COPY_DAYS_NUM IS NULL)                                              
OR (:NEW.DUPLICATE_COPY_DAYS_NUM <> :OLD.DUPLICATE_COPY_DAYS_NUM) THEN                                                              
v_column_name_txt := 'DUPLICATE_COPY_DAYS_NUM';                                                                                     
v_old_value_txt   := :OLD.DUPLICATE_COPY_DAYS_NUM;                                                                                  
v_new_value_txt   := :NEW.DUPLICATE_COPY_DAYS_NUM;                                                                                  
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
IF (:NEW.EVALUATE_CLIENT_ID_TXT IS NOT NULL AND :OLD.EVALUATE_CLIENT_ID_TXT IS NULL)                                                
OR (:OLD.EVALUATE_CLIENT_ID_TXT IS NOT NULL AND :NEW.EVALUATE_CLIENT_ID_TXT IS NULL)                                                
OR (:NEW.EVALUATE_CLIENT_ID_TXT <> :OLD.EVALUATE_CLIENT_ID_TXT) THEN                                                                
v_column_name_txt := 'EVALUATE_CLIENT_ID_TXT';                                                                                      
v_old_value_txt   := :OLD.EVALUATE_CLIENT_ID_TXT;                                                                                   
v_new_value_txt   := :NEW.EVALUATE_CLIENT_ID_TXT;                                                                                   
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
IF (:NEW.EVALUATOR_DESCRIPTION_TXT IS NOT NULL AND :OLD.EVALUATOR_DESCRIPTION_TXT IS NULL)                                          
OR (:OLD.EVALUATOR_DESCRIPTION_TXT IS NOT NULL AND :NEW.EVALUATOR_DESCRIPTION_TXT IS NULL)                                          
OR (:NEW.EVALUATOR_DESCRIPTION_TXT <> :OLD.EVALUATOR_DESCRIPTION_TXT) THEN                                                          
v_column_name_txt := 'EVALUATOR_DESCRIPTION_TXT';                                                                                   
v_old_value_txt   := :OLD.EVALUATOR_DESCRIPTION_TXT;                                                                                
v_new_value_txt   := :NEW.EVALUATOR_DESCRIPTION_TXT;                                                                                
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
IF (:NEW.EVALUATOR_ID IS NOT NULL AND :OLD.EVALUATOR_ID IS NULL)                                                                    
OR (:OLD.EVALUATOR_ID IS NOT NULL AND :NEW.EVALUATOR_ID IS NULL)                                                                    
OR (:NEW.EVALUATOR_ID <> :OLD.EVALUATOR_ID) THEN                                                                                    
v_column_name_txt := 'EVALUATOR_ID';                                                                                                
v_old_value_txt   := :OLD.EVALUATOR_ID;                                                                                             
v_new_value_txt   := :NEW.EVALUATOR_ID;                                                                                             
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
IF (:NEW.EVALUATOR_NAME_TXT IS NOT NULL AND :OLD.EVALUATOR_NAME_TXT IS NULL)                                                        
OR (:OLD.EVALUATOR_NAME_TXT IS NOT NULL AND :NEW.EVALUATOR_NAME_TXT IS NULL)                                                        
OR (:NEW.EVALUATOR_NAME_TXT <> :OLD.EVALUATOR_NAME_TXT) THEN                                                                        
v_column_name_txt := 'EVALUATOR_NAME_TXT';                                                                                          
v_old_value_txt   := :OLD.EVALUATOR_NAME_TXT;                                                                                       
v_new_value_txt   := :NEW.EVALUATOR_NAME_TXT;                                                                                       
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
IF (:NEW.EVALUATOR_SHORT_NAME_TXT IS NOT NULL AND :OLD.EVALUATOR_SHORT_NAME_TXT IS NULL)                                            
OR (:OLD.EVALUATOR_SHORT_NAME_TXT IS NOT NULL AND :NEW.EVALUATOR_SHORT_NAME_TXT IS NULL)                                            
OR (:NEW.EVALUATOR_SHORT_NAME_TXT <> :OLD.EVALUATOR_SHORT_NAME_TXT) THEN                                                            
v_column_name_txt := 'EVALUATOR_SHORT_NAME_TXT';                                                                                    
v_old_value_txt   := :OLD.EVALUATOR_SHORT_NAME_TXT;                                                                                 
v_new_value_txt   := :NEW.EVALUATOR_SHORT_NAME_TXT;                                                                                 
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
IF (:NEW.EXPIRED_OFFER_DELAY_DAYS_NUM IS NOT NULL AND :OLD.EXPIRED_OFFER_DELAY_DAYS_NUM IS NULL)                                    
OR (:OLD.EXPIRED_OFFER_DELAY_DAYS_NUM IS NOT NULL AND :NEW.EXPIRED_OFFER_DELAY_DAYS_NUM IS NULL)                                    
OR (:NEW.EXPIRED_OFFER_DELAY_DAYS_NUM <> :OLD.EXPIRED_OFFER_DELAY_DAYS_NUM) THEN                                                    
v_column_name_txt := 'EXPIRED_OFFER_DELAY_DAYS_NUM';                                                                                
v_old_value_txt   := :OLD.EXPIRED_OFFER_DELAY_DAYS_NUM;                                                                             
v_new_value_txt   := :NEW.EXPIRED_OFFER_DELAY_DAYS_NUM;                                                                             
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
IF (:NEW.EXPIRED_OFFER_PRINTER_TXT IS NOT NULL AND :OLD.EXPIRED_OFFER_PRINTER_TXT IS NULL)                                          
OR (:OLD.EXPIRED_OFFER_PRINTER_TXT IS NOT NULL AND :NEW.EXPIRED_OFFER_PRINTER_TXT IS NULL)                                          
OR (:NEW.EXPIRED_OFFER_PRINTER_TXT <> :OLD.EXPIRED_OFFER_PRINTER_TXT) THEN                                                          
v_column_name_txt := 'EXPIRED_OFFER_PRINTER_TXT';                                                                                   
v_old_value_txt   := :OLD.EXPIRED_OFFER_PRINTER_TXT;                                                                                
v_new_value_txt   := :NEW.EXPIRED_OFFER_PRINTER_TXT;                                                                                
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
IF (:NEW.FIRST_PAYMENT_PRINTER_TXT IS NOT NULL AND :OLD.FIRST_PAYMENT_PRINTER_TXT IS NULL)                                          
OR (:OLD.FIRST_PAYMENT_PRINTER_TXT IS NOT NULL AND :NEW.FIRST_PAYMENT_PRINTER_TXT IS NULL)                                          
OR (:NEW.FIRST_PAYMENT_PRINTER_TXT <> :OLD.FIRST_PAYMENT_PRINTER_TXT) THEN                                                          
v_column_name_txt := 'FIRST_PAYMENT_PRINTER_TXT';                                                                                   
v_old_value_txt   := :OLD.FIRST_PAYMENT_PRINTER_TXT;                                                                                
v_new_value_txt   := :NEW.FIRST_PAYMENT_PRINTER_TXT;                                                                                
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
IF (:NEW.IMAGE_TXT IS NOT NULL AND :OLD.IMAGE_TXT IS NULL)                                                                          
OR (:OLD.IMAGE_TXT IS NOT NULL AND :NEW.IMAGE_TXT IS NULL)                                                                          
OR (:NEW.IMAGE_TXT <> :OLD.IMAGE_TXT) THEN                                                                                          
v_column_name_txt := 'IMAGE_TXT';                                                                                                   
v_old_value_txt   := :OLD.IMAGE_TXT;                                                                                                
v_new_value_txt   := :NEW.IMAGE_TXT;                                                                                                
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
IF (:NEW.IMAGING_INPUT_DIR_TXT IS NOT NULL AND :OLD.IMAGING_INPUT_DIR_TXT IS NULL)                                                  
OR (:OLD.IMAGING_INPUT_DIR_TXT IS NOT NULL AND :NEW.IMAGING_INPUT_DIR_TXT IS NULL)                                                  
OR (:NEW.IMAGING_INPUT_DIR_TXT <> :OLD.IMAGING_INPUT_DIR_TXT) THEN                                                                  
v_column_name_txt := 'IMAGING_INPUT_DIR_TXT';                                                                                       
v_old_value_txt   := :OLD.IMAGING_INPUT_DIR_TXT;                                                                                    
v_new_value_txt   := :NEW.IMAGING_INPUT_DIR_TXT;                                                                                    
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
IF (:NEW.IMAGING_OUTPUT_DIR_TXT IS NOT NULL AND :OLD.IMAGING_OUTPUT_DIR_TXT IS NULL)                                                
OR (:OLD.IMAGING_OUTPUT_DIR_TXT IS NOT NULL AND :NEW.IMAGING_OUTPUT_DIR_TXT IS NULL)                                                
OR (:NEW.IMAGING_OUTPUT_DIR_TXT <> :OLD.IMAGING_OUTPUT_DIR_TXT) THEN                                                                
v_column_name_txt := 'IMAGING_OUTPUT_DIR_TXT';                                                                                      
v_old_value_txt   := :OLD.IMAGING_OUTPUT_DIR_TXT;                                                                                   
v_new_value_txt   := :NEW.IMAGING_OUTPUT_DIR_TXT;                                                                                   
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
IF (:NEW.KELLEYRET_TXT IS NOT NULL AND :OLD.KELLEYRET_TXT IS NULL)                                                                  
OR (:OLD.KELLEYRET_TXT IS NOT NULL AND :NEW.KELLEYRET_TXT IS NULL)                                                                  
OR (:NEW.KELLEYRET_TXT <> :OLD.KELLEYRET_TXT) THEN                                                                                  
v_column_name_txt := 'KELLEYRET_TXT';                                                                                               
v_old_value_txt   := :OLD.KELLEYRET_TXT;                                                                                            
v_new_value_txt   := :NEW.KELLEYRET_TXT;                                                                                            
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
IF (:NEW.NADARET_TXT IS NOT NULL AND :OLD.NADARET_TXT IS NULL)                                                                      
OR (:OLD.NADARET_TXT IS NOT NULL AND :NEW.NADARET_TXT IS NULL)                                                                      
OR (:NEW.NADARET_TXT <> :OLD.NADARET_TXT) THEN                                                                                      
v_column_name_txt := 'NADARET_TXT';                                                                                                 
v_old_value_txt   := :OLD.NADARET_TXT;                                                                                              
v_new_value_txt   := :NEW.NADARET_TXT;                                                                                              
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
IF (:NEW.NETWORK_TXT IS NOT NULL AND :OLD.NETWORK_TXT IS NULL)                                                                      
OR (:OLD.NETWORK_TXT IS NOT NULL AND :NEW.NETWORK_TXT IS NULL)                                                                      
OR (:NEW.NETWORK_TXT <> :OLD.NETWORK_TXT) THEN                                                                                      
v_column_name_txt := 'NETWORK_TXT';                                                                                                 
v_old_value_txt   := :OLD.NETWORK_TXT;                                                                                              
v_new_value_txt   := :NEW.NETWORK_TXT;                                                                                              
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
IF (:NEW.NET_TO_GROSS_FACTOR_NUM IS NOT NULL AND :OLD.NET_TO_GROSS_FACTOR_NUM IS NULL)                                              
OR (:OLD.NET_TO_GROSS_FACTOR_NUM IS NOT NULL AND :NEW.NET_TO_GROSS_FACTOR_NUM IS NULL)                                              
OR (:NEW.NET_TO_GROSS_FACTOR_NUM <> :OLD.NET_TO_GROSS_FACTOR_NUM) THEN                                                              
v_column_name_txt := 'NET_TO_GROSS_FACTOR_NUM';                                                                                     
v_old_value_txt   := :OLD.NET_TO_GROSS_FACTOR_NUM;                                                                                  
v_new_value_txt   := :NEW.NET_TO_GROSS_FACTOR_NUM;                                                                                  
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
IF (:NEW.NEWRET_TXT IS NOT NULL AND :OLD.NEWRET_TXT IS NULL)                                                                        
OR (:OLD.NEWRET_TXT IS NOT NULL AND :NEW.NEWRET_TXT IS NULL)                                                                        
OR (:NEW.NEWRET_TXT <> :OLD.NEWRET_TXT) THEN                                                                                        
v_column_name_txt := 'NEWRET_TXT';                                                                                                  
v_old_value_txt   := :OLD.NEWRET_TXT;                                                                                               
v_new_value_txt   := :NEW.NEWRET_TXT;                                                                                               
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
IF (:NEW.NLSU_NAME IS NOT NULL AND :OLD.NLSU_NAME IS NULL)                                                                          
OR (:OLD.NLSU_NAME IS NOT NULL AND :NEW.NLSU_NAME IS NULL)                                                                          
OR (:NEW.NLSU_NAME <> :OLD.NLSU_NAME) THEN                                                                                          
v_column_name_txt := 'NLSU_NAME';                                                                                                   
v_old_value_txt   := :OLD.NLSU_NAME;                                                                                                
v_new_value_txt   := :NEW.NLSU_NAME;                                                                                                
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
IF (:NEW.PARENT_EVALUATOR_ID IS NOT NULL AND :OLD.PARENT_EVALUATOR_ID IS NULL)                                                      
OR (:OLD.PARENT_EVALUATOR_ID IS NOT NULL AND :NEW.PARENT_EVALUATOR_ID IS NULL)                                                      
OR (:NEW.PARENT_EVALUATOR_ID <> :OLD.PARENT_EVALUATOR_ID) THEN                                                                      
v_column_name_txt := 'PARENT_EVALUATOR_ID';                                                                                         
v_old_value_txt   := :OLD.PARENT_EVALUATOR_ID;                                                                                      
v_new_value_txt   := :NEW.PARENT_EVALUATOR_ID;                                                                                      
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
IF (:NEW.SEND_CONCUR_DEC_FLG IS NOT NULL AND :OLD.SEND_CONCUR_DEC_FLG IS NULL)                                                      
OR (:OLD.SEND_CONCUR_DEC_FLG IS NOT NULL AND :NEW.SEND_CONCUR_DEC_FLG IS NULL)                                                      
OR (:NEW.SEND_CONCUR_DEC_FLG <> :OLD.SEND_CONCUR_DEC_FLG) THEN                                                                      
v_column_name_txt := 'SEND_CONCUR_DEC_FLG';                                                                                         
v_old_value_txt   := :OLD.SEND_CONCUR_DEC_FLG;                                                                                      
v_new_value_txt   := :NEW.SEND_CONCUR_DEC_FLG;                                                                                      
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
IF (:NEW.SEND_TO_DEALERTRACK_FLG IS NOT NULL AND :OLD.SEND_TO_DEALERTRACK_FLG IS NULL)                                              
OR (:OLD.SEND_TO_DEALERTRACK_FLG IS NOT NULL AND :NEW.SEND_TO_DEALERTRACK_FLG IS NULL)                                              
OR (:NEW.SEND_TO_DEALERTRACK_FLG <> :OLD.SEND_TO_DEALERTRACK_FLG) THEN                                                              
v_column_name_txt := 'SEND_TO_DEALERTRACK_FLG';                                                                                     
v_old_value_txt   := :OLD.SEND_TO_DEALERTRACK_FLG;                                                                                  
v_new_value_txt   := :NEW.SEND_TO_DEALERTRACK_FLG;                                                                                  
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
IF (:NEW.TURNDOWN_DELAY_DAYS_NUM IS NOT NULL AND :OLD.TURNDOWN_DELAY_DAYS_NUM IS NULL)                                              
OR (:OLD.TURNDOWN_DELAY_DAYS_NUM IS NOT NULL AND :NEW.TURNDOWN_DELAY_DAYS_NUM IS NULL)                                              
OR (:NEW.TURNDOWN_DELAY_DAYS_NUM <> :OLD.TURNDOWN_DELAY_DAYS_NUM) THEN                                                              
v_column_name_txt := 'TURNDOWN_DELAY_DAYS_NUM';                                                                                     
v_old_value_txt   := :OLD.TURNDOWN_DELAY_DAYS_NUM;                                                                                  
v_new_value_txt   := :NEW.TURNDOWN_DELAY_DAYS_NUM;                                                                                  
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
IF (:NEW.TURNDOWN_PRINTER_TXT IS NOT NULL AND :OLD.TURNDOWN_PRINTER_TXT IS NULL)                                                    
OR (:OLD.TURNDOWN_PRINTER_TXT IS NOT NULL AND :NEW.TURNDOWN_PRINTER_TXT IS NULL)                                                    
OR (:NEW.TURNDOWN_PRINTER_TXT <> :OLD.TURNDOWN_PRINTER_TXT) THEN                                                                    
v_column_name_txt := 'TURNDOWN_PRINTER_TXT';                                                                                        
v_old_value_txt   := :OLD.TURNDOWN_PRINTER_TXT;                                                                                     
v_new_value_txt   := :NEW.TURNDOWN_PRINTER_TXT;                                                                                     
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
IF (:NEW.VIN_DECODER_ID IS NOT NULL AND :OLD.VIN_DECODER_ID IS NULL)                                                                
OR (:OLD.VIN_DECODER_ID IS NOT NULL AND :NEW.VIN_DECODER_ID IS NULL)                                                                
OR (:NEW.VIN_DECODER_ID <> :OLD.VIN_DECODER_ID) THEN                                                                                
v_column_name_txt := 'VIN_DECODER_ID';                                                                                              
v_old_value_txt   := :OLD.VIN_DECODER_ID;                                                                                           
v_new_value_txt   := :NEW.VIN_DECODER_ID;                                                                                           
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
IF (:NEW.WELCOME_PRINTER_TXT IS NOT NULL AND :OLD.WELCOME_PRINTER_TXT IS NULL)                                                      
OR (:OLD.WELCOME_PRINTER_TXT IS NOT NULL AND :NEW.WELCOME_PRINTER_TXT IS NULL)                                                      
OR (:NEW.WELCOME_PRINTER_TXT <> :OLD.WELCOME_PRINTER_TXT) THEN                                                                      
v_column_name_txt := 'WELCOME_PRINTER_TXT';                                                                                         
v_old_value_txt   := :OLD.WELCOME_PRINTER_TXT;                                                                                      
v_new_value_txt   := :NEW.WELCOME_PRINTER_TXT;                                                                                      
Insert_CONFIG_MAINT_AUDIT(                                                                                                          
SYSDATE,                                                                                                                            
v_user_value_txt,                                                                                                                   
v_table_name_txt,                                                                                                                   
v_column_name_txt,                                                                                                                  
v_old_value_txt,                                                                                                                    
v_new_value_txt);                                                                                                                   
END IF;                                                                                                                             
END IF; -- Inserting, Updating or Deleting?                                                                                         
EXCEPTION                                                                                                                           
WHEN OTHERS THEN                                                                                                                    
v_error_num         := SQLCODE;                                                                                                     
v_error_message_txt := SUBSTR(SQLERRM, 1, 235);                                                                                     
RAISE_APPLICATION_ERROR(-20001, ' ERROR ' || v_error_num ||  ' : ' || v_error_message_txt || 'AUD_EVALUATOR_TRG aborted.');         
END;                                                                                                                                
/   


DROP PROCEDURE copyVG;
DROP PROCEDURE insVG;
DROP TABLE TMP_VG_RETURN;
/* END 07/22/2004 */

/* BEGIN Julio Jimenez Cl# 128983 07/22/04 */

CREATE TABLE mstr_dealer_type
(  
  DEALER_TYPE_ID               NUMBER        NOT NULL,
  DEALER_TYPE_DESCRIPTION_TXT  VARCHAR2(30 BYTE) NOT NULL,
  ACTIVE_FLG                      NUMBER(1)     DEFAULT 1,
  CONSTRAINT DEALER_TYPE_PK1 PRIMARY KEY (DEALER_TYPE_ID)
);

COMMENT ON COLUMN MSTR_DEALER_TYPE.DEALER_TYPE_ID IS 'Unique internal identifier for values to calculate fees in eValuate';
COMMENT ON COLUMN MSTR_DEALER_TYPE.DEALER_TYPE_DESCRIPTION_TXT IS 'Description for the Dealer type';
COMMENT ON COLUMN MSTR_DEALER_TYPE.ACTIVE_FLG IS 'Flag indicating whether the dealer type is active.';

INSERT INTO MSTR_DEALER_TYPE (dealer_type_id, dealer_type_description_txt, active_flg)
values(1,'Franchise',1);
INSERT INTO MSTR_DEALER_TYPE (dealer_type_id, dealer_type_description_txt, active_flg)
values(2,'Independent',1);
INSERT INTO MSTR_DEALER_TYPE (dealer_type_id, dealer_type_description_txt, active_flg)
values(3,'Captive',1);

ALTER TABLE EVALUATOR_ORIGINATOR ADD (DEALER_TYPE_ID NUMBER);
COMMENT ON COLUMN EVALUATOR_ORIGINATOR.DEALER_TYPE_ID IS 'Unique internal identifies for values to calculate fees in evaluate';

/* END  07/22/04 Julio Jimenez */


/* BEGIN 7/23/2004 Akash Pandya */

CREATE TABLE config_expired_offer
(
  evaluator_id              NUMBER,
  product_id          NUMBER,
  expired_offer_delay_days_num number,
  constraint  config_expired_offer_pk primary key(evaluator_id,product_id),
  constraint  config_expired_offer_fk foreign key (evaluator_id,product_id) references  XREF_EVALUATOR_PRODUCT (evaluator_id,product_id)
) ;

COMMENT ON table config_expired_offer    IS 'Configure expired offer.';
COMMENT ON COLUMN config_expired_offer.evaluator_id   IS 'Unique internal identifier for a lending company.';
COMMENT ON COLUMN config_expired_offer.product_id IS  'Unique internal identifier for a product.';
COMMENT ON COLUMN config_expired_offer.expired_offer_delay_days_num IS  'Number in days offer will be expired for product.';

/* END 7/23/2004 Akash Pandya */

/* BEGIN: Dave Kelly 07/23/2004 */
/* Update the RELATIONSHIP_DESCRIPTION_TXT field from 10 characters to 30 for LoanAppRq */

UPDATE  XML_FIELDS SET LENGTH_NUM = 30 WHERE TRANSACTION_TYPE_ID = 'LoanAppRq'
AND DB_TABLE_SEQ_NUM = 2 AND FIELD_SEQ_NUM = 20;

/* END 07/23/2004 Dave Kelly */

/* BEGIN - StevenT 07/26/2004 */
ALTER TABLE CREDIT_REQ_AUTO_MAN ADD (MILEAGE_VALUE_NUM NUMBER(14,2));
COMMENT ON COLUMN CREDIT_REQ_AUTO_MAN.mileage_value_num IS 'Amount to be added or deducted from invoice for mileage.';
/* END - StevenT 07/26/2004 */

/* BEGIN: Dave Kelly 07/27/2004 */
/* Update the RELATIONSHIP_DESCRIPTION_TXT field from 10 characters to 30 for LoanAppRq */
/* Needed to update the REQUESTOR_RELATIVES table as well as REQUESTOR from above */

UPDATE  XML_FIELDS SET LENGTH_NUM = 30 WHERE TRANSACTION_TYPE_ID = 'LoanAppRq'
AND DB_TABLE_SEQ_NUM = 4 AND FIELD_SEQ_NUM = 7;

/* END 07/27/2004 Dave Kelly */

/* BEGIN 7/27/2004 Akash Pandya */


update MSTR_PRODUCT 
set PRODUCT_SHORT_NAME_TXT = 'DMISC'
where product_id = 13;

update  MSTR_PRODUCT 
set PRODUCT_SHORT_NAME_TXT = 'DMANH'
where product_id = 14;

update  MSTR_PRODUCT 
set PRODUCT_SHORT_NAME_TXT = 'IMANH'
where product_id = 15;

update MSTR_PRODUCT 
set PRODUCT_SHORT_NAME_TXT = 'DUNSEC'
where product_id = 18;


/* END 7/27/2004 Akash Pandya */


/* BEGIN: Dave Kelly 7/29/2004 */
/* Delete value guide procedures if they're still there. */

set heading off
set feedback off
set pagesize 0
set linesize 135

spool tmp_delete_invalid_procedures.sql

select 'alter ' || object_type || ' ' || object_name || ' compile;'
from   user_objects
where  object_type = 'PROCEDURE'
and object_name in ('BB_NEW_LOGIC', 'BB_NEW_MODEL', 'BB_NEW_OPTIONAL', 'CREATE_KELLEY_NEW', 'CREATE_KELLEY_USED', 'CREATE_KELLEY_USED_MODEL');

spool off

set pagesize 35
set feedback 6
set heading on

@tmp_delete_invalid_procedures.sql

commit;

/* END: Dave Kelly 7/29/2004 */



