/* origdiff41_r34_r38.sql - Note: No changes from r29 thru r38 */

/* BEGIN: 6/29/04 Dave Kelly */
/* Added for Allison */

Create or Replace view max_deler_reserve_view as
SELECT 
CRDR.REQUEST_ID,
CRDR.ADJ_RESERVE_AMT_NUM, 
CRDR.SEQ_ID
FROM   CREDIT_REQ_DEALER_RESERVE CRDR
WHERE  CRDR.SEQ_ID   =  (Select max(seq_id) from credit_req_dealer_reserve where request_id = CRDR.REQUEST_ID);

/* END: 6/29/04 Dave Kelly */


/* BEGIN: GLENN 06/29/04 */

/* expell simple_int_num and calc_simple_int_num */

INSERT INTO XML_FIELDS ( TRANSACTION_TYPE_ID, DB_TABLE_SEQ_NUM, FIELD_SEQ_NUM, PATH_TXT, ACTION_TXT,
LENGTH_NUM, KEY_FLG, DB_FIELD_NAME_TXT, REQUIRED_FLG, DESCRIPTION_TXT, ATTRIBUTE_NAME_TXT,
NODE_TYPE_ID, PARENT_KEY_FIELD_TXT, PROCESS_IN_FLG, PROCESS_OUT_FLG, OUT_VALUE_TXT,
ALLOW_EMPTY_OUT_FLG, WRITE_VAR_TXT, VALIDATE_IN_FLG, XML_DATA_TYPE_TXT, DB_DATA_TYPE_TXT,
DEFAULT_IN_VALUE_TXT, PRECISION_NUM ) VALUES ( 
'LoanAppRq', 70, 10, '../Disclosure/SimpleRate',NULL, 15, 0, 'SIMPLE_INT_NUM', 0,null,null,1, NULL, 
1, 1, NULL, 0, NULL, 1, 'number', 'number', NULL, 2);  

INSERT INTO XML_FIELDS ( TRANSACTION_TYPE_ID, DB_TABLE_SEQ_NUM, FIELD_SEQ_NUM, PATH_TXT, ACTION_TXT,
LENGTH_NUM, KEY_FLG, DB_FIELD_NAME_TXT, REQUIRED_FLG, DESCRIPTION_TXT, ATTRIBUTE_NAME_TXT,
NODE_TYPE_ID, PARENT_KEY_FIELD_TXT, PROCESS_IN_FLG, PROCESS_OUT_FLG, OUT_VALUE_TXT,
ALLOW_EMPTY_OUT_FLG, WRITE_VAR_TXT, VALIDATE_IN_FLG, XML_DATA_TYPE_TXT, DB_DATA_TYPE_TXT,
DEFAULT_IN_VALUE_TXT, PRECISION_NUM ) VALUES ( 
'LoanAppRq', 70, 11, '../Disclosure/CalcSimpleRate',NULL, 15, 0, 'CALC_SIMPLE_INT_NUM', 0,null,null,1, NULL, 
1, 1, NULL, 0, NULL, 1, 'number', 'number', NULL, 2);  

/* END: GLENN 06/29/04 */


/* BEGIN: 07/09/2004 Glenn Leyba */

/* expell credit_req_contr_fin.calc_cash_balance_num for SST */

INSERT INTO XML_FIELDS ( TRANSACTION_TYPE_ID, DB_TABLE_SEQ_NUM, FIELD_SEQ_NUM, PATH_TXT, ACTION_TXT,
LENGTH_NUM, KEY_FLG, DB_FIELD_NAME_TXT, REQUIRED_FLG, DESCRIPTION_TXT, ATTRIBUTE_NAME_TXT,
NODE_TYPE_ID, PARENT_KEY_FIELD_TXT, PROCESS_IN_FLG, PROCESS_OUT_FLG, OUT_VALUE_TXT,
ALLOW_EMPTY_OUT_FLG, WRITE_VAR_TXT, VALIDATE_IN_FLG, XML_DATA_TYPE_TXT, DB_DATA_TYPE_TXT,
DEFAULT_IN_VALUE_TXT, PRECISION_NUM ) VALUES ( 
'LoanAppRq', 70, 236, '../CalcCashBalance',NULL, 0, 0, 'CALC_CASH_BALANCE_NUM', 0,null,null,1, NULL, 
0, 1, NULL, 0, NULL, 0, 'number', 'number', NULL, 2);  

/* END: 07/09/2004 Glenn Leyba */

/* BEGIN: 07/12/2004 Toddm */

/* expell credit_req_contr_fin.admin_fee_num for SST */

INSERT INTO XML_FIELDS ( TRANSACTION_TYPE_ID, DB_TABLE_SEQ_NUM, FIELD_SEQ_NUM, PATH_TXT, ACTION_TXT,
LENGTH_NUM, KEY_FLG, DB_FIELD_NAME_TXT, REQUIRED_FLG, DESCRIPTION_TXT, ATTRIBUTE_NAME_TXT,
NODE_TYPE_ID, PARENT_KEY_FIELD_TXT, PROCESS_IN_FLG, PROCESS_OUT_FLG, OUT_VALUE_TXT,
ALLOW_EMPTY_OUT_FLG, WRITE_VAR_TXT, VALIDATE_IN_FLG, XML_DATA_TYPE_TXT, DB_DATA_TYPE_TXT,
DEFAULT_IN_VALUE_TXT, PRECISION_NUM ) VALUES ( 
'LoanAppRq', 70, 237, '../AdminFee',NULL, 0, 0, 'ADMIN_FEE_NUM',0,null,null,1, NULL, 
0, 1, NULL, 0, NULL, 0, 'number', 'number', NULL, 2);  

/* END: 07/12/2004 Glenn Leyba */

/* BEGIN: 07/13/2004 Dave Kelly */

/* Modify contract table to match credit_request_auto model_txt size. Clientele Issue #128827 */

ALTER TABLE CREDIT_REQ_CONTR_AUTO MODIFY MODEL_TXT VARCHAR2(50);

/* END: 07/13/2004 Dave Kelly */

/* BEGIN: 07/20/2004 Wei Ma */

/* Itemized Total Down is equal to Reg Z Total Down, compl rule 1043 */

INSERT INTO MSTR_RULE (RULE_ID ,RULE_CATEGORY_ID ,RULE_NAME_TXT ,ACTION_MODULE_TXT ,PRESENTATION_NUM ,RULE_DESCRIPTION_TXT ,RULE_CONSEQUENCE_ID ,DB_DATA_TYPE_TXT ,DB_FIELD_NAME_TXT ,COUNTRY_TXT ) VALUES 
(1049 ,-1 ,'Itemized Total Down <> Reg Z Total Down' ,'act_rule_compl_contracttotaldown.cfm' ,null ,'Itemized Total Down <> Reg Z Total Down' ,1 ,'number' ,'total_down_num' ,'USA'  );

INSERT INTO XREF_PRODUCT_RULES (RULE_ID ,PRODUCT_ID ) VALUES (1049 ,1  );
INSERT INTO XREF_PRODUCT_RULES (RULE_ID ,PRODUCT_ID ) VALUES (1049 ,2  );
INSERT INTO XREF_PRODUCT_RULES (RULE_ID ,PRODUCT_ID ) VALUES (1049 ,3  );
INSERT INTO XREF_PRODUCT_RULES (RULE_ID ,PRODUCT_ID ) VALUES (1049 ,4  );

/* END: 07/20/2004 Wei Ma */

/* BEGIN Dave Kelly 07/21/2004 */
/* Added view for Allison for ACC */

Create or Replace view max_decision_ref_id_acc_view as
SELECT
CR.REQUEST_ID,
CR.STATUS_ID,
CR.SOURCE_ID,
CR.PRODUCT_ID,
CR.INITIATION_DT-0.125 INIT_DATE,
CR.CLIENT_APP_ID,
CRDE.EVALUATOR_ID,
CRDE.DECISIONED_BY_USER_ID,	
' ' APPROVED_SCORE_TXT,
CRDE.SEND_DT,
CRDE.DECISION_ID,
CRDE.CREATE_DT,
CRDE.DECISION_REF_ID,
CRDE.DECISION_CATEGORY_ID,
CRDE.LENDERLINK_EVALUATOR_ID,
calc_total_financed_num( CRDE.request_id, CRDE.evaluator_id) total_financed_num
FROM  CREDIT_REQ_DECISIONS_EVALUATOR CRDE, CREDIT_REQUEST CR
WHERE 
  CR.REQUEST_ID = CRDE.REQUEST_ID AND
  crde.decision_ref_id = (select max(decision_ref_id) from credit_req_decisions_evaluator
where  request_id = crde.request_id and DECISION_CATEGORY_ID in (1,2,3) );
/

/* END: Dave Kelly 07/21/2004 */


/* BEGIN: Dave Kelly 07/21/04 */

CREATE OR REPLACE PROCEDURE Contract_Verif_Auto_Collateral
(IN_evaluator_id IN NUMBER,IN_request_id IN NUMBER) AS

  x NUMBER(1);
  y NUMBER(1);
  z NUMBER(1);
  t NUMBER(1);
  u NUMBER(1);
  w NUMBER(1);
  v_crcc_cnt number(1);


  v_count NUMBER(1);
  NextCatID NUMBER(2);
  v_cat_id  NUMBER(1);
  v_verif_cat NUMBER(1);
  nextverifnum NUMBER(2);

  CURSOR c_getcollateral IS
  SELECT collateral_request_id, collateral_type_id
  FROM CREDIT_REQUEST_COLLATERAL
  WHERE  request_id  =   IN_request_id;

  CURSOR c_getprimaryauto IS
  SELECT credit_request_auto_id,collateral_request_id,new_used_flg,vin_txt,primary_flg,year_num,auto_make_id,model_txt,model_detail_txt,mileage_num,invoice_cost_num,msrp_num
  FROM CREDIT_REQUEST_AUTO
  WHERE request_id   = IN_request_id
  AND   primary_flg  = 1;

  CURSOR c_getauto IS
  SELECT credit_request_auto_id,collateral_request_id,new_used_flg,vin_txt,primary_flg,year_num,auto_make_id,model_txt,model_detail_txt,mileage_num,invoice_cost_num,msrp_num
  FROM CREDIT_REQUEST_AUTO
  WHERE request_id     = IN_request_id
  AND   (primary_flg    IS NULL OR primary_flg = 0)
  AND  include_in_ltv_flg = 1;

  BEGIN

  u := 0;
  nextcatid := 25;

  FOR rec IN c_getcollateral LOOP

	 SELECT COUNT(*) INTO u
	 FROM CREDIT_REQ_CONTR_VERIF_CAT
	 WHERE evaluator_id = IN_evaluator_id
	 AND   request_id   = IN_request_id
	 AND   collateral_request_id = rec.collateral_request_id;

	 IF u = 0 THEN

	 	SELECT COUNT(*) INTO v_crcc_cnt
	 	FROM CREDIT_REQ_CONTR_COLLATERAL
	 	WHERE request_id   = IN_request_id
	 	AND   collateral_request_id = rec.collateral_request_id;

		IF v_crcc_cnt = 0 THEN

		BEGIN
          		INSERT INTO CREDIT_REQ_CONTR_COLLATERAL (request_id,collateral_request_id,collateral_type_id,evaluator_id)
                        				 VALUES (IN_request_id,rec.collateral_request_id,rec.collateral_type_id,IN_evaluator_id);
		END;
	 END IF;
     END IF;

  END LOOP;

  u := 0;
  FOR rec IN c_getprimaryauto LOOP

     SELECT COUNT(*) INTO u
	 FROM CREDIT_REQ_CONTR_VERIF_CAT
	 WHERE evaluator_id           = IN_evaluator_id
	 AND   request_id             = IN_request_id
	 AND   collateral_request_id  = rec.collateral_request_id
	 AND   credit_request_auto_id = rec.credit_request_auto_id;

     IF u = 0 THEN

	    SELECT NVL(MAX(contr_verif_num),0)+1 INTO nextverifnum
		FROM  CREDIT_REQ_CONTR_VERIF_CAT
		WHERE evaluator_id          = IN_evaluator_id
		AND   request_id 			= IN_request_id;

	    BEGIN

          INSERT INTO CREDIT_REQ_CONTR_AUTO (request_id,collateral_request_id,credit_request_auto_id,year_num,new_used_flg,auto_make_id,model_txt,vin_txt,mileage_num,model_detail_txt,invoice_cost_num,msrp_num)
                                     VALUES (IN_request_id,rec.collateral_request_id,rec.credit_request_auto_id,rec.year_num,rec.new_used_flg,rec.auto_make_id,rec.model_txt,rec.vin_txt,rec.mileage_num,rec.model_detail_txt,rec.invoice_cost_num,rec.msrp_num);

          INSERT INTO CREDIT_REQ_CONTR_VERIF_CAT (evaluator_id,request_id,collateral_request_id,credit_request_auto_id,verif_category_id,contr_verif_num)
			                          VALUES (IN_evaluator_id,IN_request_id,rec.collateral_request_id,rec.credit_request_auto_id,nextcatid,nextverifnum);

	    END;

	 END IF;
     nextcatid :=  nextcatid + 1;
  END LOOP;

  u := 0;
  FOR rec IN c_getauto LOOP

	 SELECT COUNT(*) INTO u
	 FROM CREDIT_REQ_CONTR_VERIF_CAT
	 WHERE evaluator_id           = IN_evaluator_id
	 AND   request_id             = IN_request_id
	 AND   collateral_request_id  = rec.collateral_request_id
	 AND   credit_request_auto_id = rec.credit_request_auto_id;

	 IF u = 1 THEN
	    BEGIN

		   SELECT NVL(MAX(verif_category_id + 1), 5) INTO NextcatId
	       FROM CREDIT_REQ_CONTR_VERIF_CAT
	       WHERE evaluator_id           = IN_evaluator_id
	       AND   request_id             = IN_request_id
	       AND   collateral_request_id  = rec.collateral_request_id
	       AND   credit_request_auto_id = rec.credit_request_auto_id;

		END;

     END IF;

	 IF u = 0 THEN

	    SELECT NVL(MAX(contr_verif_num),0)+1 INTO nextverifnum
		FROM  CREDIT_REQ_CONTR_VERIF_CAT
		WHERE evaluator_id          = IN_evaluator_id
		AND   request_id 			= IN_request_id;

	    BEGIN

          INSERT INTO CREDIT_REQ_CONTR_AUTO (request_id,collateral_request_id,credit_request_auto_id,year_num,new_used_flg,auto_make_id,model_txt,vin_txt,mileage_num,model_detail_txt,invoice_cost_num,msrp_num)
                                     VALUES (IN_request_id,rec.collateral_request_id,rec.credit_request_auto_id,rec.year_num,rec.new_used_flg,rec.auto_make_id,rec.model_txt,rec.vin_txt,rec.mileage_num,rec.model_detail_txt,rec.invoice_cost_num,rec.msrp_num);

          INSERT INTO CREDIT_REQ_CONTR_VERIF_CAT (evaluator_id,request_id,collateral_request_id,credit_request_auto_id,verif_category_id,contr_verif_num)
			                            VALUES (IN_evaluator_id,IN_request_id,rec.collateral_request_id,rec.credit_request_auto_id,nextcatid,nextverifnum);

	      nextcatid :=  nextcatid + 1;
	    END;

     END IF;
  END LOOP;

END;
/


/* END: Dave Kelly 07/21/04 */

/* BEGIN: Jon Miller 07/23/04 */
ALTER TABLE REQUESTOR_BUREAU_SUMMARY ADD(TRADE_DEBT_NUM NUMBER(14,2));
COMMENT ON COLUMN REQUESTOR_BUREAU_SUMMARY.TRADE_DEBT_NUM IS 'Trade debt from eValuate.';
/* END: Jon Miller 07/23/04 */

