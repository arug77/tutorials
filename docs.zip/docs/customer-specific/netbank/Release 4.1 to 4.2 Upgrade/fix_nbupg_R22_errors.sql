-- fix_nbupg_R22_errors.sql

/* ERROR 1
CREATE OR REPLACE PROCEDURE copyFunding IS
*
ERROR at line 1:
ORA-01031: insufficient privileges


BEGIN copyFunding; END;

      *
ERROR at line 1:
ORA-06550: line 1, column 7:
PLS-00201: identifier 'COPYFUNDING' must be declared
ORA-06550: line 1, column 7:
PL/SQL: Statement ignored

*/


/* ERROR 2
CREATE OR REPLACE PROCEDURE addFunding IS
*
ERROR at line 1:
ORA-01031: insufficient privileges


BEGIN addFunding; END;

      *
ERROR at line 1:
ORA-06550: line 1, column 7:
PLS-00201: identifier 'ADDFUNDING' must be declared
ORA-06550: line 1, column 7:
PL/SQL: Statement ignored
*/


-- Fix for ERROR 1 and 2: 
-- Insert CONFIG_FUNDING_METHOD rows from QS 4.2 for evaluator_id's -1, 10, 12, 99

set scan off
INSERT INTO CONFIG_FUNDING_METHOD ( EVALUATOR_ID, FUND_METH_ID, PRODUCT_ID, ACTIVE_FLG, AUDIT_LAST_UPDATED_DT, AUDIT_UPDATED_USER_ID ) VALUES ( 
12, '1', 1, 1,  TO_Date( '05/14/2004 06:55:45 PM', 'MM/DD/YYYY HH:MI:SS AM'), 'SYSTEM'); 
INSERT INTO CONFIG_FUNDING_METHOD ( EVALUATOR_ID, FUND_METH_ID, PRODUCT_ID, ACTIVE_FLG, AUDIT_LAST_UPDATED_DT, AUDIT_UPDATED_USER_ID ) VALUES ( 
12, '2', 1, 1,  TO_Date( '05/14/2004 06:55:45 PM', 'MM/DD/YYYY HH:MI:SS AM'), 'SYSTEM'); 
INSERT INTO CONFIG_FUNDING_METHOD ( EVALUATOR_ID, FUND_METH_ID, PRODUCT_ID, ACTIVE_FLG, AUDIT_LAST_UPDATED_DT, AUDIT_UPDATED_USER_ID ) VALUES ( 
12, '3', 1, 1,  TO_Date( '05/14/2004 06:55:45 PM', 'MM/DD/YYYY HH:MI:SS AM'), 'SYSTEM'); 
INSERT INTO CONFIG_FUNDING_METHOD ( EVALUATOR_ID, FUND_METH_ID, PRODUCT_ID, ACTIVE_FLG, AUDIT_LAST_UPDATED_DT, AUDIT_UPDATED_USER_ID ) VALUES ( 
12, '4', 1, 1,  TO_Date( '05/14/2004 06:55:45 PM', 'MM/DD/YYYY HH:MI:SS AM'), 'SYSTEM'); 
INSERT INTO CONFIG_FUNDING_METHOD ( EVALUATOR_ID, FUND_METH_ID, PRODUCT_ID, ACTIVE_FLG, AUDIT_LAST_UPDATED_DT, AUDIT_UPDATED_USER_ID ) VALUES ( 
12, '5', 1, 1,  TO_Date( '05/14/2004 06:55:45 PM', 'MM/DD/YYYY HH:MI:SS AM'), 'SYSTEM'); 
INSERT INTO CONFIG_FUNDING_METHOD ( EVALUATOR_ID, FUND_METH_ID, PRODUCT_ID, ACTIVE_FLG, AUDIT_LAST_UPDATED_DT, AUDIT_UPDATED_USER_ID ) VALUES ( 
12, '6', 1, 1,  TO_Date( '05/14/2004 06:55:45 PM', 'MM/DD/YYYY HH:MI:SS AM'), 'SYSTEM'); 
INSERT INTO CONFIG_FUNDING_METHOD ( EVALUATOR_ID, FUND_METH_ID, PRODUCT_ID, ACTIVE_FLG, AUDIT_LAST_UPDATED_DT, AUDIT_UPDATED_USER_ID ) VALUES ( 
10, '1', 1, 1,  TO_Date( '05/14/2004 06:55:45 PM', 'MM/DD/YYYY HH:MI:SS AM'), 'SYSTEM'); 
INSERT INTO CONFIG_FUNDING_METHOD ( EVALUATOR_ID, FUND_METH_ID, PRODUCT_ID, ACTIVE_FLG, AUDIT_LAST_UPDATED_DT, AUDIT_UPDATED_USER_ID ) VALUES ( 
10, '2', 12, 1,  TO_Date( '05/14/2004 06:55:45 PM', 'MM/DD/YYYY HH:MI:SS AM'), 'SYSTEM'); 
INSERT INTO CONFIG_FUNDING_METHOD ( EVALUATOR_ID, FUND_METH_ID, PRODUCT_ID, ACTIVE_FLG, AUDIT_LAST_UPDATED_DT, AUDIT_UPDATED_USER_ID ) VALUES ( 
10, '3', 1, 0,  TO_Date( '05/14/2004 06:55:45 PM', 'MM/DD/YYYY HH:MI:SS AM'), 'SYSTEM'); 
INSERT INTO CONFIG_FUNDING_METHOD ( EVALUATOR_ID, FUND_METH_ID, PRODUCT_ID, ACTIVE_FLG, AUDIT_LAST_UPDATED_DT, AUDIT_UPDATED_USER_ID ) VALUES ( 
10, '4', 1, 0,  TO_Date( '05/14/2004 06:55:45 PM', 'MM/DD/YYYY HH:MI:SS AM'), 'SYSTEM'); 
INSERT INTO CONFIG_FUNDING_METHOD ( EVALUATOR_ID, FUND_METH_ID, PRODUCT_ID, ACTIVE_FLG, AUDIT_LAST_UPDATED_DT, AUDIT_UPDATED_USER_ID ) VALUES ( 
10, '5', 1, 1,  TO_Date( '05/14/2004 06:55:45 PM', 'MM/DD/YYYY HH:MI:SS AM'), 'SYSTEM'); 
INSERT INTO CONFIG_FUNDING_METHOD ( EVALUATOR_ID, FUND_METH_ID, PRODUCT_ID, ACTIVE_FLG, AUDIT_LAST_UPDATED_DT, AUDIT_UPDATED_USER_ID ) VALUES ( 
10, '6', 1, 0,  TO_Date( '05/14/2004 06:55:45 PM', 'MM/DD/YYYY HH:MI:SS AM'), 'SYSTEM'); 

-- ERRORS 1 and 2 Fixed


/* ERROR 3
CREATE OR REPLACE PROCEDURE addProduct IS
*
ERROR at line 1:
ORA-01031: insufficient privileges


BEGIN addProduct; END;

      *
ERROR at line 1:
ORA-06550: line 1, column 7:
PLS-00201: identifier 'ADDPRODUCT' must be declared
ORA-06550: line 1, column 7:
PL/SQL: Statement ignored


ALTER TABLE CREDIT_REQUEST_FUNDING MODIFY (product_id NOT NULL)
*
ERROR at line 1:
ORA-02296: cannot enable (NETBANK.) - null values found


ALTER TABLE CREDIT_REQUEST_PAYOFF MODIFY (product_id NOT NULL)
*
ERROR at line 1:
ORA-02296: cannot enable (NETBANK.) - null values found
*/


-- Fix for ERROR 3
-- Rerun with priveleges

/* Create procedure to populate product_id */
CREATE OR REPLACE PROCEDURE addProduct IS

  CURSOR c_product IS
   SELECT request_id, product_id
   FROM CREDIT_REQUEST;

  BEGIN

    FOR rec IN c_product LOOP

      UPDATE CREDIT_REQUEST_FUNDING SET product_id = rec.product_id WHERE request_id = rec.request_id;
      UPDATE CREDIT_REQUEST_PAYOFF SET product_id = rec.product_id WHERE request_id = rec.request_id;

    END LOOP; 

  END;
/
execute addProduct;

/* Make product_id required */
ALTER TABLE CREDIT_REQUEST_FUNDING MODIFY (product_id NOT NULL);
ALTER TABLE CREDIT_REQUEST_PAYOFF MODIFY (product_id NOT NULL);

-- ERROR 3 Fixed

/* ERROR 4
CREATE OR REPLACE PROCEDURE addOrigMeth IS
*
ERROR at line 1:
ORA-01031: insufficient privileges


BEGIN addOrigMeth; END;

      *
ERROR at line 1:
ORA-06550: line 1, column 7:
PLS-00201: identifier 'ADDORIGMETH' must be declared
ORA-06550: line 1, column 7:
PL/SQL: Statement ignored

*/

-- Fix for ERROR 4:
-- Rerun with privileges

/* Pop defaults from eo */
CREATE OR REPLACE PROCEDURE addOrigMeth IS

  CURSOR c_meth IS
   SELECT eo.evaluator_id,xeop.product_id,eo.fund_meth_id,eo.originator_id
   FROM EVALUATOR_ORIGINATOR eo, XREF_EVAL_ORIG_PRODUCT xeop
   WHERE eo.evaluator_id = xeop.evaluator_id
   AND eo.originator_id = xeop.originator_id;
  BEGIN

    FOR rec IN c_meth LOOP

      UPDATE XREF_EVAL_ORIG_PRODUCT 
      SET fund_meth_id = rec.fund_meth_id
      WHERE evaluator_id = rec.evaluator_id
      AND product_id = rec.product_id
      AND originator_id = rec.originator_id;

    END LOOP; 

  END;
/
execute addOrigMeth;

-- Fix for ERROR 4 Failed - Column dropped funding_method_id lost in evaluator_originator before
-- it was copied to xref_eval_orig_product.  Checked in NB42 config - All evaluator_originators
-- except FL301016, GA101013 and NetBank use funding_method_id = 4 = EFT/ACH.  The exceptions
-- use 1 = Cashier's check.  Talked with Mary.  Decided to set value to 4 in XREF_EVAL_ORIG_PRODUCT
-- table:

      UPDATE XREF_EVAL_ORIG_PRODUCT 
      SET fund_meth_id = 4
      WHERE evaluator_id = 12;
 
-- ERROR 4 Fixed - Note: Had to add config_funding_method for 12, 4 and 3 because 1 Direct Originator was added.


/* ERROR 5 - Triggers not created
AFTER INSERT OR UPDATE OR DELETE ON CONFIG_FUNDING_METHOD
                                    *
ERROR at line 2:
ORA-01031: insufficient privileges


AFTER INSERT OR UPDATE OR DELETE ON XREF_EVAL_ORIG_PRODUCT
                                    *
ERROR at line 2:
ORA-01031: insufficient privileges


AFTER INSERT OR UPDATE OR DELETE ON EVALUATOR_ORIGINATOR
                                    *
ERROR at line 2:
ORA-01031: insufficient privileges
*/


-- Fix for ERROR 5 - Regenerate Mnt Triggers at eoj


/* ERROR 6
DROP PROCEDURE addOrigMeth
*
ERROR at line 1:
ORA-04043: object ADDORIGMETH does not exist


DROP PROCEDURE copyFunding
*
ERROR at line 1:
ORA-04043: object COPYFUNDING does not exist


DROP PROCEDURE addFunding
*
ERROR at line 1:
ORA-04043: object ADDFUNDING does not exist


DROP PROCEDURE addProduct
*
ERROR at line 1:
ORA-04043: object ADDPRODUCT does not exist

*/

-- Fix for ERROR 6
-- Drop with privileges

DROP PROCEDURE addOrigMeth;
-- NA - Didn't create - DROP PROCEDURE copyFunding;
-- NA - Didn't create - DROP PROCEDURE addFunding;
DROP PROCEDURE addProduct;

-- ERROR 6 Fixed


/* ERROR 7

ALTER TABLE CREDIT_REQUEST_PAYOFF MODIFY product_id null
                                         *
ERROR at line 1:
ORA-01451: column to be modified to NULL cannot be modified to NULL


ALTER TABLE CREDIT_REQUEST_FUNDING MODIFY product_id null
                                          *
ERROR at line 1:
ORA-01451: column to be modified to NULL cannot be modified to NULL

*/

-- Fix for ERROR 7
-- Try again

ALTER TABLE CREDIT_REQUEST_PAYOFF MODIFY product_id null;
ALTER TABLE CREDIT_REQUEST_FUNDING MODIFY product_id null;

-- ERROR 7 Fixed


/* ERROR 8

CREATE OR REPLACE PROCEDURE copyVG IS
*
ERROR at line 1:
ORA-01031: insufficient privileges


BEGIN copyVG; END;

      *
ERROR at line 1:
ORA-06550: line 1, column 7:
PLS-00201: identifier 'COPYVG' must be declared
ORA-06550: line 1, column 7:
PL/SQL: Statement ignored

*/

/* ERROR 9
CREATE OR REPLACE PROCEDURE insVG IS
*
ERROR at line 1:
ORA-01031: insufficient privileges


BEGIN insVG; END;

      *
ERROR at line 1:
ORA-06550: line 1, column 7:
PLS-00201: identifier 'INSVG' must be declared
ORA-06550: line 1, column 7:
PL/SQL: Statement ignored

*/

-- Fix for ERROR 8 and 9: 
-- Insert VG_RETURN_VALUES rows from QS 4.2 for evaluator_id's -1, 10, 12, 99

INSERT INTO VG_RETURN_VALUES ( EVALUATOR_ID, VALUE_GUIDE_ID, NEW_USED_ID, VG_RETURN_TXT ) VALUES ( 
12, 2, 1, 'MSRP'); 
INSERT INTO VG_RETURN_VALUES ( EVALUATOR_ID, VALUE_GUIDE_ID, NEW_USED_ID, VG_RETURN_TXT ) VALUES ( 
12, 2, 2, 'Invoice'); 
INSERT INTO VG_RETURN_VALUES ( EVALUATOR_ID, VALUE_GUIDE_ID, NEW_USED_ID, VG_RETURN_TXT ) VALUES ( 
12, 2, 2, 'Loan'); 
INSERT INTO VG_RETURN_VALUES ( EVALUATOR_ID, VALUE_GUIDE_ID, NEW_USED_ID, VG_RETURN_TXT ) VALUES ( 
12, 2, 2, 'Retail'); 
INSERT INTO VG_RETURN_VALUES ( EVALUATOR_ID, VALUE_GUIDE_ID, NEW_USED_ID, VG_RETURN_TXT ) VALUES ( 
12, 3, 2, 'Average'); 
INSERT INTO VG_RETURN_VALUES ( EVALUATOR_ID, VALUE_GUIDE_ID, NEW_USED_ID, VG_RETURN_TXT ) VALUES ( 
12, 3, 2, 'Clean'); 
INSERT INTO VG_RETURN_VALUES ( EVALUATOR_ID, VALUE_GUIDE_ID, NEW_USED_ID, VG_RETURN_TXT ) VALUES ( 
12, 3, 2, 'Rough'); 
INSERT INTO VG_RETURN_VALUES ( EVALUATOR_ID, VALUE_GUIDE_ID, NEW_USED_ID, VG_RETURN_TXT ) VALUES ( 
12, 3, 2, 'XClean'); 
INSERT INTO VG_RETURN_VALUES ( EVALUATOR_ID, VALUE_GUIDE_ID, NEW_USED_ID, VG_RETURN_TXT ) VALUES ( 
10, 1, 2, 'Retail'); 
INSERT INTO VG_RETURN_VALUES ( EVALUATOR_ID, VALUE_GUIDE_ID, NEW_USED_ID, VG_RETURN_TXT ) VALUES ( 
10, 1, 2, 'Wholesale'); 
INSERT INTO VG_RETURN_VALUES ( EVALUATOR_ID, VALUE_GUIDE_ID, NEW_USED_ID, VG_RETURN_TXT ) VALUES ( 
10, 2, 2, 'Loan'); 
INSERT INTO VG_RETURN_VALUES ( EVALUATOR_ID, VALUE_GUIDE_ID, NEW_USED_ID, VG_RETURN_TXT ) VALUES ( 
10, 2, 2, 'Retail'); 
INSERT INTO VG_RETURN_VALUES ( EVALUATOR_ID, VALUE_GUIDE_ID, NEW_USED_ID, VG_RETURN_TXT ) VALUES ( 
10, 2, 2, 'Trade-In'); 
INSERT INTO VG_RETURN_VALUES ( EVALUATOR_ID, VALUE_GUIDE_ID, NEW_USED_ID, VG_RETURN_TXT ) VALUES ( 
10, 3, 2, 'Average'); 
INSERT INTO VG_RETURN_VALUES ( EVALUATOR_ID, VALUE_GUIDE_ID, NEW_USED_ID, VG_RETURN_TXT ) VALUES ( 
10, 3, 2, 'Clean'); 
INSERT INTO VG_RETURN_VALUES ( EVALUATOR_ID, VALUE_GUIDE_ID, NEW_USED_ID, VG_RETURN_TXT ) VALUES ( 
10, 3, 2, 'Rough'); 
INSERT INTO VG_RETURN_VALUES ( EVALUATOR_ID, VALUE_GUIDE_ID, NEW_USED_ID, VG_RETURN_TXT ) VALUES ( 
10, 3, 2, 'XClean'); 

-- ERRORS 8 and 9 Fixed


/* ERROR 10

AFTER INSERT OR UPDATE OR DELETE ON EVALUATOR
                                    *
ERROR at line 2:
ORA-01031: insufficient privileges

*/

-- Fix for ERROR 10 - Regenerate Mnt Triggers at eoj

/* ERROR 11
DROP PROCEDURE copyVG
*
ERROR at line 1:
ORA-04043: object COPYVG does not exist


DROP PROCEDURE insVG
*
ERROR at line 1:
ORA-04043: object INSVG does not exist

*/

-- Fix for ERROR 11
-- NA - Not creating procedures this time around

/* End of ERRORS */

