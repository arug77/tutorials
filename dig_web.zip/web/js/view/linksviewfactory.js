/**
* Makes links views (buttons or whatever) based on parameters
* supplied by the caller.
*/
function LinksViewFactory()
{
  /**
  * Makes a view (represented by an string of html) given the supplied parameters.
  */
  this.makeView = function(context)
  {
    var html = this._renderTemplate('button-template', context);
    return html;
  };
  
  // Declared in helpers.js
  this._renderTemplate = renderTemplate;
}

/**
* Get an appropriate instance of LinksViewFactory.
*/
var getLinksViewFactory = (function() {
  var singleton = null;
  return function() {
    if (null == singleton) {
      singleton = new LinksViewFactory();
    }
    return singleton;
  }
})();
