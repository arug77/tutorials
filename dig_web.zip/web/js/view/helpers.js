/**
* Not a Handlebars helper, but it helps with Handlebars.
* @param name The name of the template to render.
* @param context The context params for the template.
* @return string A string of HTML.
*/ 
function renderTemplate(name, context)
{
  var source = $('#' + name).html();
  var template = Handlebars.compile(source);
  var html = template(context);
  return html;
}

/**
* Add the corresponding values in resource into the corresponding entries in the metadata
* dictionary.
*/
Handlebars.registerHelper('metadataWithResourceValues', function(metadata, resourceOrNull)
{
  if (null == resourceOrNull) {
    return metadata;
  }
  metadata.forEach(function(entry) {
        
    // The JSON is defined such that every metadata entry
    // is guaranteed to have a corresponding key-value pair
    // in the resource.
    
    var resourceValue = resourceOrNull[entry['name']];
    if (null == resourceValue) {
      throw "JSON consistency error.";
    }
    entry['value'] = resourceValue;
  });
  return metadata;
});

/**
* Compares val1 and val2 for equality.
*/
Handlebars.registerHelper('equal', function(val1, val2)
{
  return val1 == val2;
});

/**
* Gets the onClick event that should be attached to buttons
*/
Handlebars.registerHelper('onClickEvent', function(rel)
{
  var onClickEvent = "getAppController().onButtonPress(\"" + rel + "\")";
  return onClickEvent;
});

Handlebars.registerHelper('makeView', function(context)
{
  return new Handlebars.SafeString(
    getContentViewFactory().makeView(context)
  );
});

Handlebars.registerHelper('makeButton', function(context)
{
  return new Handlebars.SafeString(
    getLinksViewFactory().makeView(context)
  );
});