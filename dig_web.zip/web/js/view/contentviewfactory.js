/**
* Makes content views (form fields for user input) based on parameters
* supplied by the caller.
*/
function ContentViewFactory()
{
  // Data Types
  var DATA_TYPE_STRING = "string";
  var DATA_TYPE_INTEGER = "integer";
  var DATA_TYPE_BOOLEAN = "boolean";
  var DATA_TYPE_DATE = "date";

  // Allowed Values
  var ALLOWED_VALUES_TYPE_NULL = "allowed values type null";
  var ALLOWED_VALUES_TYPE_ARRAY = "allowed values type array";
  var ALLOWED_VALUES_TYPE_STRING = "allowed values type string";
 
  /**
  * @param context An object holding all key-value pairs present in
  * the metadata dictionary, as well as an optional 'value' key
  * that denotes the currently selected value.
  * @return A string of HTML.
  */
  this.makeView = function(context)
  {
    var func = this._getFuncForDataType(context.dataType);
    var html = func(context);
    return html;
  };
  
  this._getFuncForDataType = function(dataType)
  {
    var func = this._dataTypeMappings[dataType];
    return func.bind(this);
  };
  
  this._getAllowedValuesType = function(allowedValues)
  {
    if (null == allowedValues) {
      return ALLOWED_VALUES_TYPE_NULL;
    } else if (Array.isArray(allowedValues)) {
      return ALLOWED_VALUES_TYPE_ARRAY
    } else if ("string" == typeof(allowedValues)) {
      return ALLOWED_VALUESS_TYPE_STRING;
    }
    throw "allowedValues has unsupported type."
  };
  
  // Declared in helpers.js
  this._renderTemplate = renderTemplate;
  
  //----------------
  //
  // String
  //
  //----------------
  
  this._makeStringInputView = function(context)
  {
    var func = this._stringAllowedValuesMappings[this._getAllowedValuesType(context.allowedValues)].bind(this);
    var html = func(context);
    return html;
  };
  
  this._makeTextField = function(context)
  {
    var html = this._renderTemplate('textfield-template', context);
    return html;
  };
  
  this._makeDropDown = function(context)
  {
    var html = this._renderTemplate('dropdownlist-template', context);
    return html;
  }
   
  this._stringAllowedValuesMappings = {};
  this._stringAllowedValuesMappings[ALLOWED_VALUES_TYPE_NULL] = this._makeTextField;
  this._stringAllowedValuesMappings[ALLOWED_VALUES_TYPE_ARRAY] = this._makeDropDown;
  
  //----------------
  //
  // Integer
  //
  //----------------
  
  this._makeIntegerInputView = function(context)
  {
    var func = this._integerAllowedValuesMappings[this._getAllowedValuesType(context.allowedValues)].bind(this);
    var html = func(context);
    return html;
  };
  
  this._makeNumberField = function(context)
  {
    var html = this._renderTemplate('numberfield-template', context);
    return html;
  };
  
  this._integerAllowedValuesMappings = {};
  this._integerAllowedValuesMappings[ALLOWED_VALUES_TYPE_NULL] = this._makeNumberField;
  
  //----------------
  //
  // Boolean
  //
  //----------------
  
  this._makeBooleanInputView = function(context)
  {
    var func = this._booleanAllowedValuesMappings[this._getAllowedValuesType(context.allowedValues)].bind(this);
    var html = func(context);
    return html;
  };
  
  this._makeRadioButtons = function(context)
  {  
    // Values for booleans are passed around as true/false, but when we display them to
    // the user, we need to show Yes/No (or anything else). Where should localization for
    // booleans go? Client-side or server-side?
    
    // The context variable must be cloned before it is mutated, or else
    // it will permanently alter the hard-coded fixture data from repository.js
    var mutableContext = JSON.parse(JSON.stringify(context));
    if (undefined != mutableContext.value) {
      mutableContext.value = mutableContext.value ? 'Yes' : 'No';
    }
    mutableContext.allowedValues = ['Yes', 'No'];
    
    var html = this._renderTemplate('radiobuttons-template', mutableContext);

    return html;
  };
  
  this._booleanAllowedValuesMappings = {};
  this._booleanAllowedValuesMappings[ALLOWED_VALUES_TYPE_NULL] = this._makeRadioButtons;
  
  //----------------
  //
  // Date
  //
  //----------------
  
  this._makeDateInputView = function(context)
  {
    var func = this._dateAllowedValuesMappings[this._getAllowedValuesType(context.allowedValues)].bind(this);
    var html = func(context);
    return html;
  };
  
  this._makeDatePicker = function(context)
  {
    var html = this._renderTemplate('datepicker-template', context);
    return html;
  };
  
  this._dateAllowedValuesMappings = {};
  this._dateAllowedValuesMappings[ALLOWED_VALUES_TYPE_NULL] = this._makeDatePicker;
  
  //----------------
  //
  // Data Types
  //
  //----------------
  
  this._dataTypeMappings = {};
  this._dataTypeMappings[DATA_TYPE_STRING] = this._makeStringInputView;
  this._dataTypeMappings[DATA_TYPE_INTEGER] = this._makeIntegerInputView;
  this._dataTypeMappings[DATA_TYPE_BOOLEAN] = this._makeBooleanInputView;
  this._dataTypeMappings[DATA_TYPE_DATE] = this._makeDateInputView;
}

/**
* Get an appropriate instance of InputViewFactory.
*/
var getContentViewFactory = (function() {
  var singleton = null;
  return function() {
    if (null == singleton) {
      singleton = new ContentViewFactory();
    }
    return singleton;
  }
})();