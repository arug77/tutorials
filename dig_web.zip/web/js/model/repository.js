/**
* Concrete Repository that uses fixtures as its backing
* data store.
*/
function FixtureRepository()
{
  this.loadInitialJson = function(callback)
  {
    callback(this._fixtures['POST']['quote']);
  };
  
  this.submitJson = function(json, href, method, callback)
  {
    var jsonResponse = this._fixtures[method][href];
    jsonResponse = this._checkForRedirect(jsonResponse);
    callback(jsonResponse);
  };

  this._checkForRedirect = function(json)
  {
    var redirect = json['response']['redirect'];
    if (redirect) {
      var href = redirect['href'];
      json = this._fixtures['GET'][href];
    }
    return json;
  };
  
  this._fixtures = {
    
    'POST' : {
      'quote' : {
        'response' : {
          'links' : [
          {
            'rel' : 'second',
            'method' : 'POST',
            'href' : 'first?rel=second',
            'label' : 'Next'
          }
          ],
          'metadata' : [
          {
            'name' : 'name',
            'dataType' : 'string',
            'allowedValues' : null,
            'label' : 'Name'
          },
          {
            'name' : 'address',
            'dataType' : 'string',
            'allowedValues' : null,
            'label' : 'Address'
          },
          {
            'name' : 'city',
            'dataType' : 'string',
            'allowedValues' : ['Richardson', 'Plano', 'McKinney'],
            'label' : 'City'
          },
          {
            'name' : 'DOB',
            'dataType' : 'date',
            'allowedValues' : null,
            'label' : 'Date of Birth'
          }
          ]
        }
      },
      'first?rel=second' : {
        'response' : {
          'links' : [
          {
            'rel' : 'first',
            'method' : 'PUT',
            'href' : 'second?rel=first',
            'label' : 'Previous'
          },
          {
            'rel' : 'third',
            'method' : 'POST',
            'href' : 'second?rel=third',
            'label' : 'Next'
          }
          ],
          'metadata' : [
          {
            'name' : 'smoker',
            'dataType' : 'boolean',
            'allowedValues' : null,
            'label' : 'Do you smoke?'
          },
          {
            'name' : 'felony',
            'dataType' : 'boolean',
            'allowedValues' : null,
            'label' : 'Have you ever been convicted of a felony?'
          },
          {
            'name' : 'pet',
            'dataType' : 'boolean',
            'allowedValues' : null,
            'label' : 'Do you own a pet?'
          }
          ]
        }
      },
      'second?rel=third' : {
        'response' : {
          'links' : [
          {
            'rel' : 'second',
            'method' : 'PUT',
            'href' : 'third?rel=second',
            'label' : 'Previous'
          },
          {
            'rel' : 'fourth',
            'method' : 'POST',
            'href' : 'third?rel=fourth',
            'label' : 'Next'
          }
          ],
          'metadata' : [
          {
            'name' : 'dwi',
            'dataType' : 'boolean',
            'allowedValues' : null,
            'label' : 'Have you ever been convicted of a DWI?'
          },
          {
            'name' : 'age',
            'dataType' : 'integer',
            'allowedValues' : null,
            'label' : 'Enter your age:'
          },
          {
            'name' : 'residence',
            'dataType' : 'integer',
            'allowedValues' : null,
            'label' : 'How long have you lived in the United States?'
          }
          ]
        }
      },
      'third?rel=fourth' : {
        'response' : {
          'links' : [
          {
            'rel' : 'third',
            'method' : 'PUT',
            'href' : 'fourth?rel=third',
            'label' : 'Previous'
          },
          {
            'rel' : 'finish',
            'method' : 'what happens now?',
            'href' : 'how do we finish?',
            'label' : 'Finish'
          }
          ],
          'metadata' : [
          {
            'name' : 'deductible',
            'dataType' : 'string',
            'allowedValues' : ['$50 deductible', '$100 deductible', '$150 deductible'],
            'label' : 'Select your deductible.'
          },
          ]
        }
      },
      'fourth' : {
        
      }
    },
    
    'PUT' : {
      'second?rel=first' : {
        'response' : {
          'redirect' : {
            'href' : 'first'
          }
        }
      },
      'third?rel=second' : {
        'response' : {
          'redirect' : {
            'href' : 'second'
          }
        }
      },
      'fourth?rel=third' : {
        'response' : {
          'redirect' : {
            'href' : 'third'
          }
        }
      }
    },
    
    'GET' : {
      'first' : {
        'response' : {
          'resource' : {
            'name' : 'John Doe',
            'address' : '123 Street',
            'city' : 'Plano',
            'DOB' : '1982-11-10'
          },
          'links' : [
          {
            'rel' : 'second',
            'method' : 'POST',
            'href' : 'first?rel=second',
            'label' : 'Next'
          }
          ],
          'metadata' : [
          {
            'name' : 'name',
            'dataType' : 'string',
            'allowedValues' : null,
            'label' : 'Name'
          },
          {
            'name' : 'address',
            'dataType' : 'string',
            'allowedValues' : null,
            'label' : 'Address'
          },
          {
            'name' : 'city',
            'dataType' : 'string',
            'allowedValues' : ['Richardson', 'Plano', 'McKinney'],
            'label' : 'City'
          },
          {
            'name' : 'DOB',
            'dataType' : 'date',
            'allowedValues' : null,
            'label' : 'Date of Birth'
          }
          ]
        }
      },
      'second' : {
        'response' : {
          'resource' : {
            'smoker' : false,
            'felony' : true,
            'pet' : true
          },
          'links' : [
          {
            'rel' : 'first',
            'method' : 'PUT',
            'href' : 'second?rel=first',
            'label' : 'Previous'
          },
          {
            'rel' : 'third',
            'method' : 'POST',
            'href' : 'second?rel=third',
            'label' : 'Next'
          }
          ],
          'metadata' : [
          {
            'name' : 'smoker',
            'dataType' : 'boolean',
            'allowedValues' : null,
            'label' : 'Do you smoke?'
          },
          {
            'name' : 'felony',
            'dataType' : 'boolean',
            'allowedValues' : null,
            'label' : 'Have you ever been convicted of a felony?'
          },
          {
            'name' : 'pet',
            'dataType' : 'boolean',
            'allowedValues' : null,
            'label' : 'Do you own a pet?'
          }
          ]
        }
      },
      'third' : {
        'response' : {
          'resource' : {
            'dwi' : true,
            'age' : 26,
            'residence' : 24
          },
          'links' : [
          {
            'rel' : 'second',
            'method' : 'PUT',
            'href' : 'third?rel=second',
            'label' : 'Previous'
          },
          {
            'rel' : 'fourth',
            'method' : 'POST',
            'href' : 'third?rel=fourth',
            'label' : 'Next'
          }
          ],
          'metadata' : [
          {
            'name' : 'dwi',
            'dataType' : 'boolean',
            'allowedValues' : null,
            'label' : 'Have you ever been convicted of a DWI?'
          },
          {
            'name' : 'age',
            'dataType' : 'integer',
            'allowedValues' : null,
            'label' : 'Enter your age:'
          },
          {
            'name' : 'residence',
            'dataType' : 'integer',
            'allowedValues' : null,
            'label' : 'How long have you lived in the United States?'
          }
          ]
        }
      },
      'fourth' : {
        
      }      
    }
  };
}

/**
* Concrete Repository that uses the actual network as its
* data store.
*/
function NetworkRepository()
{
  throw 'NetworkRepository not implemented.';
}

/**
* Gets an appropriate Repository instance.
* This is where we can switch between using
* fixtures vs. actual network calls.
*/
var getRepository = (function() {
  var singleton = null;
  return function() {
    if (null == singleton) {
      singleton = new FixtureRepository();
    }
    return singleton;
  }
})();