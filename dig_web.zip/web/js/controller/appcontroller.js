/**
* The single controller for the entire application.
*/
function AppController()
{
  this.onLoad = function()
  {
    var self = this;
    getRepository().loadInitialJson(function (json) {
      self._json = json;
      self._renderView();
    });
  };
  
  this.onButtonPress = function(rel)
  {
    var linksEntry = this._getLinksEntryForRel(rel);
    var href = linksEntry['href'];
    var method = linksEntry['method'];
    var self = this;
    getRepository().submitJson(this._json, href, method, function(json) {
      self._json = json;
      self._renderView();
    })
  };
  
  this._renderView = function()
  {
    this._renderContent();
    this._renderLinks();
  };
  
  // Declared in helpers.js
  this._renderTemplate = renderTemplate;
  
  this._renderContent = function()
  {
    var context = { 'metadata' : this._json['response']['metadata'], 'resource' : this._json['response']['resource'] };
    var html = this._renderTemplate('content-template', context);
    $('#content').html(html);
  };
  
  this._renderLinks = function()
  {
    var context = {'links' : this._json['response']['links'] };
    var html = this._renderTemplate('links-template', context);
    $('#links').html(html);
  };
  
  this._getLinksEntryForRel = function(rel)
  {
    var links = this._json['response']['links'];
    var result = null;
    links.every(function(entry) {
      if (rel == entry['rel']) {
        result = entry;
        return false;
      }
      return true;
    });
    if (null == result) {
      throw "Internal logic error.";
    }
    return result;
  };
  
  this._json = null;
}

/**
* Get the singleton instance of AppController.
*/
var getAppController = (function() {
  var singleton = null;
  return function() {
    if (null == singleton) {
      singleton = new AppController();
    }
    return singleton;
  }
})();